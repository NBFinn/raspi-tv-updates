# Temperaturabhaengiger Zweikabel-Luefter (ab 5.8.2)

Ein eigener **GPIO26, physischer Steckplatz 37**, schaltet einen passenden
Lueftertreiber. Er kollidiert nicht mit dem Anschlussplan der beiden runden Displays.
Es ist keine Verteilerplatine erforderlich. Der GPIO liefert nur das Steuersignal.

## Verhalten

- Standard: ein ab etwa **60 Grad CPU-Temperatur**, aus nach Abkuehlung unter etwa
  **50 Grad**. Zwischen beiden Grenzen bleibt der bisherige Zustand erhalten.
- Der Zweikabel-Luefter wird ein-/ausgeschaltet. Es gibt keine Drehzahlmessung und
  keine zugesicherte stufenlose Drehzahlregelung.
- Die Regelung nutzt das Linux-`gpio-fan`-Overlay. Sie arbeitet nach Aktivierung und
  Neustart auch bei ausgefallener TV-Oberflaeche und waehrend Musik/Bildschirmschoner.
- Ein normales Update aktiviert keinen GPIO und aendert die Boot-Konfiguration nicht.
  Einmal aktivierte Kernel-Einstellungen bleiben bei weiteren App-Updates erhalten.

## Benoetigte Hardware und eigene Pins

**Den Motor nicht direkt an einen GPIO anschliessen.** Benoetigt wird ein fuer
den Luefterstrom geeignetes MOSFET-/Transistormodul mit **3,3-V-kompatiblem,
aktiv-hohem Steuereingang**, definiertem AUS bei unbeschaltetem Eingang (Pull-down)
und geeigneter Schutzbeschaltung fuer die Last. Kein beliebiges aktives LOW-Modul.
Vor dem Verkabeln Pi ausschalten und vom Strom trennen.

| Verbindung | Eigener physischer Pi-Steckplatz |
|---|---|
| Treiber-Steuereingang IN / SIG | **37** (GPIO26, 3,3-V-Signal) |
| Treiber-Masse GND | **14** (Masse) |
| Versorgung fuer Treiber/Last, **nur bei geeignetem 5-V-Luefter** | **2** (5 V) |

Der Luefter selbst wird am geschalteten Lastausgang des Moduls angeschlossen,
entsprechend dessen Beschriftung und Anleitung. Er haengt nicht am Signalpin.
Bei geeigneten Modulen sind Eingangs- und Lastmasse bereits intern verbunden;
vor dem Kauf/Anschluss das konkrete Modell pruefen. So benoetigt der Pi nur einen
Masse-Steckplatz. Die beiden Display-Anschluesse bleiben unveraendert.

Die Luefterspannung ist bisher unbekannt. **5 V nicht allein aus zwei Kabeln ableiten.**
Bei 12 V ist eine passende externe Versorgung erforderlich, deren Spannung niemals
an den Pi-GPIO oder die 5-V-Pins gelangen darf. Auch bei 5 V muessen Luefterstrom,
Treiber und das verfuegbare Netzteilbudget passen. Ohne bekanntes Modul und
Luefterdaten ist dies eine Anschlussuebersicht, keine modellspezifische Verdrahtung.

## Einmal aktivieren

Update **5.8.2** installieren. Erst nach passender Verkabelung im Notfall-Terminal:

```sh
bash /opt/raspi-tv/enable-fan.sh
```

In der normalen SSH-/Textkonsole fordert das Skript bei Bedarf `sudo` und dein
Linux-Anmeldepasswort an. Mit `JA` bestaetigen und anschliessend neu starten.
Das Skript sichert vorher die Boot-Konfiguration und verwendet GPIO26.
Eine vorhandene fremde Luefter-Konfiguration wird nicht automatisch ersetzt.
Andere GPIO-Geraete/Overlays duerfen GPIO26 nicht gleichzeitig verwenden;
auch eingebundene eigene Boot-Konfigurationsdateien vorher darauf pruefen.

Optional andere Einschalttemperatur, z. B. 65 Grad (aus unter etwa 55 Grad):

```sh
bash /opt/raspi-tv/enable-fan.sh --on 65
```

Zulaessig sind 45 bis 80 Grad, Ausschaltabstand immer 10 Grad. Aenderungen benoetigen
einen Neustart. Zum Entfernen des eigenen Konfigurationsblocks:

```sh
bash /opt/raspi-tv/enable-fan.sh --disable
```

Danach ebenfalls neu starten. Das deaktiviert die automatische Kuehlung;
ausreichende andere Kuehlung sicherstellen.

## Pruefen

Nach dem Neustart das tatsaechliche Anlaufen bei Erreichen der Temperatur und
spaeteres Abschalten pruefen. Aus einem Zweikabel-Anschluss laesst sich nicht erkennen,
ob der Motor blockiert ist. Die CPU-Temperatur kann mit `vcgencmd measure_temp`
angezeigt werden. Keine Absicherung durch eine laufende TV-Oberflaeche erforderlich.
Die Konfigurations- und Pakettests laufen am Entwicklungsrechner; ein echter
Luefter-/GPIO-/Temperaturtest auf deinem Pi steht noch aus.

Technische Referenzen: [Raspberry-Pi GPIO-Fan-Overlay](https://github.com/raspberrypi/linux/blob/rpi-6.12.y/arch/arm/boot/dts/overlays/gpio-fan-overlay.dts),
[Raspberry-Pi GPIO-Dokumentation](https://www.raspberrypi.com/documentation/computers/raspberry-pi.html).
