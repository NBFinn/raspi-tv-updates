# Raspi-TV OS

**Update 7.1.8** – Spotify vom Handy zuverlässiger steuern: Weiter/Zurück bleiben bei
Titel-Aktualisierungen bedienbar. Nach einem Neustart der Browser-Erweiterung werden
die Steuerverbindungen zu Home und Spotify wiederhergestellt, ohne den Spotify-Tab
neu zu laden. Bluetooth-Updates werden in kleineren Stücken übertragen; bekannte
Handys warten beim Wiederverbinden nicht auf eine Namensabfrage. Eine neue Verbindung
ersetzt die alte, ohne deren wartende Tasten später auszuführen.

Basis ist das vollständige Online-Update 7.1.7. Teensy-Firmware 1.0.6 und Android-App
1.11 bleiben erhalten; die App lädt die neue Oberfläche vom Pi. Nach der Installation
bei Bedarf in der Handy-App über ⋮ die Update-Suche starten. Das kleine ZIP lässt
vorhandene Hintergrundbilder, Videos und Schriften auf dem Pi erhalten.

**Update 7.1.7** – Stabilere Bluetooth-Verbindung zur Handy-App (App 1.11): Herzschlag alle 4 s erkennt
tote Verbindungen sofort, Neuverbinden nach 0,3 s statt bis zu 15 s, Tasten während eines kurzen Aussetzers
werden nachgeschickt statt verworfen, kurze Aussetzer zeigen kein „Keine Verbindung“ mehr. Raspi-TV
beantwortet den Herzschlag sofort, auch während langsamer Befehle (z. B. CEC), und zeigt unter
Fernbedienung → Handy die Verbindungsabbrüche der letzten 24 Stunden mit Grund an.

**Update 7.1.6** – Teensy wird automatisch erkannt: an jedem USB-Anschluss und mit jedem „USB Type“
(Serial, Serial+MIDI, Dual Serial …). Ein neuer Dienst (raspi-tv-teensy-watch) sucht alle 3 Sekunden,
startet die Displays und spielt die Firmware ein – auch wenn der Teensy eine fremde Firmware hat oder im
Programmiermodus hängt. Bis zu 3 automatische Versuche pro Firmware-Version. Teensy-Firmware 1.0.6.
Die Handy-App (1.10) aktualisiert sich jetzt über Raspi-TV – auch nur per Bluetooth: neue Oberfläche
sofort, neue App mit einer Bestätigung („Installieren?“).

**Update 7.1.5** – Updates werden schneller erkannt: Raspi-TV sieht alle 10 Minuten nach (statt alle
6 Stunden) und liest dafür nur die kleine Datei `version.json`; bei GitHub über die API, die neue
Versionen sofort liefert. Das Paket wird erst beim Installieren geladen.

**Update 7.1.4** – Teensy-Firmware wird jetzt ohne Zusatzprogramm eingespielt: Raspi-TV spricht den
Bootloader des Teensy (HalfKay) selbst über /dev/hidraw an. Bisher wurde `teensy-loader-cli` aus dem
Internet gebraucht – fehlte es, blieb die alte Firmware drauf. (`teensy_loader_cli` bleibt Ausweichweg.)

**Update 7.1.3** – Teensy-Firmware 1.0.5: Uhr läuft gleichmäßig. Der Pi schickt die Zeit jetzt auf
die Millisekunde; der Teensy zieht kleine Abweichungen sanft nach statt bei jedem Abgleich (2× pro
Sekunde) auf die volle Sekunde zurückzuspringen.

**Update 7.1.2** – Teensy-Firmware 1.0.4: Die Update-Seite der runden Displays zeigt jetzt Raspi-TV-
und Teensy-Firmware-Version. Nach einem Firmware-Update zeigen beide Displays einige Sekunden lang
„Teensy aktualisiert“ mit alter → neuer Version (der Teensy merkt sich seine Version im EEPROM).

**Update 7.1.1** – Teensy-Neustarts: Firmware wird automatisch nur noch EINMAL je Version eingespielt
(nie mehr in einer Schleife); erneutes Einspielen per Knopf unter *Runde Displays*. Die Einstellungen
zeigen, wie oft und warum der Teensy neu gestartet ist (Strom/Spannungseinbruch, Absturz, Watchdog)
und ob der Pi Unterspannung meldet (zu schwaches Netzteil → auch der Teensy am USB startet neu).

**Update 7.1.0** – Teensy-Firmware 1.0.3: **Neustart-Animation** (kreisender Pfeil um das Logo, danach
wieder die Startanimation), **Ausschalt-Animation** („Bis bald“ / „Gute Nacht“, Displays gehen aus),
**Standby-Bild** bei ausgeschaltetem Fernseher (Mond und Sterne, Uhr gedimmt). Der Teensy meldet jetzt
Neustartgrund und Absturzbericht; die Einstellungen zeigen, wenn er unerwartet neu startet.
Firmware-Updates nur noch nach erkannter Version (kein „blindes“ Einspielen mehr).

**Update 7.0.2** – Runde Displays zeigen jetzt alles, was läuft (wie die Handy-App): Spotify
(Connect und Web-Player), Videos im Browser (YouTube, Mediatheken, Netflix …) und Radio – auf jeder
Seite, nicht nur auf der Startseite; Cover/Senderlogo und Quelle („RADIO“, „YOUTUBE“ …) inklusive.
Teensy-Firmware 1.0.2 wird automatisch eingespielt: Der Pi schickt den Teensy per USB-Befehl in den
Programmiermodus – kein Abstecken, kein Knopf (höchstens 2 Versuche je Version, dann Hinweis).

**Update 7.0.1** – Teensy-Firmware 1.0.1: Helligkeit per Software (für Displays ohne BL-Pin).

**Update 7.0.0** – Runde Displays am **Teensy 4.1** (USB): Der Teensy zeichnet beide Displays mit
eigener Firmware (kantengeglättete Grafik, bis ca. 30 Bilder/s, Übergänge Wischen/Iris/Schieben,
Equalizer-Kranz um das Albumcover, leuchtende Ringspitzen, nachglühende Minutenstriche, wandernder
Lichtschein). Der Pi schickt nur Zustand und Albumcover und spielt die Firmware selbst ein
(neuer Teensy: einmal den Knopf drücken). Verdrahtung und Details: `teensy/README.md`.
Ohne Teensy laufen die Displays wie bisher an den GPIO-Pins.

**Update 6.4.0** – Fernseher ausschalten ohne CEC-Aus (z. B. ältere Medion-Fernseher):
Im Standby (Ausschalten, Auto-Aus, Schlaf-Timer, iPhone) schaltet Raspi-TV zusätzlich das Bildsignal
ab. Fernseher, die den CEC-Aus-Befehl ignorieren, gehen dann nach einigen Minuten ohne Signal selbst
in Standby. Jede Taste (Fernbedienung, Handy-App, iPhone) oder „Fernseher an“ bringt das Bild sofort
zurück. Abschaltbar: *Einstellungen · Energie · Im Standby Bildsignal abschalten*.
Ein/Aus über HDMI-CEC probiert jetzt mehrere Varianten (direkt, Broadcast, „Text View On“,
„Active Source“) für neue und ältere Fernseher; ohne Kernel-CEC-Anschluss wird `cec-client` genutzt.

**Update 6.3.1** – Lautstärke-Schutz: Springt die Lautstärke ohne Tastendruck auf 100 % (passiert,
wenn der Fernseher ausgeschaltet wird und der HDMI-Tonausgang kurz verschwindet), stellt Raspi-TV
innerhalb von 2 Sekunden den letzten Wert wieder her. Die runden Displays zeigen bei
ausgeschaltetem Fernseher den gemerkten Wert statt 100. Absichtlich auf 100 % gestellt bleibt 100 %.

**Update 6.3.0** – flüssigere Display-Animationen und Systemupdates
- **Systemupdates inklusive:** Jedes Raspi-TV-Update aktualisiert auch Raspberry Pi OS
  (`apt-get upgrade`, entfernt nie Pakete, behält Konfigurationen). Das Update dauert dadurch
  einige Minuten länger; Display 2 zeigt den Fortschritt („Systemupdates 12 von 80 Paketen“).
  Ohne Internet geht es ohne Systemupdates weiter. Abschaltbar unter *Einstellungen · Updates*.
- **Flüssigere runde Displays:** Änderungen werden in schmalen Streifen übertragen statt als ein
  großer Ausschnitt (Seitenwechsel bei 4 MHz ca. 15–25 Bilder/s statt 4–5), jedes Display hat einen
  eigenen Sende-Thread. Neu: *Übertragung 4/8/16/32 MHz* unter *Runde Displays · Aussehen* –
  höher = noch flüssiger; bei Streifen oder Bildfehlern zurück auf 4 MHz.

**Update 6.2.1** – Test-Update für die Update-Seite der runden Displays (keine Funktionsänderung).

**Update 6.2.0** – animierte runde Displays
- Seitenwechsel als Wisch wie ein Uhrzeiger, Ringe (WLAN, CPU, Lautstärke) füllen sich beim
  Erscheinen, Zahlen zählen hoch, Lautstärke gleitet weich zum neuen Wert, Uhr mit fließendem
  Sekundenzeiger und einschwingenden Zeigern, Haken zeichnet sich, Equalizer bei Spotify.
- Neue Seite **Updates** auf Display 2: installierte Version, „NEU“ mit neuer Version, Fortschritt
  während der Installation (bleibt dann stehen), Fehler bei nicht erreichbarem Server.
- *Einstellungen · Runde Displays · Aussehen*: „Animationen: An/Aus“.

---

**Update 6.1.1** – Updates kommen ab jetzt von selbst: Die Online-Update-Adresse
`https://raw.githubusercontent.com/NBFinn/raspi-tv-updates/main/raspi-tv-update.zip` ist voreingestellt,
„Automatisch installieren“ ist an. Der Pi prüft alle 6 Stunden und installiert neue Versionen nachts
zwischen 3 und 5 Uhr, wenn der Fernseher aus ist (mit automatischer Rückkehr, falls der Start
fehlschlägt). Abschalten oder andere Adresse: *Einstellungen · Updates · Online-Update*.

---

**Update 6.1.0** – runde Displays im neuen Look

- **Startanimation** auf beiden runden Displays: Display 1 zeichnet das neue Logo (Rahmen,
  Farbverlauf, Play-Symbol, Sendewelle, Schriftzug), Display 2 füllt den Ring im Markenverlauf
  und zeigt „Bereit“ mit der Version. Solange Raspi-TV noch startet, erscheint ein Wartebild.
- **Farben passend zum Design**: Uhr, Ringe und Texte übernehmen die Akzentfarbe des
  Hintergrundbilds bzw. der gewählten Akzentfarbe; bei Spotify die kräftigste Farbe des
  Albumcovers. Farbwechsel werden weich überblendet. Ringe mit Farbverlauf.
- **Flüssiger**: Es wird nur noch der geänderte Bildausschnitt übertragen (alle 20 s einmal
  das ganze Bild zur Sicherheit). Animationen laufen dadurch trotz 4 MHz flüssig.
- *Einstellungen · Runde Displays · Aussehen*: Farben „Wie das Design“/„Klassisch Türkis“,
  Startanimation an/aus, „Startanimation jetzt zeigen“.
- Kleines Update (ohne Medien): vorhandene Hintergründe und Videos aus 6.0 bleiben erhalten.

---

**Update 6.0.0** – neues Erscheinungsbild, Medienbibliothek und schnellere Oberfläche
(Grundlage: 5.9.4 mit allen Display-, Lüfter-, Notfall- und Multimedia-Werkzeugen).

- **Neues Logo** (Bildschirm-Squircle mit Wiedergabe-Symbol und Sendewelle) in Oberfläche,
  Handy-App, App-Symbol und Startanimation; neue Schrift **Plus Jakarta Sans** (SIL OFL).
- **35 Hintergrundbilder in 4K** (Polarlicht, Nebel, Wellen, Bokeh, Verlauf – je 7 Farbwelten),
  auf 1080p-Fernsehern automatisch in einer 1080p-Fassung. Kacheln liegen als Glasflächen darüber.
  *Einstellungen · Design & Aufbau · Hintergrundbild*, auf Wunsch jeden Tag ein anderes.
- **8 Ambient-Videos** (je 60 s, nahtlose Schleife): Bildschirmschoner-Stil „Ambient-Video“,
  neue Musikansicht mit Cover und Titel, ◀ ▶ wechselt die Szene.
- **Schnellmenü** mit der Info-Taste (Fernbedienung, Handy-App, iPhone): Lautstärke, Stumm,
  Schlaf-Timer, Ambient, nächstes Hintergrundbild, Bluetooth, Design, Neustart.
- **Wecker mit Radio**: *Einstellungen · Energie · Einschalten* – „Wecken mit“ Fernsehen, Radio
  mit Morgenbild oder nur Morgenbild mit Uhr und Wetter; „Sanft wecken“ blendet das Radio
  in 90 Sekunden ein.
- **Animationen**: gleitender Fokus-Schein, weiche Seitenübergänge, Kachel-Einflug, langsam
  zoomendes Hintergrundbild. Mit *Animationen: Reduziert/Aus* wird alles abgeschaltet.
- **Schneller**: Daten der Startseite werden parallel zum Laden der Skripte geholt, Dateien
  werden komprimiert und mit Versionskennung dauerhaft im Browser zwischengespeichert.
  Gemessen (gedrosselte CPU): Kaltstart 1,17 s → 0,52 s, Rückkehr zur Startseite 0,39 s → 0,28 s,
  übertragene Daten 587 KB → 113 KB.

Installation: `fertig/raspi-tv-update-6.0.0.zip` im vorhandenen Update-Fenster auswählen
(etwa 150 MB, deshalb einige Minuten Geduld). Medien lassen sich neu erzeugen mit
`python3 tools/make-media.py` und `python3 tools/make-ambient.py`.

**Offener Hardwarebefund:** Display 1 (Uhr/Cover) – siehe Abschnitt unten; 6.0.0 verändert
die GPIO-Belegung und die Display-Diagnose nicht.

---

**Update 5.9.0** führt den bisherigen Stand 5.8.8 mit den zusätzlichen Paketen
`raspi-tv-os_2.zip` (5.5) und `raspi-tv-os867.zip` (5.5.1) zusammen.

- Handy-Player für Spotify, Radio und Videos: Titel, Künstler bzw. Webseite, Cover,
  Pause/Fortsetzen, Weiter/Zurück und Lautstärke. Videobefehle erreichen den zugehörigen Tab.
- Android-App **1.8** (Versionscode 10): über „Teilen → Raspi-TV“ Links am Fernseher
  öffnen. Beide älteren App-Zweige lassen sich damit aktualisieren.
- Spotify bleibt beim Öffnen/Schließen seiner Ansicht im selben Tab. Verspätete Statusmeldungen
  lösen keinen Browser-Neustart aus. Radio bleibt nach einer Pause auf dem Handy sichtbar.
- HDMI-Wächter für später eingeschaltete Fernseher und sauberes Beenden beim Herunterfahren.
- Windows-Zeilenumbrüche in der Paketliste werden beim Packen und Installieren entfernt.
  Damit werden benötigte Pakete mit den richtigen Namen installiert.
- Alle neueren Notfall-, Bildschirm-, Profil-, Gamepad- und Display-Werkzeuge bleiben erhalten.

Installation: `fertig/raspi-tv-update-5.9.0.zip` im vorhandenen Update-Fenster auswählen.
Die Handy-App ist zusätzlich im Windows-Paket `fertig/Raspi-TV-App-Installer-1.8.zip` enthalten.

**Offener Hardwarebefund:** Display 1 (Uhr/Cover) bleibt nach Rückmeldung auch beim Test
aus 5.8.8 leer, während der Lautstärkering funktioniert. Der Fehler ist noch nicht als
behoben bestätigt; für die weitere Eingrenzung wird der Diagnosebericht aus 5.8.8 oder
neuer benötigt. Die GPIO-Belegung wird durch dieses Update nicht verändert.

Ein eigenes Betriebssystem, das den Raspberry Pi in einen **Smart-TV** verwandelt:
Einschalten, Sender auswählen, fernsehen – ohne sichtbaren Computer, Maus oder Tastatur.
Alles wird mit der **Fernbedienung des Fernsehers** bedient.

**Startseite** – große Kacheln für *Live-TV*, *TV-Programm*, *Mediathek*, *Filme & Serien*,
*Eigene Medien*, *Radio* und *Einstellungen*, darunter „Jetzt im Fernsehen“ mit Fortschrittsbalken und
deine Apps. Oben Uhrzeit und Netzwerkstatus. Dunkles Design mit blauer Akzentfarbe und
flüssigen Animationen.

- **Live-TV:** ca. 45 freie Sender mit Senderlogos (Das Erste, ZDF, ARTE, 3sat, KiKA, phoenix, alle Dritten …)
  im Vollbild. Beim Umschalten erscheint eine Leiste mit Sender, **aktueller Sendung,
  Fortschritt** und was danach kommt. CH ± / ▲▼ / Ziffern zum Umschalten, **0** springt zum vorherigen Sender, Lieblingssender,
  Schlaf-Timer.
- **Videorekorder:** Im TV-Programm eine Sendung auswählen → **● Aufnehmen** (mit Vor- und
  Nachlauf). Beim Fernsehen nimmt **▶ Optionen → Aufnehmen** bzw. die **Aufnahme-Taste**
  (Fernbedienung/Handy) die laufende Sendung auf. Aufnahmen landen auf einem USB-Stick (Ordner
  „Raspi-TV Aufnahmen“) oder der Speicherkarte und stehen unter **Eigene Medien → Aufnahmen**.
  Geplante Sendungen haben im TV-Programm einen roten Punkt.
- **Tonspur, Untertitel, Bildformat:** im Fernsehen unter ▶ Optionen – z. B. Audiodeskription,
  Untertitel der Sender (wenn angeboten), Zoom für 4:3-Sendungen.
- **Live-TV anhalten (zeitversetzt):** Pause drücken – der Pi nimmt ab da auf. Weiter spielt
  ab der Stelle weiter, an der du angehalten hast; ◀ ▶ spulen 30 Sekunden, **Zurück** springt
  wieder zu Live. Bis zu 2 Stunden (braucht ca. 1–3 GB freien Platz auf der SD-Karte).
- **TV-Programm (EPG):** übersichtliche Tabelle mit Sendern und Sendezeiten. Sendung
  auswählen → Details, **Erinnerung setzen** oder einschalten. Erinnerungen erscheinen
  überall – auch während Netflix läuft – und schalten mit OK direkt um.
- **Mediathek:** ARD, ZDF, ARTE, 3sat, KiKA, Joyn, YouTube, Twitch.
- **Filme & Serien:** Netflix, Prime Video, Disney+, RTL+, Crunchyroll
  (jeweils mit eigenem Abo, über die offizielle Web-Version, meist bis 720p).
- **Eigene Medien:** Videos, Musik und Fotos von **USB-Sticks/Festplatten** (erscheinen
  automatisch) und aus dem **Heimnetz** (FRITZ!Box-Speicher, NAS, Windows-Freigabe) – mit
  Vorschaubildern. Player mit Spulen, Weiter-schauen-Funktion, Musik-Wiedergabeliste und
  Foto-Diashow.
- **Einstellungen:** WLAN, Bild (Auflösung mit 15-Sekunden-Rückfall, Bildgröße bei
  abgeschnittenem Rand), Ton, Sender (sortieren, ausblenden, eigene M3U-Liste),
  Fernbedienung (HDMI-CEC-Status, Handy als Fernbedienung), Bluetooth, Apps, Updates, System.
- **Handy als Fernbedienung** (iPhone/Safari und Android): Steuerkreuz oder Wischfläche
  („Wischen = Pfeile, Tippen = OK“), Lautstärke- und Senderwippe, Ziffernblock, Touchpad,
  Tastatur und Sprachsuche. Koppeln per QR-Code – oder ohne Kamera die angezeigte Adresse im
  Browser öffnen und den 6-stelligen Code eingeben. Lässt sich als App auf den Startbildschirm legen.
  Alles passt auf einen Bildschirm – nichts muss gescrollt werden. Oben zeigt „Jetzt läuft“ Sender,
  Sendung und Fortschritt; der Reiter **Sender** listet alle Sender mit aktueller und nächster
  Sendung – antippen schaltet am Fernseher um, ● nimmt auf. Unter **Mehr**: Tasten/Wischen,
  Raspberry Pi ausschalten/neu starten (auch über den Ein/Aus-Knopf oben rechts) und ein **Schlaf-Timer** (15–90 Minuten, gilt auch für den Timer am Fernseher).
  **Aussehen der Handy-App** stellst du am Fernseher ein (Einstellungen → Fernbedienung → Aussehen der
  Handy-App, mit Live-Vorschau): Farbschema, Akzentfarbe, Aufbau (Klassisch, Große Tasten, Wischfläche,
  Wippen oben), Lautstärke links/rechts, Ecken, „Jetzt läuft“-Leiste und welche Reiter unten erscheinen.
  Das Handy übernimmt das in wenigen Sekunden (WLAN oder Bluetooth) und merkt es sich.
- **Altes Android-Handy als feste Fernbedienung (Bluetooth, ohne WLAN):** Die Raspi-TV-App
  (`launcher/raspi-tv-remote.apk`, ab Android 4.4) hat dieselbe Oberfläche, verbindet sich aber
  per Bluetooth. Sie kann als Startbildschirm des Handys eingestellt werden (Handy an =
  Fernbedienung), startet nach dem Einschalten von selbst, die Lautstärketasten des Handys regeln
  den Fernseher. Einrichten: Einstellungen → Fernbedienung → Handy → „App aufs Handy laden“ und
  „Handy-App koppeln“.
- **Fernbedienungs-WLAN:** Ist Raspi-TV per LAN-Kabel verbunden, spannt er auf Wunsch ein
  eigenes WLAN auf – z. B. nur nachts (Zeiten einstellbar), wenn das Heim-WLAN aus ist. Mit
  **„Internet für verbundene Geräte“** surfen Handy, Tablet und Laptop darüber gleichzeitig
  über das LAN-Kabel des Pi. Einstellungen → Fernbedienung → Handy.
- **Ersteinrichtung** beim ersten Start: Internet, Bundesland (dein Regionalprogramm kommt
  auf Platz 3), Startverhalten, Handy koppeln.
- **Weiterschauen** auf der Startseite: zuletzt gesehene Sender und angefangene Videos.
- **Sendung suchen** im TV-Programm der nächsten zwei Tage.
- **Energie:** Bildschirmschoner mit Uhr und „Jetzt im TV“; automatisches Ausschalten nach
  längerer Nichtbenutzung (mit Vorwarnung „Noch jemand da?“); **Einschalt-Timer** (z. B. werktags
  um 7 Uhr die Nachrichten – schaltet auch den Fernseher ein); auf Wunsch nächtlicher Neustart.
- **Anrufe auf dem Fernseher:** Mit einer FRITZ!Box erscheint bei jedem Anruf die Nummer oben
  im Bild – in jeder App. Auf Wunsch hält Raspi-TV dabei das Video an (Live-TV wird
  zwischengespeichert). Einmalig an einem Telefon **#96\*5\*** wählen, dann Einstellungen →
  Mitteilungen.
- **Kindersicherung** (Einstellungen → Kindersicherung): 4-stelliger PIN für die Einstellungen.
  Im **Kinder-Modus** gibt es nur Kindersender (frei wählbar) und Kinder-Apps, auf Wunsch mit
  **Tageslimit** und **Schlafenszeit** – danach erscheint ein Sperrbildschirm, der Fernseher geht
  aus. Verlängern oder beenden nur mit PIN.
- **Nachrichten:** aktuelle Schlagzeilen (tagesschau, ZDFheute, Deutsche Welle, SPIEGEL) auf der
  Startseite und als Laufband im Bildschirmschoner.
- **Bildschirmschoner-Stile:** Uhr & Programm, analoge Uhr, Fotos vom USB-Stick (Diashow) oder
  dunkel mit wandernder Uhr (schont OLED-Fernseher).
- **Systemmonitor & Internet-Test** (Einstellungen → System): Prozessor, Temperatur, Speicher,
  Warnung bei Unterspannung/Überhitzung und ein Geschwindigkeitstest für die Internetleitung.
- **Lieblingssender** erscheinen als eigene Reihe auf der Startseite.
- **Design & Aufbau** (Einstellungen → Design & Aufbau): 8 Designs (Mitternacht, OLED Schwarz,
  Polarlicht, Abendrot, Wald, Kino, Hell und „Automatisch“ – hell am Tag, abends dunkel), 9
  Akzentfarben, Hintergrund leuchtend/bewegt/schlicht, Animationen voll/reduziert/aus (für ältere
  Pis), runde oder eckige Kacheln. Die Startseite gibt es in 5 Aufbauten: **Klassisch**,
  **Kompakt** (mehr Sender auf einen Blick), **Kino** (großes Bild der laufenden Sendung),
  **Seitenleiste** (Menü links) und **Minimal** (große Uhr). Einzelne Bereiche wie Wetter, Suche,
  Weiterschauen oder Apps lassen sich ausblenden. Alles wirkt sofort.
- **Startanimation:** animiertes Logo beim Hochfahren und beim Start der Oberfläche
  (jede Taste überspringt sie, abschaltbar unter Einstellungen → System).
- **App Store:** über 50 weitere Apps zum Installieren – Paramount+, WOW, Apple TV+,
  MagentaTV, waipu.tv, Zattoo, Pluto TV, DAZN, YouTube Music, Deezer, tagesschau, Kinder- und
  Wissens-Apps, Plex, Jellyfin, Home Assistant u. v. m. Dazu **echte Programme**: **Kodi**
  (Mediacenter), **RetroArch** (Retro-Spiele) und **Moonlight** (PC-Spiele streamen) werden
  mit Fortschrittsanzeige installiert und starten im Vollbild. Jede Webadresse kann außerdem
  eine **eigene App** werden (z. B. dein NAS). Vorinstallierte Apps lassen sich ausblenden.
- **Fernseher & Soundbar (HDMI-CEC):** Raspi-TV schaltet beim Start den Fernseher ein,
  auf Wunsch wechselt der Fernseher beim Einschalten sofort zu Raspi-TV. Lautstärke-Tasten der
  Handy-Fernbedienung, Funk-Tastatur oder Air-Maus steuern Soundbar, Fernseher oder den Pi
  (Einstellungen → Fernbedienung). Handy-Fernbedienung mit **TV an/aus** und **Zu Raspi-TV**.
- **Videos & Fotos vom Handy (DLNA):** Raspi-TV ist ein DLNA-Wiedergabegerät. In Apps wie
  BubbleUPnP (Android), „Wiedergabe auf Gerät“ (Windows) und vielen Galerie-/Medien-Apps
  Raspi-TV wählen – Videos, Musik und Fotos laufen im Vollbild, Steuerung vom Handy.
- **Sprachsuche:** In der Handy-Fernbedienung unter „Suchen“ ins Feld tippen und das Mikrofon
  der Handy-Tastatur nutzen – Ergebnis im TV-Programm, auf YouTube, Netflix, ARD, ZDF oder im
  App Store.
- **Updates übers Internet** mit **automatischer Rückkehr** zur vorherigen Version, falls die
  neue nicht startet (auch bei USB-Updates). Nach jedem Update startet der Pi von selbst neu. Ältere Versionen lassen sich unter
  Einstellungen → Updates wiederherstellen.
- **Sichern & Wiederherstellen** der Einstellungen (inkl. Sender, Apps, Erinnerungen, WLANs)
  auf einen USB-Stick – z. B. für eine neue SD-Karte (Einstellungen → System).
- **Werbeblocker** für normale Webseiten (Einstellungen → Apps), Streaming-Apps ausgenommen.
- **English interface:** Einstellungen → System → „Sprache / Language“.
- **Radio:** über 20 Sender live (1LIVE, Bayern 3, SWR3, Deutschlandfunk …) – die Sender
  deines Bundeslands stehen vorne. Läuft weiter, während du durch die Oberfläche stöberst.
- **Wetter:** aktuell auf der Startseite und im Bildschirmschoner, 6-Tage-Vorhersage mit
  animierten Symbolen. Ort frei wählbar (Daten: Open-Meteo, ohne Anmeldung).
- **Spotify:** das normale Spotify (auch mit kostenlosem Konto) in einem eigenen Hintergrund-Fenster.
  Die Musik läuft weiter, wenn du mit **Home** zur Startseite gehst, eine andere App öffnest oder der
  Fernseher in den Standby geht; was läuft, zeigt die Leiste unten rechts. Die Spotify-Kachel bringt
  dich zurück. Auch **Zurück/Escape** schließt nur die Ansicht; der Spotify-Tab bleibt erhalten.
  Der kleine Player unten rechts zeigt Titel, Künstler und Cover. Mit **❚❚/▶** pausierst du bzw.
  setzt die Musik fort; ein Klick auf Titel oder Cover öffnet denselben Spotify-Tab ohne Neustart.
  Die Knöpfe sind auch mit Pfeiltasten und OK erreichbar. Bedienung in Spotify: Pfeile springen zum nächsten Element, OK wählt bzw. spielt ab, CH ± = nächster/
  vorheriger Titel, ▶❚❚ = Pause. **F12** wechselt ebenfalls zu Home; nur **Shift+F12** startet den Browser im Notfall neu. Startet anderswo ein Video (Live-TV, Netflix, Radio …), pausiert Spotify.
  Hinweis: Hängt der Ton am Fernseher (HDMI), ist er im Standby natürlich stumm – mit Bluetooth-Box oder
  Verstärker läuft die Musik hörbar weiter.
- **iPhone als Fernbedienung:** Einstellungen → Fernbedienung → iPhone als Fernbedienung → einschalten
  (lädt einmalig ca. 15 MB). Dann am iPhone Home-App → + → Gerät hinzufügen → QR-Code vom Fernseher
  scannen → „Trotzdem hinzufügen“. Danach steht „Raspi-TV“ in der Apple-TV-Fernbedienung im
  Kontrollzentrum: Wischen = Pfeile, Tippen = OK, Zurück, Play/Pause, Info, Lautstärke über die
  iPhone-Tasten, Ein/Aus und Eingänge (Startseite, Live-TV, TV-Programm, Radio, Eigene Medien).
  Das iPhone muss im selben WLAN sein.
- **Terminal:** Einstellungen → System → Terminal (oder als App aus dem App Store). Eine echte
  Kommandozeile als Benutzer `admin` (sudo mit Passwort `raspitv`), tippen mit USB-Tastatur oder dem
  Handy (Fernbedienung → Tastatur). Die Sitzung läuft weiter, wenn du die Seite verlässt.
- **Spotify Connect:** Raspi-TV erscheint in der Spotify-App als Lautsprecher – Musik am Handy
  aussuchen, „Geräte“ → „Raspi-TV“. Titel und Cover erscheinen unten rechts und im
  Bildschirmschoner. Einschalten unter Einstellungen → Ton (wird beim ersten Mal kurz
  eingerichtet, braucht Spotify Premium).
- **AirPlay:** Musik vom iPhone, iPad oder Mac auf den Fernseher (Einstellungen → Ton).
- **Gerätename** fürs Heimnetz, AirPlay und Bluetooth (Einstellungen → System).
- **Gamepad:** Bluetooth-/USB-Controller (Xbox, PlayStation …) steuern die Oberfläche:
  Steuerkreuz/Stick = Pfeile, A = OK, B = Zurück, X = TV-Programm, Start = Startseite.
- **USB-Stick erkannt:** Steckst du einen Stick ein, fragt Raspi-TV, ob die Medien gezeigt
  werden sollen – liegt ein Update-Paket darauf, geht es direkt zum Update.
- **Software-Update per USB-Stick:** neue Raspi-TV-Versionen einspielen, ohne die SD-Karte
  neu zu beschreiben (siehe unten). Einstellungen bleiben erhalten.
- **Bildstart abgesichert:** Klappt die Grafik nicht auf Anhieb, probiert Raspi-TV
  automatisch weitere Einstellungen und merkt sich die funktionierende.

> **Antenne, Kabel, Satellit:** Dafür braucht der Pi einen zusätzlichen Empfangsweg, z. B.
> einen TV-Server im Heimnetz (Tvheadend, Jellyfin u. a.). Dessen Senderliste trägst du unter
> Einstellungen → Sender → „Eigene Senderliste (M3U)“ ein – unterstützt werden Streams im
> Format HLS/MP4 (H.264).

## Was du brauchst

**Zum Bauen (auf deinem Windows-PC):**
- Windows 10/11 mit **WSL2 + Ubuntu**
- **Docker Desktop** mit WSL-Integration
- ca. **25 GB** freier Speicher und Internet

**Für den Fernseher:**
- Raspberry Pi **4** oder **5** (mind. 2 GB RAM, besser 4 GB)
- microSD-Karte (mind. 16 GB), offizielles Netzteil, HDMI-Kabel

---

## 1. Einmalig: PC vorbereiten

Docker Desktop hast du schon. Prüfe noch zwei Dinge:

1. **Ubuntu in WSL vorhanden?** PowerShell öffnen und eingeben:
   ```powershell
   wsl -l -v
   ```
   Steht dort **Ubuntu** (mit Stern `*` als Standard), passt alles.
   Fehlt es: `wsl --install -d Ubuntu` ausführen, PC neu starten, Ubuntu einmal öffnen und
   Benutzername + Passwort festlegen. Danach: `wsl --set-default Ubuntu`.
2. **Docker für Ubuntu freigeben:** Docker Desktop → Zahnrad (Settings) → **Resources** →
   **WSL Integration** → Schalter bei **Ubuntu** einschalten → *Apply & restart*.

## 2. Image bauen

1. Den Ordner `raspi-tv` irgendwo hin entpacken, z. B. auf den Desktop.
2. **`Bauen.bat` doppelklicken.**
3. Warten (ca. **1–2 Stunden**, beim ersten Mal etwas länger). Der PC darf in der Zeit
   nicht in den Ruhezustand gehen.
4. Wenn „Fertig!“ erscheint, liegt das Image im Unterordner **`fertig`**,
   z. B. `fertig\2026-10-27-raspi-tv-os.zip`.

> Bei kurzen Netzwerkfehlern versucht es der Build automatisch erneut. Bricht er trotzdem
> ab, einfach **`Bauen.bat` noch einmal doppelklicken** – er macht an derselben Stelle
> weiter. Komplett von vorn: in PowerShell `.\Bauen.bat --neu`.

## 3. Auf die SD-Karte schreiben

1. [Raspberry Pi Imager](https://www.raspberrypi.com/software/) starten.
2. **Gerät:** dein Raspberry Pi.
   **Betriebssystem:** ganz unten **„Eigenes Image verwenden“** → die Datei aus `fertig` wählen.
   **SD-Karte:** auswählen.
3. Frage nach Einstellungen: **„Nein“** – das WLAN richtest du bequem am Fernseher ein.
4. Schreiben lassen.

## 4. Einschalten

SD-Karte in den Pi, HDMI an den Fernseher, Strom an. Nach dem Raspi-TV-Logo erscheint die
Startseite. Ohne Internet zeigt sie **„WLAN einrichten“** – OK drücken, Netzwerk wählen,
Passwort mit der Bildschirmtastatur eingeben, fertig.

> WLAN geht auch ohne Fernbedienung: SD-Karte vorher in den PC stecken, auf dem Laufwerk
> **„bootfs“** die Datei `raspi-tv-wlan.txt` öffnen, Name + Passwort eintragen, speichern.

Beim ersten Öffnen jeder App meldest du dich einmal an – die Anmeldung bleibt gespeichert.

---

## Bedienung

Am Fernseher muss **HDMI-CEC** an sein (heißt je nach Marke *Anynet+* (Samsung),
*SimpLink* (LG), *Bravia Sync* (Sony), *VIERA Link* (Panasonic), *EasyLink* (Philips)).

| Taste | Funktion |
|---|---|
| Pfeile / OK | Navigieren / Auswählen |
| Zurück | Eine Ebene zurück · **lang drücken:** Startseite |
| Home / Menü / 🔴 Rot | Startseite – sofort, aus jeder App |
| 🟢 Grün | **Maus-Modus** an/aus – Pfeile bewegen den Mauszeiger, OK klickt, Kanal +/- scrollt |
| 🟡 Gelb | Schließen / Vollbild verlassen / Tastatur zu |
| 🔵 Blau | Seite neu laden |
| Play / Pause | Wiedergabe / Pause · im Fernsehen: Live-TV anhalten |
| Spulen | vor / zurück (im Fernsehen nach dem Anhalten: 30 Sekunden) |
| CH + / CH – | Sender wechseln (im Fernsehen) |
| 0 – 9 | Sender direkt wählen (im Fernsehen) · Apps direkt öffnen (Startseite) |

**Bildschirmtastatur:** erscheint automatisch, sobald ein Textfeld ausgewählt ist. Pfeile
wählen eine Taste, OK tippt. Mit „Weiter ⇥“ springst du ins nächste Feld (z. B. vom
E-Mail- zum Passwortfeld), mit „Senden ↵“ schickst du das Formular ab.
Steckst du eine echte Tastatur an und tippst darauf, blendet sie sich aus.

**Tipp:** Netflix & Co. sind im Browser für Maus gebaut. Zum Durchstöbern ist der
**Maus-Modus (Grün)** am angenehmsten – oder eine günstige Air-Maus/Bluetooth-Fernbedienung.

## Gut zu wissen

- **Bildqualität:** Im Browser unter Linux liefern die Dienste nur eingeschränkte Qualität –
  Netflix max. 720p, Prime Video, Disney+ und Crunchyroll oft SD bis 720p. 4K/HDR gibt es
  auf dem Pi nicht. YouTube, ARD, ZDF und Twitch laufen in voller HD-Qualität.
- **Wartungszugang:** Benutzer `admin`, Passwort `raspitv`. Am Pi mit `Strg+Alt+F2` zur
  Konsole (`Strg+Alt+F1` zurück). SSH ist aus; einschalten mit `sudo raspi-config` →
  *Interface Options* → *SSH*. **Bitte dann das Passwort mit `passwd` ändern.**
- **System-Updates** (Debian, Chromium, Sicherheit): Einstellungen → Updates →
  „System aktualisieren“.
- **Raspi-TV-Updates per USB-Stick** – wenn du eine neue Version dieses Ordners hast:
  1. Am PC **`Update-Paket.bat`** doppelklicken. Es entsteht `fertig\raspi-tv-update.zip`.
  2. Die Datei **direkt ins Hauptverzeichnis** eines USB-Sticks kopieren (FAT32, exFAT
     oder NTFS), nicht in einen Unterordner.
  3. Stick an den Pi stecken → Hinweis „Software-Update gefunden“ → OK → „Installieren“.
     Nach ca. 1–3 Minuten **startet der Pi automatisch neu** (bei Updates mit neuen Systempaketen etwas
     länger, weil die neue Startanimation eingerichtet wird). Neue Pakete (z. B. für AirPlay) lädt
     der Pi dabei aus dem Internet nach.

  > Ein Update-Paket wird mit vollen Rechten installiert. Steck nur Pakete ein, die du
  > selbst mit `Update-Paket.bat` erstellt hast. Protokoll: `/var/log/raspi-tv-swupdate.log`.
- **Handy-Fernbedienung & Sicherheit:** Sie läuft nur im Heimnetz (Port 8766) und nur mit
  dem Kopplungscode aus dem QR-Code (bzw. dem 6-stelligen Code, der 15 Minuten und nur einmal gilt; nach 8 Fehlversuchen ist er 10 Minuten gesperrt). Unter Einstellungen → Handy → „Neuen Code erstellen“
  sperrst du alle bisher gekoppelten Handys aus.
- **Startverhalten:** Einstellungen → System → „Direkt Fernsehen starten“ (an = wie ein
  Fernseher, aus = Startseite mit den Apps).
- **Sender anpassen:** Die Senderliste steht in `/opt/raspi-tv/launcher/channels.json`.
- **Netflix, Prime Video & Co.** laufen über die offizielle Web-Version der Dienste
  (für den Raspberry Pi gibt es keine eigenen Apps), starten aber wie eine App –
  ohne sichtbaren Browser, Home bringt sofort zurück.

### Updates übers Internet einrichten

Raspi-TV holt Updates von einer Adresse, die **du** festlegst – z. B. ein GitHub-Release:

1. Am PC `Update-Paket.bat` ausführen → `fertig\raspi-tv-update.zip`.
2. Die Datei z. B. als Release-Anhang auf GitHub hochladen. Die Adresse
   `https://github.com/NAME/REPO/releases/latest/download/raspi-tv-update.zip` zeigt immer
   auf das neueste Release.
3. Am Fernseher: Einstellungen → Updates → „Update-Adresse“ eintragen. Raspi-TV prüft dann
   täglich und installiert auf Wunsch nachts automatisch.

Vor jedem Update sichert Raspi-TV die laufende Version. Antwortet die neue Version nach etwa
4 Minuten nicht, wird automatisch die alte wieder eingespielt.

> Updates werden mit vollen Rechten installiert. Trag nur eine Adresse ein, unter der du selbst
> die Pakete ablegst.

### App Store – gut zu wissen

- **Web-Apps** sind die offiziellen Web-Versionen der Dienste – wie Netflix & Co. Abo-Dienste
  brauchen dein eigenes Konto. Installieren legt die App auf die Startseite (und je nach Art
  zu „Mediathek“ oder „Filme & Serien“).
- **Programme** (Kodi, RetroArch, Moonlight) werden aus den Debian-/Raspberry-Pi-Paketquellen
  geladen (Moonlight aus der offiziellen Moonlight-Paketquelle) und brauchen Internet und
  etwas Speicherplatz. **Home** auf der Fernbedienung beendet das Programm, alternativ dessen
  eigenes „Beenden“; **F12** auf einer Tastatur hilft im Notfall. Kodi steuert den Fernseher
  selbst per HDMI-CEC – nach dem Beenden meldet sich Raspi-TV automatisch wieder an.
- **RetroArch** spielt nur eigene Spiele-Dateien (z. B. vom USB-Stick unter
  `/media/raspi-tv/`). **Moonlight** und die Cloud-Gaming-Apps sind als *Beta* markiert:
  ob sie auf deinem Pi laufen, hängt vom Dienst bzw. der Paketquelle ab.
- Protokoll der Installationen: `/var/log/raspi-tv-store.log`.

## Probleme?

| Problem | Lösung |
|---|---|
| `Bauen.bat`: „Docker wurde nicht gefunden“ | WSL-Integration in Docker Desktop für Ubuntu einschalten (siehe Schritt 1). |
| `Bauen.bat` schließt sofort / „bash nicht gefunden“ | Ubuntu ist nicht die Standard-Distribution: `wsl --set-default Ubuntu`. |
| Build bricht mit Netzwerkfehler ab („Connection refused“, „Unable to fetch“) | `Bauen.bat` erneut doppelklicken – es geht an derselben Stelle weiter. |
| Nach dem Logo bleibt der Bildschirm dunkel | Ab dieser Version erscheint stattdessen eine Fehlermeldung. Wartung: `Strg+Alt+F2`, `admin` / `raspitv`, dann `sudo cat /var/log/raspi-tv/x.log` |
| Kein Bild / schwarzer Bildschirm | Anderes HDMI-Kabel/-Port probieren (Pi 4/5: den Port neben dem Stromanschluss). |
| „Browser wird nicht unterstützt“ | Pi neu starten; Einstellungen → System → aktualisieren. |
| Fernbedienung reagiert nicht | CEC am Fernseher einschalten, anderen HDMI-Eingang probieren. Log: `journalctl -u raspi-tv-cec -f` |
| USB-Update wird nicht gefunden | Datei muss `raspi-tv-update….zip` heißen und direkt im Hauptverzeichnis des Sticks liegen. Stick abziehen, wieder einstecken. |
| Fernbedienungs-WLAN geht nicht an | Die Meldung steht direkt unter „Fernbedienungs-WLAN“. Beim ersten Einschalten lädt Raspi-TV fehlende Pakete (dnsmasq, nftables) – dafür muss das LAN-Kabel Internet haben. Details: `sudo cat /var/log/raspi-tv/hotspot.log` |
| Fernbedienungs-WLAN: Handy-Fernbedienung lädt nicht | Prüfen, ob das Handy im WLAN „… Fernbedienung“ ist. Bei der Frage „ohne Internet verbunden bleiben?“ „Ja“ wählen, notfalls mobile Daten kurz aus. Es muss die Adresse aus QR-Code 2 (10.42.0.1) benutzt werden. |
| Raspi-TV taucht in Spotify nicht unter „Geräte“ auf | Handy und Pi müssen im selben WLAN sein. Spotify Connect unter Einstellungen → Ton aus- und wieder einschalten. Log: `cat /var/log/raspi-tv/spotify.log` |
| AirPlay: „Wird mit dem nächsten System-Update installiert“ | Bei älteren Images fehlt das Paket – USB-Update einspielen (installiert es nach) oder neu bauen. |
| App-Store-Programm lässt sich nicht installieren | Internetverbindung prüfen, später erneut versuchen. Details: `sudo tail -50 /var/log/raspi-tv-store.log` |
| Fernbedienung reagiert nach Kodi nicht mehr | Ein paar Sekunden warten (Raspi-TV meldet sich neu beim Fernseher an), sonst Pi neu starten. |
| Handy findet Raspi-TV nicht für DLNA | Gleiches WLAN? DLNA unter Einstellungen → Ton eingeschaltet? Manche Router blockieren Multicast im WLAN („IGMP-Snooping“/„Multicast-Optimierung“). |
| Fernseher reagiert nicht auf „TV aus“/Lautstärke | Am Fernseher HDMI-CEC einschalten. Raspi-TV nimmt automatisch den HDMI-Anschluss, an dem der Fernseher hängt. Viele Fernseher ignorieren Lautstärke-Befehle per CEC – ohne Soundbar regelt Raspi-TV deshalb die eigene Lautstärke (mit Anzeige am Bildschirm). Protokoll: `cat /var/log/raspi-tv/cec.log` |
| Lautstärke-Tasten wirken nicht | Einstellungen → Fernbedienung → „Lautstärke testen“; ggf. unter „Lautstärke-Tasten“ Fernseher, Soundbar oder Raspi-TV wählen. Nicht jeder Fernseher nimmt Lautstärke per CEC an. |
| Anrufe erscheinen nicht | Einstellungen → Mitteilungen zeigt den Status. „Anrufmonitor ist aus“: an einem Telefon der FRITZ!Box `#96*5*` wählen. Nur FRITZ!Box wird unterstützt. |
| Live-TV lässt sich nicht anhalten | Manche Sender sind verschlüsselt oder liefern ein anderes Format – dann läuft es nach „Weiter“ einfach live weiter. Braucht mindestens 1 GB freien Speicher. |
| Handy-Fernbedienung lädt nicht | Handy im selben WLAN wie Raspi-TV? Adresse unter Einstellungen → Fernbedienung → Handy direkt im Browser eintippen (beginnt mit `http://`, nicht `https://`) und den Code eingeben. |
| Raspi-TV-App findet Raspi-TV nicht | Am Fernseher „Handy-App koppeln“ wählen (3 Minuten sichtbar), dann in der App „Raspi-TV auswählen“. Klappt die Suche nicht: „Nicht dabei?“ → in den Bluetooth-Einstellungen des Handys koppeln, zurück in die App. |
| Raspi-TV-App: „Bitte aktualisieren“ | Im Play Store „Android System WebView“ aktualisieren – die App nutzt es für die Anzeige. |
| Aufnahme fehlgeschlagen | Unter Eigene Medien → Aufnahmen steht der Grund. Verschlüsselte Sender lassen sich nicht aufnehmen. USB-Sticks müssen FAT32/exFAT sein (NTFS nur lesen). |
| PIN der Kindersicherung vergessen | Wartungszugang (`Strg+Alt+F2`, `admin`/`raspitv`): `sudo python3 -c "import json;p='/var/lib/raspi-tv/config.json';c=json.load(open(p));c.pop('parental',None);json.dump(c,open(p,'w'))"`, danach Pi neu starten. |
| „Unterspannung erkannt“ | Das Netzteil liefert zu wenig Strom – offizielles Raspberry-Pi-Netzteil verwenden (Pi 4: 3 A, Pi 5: 5 A). |
| Bluetooth-Gerät lässt sich nicht koppeln | Gerät erst in den Kopplungsmodus bringen, dann „Nach Geräten suchen“. Ggf. vom Handy entkoppeln. |

## Aufbau

```
Bauen.bat                    Windows: Doppelklick zum Bauen
Update-Paket.bat             Windows: Update-Paket für den USB-Stick erstellen
VERSION                      Versionsnummer von Raspi-TV
build.sh                     Build-Skript (WSL/Linux, nutzt pi-gen + Docker)
image/stage-raspitv/         Build-Stufe: Pakete, Dateien, Dienste, Bootscreen
launcher/                    TV-Oberfläche (Startseite + Einstellungen)
extension/                   Bildschirmtastatur, Home-Taste, Hinweise, Gamepad (Browser-Erweiterung)
system/                      Systemdienst (API), Fernbedienung, Browserstart, WLAN, Bluetooth,
                             DLNA, Live-TV anhalten (timeshift.py), Installations- und Update-Skripte
user/                        Grafikstart & Tastenkürzel des TV-Benutzers
branding/plymouth/           Startanimation beim Hochfahren (Plymouth)
tools/                       Hilfsskripte (make-bootscreen.py: Bilder der Startanimation, build-apk.sh: Android-App)
android/                     Raspi-TV-App für ältere Android-Handys (Fernbedienung über Bluetooth)
```

### Lokale Prüfung der Spotify- und Handy-Oberfläche

`python tools/test-home-keys.py` prüft die tatsächlich von Handy und CEC ausgegebenen Home-Tasten.
`node tools/test-spotify.cjs` prüft Navigation, Steuerung und das Verhalten bei fehlender Erweiterung.
Mit installiertem Playwright prüfen `node tools/test-spotify-browser.cjs` und
`node tools/test-remote-browser.cjs` zusätzlich die Browser-Oberfläche. `BROWSER_EXECUTABLE`
kann auf einen lokal installierten Chromium/Chrome zeigen. Der Spotify-Test verwendet eine
lokale Testseite mit echtem Audio und bildet die Erweiterungs-API durch Browser-Tabs nach;
ein angemeldetes Spotify auf dem Raspberry Pi wird dadurch nicht ersetzt.

Die Android-App 1.6 enthält die neue Handy-Oberfläche. Die vorhandene App lässt sich mit
`launcher/raspi-tv-remote.apk` aktualisieren; Kopplung und Einstellungen bleiben bei einem
normalen App-Update erhalten. Vollständiger Neubau: `bash tools/build-apk.sh`.
Bei reinen HTML-Änderungen kann `tools/refresh-apk-ui.py` alternativ die Oberfläche der
vorhandenen APK ersetzen. Das Ergebnis muss mit dem vorhandenen Projektschlüssel signiert
werden; nach `jarsigner` richtet `--align <signiert.apk> <ausgabe.apk>` die ZIP-Einträge aus.

Pi-Update 5.3.2: Home wird von Handy, CEC und F12 als eigener App-Befehl (F8) gesendet.
Physische Browser-Home-Tasten werden ebenfalls umgeleitet. Dadurch ersetzt Chromiums native
Home-Navigation den laufenden Spotify-Tab nicht mehr. Das Update erfordert den vollständigen
Neustart des Pi, damit auch die virtuellen Eingabegeräte und Tastenkürzel neu geladen werden.

## Neu in 5.4.0: Profile und zentrale App-Suche

Auf Home führen **Standard / dein Profilname** zur Profilverwaltung und **Apps suchen**
zur gemeinsamen Suche in installierten Apps und im App-Katalog.

- Bis zu acht Profile anlegen, umbenennen, wechseln und nach Rückfrage löschen.
  Das aktive Profil muss vor dem Löschen gewechselt werden.
- Neue Profile übernehmen das aktuelle Design und die aktuelle Senderauswahl.
  Änderungen an Senderreihenfolge, ausgeblendeten Sendern, Design, Akzentfarbe,
  Hintergrund, Animationen und Startseitenaufbau werden pro Profil gespeichert.
- Lieblingssender und zuletzt gesehene Sender werden im TV-Browser pro Profil getrennt.
- Netzwerk, installierte Programme, Streaming-Anmeldungen und Kindersicherung sind
  gemeinsame Geräteeinstellungen. Profile sind keine getrennten Streaming-Konten.
- Die App-Suche findet Namen und Themen, unterstützt mehrere Suchwörter und die Filter
  **Alle Apps**, **Installiert**, **Verfügbar**. Installierte Apps direkt öffnen;
  verfügbare Apps über **Details** mit dem bisherigen Installationsablauf hinzufügen.
- Die neuen Seiten beachten die vorhandene PIN-Sperre für Einstellungen und den Kinder-Modus.

Prüfung: `python tools/test-profiles.py` und mit Playwright
`node tools/test-personal-browser.cjs`. Die bisherigen Spotify/Home-Prüfungen bleiben erhalten.

## Notfall-Admin (ab 5.4.1)

Unabhängiger Dienst auf **http://PI-IP:8767/**, auch bei ausgefallenem Launcher oder Steuerdienst.
Der zufällige **vierstellige Zahlencode** (auch mit führenden Nullen) liegt auf dem Pi in `/var/lib/raspi-tv-recovery/admin.key`
(anzeigen mit `sudo cat /var/lib/raspi-tv-recovery/admin.key`). Die Seite zeigt Frontend-Fehler,
fehlende Skriptdateien und Dienst-/Update-Protokolle an und exportiert eine Diagnose als JSON.
Bestehende lange Admin-Codes werden beim nächsten Start einmalig durch vier Ziffern ersetzt;
ein gültiger vierstelliger Code bleibt bei Neustarts erhalten. Nach fünf falschen Eingaben
ist die Anmeldung für diesen Client bis zu einer Minute gesperrt.
Raspi-TV-Update-ZIP vom PC hochladen, Zielversion prüfen und separat installieren.
Vor der Installation wird eine Sicherung der bisherigen Programmdateien erstellt.

Auf älteren oder bereits defekten Installationen muss der Dienst einmalig mit
`tools/NOTFALL-INSTALLIEREN.sh` installiert werden. Das separate Rettungspaket enthält
alle dafür benötigten Dateien und eine Anleitung für die Textkonsole. Ein USB-Stick
führt ohne vorher installierten Helfer keine Programme automatisch aus.

Die Fehleranzeige im Launcher läuft vor den übrigen Skripten. Sie meldet JavaScript-
und Ladefehler an den Notfalldienst und zeigt einen direkten Zugang zur Notfallseite.
Prüfung: `python tools/test-recovery.py`, `python tools/test-recovery-pin.py`,
`node tools/test-recovery-browser.cjs` (Playwright).

## Lokaler Notfall-Admin und Terminal (5.5.1)

Der Pi startet mit der normalen TV-Oberflaeche. Antwortet sie beim Start nicht oder
tritt ein Startfehler im Launcher auf, erscheint die Admin-Anmeldung auf
http://127.0.0.1:8767/local. Erst nach Eingabe des vierstelligen Admin-Codes werden
USB-Updates, Diagnose und Terminal freigeschaltet. Auch direkt am Pi erfolgt keine
automatische Anmeldung; alte gespeicherte Codes werden beim Seitenaufruf verworfen.
**F10** oeffnet die Admin-Anmeldung bei Bedarf manuell.

**USB-Update:** ZIP oben auf einen USB-Stick kopieren, einstecken, **USB-Stick nach
Updates durchsuchen**, Version auswaehlen und **Geprueftes Update installieren**.
Der Notfalldienst bindet externe Datentraeger bei Bedarf lesend ein. Der Systemdatentraeger
wird ausgeschlossen. Updates werden vor der Installation lokal kopiert und geprueft.

Das eingebettete Root-Terminal verwendet eine persistente PTY-Sitzung. Ausgabe, Eingaben,
Fenstergroesse, Abbruch und Beenden funktionieren ueber den unabhaengigen Dienst.
Terminaldarstellung und Bildschirmtastatur benoetigen weder Internet noch den Steuerdienst.
Im Netzwerk und direkt am Pi ist dieselbe Anmeldung mit dem vierstelligen Code erforderlich.
Der lokale Einstieg ist nur ueber die Loopback-Adresse und den lokalen Hostnamen erreichbar.
Die automatische Anzeige setzt eine startfaehige Grafiksitzung und Chromium voraus.

Pruefung: python tools/test-recovery-local.py sowie die vorhandenen Recovery-, PIN-
und Update-Paket-Tests.

## Wartungswerkzeuge (5.6.0)

Der normale Start und die vierstellige Admin-Anmeldung aus 5.5.1 bleiben erhalten.
Die Notfallseite bietet nach der Anmeldung neun Werkzeugbereiche; der Update-Probelauf
steht direkt bei der ZIP-Auswahl.

1. **QR-Fehlerhilfe:** Erstellt einen bereinigten Bericht mit QR-Link zum Handy.
   Auch der Bericht hinter dem QR-Link erfordert den Admin-Code.
2. **Abgesicherter Start:** Nach drei kurzen Browserabstuerzen in fuenf Minuten
   werden Erweiterungen abgeschaltet. Drei wiederholte Launcherfehler aktivieren
   ebenfalls diesen Modus. Der Admin kann ihn aktivieren, beenden und den Browser neu starten.
3. **Update-Probelauf:** Prueft Speicher, ZIP, Python-/Shell-Syntax und Linux-Zeilenenden.
   Die Dateiinstallation laeuft in einem eigenen Testverzeichnis unter einer transienten
   systemd-Sandbox mit schreibgeschuetztem System, ohne Netzwerk, Home-Zugriff oder
   zusaetzliche Privilegien. Erst ein erfolgreicher Probelauf gibt die Installation frei.
   Auch der Installations-Worker erzwingt diese Pruefung.
4. **Netzwerkdiagnose:** Zeigt IP, WLAN, DNS und externe TCP-Erreichbarkeit getrennt.
   Externe Netzwerktests starten ausschliesslich nach Klick auf den Testknopf.
5. **CEC-Assistent:** Lernt den Eingabecode einer TV-Taste und speichert eine validierte
   Zuordnung in /var/lib/raspi-tv/cec-mapping.json. Die CEC-Uebersetzung liest sie live;
   gehaltene Tasten behalten bis zum Loslassen ihre urspruengliche Zuordnung.
6. **Bild-/Ton-Assistent:** Offline-Testbild mit Randmarkierungen und rundem Kreis,
   erfasste xrandr-Modi mit automatischem Rueckfall nach 20 Sekunden, PipeWire-Auswahl
   und ein leiser zweisekuendiger Testton. Gespeicherte Aufloesungen sind fuer den
   TV-Benutzer lesbar. Beschnitt durch TV-Overscan wird anhand des Testbilds am TV eingestellt.
7. **Fehler-Zeitleiste:** Ordnet Fehler, Updates, relevante Konfigurationsaenderungen,
   Speicherbereinigung und Support-Exporte nach Zeit und Softwareversion.
8. **Speicherverwaltung:** Zeigt grosse Dateien aus Downloads und expliziten Cache-Pfaden.
   Nur gescannte, unveraenderte Dateien koennen nach Bestaetigung geloescht werden.
   Browser-Anmeldungen, Profileinstellungen und sonstige Konfiguration werden nicht angeboten.
9. **Offline-Hilfe:** Acht bebilderte Anleitungen fuer Bild, Netzwerk, Update, CEC, Ton,
   Abstuerze, Platzmangel und Support. SVG-Grafiken und Texte liegen lokal auf dem Pi.
10. **Support auf USB:** Exportiert bereinigte Diagnose und Zeitleiste. Browserprofile,
    Zugangsdaten-Dateien und Terminalausgaben werden nicht eingepackt; bekannte Geheimnisse
    und Logzeilen mit Zugangsdaten werden ausgefiltert. Ein zuvor lesend eingebundener
    USB-Stick wird fuer das Schreiben kurz umgestellt und anschliessend wieder lesend eingebunden.

Pruefung:
- python tools/test-maintenance.py
- python tools/test-maintenance-http.py
- python tools/test-recovery.py
- python tools/test-recovery-pin.py
- python tools/test-recovery-local.py
- python tools/test-update-package.py
- node tools/test-recovery-local-browser.cjs

Die Browserpruefung verwendet eigene Profile und ein isoliertes installiertes Verzeichnis.
Geraete- und systemd-Grenzen werden auf Windows simuliert; eine echte Dateiinstallation
in den Testordner wird ausgefuehrt. CEC-Hardware, PipeWire-Ausgabe, xrandr-Umschaltung,
systemd-Sandbox und die echte Linux-PTY-Sitzung muessen auf dem Raspberry Pi geprueft werden.

Gezielter QR-Anmeldetest: node tools/test-qr-focused.cjs. Gespeicherte Anmeldungen werden beim neuen Seitenaufruf weiterhin verworfen.

## Spotify-Verbindung (5.6.1)

Die Systemerweiterung verbindet eine bereits geoeffnete Startseite nach ihrem Start
oder Neuladen erneut. Spotify-Anfragen werden beim Anlauf wiederholt, aber pro
Anfrage nur einmal ausgefuehrt. Der Notfall-Browser laedt beim normalen Start
auch die Systemerweiterung. Im abgesicherten Start oeffnet sich direkt die
Admin-Anmeldung; fuer den normalen Betrieb unter Wartungswerkzeuge > Startmodus
den normalen Start waehlen und den Browser neu starten. Der Admin-PIN bleibt erforderlich.

Pruefung: node tools/test-spotify.cjs und node tools/test-spotify-startup.cjs.

Der Installer richtet Schreibrechte fuer den Chromium-Regelcache (_metadata) ein;
JavaScript und Manifest bleiben gegen Aenderungen durch den TV-Benutzer geschuetzt.

## Neu in 5.7.0: Animierte Musikansicht und weitere Schutzmaßnahmen

**Home → Musikansicht** öffnet sofort eine animierte Szene mit Uhr, Datum sowie dem
aktuellen Spotify-Titel, Künstler und Albumcover (falls verfügbar). Radio wird ebenfalls
angezeigt. Ohne laufende Musik bleibt es eine ruhige Uhransicht. Das Öffnen, Wechseln und
Schließen der Szenen verändert weder Musikquelle noch Wiedergabeposition.

Neue Stile unter **Einstellungen → Energie → Stil des Bildschirmschoners**:
- **Polarlicht:** wandernde türkis-violette Lichtflächen.
- **Sternenflug:** ein langsam bewegtes Sternenfeld mit räumlicher Tiefe.
- **Lavalampe:** weich schwebende farbige Formen.

Die Szenen laufen lokal ohne Video-Downloads. Mit Links/Rechts zwischen den Szenen wechseln,
mit Play/Pause bzw. Leertaste Spotify Web oder Radio steuern, mit einer anderen Taste
zurückkehren. Home beendet die Ansicht ohne Neuladen des Launchers; auch Radio bleibt so
beim Verlassen erhalten. Die manuelle Musikansicht verwendet Polarlicht, wenn als
Bildschirmschoner einer der bisherigen Stile eingestellt ist. Reduzierte oder deaktivierte
Animationen und die entsprechende Betriebssystem-Einstellung werden berücksichtigt.
Schlaf-Timer und die automatische Abschaltung gelten weiterhin.

Zusätzlicher Schutz:
- Updates werden vor dem Entpacken vollständig auf ZIP-Prüfsummenfehler geprüft.
  Mehrdeutige Pfade, Datei-/Ordnerkonflikte, verschlüsselte und nicht unterstützte ZIPs
  werden abgelehnt. Die bestehenden Größenlimits gelten weiterhin.
- Der Handy-Kopplungscode wird unter einer Sperre verbraucht: Gleichzeitige Anfragen
  können denselben Einmalcode nicht mehrfach einlösen. Bestehende Fehlversuchssperren bleiben aktiv.
- Die Handy-Weboberfläche erlaubt Einbettung nur von derselben Herkunft (Schutz gegen
  fremde Seiten, die unsichtbare Bedienelemente darüberlegen).
- Negative und übergroße HTTP-Anfragen an Fernbedienung und lokale API werden vor dem Lesen abgelehnt.

Prüfung: `python tools/test-security-57.py`, `node tools/test-ambient-browser.cjs`,
`node tools/test-launcher-57.cjs` sowie die bisherigen Recovery-, Kopplungs-, Spotify- und
Update-Paket-Prüfungen. Browserprüfungen benötigen Playwright; `BROWSER_EXECUTABLE`
kann auf einen lokal installierten Chromium/Chrome zeigen. Audio wird mit einem echten
lokalen Test-Audioelement geprüft; echtes Spotify und die Leistung der Animationen auf
Raspberry-Pi-Hardware müssen dort zusätzlich geprüft werden.

## Neu in 5.8.0: Musikvisualisierung, Windows-Bild und Handy-Gamepad

**5.8.8** macht beide Displays einzeln testbar: **Display 1 testen · Uhr / Albumcover**
und **Display 2 testen · Lautstärkering**. Der jeweils andere Anschluss wird durch
den Test nicht neu initialisiert. Die GPIO-Zuordnung bleibt unverändert. Status,
Abbruch, automatische Rückkehr und Support-Bericht nennen das gewählte Display.
Die Anschlussdiagnose erfasst jetzt zusätzlich die GPIOs und SPI0.0 von Display 1.
Der schwarze Bildschirm ist damit noch nicht als Hardware-/Softwarefehler bestimmt;
dieses Update ermöglicht den Test am tatsächlich betroffenen Uhr-/Cover-Display.

**5.8.7** ergänzt dort **Testbild auf Display 2 starten**. Der laufende Display-Dienst
initialisiert ausschließlich Display 2 auf den bisherigen Pins neu und sendet
bei 500 kHz für 30 Sekunden die große 2 mit L/R und roten/grünen/blauen Feldern.
Danach stellt er automatisch die vorherige Geschwindigkeit und normale Anzeige
wieder her, auch wenn die Einstellungsseite geschlossen ist. **Test beenden**
bricht vorzeitig ab. Display 1 und die Musikwiedergabe werden nicht angehalten.
Die Oberfläche unterscheidet die angeforderte Prüfung von der Sendebestätigung
des Display-Dienstes. Ob das Bild sichtbar ist, muss am Display geprüft werden.
Testzustand und Fehler sind auch im Support-Paket enthalten.
Prüfungen: `python tools/test-display-test.py`, `python tools/test-round-displays.py`,
`python tools/test-display-settings.py` und `node tools/test-display-settings-browser.cjs`.

**5.8.6** bringt **Einstellungen → Runde Displays** auf den Fernseher: Diagnose
starten, Bericht ansehen/herunterladen und auf USB speichern, ohne das Admin-Tool
zu öffnen. Laufende Prüfungen und Ergebnisse erscheinen beim Zurückkehren wieder.
Die vorhandene Diagnose wird über eine eng begrenzte lokale Schnittstelle benutzt;
der Admin-Code wird nicht an den Browser weitergegeben. Die separate Notfallseite
bleibt bei ausgefallenem Launcher verfügbar. Verkabelung und GPIOs bleiben unverändert.
Prüfungen: `python tools/test-display-settings.py`,
`node tools/test-display-settings-browser.cjs` und die Installations-/Paketprüfungen.

**5.8.5** ergaenzt die Display-Anschlussdiagnose als Schaltflaeche auf der
Notfall-Adminseite. Nach Anmeldung unter **Runde Displays** starten, Bericht
ansehen/herunterladen oder im Support-Paket auf USB exportieren. Die Pruefung
laeuft unabhaengig vom Launcher und veraendert keine GPIOs. Sie ist noch keine
Reparatur fuer einen unbekannten SPI-/Verkabelungsfehler.
Pruefungen: `python tools/test-display-diagnose.py`,
`python tools/test-maintenance-http.py`, `node tools/test-display-diagnostics-browser.cjs`
und die vorhandenen Wartungs-/Installations-/Linux-Probelauftests.

**5.8.4** korrigiert die am GC9A01 beobachtete horizontale Spiegelung und
verwendet 4 MHz SPI fuer die Displays. Ein separater Testmodus zeigt nummerierte
Testbilder ohne Abhaengigkeit von Musikdaten oder Launcher. Der USB-Helfer
`tools/start-display-repair.sh` (im Display-Reparaturpaket `start.sh`) sichert
den Treiber und startet nach dem Test den zuvor laufenden Display-Dienst wieder.
Ein weiterhin leeres Display erfordert die Pruefung der Verkabelung; ein
softwareseitig erfolgreicher SPI-Transfer bestaetigt keinen Bildempfang.

**5.8.3** korrigiert den Start des Update-Probelaufs: `systemd-run` leitet
`RestrictAddressFamilies=none` als ungueltigen Familiennamen weiter, wodurch der
Dienststart mit "Failed to set unit properties: Invalid argument" scheitert.
Die Korrektur verwendet `SystemCallFilter=~@network-io` mit `EPERM`. Netzwerkzugriff,
globale Schreibrechte und zusaetzliche Privilegien bleiben im Probelauf gesperrt.
Ein separater USB-Helfer (`tools/start-update-repair.sh`, im Rettungspaket `start.sh`)
korrigiert genau diese Stelle im bereits installierten Notfalldienst mit Sicherung,
ohne die Update-Pruefung zu umgehen. Der normale TV-Startfehler muss weiterhin
anhand des Fehlerberichts diagnostiziert werden.
Pruefungen: `python tools/test-repair-update.py`, `python tools/test-maintenance.py`,
`python tools/test-maintenance-http.py` und unter echtem Linux mit systemd als root
`python tools/test-preflight-linux.py` (vollstaendiger Paket-Probelauf und Isolation).

Neu in **5.8.2**: optionaler temperaturabhaengiger Zweikabel-Luefter ueber
GPIO26 (physischer Pin 37). Standard ein ab 60 Grad, aus unter etwa 50 Grad.
Die Kernel-Regelung funktioniert auch ohne TV-Oberflaeche. Ein geeigneter
3,3-V-kompatibler MOSFET-/Transistortreiber ist erforderlich; Motor nicht direkt
an GPIO anschliessen. Anleitung und einmalige Aktivierung: **Luefter.md**.
Der normale Update-Ablauf aktiviert die Lueftersteuerung nicht automatisch.
Pruefung: `python tools/test-fan-setup.py` (Belegung, Boot-Konfiguration,
Sicherung, wiederholte Aktivierung und Schreibfehler) sowie Installationstest.

### Visualisierung als Bildschirmschoner

Unter **Einstellungen → Energie → Stil des Bildschirmschoners → Musikvisualisierung**
auswählen. Nach der eingestellten Ruhezeit startet die Anzeige automatisch. Sie kann
auch über **Home → Musikansicht** geöffnet werden. Die Analyse verwendet den Monitor
des aktuellen Pi-Audioausgangs (bei HDMI-Wiedergabe den HDMI-Ausgang), kein Mikrofon.
Zehn Frequenzbänder werden aus dem tatsächlich ausgegebenen PCM-Ton berechnet;
Titel, Künstler und Cover kommen weiterhin aus den vorhandenen Spotify-Informationen.
Fehlt der Audiozugriff, erscheint eine Fehlermeldung statt erfundener Ausschläge.
Beim Schließen endet die Audioanalyse nach wenigen Sekunden; die Musik bleibt an.

### Windows-Bildschirm spiegeln

Das separate **Raspi-TV-PC-Bildschirm.zip** am Windows-PC entpacken und `Starten.bat`
öffnen (Python 3 nötig). In Edge/Chrome die auf Home → PC-Bildschirm angezeigte IP und
Kopplungsnummer eingeben, verbinden und die gewünschte Bildschirm-/Fensterfreigabe
bestätigen. Der localhost-Helfer übermittelt nur die Verbindungsdaten an den Pi;
das Bild läuft direkt per WebRTC im LAN. Kein Cloud- oder TURN-Dienst.
Bildschirmton ist optional und muss vom Browser angeboten und vom Benutzer gewählt werden.
Die Funktion spiegelt eine Freigabe; sie erzeugt keinen zusätzlichen Windows-Desktop.
Home am Pi oder Beenden am PC beendet die Sitzung. Ein inaktiver PC verliert nach
25 Sekunden seine Signalisierungssitzung. Bestehende Kopplungs- und Herkunftsprüfungen gelten.

### Handy als Gamepad

Handy-Weboberfläche neu laden oder Android-App **1.7** installieren. Den neuen Reiter
**Gamepad** öffnen und Aktivieren. Steuerkreuz, A/B/X/Y, L/R, Select und Start unterstützen
mehrere gleichzeitige Berührungen. In RetroArch/unterstützten Spielen den virtuellen
Controller **Raspi-TV Handy Gamepad** auswählen bzw. einmalig zuordnen.
Beim Wechsel des Reiters, Sperren des Handys und Verbindungsabbruch werden Tasten
freigegeben. Der Pi setzt den Controller nach etwa einer Sekunde ohne Aktualisierung
neutral; veraltete Paket-Sequenzen werden ignoriert. Die Bedienung funktioniert über
WLAN und die bestehende Android-Bluetooth-Anbindung. Dies ist ein digitaler Controller
mit Steuerkreuz, keine automatische Garantie für alle Spiele.

### Runde GC9A01-Displays mit Lautstärkering

Der optionale, nach dem Update zunächst deaktivierte Dienst zeigt auf Display 1 Cover/Titel
oder Uhr, auf Display 2 einen echten Lautstärkering. Einzelheiten und Anschlussplan:
**Runde-Displays.md**. GPIO/SPI erst nach passender Verkabelung ausdrücklich aktivieren.

Ab **5.8.1** hat jedes Display eigene Pins (SPI0 und SPI1, separate DC-/Reset-Leitungen).
Es wird keine Verteilerplatine benötigt. Beim Umstieg von 5.8.0 stromlos nach dem
neuen Plan umstecken und erneut aktivieren; die alte Freigabe gilt nicht für die
neue Belegung. Das Einrichtungsskript kann beide SPI-Schnittstellen mit Sicherung
der Boot-Konfiguration vorbereiten; anschließend ist ein Neustart nötig.

Prüfungen: `python tools/test-multimedia.py`, `python tools/test-round-displays.py`,
`node tools/test-mirror-browser.cjs`, `node tools/test-phone-gamepad-browser.cjs`,
`node tools/test-ambient-browser.cjs` sowie die vorhandenen Launcher-, Sicherheits-
und Installationstests. Die WebRTC-Prüfung nutzt echte lokale Verbindungen und
Videobilder, aber eine Test-Bildquelle statt einer Windows-Bildschirmfreigabe.
Audio-Monitor, GPIO/SPI, Gamepad-Erkennung durch Spiele und Bildübertragungsleistung
müssen auf der Raspberry-Pi-Hardware zusätzlich geprüft werden.
