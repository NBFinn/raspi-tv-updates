# Zwei runde Displays am Raspi-TV

Vorbereitet für zwei GC9A01-Displays, 1,28 Zoll, 240 × 240, Pins
**VCC GND SCL SDA DC CS RST**. Der Anschlussplan mit eigenen Pins gilt ab **5.8.1**.
Die GPIO-Ansteuerung bleibt nach dem normalen Update deaktiviert.

Ab **5.8.8** gibt es unter **Einstellungen → Runde Displays** zwei eigene Testknöpfe:
**Display 1 testen · Uhr / Albumcover** und **Display 2 testen · Lautstärkering**.
Wenn der Lautstärkering funktioniert und das andere Display leer bleibt, **Display 1** testen.
Nur das ausgewählte Display wird mit denselben GPIOs neu initialisiert und überträgt mit 500 kHz
statt 4 MHz seine große Nummer (**1** oder **2**), L/R und rote/grüne/blaue Farbfelder. Nach 30 Sekunden
stellt der Display-Dienst die ursprüngliche Geschwindigkeit und die normale Anzeige
wieder her. Das funktioniert auch bei geschlossener Einstellungsseite.
**Test beenden** bricht früher ab. Das andere Display und Musik laufen weiter.
Eine Sendebestätigung bedeutet, dass der Treiber das Bild übertragen hat; sie kann
den tatsächlichen Bildempfang nicht bestätigen. Bitte beobachten, ob die Nummer erscheint
und ob die normale Anzeige nach dem Test sichtbar bleibt. Bei Bedarf anschließend
eine neue Diagnose erstellen und das Support-Paket exportieren. Der Diagnosebericht
erfasst jetzt auch GPIO8/10/11/25/27 für Display 1 und nennt das getestete Display.

Ab **5.8.6** gibt es auf dem Fernseher **Einstellungen → Runde Displays**.
Dort die Diagnose starten, den Bericht ansehen/herunterladen oder mit
**Bericht auf USB speichern** einen erkannten Stick auswählen. Ein Terminalbefehl
oder eine zusätzliche Admin-Anmeldung ist dafür nicht nötig. Die Prüfung läuft
beim Verlassen der Seite weiter; beim Zurückkehren erscheint ihr Ergebnis wieder.
Das Support-Paket auf USB enthält auch den Display-Bericht. Die GPIO-Belegung
und die laufende Wiedergabe werden nicht geändert.

Ab **5.8.5** kann die Anschlussdiagnose auch in der **Notfall-Adminseite → Runde
Displays → Display-Diagnose starten** ausgefuehrt werden. Kein Terminalbefehl ist
noetig. Der Bericht ist dort lesbar und als Textdatei herunterladbar. Mit
**Support auf USB oeffnen → Support-Paket auf USB speichern** landet er zusammen
mit den bisherigen Diagnoseinformationen auf dem Stick. Die Diagnose liest nur
SPI-Geraete, GPIO-Funktionen, Hardware-Konfiguration und Display-Dienstmeldungen;
sie fordert keine GPIO-Leitungen an und aendert die Belegung nicht. Erst der Bericht
vom betroffenen Pi erlaubt die weitere Eingrenzung eines leer bleibenden Displays.

Ab **5.8.4** ist die horizontale Ausrichtung fuer die hier beobachteten,
spiegelverkehrt anzeigenden Module korrigiert (MADCTL MX). Die SPI-Geschwindigkeit
ist auf 4 MHz reduziert, um die Uebertragung ueber die verwendeten einzelnen
Steckkabel weniger anspruchsvoll zu machen. Das behebt keine falsch angeschlossene
oder lose Leitung. Mit dem separaten Display-Reparaturpaket laesst sich der Treiber
auch ohne ein vollstaendiges Update ersetzen und testen; es sichert die alte Datei.

Der Test zeigt grosse **1** (Uhr/Cover) und **2** (Lautstaerke), L/R sowie
rote/gruene/blaue Felder. Die Testbilder benoetigen weder WLAN noch eine laufende
TV-Oberflaeche. Sie bleiben bis zur Eingabetaste sichtbar. Ein Testbild kann ueber
SPI ohne Rueckleitung gesendet werden, auch wenn das Display es nicht empfaengt.
Eine Erfolgsmeldung des Programms ist deshalb keine Sichtpruefung der Hardware.
Bei leerem Display 1 besonders dessen SCL/SDA, CS, DC und RST nach der Tabelle
pruefen. Vor dem Umstecken den Pi vollstaendig vom Strom trennen.

## Anzeigen

- Display 1: Spotify-Albumcover und Titel, ersatzweise Uhr.
- Display 2: grafischer Lautstärkering mit 0–100 %, Prozentzahl und Stumm-Anzeige.
- Der Ring liest den Pi-Mixer. Bei externer TV-/Soundbar-Lautstärke ohne verfügbaren
  Rückmeldewert zeigt er `--`, statt einen Prozentwert zu erfinden.

## Anschlussplan (40-Pin-Header)

Den Pi vor dem Verkabeln vollständig ausschalten und vom Strom trennen.
Signalpegel am GPIO sind **3,3 V**. Die zulässige Versorgung deiner konkreten
Platine vor dem Anschluss prüfen; nicht allein aus dem Controller-Namen ableiten.
Der folgende Plan verwendet eine für 3,3-V-Versorgung geeignete Platine.
SCL/SDA sind hier die SPI-Leitungen, kein I²C-Anschluss.

Jedes Kabel bekommt einen eigenen Steckplatz am Pi: **14 Kabel, keine Abzweigung,
keine Verteilerplatine**. Die Zahlen in der Tabelle sind die **physischen Pin-Nummern**
des 40-Pin-Headers; die GPIO-Namen stehen zur Unterscheidung dahinter.

| Display-Pin | Display 1: Cover/Uhr → Pi-Pin | Display 2: Lautstärkering → Pi-Pin |
|---|---|---|
| VCC | **1** (3,3 V) | **17** (3,3 V) |
| GND | **6** (Masse) | **9** (Masse) |
| SCL | **23** (GPIO11 / SPI0-SCLK) | **40** (GPIO21 / SPI1-SCLK) |
| SDA | **19** (GPIO10 / SPI0-MOSI) | **38** (GPIO20 / SPI1-MOSI) |
| DC | **22** (GPIO25) | **18** (GPIO24) |
| CS | **24** (GPIO8 / SPI0-CE0) | **12** (GPIO18 / SPI1-CE0) |
| RST | **13** (GPIO27) | **16** (GPIO23) |

Der Treiber initialisiert beide Displays getrennt über SPI0 und SPI1.
Der optionale Luefter ab 5.8.2 verwendet GPIO26 / Steckplatz 37 sowie die freien
Masse-/Versorgungs-Steckplaetze 14 und gegebenenfalls 2; siehe **Luefter.md**.
Die Massen und die 3,3-V-Versorgung sind im Pi intern verbunden; dafür sind keine
zusätzlichen Kabel zwischen den Displays nötig. SPI kann außerdem seine unbenutzten
MISO-/CS-Pins reservieren. Andere Geräte dürfen die benutzten Schnittstellen und
GPIOs nicht gleichzeitig beanspruchen. Dieser Plan benötigt einen Pi mit 40-Pin-Header
und SPI1-Unterstützung. Die Pin-Positionen anhand des Pi-Pinouts prüfen.

**Bei Umstieg von 5.8.0:** Den alten gemeinsamen Anschlussplan nicht weiterverwenden.
Die Freigabe für die alte Belegung aktiviert den neuen Treiber nicht. Erst stromlos
nach dieser Tabelle umstecken und anschließend erneut aktivieren.

## Einrichten

1. Update **5.8.1** installieren. Pi herunterfahren, Strom trennen und nach obiger
   Tabelle verkabeln. Anschließend starten.
2. Im Notfall-Terminal diesen Befehl ausführen:

```sh
bash /opt/raspi-tv/enable-round-displays.sh
```

Das Notfall-Terminal läuft als Administrator. In einer normalen `admin`-SSH-Sitzung
`sudo` voranstellen. Das Skript prüft SPI, installiert bei Bedarf die optionalen
Display-Pakete (Internet erforderlich) und fragt die Verkabelung nochmals ab.
Wenn SPI0/SPI1 fehlen, bietet es mit `JA` an, die Boot-Konfiguration mit Sicherung
vorzubereiten. Danach den Pi neu starten und denselben Befehl nochmals ausführen.
Bei vorhandenen Schnittstellen die passende Verkabelung mit `JA` bestätigen.

```sh
journalctl -u raspi-tv-round -n 30 --no-pager
```

Zum Deaktivieren:

```sh
sudo systemctl disable --now raspi-tv-round
sudo rm -f /var/lib/raspi-tv-round/enabled-separate-pins
```

Ruhende Bilder werden nicht fortlaufend erneut über SPI übertragen. Der Dienst
ändert weder die Lautstärke noch die Musikquelle. Ein Test an den echten Displays
steht noch aus; Orientierung/Farben und die Initialisierung der konkreten
Platinenvariante müssen dort geprüft werden.

Technische Referenzen: [GC9A01A-Datenblatt](https://files.waveshare.com/wiki/common/GC9A01A.pdf),
[Raspberry-Pi-GPIO und SPI](https://www.raspberrypi.com/documentation/computers/raspberry-pi.html).
