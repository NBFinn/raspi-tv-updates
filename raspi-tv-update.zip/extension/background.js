// Raspi-TV Hintergrunddienst
//  * Home-Taste: bringt aus jeder App sofort zurück zur Startseite (ohne Browser-Neustart)
//  * Fernseher aus (HDMI-CEC): laufende Videos in Apps werden pausiert
//  * Erinnerungen an Sendungen werden in jeder App eingeblendet
const HOME = "http://127.0.0.1:8765/";
let lastTv = "unknown";

// After an extension update, existing tabs keep playing but their old content
// scripts cannot receive commands. Restore both ends without reloading a page.
const isLauncher = url => { try { return new URL(url).origin === new URL(HOME).origin; } catch (_) { return false; } };
async function repairTabBridge(tab) {
  if (!tab || tab.id === undefined) return;
  const files = isLauncher(tab.url) ? ["bridge.js", "keys.js", "nav.js"]
    : /^https:\/\/open\.spotify\.com\//.test(tab.url || "") ? ["keys.js", "nav.js"] : null;
  if (!files) return;
  try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, files }); } catch (_) {}
}
async function repairTabs() {
  try { for (const tab of await chrome.tabs.query({})) await repairTabBridge(tab); } catch (_) {}
}
chrome.tabs.onUpdated.addListener((id, change, tab) => {
  if (change.status === "complete") repairTabBridge({ ...tab, id });
});
repairTabs();


// Apps, die im Hintergrund weiterlaufen (eigener Tab): Spotify spielt weiter auf der Startseite,
// in anderen Apps und wenn der Fernseher aus ist.
const BG_APPS = [/^https:\/\/open\.spotify\.com\//];
const isBgApp = url => BG_APPS.some(r => r.test(url || ""));

// Den „normalen“ Tab (Startseite und alle anderen Apps) zeigen – der Hintergrund-Tab bleibt offen
async function showMain(exceptId, url) {
  const tabs = await chrome.tabs.query({});
  const main = tabs.find(t => t.id !== exceptId && !isBgApp(t.url));
  if (main) {
    const upd = { active: true };
    if (url) upd.url = url;
    else if (main.url !== HOME && main.url !== HOME + "#/") upd.url = HOME;   // Home-Taste = Startseite
    await chrome.tabs.update(main.id, upd);
  } else {
    await chrome.tabs.create({ url: url || HOME, active: true });
  }
}

async function openBg(url, navigate = false) {
  const tabs = await chrome.tabs.query({});
  const host = new URL(url).host;
  const t = tabs.find(x => [x.pendingUrl, x.url].some(value => isBgApp(value) && new URL(value).host === host));
  // Only an explicit shared link may change the playing page. Reopening Spotify just focuses it.
  const deep = navigate && new URL(url).pathname.length > 1;
  if (t) await chrome.tabs.update(t.id, deep && (t.pendingUrl || t.url) !== url
    ? { active: true, autoDiscardable: false, url } : { active: true, autoDiscardable: false });
  else {
    const created = await chrome.tabs.create({ url, active: true });
    await chrome.tabs.update(created.id, { autoDiscardable: false });
  }
}

// ---- Hintergrund-Musik absichern -------------------------------------------------------
// Protokoll (auf dem Pi: /var/log/raspi-tv/spotify-bg.log), damit sich klären lässt, warum Musik stoppt.
function bgLog(event, extra) {
  const e = Object.assign({ event }, extra || {});
  fetch(HOME + "api/spotify/bglog?e=" + encodeURIComponent(JSON.stringify(e)),
        { cache: "no-store", headers: { "X-Raspi-TV": "1" } }).catch(() => {});
}
// Zustand liegt in storage.session, weil der Hintergrunddienst zwischendurch schlafen gelegt wird
const BG = { playing: false, at: 0, tabId: null, resume: false, healAt: 0, ourPauseAt: 0, title: "" };
const bgStore = chrome.storage && chrome.storage.session;
const bgReady = bgStore ? bgStore.get("bg").then(r => Object.assign(BG, r.bg || {})).catch(() => {}) : Promise.resolve();
const bgSave = () => { if (bgStore) bgStore.set({ bg: BG }).catch(() => {}); };

async function pauseBgApps(reason, from) {
  const tabs = await chrome.tabs.query({});
  for (const t of tabs) if (isBgApp(t.url)) {
    BG.ourPauseAt = Date.now(); BG.resume = false; bgSave();
    bgLog("pause", { reason, from: (from || "").slice(0, 120) });
    chrome.tabs.sendMessage(t.id, { type: "raspi-tv-pause" }).catch(() => {});
  }
}

// Spotify-Tab neu laden und danach weiterspielen (z. B. nach Absturz oder wenn er entladen wurde)
async function healSpotify(tab, why) {
  if (Date.now() - BG.healAt < 60000) return;          // nicht in einer Schleife neu laden
  BG.healAt = Date.now(); BG.resume = true; bgSave();
  bgLog("heal", { why });
  try { await chrome.tabs.reload(tab.id); } catch (_) {}
}

if (chrome.tabs.onRemoved) chrome.tabs.onRemoved.addListener(id => {
  bgReady.then(() => { if (id === BG.tabId) { bgLog("tab-closed", { wasPlaying: BG.playing }); BG.tabId = null; BG.playing = false; bgSave(); } });
});
if (chrome.tabs.onUpdated) chrome.tabs.onUpdated.addListener((id, info, tab) => {
  if (!isBgApp(tab.url)) return;
  bgReady.then(() => {
    BG.tabId = id;
    if (info.discarded) { bgLog("discarded"); if (BG.playing) healSpotify(tab, "discarded"); }
    if (info.autoDiscardable === true) chrome.tabs.update(id, { autoDiscardable: false }).catch(() => {});
    bgSave();
  });
});

// Wächter: Spielt Spotify laut letzter Meldung, aber die Meldungen bleiben aus, ist die Seite
// eingefroren oder abgestürzt („Oh nein!“-Seite) → neu laden und weiterspielen.
async function watchSpotify() {
  await bgReady;
  const tabs = await chrome.tabs.query({});
  const sp = tabs.find(t => isBgApp(t.url));
  if (!sp) return;
  if (sp.autoDiscardable) chrome.tabs.update(sp.id, { autoDiscardable: false }).catch(() => {});
  if (sp.discarded && BG.playing) return healSpotify(sp, "discarded");
  // A delayed report does not prove a crash. Refresh metadata without interrupting audio.
  if (BG.playing && BG.at && Date.now() - BG.at > 40000)
    chrome.tabs.sendMessage(sp.id, { type: "raspi-tv-spotify-refresh" }, { frameId: 0 }).catch(() => {});
}

function onSpotifyReport(tab, now) {
  bgReady.then(() => {
    const playing = !!(now && now.playing);
    if (BG.playing && !playing && Date.now() - BG.ourPauseAt > 5000) {
      // nicht von Raspi-TV angehalten: Spotify selbst (anderes Gerät, Fehler, Werbung …) oder Benutzer
      bgLog("stopped", { title: BG.title, active: !!tab.active });
    }
    if (!BG.playing && playing) bgLog("playing", { title: now.title });
    BG.playing = playing; BG.at = Date.now(); BG.tabId = tab.id; BG.title = (now && now.title) || BG.title;
    // nach dem Neuladen: sobald der Player bereit ist, wieder abspielen
    if (BG.resume && now && now.title && !playing) {
      BG.resume = false;
      bgLog("resume", { title: now.title });
      chrome.tabs.sendMessage(tab.id, { type: "raspi-tv-spotify-toggle" }, { frameId: 0 }).catch(() => {});
    } else if (playing) BG.resume = false;
    bgSave();
  });
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || !sender.tab || sender.tab.id === undefined) return;
  if (msg.type === "raspi-tv-home") {
    if (isBgApp(sender.tab.url)) showMain(sender.tab.id).catch(() => {});
    else chrome.tabs.update(sender.tab.id, { url: HOME });
  }
  if (msg.type === "raspi-tv-open-bg" && isBgApp(msg.url)) {
    openBg(msg.url).then(() => reply({ ok: true }), () => reply({ ok: false }));
    return true;
  }
  if (msg.type === "raspi-tv-spotify-control" &&
      sender.tab.url && new URL(sender.tab.url).origin === new URL(HOME).origin &&
      ["toggle", "refresh"].includes(msg.action)) {
    chrome.tabs.query({}).then(tabs => {
      const spotify = tabs.find(t => isBgApp(t.url));
      if (spotify) return chrome.tabs.sendMessage(spotify.id,
        { type: "raspi-tv-spotify-" + msg.action }, { frameId: 0 });
    }).catch(() => {});
  }
  // Anderswo startet ein Video oder Ton → Spotify anhalten, damit nichts durcheinander spielt
  if (msg.type === "raspi-tv-media-start" && !isBgApp(sender.tab.url)) pauseBgApps("media-start", msg.src || sender.tab.url).catch(() => {});
  // Was in anderen Tabs läuft (YouTube, Mediatheken …) → an den Pi (Mini-Player der Handy-App)
  if (msg.type === "raspi-tv-medianow" && !isBgApp(sender.tab.url)) {
    fetch(HOME + "api/media/webnow?d=" + encodeURIComponent(JSON.stringify(Object.assign({}, msg.now || {}, { tab: sender.tab.id }))),
          { cache: "no-store", headers: { "X-Raspi-TV": "1" } }).catch(() => {});
  }
  // Was Spotify gerade spielt → an den Pi (Leiste auf der Startseite)
  if (msg.type === "raspi-tv-webnow" && isBgApp(sender.tab.url)) {
    onSpotifyReport(sender.tab, msg.now);
    fetch(HOME + "api/spotify/webnow?d=" + encodeURIComponent(JSON.stringify(msg.now || {})),
          { cache: "no-store", headers: { "X-Raspi-TV": "1" } }).catch(() => {});
  }
});

// Mini-Player der Handy-App: Spotify-Tab bzw. Radio auf der Startseite steuern
async function mediaCommand(m) {
  const tabs = await chrome.tabs.query({});
  const cmd = ["toggle", "next", "previous"].includes(m.cmd) ? m.cmd : "toggle";
  if (m.target === "spotify") {
    const sp = tabs.find(t => isBgApp(t.url));
    if (sp) await chrome.tabs.sendMessage(sp.id, { type: "raspi-tv-spotify-" + cmd }, { frameId: 0 });
  } else if (m.target === "web") {
    const main = tabs.find(t => t.id === m.tab && !isBgApp(t.url));
    if (main) await chrome.tabs.sendMessage(main.id, { type: "raspi-tv-media-ctl", cmd }, { frameId: 0 });
  } else if (m.target === "radio") {
    const main = tabs.find(t => !isBgApp(t.url) && (t.url || "").startsWith(HOME));
    if (main) await chrome.tabs.sendMessage(main.id, { type: "raspi-tv-radio-ctl", cmd }, { frameId: 0 });
  }
}

// Vom Handy oder per DLNA angeforderte Seite öffnen
let navBusy = false;
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || msg.type !== "raspi-tv-nav-poll" || !sender.tab) return;
  if (navBusy) { reply({}); return; }
  navBusy = true;
  fetch(HOME + "api/nav/pending", { cache: "no-store", headers: { "X-Raspi-TV": "1" } })
    .then(r => r.json())
    .then(({ url, osd, notice, media, profile }) => {
      if (media) mediaCommand(media).catch(() => {});
      if (profile) switchSpotifyProfile(profile).catch(() => {});
      if (url && /^https?:\/\//.test(url)) {
        // Anfrage vom Handy, während Spotify vorne ist: im normalen Tab öffnen, Spotify läuft weiter
        if (isBgApp(url)) openBg(url, true).catch(() => {});
        else if (isBgApp(sender.tab.url)) showMain(sender.tab.id, url).catch(() => {});
        else chrome.tabs.update(sender.tab.id, { url });
      }
      if (notice) {
        // z. B. eingehender Anruf: Hinweis einblenden und auf Wunsch Videos anhalten
        if (notice.close) {
          chrome.tabs.sendMessage(sender.tab.id, { type: "raspi-tv-notice-close", tag: notice.close }, { frameId: 0 }).catch(() => {});
        } else {
          if (notice.pause) chrome.tabs.sendMessage(sender.tab.id, { type: "raspi-tv-pause" }).catch(() => {});
          chrome.tabs.sendMessage(sender.tab.id, { type: "raspi-tv-notice", notice }, { frameId: 0 }).catch(() => {});
        }
      }
      reply({ osd: osd || null });
    })
    .catch(() => reply({}))
    .finally(() => { navBusy = false; });
  return true;   // Antwort kommt asynchron
});

async function checkTvPower() {
  try {
    const r = await fetch(HOME + "api/status", { cache: "no-store" });
    const s = await r.json();
    if (s.tv === "standby" && lastTv !== "standby") {
      const tabs = await chrome.tabs.query({});
      for (const t of tabs) {
        if (isBgApp(t.url)) continue;          // Musik läuft im Standby weiter
        chrome.tabs.sendMessage(t.id, { type: "raspi-tv-pause" }).catch(() => {});
      }
    }
    lastTv = s.tv || "unknown";
  } catch (_) {}
}

// Erinnerungen an Sendungen: in jeder App einblenden
async function checkReminders() {
  try {
    const r = await fetch(HOME + "api/reminders/due", { cache: "no-store", headers: { "X-Raspi-TV": "1" } });
    const { due } = await r.json();
    if (!due || !due.length) return;
    const tabs = await chrome.tabs.query({ active: true });
    for (const rem of due) {
      for (const t of tabs) {
        chrome.tabs.sendMessage(t.id, { type: "raspi-tv-reminder", reminder: rem }, { frameId: 0 }).catch(() => {});
      }
    }
  } catch (_) {}
}

// Automatisch ausschalten: Vorwarnung anzeigen / Bedienung melden
async function checkAutoOff() {
  try {
    const s = await (await fetch(HOME + "api/status", { cache: "no-store" })).json();
    if (typeof s.autooff === "number") {
      const tabs = await chrome.tabs.query({ active: true });
      for (const t of tabs) {
        chrome.tabs.sendMessage(t.id, { type: "raspi-tv-autooff", seconds: s.autooff }, { frameId: 0 }).catch(() => {});
      }
    }
  } catch (_) {}
}

let lastPing = 0;
chrome.runtime.onMessage.addListener(msg => {
  if (msg && msg.type === "raspi-tv-activity" && Date.now() - lastPing > 30000) {
    lastPing = Date.now();
    fetch(HOME + "api/activity", { method: "POST" }).catch(() => {});
  }
});

// USB-Stick eingesteckt -> Hinweis (bei Update-Paket: direkt zum Update)
let knownUsb = null;
async function checkUsb() {
  try {
    const { sources } = await (await fetch(HOME + "api/media/sources", { cache: "no-store" })).json();
    const usb = sources.filter(s => s.kind === "usb");
    const ids = new Set(usb.map(s => s.id));
    if (knownUsb === null) { knownUsb = ids; return; }   // beim Start nichts melden
    const added = usb.filter(s => !knownUsb.has(s.id));
    knownUsb = ids;
    if (!added.length) return;
    let update = null;
    try {
      const u = await (await fetch(HOME + "api/swupdate", { cache: "no-store" })).json();
      update = (u.found || []).find(f => added.some(a => a.id === f.src));
    } catch (_) {}
    const notice = update
      ? uiLang === "en"
        ? { kicker: "Software update found", title: "Raspi-TV " + update.version, sub: "on “" + update.name + "” · OK to install", url: HOME + "#/settings/updates" }
        : { kicker: "Software-Update gefunden", title: "Raspi-TV " + update.version, sub: "auf „" + update.name + "“ · OK zum Installieren",
          url: HOME + "#/settings/updates" }
      : { kicker: uiLang === "en" ? "USB storage detected" : "USB-Speicher erkannt", title: added[0].name,
          sub: uiLang === "en" ? "OK shows videos, music and photos" : "OK zeigt Videos, Musik und Fotos",
          url: HOME + "#/media/" + encodeURIComponent(added[0].id) };
    const tabs = await chrome.tabs.query({ active: true });
    for (const t of tabs) chrome.tabs.sendMessage(t.id, { type: "raspi-tv-notice", notice }, { frameId: 0 }).catch(() => {});
  } catch (_) {}
}

// Werbeblocker für normale Webseiten (Streaming-Apps sind in den Regeln ausgenommen)
let adblockOn = null;
let uiLang = null;
async function checkAdblock() {
  try {
    const cfg = await (await fetch(HOME + "api/config", { cache: "no-store" })).json();
    const on = !!cfg.adblock;
    if (cfg.lang !== uiLang) { uiLang = cfg.lang || "de"; chrome.storage.local.set({ lang: uiLang }).catch(() => {}); }
    if (on === adblockOn) return;
    await chrome.declarativeNetRequest.updateEnabledRulesets(on ? { enableRulesetIds: ["ads"] } : { disableRulesetIds: ["ads"] });
    adblockOn = on;
  } catch (_) {}
}

// Lebenszeichen an den Pi: zeigt, dass die Erweiterung läuft (und in welcher Version)
function hello() {
  const v = chrome.runtime.getManifest ? chrome.runtime.getManifest().version : "?";
  fetch(HOME + "api/ext/hello?v=" + encodeURIComponent(v),
        { cache: "no-store", headers: { "X-Raspi-TV": "1" } }).catch(() => {});
}
hello();

function tick() { hello(); checkAdblock(); checkTvPower(); checkReminders(); checkAutoOff(); checkUsb(); watchSpotify().catch(() => {}); }
chrome.alarms.create("raspi-tv-power", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(a => { if (a.name === "raspi-tv-power") tick(); });
chrome.runtime.onStartup.addListener(() => { repairTabs(); tick(); });
chrome.runtime.onInstalled.addListener(() => { repairTabs(); tick(); });


// ======================================================================
// 7.4: Profile mit eigenem Spotify-Konto – beim Profilwechsel die Spotify-Anmeldung (Cookies) tauschen
// ======================================================================
let spotifySwapping = false;
async function switchSpotifyProfile(p) {
  if (!p || !p.to || spotifySwapping || !chrome.cookies) return;
  spotifySwapping = true;
  try {
    const st = await chrome.storage.local.get("spotifyOwner");
    const owner = st.spotifyOwner || p.from || "default";
    if (owner === p.to) return;
    const all = await chrome.cookies.getAll({ domain: "spotify.com" });
    const keep = all.map(c => {
      const host = c.domain.replace(/^\./, "");
      const o = { url: "https://" + host + c.path, name: c.name, value: c.value, path: c.path, secure: c.secure,
                  httpOnly: c.httpOnly, sameSite: c.sameSite, storeId: c.storeId };
      if (!c.hostOnly) o.domain = c.domain;
      if (!c.session && c.expirationDate) o.expirationDate = c.expirationDate;
      return o;
    });
    await chrome.storage.local.set({ ["spotify-cookies:" + owner]: keep });
    for (const c of all) {
      await chrome.cookies.remove({ url: "https://" + c.domain.replace(/^\./, "") + c.path, name: c.name, storeId: c.storeId }).catch(() => {});
    }
    const saved = (await chrome.storage.local.get("spotify-cookies:" + p.to))["spotify-cookies:" + p.to] || [];
    for (const c of saved) await chrome.cookies.set(c).catch(() => {});
    await chrome.storage.local.set({ spotifyOwner: p.to });
    // Spotify mit dem anderen Konto neu laden (ohne Konto: Anmeldeseite)
    const tabs = await chrome.tabs.query({});
    for (const t of tabs) if (t.url && new URL(t.url).hostname.endsWith("spotify.com")) chrome.tabs.reload(t.id).catch(() => {});
  } finally {
    spotifySwapping = false;
  }
}

// Weiterschauen: an welcher Stelle eine Seite zuletzt war
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || msg.type !== "raspi-tv-resume-pos" || !sender.tab) return;
  fetch(HOME + "api/continue/pos?u=" + encodeURIComponent(msg.url || ""), { cache: "no-store", headers: { "X-Raspi-TV": "1" } })
    .then(r => r.json()).then(j => reply({ pos: j.pos })).catch(() => reply({}));
  return true;
});
