/* Local Home bridge. It can be restored after extension startup or reload. */
(() => {
  "use strict";
  if (location.origin !== "http://127.0.0.1:8765" || window.top !== window) return;
  if (window.__raspiTvBridge) window.removeEventListener("message", window.__raspiTvBridge);
  const requests = new Map();
  const listener = e => {
    if (e.source !== window || e.origin !== location.origin || !e.data) return;
    try { if (!chrome.runtime.id) return; } catch (_) { return; }
    if (e.data.type === "raspi-tv-spotify-control") {
      if (["toggle", "refresh"].includes(e.data.action)) {
        try { chrome.runtime.sendMessage({ type: e.data.type, action: e.data.action }, () => void chrome.runtime.lastError); } catch (_) {}
      }
      return;
    }
    if (e.data.type !== "raspi-tv-open-bg") return;
    const requestId = e.data.requestId;
    if (typeof requestId !== "string" || requestId.length > 128) return;
    const respond = ok => window.postMessage({ type: "raspi-tv-open-bg-ok", requestId, ok }, location.origin);
    if (requests.has(requestId)) {
      const previous = requests.get(requestId);
      if (previous !== null) respond(previous);
      return;
    }
    if (requests.size >= 50) return;
    requests.set(requestId, null);
    setTimeout(() => requests.delete(requestId), 15000);
    const finish = ok => { requests.set(requestId, ok); respond(ok); };
    try {
      chrome.runtime.sendMessage({ type: "raspi-tv-open-bg", url: String(e.data.url || "") }, reply => {
        const error = chrome.runtime.lastError;
        if (error) { requests.delete(requestId); return; }
        finish(!!(reply && reply.ok));
      });
    } catch (_) { requests.delete(requestId); }
  };
  window.__raspiTvBridge = listener;
  window.addEventListener("message", listener);
})();
