/* Raspi-TV: Bluetooth-/USB-Controller (Gamepad) steuern die Oberfläche
 *   Steuerkreuz / linker Stick  -> Pfeiltasten
 *   A -> OK · B -> Zurück · X -> TV-Programm · Y -> Info
 *   LB / RB -> Seite/Kanal − / +  · Start -> Startseite · Select -> Schließen
 * Läuft nur im obersten Fenster, damit Tasten nicht doppelt ankommen.
 */
(() => {
  "use strict";
  if (window.top !== window || window.__raspiTvPad) return;
  window.__raspiTvPad = true;

  const MAP = {
    12: "ArrowUp", 13: "ArrowDown", 14: "ArrowLeft", 15: "ArrowRight",
    0: "Enter", 1: "Escape", 2: "g", 3: "i", 4: "PageDown", 5: "PageUp", 8: "Escape", 9: "F8",
  };
  const REPEAT = new Set(["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "PageUp", "PageDown"]);
  const held = {};   // key -> {since, last}

  function send(key) {
    const target = document.activeElement || document.body;
    const opts = { key, code: key, bubbles: true, cancelable: true };
    target.dispatchEvent(new KeyboardEvent("keydown", opts));
    target.dispatchEvent(new KeyboardEvent("keyup", opts));
  }

  function pressed(gp) {
    const keys = new Set();
    gp.buttons.forEach((b, i) => { if ((b.pressed || b.value > 0.5) && MAP[i]) keys.add(MAP[i]); });
    const [x = 0, y = 0] = gp.axes;
    if (y < -0.6) keys.add("ArrowUp");
    if (y > 0.6) keys.add("ArrowDown");
    if (x < -0.6) keys.add("ArrowLeft");
    if (x > 0.6) keys.add("ArrowRight");
    return keys;
  }

  // The phone joystick belongs to the game; do not also turn its Start button into Home.
  function loop(t) {
    const pads = navigator.getGamepads ? [...navigator.getGamepads()].filter(gp => gp && !/Raspi-TV Handy Gamepad/i.test(gp.id || "")) : [];
    const now = new Set();
    pads.forEach(gp => pressed(gp).forEach(k => now.add(k)));
    for (const k of now) {
      const h = held[k];
      if (!h) { held[k] = { since: t, last: t }; send(k); }
      else if (REPEAT.has(k) && t - h.since > 420 && t - h.last > 110) { h.last = t; send(k); }
    }
    for (const k of Object.keys(held)) if (!now.has(k)) delete held[k];
    requestAnimationFrame(loop);
  }

  window.addEventListener("gamepadconnected", () => {
    if (!window.__raspiTvPadLoop) { window.__raspiTvPadLoop = true; requestAnimationFrame(loop); }
  });
})();
