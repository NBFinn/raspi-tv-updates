/* Raspi-TV: systemweite Tasten in jeder App
 *   Home-Taste der Fernbedienung (F8; BrowserHome als Altbelegung) -> Startseite
 * Läuft vor den Skripten der Webseite, damit keine App die Taste abfangen kann.
 */
(() => {
  "use strict";
  const T = s => (window.__rtvT ? window.__rtvT(s) : s);
  if (window.__raspiTvKeys) return;
  window.__raspiTvKeys = true;

  const send = m => { try { chrome.runtime.sendMessage(m, () => void chrome.runtime.lastError); } catch (_) {} };

  // Medientaste der Seite selbst auslösen (mediakeys.js merkt sich, was die Seite anmeldet). true = ausgelöst.
  const pageMediaAction = action => {
    try {
      const have = (document.documentElement.getAttribute("data-rtv-media") || "").split(",");
      if (!have.includes(action)) return false;
      window.postMessage({ type: "raspi-tv-media-action", action }, location.origin);
      return true;
    } catch (_) { return false; }
  };
  const clickFirst = sel => {
    const b = [...document.querySelectorAll(sel)].find(x => !x.disabled && x.getAttribute("aria-disabled") !== "true" && x.offsetParent !== null)
      || [...document.querySelectorAll(sel)].find(x => !x.disabled && x.getAttribute("aria-disabled") !== "true");
    if (b) b.click();
    return !!b;
  };

  // Hörbarer Ton startet in einem normalen Tab → Hintergrund-Musik (Spotify) anhalten
  if (location.hostname !== "open.spotify.com") {
    document.addEventListener("play", e => {
      const m = e.target;
      if (m && (m.tagName === "VIDEO" || m.tagName === "AUDIO") && !m.muted && m.volume > 0)
        send({ type: "raspi-tv-media-start", src: location.href.split("#")[0] + " " + String(m.currentSrc || m.src || "").slice(0, 80) });
    }, true);
  }

  // Spotify: melden, was gerade läuft (für die Leiste auf der Startseite)
  // Alle anderen Seiten (YouTube, Mediatheken, Netflix …): melden, was gerade läuft – für die Handy-App
  const isLauncherPage = location.origin === "http://127.0.0.1:8765";
  if (!isLauncherPage && location.hostname !== "open.spotify.com" && window.top === window) {
    const SITES = { "youtube.com": "YouTube", "netflix.com": "Netflix", "ardmediathek.de": "ARD Mediathek", "zdf.de": "ZDF",
      "arte.tv": "ARTE", "3sat.de": "3sat", "kika.de": "KiKA", "joyn.de": "Joyn", "twitch.tv": "Twitch",
      "primevideo.com": "Prime Video", "amazon.de": "Prime Video", "disneyplus.com": "Disney+", "plus.rtl.de": "RTL+",
      "crunchyroll.com": "Crunchyroll", "music.youtube.com": "YouTube Music" };
    const site = () => {
      const h = location.hostname.replace(/^www\./, "");
      const k = Object.keys(SITES).sort((a, b) => b.length - a.length).find(d => h === d || h.endsWith("." + d));
      return k ? SITES[k] : h;
    };
    const mainMedia = () => {
      const all = [...document.querySelectorAll("video, audio")].filter(m => m.currentSrc || m.src);
      return all.find(m => !m.paused) || all.find(m => m.duration > 0 && m.currentTime > 0) || null;
    };
    let lastKey = "", lastAt = 0;
    setInterval(() => {
      let now = null;
      try {
        const m = mainMedia();
        const md = navigator.mediaSession && navigator.mediaSession.metadata;
        if (m) {
          const art = md && md.artwork && md.artwork.length ? md.artwork[md.artwork.length - 1].src : "";
          const title = (md && md.title) || document.title.replace(/\s*[-–|]\s*(YouTube|Netflix|ARD Mediathek|ZDFmediathek)\s*$/i, "");
          now = { title: String(title || site()).trim().slice(0, 120), artist: (md && md.artist) || site(), cover: art,
                  playing: !m.paused, site: site() };
          // Position und Länge (Sekunden) für den Fortschrittsring der runden Displays; Live-Streams haben keine Länge
          if (isFinite(m.duration) && m.duration > 0) { now.pos = Math.round(m.currentTime); now.dur = Math.round(m.duration); }
        }
      } catch (_) {}
      const key = JSON.stringify(now);
      if (key !== lastKey || (now && Date.now() - lastAt > 8000)) {
        lastKey = key; lastAt = Date.now();
        send({ type: "raspi-tv-medianow", now });
      }
    }, 2500);
    chrome.runtime.onMessage.addListener(msg => {
      if (!msg || msg.type !== "raspi-tv-media-ctl") return;
      const m = mainMedia();
      if (msg.cmd === "toggle" && m) { if (m.paused) m.play().catch(() => {}); else m.pause(); }
      if (msg.cmd === "next" || msg.cmd === "previous") {
        const next = msg.cmd === "next";
        const sel = next ? ".ytp-next-button, [data-uia=control-next], button[aria-label*='Nächst'], button[aria-label*='Next'], button[aria-label*='Weiter']"
                         : ".ytp-prev-button, button[aria-label*='Vorher'], button[aria-label*='Previous'], button[aria-label*='Zurück']";
        // 1. Medientaste der Seite, 2. sichtbarer Knopf, 3. Zurück = von vorn / Weiter = 30 s vor
        if (!pageMediaAction(next ? "nexttrack" : "previoustrack") && !clickFirst(sel) && m) {
          if (next) m.currentTime = Math.min(m.duration || 1e9, m.currentTime + 30);
          else m.currentTime = m.currentTime > 5 ? 0 : Math.max(0, m.currentTime - 15);
        }
      }
      lastKey = "";
    });
  }

  if (location.hostname === "open.spotify.com" && window.top === window) {
    let lastNow = "", lastAt = 0;
    const reportNow = () => {
      let now = null;
      try {
        const md = navigator.mediaSession && navigator.mediaSession.metadata;
        const q = s => document.querySelector(s);
        const widget = q('[data-testid="now-playing-widget"]');
        const titleNode = q('[data-testid="context-item-info-title"]') ||
          (widget && widget.querySelector('a[data-testid="context-item-link"], a[href*="/track/"], a[href*="/episode/"]'));
        const artistNode = q('[data-testid="context-item-info-artist"]') ||
          (widget && widget.querySelector('[data-testid="context-item-info-subtitles"], a[href*="/artist/"]'));
        const title = (md && md.title) || (titleNode && titleNode.textContent) || "";
        const artist = (md && md.artist) || (artistNode && artistNode.textContent) || "";
        const art = md && md.artwork && md.artwork.length ? md.artwork[md.artwork.length - 1].src
          : (q('[data-testid="now-playing-widget"] img') || {}).src || "";
        const btn = q('[data-testid="control-button-playpause"]');
        const label = btn ? (btn.getAttribute("aria-label") || "") : "";
        const playing = label ? /pause|pausieren|anhalten/i.test(label)
          : !!(navigator.mediaSession && navigator.mediaSession.playbackState === "playing");
        if (title) now = { title: title.trim(), artist: artist.trim(), cover: art, playing };
        if (now) {
          // Position und Länge: Zeitangaben des Players („1:23“, Restzeit „-2:10“) oder der Schieberegler
          const secs = el => {
            const m = el && /(-?)\s*(?:(\d+):)?(\d+):(\d\d)/.exec(el.textContent || "");
            return m ? { neg: !!m[1], v: (+(m[2] || 0)) * 3600 + (+m[3]) * 60 + (+m[4]) } : null;
          };
          const p = secs(q('[data-testid="playback-position"]')), d = secs(q('[data-testid="playback-duration"]'));
          const bar = q('[data-testid="playback-progressbar"] input[type="range"]');
          if (p && d) { now.pos = p.v; now.dur = d.neg ? p.v + d.v : d.v; }
          else if (bar && +bar.max > 0) { now.pos = Math.round(+bar.value / 1000); now.dur = Math.round(+bar.max / 1000); }
        }
      } catch (_) {}
      const key = JSON.stringify(now);
      if (key !== lastNow || Date.now() - lastAt > 8000) {
        lastNow = key; lastAt = Date.now();
        send({ type: "raspi-tv-webnow", now });
      }
    };
    setInterval(reportNow, 2500);
    chrome.runtime.onMessage.addListener(msg => {
      const BTN = { "raspi-tv-spotify-toggle": "control-button-playpause", "raspi-tv-spotify-next": "control-button-skip-forward",
                    "raspi-tv-spotify-previous": "control-button-skip-back" };
      if (!msg || !(msg.type in BTN || msg.type === "raspi-tv-spotify-refresh")) return;
      if (BTN[msg.type]) {
        // Weiter/Zurück zuerst über die Medientasten von Spotify selbst – unabhängig davon, wie die Knöpfe gerade heißen
        const action = { "raspi-tv-spotify-next": "nexttrack", "raspi-tv-spotify-previous": "previoustrack" }[msg.type];
        const label = { "raspi-tv-spotify-next": "[aria-label='Weiter'], [aria-label='Next'], [aria-label*='Nächster']",
                        "raspi-tv-spotify-previous": "[aria-label='Zurück'], [aria-label='Previous'], [aria-label*='Vorheriger']" }[msg.type];
        if (!(action && pageMediaAction(action)))
          clickFirst(`[data-testid="${BTN[msg.type]}"]`) || (label && clickFirst("button" + label.split(", ").join(", button")));
      }
      lastNow = ""; lastAt = 0;
      reportNow();
      if (BTN[msg.type]) { setTimeout(reportNow, 150); setTimeout(reportNow, 1200); }
    });
  }

  // Radio auf der Startseite vom Handy steuern (Mini-Player)
  if (location.origin === "http://127.0.0.1:8765" && window.top === window) {
    chrome.runtime.onMessage.addListener(msg => {
      if (msg && msg.type === "raspi-tv-radio-ctl") window.postMessage({ type: "raspi-tv-radio-ctl", cmd: msg.cmd }, location.origin);
    });
  }

  // Spotify-Anmeldung (ncspot): Nach der Bestätigung landet der Browser auf der kleinen
  // Rückmeldeseite von ncspot (127.0.0.1:<Port>/login?code=…) – von dort automatisch zurück zur App.
  try {
    if (window.top === window && location.hostname === "127.0.0.1" && location.port && location.port !== "8765" &&
        /^\/(ncspot_)?login$/.test(location.pathname) && /[?&]code=/.test(location.search)) {
      setTimeout(() => { location.href = "http://127.0.0.1:8765/terminal.html?app=spotify"; }, 2000);
    }
  } catch (_) {}

  let sent = 0;
  function goHome() {
    // Leaving a saver must not reload the launcher and destroy its radio element.
    if (location.origin === "http://127.0.0.1:8765" && document.querySelector(".saver")) {
      window.postMessage({ type: "raspi-tv-close-saver" }, location.origin);
      return;
    }
    const now = Date.now();
    if (now - sent < 1500) return; // doppelte Auslösung vermeiden
    sent = now;
    try {
      chrome.runtime.sendMessage({ type: "raspi-tv-home" });
    } catch (_) {
      if (window.top === window && location.hostname !== "open.spotify.com") location.href = "http://127.0.0.1:8765/";
    }
  }

  // Fernseher wurde ausgeschaltet -> alle Videos dieser Seite anhalten
  // Erinnerung -> Hinweis einblenden
  try {
    chrome.runtime.onMessage.addListener(msg => {
      if (msg && msg.type === "raspi-tv-pause") {
        // Spotify über den eigenen Knopf anhalten (sonst passt die Anzeige nicht mehr zum Ton)
        const sp = location.hostname === "open.spotify.com" && document.querySelector('[data-testid="control-button-playpause"]');
        if (sp) { if (/pause/i.test(sp.getAttribute("aria-label") || "")) sp.click(); }
        else document.querySelectorAll("video, audio").forEach(m => { try { m.pause(); } catch (_) {} });
      }
      if (msg && msg.type === "raspi-tv-reminder" && window.top === window) showReminder(msg.reminder);
      if (msg && msg.type === "raspi-tv-autooff" && window.top === window) showAutoOff(msg.seconds);
      if (msg && msg.type === "raspi-tv-notice" && window.top === window) showNotice(msg.notice);
      if (msg && msg.type === "raspi-tv-notice-close" && window.top === window && reminderBox && reminderBox.dataset.tag === msg.tag) closeReminder();
    });
  } catch (_) {}

  let reminderBox = null, noticeTimer = null;
  const ICONS = {
    bell: '<path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 21h4"/>',
    phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
  };
  function hhmm(ts) {
    const d = new Date(ts * 1000);
    return String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
  }
  function closeReminder() {
    if (!reminderBox) return;
    const box = reminderBox;
    reminderBox = null;
    box.style.opacity = "0";
    box.style.transform = "translate(-50%, -3vh) scale(.96)";
    setTimeout(() => (box._host || box).remove(), 300);
  }
  function showReminder(r) {
    const started = r.start <= Date.now() / 1000;
    showNotice({
      kicker: T("Erinnerung"), title: r.title || T("Sendung"), okLabel: T("Umschalten"),
      sub: T(started ? "Läuft seit" : "Beginnt um") + " " + hhmm(r.start) + " " + T("Uhr auf") + " " + r.channel,
      url: "http://127.0.0.1:8765/tv.html?name=" + encodeURIComponent(r.channel),
    });
  }
  function showNotice(n) {
    closeReminder();
    const host = document.createElement("raspi-tv-reminder");
    const root = host.attachShadow({ mode: "closed" });
    root.innerHTML = `<style>
      .b { position: fixed; top: 4vh; left: 50%; transform: translate(-50%, -3vh) scale(.96); opacity: 0; z-index: 2147483647;
        display: flex; align-items: center; gap: 1.4vw; min-width: 44vw; max-width: 70vw; padding: 2vh 2vw;
        background: linear-gradient(135deg, rgba(22,40,78,.97), rgba(11,13,18,.97)); color: #f3f4f7;
        border: 1px solid rgba(61,139,255,.6); border-radius: 1.4vw; box-shadow: 0 3vh 8vh rgba(0,0,0,.6), 0 0 4vw rgba(61,139,255,.25);
        font-family: "DejaVu Sans", system-ui, sans-serif; transition: opacity .3s cubic-bezier(.2,.8,.2,1), transform .45s cubic-bezier(.34,1.56,.64,1); }
      .i { width: 3.4vw; height: 3.4vw; border-radius: 50%; background: #3d8bff; display: flex; align-items: center; justify-content: center; flex: none;
        animation: ring 1.2s ease-in-out var(--rings, 2); }
      .b.call .i { background: #2fbf71; box-shadow: 0 0 0 0 rgba(47,191,113,.6); animation: ring 1.2s ease-in-out infinite, pulse 1.2s ease-out infinite; }
      @keyframes pulse { 0% { box-shadow: 0 0 0 0 rgba(47,191,113,.6); } 100% { box-shadow: 0 0 0 1.6vw rgba(47,191,113,0); } }
      .b.call { border-color: rgba(47,191,113,.7); background: linear-gradient(135deg, rgba(18,58,40,.97), rgba(11,13,18,.97)); }
      .b.call .k { color: #8fe3b6; }
      @keyframes ring { 0%,100% { transform: rotate(0); } 20% { transform: rotate(-14deg); } 40% { transform: rotate(12deg); } 60% { transform: rotate(-8deg); } 80% { transform: rotate(5deg); } }
      .i svg { width: 1.8vw; height: 1.8vw; }
      .k { color: #8fb8ff; font-size: .95vw; font-weight: 700; letter-spacing: .12em; text-transform: uppercase; }
      .t { font-size: 1.7vw; font-weight: 800; margin: .3vh 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .s { color: #b9bfcc; font-size: 1.05vw; }
      .h { margin-left: auto; text-align: right; font-size: .95vw; color: #b9bfcc; white-space: nowrap; line-height: 1.8; }
      .h b { color: #fff; background: rgba(255,255,255,.12); padding: .2vh .6vw; border-radius: .4vw; }
    </style>
    <div class="b"><div class="i"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linejoin="round">${ICONS[n.icon] || ICONS.bell}</svg></div>
      <div><div class="k">Erinnerung</div><div class="t"></div><div class="s"></div></div>
      <div class="h">${n.url ? `<b>OK</b> <span class="ok"></span><br><b>${T("Zurück")}</b> ${T("Schließen")}` : `<b>OK</b> ${T("Schließen")}`}</div></div>`;
    root.querySelector(".k").textContent = n.kicker || "";
    root.querySelector(".t").textContent = n.title || "";
    root.querySelector(".s").textContent = n.sub || "";
    if (root.querySelector(".ok")) root.querySelector(".ok").textContent = n.okLabel || T("Öffnen");
    (document.documentElement || document).appendChild(host);
    reminderBox = root.querySelector(".b");
    reminderBox.dataset.url = n.url || "";
    reminderBox.dataset.tag = n.tag || "";
    if (n.icon === "phone") reminderBox.classList.add("call");
    reminderBox._host = host;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      reminderBox.style.opacity = "1";
      reminderBox.style.transform = "translate(-50%, 0) scale(1)";
    }));
    clearTimeout(noticeTimer);
    noticeTimer = setTimeout(closeReminder, n.timeout || 60000);
  }

  // ---- Bedienung melden (für „Automatisch ausschalten“) ----
  let lastAct = 0;
  function activity() {
    if (Date.now() - lastAct < 30000) return;
    lastAct = Date.now();
    try { chrome.runtime.sendMessage({ type: "raspi-tv-activity" }); } catch (_) {}
  }
  ["keydown", "mousedown", "wheel"].forEach(ev => window.addEventListener(ev, () => { activity(); hideAutoOff(); }, true));

  // ---- Vorwarnung „schaltet sich gleich aus“ ----
  let offBox = null, offTimer = null;
  function hideAutoOff() {
    if (!offBox) return;
    clearInterval(offTimer);
    const h = offBox;
    offBox = null;
    lastAct = 0;
    activity();
    h.remove();
  }
  function showAutoOff(seconds) {
    if (offBox) return;
    const host = document.createElement("raspi-tv-autooff");
    const root = host.attachShadow({ mode: "closed" });
    root.innerHTML = `<style>
      .w { position: fixed; inset: 0; z-index: 2147483647; display: flex; align-items: center; justify-content: center;
        background: rgba(5,6,10,.72); font-family: "DejaVu Sans", system-ui, sans-serif; color: #f3f4f7; animation: f .3s ease; }
      @keyframes f { from { opacity: 0; } }
      .b { text-align: center; background: #151922; border: 1px solid #2a3142; border-radius: 1.6vw; padding: 4vh 4vw;
        box-shadow: 0 4vh 10vh rgba(0,0,0,.6); animation: p .45s cubic-bezier(.34,1.56,.64,1); }
      @keyframes p { from { transform: scale(.9); opacity: 0; } }
      .n { font-size: 6vw; font-weight: 800; color: #6aa5ff; font-variant-numeric: tabular-nums; }
      .t { font-size: 1.7vw; font-weight: 700; margin: 1vh 0; }
      .s { font-size: 1.1vw; color: #b9bfcc; }
    </style><div class="w"><div class="b"><div class="t">${T("Noch jemand da?")}</div><div class="n"></div>
      <div class="s">${T("Raspi-TV schaltet sich gleich aus, weil länger nichts bedient wurde.")}<br>${T("Drücke eine beliebige Taste, um weiterzuschauen.")}</div></div></div>`;
    (document.documentElement || document).appendChild(host);
    offBox = host;
    let left = Math.max(1, Math.round(seconds));
    const n = root.querySelector(".n");
    const draw = () => { n.textContent = left + " s"; };
    draw();
    offTimer = setInterval(() => { left--; if (left <= 0) { clearInterval(offTimer); host.remove(); offBox = null; } else draw(); }, 1000);
  }

  window.addEventListener("keydown", e => {
    if (!reminderBox) return;
    if (e.key === "Enter") {
      const url = reminderBox.dataset.url;
      closeReminder();
      if (url) location.href = url;
    } else if (["Escape", "Backspace", "BrowserBack"].includes(e.key)) {
      closeReminder();
    } else {
      return;
    }
    e.preventDefault();
    e.stopImmediatePropagation();
  }, true);

  window.addEventListener("keydown", e => {
    const typing = e.target && ((e.target.matches && e.target.matches("input, textarea")) || e.target.isContentEditable);
    const closeSpotify = location.hostname === "open.spotify.com" && !typing &&
      ["Escape", "BrowserBack", "Backspace"].includes(e.key);
    if (closeSpotify || e.key === "F8" || e.code === "F8" || e.key === "BrowserHome" || e.key === "GoHome" || e.code === "BrowserHome") {
      e.preventDefault();
      e.stopImmediatePropagation();
      goHome();
    }
  }, true);
})();
