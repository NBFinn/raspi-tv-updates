/* Raspi-TV: Sprache für Hinweise und Bildschirmtastatur (Deutsch / English).
 * Die Sprache stellt der Hintergrunddienst aus den Raspi-TV-Einstellungen bereit. */
(() => {
  "use strict";
  if (window.__rtvT) return;
  const EN = {
    "Erinnerung": "Reminder", "Sendung": "Show", "Umschalten": "Switch", "Läuft seit": "Started", "Beginnt um": "Starts at", "Uhr auf": "on",
    "Schließen": "Close", "Zurück": "Back", "Öffnen": "Open", "Noch jemand da?": "Still watching?",
    "Raspi-TV schaltet sich gleich aus, weil länger nichts bedient wurde.": "Raspi-TV will turn off soon because nothing was pressed for a while.",
    "Drücke eine beliebige Taste, um weiterzuschauen.": "Press any key to keep watching.",
    "Leerzeichen": "Space", "Weiter ⇥": "Next ⇥", "Senden ↵": "Send ↵", "Fertig": "Done", "Taste wählen": "choose key", "tippen": "type",
    "Gelb": "Yellow", "schließen": "close",
  };
  window.__rtvLang = "de";
  window.__rtvT = s => (window.__rtvLang === "en" && EN[s]) || s;
  try { chrome.storage.local.get("lang", r => { if (r && r.lang) window.__rtvLang = r.lang; }); } catch (_) {}
})();
