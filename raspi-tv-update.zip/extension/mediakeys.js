/* Raspi-TV: „Weiter“ / „Zurück“ / Play-Pause vom Handy für jede Seite.
 * Läuft in der Welt der Webseite (world: MAIN) und merkt sich die Medientasten-Funktionen, die die Seite
 * selbst anmeldet (navigator.mediaSession.setActionHandler – Spotify, YouTube, Mediatheken …). keys.js ruft
 * sie über eine Nachricht auf. Das funktioniert auch, wenn die Seite ihre Knöpfe umbenennt oder versteckt.
 */
(() => {
  "use strict";
  if (window.__raspiTvMediaKeys || !("mediaSession" in navigator)) return;
  window.__raspiTvMediaKeys = true;
  const handlers = {};
  const publish = () => {
    try { document.documentElement.setAttribute("data-rtv-media", Object.keys(handlers).join(",")); } catch (_) {}
  };
  try {
    const proto = Object.getPrototypeOf(navigator.mediaSession);
    const original = proto.setActionHandler;
    proto.setActionHandler = function (action, handler) {
      try {
        if (typeof handler === "function") handlers[action] = handler; else delete handlers[action];
        publish();
      } catch (_) {}
      return original.apply(this, arguments);
    };
  } catch (_) { return; }
  window.addEventListener("message", e => {
    if (e.source !== window || !e.data || e.data.type !== "raspi-tv-media-action") return;
    const fn = handlers[e.data.action];
    if (typeof fn !== "function") return;
    try { fn({ action: e.data.action }); } catch (_) {}
  });
  document.addEventListener("DOMContentLoaded", publish);
})();
