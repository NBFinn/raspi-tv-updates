/* Raspi-TV: Seiten öffnen, die vom Handy oder per DLNA angefordert werden
 * (Sprachsuche, „Wiedergabe auf Raspi-TV“), und Lautstärke einblenden. Nur im obersten Fenster. */
(() => {
  "use strict";
  if (window.top !== window || window.__raspiTvNav) return;
  window.__raspiTvNav = true;

  let host = null, root = null, hideTimer = null;
  function showVolume(o) {
    if (!host) {
      host = document.createElement("raspi-tv-volume");
      root = host.attachShadow({ mode: "closed" });
      root.innerHTML = `<style>
        .v { position: fixed; right: 3vw; top: 50%; transform: translate(2vw, -50%); opacity: 0; z-index: 2147483647;
          width: 4.6vw; padding: 1.4vw 0 1.2vw; border-radius: 2.4vw; background: rgba(15,18,26,.92); border: 1px solid rgba(255,255,255,.12);
          display: flex; flex-direction: column; align-items: center; gap: 1vw; color: #fff; font: 700 1.05vw "DejaVu Sans", system-ui, sans-serif;
          box-shadow: 0 2vh 6vh rgba(0,0,0,.5); transition: opacity .2s ease, transform .35s cubic-bezier(.34,1.56,.64,1); }
        .v.show { opacity: 1; transform: translate(0, -50%); }
        .bar { width: .7vw; height: 22vh; border-radius: 99px; background: rgba(255,255,255,.18); position: relative; overflow: hidden; }
        .bar i { position: absolute; left: 0; right: 0; bottom: 0; background: #3d8bff; border-radius: inherit; transition: height .15s ease; }
        svg { width: 1.8vw; height: 1.8vw; }
      </style><div class="v"><div class="bar"><i></i></div><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linejoin="round"><path d="M4 9h4l5-4v14l-5-4H4z"/><path class="w" d="M16.5 8.5a5 5 0 0 1 0 7"/></svg><span></span></div>`;
      (document.documentElement || document).appendChild(host);
    }
    const v = root.querySelector(".v");
    const level = Math.max(0, Math.min(100, o.volume || 0));
    root.querySelector(".bar i").style.height = (o.muted ? 0 : level) + "%";
    root.querySelector("span").textContent = o.muted ? "×" : String(level);
    root.querySelector(".w").style.display = o.muted ? "none" : "";
    requestAnimationFrame(() => v.classList.add("show"));
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => v.classList.remove("show"), 1800);
  }

  setInterval(() => {
    if (document.visibilityState !== "visible") return;
    try {
      chrome.runtime.sendMessage({ type: "raspi-tv-nav-poll" }, r => {
        void chrome.runtime.lastError;
        if (r && r.osd && r.osd.volume != null) showVolume(r.osd);
      });
    } catch (_) {}
  }, 700);
})();
