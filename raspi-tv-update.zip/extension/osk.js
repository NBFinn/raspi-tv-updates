/* Raspi-TV – Bildschirmtastatur
 *
 * Erscheint automatisch, sobald ein Textfeld fokussiert wird (auf jeder Webseite,
 * z. B. beim Login von Netflix, und in den Raspi-TV-Einstellungen).
 * Bedienung: Pfeiltasten wählen, OK tippt, Gelb/Esc/Zurück schließt.
 * Wer eine echte Tastatur benutzt, bekommt sie nicht mehr angezeigt.
 */
(() => {
  "use strict";
  const T = s => (window.__rtvT ? window.__rtvT(s) : s);
  if (window.__raspiTvOsk) return;
  window.__raspiTvOsk = true;

  const TEXT_TYPES = new Set(["text", "email", "password", "search", "url", "tel", "number", ""]);

  const BOTTOM = mode => [
    { k: "mode", l: mode, w: 1.6 }, "@", { k: "space", l: T("Leerzeichen"), w: 4.4 }, ".",
    { k: "next", l: T("Weiter ⇥"), w: 1.7 }, { k: "enter", l: T("Senden ↵"), w: 1.7 }, { k: "close", l: T("Fertig"), w: 1.5 },
  ];
  const LAYOUTS = {
    abc: [
      ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "ß"],
      ["q", "w", "e", "r", "t", "z", "u", "i", "o", "p", "ü"],
      ["a", "s", "d", "f", "g", "h", "j", "k", "l", "ö", "ä"],
      [{ k: "shift", l: "⇧", w: 1.6 }, "y", "x", "c", "v", "b", "n", "m", "-", "_", { k: "back", l: "⌫", w: 1.6 }],
      BOTTOM("?123"),
    ],
    sym: [
      ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "€"],
      ["!", "\"", "§", "$", "%", "&", "/", "(", ")", "=", "?"],
      ["+", "*", "#", "'", ":", ";", ",", "<", ">", "|", "~"],
      [{ k: "dotcom", l: ".de", w: 1.6 }, "{", "}", "[", "]", "\\", "^", "°", "`", "´", { k: "back", l: "⌫", w: 1.6 }],
      BOTTOM("ABC"),
    ],
  };

  let host, root, kbEl;
  let open = false;
  let layout = "abc";
  let shift = 0; // 0 aus, 1 einmal, 2 dauerhaft
  let row = 1, col = 0;
  let target = null;
  let physicalKeyboard = false;
  const swallowed = new Set();

  // ---------------------------------------------------------------- Helfer
  function deepActive() {
    let a = document.activeElement;
    while (a && a.shadowRoot && a.shadowRoot.activeElement) a = a.shadowRoot.activeElement;
    return a;
  }

  function isEditable(el) {
    if (!el || el.disabled || el.readOnly) return false;
    if (el.closest && el.closest("[data-no-osk]")) return false;   // z. B. Terminal: eigene Tastatureingabe
    if (el.isContentEditable) return true;
    if (el.tagName === "TEXTAREA") return true;
    if (el.tagName === "INPUT") return TEXT_TYPES.has((el.getAttribute("type") || "").toLowerCase());
    return false;
  }

  function visible(el) {
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== "hidden";
  }

  // ---------------------------------------------------------------- Oberfläche
  const CSS = `
    :host { all: initial; }
    .kb {
      position: fixed; left: 0; right: 0; bottom: 0;
      z-index: 2147483647;
      background: rgba(11, 13, 18, .97);
      border-top: 1px solid #2a3142;
      box-shadow: 0 -2vh 6vh rgba(0,0,0,.55);
      padding: 1.6vh 6vw 2.2vh;
      font-family: "DejaVu Sans", system-ui, sans-serif;
      color: #f3f4f7;
      display: none;
      user-select: none;
    }
    .kb.open { display: block; animation: up .14s ease-out; }
    @keyframes up { from { transform: translateY(20%); opacity: 0; } }
    .top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.2vh; font-size: .95vw; color: #8b93a5; }
    .top b { color: #f3f4f7; font-weight: 600; }
    .r { display: flex; gap: .5vw; margin-bottom: .6vw; }
    .k {
      flex: 1 1 0;
      height: 5.6vh;
      min-height: 32px;
      display: flex; align-items: center; justify-content: center;
      background: #1c2230;
      border-radius: .6vw;
      font-size: 1.35vw;
      transition: transform .08s, background .08s;
      cursor: pointer;
    }
    .k.fn { background: #262d3c; font-size: 1vw; font-weight: 600; }
    .k.on { background: #ff7a59; color: #1a0d08; }
    .k.f { background: #f3f4f7; color: #0b0d12; transform: scale(1.08); box-shadow: 0 .6vh 1.6vh rgba(0,0,0,.5); }
    .k:active { transform: scale(.96); }
  `;

  function build() {
    host = document.createElement("raspi-tv-osk");
    root = host.attachShadow({ mode: "closed" });
    root.innerHTML = `<style>${CSS}</style><div class="kb"></div>`;
    kbEl = root.querySelector(".kb");
    // Klicks dürfen den Fokus nicht aus dem Textfeld nehmen
    kbEl.addEventListener("mousedown", e => e.preventDefault());
    kbEl.addEventListener("click", e => {
      const k = e.target.closest(".k");
      if (!k) return;
      row = +k.dataset.r; col = +k.dataset.c;
      press();
    });
    (document.documentElement || document).appendChild(host);
  }

  function keyAt(r, c) {
    const k = LAYOUTS[layout][r][c];
    return typeof k === "string" ? { k: "char", l: k, ch: k } : k;
  }

  function label(key) {
    if (key.k === "char" && shift && key.l.length === 1) return key.l.toUpperCase();
    return key.l;
  }

  function draw() {
    const rows = LAYOUTS[layout];
    row = Math.min(row, rows.length - 1);
    col = Math.min(col, rows[row].length - 1);
    kbEl.innerHTML =
      `<div class="top"><span><b>◀ ▶ ▲ ▼</b> ${T("Taste wählen")} &nbsp; <b>OK</b> ${T("tippen")}</span>` +
      `<span><b>${T("Gelb")}</b> / <b>${T("Zurück")}</b> ${T("schließen")}</span></div>` +
      rows.map((r, ri) => `<div class="r">${r.map((_, ci) => {
        const key = keyAt(ri, ci);
        const fn = key.k !== "char";
        const on = key.k === "shift" && shift;
        const f = ri === row && ci === col;
        const txt = label(key).replace(/&/g, "&amp;").replace(/</g, "&lt;");
        return `<div class="k${fn ? " fn" : ""}${on ? " on" : ""}${f ? " f" : ""}" ` +
          `style="flex-grow:${key.w || 1}" data-r="${ri}" data-c="${ci}">${txt}</div>`;
      }).join("")}</div>`).join("");
  }

  function show(el) {
    if (physicalKeyboard || !el) return;
    if (!host || !host.isConnected) build();
    target = el;
    const t = (el.getAttribute && (el.getAttribute("type") || "").toLowerCase()) || "";
    layout = t === "number" || t === "tel" ? "sym" : "abc";
    shift = 0;
    row = 1; col = 0;
    draw();
    kbEl.classList.add("open");
    open = true;
    // Textfeld über die Tastatur schieben
    setTimeout(() => {
      const r = el.getBoundingClientRect();
      if (r.bottom > innerHeight * 0.52) window.scrollBy({ top: r.top - innerHeight * 0.18, behavior: "smooth" });
    }, 30);
  }

  function hide() {
    if (!open) return;
    open = false;
    kbEl.classList.remove("open");
  }

  // ---------------------------------------------------------------- Eingabe
  function insert(text) {
    const el = target;
    if (!el) return;
    if (deepActive() !== el) el.focus();
    if (document.execCommand && document.execCommand("insertText", false, text)) return;
    if ("value" in el) {
      try {
        const s = el.selectionStart ?? el.value.length, e = el.selectionEnd ?? el.value.length;
        el.setRangeText(text, s, e, "end");
      } catch (_) {
        el.value += text;
      }
      el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    }
  }

  function backspace() {
    const el = target;
    if (!el) return;
    if (deepActive() !== el) el.focus();
    if (document.execCommand && document.execCommand("delete", false)) return;
    if ("value" in el) {
      el.value = el.value.slice(0, -1);
      el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "deleteContentBackward" }));
    }
  }

  function editableFields() {
    return [...document.querySelectorAll("input, textarea, [contenteditable=''], [contenteditable='true']")]
      .filter(el => isEditable(el) && visible(el));
  }

  function nextField() {
    const list = editableFields();
    const i = list.indexOf(target);
    const next = list[i + 1];
    if (next) next.focus(); else hide();
  }

  function submit() {
    const el = target;
    hide();
    if (!el) return;
    const form = el.form || (el.closest && el.closest("form"));
    if (form) {
      const btn = form.querySelector("button[type=submit], input[type=submit], button:not([type])");
      if (btn && !btn.disabled) return btn.click();
      if (form.requestSubmit) return form.requestSubmit();
    }
    for (const type of ["keydown", "keypress", "keyup"]) {
      el.dispatchEvent(new KeyboardEvent(type, { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }));
    }
  }

  function press() {
    const key = keyAt(row, col);
    switch (key.k) {
      case "char":
        insert(shift ? key.ch.toUpperCase() : key.ch);
        if (shift === 1) shift = 0;
        break;
      case "space": insert(" "); break;
      case "dotcom": insert(".de"); break;
      case "back": backspace(); break;
      case "shift": shift = (shift + 1) % 3; break;
      case "mode": layout = layout === "abc" ? "sym" : "abc"; break;
      case "next": nextField(); return;
      case "enter": submit(); return;
      case "close": hide(); return;
    }
    if (open) draw();
  }

  function move(dx, dy) {
    const rows = LAYOUTS[layout];
    if (dx) {
      const len = rows[row].length;
      col = (col + dx + len) % len;
    } else {
      // in der Nachbarzeile die Taste mit der nächsten horizontalen Position nehmen
      const cur = root.querySelector(`.k[data-r="${row}"][data-c="${col}"]`);
      const x = cur ? cur.getBoundingClientRect().left + cur.getBoundingClientRect().width / 2 : 0;
      const nr = (row + dy + rows.length) % rows.length;
      let best = 0, bestD = Infinity;
      root.querySelectorAll(`.k[data-r="${nr}"]`).forEach(k => {
        const r = k.getBoundingClientRect();
        const d = Math.abs(r.left + r.width / 2 - x);
        if (d < bestD) { bestD = d; best = +k.dataset.c; }
      });
      row = nr; col = best;
    }
    draw();
  }

  // ---------------------------------------------------------------- Ereignisse
  function swallow(e) {
    swallowed.add(e.key);
    e.preventDefault();
    e.stopImmediatePropagation();
  }

  window.addEventListener("keydown", e => {
    if (!open) {
      // OK auf einem Textfeld öffnet die Tastatur wieder
      if (e.key === "Enter" && !physicalKeyboard && isEditable(deepActive()) &&
          !(deepActive().value || "").length) {
        show(deepActive());
        swallow(e);
      }
      return;
    }
    if (/^[a-zA-ZäöüÄÖÜ]$/.test(e.key) && !e.ctrlKey && !e.altKey) {
      // echte Tastatur erkannt -> Bildschirmtastatur nicht mehr anzeigen
      physicalKeyboard = true;
      hide();
      return;
    }
    switch (e.key) {
      case "ArrowLeft": move(-1, 0); break;
      case "ArrowRight": move(1, 0); break;
      case "ArrowUp": move(0, -1); break;
      case "ArrowDown": move(0, 1); break;
      case "Enter": press(); break;
      case "Escape": case "BrowserBack": case "GoBack": hide(); break;
      default: return; // Ziffern, Rücktaste usw. normal durchlassen
    }
    swallow(e);
  }, true);

  window.addEventListener("keyup", e => {
    if (swallowed.has(e.key)) {
      swallowed.delete(e.key);
      e.preventDefault();
      e.stopImmediatePropagation();
    }
  }, true);

  document.addEventListener("focusin", e => {
    const el = (e.composedPath && e.composedPath()[0]) || e.target;
    if (isEditable(el)) show(el);
  }, true);

  document.addEventListener("focusout", () => {
    setTimeout(() => {
      if (!isEditable(deepActive())) hide();
      else if (open && deepActive() !== target) target = deepActive();
    }, 60);
  }, true);
})();
