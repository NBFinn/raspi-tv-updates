/* Raspi-TV: Spotify (open.spotify.com) mit der Fernbedienung bedienen
 *   Pfeiltasten springen zum nächsten Element in der Richtung, OK wählt aus,
 *   CH + / CH – = nächster / vorheriger Titel, ▶❚❚ (Leertaste) = Pause.
 *   Zurück schließt die Ansicht, Home zeigt die Startseite – Spotify spielt weiter.
 */
(() => {
  "use strict";
  if (window.top !== window || window.__raspiSpotNav) return;
  window.__raspiSpotNav = true;

  const SEL = 'a[href], button:not([disabled]), [role="button"], [role="link"], [role="row"], [role="tab"], input, [tabindex="0"]';
  const style = document.createElement("style");
  style.textContent = `
    .rtv-focus { outline: 3px solid #1ed760 !important; outline-offset: 2px !important; border-radius: 6px;
      box-shadow: 0 0 0 6px rgba(30,215,96,.25) !important; }
    [role="row"].rtv-focus { outline-offset: -3px !important; }`;
  (document.head || document.documentElement).appendChild(style);

  let cur = null;
  function visible(el) {
    const r = el.getBoundingClientRect();
    if (r.width < 6 || r.height < 6 || r.bottom < 0 || r.top > innerHeight || r.right < 0 || r.left > innerWidth) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== "hidden" && cs.display !== "none" && cs.opacity !== "0" && !el.closest('[aria-hidden="true"], [inert]');
  }
  function candidates() { return [...document.querySelectorAll(SEL)].filter(visible); }
  function mark(el) {
    if (cur && cur !== el) cur.classList.remove("rtv-focus");
    cur = el;
    if (!el) return;
    el.classList.add("rtv-focus");
    try { el.focus({ preventScroll: true }); } catch (_) {}
    el.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "smooth" });
  }
  function scrollerOf(el) {
    for (let p = el && el.parentElement; p; p = p.parentElement) {
      const cs = getComputedStyle(p);
      if (/(auto|scroll)/.test(cs.overflowY) && p.scrollHeight > p.clientHeight + 10) return p;
    }
    return document.querySelector(".main-view-container__scroll-node, [data-overlayscrollbars-viewport]") || document.scrollingElement;
  }

  function move(dir) {
    if (!cur || !document.contains(cur) || !visible(cur)) {
      const list = candidates();
      const main = list.find(el => el.closest("main, [role=main]")) || list[0];
      return mark(main || null);
    }
    const r = cur.getBoundingClientRect();
    const cx = (r.left + r.right) / 2, cy = (r.top + r.bottom) / 2;
    let best = null, bestScore = Infinity;
    for (const el of candidates()) {
      if (el === cur || el.contains(cur) || cur.contains(el)) continue;
      const e = el.getBoundingClientRect();
      const ex = (e.left + e.right) / 2, ey = (e.top + e.bottom) / 2;
      let ok, main, side;
      // seitlicher Abstand = Lücke zwischen den Rändern (0, wenn sie sich überlappen) – so trifft
      // „runter“ auch breite Titelzeilen unter einem kleinen Knopf
      const gapX = Math.max(0, e.left - r.right, r.left - e.right), gapY = Math.max(0, e.top - r.bottom, r.top - e.bottom);
      if (dir === "right") { ok = e.left >= r.right - 4 || ex > r.right; main = Math.max(0, e.left - r.right) + 1; side = gapY; }
      else if (dir === "left") { ok = e.right <= r.left + 4 || ex < r.left; main = Math.max(0, r.left - e.right) + 1; side = gapY; }
      else if (dir === "down") { ok = e.top >= r.bottom - 4 || ey > r.bottom; main = Math.max(0, e.top - r.bottom) + 1; side = gapX; }
      else { ok = e.bottom <= r.top + 4 || ey < r.top; main = Math.max(0, r.top - e.bottom) + 1; side = gapX; }
      if (!ok || main <= 0) continue;
      const score = main + side * 3 + Math.abs((dir === "up" || dir === "down") ? ex - cx : ey - cy) * 0.05;
      if (score < bestScore) { bestScore = score; best = el; }
    }
    if (best) return mark(best);
    // nichts mehr in der Richtung sichtbar: Liste weiterscrollen, dann erneut suchen
    if (dir === "down" || dir === "up") {
      const sc = scrollerOf(cur);
      if (sc) { sc.scrollBy({ top: (dir === "down" ? 1 : -1) * innerHeight * 0.5, behavior: "smooth" }); setTimeout(() => move(dir), 350); }
    }
  }

  function clickControl(id) {
    const b = document.querySelector(`[data-testid="${id}"]`);
    if (b) b.click();
  }

  window.addEventListener("keydown", e => {
    const a = document.activeElement;
    const typing = a && (a.tagName === "INPUT" || a.tagName === "TEXTAREA" || a.isContentEditable);
    const dirs = { ArrowUp: "up", ArrowDown: "down", ArrowLeft: "left", ArrowRight: "right" };
    if (dirs[e.key]) {
      if (typing && (e.key === "ArrowLeft" || e.key === "ArrowRight")) return;   // Cursor im Suchfeld
      if (typing) cur = a;
      e.preventDefault(); e.stopPropagation();
      move(dirs[e.key]);
      return;
    }
    if (e.key === "PageDown" && !typing) { e.preventDefault(); e.stopPropagation(); clickControl("control-button-skip-forward"); return; }
    if (e.key === "PageUp" && !typing) { e.preventDefault(); e.stopPropagation(); clickControl("control-button-skip-back"); return; }
    if (e.key === "Enter" && cur && document.contains(cur) && !typing) {
      // Titelzeilen spielen bei Spotify per Doppelklick ab
      if (cur.getAttribute("role") === "row") {
        e.preventDefault(); e.stopPropagation();
        cur.dispatchEvent(new MouseEvent("dblclick", { bubbles: true, cancelable: true, view: window }));
        return;
      }
      if (!/^(A|BUTTON|INPUT)$/.test(cur.tagName)) { e.preventDefault(); e.stopPropagation(); cur.click(); }
    }
  }, true);

  // Klick mit der Maus / dem Handy-Touchpad: Markierung folgt
  document.addEventListener("focusin", e => { const el = e.target.closest && e.target.closest(SEL); if (el && el !== cur) mark(el); }, true);
})();
