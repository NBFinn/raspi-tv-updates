#!/bin/bash -e
# Läuft im Image (chroot): Browser + DRM-Modul installieren

CHROMIUM_PKG="chromium"
if apt-cache policy chromium-browser 2>/dev/null | grep -q 'Candidate: [0-9]'; then
	CHROMIUM_PKG="chromium-browser"
fi

# Browser und Widevine (DRM) in einem Schritt – ohne Widevine geht kein Netflix/Prime/Spotify,
# fehlt es, soll der Build abbrechen.
apt-get install -y "$CHROMIUM_PKG" libwidevinecdm0

apt-get clean
