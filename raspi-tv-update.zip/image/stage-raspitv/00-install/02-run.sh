#!/bin/bash -e
# Läuft auf dem Build-Rechner: Raspi-TV-Dateien ins Image kopieren
F=../files
R="${ROOTFS_DIR}"
D="$R/opt/raspi-tv"

# Programmdateien (gleiche Logik wie beim Software-Update per USB-Stick)
bash "$F/system/install-files.sh" "$F" "$R"

# WLAN-Vorlage auf die Boot-Partition (am PC als Laufwerk "bootfs" sichtbar)
install -m 644 "$F/system/raspi-tv-wlan.txt" "$R/boot/firmware/raspi-tv-wlan.txt"

# Pi 5: Widevine läuft nur mit dem 4K-Page-Kernel
if ! grep -q 'Raspi-TV' "$R/boot/firmware/config.txt"; then
	printf '\n[pi5]\n# Raspi-TV: Widevine (Netflix/Prime) braucht 4K-Pages\nkernel=kernel8.img\n\n[all]\n' \
		>>"$R/boot/firmware/config.txt"
fi
