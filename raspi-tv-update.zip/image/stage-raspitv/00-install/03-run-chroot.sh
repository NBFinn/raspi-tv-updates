#!/bin/bash -e
# Läuft im Image (chroot): TV-Benutzer, Autostart, Dienste

TV_USER=tv

if ! id "$TV_USER" &>/dev/null; then
	adduser --disabled-password --gecos "Raspi-TV" "$TV_USER"
fi
# Der Benutzer wird erst nach install-files angelegt: Cache-Eigentuemer jetzt setzen.
chown --no-dereference "$TV_USER:$TV_USER" /opt/raspi-tv/extension/_metadata
for g in video audio input render bluetooth; do
	getent group "$g" >/dev/null && usermod -aG "$g" "$TV_USER"
done

install -m 644 -o "$TV_USER" -g "$TV_USER" /opt/raspi-tv/user/xinitrc     "/home/$TV_USER/.xinitrc"
install -m 644 -o "$TV_USER" -g "$TV_USER" /opt/raspi-tv/user/xbindkeysrc "/home/$TV_USER/.xbindkeysrc"
touch "/home/$TV_USER/.hushlogin"
chown "$TV_USER:$TV_USER" "/home/$TV_USER/.hushlogin"

install -m 644 -o "$TV_USER" -g "$TV_USER" /opt/raspi-tv/user/bash_profile "/home/$TV_USER/.bash_profile"
chown "$TV_USER:$TV_USER" "/home/$TV_USER/.bash_profile"

# Automatische, stille Anmeldung des TV-Benutzers auf dem Bildschirm
install -d /etc/systemd/system/getty@tty1.service.d
cat >/etc/systemd/system/getty@tty1.service.d/autologin.conf <<EOF
[Service]
ExecStart=
ExecStart=-/sbin/agetty --autologin $TV_USER --noclear --noissue %I \$TERM
EOF

install -d -m 755 /var/lib/raspi-tv
install -d -m 755 /media/raspi-tv /var/cache/raspi-tv/thumbs
install -d -m 755 -o "$TV_USER" -g "$TV_USER" /var/log/raspi-tv

systemctl enable raspi-tv-recovery.service raspi-tv-ctl.service raspi-tv-cec.service raspi-tv-wlan.service raspi-tv-btagent.service raspi-tv-update-check.service raspi-tv-teensy-watch.service raspi-tv-reboot-wake.service
# AirPlay läuft nur auf Wunsch (Einstellungen → Ton), gestartet vom Raspi-TV-Dienst
systemctl disable shairport-sync.service 2>/dev/null || true
systemctl set-default multi-user.target
