#!/bin/bash -e
# Läuft auf dem Build-Rechner: Bootscreen-Theme kopieren, stillen Start einstellen
F=../files
R="${ROOTFS_DIR}"
T="$R/usr/share/plymouth/themes/raspitv"

install -d "$T"
install -m 644 "$F"/branding/plymouth/* "$T/"

# Kein Regenbogen-Bild der Firmware
CFG="$R/boot/firmware/config.txt"
grep -q '^disable_splash=1' "$CFG" || printf '\n[all]\ndisable_splash=1\n' >>"$CFG"

# Kernel: Meldungen auf tty3 statt auf den Fernseher, Bootscreen an, kein Cursor
CMD="$R/boot/firmware/cmdline.txt"
sed -i 's/console=tty1/console=tty3/' "$CMD"
for opt in quiet splash loglevel=3 logo.nologo vt.global_cursor_default=0 plymouth.ignore-serial-consoles; do
	grep -qw -- "$opt" "$CMD" || sed -i "1 s/\$/ $opt/" "$CMD"
done
