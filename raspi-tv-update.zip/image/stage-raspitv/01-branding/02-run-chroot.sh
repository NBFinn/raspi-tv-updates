#!/bin/bash -e
# Läuft im Image (chroot): Bootscreen aktivieren
plymouth-set-default-theme raspitv
# Bootscreen auch ins initramfs, damit er sofort beim Start erscheint
update-initramfs -u -k all || echo "Hinweis: initramfs konnte nicht aktualisiert werden – Bootscreen erscheint etwas später."
# merken, welche Startanimation im Startsystem steckt (Updates bauen es nur bei Änderungen neu)
install -d /var/lib/raspi-tv
cat /usr/share/plymouth/themes/raspitv/* | md5sum | cut -d' ' -f1 >/var/lib/raspi-tv/.plymouth-installed || true
