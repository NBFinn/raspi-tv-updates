/* Animated ambient scenes: decorative only, no playback/navigation side effects. */
"use strict";
const AMBIENT_STYLES = [["aurora", "Polarlicht"], ["stars", "Sternenflug"], ["lava", "Lavalampe"], ["spectrum", "Musikvisualisierung"]];
SAVER_STYLES.push(...AMBIENT_STYLES);
function ambientParticles(style) {
  if (style === "spectrum") return '<canvas class="spectrum-canvas"></canvas><span class="spectrum-status">Verbinde mit Audio-Ausgang …</span>';
  return style === "stars" ? Array.from({length: 36}, (_, i) => `<i style="--x:${(i * 37) % 100}%;--y:${(i * 23) % 100}%;--delay:-${i % 12}s;--speed:${8 + i % 9}s"></i>`).join("") : '<i></i><i></i><i></i><i></i>';
}
const ambientPreviousShow = Saver.show;
Saver.show = function () {
  const style = state.config.saver_style || "classic";
  return AMBIENT_STYLES.some(s => s[0] === style) ? this.showAmbient(style) : ambientPreviousShow.call(this);
};
Saver.showAmbient = function (style) {
  if (this.el) return;
  style = style || (AMBIENT_STYLES.some(s => s[0] === state.config.saver_style) ? state.config.saver_style : "aurora");
  if (!AMBIENT_STYLES.some(s => s[0] === style)) style = "aurora";
  const el = document.createElement("div");
  el.className = "saver ambient ambient-" + style;
  if (state.config.motion === "off" || state.config.motion === "reduced") el.classList.add("ambient-still");
  el.dataset.scene = style;
  const particles = ambientParticles(style);
  el.innerHTML = `<div class="ambient-scene" aria-hidden="true">${particles}</div>
    <div class="ambient-clock"><b id="ambient-time"></b><span id="ambient-date"></span></div>
    <div class="ambient-track"><span class="ambient-cover">${ICON.music}</span><div><small id="ambient-source">Musikansicht</small><h1 id="ambient-title">Zeit zum Abschalten</h1><p id="ambient-artist">Musik läuft beim Öffnen und Schließen weiter.</p></div></div>
    <div class="saver-hint">◀ ▶ Szene wechseln · ▶❚❚ Pause / Wiedergabe · Andere Taste zurück</div>`;
  document.body.appendChild(el);
  this.el = el;
  const update = () => {
    if (this.el !== el) return;
    const d = new Date();
    el.querySelector("#ambient-time").textContent = d.toLocaleTimeString(I18N.lang === "en" ? "en-GB" : "de-DE", {hour:"2-digit",minute:"2-digit"});
    el.querySelector("#ambient-date").textContent = d.toLocaleDateString(I18N.lang === "en" ? "en-GB" : "de-DE", {weekday:"long",day:"numeric",month:"long"});
    const sp = SpotifyNow.cur;
    const playingSpotify = sp && sp.title && (sp.playing || sp.paused);
    const radio = Radio.current;
    const title = playingSpotify ? sp.title : radio ? radio.name : "Zeit zum Abschalten";
    el.querySelector("#ambient-title").textContent = title;
    el.querySelector("#ambient-artist").textContent = playingSpotify ? sp.artist || "Spotify" : radio ? "Radio" : "Musik läuft beim Öffnen und Schließen weiter.";
    el.querySelector("#ambient-source").textContent = playingSpotify ? "Spotify · " + (sp.playing ? "Wiedergabe" : "Pause") : radio ? "Radio · " + (Radio.audio && Radio.audio.paused ? "Pause" : "Wiedergabe") : "Musikansicht";
    const cover = el.querySelector(".ambient-cover"), url = playingSpotify ? sp.cover || "" : "";
    if (cover.dataset.url !== url) {
      cover.dataset.url = url;
      cover.innerHTML = url ? `<img src="${esc(url)}" alt="Albumcover">` : ICON.music;
    }
  };
  update();
  this.rot = setInterval(update, 1000);
};
// Consume media controls before the generic saver dismissal listener.
document.addEventListener("keydown", e => {
  if (!Saver.el) return;
  if (Saver.el.classList.contains("ambient") && ["ArrowLeft", "ArrowRight"].includes(e.key)) {
    e.preventDefault(); e.stopImmediatePropagation();
    const el = Saver.el;
    const index = AMBIENT_STYLES.findIndex(s => s[0] === el.dataset.scene);
    const next = AMBIENT_STYLES[(index + (e.key === "ArrowRight" ? 1 : AMBIENT_STYLES.length - 1)) % AMBIENT_STYLES.length][0];
    el.classList.remove("ambient-" + el.dataset.scene);
    el.classList.add("ambient-" + next); el.dataset.scene = next;
    el.querySelector(".ambient-scene").innerHTML = ambientParticles(next);
    return;
  }
  if (!(e.key === "MediaPlayPause" || e.key === " ")) return;
  const sp = SpotifyNow.cur;
  if (sp && sp.web && sp.title && (sp.playing || sp.paused)) {
    e.preventDefault(); e.stopImmediatePropagation(); SpotifyNow.control("toggle");
  } else if (Radio.current && Radio.audio) {
    e.preventDefault(); e.stopImmediatePropagation();
    if (Radio.audio.paused) Radio.audio.play().catch(() => {}); else Radio.audio.pause();
  }
}, true);
window.addEventListener("message", e => {
  if (e.source === window && e.origin === location.origin && e.data && e.data.type === "raspi-tv-close-saver") Saver.hide();
});
document.addEventListener("visibilitychange", () => { Saver.idleSince = Date.now(); if (document.hidden && Saver.el) Saver.hide(); });
