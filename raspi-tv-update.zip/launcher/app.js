/* Raspi-TV OS – Oberfläche */
"use strict";

// ======================================================================
// Apps
// ======================================================================
const APPS = [
  // Mediatheken & freie Angebote
  { id: "ard",         cat: "mediathek", name: "ARD Mediathek", kind: "Das Erste & Dritte", url: "https://www.ardmediathek.de/", c1: "#1d4f91", c2: "#0b1d36" },
  { id: "zdf",         cat: "mediathek", name: "ZDF Mediathek", kind: "ZDF, neo, info",     url: "https://www.zdf.de/",          c1: "#e0701c", c2: "#4b2208" },
  { id: "arte",        cat: "mediathek", name: "ARTE",          kind: "Kultur & Doku",      url: "https://www.arte.tv/de/",      c1: "#5a5a5a", c2: "#1a1a1a" },
  { id: "3sat",        cat: "mediathek", name: "3sat",          kind: "Kultur & Wissen",    url: "https://www.3sat.de/",         c1: "#2a6f8f", c2: "#0c2430" },
  { id: "kika",        cat: "mediathek", name: "KiKA",          kind: "Für Kinder",         url: "https://www.kika.de/",         c1: "#3f9a3a", c2: "#123210" },
  { id: "joyn",        cat: "mediathek", name: "Joyn",          kind: "ProSieben, Sat.1 …", url: "https://www.joyn.de/",         c1: "#5a2a8c", c2: "#1a0b2e" },
  { id: "youtube",     cat: "mediathek", name: "YouTube",       kind: "Videos",             url: "https://www.youtube.com/",     c1: "#b3121b", c2: "#3a0508" },
  { id: "twitch",      cat: "mediathek", name: "Twitch",        kind: "Livestreams",        url: "https://www.twitch.tv/",       c1: "#6a3fc4", c2: "#1f1040" },
  // Streamingdienste (Abo)
  { id: "netflix",     cat: "streaming", name: "Netflix",       kind: "Abo · bis 720p",     url: "https://www.netflix.com/browse", c1: "#9b0d14", c2: "#2b0507" },
  { id: "prime",       cat: "streaming", name: "Prime Video",   kind: "Abo · SD/720p",      url: "https://www.primevideo.com/",  c1: "#0f6c9c", c2: "#0a2233" },
  { id: "disney",      cat: "streaming", name: "Disney+",       kind: "Abo · SD/720p",      url: "https://www.disneyplus.com/de-de", c1: "#1b3a8f", c2: "#0a1233" },
  { id: "rtlplus",     cat: "streaming", name: "RTL+",          kind: "Abo · RTL & Co.",    url: "https://plus.rtl.de/",         c1: "#c8102e", c2: "#3a0610" },
  { id: "crunchyroll", cat: "streaming", name: "Crunchyroll",   kind: "Anime",              url: "https://www.crunchyroll.com/de/", c1: "#d8661a", c2: "#4a1d05" },
  { id: "spotify",     cat: "streaming", name: "Spotify",       kind: "Musik · läuft im Hintergrund", url: "https://open.spotify.com/", c1: "#148a45", c2: "#07301a", bg: true },
];

// ======================================================================
// Kleine Helfer
// ======================================================================
const $ = (sel, root = document) => root.querySelector(sel);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const sleep = ms => new Promise(r => setTimeout(r, ms));

const API = {
  async get(path) {
    // Beim Start schon parallel angefragt (index.html) → Antwort sofort nutzen
    const pre = window.__pre && window.__pre[path];
    if (pre && Date.now() - window.__preAt < 4000) {
      delete window.__pre[path];
      const res = await pre.catch(() => null);
      if (res && res.ok) return res.clone().json();
    }
    const r = await fetch(path);
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || "Fehler");
    return j;
  },
  async post(path, body = {}) {
    const r = await fetch(path, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Raspi-TV": "1" },
      body: JSON.stringify(body),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || "Fehler");
    return j;
  },
};

const ICON = {
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  download: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11M7 10.5l5 5 5-5M5 20h14"/></svg>',
  store: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 8h14l-1.2 11.2a2 2 0 0 1-2 1.8H8.2a2 2 0 0 1-2-1.8L5 8z"/><path d="M9 10V6.5a3 3 0 0 1 6 0V10"/></svg>',
  wifi: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M2 8.5a15 15 0 0 1 20 0"/><path d="M5 12a10.5 10.5 0 0 1 14 0"/><path d="M8.5 15.5a5.5 5.5 0 0 1 7 0"/><circle cx="12" cy="19" r="1.2" fill="currentColor"/></svg>',
  wifiOff: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 3l18 18"/><path d="M8.5 15.5a5.5 5.5 0 0 1 7 0"/><path d="M5 12a10.5 10.5 0 0 1 5-2.7"/><path d="M2 8.5A15 15 0 0 1 8 5.3"/><circle cx="12" cy="19" r="1.2" fill="currentColor"/></svg>',
  lan: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="9" y="3" width="6" height="5" rx="1"/><rect x="3" y="16" width="6" height="5" rx="1"/><rect x="15" y="16" width="6" height="5" rx="1"/><path d="M12 8v4M6 16v-4h12v4"/></svg>',
  bt: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 7l10 10-5 4V3l5 4L7 17"/></svg>',
  sound: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"/></svg>',
  apps: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="2"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="2"/></svg>',
  system: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="5" width="14" height="14" rx="2"/><rect x="9" y="9" width="6" height="6" rx="1"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/></svg>',
  gear: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><circle cx="12" cy="12" r="3.2"/><path d="M12 2.5l2 2.6 3.2-.6.9 3.1 3 1.4-1.2 3 1.2 3-3 1.4-.9 3.1-3.2-.6-2 2.6-2-2.6-3.2.6-.9-3.1-3-1.4L4.1 12 2.9 9l3-1.4.9-3.1 3.2.6z"/></svg>',
  lock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>',
  search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l5 5"/></svg>',
  headset: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M4 15v-3a8 8 0 0 1 16 0v3"/><rect x="3" y="14" width="4" height="7" rx="1.5"/><rect x="17" y="14" width="4" height="7" rx="1.5"/></svg>',
  gamepad: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M7 7h10a5 5 0 0 1 4.8 6.4l-1 3.3a2.5 2.5 0 0 1-4.3.9L14 15h-4l-2.5 2.6a2.5 2.5 0 0 1-4.3-.9l-1-3.3A5 5 0 0 1 7 7z"/><path d="M8 10v3M6.5 11.5h3"/><circle cx="16" cy="11" r=".6" fill="currentColor"/><circle cx="17.5" cy="12.8" r=".6" fill="currentColor"/></svg>',
  keyboard: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10"/></svg>',
  device: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="2.5" width="12" height="19" rx="2.5"/><path d="M11 18h2"/></svg>',
  speaker: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="2.5" width="14" height="19" rx="2.5"/><circle cx="12" cy="14" r="3.5"/><circle cx="12" cy="7" r="1" fill="currentColor"/></svg>',
  tv: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="2.5" y="4" width="19" height="13" rx="2"/><path d="M8 21h8"/></svg>',
  update: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5"/></svg>',
  logout: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 17l-5-5 5-5M5 12h11"/></svg>',
  power: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 3v8"/><path d="M6.3 6.8a8 8 0 1 0 11.4 0"/></svg>',
  restart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12a8 8 0 1 0 2.3-5.7M4 4v5h5"/></svg>',
  phone: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="6" y="2.5" width="12" height="19" rx="2.5"/><path d="M11 18h2"/><path d="M9.5 8.5l2.5-2 2.5 2M12 6.5v6"/></svg>',
  live: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="2.5" y="6" width="19" height="13" rx="2"/><path d="M8 2.5l4 3.5 4-3.5"/><circle cx="12" cy="12.5" r="2.2" fill="currentColor"/></svg>',
  mediathek: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M10 7.5l4.5 2.5-4.5 2.5z" fill="currentColor"/><path d="M7 20h10"/></svg>',
  film: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 3v18M17 3v18M3 8h4M3 12h4M3 16h4M17 8h4M17 12h4M17 16h4"/></svg>',
  folder: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M3 6a2 2 0 0 1 2-2h4l2 2.5h8a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>',
  guide: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M8 9v11M3 14.5h18"/></svg>',
  picture: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="2.5" y="4" width="19" height="13" rx="2"/><path d="M8 21h8M12 17v4"/><path d="M6 13l3.5-3.5 3 3 2-2L18 13"/></svg>',
  remote: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="7" y="2.5" width="10" height="19" rx="3"/><circle cx="12" cy="8" r="2"/><path d="M10 13h.01M14 13h.01M10 16h.01M14 16h.01" stroke-linecap="round" stroke-width="2.6"/></svg>',
  list: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M9 6h12M9 12h12M9 18h12"/><path d="M4 6h.01M4 12h.01M4 18h.01" stroke-width="3"/></svg>',
  usb: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="7" y="9" width="10" height="13" rx="2"/><path d="M9 9V3h6v6M11 5.5h.01M13 5.5h.01"/></svg>',
  network: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="3" y="3" width="18" height="7" rx="1.5"/><rect x="3" y="14" width="18" height="7" rx="1.5"/><path d="M7 6.5h.01M7 17.5h.01" stroke-width="3" stroke-linecap="round"/></svg>',
  video: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="2.5" y="5" width="14" height="14" rx="2"/><path d="M16.5 10l5-3v10l-5-3z"/></svg>',
  music: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M9 18V5l11-2v13"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/></svg>',
  photo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-8 9"/></svg>',
  bell: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 21h4"/></svg>',
  plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  up: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M6 15l6-6 6 6"/></svg>',
  down: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>',
  eye: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>',
  warn: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18h.01"/></svg>',
};

function bars(signal) {
  const n = signal >= 75 ? 4 : signal >= 50 ? 3 : signal >= 25 ? 2 : 1;
  return `<span class="bars">${[1, 2, 3, 4].map(i => `<i class="${i <= n ? "on" : ""}"></i>`).join("")}</span>`;
}

function btIcon(icon) {
  if (/audio|headset|headphone/.test(icon)) return ICON.headset;
  if (/speaker/.test(icon)) return ICON.speaker;
  if (/gaming|joystick/.test(icon)) return ICON.gamepad;
  if (/keyboard|mouse|input/.test(icon)) return ICON.keyboard;
  return ICON.device;
}

function fmtBytes(b) {
  if (!b) return "–";
  const gb = b / 1024 ** 3;
  return gb >= 1 ? gb.toFixed(1).replace(".", ",") + " GB" : Math.round(b / 1024 ** 2) + " MB";
}

function fmtUptime(s) {
  const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
  return (d ? d + " T. " : "") + (h ? h + " Std. " : "") + m + " Min.";
}

// ======================================================================
// Toast
// ======================================================================
let toastTimer;
function toast(msg, type = "", ms = 3200) {
  const t = $("#toast");
  t.className = "toast show " + type;
  t.innerHTML = esc(msg);
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("show"), ms);
}

// ======================================================================
// Navigation mit Pfeiltasten (räumlich)
// ======================================================================
const Nav = {
  current: null,
  memory: {},

  scope() {
    const modals = document.querySelectorAll("#modals .modal");
    return modals.length ? modals[modals.length - 1] : document;
  },

  items() {
    return [...this.scope().querySelectorAll(".nav")].filter(el =>
      !el.disabled && el.offsetParent !== null && !el.closest("[hidden]"));
  },

  focus(el, scroll = true) {
    if (!el) return;
    if (this.current && this.current !== el) this.current.classList.remove("focused");
    this.current = el;
    el.classList.add("focused");
    if (el.matches("input, textarea")) el.focus();
    else {
      if (document.activeElement && document.activeElement.matches("input, textarea")) document.activeElement.blur();
      el.focus({ preventScroll: true });
    }
    if (scroll) el.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "smooth" });
    if (this.scope() === document) {
      const key = el.dataset.key;
      if (key) this.memory[location.hash || "#/"] = key;
    }
  },

  restore() {
    const key = this.memory[location.hash || "#/"];
    const items = this.items();
    const el = (key && items.find(i => i.dataset.key === key)) || items[0];
    this.focus(el, false);
  },

  refocus() {
    // nach Neuzeichnen: gleiches Element (über data-key) wieder fokussieren
    const key = this.current && this.current.dataset.key;
    const items = this.items();
    if (this.current && items.includes(this.current)) return;
    const el = (key && items.find(i => i.dataset.key === key)) || items[0];
    this.focus(el, false);
  },

  move(dx, dy) {
    const items = this.items();
    if (!this.current || !items.includes(this.current)) return this.focus(items[0]);
    const a = this.current.getBoundingClientRect();
    const ax = a.left + a.width / 2, ay = a.top + a.height / 2;
    let best = null, bestScore = Infinity;
    for (const el of items) {
      if (el === this.current) continue;
      const b = el.getBoundingClientRect();
      const bx = b.left + b.width / 2, by = b.top + b.height / 2;
      const along = dx ? (bx - ax) * dx : (by - ay) * dy;
      if (along <= 4) continue;
      // Überlappung in Querrichtung bevorzugen
      const overlap = dx
        ? Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top))
        : Math.max(0, Math.min(a.right, b.right) - Math.max(a.left, b.left));
      const across = dx ? Math.abs(by - ay) : Math.abs(bx - ax);
      const score = along + across * (overlap > 0 ? 0.3 : 2.5);
      if (score < bestScore) { bestScore = score; best = el; }
    }
    if (best) this.focus(best);
  },
};

// ======================================================================
// Dialoge
// ======================================================================
function openModal({ title, text = "", html = "", buttons = [], focus, top = false }) {
  const prevFocus = Nav.current;
  const m = document.createElement("div");
  m.className = "modal" + (top ? " top" : "");
  m.innerHTML = `
    <div class="dialog">
      <h3>${esc(title)}</h3>
      ${text ? `<p>${esc(text)}</p>` : ""}
      ${html}
      <div class="buttons">
        ${buttons.map((b, i) => `<button class="btn nav ${b.style || ""}" data-i="${i}">${esc(b.label)}</button>`).join("")}
      </div>
    </div>`;
  const close = () => {
    m.remove();
    if (prevFocus && document.contains(prevFocus)) Nav.focus(prevFocus, false);
    else Nav.restore();
  };
  m.querySelectorAll(".btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const b = buttons[+btn.dataset.i];
      if (b.action) b.action(close, m); else close();
    });
  });
  m._close = close;
  $("#modals").appendChild(m);
  Nav.focus(focus ? m.querySelector(focus) : m.querySelector(".btn"), false);
  return { close, el: m };
}

function confirmDialog(title, text, label, style = "primary") {
  return new Promise(resolve => {
    openModal({
      title, text,
      buttons: [
        { label: "Abbrechen", action: c => { c(); resolve(false); } },
        { label, style, action: c => { c(); resolve(true); } },
      ],
    });
  });
}

function closeTopModal() {
  const ms = document.querySelectorAll("#modals .modal");
  if (!ms.length) return false;
  ms[ms.length - 1]._close();
  return true;
}

function closeAllModals() {
  document.querySelectorAll("#modals .modal").forEach(m => m.remove());
}

// ======================================================================
// Zustand
// ======================================================================
const state = { network: null, config: { hidden: [] } };

async function refreshStatus() {
  try {
    const s = await API.get("/api/status");
    state.network = s.network;
    // Kinder-Modus: Wechsel übernehmen, bei Tageslimit/Schlafenszeit zum Sperrbildschirm
    if (typeof Kids !== "undefined") {
      if (!!s.kids !== Kids.on) { await Kids.load(); if (route() === "home") render(); }
      Kids.st.blocked = s.kids_blocked || "";
      if (s.kids_blocked && route() !== "kidslock" && !Kids.unlockToken()) go("#/kidslock");
    }
  } catch (_) {
    state.network = null;
  }
  renderNet();
  if (route() === "home") updateBanner();
}

function renderNet() {
  const n = state.network, el = $("#net");
  if (!n || !n.online) {
    el.className = "net offline";
    el.innerHTML = ICON.wifiOff + "Offline";
  } else if (n.ethernet) {
    el.className = "net";
    el.innerHTML = ICON.lan + "Kabel";
  } else if (n.wifi && n.wifi.ssid) {
    el.className = "net";
    el.innerHTML = ICON.wifi + esc(n.wifi.ssid);
  } else {
    el.className = "net";
    el.innerHTML = ICON.wifi + "Online";
  }
}

function tick() {
  const d = new Date();
  $("#time").textContent = String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
  $("#date").textContent = d.toLocaleDateString("de-DE", { weekday: "long", day: "numeric", month: "long" });
}


let opening = false;
function openApp(id) {
  const app = findApp(id);
  if (!app || opening) return;
  if (app.native) return NativeRun.launch(app);
  if (!app.custom && !(app.local && app.id !== "spotify") && state.network && !state.network.online) {
    toast("Keine Internetverbindung – bitte zuerst WLAN einrichten.", "error");
    return;
  }
  opening = true;
  const o = document.createElement("div");
  o.className = "overlay splash";
  o.style.setProperty("--c1", app.c1);
  o.style.setProperty("--c2", app.c2);
  o.innerHTML = `<div class="splash-name">${esc(app.name)}</div><div class="spinner"></div>`;
  document.body.appendChild(o);
  if (app.bg) return openBgApp(app, o);
  setTimeout(() => { location.href = app.url; }, 350);
}

// Apps mit eigenem Tab (Spotify): laufen weiter, wenn man zur Startseite oder in andere Apps geht
function openBgApp(app, splash) {
  const requestId = "bg-" + Date.now() + "-" + Math.random().toString(36).slice(2);
  let finished = false, timeout, retry;
  const finish = error => {
    if (finished) return;
    finished = true;
    clearTimeout(timeout);
    clearInterval(retry);
    window.removeEventListener("message", onMsg);
    splash.remove();
    opening = false;
    if (error) toast(error, "error", 8000);
  };
  const onMsg = e => {
    if (e.source !== window || e.origin !== location.origin || !e.data ||
        e.data.type !== "raspi-tv-open-bg-ok" || e.data.requestId !== requestId) return;
    finish(e.data.ok ? "" : "Spotify konnte nicht geöffnet werden. Bitte Raspi-TV neu starten.");
  };
  window.addEventListener("message", onMsg);
  const request = () => window.postMessage({ type: "raspi-tv-open-bg", url: app.url, requestId }, location.origin);
  timeout = setTimeout(() => finish("Die Raspi-TV-Systemerweiterung antwortet nicht. Bitte den Browser unter Notfall-Admin → Wartungswerkzeuge → Startmodus neu starten."), 10000);
  retry = setInterval(request, 500);
  request();
}

window.addEventListener("pageshow", () => {
  opening = false;
  document.querySelectorAll(".overlay").forEach(o => o.remove());
});


// ======================================================================
// Einstellungen – Übersicht
// ======================================================================
function renderSettings(view, token) {
  const n = state.network;
  const netSub = !n || !n.online ? "Nicht verbunden"
    : n.ethernet ? "Über Kabel verbunden"
    : n.wifi && n.wifi.ssid ? "Verbunden mit " + n.wifi.ssid : "Verbunden";
  const cards = [
    { key: "profiles", icon: ICON.remote, title: "Benutzerprofile", sub: "Eigene Sender und eigenes Design" },
    { key: "wifi", icon: ICON.wifi, title: "WLAN", sub: netSub },
    { key: "display", icon: ICON.picture, title: "Bild", sub: "Auflösung & Bildgröße" },
    { key: "round-displays", icon: ICON.system, title: "Runde Displays", sub: "Diagnose, Fehlerbericht & USB-Export" },
    { key: "sound", icon: ICON.sound, title: "Ton", sub: "Ausgabe & Lautstärke" },
    { key: "channels", icon: ICON.list, title: "Sender", sub: "Reihenfolge, ausblenden, eigene Liste" },
    { key: "remote", icon: ICON.remote, title: "Fernbedienung", sub: "TV-Fernbedienung & Handy" },
    { key: "bluetooth", icon: ICON.bt, title: "Bluetooth", sub: "Kopfhörer, Lautsprecher, Controller" },
    { key: "apps", icon: ICON.apps, title: "Apps", sub: "App Store, ein- und ausblenden" },
    { key: "energy", icon: ICON.power, title: "Energie", sub: "Einschalt-Timer, Ausschalten, Bildschirmschoner" },
    { key: "look", icon: ICON.picture, title: "Design & Aufbau", sub: "Farben, Startseite, Animationen" },
    { key: "parental", icon: ICON.lock, title: "Kindersicherung", sub: "PIN, Kinder-Modus, Tageslimit" },
    { key: "notify", icon: ICON.bell, title: "Mitteilungen", sub: "Anrufe auf dem Fernseher" },
    { key: "updates", icon: ICON.update, title: "Updates", sub: "System & Programmdaten" },
    { key: "system", icon: ICON.system, title: "System", sub: "Info, Start, Neustart" },
  ];
  view.innerHTML = `<div class="cards">${cards.map(c => `
    <button class="card nav" data-key="${c.key}" data-go="#/settings/${c.key}">
      ${c.icon}<span class="title">${c.title}</span><span class="sub" id="sub-${c.key}">${esc(c.sub)}</span>
    </button>`).join("")}</div>`;

  if (!state.network) refreshStatus().then(() => {
    if (token !== renderToken || !$("#sub-wifi")) return;
    const m = state.network;
    $("#sub-wifi").textContent = !m || !m.online ? "Nicht verbunden" : m.ethernet ? "Über Kabel verbunden"
      : m.wifi && m.wifi.ssid ? "Verbunden mit " + m.wifi.ssid : "Verbunden";
  });
  API.get("/api/bluetooth").then(bt => {
    if (token !== renderToken) return;
    const con = bt.devices.filter(d => d.connected);
    const paired = bt.devices.filter(d => d.paired);
    $("#sub-bluetooth").textContent = con.length ? "Verbunden: " + con.map(d => d.name).join(", ")
      : paired.length ? paired.length + " Gerät(e) gekoppelt" : "Keine Geräte gekoppelt";
  }).catch(() => {});
  API.get("/api/audio").then(a => {
    if (token !== renderToken) return;
    const out = a.outputs.find(o => o.default);
    $("#sub-sound").textContent = (out ? out.name : "Ausgabe") + (a.volume != null ? " · " + a.volume + " %" : "");
  }).catch(() => {});
  API.get("/api/system").then(s => {
    if (token !== renderToken) return;
    $("#sub-system").textContent = "Version " + s.version;
  }).catch(() => {});
}

// ======================================================================
// WLAN
// ======================================================================
function renderWifi(view, token) {
  view.innerHTML = `
    <div class="page">
      <h1>WLAN</h1>
      <p class="lead">Wähle dein Netzwerk aus. Das Passwort gibst du mit der Bildschirmtastatur ein.</p>
      <div class="list" id="wifi-status"></div>
      <h2>Verfügbare Netzwerke</h2>
      <div class="list">
        <button class="row nav primary" data-key="scan" id="scan">
          <span class="icon">${ICON.search}</span>
          <span class="main"><div class="label">Erneut suchen</div></span>
          <span class="value" id="scan-state"></span>
        </button>
      </div>
      <div class="list" id="wifi-list" style="margin-top:.7vh"></div>
    </div>`;
  $("#scan").addEventListener("click", () => scan());
  renderWifiStatus();
  scan();

  function renderWifiStatus() {
    const n = state.network;
    let html;
    if (n && n.ethernet) {
      html = `<div class="row static"><span class="icon">${ICON.lan}</span><span class="main">
        <div class="label">Über LAN-Kabel verbunden</div><div class="desc">IP-Adresse ${esc(n.ip || "")}</div></span>
        <span class="value"><span class="badge ok">Online</span></span></div>`;
    } else if (n && n.wifi && n.wifi.ssid) {
      html = `<div class="row static"><span class="icon">${ICON.wifi}</span><span class="main">
        <div class="label">Verbunden mit ${esc(n.wifi.ssid)}</div><div class="desc">IP-Adresse ${esc(n.ip || "–")}</div></span>
        <span class="value">${bars(n.wifi.signal || 0)}<span class="badge ok">Online</span></span></div>`;
    } else {
      html = `<div class="row static"><span class="icon">${ICON.wifiOff}</span><span class="main">
        <div class="label">Nicht verbunden</div><div class="desc">Wähle unten ein Netzwerk aus.</div></span></div>`;
    }
    $("#wifi-status").innerHTML = html;
  }

  async function scan() {
    $("#scan-state").innerHTML = '<span class="spinner"></span>Suche …';
    try {
      const { networks } = await API.get("/api/wifi/scan");
      if (token !== renderToken) return;
      const list = $("#wifi-list");
      list.innerHTML = networks.length ? networks.map(n => `
        <button class="row nav" data-key="net-${esc(n.ssid)}" data-ssid="${esc(n.ssid)}">
          <span class="icon">${n.secure ? ICON.lock : ICON.wifi}</span>
          <span class="main"><div class="label">${esc(n.ssid)}</div>
            ${n.saved && !n.connected ? '<div class="desc">Gespeichert</div>' : ""}</span>
          <span class="value">${n.connected ? '<span class="badge ok">Verbunden</span>' : ""}${bars(n.signal)}</span>
        </button>`).join("")
        : `<div class="empty">Keine Netzwerke gefunden. Steht der Router in der Nähe?</div>`;
      list.querySelectorAll("[data-ssid]").forEach(el => {
        const net = networks.find(n => n.ssid === el.dataset.ssid);
        el.addEventListener("click", () => chooseNetwork(net));
      });
      $("#scan-state").textContent = networks.length + " gefunden";
      Nav.refocus();
    } catch (e) {
      if (token !== renderToken) return;
      $("#scan-state").textContent = "";
      toast(e.message, "error");
    }
  }

  function chooseNetwork(net) {
    if (net.connected) {
      openModal({
        title: net.ssid,
        text: "Du bist mit diesem Netzwerk verbunden.",
        buttons: [
          { label: "Abbrechen" },
          { label: "Vergessen", style: "danger", action: async c => {
            c();
            await API.post("/api/wifi/forget", { ssid: net.ssid }).catch(e => toast(e.message, "error"));
            toast("Netzwerk vergessen");
            await refreshStatus(); renderWifiStatus(); scan();
          } },
        ],
      });
    } else if (net.saved || !net.secure) {
      connect(net.ssid, "");
    } else {
      askPassword(net);
    }
  }

  function askPassword(net) {
    const { el } = openModal({
      title: "Mit „" + net.ssid + "“ verbinden",
      top: true,
      html: `<div class="field">
          <input class="nav" id="pw" type="password" placeholder="WLAN-Passwort" autocomplete="off" spellcheck="false" data-key="pw">
          <button class="btn nav" id="pw-show" data-key="pw-show">Anzeigen</button>
        </div>`,
      buttons: [
        { label: "Abbrechen" },
        { label: "Verbinden", style: "primary", action: c => {
          const pw = $("#pw", el).value;
          if (pw.length < 8) { toast("Das Passwort hat mindestens 8 Zeichen.", "error"); return; }
          c(); connect(net.ssid, pw);
        } },
      ],
      focus: "#pw",
    });
    $("#pw-show", el).addEventListener("click", () => {
      const i = $("#pw", el);
      i.type = i.type === "password" ? "text" : "password";
      $("#pw-show", el).textContent = i.type === "password" ? "Anzeigen" : "Verbergen";
    });
    $("#pw", el).addEventListener("keydown", e => {
      if (e.key === "Enter" && !e.defaultPrevented) { e.preventDefault(); el.querySelector(".btn.primary").click(); }
    });
  }

  async function connect(ssid, password) {
    const row = document.querySelector(`[data-ssid="${CSS.escape(ssid)}"]`);
    if (row) { row.classList.add("busy"); row.querySelector(".value").innerHTML = '<span class="spinner"></span>Verbinde …'; }
    try {
      await API.post("/api/wifi/connect", { ssid, password });
      toast("Verbunden mit " + ssid, "ok");
    } catch (e) {
      toast(e.message, "error", 5000);
    }
    await refreshStatus();
    if (token !== renderToken) return;
    renderWifiStatus();
    scan();
  }
}

// ======================================================================
// Bluetooth
// ======================================================================
function renderBluetooth(view, token) {
  view.innerHTML = `
    <div class="page">
      <h1>Bluetooth</h1>
      <p class="lead">Versetze dein Gerät in den Kopplungsmodus (meist eine Taste lange gedrückt halten) und starte dann die Suche.</p>
      <div class="list">
        <button class="row nav primary" data-key="scan" id="bt-scan">
          <span class="icon">${ICON.search}</span>
          <span class="main"><div class="label">Nach Geräten suchen</div></span>
          <span class="value" id="bt-state"></span>
        </button>
      </div>
      <h2>Meine Geräte</h2>
      <div class="list" id="bt-paired"></div>
      <h2>Verfügbare Geräte</h2>
      <div class="list" id="bt-found"></div>
    </div>`;
  let polling = null;

  $("#bt-scan").addEventListener("click", async () => {
    try { draw(await API.post("/api/bluetooth/scan")); } catch (e) { toast(e.message, "error"); }
    startPolling();
  });

  function startPolling() {
    if (polling) return;
    polling = setInterval(async () => {
      if (token !== renderToken) return clearInterval(polling);
      try {
        const d = await API.get("/api/bluetooth");
        draw(d);
        if (!d.scanning) { clearInterval(polling); polling = null; }
      } catch (_) {}
    }, 2000);
    pageTimers.push(polling);
  }

  function row(d) {
    const status = d.connected ? '<span class="badge ok">Verbunden</span>'
      : d.paired ? '<span class="badge">Gekoppelt</span>' : "";
    return `<button class="row nav" data-key="bt-${d.mac}" data-mac="${d.mac}">
      <span class="icon">${btIcon(d.icon)}</span>
      <span class="main"><div class="label">${esc(d.name)}</div></span>
      <span class="value">${status}</span></button>`;
  }

  function draw(data) {
    if (token !== renderToken) return;
    $("#bt-state").innerHTML = data.scanning ? '<span class="spinner"></span>Suche läuft …' : "";
    const paired = data.devices.filter(d => d.paired);
    const found = data.devices.filter(d => !d.paired);
    $("#bt-paired").innerHTML = paired.length ? paired.map(row).join("") : '<div class="empty">Noch keine Geräte gekoppelt.</div>';
    $("#bt-found").innerHTML = found.length ? found.map(row).join("")
      : `<div class="empty">${data.scanning ? "Suche …" : "Keine Geräte gefunden."}</div>`;
    view.querySelectorAll("[data-mac]").forEach(el => {
      const dev = data.devices.find(d => d.mac === el.dataset.mac);
      el.addEventListener("click", () => choose(dev, el));
    });
    Nav.refocus();
  }

  async function act(action, dev, el, busyText, okText) {
    if (el) { el.classList.add("busy"); el.querySelector(".value").innerHTML = `<span class="spinner"></span>${busyText}`; }
    try {
      await API.post("/api/bluetooth/" + action, { mac: dev.mac });
      toast(okText, "ok");
    } catch (e) {
      toast(e.message, "error", 5000);
    }
    try { draw(await API.get("/api/bluetooth")); } catch (_) {}
  }

  function choose(dev, el) {
    if (!dev.paired) return act("pair", dev, el, "Kopple …", dev.name + " gekoppelt");
    openModal({
      title: dev.name,
      text: dev.connected ? "Das Gerät ist verbunden." : "Das Gerät ist gekoppelt, aber nicht verbunden.",
      buttons: [
        { label: "Abbrechen" },
        { label: "Entfernen", style: "danger", action: c => { c(); act("remove", dev, el, "Entferne …", dev.name + " entfernt"); } },
        dev.connected
          ? { label: "Trennen", style: "primary", action: c => { c(); act("disconnect", dev, el, "Trenne …", dev.name + " getrennt"); } }
          : { label: "Verbinden", style: "primary", action: c => { c(); act("connect", dev, el, "Verbinde …", dev.name + " verbunden"); } },
      ],
    });
  }

  API.get("/api/bluetooth").then(d => { draw(d); if (d.scanning) startPolling(); })
    .catch(e => toast(e.message, "error"));
}

// ======================================================================
// Ton
// ======================================================================
function renderSound(view, token) {
  view.innerHTML = `
    <div class="page">
      <h1>Ton</h1>
      <p class="lead">Die Lautstärke des Fernsehers regelst du wie gewohnt mit der TV-Fernbedienung. Hier wählst du, wo der Ton herauskommt.</p>
      <h2>Lautstärke</h2>
      <div class="list">
        <div class="row nav slider" data-key="volume" id="vol" tabindex="-1">
          <span class="icon">${ICON.sound}</span>
          <span class="main"><div class="label">Lautstärke</div><div class="desc">Mit ◀ ▶ ändern</div></span>
          <span class="slider-track"><span class="slider-fill" id="vol-fill"></span><span class="slider-knob" id="vol-knob"></span></span>
          <span class="value" id="vol-val">–</span>
        </div>
      </div>
      <h2>Ausgabe</h2>
      <div class="list" id="outputs"></div>
    </div>`;
  let volume = 0, sendTimer;

  function drawVolume() {
    $("#vol-fill").style.width = volume + "%";
    $("#vol-knob").style.left = volume + "%";
    $("#vol-val").textContent = volume + " %";
  }

  $("#vol")._adjust = delta => {
    volume = Math.max(0, Math.min(100, volume + delta));
    drawVolume();
    clearTimeout(sendTimer);
    sendTimer = setTimeout(() => API.post("/api/audio", { volume }).catch(e => toast(e.message, "error")), 200);
  };

  function draw(a) {
    if (token !== renderToken) return;
    if (a.volume != null) { volume = a.volume; drawVolume(); }
    $("#outputs").innerHTML = a.outputs.length ? a.outputs.map(o => `
      <button class="row nav" data-key="out-${o.id}" data-id="${o.id}">
        <span class="radio ${o.default ? "on" : ""}"></span>
        <span class="icon">${o.bluetooth ? ICON.headset : ICON.tv}</span>
        <span class="main"><div class="label">${esc(o.name)}</div>
          <div class="desc">${o.bluetooth ? "Bluetooth" : "HDMI / eingebaut"}</div></span>
      </button>`).join("")
      : `<div class="empty">Keine Tonausgabe gefunden. Ist der Fernseher eingeschaltet?</div>`;
    view.querySelectorAll("[data-id]").forEach(el => el.addEventListener("click", async () => {
      try { draw(await API.post("/api/audio", { output: +el.dataset.id })); toast("Tonausgabe geändert", "ok"); }
      catch (e) { toast(e.message, "error"); }
    }));
    Nav.refocus();
  }

  API.get("/api/audio").then(draw).catch(e => toast(e.message, "error"));
}

// ======================================================================
// Apps ein-/ausblenden
// ======================================================================
function renderApps(view) {
  view.innerHTML = `
    <div class="page">
      <h1>Apps</h1>
      <p class="lead">Lege fest, welche Apps unter „Mediathek“, „Filme &amp; Serien“ und auf der Startseite erscheinen.</p>
      <div class="list"><button class="row nav primary" data-key="open-store" data-go="#/store"><span class="icon">${ICON.store}</span>
        <span class="main"><div class="label">App Store</div><div class="desc">Über 50 weitere Apps und Programme wie Kodi installieren</div></span></button></div>
      <h2>Vorinstalliert</h2>
      <div class="list" id="app-list"></div>
      <div id="app-extra"></div>
    </div>`;
  function draw() {
    $("#app-list").innerHTML = APPS.map(a => {
      const on = !state.config.hidden.includes(a.id);
      return `<button class="row nav" data-key="toggle-${a.id}" data-id="${a.id}">
        <span class="icon"><span style="width:100%;height:100%;border-radius:.4vw;background:linear-gradient(145deg,${a.c1},${a.c2})"></span></span>
        <span class="main"><div class="label">${esc(a.name)}</div><div class="desc">${esc(a.kind)}</div></span>
        <span class="switch ${on ? "on" : ""}"></span></button>`;
    }).join("");
    $("#app-list").querySelectorAll("[data-id]").forEach(el => el.addEventListener("click", async () => {
      const id = el.dataset.id;
      const hidden = new Set(state.config.hidden);
      hidden.has(id) ? hidden.delete(id) : hidden.add(id);
      if (hidden.size >= APPS.length) { toast("Mindestens eine App muss sichtbar bleiben.", "error"); return; }
      try {
        state.config = await API.post("/api/config", { hidden: [...hidden], startup: state.config.startup || "tv" });
        draw();
      } catch (e) { toast(e.message, "error"); }
    }));
    const extra = allApps().filter(a => !a.builtin && !APPS.includes(a));
    $("#app-extra").innerHTML = extra.length ? `<h2>Aus dem App Store</h2><div class="list">${extra.map(a => `
      <button class="row nav" data-key="x-${esc(a.id)}" data-x="${esc(a.id)}">
        <span class="icon"><span style="width:100%;height:100%;border-radius:.4vw;background:linear-gradient(145deg,${a.c1},${a.c2 || a.c1})"></span></span>
        <span class="main"><div class="label">${esc(a.name)}</div><div class="desc">${esc(a.kind)}</div></span>
        <span class="value">Entfernen</span></button>`).join("")}</div>` : "";
    $("#app-extra").querySelectorAll("[data-x]").forEach(el => el.addEventListener("click", () => removeApp(findApp(el.dataset.x), draw)));
    Nav.refocus();
  }
  Store.refresh().catch(() => {}).then(draw);
}

// ======================================================================
// Handy als Fernbedienung
// ======================================================================
function renderPhone(view, token) {
  view.innerHTML = `
    <div class="phone-page">
      <div class="qr-box"><div class="qr" id="qr"><div class="spinner"></div></div></div>
      <div class="page">
        <h1>Handy als Fernbedienung</h1>
        <p class="lead">Scanne den Code mit der Kamera deines Handys. Dein Handy wird dann zur Fernbedienung –
          mit <b>Touchpad</b> zum Klicken in Netflix &amp; Co. und <b>Tastatur</b> für Logins und Suche.
          Handy und Raspi-TV müssen im selben Netz sein – ohne Heim-WLAN hilft das Fernbedienungs-WLAN unten.</p>
        <div class="steps">
          <div><b>1</b>Kamera-App öffnen und auf den Code richten</div>
          <div><b>2</b>Link antippen – fertig</div>
          <div><b>3</b>Tipp: „Zum Startbildschirm hinzufügen“, dann ist die Fernbedienung immer da</div>
        </div>
        <div class="list" style="margin-top:3vh">
          <div class="row static"><span class="icon">${ICON.wifi}</span><span class="main">
            <div class="label">Ohne Kamera: im Handy-Browser öffnen</div><div class="desc" id="phone-url">–</div></span>
            <span class="value pin-code" id="phone-pin">–</span></div>
          <button class="row nav" data-key="phone-reset" id="phone-reset">
            <span class="icon">${ICON.restart}</span>
            <span class="main"><div class="label">Neuen Code erstellen</div>
              <div class="desc">Bisher gekoppelte Handys funktionieren danach nicht mehr</div></span>
          </button>
        </div>
      </div>
    </div>`;

  function draw(info) {
    if (token !== renderToken) return;
    if (!info.url) {
      $("#qr").innerHTML = '<div class="qr-off">Erst mit dem Internet/WLAN verbinden</div>';
      $("#phone-url").textContent = "nicht verbunden";
      return;
    }
    const qr = qrcode(0, "M");
    qr.addData(info.url);
    qr.make();
    $("#qr").innerHTML = qr.createSvgTag({ cellSize: 8, margin: 2, scalable: true });
    // Kopplungsschlüssel (hinter #) nicht im Klartext anzeigen – stattdessen kurzer Code zum Eintippen
    $("#phone-url").textContent = (info.address || info.url.split("#")[0]) + " → Code eingeben (gilt 15 Minuten)";
    $("#phone-pin").textContent = info.pin ? info.pin.slice(0, 3) + " " + info.pin.slice(3) : "–";
  }

  API.get("/api/remote").then(draw).catch(e => toast(e.message, "error"));
  // Zahlencode gilt nur kurz und nur einmal – Anzeige aktuell halten
  pageTimers.push(setInterval(() => API.get("/api/remote").then(draw).catch(() => {}), 30000));
  $("#phone-reset").addEventListener("click", async () => {
    if (!await confirmDialog("Neuen Code erstellen?", "Alle bisher gekoppelten Handys müssen den neuen Code scannen.", "Neuer Code", "danger")) return;
    try { draw(await API.post("/api/remote/reset")); toast("Neuer Code erstellt", "ok"); }
    catch (e) { toast(e.message, "error"); }
  });
}

// ======================================================================
// System
// ======================================================================
function renderSystem(view, token) {
  view.innerHTML = `
    <div class="page">
      <h1>System</h1>
      <p class="lead">Informationen zu deinem Raspi-TV und Wartung.</p>
      <dl class="info" id="sysinfo"><dt>Lade …</dt><dd></dd></dl>
      <h2>Beim Einschalten</h2>
      <div class="list">
        <button class="row nav" data-key="startup" id="startup">
          <span class="icon">${ICON.tv}</span>
          <span class="main"><div class="label">Direkt Fernsehen starten</div><div class="desc">Wie ein normaler Fernseher: Einschalten und der letzte Sender läuft</div></span>
          <span class="switch ${(state.config.startup || "tv") === "tv" ? "on" : ""}" id="startup-sw"></span>
        </button>
        <button class="row nav" data-key="intro" id="intro-row">
          <span class="icon">${ICON.tv}</span>
          <span class="main"><div class="label">Startanimation</div><div class="desc">Animiertes Raspi-TV-Logo beim Einschalten · jede Taste überspringt sie</div></span>
          <span class="switch ${state.config.intro !== false ? "on" : ""}" id="intro-sw"></span>
        </button>
      </div>
      <h2>Wartung</h2>
      <div class="list">
        <button class="row nav" data-key="resetup" id="resetup">
          <span class="icon">${ICON.restart}</span>
          <span class="main"><div class="label">Ersteinrichtung erneut starten</div><div class="desc">Region, Startverhalten und Handy neu einrichten</div></span>
        </button>
        <button class="row nav" data-key="logout" id="logout">
          <span class="icon">${ICON.logout}</span>
          <span class="main"><div class="label">Bei allen Apps abmelden</div><div class="desc">Löscht Anmeldungen und gespeicherte Daten des Browsers</div></span>
        </button>
        <button class="row nav" data-key="reboot" id="reboot">
          <span class="icon">${ICON.restart}</span>
          <span class="main"><div class="label">Neu starten</div></span>
        </button>
        <button class="row nav danger" data-key="shutdown" id="shutdown">
          <span class="icon">${ICON.power}</span>
          <span class="main"><div class="label">Ausschalten</div></span>
        </button>
      </div>
    </div>`;

  API.get("/api/system").then(s => {
    if (token !== renderToken) return;
    const rows = [
      ["Version", "Raspi-TV OS " + s.version + (s.build ? " (" + s.build + ")" : "")],
      ["Gerät", s.model],
      ["Name im Netzwerk", s.hostname],
      ["IP-Adresse", s.ip || "nicht verbunden"],
      ["Temperatur", s.temp != null ? s.temp.toFixed(1).replace(".", ",") + " °C" : "–"],
      ["Arbeitsspeicher frei", fmtBytes(s.mem_free) + " von " + fmtBytes(s.mem_total)],
      ["Speicher frei", fmtBytes(s.disk_free) + " von " + fmtBytes(s.disk_total)],
      ["Läuft seit", fmtUptime(s.uptime)],
    ];
    $("#sysinfo").innerHTML = rows.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join("");
  }).catch(e => toast(e.message, "error"));


  $("#startup").addEventListener("click", async () => {
    const next = (state.config.startup || "tv") === "tv" ? "home" : "tv";
    try {
      state.config = await API.post("/api/config", { hidden: state.config.hidden, startup: next });
      $("#startup-sw").classList.toggle("on", next === "tv");
      toast(next === "tv" ? "Startet ab jetzt direkt mit Fernsehen" : "Startet ab jetzt mit der Startseite", "ok");
    } catch (e) { toast(e.message, "error"); }
  });


  $("#intro-row").addEventListener("click", async () => {
    const next = state.config.intro === false;
    try {
      state.config = await API.post("/api/config", { intro: next });
      $("#intro-sw").classList.toggle("on", next);
      toast(next ? "Startanimation eingeschaltet" : "Startanimation ausgeschaltet", "ok");
    } catch (e) { toast(e.message, "error"); }
  });

  $("#resetup").addEventListener("click", () => {
    try { sessionStorage.setItem("setup.step", "welcome"); } catch (_) {}
    go("#/setup");
  });
  $("#logout").addEventListener("click", async () => {
    if (!await confirmDialog("Bei allen Apps abmelden?", "Du musst dich danach bei Netflix, Prime Video & Co. neu anmelden.", "Abmelden", "danger")) return;
    showOverlay("Daten werden gelöscht …");
    API.post("/api/reset-browser").catch(() => {});
  });
  $("#reboot").addEventListener("click", async () => {
    if (!await confirmDialog("Neu starten?", "Raspi-TV startet in etwa einer Minute neu.", "Neu starten")) return;
    showOverlay("Raspi-TV startet neu …");
    API.post("/api/reboot").catch(() => {});
  });
  $("#shutdown").addEventListener("click", async () => {
    if (!await confirmDialog("Ausschalten?", "Warte nach dem Ausschalten ca. 10 Sekunden, bevor du den Stecker ziehst.", "Ausschalten", "danger")) return;
    showOverlay("Raspi-TV wird ausgeschaltet …");
    API.post("/api/shutdown").catch(() => {});
  });
}

function showOverlay(text) {
  const o = document.createElement("div");
  o.className = "overlay";
  o.innerHTML = `<div class="spinner"></div><div>${esc(text)}</div>`;
  document.body.appendChild(o);
}
