/* Raspi-TV OS – Einstellungen · Fernbedienung · Aussehen der Handy-App.
 * Farben und Aufbau der Handy-Fernbedienung (Webseite und Raspi-TV-App). Das Handy holt sich die
 * Einstellung bei jeder Verbindung (WLAN oder Bluetooth) und speichert sie. */
"use strict";

const APPLOOK = {
  THEMES: [{ id: "tv", name: "Wie der Fernseher", sub: "Folgt Design & Aufbau" }]
    .concat(Look.THEMES.filter(t => t.id !== "auto").map(t => ({ id: t.id, name: t.name, sub: t.sub, c: t.c }))),
  ACCENTS: [{ id: "tv", name: "Wie der Fernseher", c: "conic-gradient(#3d8bff, #22d3ee, #34d399, #fbbf24, #fb923c, #f87171, #f472b6, #a78bfa, #3d8bff)" }]
    .concat(Look.ACCENTS.filter(a => a.id !== "theme")),
  LAYOUTS: [
    { id: "classic", name: "Klassisch", sub: "Steuerkreuz, Wippen, alle Tasten" },
    { id: "big", name: "Große Tasten", sub: "Weniger Knöpfe, leicht zu treffen" },
    { id: "swipe", name: "Wischfläche", sub: "Wischen statt Steuerkreuz" },
    { id: "top", name: "Wippen oben", sub: "Lautstärke und Sender zuerst" },
  ],
  HAND: [["right", "Lautstärke links"], ["left", "Lautstärke rechts"]],
  CORNERS: [["tv", "Wie der Fernseher"], ["round", "Rund"], ["soft", "Sehr rund"], ["square", "Eckig"]],
  TABS: [["gamepad", "Reiter „Gamepad“", "Handy als Spiele-Controller"], ["channels", "Reiter „Sender“", "Senderliste mit Jetzt & Danach"], ["touch", "Reiter „Maus“", "Touchpad für Webseiten und Apps"],
         ["keys", "Reiter „Tastatur“", "Text eingeben, z. B. Passwörter"], ["search", "Reiter „Suchen“", "Sprachsuche im TV-Programm und in Apps"]],
  DEFAULT: { theme: "tv", accent: "tv", layout: "classic", hand: "right", corners: "tv", nowbar: true,
             tabs: { gamepad: true, channels: true, touch: true, keys: true, search: true } },
};

function renderAppLook(view, token) {
  const check = '<span class="on"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span>';
  const cur = () => {
    const s = (state.config && state.config.app_look) || {};
    return Object.assign({}, APPLOOK.DEFAULT, s, { tabs: Object.assign({}, APPLOOK.DEFAULT.tabs, s.tabs || {}) });
  };
  const label = (list, v) => (list.find(o => o[0] === v) || list[0])[1];

  function swatch(t) {
    if (!t.c) return `<span class="sw" style="background:linear-gradient(135deg, var(--bg) 50%, var(--panel) 50%)"><i class="a" style="background:var(--accent)"></i>
      <span class="r"><i style="background:var(--panel-2)"></i><i style="background:var(--panel)"></i><i style="background:var(--panel-2)"></i></span></span>`;
    const [bg, panel, p2, acc] = t.c;
    return `<span class="sw" style="background:${bg}"><i class="a" style="background:${acc}"></i>
      <span class="r"><i style="background:${panel}"></i><i style="background:${p2}"></i><i style="background:${panel}"></i></span></span>`;
  }
  // kleine Handy-Skizze je Aufbau
  function phone(id) {
    const pad = id === "swipe" ? '<i class="sq"></i>' : '<i class="cr"></i>';
    const row = id === "big" ? '<span class="r"><i></i><i></i><i></i></span>' : '<span class="r"><i></i><i></i><i></i><i></i></span>';
    const rock = id === "big" ? '<span class="r tall"><i></i><i></i></span>' : '<span class="r tall"><i></i><i class="m"></i><i></i></span>';
    const body = id === "top" ? rock + row + pad : pad + row + rock;
    return `<span class="pwf"><span class="scr"><i class="nb"></i>${body}<span class="r tb"><i></i><i></i><i></i><i></i></span></span></span>`;
  }

  view.innerHTML = `
    <div class="page wide">
      <h1>Aussehen der Handy-App</h1>
      <p class="lead">Farben und Aufbau der Handy-Fernbedienung – für die Raspi-TV-App und die Fernbedienung im Browser.
        Das Handy übernimmt die Einstellung in wenigen Sekunden und merkt sie sich.</p>
      <div class="al-split">
        <div class="al-main">
          <h2>Farbschema</h2>
          <div class="look-strip" id="al-themes">${APPLOOK.THEMES.map(t => `
            <button class="look-card nav" data-key="al-t-${t.id}" data-th="${t.id}">${check}${swatch(t)}
              <span class="name">${esc(t.name)}</span><span class="sub">${esc(t.sub)}</span></button>`).join("")}</div>
          <h2>Akzentfarbe</h2>
          <div class="look-strip" id="al-accents">${APPLOOK.ACCENTS.map(a => `
            <button class="look-card dot-card nav" data-key="al-a-${a.id}" data-ac="${a.id}">${check}
              <span class="dot" style="background:${a.c}"></span><span class="name">${esc(a.name)}</span></button>`).join("")}</div>
          <h2>Aufbau</h2>
          <div class="look-strip" id="al-layouts">${APPLOOK.LAYOUTS.map(l => `
            <button class="look-card nav" data-key="al-l-${l.id}" data-lay="${l.id}">${check}${phone(l.id)}
              <span class="name">${esc(l.name)}</span><span class="sub">${esc(l.sub)}</span></button>`).join("")}</div>
          <h2>Feinheiten</h2>
          <div class="list" id="al-more"></div>
          <h2>Reiter unten</h2>
          <div class="list" id="al-tabs"></div>
        </div>
        <div class="al-side">
          <div class="al-phone" id="al-phone"><iframe id="al-frame" src="/remote.html?preview" tabindex="-1" title="Vorschau"></iframe></div>
          <p class="desc">Vorschau</p>
        </div>
      </div>
    </div>`;

  const frame = $("#al-frame");
  function scaleFrame() {
    const box = $("#al-phone");
    if (!box) return;
    const s = box.clientWidth / 360;
    frame.style.transform = `scale(${s})`;
    box.style.height = Math.round(740 * s) + "px";
  }
  function preview(tab) {
    if (!frame.contentWindow) return;
    const c = cur();
    // so auflösen wie der Pi es für das Handy tut („Wie der Fernseher“ → aktuelles Design)
    API.get("/api/applook").then(r => {
      frame.contentWindow.postMessage({ raspiLook: r.look, lang: I18N.lang, tab: tab || null }, "*");
    }).catch(() => {});
    return c;
  }
  window.addEventListener("message", function onReady(e) {
    if (token !== renderToken) { window.removeEventListener("message", onReady); return; }
    if (e.data && e.data.raspiPreviewReady) preview();
  });
  scaleFrame();
  window.addEventListener("resize", scaleFrame);

  async function save(patch, tab) {
    const prev = state.config;
    const next = Object.assign(cur(), patch);
    state.config = Object.assign({}, state.config, { app_look: next });
    mark();
    try { state.config = await API.post("/api/config", { app_look: next }); preview(tab); }
    catch (e) { state.config = prev; mark(); toast(e.message, "error"); }
  }
  function cycle(list, v) { const i = list.findIndex(o => o[0] === v); return list[(i + 1) % list.length][0]; }

  function mark() {
    const c = cur();
    view.querySelectorAll("[data-th]").forEach(b => b.classList.toggle("selected", b.dataset.th === c.theme));
    view.querySelectorAll("[data-ac]").forEach(b => b.classList.toggle("selected", b.dataset.ac === c.accent));
    view.querySelectorAll("[data-lay]").forEach(b => b.classList.toggle("selected", b.dataset.lay === c.layout));
    drawRows();
  }

  function drawRows() {
    const c = cur();
    const focusKey = Nav.current && Nav.current.dataset.key;
    $("#al-more").innerHTML = `
      ${toggleRow("al-nowbar", ICON.tv, "„Jetzt läuft“ oben", "Sender, Sendung und Fortschritt über dem Steuerkreuz", c.nowbar)}
      ${valueRow("al-hand", ICON.remote, "Wippen", "Für Links- oder Rechtshänder", label(APPLOOK.HAND, c.hand))}
      ${valueRow("al-corners", ICON.apps, "Ecken", "Form der Tasten", label(APPLOOK.CORNERS, c.corners))}
      ${valueRow("al-reset", ICON.restart, "Auf Standard zurücksetzen", "Wie der Fernseher · Klassisch · alle Reiter", "")}`;
    $("#al-tabs").innerHTML = APPLOOK.TABS.map(([id, name, desc]) => toggleRow("al-tab-" + id, ICON.list, name, desc, c.tabs[id])).join("");
    $("#al-nowbar").addEventListener("click", () => save({ nowbar: !cur().nowbar }));
    $("#al-hand").addEventListener("click", () => save({ hand: cycle(APPLOOK.HAND, cur().hand) }));
    $("#al-corners").addEventListener("click", () => save({ corners: cycle(APPLOOK.CORNERS, cur().corners) }));
    $("#al-reset").addEventListener("click", () => save(JSON.parse(JSON.stringify(APPLOOK.DEFAULT))));
    APPLOOK.TABS.forEach(([id]) => $("#al-tab-" + id).addEventListener("click", () => {
      const tabs = Object.assign({}, cur().tabs);
      tabs[id] = !tabs[id];
      save({ tabs }, tabs[id] ? id : "remote");
    }));
    const again = focusKey && view.querySelector(`[data-key="${focusKey}"]`);
    if (again && (!Nav.current || !document.contains(Nav.current))) Nav.focus(again, false);
  }

  view.querySelectorAll("[data-th]").forEach(b => b.addEventListener("click", () => save({ theme: b.dataset.th })));
  view.querySelectorAll("[data-ac]").forEach(b => b.addEventListener("click", () => save({ accent: b.dataset.ac })));
  view.querySelectorAll("[data-lay]").forEach(b => b.addEventListener("click", () => save({ layout: b.dataset.lay }, "remote")));
  mark();
}

// Verweise aus „Fernbedienung“ und „Handy“
function appLookRow() {
  return `<button class="row nav" data-key="applook" data-go="#/settings/applook"><span class="icon">${ICON.phone}</span>
    <span class="main"><div class="label">Aussehen der Handy-App</div>
    <div class="desc">Farben, Aufbau und Reiter der Handy-Fernbedienung</div></span></button>`;
}
function addAppLookLink(view) {
  const list = view.querySelector(".page .list");
  if (list) list.insertAdjacentHTML("beforeend", appLookRow() + iphoneRow());
}
function addAppLookSection(view) {
  const page = view.querySelector(".page");
  if (page) page.insertAdjacentHTML("beforeend", `<h2>Aussehen &amp; iPhone</h2><div class="list">${appLookRow()}${iphoneRow()}</div>`);
}

// Einstellungen · System: Terminal
function addTerminalRow(view) {
  const page = view.querySelector(".page");
  if (!page) return;
  page.insertAdjacentHTML("beforeend", `<h2>Für Bastler</h2><div class="list">
    <button class="row nav" data-key="terminal" id="sys-term"><span class="icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="4" width="19" height="16" rx="2.5"/><path d="M7 9l3 3-3 3M12.5 15H17"/></svg></span>
      <span class="main"><div class="label">Terminal</div><div class="desc">Kommandozeile auf dem Pi · Benutzer admin, sudo mit Passwort raspitv · tippen mit USB-Tastatur oder Handy</div></span></button></div>`);
  $("#sys-term").addEventListener("click", () => { location.href = "/terminal.html"; });
}

// ======================================================================
// Einstellungen · Fernbedienung · iPhone (Apple-TV-Fernbedienung über HomeKit)
// ======================================================================
const ICON_APPLE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="7" y="2.5" width="10" height="19" rx="2.6"/><path d="M11 18.5h2"/><circle cx="12" cy="8" r="1.6"/></svg>';

function renderIphone(view, token) {
  view.innerHTML = `
    <div class="page">
      <h1>iPhone als Fernbedienung</h1>
      <p class="lead">Raspi-TV erscheint in der Apple-TV-Fernbedienung im Kontrollzentrum des iPhones – wie ein Apple TV.
        Dafür meldet sich Raspi-TV über HomeKit als Fernseher an.</p>
      <div class="list" id="hk-main"><div class="row static"><span class="spinner"></span></div></div>
      <div id="hk-body"></div>
    </div>`;
  let st = null, last = "";
  async function load() {
    try {
      const s = await API.get("/api/homekit");
      const j = JSON.stringify(s);
      if (j === last) return;
      last = j; st = s; draw();
    } catch (e) { toast(e.message, "error"); }
  }
  function draw() {
    if (token !== renderToken || !st) return;
    const key = Nav.current && Nav.current.dataset.key;
    const job = st.job && (st.job.running || st.job.error) ? st.job : null;
    $("#hk-main").innerHTML = toggleRow("hk-on", ICON_APPLE, "iPhone-Fernbedienung (HomeKit)",
      st.enabled ? (st.running ? (st.paired ? `Verbunden · ${st.clients} ${st.clients === 1 ? "Gerät" : "Geräte"}` : "Bereit zum Hinzufügen") : job ? "Wird eingerichtet …" : "Startet …")
        : "Aus · beim ersten Einschalten werden ca. 15 MB geladen", st.enabled);
    let body = "";
    if (job) {
      body = job.error ? `<p class="lead" style="color:var(--danger)">${esc(job.error)}</p>`
        : `<h2>Wird eingerichtet</h2><div class="list"><div class="row static"><span class="spinner"></span><span class="main">
           <div class="label">${esc(job.step || "Wird vorbereitet")}</div><div class="desc">${job.percent || 0} %</div></span></div></div>`;
    } else if (st.enabled && st.running && !st.paired && st.uri) {
      const q = qrcode(0, "M"); q.addData(st.uri); q.make();
      body = `<h2>Zur Home-App hinzufügen</h2>
        <div style="display:flex;gap:3vw;align-items:center">
          <div style="flex:none;width:15vw;background:#fff;padding:.7vw;border-radius:1vw">${q.createSvgTag({ cellSize: 8, margin: 2, scalable: true })}</div>
          <div>
            <div style="font-size:3vw;font-weight:800;letter-spacing:.12em">${esc(st.pin)}</div>
            <ol class="lead" style="margin-top:1.5vh;padding-left:1.4vw;line-height:1.7">
              <li>Am iPhone die <b>Home-App</b> öffnen → <b>+</b> → <b>Gerät hinzufügen</b>.</li>
              <li>Diesen QR-Code scannen (oder „Weitere Optionen“ → „Raspi-TV“ → Code eingeben).</li>
              <li>Bei „Nicht zertifiziertes Gerät“ auf <b>Trotzdem hinzufügen</b> tippen.</li>
              <li>Fertig: Kontrollzentrum → Fernbedienung → oben <b>Raspi-TV</b> wählen.</li>
            </ol>
          </div>
        </div>
        <p class="lead" style="margin-top:2vh">Das iPhone muss im selben WLAN sein wie Raspi-TV (Heim-WLAN oder Raspi-TV-WLAN).</p>`;
    } else if (st.enabled && st.running && st.paired) {
      body = `<h2>So bedienst du Raspi-TV</h2>
        <p class="lead">Kontrollzentrum öffnen → <b>Fernbedienung</b> (Symbol mit der Apple-TV-Fernbedienung) → oben <b>Raspi-TV</b> wählen.
          Wischen = Pfeile, Tippen = OK, ‹ = Zurück, ▶❚❚ = Pause, ⓘ = Info, Lautstärketasten am iPhone = Lautstärke.
          Fehlt das Symbol: iPhone-Einstellungen → Kontrollzentrum → „Apple TV Remote“ hinzufügen.</p>
        <p class="lead">Über den Eingang (in der Home-App) springst du direkt zu Startseite, Live-TV, TV-Programm, Radio oder Eigenen Medien.</p>`;
    }
    $("#hk-body").innerHTML = body + (st.enabled && st.installed ? `<h2>Weitere</h2><div class="list">
      ${valueRow("hk-reset", ICON.restart, "Kopplung zurücksetzen", "Neuer Code – das iPhone muss Raspi-TV neu hinzufügen (vorher in der Home-App entfernen)", "")}</div>` : "");
    $("#hk-on").addEventListener("click", async () => {
      try { st = await API.post("/api/homekit", { on: !st.enabled }); last = ""; draw(); } catch (e) { toast(e.message, "error"); }
    });
    const rs = $("#hk-reset");
    if (rs) rs.addEventListener("click", async () => {
      if (!await confirmDialog("Kopplung zurücksetzen?", "Raspi-TV muss danach in der Home-App neu hinzugefügt werden.", "Zurücksetzen", "danger")) return;
      try { st = await API.post("/api/homekit/reset", {}); last = ""; draw(); toast("Kopplung zurückgesetzt"); } catch (e) { toast(e.message, "error"); }
    });
    const again = key && view.querySelector(`[data-key="${key}"]`);
    if (again) Nav.focus(again, false); else Nav.restore();
  }
  load();
  pageTimers.push(setInterval(load, 3000));
}

function iphoneRow() {
  return `<button class="row nav" data-key="iphone" data-go="#/settings/iphone"><span class="icon">${ICON_APPLE}</span>
    <span class="main"><div class="label">iPhone als Fernbedienung</div>
    <div class="desc">Apple-TV-Fernbedienung im Kontrollzentrum (HomeKit)</div></span></button>`;
}
