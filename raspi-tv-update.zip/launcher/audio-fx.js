/* Raspi-TV 7.8: Ton-Verbesserung für Fernsehen und Mediatheken-Player
 *  - Lautstärke angleichen: misst laufend die Lautheit und regelt langsam auf ein festes Ziel
 *    (Musik- und Shoppingsender nicht mehr lauter als ARD), dazu ein Begrenzer gegen Spitzen.
 *  - Dialoge verständlicher: hebt den Stimmenbereich an, nimmt Bässe zurück und verdichtet stärker
 *    (laute Musik und Explosionen werden leiser, Sprache bleibt gleich laut).
 *  Wichtig: Ein <video> lässt sich nur einmal an Web Audio hängen und klingt danach ausschließlich
 *  darüber. Deshalb wird der Klangweg erst gebaut, wenn eine der Funktionen eingeschaltet wird, und
 *  nur für Quellen, deren Ton der Browser hergibt (HLS über hls.js oder Dateien vom Pi selbst). */
"use strict";

const AudioFx = (() => {
  const st = { level: false, dialog: false };
  let ctx = null, n = null, el = null, timer = null, loud = -23;
  const TARGET = -20;          // Ziel-Lautheit (dBFS, RMS nach dem Verdichter)

  function build(video) {
    if (ctx) return true;
    try {
      ctx = new (window.AudioContext || window.webkitAudioContext)();
      const src = ctx.createMediaElementSource(video);
      n = {
        low: ctx.createBiquadFilter(), voice: ctx.createBiquadFilter(), air: ctx.createBiquadFilter(),
        comp: ctx.createDynamicsCompressor(), agc: ctx.createGain(), limit: ctx.createDynamicsCompressor(),
        meter: ctx.createAnalyser(),
      };
      n.low.type = "lowshelf"; n.low.frequency.value = 180;
      n.voice.type = "peaking"; n.voice.frequency.value = 2400; n.voice.Q.value = 0.8;
      n.air.type = "highshelf"; n.air.frequency.value = 9000;
      n.limit.threshold.value = -2; n.limit.knee.value = 0; n.limit.ratio.value = 20;
      n.limit.attack.value = 0.002; n.limit.release.value = 0.1;
      n.meter.fftSize = 2048;
      src.connect(n.low); n.low.connect(n.voice); n.voice.connect(n.air); n.air.connect(n.comp);
      n.comp.connect(n.agc); n.comp.connect(n.meter); n.agc.connect(n.limit); n.limit.connect(ctx.destination);
      el = video;
      if (ctx.state !== "running") ctx.resume().catch(() => {});
      return true;
    } catch (e) {
      console.warn("Ton-Verbesserung nicht möglich:", e);
      ctx = null;
      return false;
    }
  }

  function apply() {
    if (!ctx) return;
    const t = ctx.currentTime;
    const set = (p, v) => p.setTargetAtTime(v, t, 0.15);
    // Stimmen: Bässe −6 dB, Sprache +6 dB, Zischlaute −2 dB
    set(n.low.gain, st.dialog ? -6 : 0);
    set(n.voice.gain, st.dialog ? 6 : 0);
    set(n.air.gain, st.dialog ? -2 : 0);
    // Verdichter: beim Angleichen sanft, für Dialoge kräftiger
    const c = st.dialog ? { th: -32, ra: 5, kn: 12 } : st.level ? { th: -26, ra: 3, kn: 18 } : { th: 0, ra: 1, kn: 0 };
    set(n.comp.threshold, c.th); set(n.comp.ratio, c.ra); set(n.comp.knee, c.kn);
    n.comp.attack.value = 0.01; n.comp.release.value = 0.35;
    if (!st.level && !st.dialog) set(n.agc.gain, 1);
    clearInterval(timer);
    timer = (st.level || st.dialog) ? setInterval(measure, 100) : null;
  }

  // Lautheit messen (nur bei Ton, Pausen und Stille zählen nicht) und Verstärkung langsam nachführen
  const buf = new Float32Array(2048);
  function measure() {
    if (!ctx || el.paused) return;
    n.meter.getFloatTimeDomainData(buf);
    let sum = 0;
    for (let i = 0; i < buf.length; i++) sum += buf[i] * buf[i];
    const db = 10 * Math.log10(sum / buf.length + 1e-12);
    if (db < -55) return;
    loud += (db - loud) * 0.03;                       // ≈ 3 s Mittelung
    const gainDb = st.level ? Math.max(-12, Math.min(12, TARGET - loud)) : (st.dialog ? 3 : 0);
    n.agc.gain.setTargetAtTime(Math.pow(10, gainDb / 20), ctx.currentTime, 1.5);
  }

  return {
    /** Einstellungen setzen ({level, dialog}); baut den Klangweg erst, wenn etwas an ist. */
    set(video, opts) {
      Object.assign(st, opts || {});
      if ((st.level || st.dialog) && !build(video)) return false;
      apply();
      return true;
    },
    state: () => ({ ...st }),
    /** Nach einem Senderwechsel schnell neu einpendeln statt langsam vom alten Pegel aus. */
    reset() { loud = -23; },
  };
})();
