/* Läuft vor allen Launcher-Abhängigkeiten und macht Startfehler sichtbar. */
(function(){
  'use strict';var shown=false;
  if(new URLSearchParams(location.search).get('safe')==='1'){
    document.addEventListener('DOMContentLoaded',function(){
      var banner=document.createElement('div');
      banner.style.cssText='position:fixed;top:0;left:0;right:0;z-index:2147483646;background:#543600;color:#fff;padding:10px;text-align:center;font:18px system-ui';
      banner.textContent='Abgesicherter Start: Browser-Erweiterungen sind deaktiviert. ';
      var link=document.createElement('a');link.href='http://'+location.hostname+':8767/local';link.textContent='Admin-Anmeldung';link.style.color='#fff';banner.appendChild(link);document.body.appendChild(banner);
    });
  }
  function fail(message,file,line){
    var report={message:String(message||'Unbekannter Oberflächenfehler'),file:String(file||'').split('?')[0],line:line||0};
    try{fetch('http://127.0.0.1:8767/report',{method:'POST',headers:{'Content-Type':'text/plain'},body:JSON.stringify(report)}).catch(function(){});}catch(e){}
    if(shown)return;shown=true;
    function display(){
      var box=document.createElement('div');box.style.cssText='position:fixed;inset:5vh 5vw;z-index:2147483647;background:#111b30;color:#fff;padding:4vw;border:2px solid #ff8d9e;border-radius:16px;font:20px/1.6 sans-serif;overflow:auto';
      var h=document.createElement('h2');h.textContent='Die TV-Oberfläche konnte nicht starten.';box.appendChild(h);
      var text=document.createElement('pre');text.style.whiteSpace='pre-wrap';text.textContent=report.message+'\n'+report.file+':'+report.line;box.appendChild(text);
      var a=document.createElement('a');a.href='http://'+location.hostname+':8767/'+((location.hostname==='127.0.0.1'||location.hostname==='localhost')?'local':'');a.textContent='Notfall-Admin öffnen';a.style.cssText='color:#aaccff;display:inline-block;padding:20px;background:#253d66;border-radius:8px';box.appendChild(a);document.body.appendChild(box);a.focus();setTimeout(function(){location.href=a.href;},3000);
    }
    if(document.body)display();else document.addEventListener('DOMContentLoaded',display);
  }
  window.addEventListener('error',function(e){if(e.target&&e.target.tagName==='SCRIPT')fail('Skript konnte nicht geladen werden',e.target.src,0);else if(e.message)fail(e.message,e.filename,e.lineno);},true);
  window.addEventListener('unhandledrejection',function(e){fail(e.reason&&e.reason.message||String(e.reason),'Promise',0);});
})();
