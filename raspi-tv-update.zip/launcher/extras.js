/* Raspi-TV OS – Ersteinrichtung, Suche, Weiterschauen, Bildschirmschoner, Energie */
"use strict";

// ======================================================================
// Ersteinrichtung
// ======================================================================
const REGIONS = [
  ["BW", "Baden-Württemberg", "SWR"], ["BY", "Bayern", "BR Fernsehen"], ["BE", "Berlin", "rbb"],
  ["BB", "Brandenburg", "rbb"], ["HB", "Bremen", "Radio Bremen TV"], ["HH", "Hamburg", "NDR"],
  ["HE", "Hessen", "hr-fernsehen"], ["MV", "Mecklenburg-Vorpommern", "NDR"], ["NI", "Niedersachsen", "NDR"],
  ["NW", "Nordrhein-Westfalen", "WDR"], ["RP", "Rheinland-Pfalz", "SWR"], ["SL", "Saarland", "SR Fernsehen"],
  ["SN", "Sachsen", "MDR"], ["ST", "Sachsen-Anhalt", "MDR"], ["SH", "Schleswig-Holstein", "NDR"], ["TH", "Thüringen", "MDR"],
];
const SETUP_STEPS = ["welcome", "network", "region", "startup", "phone", "done"];

function setupStep() {
  try { return Math.max(0, SETUP_STEPS.indexOf(sessionStorage.getItem("setup.step") || "welcome")); } catch (_) { return 0; }
}
function setSetupStep(i) {
  try { sessionStorage.setItem("setup.step", SETUP_STEPS[i]); } catch (_) {}
  render();
}

function renderSetup(view, token) {
  const i = setupStep();
  const step = SETUP_STEPS[i];
  const dots = SETUP_STEPS.slice(1, -1).map((s, j) => `<i class="${j + 1 < i ? "done" : j + 1 === i ? "on" : ""}"></i>`).join("");
  const next = () => setSetupStep(i + 1);
  const wrap = (inner, opts = {}) => `
    <div class="setup step-${step}">
      ${i > 0 && i < SETUP_STEPS.length - 1 ? `<div class="setup-dots">${dots}</div>` : ""}
      ${inner}
      ${opts.noNav ? "" : `<div class="setup-nav">
        ${i > 0 ? '<button class="btn nav" data-key="s-back" id="s-back">Zurück</button>' : ""}
        <button class="btn primary nav" data-key="s-next" id="s-next">${opts.nextLabel || "Weiter"}</button>
      </div>`}
    </div>`;

  if (step === "welcome") {
    view.innerHTML = wrap(`
      <div class="setup-hero">
        <svg class="setup-logo" viewBox="0 0 96 96" aria-hidden="true"><defs><linearGradient id="slg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8B5CF6"/><stop offset=".55" stop-color="#3D7BFF"/><stop offset="1" stop-color="#22D3EE"/></linearGradient></defs><path d="M48 4C80 4 92 16 92 48s-12 44-44 44S4 80 4 48 16 4 48 4z" fill="url(#slg)"/><path d="M39 31.5c0-3 3.2-4.8 5.8-3.3l20.4 12.6c2.5 1.5 2.5 5.1 0 6.6L44.8 60c-2.6 1.6-5.8-.3-5.8-3.3z" fill="#fff"/><path d="M70.5 22.5a14 14 0 0 1 5 6.2M68 28.4a7 7 0 0 1 2.4 3" stroke="#fff" stroke-opacity=".85" stroke-width="3.6" stroke-linecap="round" fill="none"/></svg>
        <h1>Willkommen bei Raspi-TV</h1>
        <p>In wenigen Schritten ist dein Fernseher bereit. Bedienung mit den <b>Pfeiltasten</b> und <b>OK</b> deiner TV-Fernbedienung.</p>
      </div>`, { nextLabel: "Los geht’s" });
  } else if (step === "network") {
    const n = state.network;
    const online = n && n.online;
    view.innerHTML = wrap(`
      <div class="setup-card">
        <span class="setup-icon ${online ? "ok" : ""}">${online ? ICON.wifi : ICON.wifiOff}</span>
        <h1>${online ? "Mit dem Internet verbunden" : "Mit dem Internet verbinden"}</h1>
        <p id="net-text">${online ? (n.ethernet ? "Über LAN-Kabel." : "WLAN: " + esc(n.wifi.ssid || "")) + " Alles bereit."
          : "Wähle dein WLAN aus oder stecke ein LAN-Kabel ein."}</p>
        ${online ? "" : '<button class="btn primary nav big" data-key="s-wifi" data-go="#/settings/wifi">WLAN auswählen</button>'}
      </div>`, { nextLabel: online ? "Weiter" : "Später einrichten" });
    if (!online) pageTimers.push(setInterval(() => { if (state.network && state.network.online && token === renderToken) render(); }, 3000));
  } else if (step === "region") {
    const cur = state.config.region || "";
    view.innerHTML = wrap(`
      <h1 class="setup-title">Wo wohnst du?</h1>
      <p class="setup-lead">Dein Regionalprogramm landet dann auf Platz 3 – gleich nach Das Erste und ZDF.</p>
      <div class="region-grid">
        ${REGIONS.map(([k, name, ch]) => `<button class="region nav ${k === cur ? "on" : ""}" data-key="r-${k}" data-region="${k}">
          <b>${esc(name)}</b><span>${esc(ch)}</span></button>`).join("")}
      </div>`, { noNav: true });
    view.querySelectorAll("[data-region]").forEach(el => el.addEventListener("click", async () => {
      const r = REGIONS.find(x => x[0] === el.dataset.region);
      try {
        state.config = await API.post("/api/config", { region: r[0] });
        const s = await API.get("/api/channels/settings");
        const names = s.channels.map(c => c.name).filter(nm => nm !== r[2]);
        const at = Math.min(2, names.length);
        if (s.channels.some(c => c.name === r[2])) names.splice(at, 0, r[2]);
        await API.post("/api/channels/config", { order: names, hidden: s.channels.filter(c => c.hidden).map(c => c.name) });
      } catch (e) { toast(e.message, "error"); }
      next();
    }));
  } else if (step === "startup") {
    const cur = state.config.startup || "tv";
    view.innerHTML = wrap(`
      <h1 class="setup-title">Was soll beim Einschalten kommen?</h1>
      <div class="choice-grid">
        <button class="choice nav ${cur === "tv" ? "on" : ""}" data-key="c-tv" data-choice="tv">
          <span class="choice-icon">${ICON.live}</span><b>Live-TV</b><span>Wie ein normaler Fernseher – der letzte Sender läuft sofort.</span></button>
        <button class="choice nav ${cur === "home" ? "on" : ""}" data-key="c-home" data-choice="home">
          <span class="choice-icon">${ICON.apps}</span><b>Startseite</b><span>Erst die Übersicht mit Live-TV, Mediathek, Apps und Medien.</span></button>
      </div>`, { noNav: true });
    view.querySelectorAll("[data-choice]").forEach(el => el.addEventListener("click", async () => {
      try { state.config = await API.post("/api/config", { startup: el.dataset.choice }); } catch (e) { toast(e.message, "error"); }
      next();
    }));
  } else if (step === "phone") {
    view.innerHTML = wrap(`
      <div class="setup-split">
        <div class="qr-box"><div class="qr" id="qr"><div class="spinner"></div></div></div>
        <div>
          <h1 class="setup-title">Handy als Fernbedienung</h1>
          <p class="setup-lead">Praktisch zum Einloggen bei Netflix &amp; Co.: Mit dem Handy tippst du Text und klickst über ein Touchpad.
            Scanne einfach den Code mit der Kamera. Das geht auch später unter Einstellungen → Fernbedienung.</p>
        </div>
      </div>`, { nextLabel: "Weiter" });
    API.get("/api/remote").then(info => {
      if (token !== renderToken) return;
      if (!info.url) { $("#qr").innerHTML = '<div class="qr-off">Erst mit dem WLAN verbinden</div>'; return; }
      const qr = qrcode(0, "M"); qr.addData(info.url); qr.make();
      $("#qr").innerHTML = qr.createSvgTag({ cellSize: 8, margin: 2, scalable: true });
    }).catch(() => {});
  } else {
    view.innerHTML = wrap(`
      <div class="setup-hero done">
        <div class="setup-check"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></div>
        <h1>Fertig – viel Spaß!</h1>
        <p>Tipp: Die <b>Home-Taste</b> bringt dich aus jeder App zurück. Mit <b>Guide</b> öffnest du das TV-Programm.</p>
      </div>`, { nextLabel: (state.config.startup || "tv") === "tv" ? "Fernsehen starten" : "Zur Startseite" });
  }

  const nb = $("#s-next"), bb = $("#s-back");
  if (bb) bb.addEventListener("click", () => setSetupStep(i - 1));
  if (nb) nb.addEventListener("click", async () => {
    if (step !== "done") return next();
    try { state.config = await API.post("/api/config", { setup_done: true }); } catch (_) {}
    try { sessionStorage.removeItem("setup.step"); } catch (_) {}
    if ((state.config.startup || "tv") === "tv" && state.network && state.network.online) location.replace("/tv.html");
    else go("#/");
  });
  // Auswahl sinnvoll vorbelegen
  setTimeout(() => {
    if (token !== renderToken) return;
    const pre = view.querySelector(".region.on, .choice.on") || (step === "region" ? view.querySelector(".region") : null) || nb;
    if (pre) Nav.focus(pre, false);
  }, 0);
}

// ======================================================================
// Weiterschauen (zuletzt gesehene Sender, angefangene Videos)
// ======================================================================
function continueItems() {
  const items = [];
  let recent = [];
  try { recent = JSON.parse(localStorage.getItem("tv.recent") || "[]"); } catch (_) {}
  for (const name of recent.slice(0, 4)) {
    const idx = TV.channels.findIndex(c => c.name === name);
    if (idx >= 0) items.push({ kind: "channel", idx, name, at: 0 });
  }
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (!k.startsWith("resume:")) continue;
      const v = JSON.parse(localStorage.getItem(k));
      if (!v || typeof v !== "object" || !v.d || v.t < 30 || v.t > v.d - 60) continue;
      const rest = k.slice(7);
      const src = rest.slice(0, rest.indexOf(":")), path = rest.slice(rest.indexOf(":") + 1);
      items.push({ kind: "video", src, path, t: v.t, d: v.d, at: v.at || 0 });
    }
  } catch (_) {}
  const videos = items.filter(x => x.kind === "video").sort((a, b) => b.at - a.at).slice(0, 6);
  return items.filter(x => x.kind === "channel").concat(videos);
}

function renderContinue(container) {
  const items = continueItems();
  const sec = container.previousElementSibling;
  if (!items.length) { container.hidden = true; if (sec) sec.hidden = true; return; }
  container.hidden = false; if (sec) sec.hidden = false;
  container.innerHTML = items.map((it, i) => {
    if (it.kind === "channel") {
      const p = (TV.now[it.name] || {}).now;
      return `<button class="cont-card nav" data-key="cont-ch-${esc(it.name)}" data-i="${i}">
        <span class="cont-thumb live">${ICON.live}<em>LIVE</em></span>
        <span class="cont-title">${esc(it.name)}</span>
        <span class="cont-sub">${p ? esc(p.title) : "Live-TV"}</span>
        <span class="bar"><i style="width:${progress(p)}%"></i></span></button>`;
    }
    const name = it.path.split("/").pop().replace(/\.[^.]+$/, "").replace(/[._]+/g, " ");
    return `<button class="cont-card nav" data-key="cont-v-${esc(it.path)}" data-i="${i}">
      <span class="cont-thumb">${ICON.video}<img loading="lazy" alt="" onerror="this.remove()" src="/media/thumb?src=${encodeURIComponent(it.src)}&path=${encodeURIComponent(it.path)}"></span>
      <span class="cont-title">${esc(name)}</span>
      <span class="cont-sub">Noch ${Math.max(1, Math.round((it.d - it.t) / 60))} Min.</span>
      <span class="bar"><i style="width:${it.t / it.d * 100}%"></i></span></button>`;
  }).join("");
  container.querySelectorAll("[data-i]").forEach(el => el.addEventListener("click", () => {
    const it = items[+el.dataset.i];
    if (it.kind === "channel") return openChannel(it.idx);
    showOverlay("Wird geöffnet …");
    location.href = `/player.html?src=${encodeURIComponent(it.src)}&path=${encodeURIComponent(it.path)}`;
  }));
}

// ======================================================================
// Suche im TV-Programm
// ======================================================================
function renderSearch(view, token, params = {}) {
  let q = "";
  try { q = sessionStorage.getItem("search.q") || ""; } catch (_) {}
  if (params.q) q = params.q;   // vom Handy (Sprachsuche)
  view.innerHTML = `
    <div class="page wide">
      <h1>Sendung suchen</h1>
      <p class="lead">Durchsucht das TV-Programm der nächsten zwei Tage – z. B. „Tatort“, „Tagesschau“ oder „Fußball“.</p>
      <div class="search-bar">
        <span class="search-icon">${ICON.search}</span>
        <input class="nav" id="q" data-key="q" placeholder="Titel eingeben …" autocomplete="off" spellcheck="false" value="${esc(q)}">
      </div>
      <div class="list" id="results"></div>
    </div>`;
  let timer;
  const input = $("#q");
  input.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(run, 350); });
  input.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); clearTimeout(timer); run(); } });

  async function run() {
    q = input.value.trim();
    try { sessionStorage.setItem("search.q", q); } catch (_) {}
    if (q.length < 2) { $("#results").innerHTML = ""; return; }
    let r;
    try { r = await API.get("/api/epg/search?q=" + encodeURIComponent(q)); } catch (e) { return toast(e.message, "error"); }
    if (token !== renderToken) return;
    await TV.loadReminders();
    const rem = new Set(TV.reminders.map(x => x.id));
    $("#results").innerHTML = r.results.length ? r.results.map((p, i) => {
      const live = p.start <= Date.now() / 1000;
      return `<button class="row nav" data-key="res-${p.channel}-${p.start}" data-i="${i}">
        <span class="when"><b>${hhmm(p.start)}</b><small>${dayLabel(p.start)}</small></span>
        <span class="main"><div class="label">${esc(p.title)}${rem.has(p.channel + "|" + p.start) ? ` <span class="bell">${ICON.bell}</span>` : ""}</div>
          <div class="desc">${esc(p.channel)}${p.sub ? " · " + esc(p.sub) : ""}</div></span>
        <span class="value">${live ? '<span class="badge live">LÄUFT</span>' : ""}</span></button>`;
    }).join("") : '<div class="empty">Nichts gefunden. Probier einen kürzeren Suchbegriff.</div>';
    $("#results").querySelectorAll("[data-i]").forEach(el => el.addEventListener("click", () => {
      const p = r.results[+el.dataset.i];
      showProgram(p.channel, p.index, p, run);
    }));
  }
  if (q) run();
  setTimeout(() => { if (token === renderToken && !q) Nav.focus(input, false); }, 0);
}

// Details einer Sendung (aus Suche oder Programmübersicht)
function showProgram(chName, chIndex, p, after) {
  const now = Date.now() / 1000;
  const rid = chName + "|" + p.start;
  const has = TV.reminders.some(r => r.id === rid);
  const buttons = [{ label: "Schließen" }];
  if (p.start > now) {
    buttons.push(has
      ? { label: "Erinnerung löschen", style: "danger", action: async cl => {
          cl();
          try { TV.reminders = (await API.post("/api/reminders/remove", { id: rid })).reminders; toast("Erinnerung gelöscht"); }
          catch (err) { toast(err.message, "error"); }
          if (after) after();
        } }
      : { label: "Erinnern", style: "primary", action: async cl => {
          cl();
          try {
            TV.reminders = (await API.post("/api/reminders/add", { channel: chName, start: p.start, stop: p.stop, title: p.title })).reminders;
            toast(`Erinnerung für ${dayLabel(p.start)}, ${hhmm(p.start)} gesetzt`, "ok");
          } catch (err) { toast(err.message, "error"); }
          if (after) after();
        } });
  }
  // Videorekorder: vormerken bzw. laufende Sendung ab jetzt aufnehmen
  const rec = (TV.recs || []).find(r => r.id === rid && r.status !== "failed");
  if (p.stop > now) {
    buttons.push(rec
      ? { label: rec.status === "recording" ? "Aufnahme beenden" : "Aufnahme löschen", style: "danger", action: async cl => {
          cl();
          try { TV.recs = (await API.post("/api/rec/cancel", { id: rid })).schedule; toast(rec.status === "recording" ? "Aufnahme beendet" : "Aufnahme gelöscht"); }
          catch (err) { toast(err.message, "error"); }
          if (after) after();
        } }
      : { label: p.start > now ? "● Aufnehmen" : "● Ab jetzt aufnehmen", style: "rec", action: async cl => {
          cl();
          try {
            TV.recs = (await API.post("/api/rec/plan", { channel: chName, start: p.start, stop: p.stop, title: p.title })).schedule;
            toast(p.start > now ? `Aufnahme für ${dayLabel(p.start)}, ${hhmm(p.start)} geplant` : "Aufnahme läuft", "ok");
          } catch (err) { toast(err.message, "error"); }
          if (after) after();
        } });
  }
  buttons.push({ label: p.start > now ? "Sender jetzt einschalten" : "Jetzt ansehen", style: p.start > now ? "" : "primary",
                 action: cl => { cl(); openChannel(chIndex); } });
  const mins = Math.round((p.stop - p.start) / 60);
  openModal({
    title: p.title,
    html: `<div class="detail-meta">${dayLabel(p.start)}, ${hhmm(p.start)} – ${hhmm(p.stop)} Uhr · ${mins} Min. · ${esc(chName)}${p.cat ? " · " + esc(p.cat) : ""}</div>
           ${p.sub ? `<div class="detail-sub">${esc(p.sub)}</div>` : ""}
           <p class="detail-desc">${esc(p.desc || "Keine Beschreibung vorhanden.")}</p>`,
    buttons,
    focus: ".btn:last-child",
  });
}

// ======================================================================
// Einstellungen: Energie & Bildschirmschoner
// ======================================================================
function renderEnergy(view, token) {
  const opts = {
    auto_off_hours: [[0, "Nie"], [2, "Nach 2 Stunden"], [4, "Nach 4 Stunden"], [6, "Nach 6 Stunden"], [8, "Nach 8 Stunden"]],
    screensaver_min: [[0, "Aus"], [5, "Nach 5 Minuten"], [10, "Nach 10 Minuten"], [20, "Nach 20 Minuten"], [30, "Nach 30 Minuten"]],
  };
  const label = (k) => (opts[k].find(o => o[0] === state.config[k]) || opts[k][0])[1];
  view.innerHTML = `
    <div class="page">
      <h1>Energie</h1>
      <p class="lead">Spart Strom, wenn niemand schaut – wie bei einem modernen Fernseher.</p>
      <div class="list">
        <button class="row nav" data-key="e-off" id="e-off"><span class="icon">${ICON.power}</span>
          <span class="main"><div class="label">Automatisch ausschalten</div><div class="desc">Ohne Bedienung schaltet Raspi-TV den Fernseher aus (mit 2 Minuten Vorwarnung)</div></span>
          <span class="value" id="v-off">${label("auto_off_hours")}</span></button>
        <button class="row nav" data-key="e-ss" id="e-ss"><span class="icon">${ICON.picture}</span>
          <span class="main"><div class="label">Bildschirmschoner</div><div class="desc">Uhr und „Jetzt im TV“ auf der Startseite, wenn nichts passiert</div></span>
          <span class="value" id="v-ss">${label("screensaver_min")}</span></button>
        <button class="row nav" data-key="e-try" id="e-try"><span class="icon">${ICON.eye}</span>
          <span class="main"><div class="label">Bildschirmschoner ansehen</div></span></button>
      </div>
    </div>`;
  function cycle(key, el) {
    const list = opts[key];
    const i = list.findIndex(o => o[0] === state.config[key]);
    const nextV = list[(i + 1) % list.length][0];
    API.post("/api/config", { [key]: nextV }).then(c => { state.config = c; el.textContent = label(key); }).catch(e => toast(e.message, "error"));
  }
  $("#e-off").addEventListener("click", () => cycle("auto_off_hours", $("#v-off")));
  $("#e-ss").addEventListener("click", () => cycle("screensaver_min", $("#v-ss")));
  $("#e-try").addEventListener("click", () => Saver.show());
}

// ======================================================================
// Bildschirmschoner (Ambient-Modus)
// ======================================================================
const Saver = {
  idleSince: Date.now(),
  el: null,
  rot: null,
  i: 0,

  init() {
    const reset = () => { this.idleSince = Date.now(); };
    ["keydown", "mousemove", "mousedown"].forEach(ev => document.addEventListener(ev, reset, true));
    document.addEventListener("keydown", e => {
      if (this.el) { e.preventDefault(); e.stopImmediatePropagation(); this.hide(); }
    }, true);
    document.addEventListener("mousedown", () => { if (this.el) this.hide(); }, true);
    setInterval(() => {
      const min = state.config.screensaver_min;
      if (document.hidden || !min || this.el || document.querySelector("#modals .modal")) return;
      if (Date.now() - this.idleSince > min * 60000) this.show();
    }, 5000);
  },

  async show() {
    if (this.el) return;
    const el = document.createElement("div");
    el.className = "saver";
    el.innerHTML = `<div class="saver-bg"></div><div class="saver-bg b2"></div>
      <div class="saver-clock"><div class="saver-time" id="sv-time"></div><div class="saver-date" id="sv-date"></div></div>
      <div class="saver-now" id="sv-now"></div>
      <div class="saver-hint">Beliebige Taste drücken</div>`;
    document.body.appendChild(el);
    this.el = el;
    const tickNow = () => {
      const d = new Date();
      $("#sv-time", el).textContent = String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
      $("#sv-date", el).textContent = d.toLocaleDateString("de-DE", { weekday: "long", day: "numeric", month: "long" });
    };
    tickNow();
    if (!TV.channels.length) await TV.loadChannels();
    await TV.loadNow();
    API.get("/api/weather").then(w => {
      if (!this.el) return;
      const k = wmo(w.code);
      const box = document.createElement("div");
      box.className = "saver-weather";
      box.innerHTML = weatherIcon(k.kind, !w.day) + `<div><b>${fmtTemp(w.temp)}</b><span>${esc(w.place)} · ${k.text}</span></div>`;
      el.appendChild(box);
    }).catch(() => {});
    const cycle = () => {
      if (!this.el) return;
      const sp = SpotifyNow.cur;
      if (sp && sp.playing && sp.title) {
        tickNow();
        $("#sv-now", el).innerHTML = `<span class="sv-k">Spotify</span><span class="sv-t">${esc(sp.title)}</span><span class="sv-c">${esc(sp.artist)}</span>`;
        $("#sv-now", el).classList.add("in");
        return;
      }
      if (Radio.current) {
        tickNow();
        $("#sv-now", el).innerHTML = `<span class="sv-k">Radio läuft</span><span class="sv-t">${esc(Radio.current.name)}</span>`;
        $("#sv-now", el).classList.add("in");
        return;
      }
      const list = TV.channels.filter(c => (TV.now[c.name] || {}).now).slice(0, 12);
      tickNow();
      if (!list.length) return;
      const c = list[this.i++ % list.length];
      const p = TV.now[c.name].now;
      const box = $("#sv-now", el);
      box.classList.remove("in");
      setTimeout(() => {
        box.innerHTML = `<span class="sv-k">Jetzt im TV · ${esc(c.name)}</span><span class="sv-t">${esc(p.title)}</span>
          <span class="bar"><i style="width:${progress(p)}%"></i></span>`;
        box.classList.add("in");
      }, 450);
    };
    cycle();
    this.rot = setInterval(cycle, 9000);
  },

  hide() {
    clearInterval(this.rot);
    const el = this.el;
    this.el = null;
    this.idleSince = Date.now();
    if (!el) return;
    el.classList.add("out");
    setTimeout(() => el.remove(), 400);
  },
};
