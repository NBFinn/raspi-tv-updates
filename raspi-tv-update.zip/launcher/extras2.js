/* Raspi-TV OS – Radio, Wetter, Software-Update, AirPlay, Gerätename */
"use strict";

// ======================================================================
// Radio (läuft beim Stöbern in der Oberfläche weiter)
// ======================================================================
const Radio = {
  _reported: null,
  _reportedAt: 0,
  stations: [],
  audio: null,
  current: null,
  state: "stopped", // stopped | loading | playing | error

  async load() {
    if (this.stations.length) return this.stations;
    try { this.stations = await (await fetch("radio.json", { cache: "no-store" })).json(); } catch (_) { this.stations = []; }
    // Regionale Sender des eigenen Bundeslands nach vorne
    const reg = state.config.region;
    if (reg) this.stations.sort((a, b) => (b.region === reg) - (a.region === reg));
    return this.stations;
  },

  ensureAudio() {
    if (this.audio) return this.audio;
    const a = this.audio = new Audio();
    a.preload = "none";
    a.addEventListener("playing", () => { this.state = "playing"; this.update(); });
    a.addEventListener("waiting", () => { this.state = "loading"; this.update(); });
    a.addEventListener("error", () => {
      if (!this.current) return;
      this.state = "error"; this.update();
      toast(this.current.name + " ist gerade nicht erreichbar.", "error");
    });
    return a;
  },

  play(st) {
    const a = this.ensureAudio();
    if (this.current && this.current.name === st.name && this.state !== "error") return this.stop();
    this.current = st;
    this.state = "loading";
    a.src = st.url;
    a.play().catch(() => {});
    try { localStorage.setItem("radio.last", st.name); } catch (_) {}
    this.update();
  },

  stop() {
    if (this.audio) { this.audio.pause(); this.audio.removeAttribute("src"); this.audio.load(); }
    this.current = null;
    this.state = "stopped";
    this.update();
  },

  // dem Pi melden, was läuft (für den Mini-Player in der Handy-App)
  report() {
    const key = this.current ? this.current.name + "|" + this.state : "";
    if (key === this._reported && Date.now() - this._reportedAt < 10000) return;
    this._reported = key; this._reportedAt = Date.now();
    API.post("/api/radio/now", this.current ? { name: this.current.name, genre: this.current.genre || "", state: this.state, logo: this.current.logo || "" } : {}).catch(() => { this._reported = null; });
  },

  // Befehle aus der Handy-App
  async control(cmd) {
    if (!["toggle", "next", "previous"].includes(cmd)) return;
    const list = await this.load();
    if (!list.length) return;
    if (cmd === "toggle") {
      if (this.current) {
        if (this.state === "paused") {
          this.state = "loading";
          this.ensureAudio().play().catch(() => { this.state = "error"; this.update(); });
        } else { this.ensureAudio().pause(); this.state = "paused"; }
        this.update(); return;
      }
      let last = null;
      try { last = localStorage.getItem("radio.last"); } catch (_) {}
      return this.play(list.find(s => s.name === last) || list[0]);
    }
    const i = Math.max(0, list.findIndex(s => this.current && s.name === this.current.name));
    const next = list[(i + (cmd === "next" ? 1 : list.length - 1)) % list.length];
    this.current = null;          // sonst würde play() denselben Sender anhalten
    this.play(next);
  },

  update() {
    this.report();
    let bar = $("#radio-bar");
    if (!this.current) { if (bar) bar.classList.remove("show"); }
    else {
      if (!bar) {
        bar = document.createElement("div");
        bar.id = "radio-bar";
        bar.className = "radio-bar";
        document.body.appendChild(bar);
      }
      bar.innerHTML = `<span class="rb-eq ${this.state === "playing" ? "on" : ""}"><i></i><i></i><i></i><i></i></span>
        <span class="rb-text"><b>${esc(this.current.name)}</b><small>${this.state === "loading" ? "Verbinde …" : this.state === "error" ? "Nicht erreichbar" : this.state === "paused" ? "Pause" : "Radio · Live"}</small></span>`;
      requestAnimationFrame(() => bar.classList.add("show"));
    }
    document.querySelectorAll(".station").forEach(el => {
      const on = this.current && el.dataset.name === this.current.name;
      el.classList.toggle("playing", !!on);
      const s = el.querySelector(".st-state");
      if (s) s.textContent = on ? (this.state === "loading" ? "Verbinde …" : this.state === "error" ? "Fehler" : this.state === "paused" ? "Pause" : "Läuft") : "";
    });
  },
};

function renderRadio(view, token) {
  view.innerHTML = `
    <div class="page wide">
      <h1>Radio</h1>
      <p class="lead">Über 20 Sender live. Das Radio läuft weiter, während du durch die Oberfläche stöberst – <b>OK</b> auf den laufenden Sender stoppt es.</p>
      <div class="station-grid" id="stations"><div class="empty">Lade Sender …</div></div>
    </div>`;
  const hues = { "Pop & Charts": 215, "Pop & Info": 200, "Pop & Hits": 230, "Oldies": 30, "Oldies & Info": 25, "Nachrichten": 0,
                 "Kultur": 280, "Junges Radio": 320, "Klassik": 45, "Hip-Hop & Pop": 260, "Rock": 350, "Hits": 190, "Pop & Kultur": 170 };
  Radio.load().then(list => {
    if (token !== renderToken) return;
    $("#stations").innerHTML = list.map((s, i) => {
      const h = hues[s.genre] ?? 210;
      return `<button class="station nav" data-key="st-${i}" data-i="${i}" data-name="${esc(s.name)}"
          style="--h1:hsl(${h} 70% 28%);--h2:hsl(${(h + 30) % 360} 65% 14%)">
        <span class="st-name">${esc(s.name)}</span>
        <span class="st-genre">${esc(s.genre)}${s.region && s.region === state.config.region ? " · Deine Region" : ""}</span>
        <span class="st-state"></span>
        <span class="st-eq"><i></i><i></i><i></i><i></i></span>
      </button>`;
    }).join("");
    $("#stations").querySelectorAll("[data-i]").forEach(el => el.addEventListener("click", () => Radio.play(list[+el.dataset.i])));
    Radio.update();
    let last = null;
    try { last = localStorage.getItem("radio.last"); } catch (_) {}
    const el = Radio.current ? document.querySelector(`.station[data-name="${CSS.escape(Radio.current.name)}"]`)
      : last ? document.querySelector(`.station[data-name="${CSS.escape(last)}"]`) : null;
    Nav.focus(el || $("#stations .station"), false);
  });
}

// Radio aus, sobald Live-TV, Apps oder Videos gestartet werden
window.addEventListener("pagehide", () => Radio.stop());

// ======================================================================
// Wetter
// ======================================================================
const WMO = [
  [[0], "Sonnig", "sun"], [[1], "Überwiegend sonnig", "sun-cloud"], [[2], "Teilweise bewölkt", "sun-cloud"],
  [[3], "Bedeckt", "cloud"], [[45, 48], "Nebel", "fog"], [[51, 53, 55, 56, 57], "Nieselregen", "rain"],
  [[61, 63, 66], "Regen", "rain"], [[65, 67], "Starker Regen", "rain"], [[71, 73, 75, 77], "Schnee", "snow"],
  [[80, 81, 82], "Regenschauer", "rain"], [[85, 86], "Schneeschauer", "snow"], [[95, 96, 99], "Gewitter", "storm"],
];
function wmo(code) {
  const hit = WMO.find(w => w[0].includes(code));
  return hit ? { text: hit[1], kind: hit[2] } : { text: "–", kind: "cloud" };
}
function weatherIcon(kind, night) {
  const sun = night
    ? '<path class="wi-moon" d="M33 14a14 14 0 1 0 17 17A11 11 0 0 1 33 14z"/>'
    : '<g class="wi-sun"><circle cx="32" cy="28" r="10"/><g class="wi-rays"><path d="M32 8v6M32 42v6M12 28h6M46 28h6M18 14l4 4M42 38l4 4M46 14l-4 4M22 38l-4 4"/></g></g>';
  const cloud = '<path class="wi-cloud" d="M20 50h26a10 10 0 0 0 0-20 14 14 0 0 0-27-2A9 9 0 0 0 20 50z"/>';
  const drops = '<g class="wi-drops"><path d="M24 54l-2 6M33 54l-2 6M42 54l-2 6"/></g>';
  const flakes = '<g class="wi-flakes"><circle cx="24" cy="57" r="1.8"/><circle cx="33" cy="60" r="1.8"/><circle cx="42" cy="57" r="1.8"/></g>';
  const bolt = '<path class="wi-bolt" d="M34 50l-6 9h6l-3 7 9-11h-6l3-5z"/>';
  const fog = '<g class="wi-fog"><path d="M14 34h36M18 42h30M14 50h36"/></g>';
  const parts = {
    sun: sun, "sun-cloud": `<g transform="translate(-8 -6) scale(.85)">${sun}</g>${cloud}`,
    cloud: cloud, fog: fog, rain: cloud + drops, snow: cloud + flakes, storm: cloud + bolt,
  }[kind] || cloud;
  return `<svg class="wi wi-${kind}" viewBox="0 0 64 64" aria-hidden="true">${parts}</svg>`;
}
const fmtTemp = t => (t == null ? "–" : Math.round(t) + "°");

async function loadWeatherChip(el, token) {
  try {
    const w = await API.get("/api/weather");
    if (token !== renderToken || !el) return;
    const k = wmo(w.code);
    el.innerHTML = weatherIcon(k.kind, !w.day) + `<b>${fmtTemp(w.temp)}</b><span>${esc(w.place)}</span>`;
    el.hidden = false;
  } catch (_) { if (el) el.hidden = true; }
}

function renderWeather(view, token) {
  view.innerHTML = `<div class="page wide"><div class="weather" id="wx"><div class="empty">Lade Wetter …</div></div></div>`;
  API.get("/api/weather").then(w => {
    if (token !== renderToken) return;
    const k = wmo(w.code);
    const days = w.days.slice(0, 6).map((d, i) => {
      const dk = wmo(d.code);
      const label = i === 0 ? "Heute" : i === 1 ? "Morgen" : new Date(d.date + "T12:00").toLocaleDateString("de-DE", { weekday: "long" });
      return `<div class="wx-day">
        <span class="wx-dname">${label}</span>${weatherIcon(dk.kind, false)}
        <span class="wx-dtext">${dk.text}</span>
        <span class="wx-temps"><b>${fmtTemp(d.max)}</b><small>${fmtTemp(d.min)}</small></span>
        ${d.rain != null ? `<span class="wx-rain">Regen ${d.rain} %</span>` : ""}
      </div>`;
    }).join("");
    $("#wx").innerHTML = `
      <div class="wx-now ${w.day ? "" : "night"}">
        <div class="wx-big">${weatherIcon(k.kind, !w.day)}</div>
        <div>
          <div class="wx-place">${esc(w.place)}</div>
          <div class="wx-temp">${fmtTemp(w.temp)}</div>
          <div class="wx-text">${k.text} · gefühlt ${fmtTemp(w.feels)}</div>
          <div class="wx-meta">Wind ${w.wind != null ? Math.round(w.wind) + " km/h" : "–"} · Luftfeuchte ${w.humidity != null ? w.humidity + " %" : "–"}</div>
        </div>
        <button class="btn nav wx-place-btn" data-key="wx-place" id="wx-place">Ort ändern</button>
      </div>
      <div class="wx-days">${days}</div>
      <p class="wx-src">Wetterdaten: Open-Meteo.com</p>`;
    $("#wx-place").addEventListener("click", placeDialog);
    Nav.restore();
  }).catch(e => { if (token === renderToken) $("#wx").innerHTML = `<div class="empty">${esc(e.message)}</div>`; });

  function placeDialog() {
    const { el, close } = openModal({
      title: "Ort für das Wetter",
      top: true,
      html: `<div class="field"><input class="nav" id="wx-q" data-key="wx-q" placeholder="Stadt oder Ort, z. B. Köln" autocomplete="off" spellcheck="false"></div>
             <div class="list" id="wx-res"></div>`,
      buttons: [
        { label: "Abbrechen" },
        { label: "Wie Bundesland", action: async c => { await API.post("/api/weather/place", { reset: true }).catch(() => {}); c(); render(); } },
      ],
      focus: "#wx-q",
    });
    let timer;
    $("#wx-q", el).addEventListener("input", () => {
      clearTimeout(timer);
      timer = setTimeout(async () => {
        const q = $("#wx-q", el).value.trim();
        if (q.length < 2) return;
        try {
          const r = await API.get("/api/weather/search?q=" + encodeURIComponent(q));
          $("#wx-res", el).innerHTML = r.results.map((p, i) => `<button class="row nav" data-key="wxr-${i}" data-i="${i}">
            <span class="main"><div class="label">${esc(p.name)}</div><div class="desc">${esc(p.area)}</div></span></button>`).join("")
            || '<div class="empty">Kein Ort gefunden.</div>';
          $("#wx-res", el).querySelectorAll("[data-i]").forEach(b => b.addEventListener("click", async () => {
            const p = r.results[+b.dataset.i];
            try { await API.post("/api/weather/place", p); close(); toast("Ort gespeichert: " + p.name, "ok"); render(); }
            catch (e) { toast(e.message, "error"); }
          }));
        } catch (e) { toast(e.message, "error"); }
      }, 500);
    });
  }
}

// ======================================================================
// Software-Update vom USB-Stick (Teil der Seite „Updates“)
// ======================================================================
function addUsbUpdateSection(view, token) {
  const page = view.querySelector(".page");
  if (!page) return;
  const box = document.createElement("div");
  box.innerHTML = `<h2>Raspi-TV aktualisieren (USB-Stick)</h2>
    <div class="list" id="swu"><div class="row static"><span class="icon">${ICON.usb}</span><span class="main">
      <div class="label">Suche Update auf USB-Sticks …</div></span><span class="spinner"></span></div></div>`;
  page.appendChild(box);

  async function check() {
    let r;
    try { r = await API.get("/api/swupdate"); } catch (e) { return; }
    if (token !== renderToken) return;
    if (r.status && r.status.running) return progress();
    const rows = r.found.map((f, i) => `
      <button class="row nav primary" data-key="swu-${i}" data-i="${i}"><span class="icon">${ICON.update}</span>
        <span class="main"><div class="label">Version ${esc(f.version)} installieren</div>
          <div class="desc">${esc(f.file)} auf „${esc(f.name)}“ · installiert ist Version ${esc(r.installed)}</div></span></button>`).join("");
    $("#swu").innerHTML = rows || `<div class="row static"><span class="icon">${ICON.usb}</span><span class="main">
      <div class="label">Kein Update-Paket gefunden</div>
      <div class="desc">Am PC „Update-Paket.bat“ starten, die Datei raspi-tv-update.zip auf einen USB-Stick kopieren und einstecken. Installiert: Version ${esc(r.installed)}</div></span></div>`;
    $("#swu").querySelectorAll("[data-i]").forEach(el => el.addEventListener("click", async () => {
      const f = r.found[+el.dataset.i];
      if (!await confirmDialog(`Version ${f.version} installieren?`, "Raspi-TV wird aktualisiert und startet danach neu. Deine Einstellungen bleiben erhalten.", "Installieren")) return;
      try { await API.post("/api/swupdate/install", { src: f.src, file: f.file }); progress(); } catch (e) { toast(e.message, "error"); }
    }));
    if (r.status && r.status.error) toast("Letztes Update: " + r.status.error, "error", 6000);
    Nav.refocus();
  }

  function progress() {
    const o = document.createElement("div");
    o.className = "overlay";
    o.innerHTML = `<div class="spinner"></div><div id="swu-step">Update wird installiert …</div>
      <div style="font-size:1vw;color:var(--muted)">Bitte nicht ausschalten.</div>`;
    document.body.appendChild(o);
    const t = setInterval(async () => {
      try {
        const s = await API.get("/api/swupdate/status");
        $("#swu-step").textContent = s.step || "…";
        if (s.error) { clearInterval(t); o.remove(); toast(s.error, "error", 8000); check(); }
        if (s.done) {
          clearInterval(t);
          $("#swu-step").textContent = "Fertig – Raspi-TV " + (s.version || "") + " startet neu …";
          setTimeout(() => location.replace("/#/"), 25000);   // falls der Neustart ausbleibt
        }
      } catch (_) {
        $("#swu-step").textContent = "Raspi-TV startet neu …";   // Dienst startet gerade neu
      }
    }, 1500);
  }

  check();
  pageTimers.push(setInterval(check, 8000));
}

// ======================================================================
// AirPlay (Seite „Ton“) und Gerätename (Seite „System“)
// ======================================================================
function addAirplayRow(view, token) {
  const page = view.querySelector(".page");
  if (!page) return;
  const box = document.createElement("div");
  box.innerHTML = `<h2>Vom Handy abspielen</h2><div class="list">
    <button class="row nav" data-key="airplay" id="airplay"><span class="icon">${ICON.music}</span>
      <span class="main"><div class="label">AirPlay</div><div class="desc" id="ap-desc">Musik vom iPhone, iPad oder Mac auf dem Fernseher abspielen</div></span>
      <span class="switch" id="ap-sw"></span></button></div>`;
  page.appendChild(box);
  const draw = s => {
    if (token !== renderToken) return;
    $("#ap-sw").classList.toggle("on", s.enabled);
    $("#ap-desc").textContent = !s.available ? "Wird mit dem nächsten System-Update installiert"
      : s.enabled ? `Aktiv – am iPhone im Kontrollzentrum „${s.name}“ wählen` : "Musik vom iPhone, iPad oder Mac auf dem Fernseher abspielen";
  };
  API.get("/api/airplay").then(draw).catch(() => {});
  $("#airplay").addEventListener("click", async () => {
    try { draw(await API.post("/api/airplay", { enabled: !$("#ap-sw").classList.contains("on") })); }
    catch (e) { toast(e.message, "error"); }
  });
}

function addDeviceNameRow(view, token) {
  const list = view.querySelector(".page .list");
  if (!list) return;
  const row = document.createElement("button");
  row.className = "row nav";
  row.dataset.key = "devname";
  row.innerHTML = `<span class="icon">${ICON.tv}</span><span class="main"><div class="label">Gerätename</div>
    <div class="desc">So heißt Raspi-TV im Heimnetz, bei AirPlay und Bluetooth</div></span><span class="value" id="dn-val">…</span>`;
  list.prepend(row);
  API.get("/api/system").then(s => { if (token === renderToken) $("#dn-val").textContent = s.hostname; }).catch(() => {});
  row.addEventListener("click", () => {
    const { el, close } = openModal({
      title: "Gerätename",
      top: true,
      html: `<p>Buchstaben, Ziffern und Bindestrich, z. B. „Wohnzimmer-TV“.</p>
             <div class="field"><input class="nav" id="dn" data-key="dn" value="${esc($("#dn-val").textContent)}" autocomplete="off" spellcheck="false"></div>`,
      buttons: [
        { label: "Abbrechen" },
        { label: "Speichern", style: "primary", action: async () => {
          try { const r = await API.post("/api/device-name", { name: $("#dn", el).value.trim() }); $("#dn-val").textContent = r.name; close(); toast("Name geändert", "ok"); }
          catch (e) { toast(e.message, "error", 6000); }
        } },
      ],
      focus: "#dn",
    });
  });
}

window.addEventListener("message", e => {
  if (e.source === window && e.origin === location.origin && e.data && e.data.type === "raspi-tv-radio-ctl") Radio.control(e.data.cmd);
});

setInterval(() => Radio.report(), 10000);
