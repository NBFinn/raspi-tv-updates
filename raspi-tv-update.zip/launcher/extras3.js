/* Raspi-TV OS – Spotify Connect: Einstellung, Installation, „Läuft gerade“-Leiste */
"use strict";

// ======================================================================
// Was läuft gerade über Spotify Connect?
// ======================================================================
const SpotifyNow = {
  cur: null,
  timer: null,

  start() {
    clearInterval(this.timer);
    // auch ohne Spotify Connect: die Spotify-App (ncspot) meldet hier, was läuft
    this.control("refresh");
    this.poll();
    setTimeout(() => this.poll(), 500);
    this.timer = setInterval(() => this.poll(), 4000);
  },

  control(action) {
    window.postMessage({ type: "raspi-tv-spotify-control", action }, location.origin);
  },

  async poll() {
    // Hintergrund-Timer werden von Chromium gedrosselt: Metadaten aktiv anfordern.
    this.control("refresh");
    let n;
    try { n = await API.get("/api/spotify/now"); } catch (_) { return; }
    const was = this.cur && this.cur.playing;
    this.cur = n;
    // Spotify startet → Radio der Oberfläche anhalten, damit nichts durcheinander spielt
    if (n.playing && !was && typeof Radio !== "undefined" && Radio.current) Radio.stop();
    this.draw();
  },

  draw() {
    const n = this.cur;
    let bar = $("#spotify-bar");
    if (!n || !(n.playing || n.paused) || !n.title) { if (bar) bar.classList.remove("show"); return; }
    if (!bar) {
      bar = document.createElement("div");
      bar.id = "spotify-bar";
      bar.className = "radio-bar spotify-bar";
      document.body.appendChild(bar);
    }
    if (!bar.querySelector(".sb-open")) {
      bar.innerHTML = `<button class="nav sb-open" data-key="spotify-open" aria-label="Spotify öffnen">
        <span class="sb-art"></span><span class="rb-text"><b></b><small></small></span></button>
        <button class="nav sb-toggle" data-key="spotify-toggle"></button>`;
      bar.querySelector(".sb-open").addEventListener("click", () => openApp("spotify"));
      bar.querySelector(".sb-toggle").addEventListener("click", () => this.control("toggle"));
    }
    bar.querySelector(".rb-text b").textContent = n.title;
    bar.querySelector(".rb-text small").textContent = n.artist || "Spotify";
    const art = bar.querySelector(".sb-art");
    if (art.dataset.cover !== (n.cover || "")) {
      art.dataset.cover = n.cover || "";
      art.innerHTML = n.cover ? `<img class="sb-cover" src="${esc(n.cover)}" alt="">` : ICON.music;
    } else if (!art.firstChild) art.innerHTML = ICON.music;
    const toggle = bar.querySelector(".sb-toggle");
    toggle.hidden = !n.web;
    toggle.textContent = n.playing ? "❚❚" : "▶";
    toggle.setAttribute("aria-label", n.playing ? "Musik pausieren" : "Musik fortsetzen");
    const radio = $("#radio-bar.show");
    bar.style.bottom = radio ? `calc(2vh + ${radio.offsetHeight}px + 1.2vh)` : "";
    requestAnimationFrame(() => bar.classList.add("show"));
  },
};

document.addEventListener("visibilitychange", () => {
  if (document.hidden) return;
  SpotifyNow.control("refresh");
  SpotifyNow.poll();
  setTimeout(() => SpotifyNow.poll(), 500);
});

// ======================================================================
// Einschalten (beim ersten Mal mit Installation) / Ausschalten
// ======================================================================
async function spotifySet(on, after) {
  let s;
  try { s = await API.get("/api/spotify"); } catch (e) { return toast(e.message, "error"); }
  if (on && !s.available) {
    if (state.network && !state.network.online)
      return toast("Zum Einrichten braucht Raspi-TV eine Internetverbindung.", "error", 5000);
    if (!await confirmDialog("Spotify Connect einrichten?",
      "Raspi-TV lädt dafür ein kleines Zusatzprogramm (librespot, ca. 10 MB). Zum Abspielen brauchst du Spotify Premium.",
      "Einrichten")) return;
  }
  try { s = await API.post("/api/spotify", { enabled: on }); }
  catch (e) { return toast(e.message, "error", 6000); }
  state.config.spotify = on;
  if (s.job && s.job.running) return spotifyProgress(after);
  SpotifyNow.start();
  if (on) toast(`Fertig! In der Spotify-App auf „Geräte“ tippen und „${s.name}“ wählen.`, "ok", 7000);
  after && after(s);
}

function spotifyProgress(after) {
  const { el, close } = openModal({
    title: "Spotify Connect wird eingerichtet",
    html: `<div class="job">
        <div class="job-bar"><i id="job-fill"></i></div>
        <div class="job-row"><span id="job-step">Wird vorbereitet …</span><b id="job-pct">0 %</b></div>
      </div>`,
    buttons: [{ label: "Im Hintergrund weiter" }],
  });
  const t = setInterval(async () => {
    let s;
    try { s = await API.get("/api/spotify"); } catch (_) { return; }
    const j = s.job || {};
    if (document.contains(el)) {
      $("#job-fill", el).style.width = (j.percent || 0) + "%";
      $("#job-pct", el).textContent = (j.percent || 0) + " %";
      $("#job-step", el).textContent = j.error ? "Fehler" : (j.step || "…");
    }
    if (j.running) return;
    clearInterval(t);
    if (document.contains(el)) close();
    state.config.spotify = s.enabled;
    if (j.error) toast(j.error, "error", 9000);
    else { toast(`Fertig! In der Spotify-App auf „Geräte“ tippen und „${s.name}“ wählen.`, "ok", 8000); SpotifyNow.start(); }
    after && after(s);
  }, 1000);
}

// Zeile auf der Seite „Ton“ (unter „Musik vom Handy“, neben AirPlay)
function addSpotifyRow(view, token) {
  const ap = $("#airplay");
  if (!ap) return;
  const row = document.createElement("button");
  row.className = "row nav";
  row.dataset.key = "spotify";
  row.id = "spotify";
  row.innerHTML = `<span class="icon">${ICON.speaker}</span>
    <span class="main"><div class="label">Spotify Connect</div><div class="desc" id="sp-desc">Raspi-TV als Lautsprecher in der Spotify-App (Premium)</div></span>
    <span class="switch" id="sp-sw"></span>`;
  ap.parentNode.insertBefore(row, ap);
  const draw = s => {
    if (token !== renderToken) return;
    $("#sp-sw").classList.toggle("on", s.enabled);
    $("#sp-desc").textContent = s.job && s.job.running ? "Wird eingerichtet …"
      : s.enabled ? `Aktiv – in der Spotify-App unter „Geräte“ „${s.name}“ wählen`
      : !s.available ? "Raspi-TV als Lautsprecher in der Spotify-App (Premium) – wird beim Einschalten eingerichtet"
      : "Raspi-TV als Lautsprecher in der Spotify-App (Premium)";
  };
  API.get("/api/spotify").then(draw).catch(() => {});
  row.addEventListener("click", () => spotifySet(!$("#sp-sw").classList.contains("on"), draw));
}

// ======================================================================
// Fernbedienungs-WLAN (Seite „Handy als Fernbedienung“)
// ======================================================================
function addHotspotSection(view, token) {
  const page = view.querySelector(".phone-page .page");
  if (!page) return;
  const MODES = [["off", "Aus"], ["night", "Nur nachts"], ["always", "Immer an"]];
  const STARTS = [18, 19, 20, 21, 22, 23, 0];
  const ENDS = [5, 6, 7, 8, 9, 10];
  const box = document.createElement("div");
  box.innerHTML = `<h2>Ohne Heim-WLAN (z. B. nachts)</h2>
    <p class="hs-lead">Ist Raspi-TV per LAN-Kabel verbunden, kann er ein eigenes WLAN aufspannen – für die Handy-Fernbedienung
      und auf Wunsch mit Internet für alle verbundenen Geräte. So klappt beides auch, wenn das Heim-WLAN aus ist.</p>
    <div class="list" id="hs-list"><div class="row static"><span class="spinner"></span></div></div>`;
  page.appendChild(box);
  let s = null;

  const hh = h => String(h).padStart(2, "0") + ":00";
  const next = (arr, v) => arr[(arr.indexOf(v) + 1) % arr.length];

  async function save(patch) {
    $("#hs-state") && ($("#hs-state").textContent = "Wird umgestellt …");
    try { s = await API.post("/api/hotspot", patch); draw(); if (s.error) toast(s.error, "error", 7000); }
    catch (e) { toast(e.message, "error", 6000); }
  }

  function draw() {
    if (token !== renderToken || !s) return;
    const mode = MODES.find(m => m[0] === s.mode) || MODES[0];
    const conn = s.clients ? ` · ${s.clients} ${s.clients === 1 ? "Gerät" : "Geräte"} verbunden` : "";
    const state = s.active ? `Aktiv – WLAN „${esc(s.ssid)}“${conn}`
      : s.busy ? esc(s.step || "Wird gestartet …")
      : s.error ? esc(s.error)
      : s.mode === "night" ? `Schaltet sich um ${hh(s.start)} Uhr ein`
      : s.mode === "off" ? "Aus" : "Startet gleich …";
    $("#hs-list").innerHTML = `
      <button class="row nav" data-key="hs-mode" id="hs-mode"><span class="icon">${ICON.wifi}</span>
        <span class="main"><div class="label">Fernbedienungs-WLAN</div><div class="desc" id="hs-state">${state}</div></span>
        <span class="value">${mode[1]}</span></button>
      ${s.mode === "night" ? `
      <button class="row nav" data-key="hs-start" id="hs-start"><span class="icon">${ICON.power}</span>
        <span class="main"><div class="label">Einschalten um</div></span><span class="value">${hh(s.start)} Uhr</span></button>
      <button class="row nav" data-key="hs-end" id="hs-end"><span class="icon">${ICON.power}</span>
        <span class="main"><div class="label">Ausschalten um</div></span><span class="value">${hh(s.end)} Uhr</span></button>` : ""}
      ${s.mode !== "off" ? `
      <button class="row nav" data-key="hs-net" id="hs-net"><span class="icon">${ICON.network}</span>
        <span class="main"><div class="label">Internet für verbundene Geräte</div>
          <div class="desc">${s.internet ? "An – alle Geräte im WLAN surfen über das LAN-Kabel des Pi" : "Aus – das WLAN dient nur der Fernbedienung"}</div></span>
        <span class="switch ${s.internet ? "on" : ""}"></span></button>
      <button class="row nav primary" data-key="hs-qr" id="hs-qr"><span class="icon">${ICON.phone}</span>
        <span class="main"><div class="label">Handy einrichten</div><div class="desc">Zwei QR-Codes: WLAN beitreten, Fernbedienung öffnen</div></span></button>` : ""}`;
    $("#hs-mode").addEventListener("click", () => {
      const m = next(MODES.map(x => x[0]), s.mode);
      if (m !== "off" && !s.ethernet) return toast("Das geht nur, wenn Raspi-TV per LAN-Kabel mit dem Router verbunden ist.", "error", 6000);
      save({ mode: m });
    });
    const st = $("#hs-start"), en = $("#hs-end"), qr = $("#hs-qr"), net = $("#hs-net");
    if (net) net.addEventListener("click", () => save({ internet: !s.internet }));
    if (st) st.addEventListener("click", () => save({ start: next(STARTS, s.start) }));
    if (en) en.addEventListener("click", () => save({ end: next(ENDS, s.end) }));
    if (qr) qr.addEventListener("click", showCodes);
    Nav.refocus();
  }

  function svg(text) {
    const q = qrcode(0, "M");
    q.addData(text);
    q.make();
    return q.createSvgTag({ cellSize: 6, margin: 2, scalable: true });
  }

  function showCodes() {
    openModal({
      title: "Handy fürs Fernbedienungs-WLAN einrichten",
      html: `<div class="hs-codes">
          <div><div class="qr">${svg(s.wifi_qr)}</div><b>1 · WLAN beitreten</b>
            <span>„${esc(s.ssid)}“<br>Passwort: <code>${esc(s.password)}</code></span></div>
          <div><div class="qr">${svg(s.remote_url)}</div><b>2 · Fernbedienung öffnen</b>
            <span>Danach „Zum Startbildschirm hinzufügen“ – z. B. als „TV Nacht“</span></div>
        </div>
        <p class="ad-note">${s.internet
          ? "Das Handy verbindet sich ab dann von selbst mit diesem WLAN und hat darüber Internet. Weitere Geräte (Tablet, Laptop) scannen einfach Code 1."
          : "Das Handy verbindet sich ab dann von selbst mit diesem WLAN. Es hat darüber kein Internet – fragt das Handy, ob es verbunden bleiben soll, „Ja“ wählen. Lädt die Fernbedienung nicht, kurz die mobilen Daten ausschalten."}</p>`,
      buttons: [
        { label: "Neues Passwort", action: async c => {
          if (!await confirmDialog("Neues WLAN-Passwort?", "Alle Handys müssen danach den neuen WLAN-Code scannen.", "Neues Passwort", "danger")) return;
          c(); await save({ new_password: true }); showCodes();
        } },
        { label: "Fertig", style: "primary" },
      ],
      focus: ".btn.primary",
    });
  }

  API.get("/api/hotspot").then(r => { s = r; draw(); }).catch(() => { box.remove(); });
  pageTimers.push(setInterval(() => API.get("/api/hotspot").then(r => {
    if (!s || r.active !== s.active || r.error !== s.error || r.busy !== s.busy || r.step !== s.step) { s = r; draw(); }
  }).catch(() => {}), 3000));
}
