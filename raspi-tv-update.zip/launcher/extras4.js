/* Raspi-TV OS – Fernseher & Soundbar (CEC), Sichern, Updates, Werbeblocker, DLNA */
"use strict";

// Kleine Helfer für Ein/Aus-Zeilen und Auswahl-Zeilen
function toggleRow(key, icon, label, desc, on) {
  return `<button class="row nav" data-key="${key}" id="${key}"><span class="icon">${icon}</span>
    <span class="main"><div class="label">${label}</div><div class="desc">${desc}</div></span>
    <span class="switch ${on ? "on" : ""}"></span></button>`;
}
function valueRow(key, icon, label, desc, value, cls = "") {
  return `<button class="row nav ${cls}" data-key="${key}" id="${key}"><span class="icon">${icon}</span>
    <span class="main"><div class="label">${label}</div>${desc ? `<div class="desc">${desc}</div>` : ""}</span>
    <span class="value">${value}</span></button>`;
}

// ======================================================================
// Fernseher & Soundbar (Seite „Fernbedienung“)
// ======================================================================
function addCecSection(view, token) {
  const first = view.querySelector(".page .list");
  if (!first) return;
  const box = document.createElement("div");
  box.innerHTML = `<h2>Fernseher &amp; Soundbar</h2><div class="list" id="cec-list"><div class="row static"><span class="spinner"></span></div></div>`;
  first.after(box);
  const TARGETS = [["auto", "Automatisch"], ["tv", "Fernseher"], ["soundbar", "Soundbar"], ["pi", "Raspi-TV"]];
  let c = null;

  async function save(patch) {
    try { c = await API.post("/api/cec", patch); draw(); } catch (e) { toast(e.message, "error"); }
  }
  async function act(action, ok) {
    try { await API.post("/api/cec/action", { action }); if (ok) toast(ok, "ok"); } catch (e) { toast(e.message, "error", 5000); }
  }

  function draw() {
    if (token !== renderToken || !c) return;
    if (!c.adapter) {
      $("#cec-list").innerHTML = `<div class="row static"><span class="icon">${ICON.tv}</span><span class="main">
        <div class="label">HDMI-CEC nicht verfügbar</div><div class="desc">Am Fernseher HDMI-CEC einschalten und Raspi-TV neu starten.</div></span></div>`;
      return;
    }
    const found = [c.tvname ? `Fernseher „${esc(c.tvname)}“` : "Fernseher", c.soundbar ? `Soundbar „${esc(c.soundbar)}“` : null].filter(Boolean).join(" · ");
    const eff = { tv: "den Fernseher", soundbar: "die Soundbar", pi: "Raspi-TV selbst" }[c.volume_effective] || "";
    const tgt = TARGETS.find(t => t[0] === c.volume_target) || TARGETS[0];
    $("#cec-list").innerHTML = `
      ${toggleRow("cec-wake", ICON.power, "Fernseher mit Raspi-TV einschalten", "Beim Start schaltet sich der Fernseher ein und wechselt auf Raspi-TV", c.wake_tv)}
      ${toggleRow("cec-auto", ICON.tv, "Beim Einschalten zu Raspi-TV wechseln", "Schaltest du den Fernseher ein, erscheint sofort Raspi-TV (statt des letzten Eingangs)", c.autoswitch)}
      ${valueRow("cec-vol", ICON.speaker, "Lautstärke-Tasten", `Handy-Fernbedienung, Funk-Tastatur und Air-Maus steuern ${eff}`, tgt[1])}
      ${valueRow("cec-test", ICON.sound, "Lautstärke testen", "Lauter, leiser und stumm ausprobieren", "")}
      ${valueRow("cec-off", ICON.power, "Fernseher ausschalten", found ? "Gefunden: " + found : "", "")}`;
    $("#cec-wake").addEventListener("click", () => save({ cec_wake_tv: !c.wake_tv }));
    $("#cec-auto").addEventListener("click", () => save({ cec_autoswitch: !c.autoswitch }));
    $("#cec-vol").addEventListener("click", () => {
      const i = TARGETS.findIndex(t => t[0] === c.volume_target);
      save({ volume_target: TARGETS[(i + 1) % TARGETS.length][0] });
    });
    $("#cec-test").addEventListener("click", () => openModal({
      title: "Lautstärke testen",
      text: "Hörst du die Änderung? Wenn nicht, unter „Lautstärke-Tasten“ ein anderes Gerät wählen.",
      buttons: [
        { label: "Leiser", action: () => API.post("/api/volume", { action: "down" }).catch(e => toast(e.message, "error")) },
        { label: "Stumm", action: () => API.post("/api/volume", { action: "mute" }).catch(e => toast(e.message, "error")) },
        { label: "Lauter", style: "primary", action: () => API.post("/api/volume", { action: "up" }).catch(e => toast(e.message, "error")) },
      ],
      focus: ".btn.primary",
    }));
    $("#cec-off").addEventListener("click", async () => {
      if (await confirmDialog("Fernseher ausschalten?", "Raspi-TV bleibt an. Schaltest du den Fernseher wieder ein, geht es hier weiter.", "Ausschalten")) act("tv_off");
    });
    Nav.refocus();
  }
  API.get("/api/cec").then(r => { c = r; draw(); }).catch(() => box.remove());
}

// ======================================================================
// Updates übers Internet (Seite „Updates“)
// ======================================================================
function updateProgressOverlay() {
  const o = document.createElement("div");
  o.className = "overlay";
  o.innerHTML = `<div class="spinner"></div><div id="ou-step">Update wird installiert …</div>
    <div style="font-size:1vw;color:var(--muted)">Bitte nicht ausschalten. Klappt etwas nicht, kehrt Raspi-TV automatisch zur vorherigen Version zurück.</div>`;
  document.body.appendChild(o);
  const t = setInterval(async () => {
    try {
      const s = await API.get("/api/swupdate/status");
      $("#ou-step").textContent = s.step || "…";
      if (s.error) { clearInterval(t); o.remove(); toast(s.error, "error", 9000); }
      if (s.done) {
        clearInterval(t);
        $("#ou-step").textContent = "Fertig – Raspi-TV " + (s.version || "") + " startet neu …";
        setTimeout(() => location.replace("/#/"), 25000);
      }
    } catch (_) { $("#ou-step").textContent = "Raspi-TV startet neu …"; }
  }, 1500);
}

function addOnlineUpdateSection(view, token) {
  const page = view.querySelector(".page");
  if (!page) return;
  const box = document.createElement("div");
  box.innerHTML = `<h2>Raspi-TV aktualisieren (Internet)</h2><div class="list" id="ou-list"><div class="row static"><span class="spinner"></span></div></div>`;
  page.appendChild(box);
  let s = null;

  function draw() {
    if (token !== renderToken || !s) return;
    let host = "";
    try { host = s.url ? new URL(s.url).host : ""; } catch (_) {}
    const stateTxt = s.busy ? "Suche …" : s.error ? esc(s.error)
      : s.newer ? `Version ${esc(s.latest)} ist verfügbar (installiert: ${esc(s.installed)})`
      : s.latest ? `Raspi-TV ist aktuell (Version ${esc(s.installed)})`
      : s.url ? "Noch nicht gesucht" : "Erst eine Update-Adresse eintragen";
    $("#ou-list").innerHTML = `
      ${valueRow("ou-check", ICON.update, s.newer ? `Version ${esc(s.latest)} installieren` : "Nach Updates suchen", stateTxt, s.busy ? '<span class="spinner"></span>' : "", s.newer ? "primary" : "")}
      ${valueRow("ou-url", ICON.network, "Update-Adresse", s.url ? esc(host) : "Wo dein Update-Paket im Internet liegt (z. B. GitHub-Releases)", s.url ? "Ändern" : "Eintragen")}
      ${s.url ? toggleRow("ou-auto", ICON.restart, "Automatisch installieren", "Nachts zwischen 3 und 5 Uhr, wenn der Fernseher aus ist", s.auto) : ""}`;
    $("#ou-check").addEventListener("click", async () => {
      if (!s.url) return editUrl();
      if (s.newer) {
        if (!await confirmDialog(`Version ${s.latest} installieren?`, "Raspi-TV lädt das Update, installiert es und startet neu. Klappt der Start nicht, geht es automatisch zurück zur jetzigen Version.", "Installieren")) return;
        try { await API.post("/api/online-update/install"); updateProgressOverlay(); } catch (e) { toast(e.message, "error", 7000); }
        return;
      }
      s.busy = true; draw();
      try { s = await API.post("/api/online-update/check"); } catch (e) { toast(e.message, "error"); }
      draw();
    });
    $("#ou-url").addEventListener("click", editUrl);
    const auto = $("#ou-auto");
    if (auto) auto.addEventListener("click", async () => { try { s = await API.post("/api/online-update", { auto: !s.auto }); draw(); } catch (e) { toast(e.message, "error"); } });
    Nav.refocus();
  }

  function editUrl() {
    const { el, close } = openModal({
      title: "Update-Adresse",
      top: true,
      html: `<p>Adresse deiner Datei <b>raspi-tv-update.zip</b> (aus Update-Paket.bat), z. B. als Release auf GitHub:<br>
          <small>https://github.com/NAME/raspi-tv/releases/latest/download/raspi-tv-update.zip</small></p>
        <div class="field"><input class="nav" id="ou-in" data-key="ou-in" value="${esc(s.url)}" placeholder="https://…" autocomplete="off" spellcheck="false"></div>
        <p class="ad-note">Updates werden mit vollen Rechten installiert – trag nur eine Adresse ein, unter der <b>du selbst</b> die Pakete ablegst.</p>`,
      buttons: [
        { label: "Abbrechen" },
        { label: "Speichern", style: "primary", action: async () => {
          try { s = await API.post("/api/online-update", { url: $("#ou-in", el).value.trim() }); close(); draw(); toast("Gespeichert", "ok"); }
          catch (e) { toast(e.message, "error", 6000); }
        } },
      ],
      focus: "#ou-in",
    });
  }

  API.get("/api/online-update").then(r => { s = r; draw(); if (r.job && r.job.running) updateProgressOverlay(); }).catch(() => box.remove());
}

// Vorherige Version wiederherstellen
function addRollbackSection(view, token) {
  const page = view.querySelector(".page");
  if (!page) return;
  API.get("/api/rollback").then(r => {
    if (token !== renderToken) return;
    if (r.auto_rolled_back) {
      openModal({
        title: "Update zurückgenommen",
        text: "Die neue Version ist nicht richtig gestartet. Raspi-TV ist deshalb automatisch zur vorherigen Version zurückgekehrt – deine Einstellungen sind unverändert.",
        buttons: [{ label: "OK", style: "primary", action: c => { c(); API.post("/api/rollback/ack").catch(() => {}); } }],
      });
    }
    if (!r.snapshots.length) return;
    const box = document.createElement("div");
    box.innerHTML = `<h2>Zur vorherigen Version zurück</h2><div class="list">${r.snapshots.map((x, i) =>
      valueRow("rb-" + i, ICON.restart, `Version ${esc(x.version)} wiederherstellen`, `Gesichert am ${esc(x.date)} vor einem Update`, "")).join("")}</div>`;
    page.appendChild(box);
    r.snapshots.forEach((x, i) => $("#rb-" + i).addEventListener("click", async () => {
      if (!await confirmDialog(`Zu Version ${x.version} zurück?`, "Raspi-TV spielt die gesicherte Version ein und startet neu. Deine Einstellungen bleiben erhalten.", "Zurücksetzen", "danger")) return;
      try { await API.post("/api/rollback", { file: x.file }); showOverlay("Raspi-TV startet neu …"); setTimeout(() => location.replace("/#/"), 20000); }
      catch (e) { toast(e.message, "error", 6000); }
    }));
  }).catch(() => {});
}

// ======================================================================
// Einstellungen sichern & wiederherstellen (Seite „System“)
// ======================================================================
function addBackupSection(view, token) {
  const page = view.querySelector(".page");
  if (!page) return;
  const box = document.createElement("div");
  box.innerHTML = `<h2>Sichern &amp; Wiederherstellen</h2><div class="list" id="bk-list"><div class="row static"><span class="spinner"></span></div></div>`;
  page.appendChild(box);
  let r = null;

  function fmtDate(ts) {
    return ts ? new Date(ts * 1000).toLocaleString("de-DE", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "";
  }
  function draw() {
    if (token !== renderToken || !r) return;
    $("#bk-list").innerHTML = `
      ${valueRow("bk-save", ICON.usb, "Auf USB-Stick sichern",
        r.sticks.length ? "Einstellungen, Sender, Apps, Erinnerungen und gespeicherte WLANs" : "Bitte zuerst einen USB-Stick einstecken (FAT32 oder exFAT)", "")}
      ${r.backups.map((b, i) => valueRow("bk-" + i, ICON.restart, "Wiederherstellen: " + fmtDate(b.created),
        `${esc(b.device || "Raspi-TV")} · Version ${esc(b.version || "?")} · auf „${esc(b.stick)}“`, "")).join("")}`;
    $("#bk-save").addEventListener("click", save);
    r.backups.forEach((b, i) => $("#bk-" + i).addEventListener("click", () => restore(b)));
    Nav.refocus();
  }
  async function save() {
    if (!r.sticks.length) return toast("Kein USB-Stick gefunden.", "error");
    const go = async src => {
      showOverlay("Sicherung wird gespeichert …");
      try {
        const x = await API.post("/api/backup/create", { src });
        toast(`Gesichert auf „${x.stick}“ (${x.file})`, "ok", 6000);
        r = await API.get("/api/backup"); draw();
      } catch (e) { toast(e.message, "error", 8000); }
      document.querySelectorAll(".overlay").forEach(o => o.remove());
    };
    if (r.sticks.length === 1) return go(r.sticks[0].src);
    openModal({ title: "Auf welchen Stick?", buttons: r.sticks.map(s => ({ label: s.name, action: c => { c(); go(s.src); } })) });
  }
  async function restore(b) {
    if (!await confirmDialog("Sicherung wiederherstellen?",
      `Einstellungen vom ${fmtDate(b.created)} werden übernommen, danach startet die Oberfläche neu. Anmeldungen in Netflix & Co. musst du neu eingeben.`,
      "Wiederherstellen", "danger")) return;
    try {
      const x = await API.post("/api/backup/restore", { src: b.src, file: b.file });
      showOverlay(`${x.restored} Einträge wiederhergestellt – Raspi-TV startet neu …`);
      setTimeout(() => location.replace("/#/"), 15000);
    } catch (e) { toast(e.message, "error", 8000); }
  }
  API.get("/api/backup").then(x => { r = x; draw(); }).catch(() => box.remove());
}

// ======================================================================
// Werbeblocker (Seite „Apps“)
// ======================================================================
function addAdblockRow(view, token) {
  const page = view.querySelector(".page");
  if (!page) return;
  const box = document.createElement("div");
  box.innerHTML = `<h2>Internet</h2><div class="list">${toggleRow("adblock", ICON.eye, "Werbeblocker für Webseiten",
    "Blockiert Werbung und Tracker auf normalen Webseiten (z. B. in der App „Internet“). Streaming- und Mediathek-Apps sind ausgenommen, damit sie weiter laufen.",
    !!state.config.adblock)}</div>`;
  const first = page.querySelector(".list");
  (first ? first.parentNode.insertBefore(box, first.nextSibling) : page.appendChild(box));
  $("#adblock").addEventListener("click", async () => {
    try {
      state.config = await API.post("/api/config", { adblock: !state.config.adblock });
      $("#adblock .switch").classList.toggle("on", !!state.config.adblock);
      toast(state.config.adblock ? "Werbeblocker an – wirkt nach wenigen Sekunden" : "Werbeblocker aus", "ok");
    } catch (e) { toast(e.message, "error"); }
  });
}

// ======================================================================
// DLNA (Seite „Ton“, unter „Vom Handy abspielen“)
// ======================================================================
function addDlnaRow(view, token) {
  const ap = $("#airplay");
  if (!ap) return;
  const holder = document.createElement("div");
  holder.innerHTML = toggleRow("dlna", ICON.video, "Videos &amp; Fotos vom Handy (DLNA)",
    "Lädt …", false);
  const row = holder.firstElementChild;
  ap.parentNode.appendChild(row);
  const draw = s => {
    if (token !== renderToken) return;
    row.querySelector(".switch").classList.toggle("on", s.enabled);
    row.querySelector(".desc").textContent = s.enabled
      ? `Aktiv – in Apps wie BubbleUPnP oder „Wiedergabe auf Gerät“ (Windows) „${s.name}“ wählen`
      : "Videos, Musik und Fotos vom Handy oder PC auf dem Fernseher abspielen";
  };
  let cur = null;
  API.get("/api/dlna").then(s => { cur = s; draw(s); }).catch(() => row.remove());
  row.addEventListener("click", async () => {
    try { cur = await API.post("/api/dlna", { enabled: !(cur && cur.enabled) }); draw(cur); } catch (e) { toast(e.message, "error"); }
  });
}

// ======================================================================
// Sprache (Seite „System“)
// ======================================================================
function addLanguageRow(view, token) {
  const list = view.querySelector(".page .list");
  if (!list) return;
  const holder = document.createElement("div");
  const cur = state.config.lang === "en" ? "en" : "de";
  holder.innerHTML = valueRow("lang", ICON.network, "Sprache / Language", "Deutsch · English", cur === "en" ? "English" : "Deutsch");
  const row = holder.firstElementChild;
  list.prepend(row);
  row.addEventListener("click", async () => {
    const next = (state.config.lang === "en") ? "de" : "en";
    try {
      state.config = await API.post("/api/config", { lang: next });
      I18N.set(next);
      row.querySelector(".value").textContent = next === "en" ? "English" : "Deutsch";
    } catch (e) { toast(e.message, "error"); }
  });
}
