/* Raspi-TV OS – Mitteilungen (Anrufe von der FRITZ!Box) und Einschalt-Timer */
"use strict";

// ======================================================================
// Einstellungen · Mitteilungen
// ======================================================================
function renderNotify(view, token) {
  view.innerHTML = `
    <div class="page">
      <h1>Mitteilungen</h1>
      <p class="lead">Raspi-TV blendet Wichtiges in jeder App ein – auch mitten im Film.</p>
      <h2>Anrufe</h2>
      <div class="list" id="cm-list"><div class="row static"><span class="spinner"></span></div></div>
    </div>`;
  let c = null;

  async function save(patch) {
    try { c = await API.post("/api/callmon", patch); draw(); } catch (e) { toast(e.message, "error"); }
  }

  function stateRow() {
    const S = {
      connected: ["Verbunden mit der FRITZ!Box", "Eingehende Anrufe erscheinen oben auf dem Bildschirm."],
      refused: ["Anrufmonitor der FRITZ!Box ist aus", "Einmalig an einem Telefon der FRITZ!Box #96*5* wählen – danach klappt es von selbst."],
      offline: ["Keine FRITZ!Box gefunden", "Raspi-TV sucht unter der eingetragenen Adresse. Andere Router werden nicht unterstützt."],
      off: ["Ausgeschaltet", ""],
    }[c.state] || ["Verbinde …", ""];
    return `<div class="row static"><span class="icon">${c.state === "connected" ? ICON.check : c.state === "off" ? ICON.phone : ICON.warn}</span>
      <span class="main"><div class="label">${S[0]}</div>${S[1] ? `<div class="desc">${S[1]}</div>` : ""}</span></div>`;
  }

  function draw() {
    if (token !== renderToken || !c) return;
    const key = Nav.current && Nav.current.dataset.key;
    $("#cm-list").innerHTML = `
      ${toggleRow("cm-on", ICON.phone, "Anrufe anzeigen", "Name bzw. Nummer des Anrufers erscheint in jeder App (FRITZ!Box)", c.enabled)}
      ${c.enabled ? stateRow() : ""}
      ${c.enabled ? toggleRow("cm-pause", ICON.video, "Bei Anruf Video anhalten", "Live-TV wird zwischengespeichert, Apps pausieren – nach dem Telefonat einfach weiterschauen", c.pause) : ""}
      ${c.enabled ? valueRow("cm-host", ICON.network, "Adresse der FRITZ!Box", "Nur ändern, wenn sie nicht „fritz.box“ heißt", esc(c.host)) : ""}
      ${c.enabled ? valueRow("cm-test", ICON.bell, "Testanruf anzeigen", "So sieht ein Anruf auf dem Fernseher aus", "") : ""}`;
    $("#cm-on").addEventListener("click", () => save({ enabled: !c.enabled }));
    if (c.enabled) {
      $("#cm-pause").addEventListener("click", () => save({ pause: !c.pause }));
      $("#cm-test").addEventListener("click", async () => {
        try { await API.post("/api/callmon/test"); } catch (e) { toast(e.message, "error"); }
      });
      $("#cm-host").addEventListener("click", () => {
        const { el, close } = openModal({
          title: "Adresse der FRITZ!Box",
          top: true,
          html: `<p>Meist „fritz.box“ oder „192.168.178.1“.</p>
                 <div class="field"><input class="nav" id="cm-h" data-key="cm-h" value="${esc(c.host)}" autocomplete="off" spellcheck="false"></div>`,
          buttons: [
            { label: "Abbrechen" },
            { label: "Speichern", style: "primary", action: async () => { await save({ host: $("#cm-h", el).value.trim() }); close(); } },
          ],
          focus: "#cm-h",
        });
      });
    }
    const again = key && $("#cm-list").querySelector(`[data-key="${key}"]`);
    if (again) Nav.focus(again, false); else Nav.restore();
  }

  API.get("/api/callmon").then(r => { c = r; draw(); }).catch(e => toast(e.message, "error"));
  // Verbindungsstatus aktuell halten
  pageTimers.push(setInterval(() => {
    API.get("/api/callmon").then(r => {
      if (!c || r.state !== c.state) { c = r; draw(); }
    }).catch(() => {});
  }, 5000));
}

// ======================================================================
// Energie: Einschalt-Timer und nächtlicher Neustart
// ======================================================================
const WAKE_DAYS = [
  [[1, 2, 3, 4, 5], "Montag bis Freitag"],
  [[1, 2, 3, 4, 5, 6, 7], "Jeden Tag"],
  [[6, 7], "Samstag und Sonntag"],
];

function wakeDaysLabel(days) {
  const k = days.join(",");
  const p = WAKE_DAYS.find(d => d[0].join(",") === k);
  if (p) return p[1];
  const N = ["", "Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];
  return days.map(d => N[d]).join(", ") || "Nie";
}

function addWakeSection(view, token) {
  const page = view.querySelector(".page");
  if (!page) return;
  const box = document.createElement("div");
  box.innerHTML = `<h2>Einschalten</h2><div class="list" id="wk-list"><div class="row static"><span class="spinner"></span></div></div>
    <h2>Wartung</h2><div class="list" id="wk-list2"></div>`;
  page.appendChild(box);
  let w = null;

  async function save(patch) {
    try { w = await API.post("/api/wake", patch); draw(); } catch (e) { toast(e.message, "error"); }
  }

  function nextLabel() {
    if (!w.enabled || !w.next) return "Aus";
    const d = new Date(w.next * 1000);
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const diff = Math.round((new Date(d).setHours(0, 0, 0, 0) - today) / 86400000);
    const day = diff === 0 ? "heute" : diff === 1 ? "morgen" : ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"][d.getDay()];
    return `Nächstes Mal ${day} um ${w.time} Uhr`;
  }

  function shiftTime(min) {
    const [h, m] = w.time.split(":").map(Number);
    let t = (h * 60 + m + min + 1440) % 1440;
    t = Math.round(t / 5) * 5 % 1440;
    return String(Math.floor(t / 60)).padStart(2, "0") + ":" + String(t % 60).padStart(2, "0");
  }

  function pickChannel() {
    const opts = ["", ...w.channels];
    const { el, close } = openModal({
      title: "Was soll laufen?",
      top: true,
      html: `<div class="list mlist">${opts.map((n, i) => `
        <button class="row nav${n === w.channel ? " current" : ""}" data-key="wkc-${i}" data-i="${i}">
          <span class="icon">${n ? ICON.live : ICON.tv}</span><span class="main"><div class="label">${n ? esc(n) : "Startseite"}</div></span>
          ${n === w.channel ? `<span class="value">${ICON.check}</span>` : ""}</button>`).join("")}</div>`,
      buttons: [{ label: "Abbrechen" }],
      focus: ".mlist .row.current",
    });
    el.querySelectorAll(".mlist .row").forEach(b => b.addEventListener("click", () => {
      close();
      save({ channel: opts[+b.dataset.i] });
    }));
  }

  function draw() {
    if (token !== renderToken || !w) return;
    const key = Nav.current && Nav.current.dataset.key;
    $("#wk-list").innerHTML = `
      ${toggleRow("wk-on", ICON.power, "Einschalt-Timer", w.enabled ? nextLabel() : "Schaltet Fernseher und Raspi-TV zur eingestellten Zeit ein – z. B. morgens die Nachrichten", w.enabled)}
      ${w.enabled ? valueRow("wk-time", ICON.update, "Uhrzeit", "◀ ▶ in 5-Minuten-Schritten · OK +1 Stunde", w.time + " Uhr") : ""}
      ${w.enabled ? valueRow("wk-days", ICON.guide, "An welchen Tagen", "OK wechselt", wakeDaysLabel(w.days)) : ""}
      ${w.enabled ? valueRow("wk-ch", ICON.live, "Was soll laufen?", "Sender oder Startseite", esc(w.channel || "Startseite")) : ""}`;
    $("#wk-list2").innerHTML = toggleRow("wk-night", ICON.restart, "Nachts automatisch neu starten",
      "Um 4 Uhr, wenn der Fernseher aus ist – hält Raspi-TV dauerhaft frisch", w.nightly);
    $("#wk-on").addEventListener("click", () => save({ enabled: !w.enabled }));
    $("#wk-night").addEventListener("click", () => save({ nightly: !w.nightly }));
    if (w.enabled) {
      const t = $("#wk-time");
      t._adjust = d => {
        w.time = shiftTime(d > 0 ? 5 : -5);
        t.querySelector(".value").textContent = w.time + " Uhr";
        clearTimeout(t._save);
        t._save = setTimeout(() => save({ time: w.time }), 700);
      };
      t.addEventListener("click", () => save({ time: shiftTime(60) }));
      $("#wk-days").addEventListener("click", () => {
        const i = WAKE_DAYS.findIndex(d => d[0].join(",") === w.days.join(","));
        save({ days: WAKE_DAYS[(i + 1) % WAKE_DAYS.length][0] });
      });
      $("#wk-ch").addEventListener("click", pickChannel);
    }
    const again = key && view.querySelector(`[data-key="${key}"]`);
    if (again) Nav.focus(again, false);
  }

  API.get("/api/wake").then(r => { w = r; draw(); Nav.restore(); }).catch(e => toast(e.message, "error"));
}

// ======================================================================
// Einstellungen · Handy: Raspi-TV-App für ältere Android-Handys (Bluetooth, ohne WLAN)
// ======================================================================
function addBtAppSection(view, token) {
  const page = view.querySelector(".page");
  if (!page) return;
  const box = document.createElement("div");
  box.innerHTML = `<h2>Altes Android-Handy als feste Fernbedienung</h2>
    <p class="hs-lead">Die Raspi-TV-App (ab Android 4.4) steuert über <b>Bluetooth</b> – ganz ohne WLAN.
      Sie kann als Startbildschirm des Handys eingestellt werden: Handy an = Fernbedienung.</p>
    <div class="list" id="bta-list"><div class="row static"><span class="spinner"></span></div></div>`;
  page.appendChild(box);
  let s = null, addr = null;

  function draw() {
    if (token !== renderToken || !s) return;
    const key = Nav.current && Nav.current.dataset.key;
    const phones = s.phones.map((p, i) => {
      const on = s.connected.some(c => c.mac === p.mac);
      return valueRow("bta-p" + i, ICON.phone, esc(p.name), on ? "Verbunden" : "Gekoppelt · OK entfernt das Handy", on ? "●" : "");
    }).join("");
    $("#bta-list").innerHTML = `
      ${valueRow("bta-dl", ICON.download, "1 · App aufs Handy laden", "QR-Code mit dem Handy scannen (Handy kurz im WLAN) – oder die Datei raspi-tv-remote.apk vom PC kopieren", "")}
      ${valueRow("bta-pair", ICON.bt, "2 · Handy-App koppeln",
        s.window ? `Raspi-TV ist jetzt sichtbar – in der App „Raspi-TV auswählen“ tippen und „${esc(s.name)}“ wählen` : "Macht Raspi-TV 3 Minuten lang sichtbar, dann in der App „Raspi-TV auswählen“",
        s.window ? Math.floor(s.window / 60) + ":" + String(s.window % 60).padStart(2, "0") : "")}
      ${s.error && !s.listening ? `<div class="row static"><span class="icon">${ICON.warn}</span><span class="main"><div class="label">Bluetooth-Empfang nicht bereit</div><div class="desc">${esc(s.error)}</div></span></div>` : ""}
      ${phones}
      ${s.drops && s.drops.length ? `<div class="row static"><span class="icon">${ICON.warn}</span><span class="main"><div class="label">Verbindungsabbrüche (24 h): ${s.drops.length}</div><div class="desc">${esc(s.drops.slice(-3).reverse().map(d => new Date(d.at * 1000).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" }) + " · " + d.name + " · " + d.reason + " (nach " + (d.secs >= 120 ? Math.round(d.secs / 60) + " min" : d.secs + " s") + ")").join(" · "))}</div></span></div>` : ""}`;
    $("#bta-dl").addEventListener("click", showDownload);
    $("#bta-pair").addEventListener("click", async () => {
      try { s = await API.post("/api/btremote/window"); last = JSON.stringify(s); draw(); toast("Raspi-TV ist 3 Minuten lang sichtbar", "ok"); }
      catch (e) { toast(e.message, "error"); }
    });
    s.phones.forEach((p, i) => $("#bta-p" + i).addEventListener("click", async () => {
      if (!await confirmDialog(p.name + " entfernen?", "Das Handy kann Raspi-TV danach erst nach erneutem Koppeln steuern.", "Entfernen", "danger")) return;
      try { s = await API.post("/api/btremote/forget", { mac: p.mac }); last = JSON.stringify(s); draw(); } catch (e) { toast(e.message, "error"); }
    }));
    const again = key && view.querySelector(`[data-key="${key}"]`);
    if (again) Nav.focus(again, false);
  }

  function showDownload() {
    if (!addr) return toast("Erst mit dem Heimnetz verbinden", "error");
    const url = addr + "/raspi-tv-remote.apk";
    const q = qrcode(0, "M"); q.addData(url); q.make();
    openModal({
      title: "Raspi-TV-App aufs Handy laden",
      html: `<div class="setup-split" style="gap:3vw;align-items:center">
          <div class="qr" style="width:20vw;background:#fff;padding:.6vw;border-radius:1vw">${q.createSvgTag({ cellSize: 8, margin: 2, scalable: true })}</div>
          <div><p>1. Handy kurz ins WLAN (Heim- oder Fernbedienungs-WLAN) und den Code scannen.</p>
            <p>2. Die Datei öffnen. Fragt Android nach „Unbekannte Herkunft“: in den Einstellungen erlauben.</p>
            <p>3. App öffnen – danach braucht sie kein WLAN mehr.</p>
            <p class="desc">${esc(url)}</p></div></div>`,
      buttons: [{ label: "Fertig", style: "primary" }],
    });
  }

  let last = "";
  async function load() {
    try {
      const r = await API.get("/api/btremote");
      const j = JSON.stringify(r);
      if (j === last) return;          // nur neu zeichnen, wenn sich etwas geändert hat
      last = j; s = r; draw();
    } catch (_) {}
  }
  API.get("/api/remote").then(r => { addr = r.address; }).catch(() => {});
  load();
  pageTimers.push(setInterval(load, 2000));
}
