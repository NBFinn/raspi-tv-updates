/* Raspi-TV OS – Nachrichten, Bildschirmschoner-Stile, Systemmonitor und Geschwindigkeitstest */
"use strict";

// ======================================================================
// Nachrichten
// ======================================================================
const News = {
  data: null, at: 0,
  async load() {
    if (this.data && Date.now() - this.at < 10 * 60000) return this.data;
    try { this.data = await API.get("/api/news"); this.at = Date.now(); } catch (_) {}
    return this.data;
  },
};

function newsAgo(ts) {
  if (!ts) return "";
  const m = Math.round((Date.now() / 1000 - ts) / 60);
  if (m < 1) return "gerade eben";
  if (m < 60) return "vor " + m + " Min.";
  if (m < 24 * 60) return "vor " + Math.round(m / 60) + " Std.";
  return hhmm(ts);
}

async function loadNewsStrip(box, token) {
  const d = await News.load();
  if (token !== renderToken || !box || !d || !d.items || !d.items.length) return;
  const sec = $("#sec-news");
  sec.hidden = false; box.hidden = false;
  sec.innerHTML = `Nachrichten <small>· ${esc(d.source)}</small>`;
  box.innerHTML = d.items.slice(0, 10).map((n, i) => `
    <button class="news-card nav" data-key="news-${i}" data-i="${i}">
      <span class="news-time">${esc(newsAgo(n.time))}</span>
      <span class="news-title">${esc(n.title)}</span>
      <span class="news-desc">${esc(n.desc)}</span>
    </button>`).join("");
  box.querySelectorAll("[data-i]").forEach(el => el.addEventListener("click", () => {
    const n = d.items[+el.dataset.i];
    openModal({
      title: n.title,
      html: `<div class="detail-meta">${esc(d.source)} · ${esc(newsAgo(n.time))}</div><p class="detail-desc">${esc(n.desc || "")}</p>`,
      buttons: [{ label: "Schließen" }].concat(n.link ? [{ label: "Ganzen Artikel lesen", style: "primary", action: c => { c(); location.href = n.link; } }] : []),
      focus: ".btn:last-child",
    });
  }));
  Nav.refocus();
}

// ======================================================================
// Bildschirmschoner: weitere Stile und Nachrichtenzeile
// ======================================================================
Saver._showClassic = Saver.show;

Saver.show = async function () {
  if (this.el) return;
  const style = state.config.saver_style || "classic";
  if (style === "classic") {
    await this._showClassic();
  } else {
    const el = document.createElement("div");
    el.className = "saver saver-" + style;
    document.body.appendChild(el);
    this.el = el;
    if (style === "analog") this._analog(el);
    else if (style === "photos") await this._photos(el);
    else this._dark(el);
  }
  if (this.el && state.config.saver_news !== false && style !== "dark") this._ticker(this.el);
};

Saver._analog = function (el) {
  const marks = Array.from({ length: 60 }, (_, i) => {
    const big = i % 5 === 0;
    return `<line x1="100" y1="${big ? 12 : 14}" x2="100" y2="${big ? 24 : 18}" transform="rotate(${i * 6} 100 100)" class="${big ? "mk big" : "mk"}"/>`;
  }).join("");
  el.innerHTML = `<div class="saver-bg"></div><div class="saver-bg b2"></div>
    <div class="analog"><svg viewBox="0 0 200 200">
      <circle cx="100" cy="100" r="96" class="face"/>${marks}
      <line id="an-h" x1="100" y1="100" x2="100" y2="52" class="hand h"/>
      <line id="an-m" x1="100" y1="100" x2="100" y2="30" class="hand m"/>
      <line id="an-s" x1="100" y1="112" x2="100" y2="24" class="hand s"/>
      <circle cx="100" cy="100" r="4" class="pin"/></svg>
      <div class="an-date" id="an-date"></div></div>
    <div class="saver-hint">Beliebige Taste drücken</div>`;
  const tick = () => {
    if (!this.el) return;
    const d = new Date();
    const s = d.getSeconds(), m = d.getMinutes() + s / 60, h = d.getHours() % 12 + m / 60;
    el.querySelector("#an-h").setAttribute("transform", `rotate(${h * 30} 100 100)`);
    el.querySelector("#an-m").setAttribute("transform", `rotate(${m * 6} 100 100)`);
    el.querySelector("#an-s").setAttribute("transform", `rotate(${s * 6} 100 100)`);
    el.querySelector("#an-date").textContent = d.toLocaleDateString(I18N.lang === "en" ? "en-GB" : "de-DE", { weekday: "long", day: "numeric", month: "long" });
  };
  tick();
  this.rot = setInterval(tick, 1000);
};

Saver._photos = async function (el) {
  let photos = [];
  try { photos = (await API.get("/api/saver/photos")).photos; } catch (_) {}
  if (!this.el) return;
  if (!photos.length) {
    el.innerHTML = `<div class="saver-bg"></div><div class="saver-bg b2"></div><div class="ph-empty">
      <b>Keine Fotos gefunden</b><span>Steck einen USB-Stick mit Fotos an – dann laufen sie hier als Diashow.</span></div>
      <div class="saver-hint">Beliebige Taste drücken</div>`;
    return;
  }
  el.innerHTML = `<div class="ph-layer" id="ph-a"></div><div class="ph-layer" id="ph-b"></div>
    <div class="ph-clock" id="ph-clock"></div><div class="saver-hint">Beliebige Taste drücken</div>`;
  let i = 0, front = "a";
  const show = () => {
    if (!this.el) return;
    const p = photos[i++ % photos.length];
    const url = `/media/file?src=${encodeURIComponent(p.src)}&path=${encodeURIComponent(p.path)}`;
    const img = new Image();
    img.onload = () => {
      if (!this.el) return;
      const back = front === "a" ? "b" : "a";
      const layer = el.querySelector("#ph-" + back);
      layer.style.backgroundImage = `url("${url}")`;
      layer.classList.remove("kb"); void layer.offsetWidth; layer.classList.add("kb");
      layer.classList.add("on");
      el.querySelector("#ph-" + front).classList.remove("on");
      front = back;
    };
    img.onerror = () => setTimeout(show, 200);
    img.src = url;
    const d = new Date();
    el.querySelector("#ph-clock").textContent = String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
  };
  show();
  this.rot = setInterval(show, 12000);
};

// Fast schwarz, kleine Uhr wandert langsam (schont OLED-Fernseher)
Saver._dark = function (el) {
  el.innerHTML = `<div class="dk-clock" id="dk-clock"></div>`;
  const move = () => {
    if (!this.el) return;
    const d = new Date();
    const c = el.querySelector("#dk-clock");
    c.textContent = String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
    c.style.left = (8 + Math.random() * 70) + "vw";
    c.style.top = (10 + Math.random() * 70) + "vh";
  };
  move();
  this.rot = setInterval(move, 60000);
};

Saver._ticker = async function (el) {
  const d = await News.load();
  if (!this.el || this.el !== el || !d || !d.items || !d.items.length) return;
  const t = document.createElement("div");
  t.className = "saver-news";
  t.innerHTML = `<span class="sn-src">${esc(d.source)}</span><span class="sn-run"><span>${d.items.slice(0, 12).map(n => esc(n.title)).join('<i>•</i>')}</span></span>`;
  el.appendChild(t);
};

// ======================================================================
// Energie: Stil des Bildschirmschoners
// ======================================================================
const SAVER_STYLES = [["classic", "Uhr & Programm"], ["analog", "Analoge Uhr"], ["photos", "Fotos vom USB-Stick"], ["dark", "Dunkel (schont OLED)"]];

function addSaverStyleRows(view, token) {
  const list = view.querySelector(".page .list");
  if (!list) return;
  const holder = document.createElement("div");
  const lbl = () => (SAVER_STYLES.find(s => s[0] === (state.config.saver_style || "classic")) || SAVER_STYLES[0])[1];
  holder.innerHTML = valueRow("ss-style", ICON.picture, "Stil des Bildschirmschoners", "Uhr · Fotos · Polarlicht · Sternenflug · Lavalampe · Musikvisualisierung", lbl())
    + toggleRow("ss-news", ICON.list, "Nachrichten im Bildschirmschoner", "Schlagzeilen laufen unten durchs Bild", state.config.saver_news !== false);
  const ref = list.querySelector("#e-try");
  [...holder.children].forEach(c => list.insertBefore(c, ref));
  $("#ss-style").addEventListener("click", async () => {
    const i = SAVER_STYLES.findIndex(s => s[0] === (state.config.saver_style || "classic"));
    const next = SAVER_STYLES[(i + 1) % SAVER_STYLES.length][0];
    try { state.config = await API.post("/api/config", { saver_style: next }); $("#ss-style .value").textContent = lbl(); }
    catch (e) { toast(e.message, "error"); }
  });
  $("#ss-news").addEventListener("click", async () => {
    try {
      state.config = await API.post("/api/config", { saver_news: state.config.saver_news === false });
      $("#ss-news .switch").classList.toggle("on", state.config.saver_news !== false);
    } catch (e) { toast(e.message, "error"); }
  });
}

// ======================================================================
// System: Systemmonitor und Internet-Geschwindigkeit
// ======================================================================
function addSysmonSection(view, token) {
  const page = view.querySelector(".page");
  if (!page) return;
  const box = document.createElement("div");
  box.innerHTML = `<h2>Systemmonitor</h2>
    <div class="mon-grid" id="mon">
      <div class="mon"><span class="mk">Prozessor</span><b id="mon-cpu">–</b><span class="mbar"><i id="mon-cpu-bar"></i></span></div>
      <div class="mon"><span class="mk">Temperatur</span><b id="mon-temp">–</b><span class="mbar"><i id="mon-temp-bar"></i></span></div>
      <div class="mon"><span class="mk">Arbeitsspeicher</span><b id="mon-mem">–</b><span class="mbar"><i id="mon-mem-bar"></i></span></div>
      <div class="mon"><span class="mk">Speicherkarte</span><b id="mon-disk">–</b><span class="mbar"><i id="mon-disk-bar"></i></span></div>
    </div>
    <div class="list" id="mon-warn"></div>
    <h2>Internet</h2>
    <div class="list">
      ${valueRow("speed", ICON.network, "Internet-Geschwindigkeit testen", "Misst Download, Upload und Antwortzeit (dauert ca. 20 Sekunden)", "")}
    </div>`;
  // vor „Beim Einschalten“ einfügen
  const anchor = page.querySelector("h2");
  page.insertBefore(box, anchor);
  const bar = (id, pct, warn) => {
    const i = $("#" + id);
    if (!i) return;
    i.style.width = Math.max(2, Math.min(100, pct)) + "%";
    i.classList.toggle("warn", !!warn);
  };

  async function tick() {
    if (token !== renderToken) return;
    let m;
    try { m = await API.get("/api/sysmon"); } catch (_) { return; }
    if (token !== renderToken || !$("#mon-cpu")) return;
    if (m.cpu != null) { $("#mon-cpu").textContent = Math.round(m.cpu) + " %"; bar("mon-cpu-bar", m.cpu, m.cpu > 85); }
    if (m.temp != null) { $("#mon-temp").textContent = m.temp.toFixed(1).replace(".", ",") + " °C"; bar("mon-temp-bar", (m.temp - 30) / 55 * 100, m.temp > 75); }
    else $("#mon-temp").textContent = "–";
    if (m.mem_total) { const u = 100 - m.mem_free / m.mem_total * 100; $("#mon-mem").textContent = Math.round(u) + " %"; bar("mon-mem-bar", u, u > 90); }
    if (m.disk_total) { const u = 100 - m.disk_free / m.disk_total * 100; $("#mon-disk").textContent = fmtBytes(m.disk_free) + " frei"; bar("mon-disk-bar", u, u > 92); }
    const t = m.throttle;
    const warns = [];
    if (t && (t.undervoltage_now || t.undervoltage_past)) warns.push(["Unterspannung " + (t.undervoltage_now ? "gerade jetzt" : "seit dem Start") + " erkannt",
      "Das Netzteil ist zu schwach oder das Kabel zu dünn. Ein offizielles Raspberry-Pi-Netzteil verhindert Ruckler und Abstürze."]);
    if (t && (t.throttled_now || t.throttled_past)) warns.push(["Der Pi hat sich " + (t.throttled_now ? "gerade" : "zwischendurch") + " gedrosselt",
      "Meist wegen Wärme oder Unterspannung. Ein Gehäuse mit Lüfter oder Kühlkörper hilft."]);
    if (m.temp != null && m.temp > 80) warns.push(["Sehr warm (" + Math.round(m.temp) + " °C)", "Für gute Belüftung sorgen – nicht hinter dem Fernseher einklemmen."]);
    $("#mon-warn").innerHTML = warns.map(([a, b]) => `<div class="row static warn"><span class="icon">${ICON.warn}</span>
      <span class="main"><div class="label">${esc(a)}</div><div class="desc">${esc(b)}</div></span></div>`).join("");
  }
  tick();
  pageTimers.push(setInterval(tick, 3000));

  let polling = null;
  $("#speed").addEventListener("click", async () => {
    try { await API.post("/api/speedtest"); } catch (e) { return toast(e.message, "error"); }
    clearInterval(polling);
    polling = setInterval(show, 700);
    pageTimers.push(polling);
    show();
  });
  async function show() {
    let s;
    try { s = await API.get("/api/speedtest"); } catch (_) { return; }
    if (token !== renderToken || !$("#speed")) return clearInterval(polling);
    const ph = { ping: "Antwortzeit …", down: "Download …", up: "Upload …" }[s.phase] || "";
    const parts = [];
    if (s.down != null) parts.push("↓ " + String(s.down).replace(".", ",") + " Mbit/s");
    if (s.up != null) parts.push("↑ " + String(s.up).replace(".", ",") + " Mbit/s");
    if (s.ping != null) parts.push(s.ping + " ms");
    $("#speed .value").textContent = s.running ? (ph + (parts.length ? "  " + parts.join(" · ") : "")) : (s.error || parts.join(" · "));
    if (!s.running) {
      clearInterval(polling);
      if (!s.error && s.down != null) {
        const v = s.down;
        const verdict = v >= 25 ? "Reicht für alles, auch HD-Streaming auf mehreren Geräten." : v >= 8 ? "Reicht für HD-Streaming." : v >= 3 ? "Reicht für normale Bildqualität." : "Eher langsam – Streams können ruckeln.";
        $("#speed .desc").textContent = verdict;
      }
    }
  }
  API.get("/api/speedtest").then(s => { if (s.at && !s.running) show(); }).catch(() => {});
}
