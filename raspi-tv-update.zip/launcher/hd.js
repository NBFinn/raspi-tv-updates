/* Raspi-TV OS 6.0 – Hintergrundbilder, Ambient-Videos, Schnellmenü, Weckbildschirm,
 * gleitender Fokus-Schein. Wird nach main.js geladen und erweitert die bestehenden Module. */
"use strict";

// ======================================================================
// Medienbibliothek (4K-Hintergründe und Ambient-Szenen, liegen unter media/)
// ======================================================================
const Media = {
  _walls: null, _scenes: null,
  async walls() {
    if (!this._walls) this._walls = fetch("media/wallpapers.json").then(r => r.json()).catch(() => []);
    return this._walls;
  },
  async scenes() {
    if (!this._scenes) this._scenes = fetch("media/ambient.json").then(r => r.json()).catch(() => []);
    return this._scenes;
  },
};

// ======================================================================
// Hintergrundbild
// ======================================================================
const Wall = {
  DEFAULT: "aurora-nordlicht",
  el: null, shown: "",

  // gewähltes Bild (bei „Täglich wechseln“ jeden Tag ein anderes)
  async pick(c) {
    const list = await Media.walls();
    if (!list.length) return null;
    if (c.wallpaper_rotate) {
      const day = Math.floor((Date.now() - new Date().getTimezoneOffset() * 60000) / 86400000);
      return list[day % list.length];
    }
    return list.find(w => w.id === c.wallpaper) || list.find(w => w.id === Wall.DEFAULT) || list[0];
  },

  async apply(c) {
    c = c || {};
    if ((c.background || Look.current.background) !== "wallpaper") return;
    const w = await this.pick(c);
    if (!w) return;
    // 4K nur auf 4K-Bildschirmen laden, sonst die 1080p-Fassung (schneller, weniger Speicher)
    const big = screen.width * (window.devicePixelRatio || 1) > 2000;
    const src = big ? w.file : (w.hd || w.file);
    if (src === this.shown) return;
    this.shown = src;
    if (!this.el) {
      this.el = document.createElement("div");
      this.el.id = "wall";
      document.body.prepend(this.el);
    }
    const img = new Image();
    img.alt = "";
    img.decoding = "async";
    img.src = src;
    try { await img.decode(); } catch (_) { return; }
    if (this.shown !== src) return;
    const old = [...this.el.querySelectorAll("img")];
    this.el.appendChild(img);
    requestAnimationFrame(() => img.classList.add("on"));
    setTimeout(() => old.forEach(o => o.remove()), 1400);
  },
};

// Look erweitern: neue Hintergrund-Art „Hintergrundbild“ (Standard ab 6.0)
Look.BG.unshift(["wallpaper", "Hintergrundbild"]);
(function () {
  const cfg0 = Look.cfg, apply0 = Look.apply;
  Look.cfg = c => {
    const r = cfg0(c);
    if (!c || !c.background) r.background = "wallpaper";
    r.wallpaper = (c && c.wallpaper) || Wall.DEFAULT;
    r.wallpaper_rotate = !!(c && c.wallpaper_rotate);
    return r;
  };
  Look.apply = c => {
    apply0(c);
    const k = Look.cfg(c);
    document.documentElement.dataset.bg = k.background;
    if (k.accent === "theme" && k.theme === "midnight") document.documentElement.dataset.hdBrand = "";
    else delete document.documentElement.dataset.hdBrand;
    Wall.apply(k);
  };
  try { Look.apply(JSON.parse(localStorage.getItem("raspi-tv.look") || "null")); } catch (_) { Look.apply(); }
  // um Mitternacht neu wählen (Täglich wechseln)
  setInterval(() => { if (Look.cfg(state.config).wallpaper_rotate) Wall.apply(Look.cfg(state.config)); }, 10 * 60000);
})();

// Einstellungen · Design & Aufbau: Bilder zum Auswählen
function addWallpaperSection(view, token) {
  const page = view.querySelector(".page");
  if (!page) return;
  const box = document.createElement("div");
  box.innerHTML = `<h2>Hintergrundbild <span class="hd-badge">NEU</span></h2>
    <div class="wp-strip" id="wp-strip"><div class="empty">Lade Bilder …</div></div>
    <div class="list" id="wp-rows"></div>`;
  const first = page.querySelector("h2:nth-of-type(2)");
  page.insertBefore(box, first);

  async function save(patch) {
    state.config = Object.assign({}, state.config, patch);
    Look.apply(state.config);
    mark();
    try { state.config = await API.post("/api/config", patch); Look.apply(state.config); } catch (e) { toast(e.message, "error"); }
  }
  function mark() {
    const k = Look.cfg(state.config);
    box.querySelectorAll("[data-wp]").forEach(b => b.classList.toggle("selected",
      b.dataset.wp === "" ? k.background !== "wallpaper" : k.background === "wallpaper" && !k.wallpaper_rotate && b.dataset.wp === k.wallpaper));
    const focusKey = Nav.current && Nav.current.dataset.key;
    $("#wp-rows").innerHTML = toggleRow("wp-rot", ICON.restart, "Jeden Tag ein anderes Bild",
      "Raspi-TV wechselt um Mitternacht automatisch", k.background === "wallpaper" && k.wallpaper_rotate);
    $("#wp-rot").addEventListener("click", () => save({ background: "wallpaper", wallpaper_rotate: !Look.cfg(state.config).wallpaper_rotate }));
    const again = focusKey && view.querySelector(`[data-key="${focusKey}"]`);
    if (again && (!Nav.current || !document.contains(Nav.current))) Nav.focus(again, false);
  }
  Media.walls().then(list => {
    if (token !== renderToken) return;
    $("#wp-strip").innerHTML = `<button class="wp-card none nav" data-key="wp-none" data-wp="">Ohne Bild</button>` +
      list.map(w => `<button class="wp-card nav" data-key="wp-${esc(w.id)}" data-wp="${esc(w.id)}">
        <img loading="lazy" decoding="async" src="${esc(w.thumb)}" alt=""><span>${esc(w.name)}</span></button>`).join("");
    box.querySelectorAll("[data-wp]").forEach(b => b.addEventListener("click", () => {
      if (!b.dataset.wp) return save({ background: "glow" });
      save({ background: "wallpaper", wallpaper: b.dataset.wp, wallpaper_rotate: false });
    }));
    mark();
  });
  mark();
}
ROUTES.look = { render: (v, t) => { renderLook(v, t); addWallpaperSection(v, t); }, crumb: ROUTES.look.crumb };

// ======================================================================
// Ambient-Videos: Bildschirmschoner-Stil „Ambient-Video“ und Musikansicht
// ======================================================================
SAVER_STYLES.unshift(["video", "Ambient-Video (bewegte Szenen)"]);
const VideoSaver = {
  el: null, scenes: [], i: 0, timer: null,

  async show(opts = {}) {
    if (this.el || Saver.el) return;
    this.scenes = await Media.scenes();
    if (!this.scenes.length) return false;
    const want = opts.scene || state.config.ambient_scene;
    this.i = Math.max(0, this.scenes.findIndex(s => s.id === want));
    const el = document.createElement("div");
    el.className = "saver vsaver" + (opts.cls ? " " + opts.cls : "");
    el.innerHTML = `<video muted loop playsinline preload="auto"></video><video muted loop playsinline preload="none"></video>
      <div class="vs-info">${opts.head || ""}<div class="vs-time"></div><div class="vs-date"></div>${opts.extra || ""}<div class="vs-track"></div></div>
      <div class="vs-scene"></div><div class="vs-hint">${opts.hint || "◀ ▶ Szene wechseln · andere Taste: zurück"}</div>`;
    document.body.appendChild(el);
    this.el = el;
    Saver.el = el;           // Saver erkennt: Schoner läuft (Tasten schließen ihn)
    Saver.rot = setInterval(() => this.tick(), 1000);
    this.tick();
    this.play(this.i, false);
    return true;
  },

  play(i, label = true) {
    const el = this.el;
    if (!el) return;
    this.i = (i + this.scenes.length) % this.scenes.length;
    const s = this.scenes[this.i];
    const [a, b] = el.querySelectorAll("video");
    const next = a.classList.contains("on") ? b : a, prev = next === a ? b : a;
    next.src = s.file;
    next.play().catch(() => {});
    next.addEventListener("playing", () => { next.classList.add("on"); prev.classList.remove("on"); setTimeout(() => { if (!prev.classList.contains("on")) { prev.pause(); prev.removeAttribute("src"); prev.load(); } }, 1500); }, { once: true });
    if (label) {
      const tag = el.querySelector(".vs-scene");
      tag.textContent = s.name;
      tag.classList.add("show");
      clearTimeout(this.timer);
      this.timer = setTimeout(() => tag.classList.remove("show"), 2500);
    }
  },

  tick() {
    const el = this.el;
    if (!el) return;
    const d = new Date(), en = I18N.lang === "en";
    el.querySelector(".vs-time").textContent = d.toLocaleTimeString(en ? "en-GB" : "de-DE", { hour: "2-digit", minute: "2-digit" });
    el.querySelector(".vs-date").textContent = d.toLocaleDateString(en ? "en-GB" : "de-DE", { weekday: "long", day: "numeric", month: "long" });
    const sp = SpotifyNow.cur, radio = Radio.current;
    const box = el.querySelector(".vs-track");
    let html = "";
    if (sp && sp.title && (sp.playing || sp.paused)) {
      html = `${sp.cover ? `<img src="${esc(sp.cover)}" alt="">` : `<span class="ph">${ICON.music}</span>`}<div><small>Spotify${sp.paused ? " · Pause" : ""}</small><b>${esc(sp.title)}</b><i>${esc(sp.artist || "")}</i></div>`;
    } else if (radio) {
      html = `${radio.logo ? `<img src="${esc(radio.logo)}" alt="">` : `<span class="ph">${ICON.music}</span>`}<div><small>Radio${Radio.state === "paused" ? " · Pause" : ""}</small><b>${esc(radio.name)}</b><i>${esc(radio.genre || "")}</i></div>`;
    }
    if (box.dataset.h !== html) { box.dataset.h = html; box.innerHTML = html; }
  },

  hide() {
    const el = this.el;
    this.el = null;
    clearTimeout(this.timer);
    if (!el) return;
    el.querySelectorAll("video").forEach(v => { v.pause(); v.removeAttribute("src"); v.load(); });
  },
};
(function () {
  const show0 = Saver.show, hide0 = Saver.hide;
  Saver.show = function () {
    if ((state.config.saver_style || "") === "video") return VideoSaver.show();
    return show0.apply(this, arguments);
  };
  Saver.hide = function () {
    if (VideoSaver.el) VideoSaver.hide();
    return hide0.apply(this, arguments);
  };
})();
// ◀ ▶ wechselt die Szene (vor dem allgemeinen „Taste beendet Schoner“)
document.addEventListener("keydown", e => {
  if (!VideoSaver.el || !["ArrowLeft", "ArrowRight"].includes(e.key)) return;
  e.preventDefault(); e.stopImmediatePropagation();
  VideoSaver.play(VideoSaver.i + (e.key === "ArrowRight" ? 1 : -1));
  Saver.idleSince = Date.now();
}, true);

// ======================================================================
// Weckbildschirm (Einschalt-Timer mit Radio oder Ambient-Szene)
// ======================================================================
const Wakeup = {
  async start(q) {
    const radioName = q.get("radio") || "";
    const gentle = q.get("gentle") !== "0";
    const h = new Date().getHours();
    const hello = h < 11 ? "Guten Morgen" : h < 18 ? "Guten Tag" : "Guten Abend";
    Saver.hide();
    const ok = await VideoSaver.show({ scene: q.get("scene") || "", cls: "wakeup",
      head: `<div class="wk-hello">${hello}</div>`, extra: `<div class="wk-wx"></div>`, hint: "Beliebige Taste: zur Startseite" });
    if (!ok) return;
    API.get("/api/weather").then(w => {
      const k = wmo(w.code), box = VideoSaver.el && VideoSaver.el.querySelector(".wk-wx");
      if (box) box.textContent = `${fmtTemp(w.temp)} · ${k.text} in ${w.place}`;
    }).catch(() => {});
    if (q.get("mode") === "radio") {
      const list = await Radio.load();
      let st = list.find(s => s.name === radioName);
      if (!st) { let last = null; try { last = localStorage.getItem("radio.last"); } catch (_) {} st = list.find(s => s.name === last) || list[0]; }
      if (st && !(Radio.current && Radio.current.name === st.name)) {
        const a = Radio.ensureAudio();
        if (gentle) a.volume = 0.05;
        Radio.play(st);
        if (gentle) {   // in 90 Sekunden langsam lauter
          const t0 = Date.now();
          const ramp = setInterval(() => {
            const p = Math.min(1, (Date.now() - t0) / 90000);
            a.volume = 0.05 + 0.95 * p * p;
            if (p >= 1 || !Radio.current) { clearInterval(ramp); a.volume = 1; }
          }, 500);
        }
      }
    }
  },
  check() {
    const m = (location.hash || "").match(/^#\/wakeup\?(.*)$/);
    if (!m) return;
    history.replaceState(null, "", "#/");
    Wakeup.start(new URLSearchParams(m[1]));
  },
};
window.addEventListener("hashchange", Wakeup.check);
setTimeout(Wakeup.check, 0);

// Einstellungen · Energie: Wecker um Radio/Ambient erweitern
(function () {
  const r = ROUTES.energy.render;
  ROUTES.energy.render = (v, t) => { r(v, t); setTimeout(() => addWakeModeRows(v, t), 0); };
})();
function addWakeModeRows(view, token) {
  const list = view.querySelector("#wk-list");
  if (!list || token !== renderToken) return;
  let w = null;
  const box = document.createElement("div");
  box.className = "list";
  box.id = "wk-mode";
  list.after(box);
  const MODES = [["tv", "Fernsehen / Startseite"], ["radio", "Radio mit Morgenbild"], ["ambient", "Nur Morgenbild mit Uhr"]];
  async function load() { try { w = await API.get("/api/wake"); draw(); } catch (_) {} }
  async function save(p) { try { w = await API.post("/api/wake", p); draw(); } catch (e) { toast(e.message, "error"); } }
  async function draw() {
    if (token !== renderToken || !w) return;
    const key = Nav.current && Nav.current.dataset.key;
    const scenes = await Media.scenes();
    const scene = (scenes.find(s => s.id === w.scene) || scenes[0] || { name: "–" }).name;
    box.innerHTML = valueRow("wk-mode-b", ICON.bell, "Wecken mit", "Was beim Einschalten passiert", (MODES.find(m => m[0] === (w.mode || "tv")) || MODES[0])[1])
      + (w.mode === "radio" ? valueRow("wk-radio", ICON.music, "Radiosender", "Leer = zuletzt gehörter Sender", esc(w.radio || "Zuletzt gehört")) : "")
      + (w.mode && w.mode !== "tv" ? valueRow("wk-scene", ICON.picture, "Morgenbild", "Bewegte Szene im Hintergrund", esc(scene))
        + toggleRow("wk-gentle", ICON.sound, "Sanft wecken", "Radio wird in 90 Sekunden langsam lauter", w.gentle !== false) : "");
    $("#wk-mode-b").addEventListener("click", () => {
      const i = MODES.findIndex(m => m[0] === (w.mode || "tv"));
      save({ mode: MODES[(i + 1) % MODES.length][0] });
    });
    const r = $("#wk-radio");
    if (r) r.addEventListener("click", async () => {
      const st = await Radio.load();
      const names = ["", ...st.map(s => s.name)];
      save({ radio: names[(names.indexOf(w.radio || "") + 1) % names.length] });
    });
    const sc = $("#wk-scene");
    if (sc) sc.addEventListener("click", () => {
      const i = scenes.findIndex(s => s.id === w.scene);
      if (scenes.length) save({ scene: scenes[(i + 1) % scenes.length].id });
    });
    const g = $("#wk-gentle");
    if (g) g.addEventListener("click", () => save({ gentle: w.gentle === false }));
    const again = key && view.querySelector(`[data-key="${key}"]`);
    if (again && (!Nav.current || !document.contains(Nav.current))) Nav.focus(again, false);
  }
  load();
}

// ======================================================================
// Schnellmenü: Info-Taste (oder Taste „Menü“) auf jeder Seite
// ======================================================================
const QuickMenu = {
  SLEEP: [0, 15, 30, 60, 90, 120],
  open() {
    if (document.querySelector("#modals .modal.qm")) return this.close();
    const svg = d => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
    const I = {
      vdown: svg('<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M17 12h4"/>'),
      vup: svg('<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M17 12h4M19 10v4"/>'),
      mute: svg('<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M17 9l4 6M21 9l-4 6"/>'),
      moon: svg('<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>'),
      film: svg('<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 9.5v5l4-2.5z"/>'),
      img: svg('<rect x="3" y="5" width="18" height="14" rx="3"/><circle cx="9" cy="10" r="1.6"/><path d="M21 16l-5-5-8 8"/>'),
    };
    const btn = (id, ic, label, sub) => `<button class="qm-b nav" data-key="qm-${id}" data-q="${id}"><span class="ic">${ic}</span><b>${label}</b><small id="qm-s-${id}">${sub}</small></button>`;
    const { el, close } = openModal({
      title: "Schnellmenü",
      html: `<div class="qm-row">
        ${btn("vdown", I.vdown, "Leiser", "Lautstärke")}${btn("vup", I.vup, "Lauter", "Lautstärke")}${btn("mute", I.mute, "Stumm", "Ton aus/an")}
        ${btn("sleep", I.moon, "Schlaf-Timer", "…")}${btn("ambient", I.film, "Ambient", "Bewegte Szenen")}
        ${btn("wall", I.img, "Hintergrund", "Nächstes Bild")}${btn("bt", ICON.bt, "Bluetooth", "Kopfhörer & Boxen")}
        ${btn("look", ICON.eye, "Design", "Farben & Aufbau")}${btn("reboot", ICON.restart, "Neustart", "Pi neu starten")}</div>`,
      buttons: [],
      focus: '[data-q="vup"]',
    });
    el.classList.add("qm");
    this.el = el; this.close = close;
    const sub = (id, t) => { const s = el.querySelector("#qm-s-" + id); if (s) s.textContent = t; };
    const sleepTxt = s => s > 0 ? `noch ${Math.ceil(s / 60)} Min.` : "Aus";
    API.get("/api/sleep").then(r => sub("sleep", sleepTxt(r.sleep_left))).catch(() => sub("sleep", "Aus"));
    const vol = async action => {
      try { const r = await API.post("/api/volume", { action }); sub(action === "mute" ? "mute" : "vup", r && r.volume != null ? (r.muted ? "Stumm" : r.volume + " %") : "OK"); }
      catch (e) { toast(e.message, "error"); }
    };
    el.querySelectorAll("[data-q]").forEach(b => b.addEventListener("click", async () => {
      const q = b.dataset.q;
      if (q === "vdown" || q === "vup" || q === "mute") return vol(q === "vdown" ? "down" : q === "vup" ? "up" : "mute");
      if (q === "sleep") {
        let left = 0;
        try { left = (await API.get("/api/sleep")).sleep_left || 0; } catch (_) {}
        const curMin = Math.ceil(left / 60);
        const next = this.SLEEP.find(m => m > curMin) ?? 0;
        try { const r = await API.post("/api/sleep", { minutes: next }); sub("sleep", sleepTxt(r.sleep_left)); toast(next ? `Schlaf-Timer: ${next} Minuten` : "Schlaf-Timer aus", "ok"); }
        catch (e) { toast(e.message, "error"); }
        return;
      }
      close();
      if (q === "ambient") return VideoSaver.show();
      if (q === "wall") return this.nextWall();
      if (q === "bt") return go("#/settings/bluetooth");
      if (q === "look") return go("#/settings/look");
      if (q === "reboot") {
        if (await confirmDialog("Neu starten?", "Raspi-TV startet neu und ist in etwa einer Minute wieder da.", "Neu starten"))
          API.post("/api/reboot", {}).catch(e => toast(e.message, "error"));
      }
    }));
  },
  async nextWall() {
    const list = await Media.walls();
    if (!list.length) return;
    const k = Look.cfg(state.config);
    const i = list.findIndex(w => w.id === k.wallpaper);
    const w = list[(i + 1) % list.length];
    const patch = { background: "wallpaper", wallpaper: w.id, wallpaper_rotate: false };
    state.config = Object.assign({}, state.config, patch);
    Look.apply(state.config);
    toast("Hintergrund: " + w.name, "ok");
    API.post("/api/config", patch).then(c => { state.config = c; }).catch(() => {});
  },
};
document.addEventListener("keydown", e => {
  if (e.defaultPrevented || Saver.el) return;
  if (!["i", "I", "ContextMenu", "F2"].includes(e.key)) return;
  if (e.target.matches && e.target.matches("input, textarea")) return;
  if (document.querySelector("#modals .modal:not(.qm)")) return;
  e.preventDefault();
  QuickMenu.open();
});

// ======================================================================
// Gleitender Fokus-Schein (nur bei „Volle Animationen“)
// ======================================================================
const Halo = {
  el: null, target: null, raf: 0, until: 0,
  init() {
    this.el = document.createElement("div");
    this.el.id = "halo";
    document.body.appendChild(this.el);
    const f0 = Nav.focus.bind(Nav);
    Nav.focus = (el, scroll) => { f0(el, scroll); this.follow(el); };
    window.addEventListener("resize", () => this.follow(this.target));
    document.addEventListener("scroll", () => this.follow(this.target), true);
  },
  follow(el) {
    this.target = el;
    if (!el || document.documentElement.dataset.motion !== "full") { this.el.classList.remove("on"); return; }
    this.until = Date.now() + 700;      // während Scroll-/Zoom-Animation mitlaufen
    if (!this.raf) this.raf = requestAnimationFrame(() => this.step());
  },
  step() {
    this.raf = 0;
    const el = this.target;
    if (!el || !document.contains(el) || !el.classList.contains("focused")) { this.el.classList.remove("on"); return; }
    const r = el.getBoundingClientRect();
    if (!r.width) { this.el.classList.remove("on"); return; }
    const s = this.el.style;
    s.transform = `translate(${r.left}px, ${r.top}px)`;
    s.width = r.width + "px";
    s.height = r.height + "px";
    s.borderRadius = getComputedStyle(el).borderRadius;
    this.el.classList.add("on");
    if (Date.now() < this.until) this.raf = requestAnimationFrame(() => this.step());
  },
};
Halo.init();

// 6.0: beim ersten Start nach dem Update einmal auf das neue Hintergrundbild umstellen
setTimeout(function migrate() {
  if (!state.config || !state.config.setup_done) return;
  if (state.config.wallpaper !== undefined) return;
  const patch = { background: "wallpaper", wallpaper: Wall.DEFAULT };
  API.post("/api/config", patch).then(c => { state.config = c; Look.apply(c); }).catch(() => {});
}, 4000);
