/* Raspi-TV OS – Sprache der Oberfläche (Deutsch / English)
 *
 * Die Oberfläche ist auf Deutsch geschrieben. Ist Englisch eingestellt, übersetzt
 * diese Datei alle sichtbaren Texte beim Anzeigen (Wörterbuch + Muster für Texte
 * mit Zahlen/Namen). Unbekannte Texte bleiben unverändert.
 */
"use strict";

const I18N_EN = {
  "PC-Bildschirm": "PC screen", "Musikvisualisierung": "Music visualization", "Handy-Gamepad": "Phone gamepad",
  "Polarlicht": "Aurora", "Sternenflug": "Starflight", "Lavalampe": "Lava lamp", "Musikansicht": "Music view",
  "Zeit zum Abschalten": "Time to unwind", "Musik läuft beim Öffnen und Schließen weiter.": "Music keeps playing when you open or close this view.",
  "◀ ▶ Szene wechseln · ▶❚❚ Pause / Wiedergabe · Andere Taste zurück": "◀ ▶ Change scene · ▶❚❚ Pause / play · Other key to return",

  "Benutzerprofile": "User profiles", "Dein Raspi-TV": "Your Raspi-TV", "Apps suchen": "Find apps",
  "Neues Profil": "New profile", "Profil umbenennen": "Rename profile", "Profilname": "Profile name",
  "Aktives Profil": "Active profile", "Wechseln": "Switch", "Umbenennen": "Rename", "Löschen": "Delete",
  "Sender bearbeiten": "Edit channels", "Design bearbeiten": "Edit appearance", "Welche App suchst du?": "Which app are you looking for?",
  "Name oder Thema": "Name or topic", "Alle Apps": "All apps", "Verfügbar": "Available", "Im App-Katalog": "In the app catalog",
  "Eigene Sender und eigenes Design": "Your channels and appearance", "Deine Sender · Dein Design": "Your channels · Your appearance",

  // ---------------------------------------------------------------- Allgemein
  "Abbrechen": "Cancel", "Speichern": "Save", "Fertig": "Done", "Öffnen": "Open", "Zurück": "Back", "Schließen": "Close",
  "Weiter": "Next", "Ja": "Yes", "Nein": "No", "OK": "OK", "Aus": "Off", "An": "On", "Ändern": "Change", "Eintragen": "Set up",
  "Hinzufügen": "Add", "Übernehmen": "Apply", "Zurücksetzen": "Reset", "Entfernen": "Remove", "Installieren": "Install",
  "Installiert": "Installed", "Starten": "Start", "Ausblenden": "Hide", "Einblenden": "Show", "Wieder anzeigen": "Show again",
  "Einschalten": "Turn on", "Ausschalten": "Turn off", "Einrichten": "Set up", "Neu starten": "Restart", "Fehler": "Error", "Fehler:": "Error:",
  "Lade …": "Loading …", "Lädt …": "Loading …", "Prüfe …": "Checking …", "Prüfen": "Check", "Suche …": "Searching …",
  "Wird geöffnet …": "Opening …", "Nicht verfügbar": "Not available", "Läuft": "Playing", "LÄUFT": "LIVE", "Live": "Live", "LIVE": "LIVE",
  "Heute": "Today", "Morgen": "Tomorrow", "Gestern": "Yesterday", "Montag": "Monday", "Dienstag": "Tuesday", "Mittwoch": "Wednesday",
  "Donnerstag": "Thursday", "Freitag": "Friday", "Samstag": "Saturday", "Sonntag": "Sunday", "Alle": "All", "Seite": "Page",
  "Start": "Home", "Startseite": "Home", "Zur Startseite": "Go to home", "Auswählen": "Select", "Eine Ebene zurück": "Go back",
  "Version": "Version", "Gerät": "Device", "Größe": "Size", "Kategorie": "Category", "Art": "Type", "Kosten": "Price", "Herkunft": "Origin",
  "Vorinstalliert": "Pre-installed", "Online": "Online", "Offline": "Offline", "Kabel": "Cable", "Empfehlung": "Recommended",
  "Guten Morgen": "Good morning", "Guten Tag": "Good afternoon", "Guten Abend": "Good evening", "Gute Nacht": "Good night",
  "Erneut suchen": "Search again", "Ende": "Exit", "Danach": "Next",
  // ---------------------------------------------------------------- Startseite
  "Live-TV": "Live TV", "Fernsehen": "Television", "TV‑Programm": "TV guide", "TV-Programm": "TV guide", "Was läuft wann": "What's on when",
  "Mediathek": "On demand", "ARD, ZDF, ARTE & mehr": "ARD, ZDF, ARTE & more", "Filme & Serien": "Movies & series",
  "Netflix, Prime & mehr": "Netflix, Prime & more", "Eigene Medien": "My media", "USB & Heimnetz": "USB & home network",
  "Radio": "Radio", "Über 20 Sender live": "20+ stations live", "Einstellungen": "Settings", "WLAN, Bild, Ton …": "Wi-Fi, picture, sound …",
  "Sendung suchen": "Search shows", "Weiterschauen": "Continue watching", "Jetzt im Fernsehen": "On TV now", "Apps": "Apps",
  "App Store": "App Store", "Neue Apps holen": "Get new apps", "Keine Sender verfügbar.": "No channels available.",
  "Sender werden geladen …": "Loading channels …", "Keine Internetverbindung.": "No internet connection.",
  "Verbinde den Raspi-TV mit deinem WLAN oder stecke ein LAN-Kabel ein.": "Connect Raspi-TV to your Wi-Fi or plug in a network cable.",
  "WLAN einrichten": "Set up Wi-Fi", "OK Öffnen": "OK Open", "Startseite aus jeder App": "Home from any app",
  "Maus-Modus": "Mouse mode", "Guide": "Guide",
  // ---------------------------------------------------------------- App-Seiten
  "Diese Dienste brauchen ein eigenes Abo. Sie laufen über ihre offizielle Web-Version – die Bildqualität ist dort meist auf 720p begrenzt.":
    "These services need their own subscription. They run in their official web version – picture quality there is usually limited to 720p.",
  "Kostenlose Mediatheken und Videoangebote. Live-Sender findest du unter „Live-TV“.": "Free on-demand libraries and videos. Live channels are under “Live TV”.",
  "Mehr Apps": "More apps", "Im App Store stöbern": "Browse the App Store",
  "Das Erste & Dritte": "Das Erste & regional", "ZDF, neo, info": "ZDF, neo, info", "Kultur & Doku": "Culture & docs",
  "Kultur & Wissen": "Culture & science", "Für Kinder": "For kids", "ProSieben, Sat.1 …": "ProSieben, Sat.1 …", "Videos": "Videos",
  "Livestreams": "Live streams", "Abo · bis 720p": "Subscription · up to 720p", "Abo · SD/720p": "Subscription · SD/720p",
  "Abo · RTL & Co.": "Subscription · RTL & co.", "Anime": "Anime", "Musik & Podcasts": "Music & podcasts",
  "Keine Internetverbindung – bitte zuerst WLAN einrichten.": "No internet connection – please set up Wi-Fi first.",
  // ---------------------------------------------------------------- Live-TV
  "Sender": "Channels", "Senderliste": "Channel list", "Senderliste ·": "Channel list ·", "Optionen": "Options", "Optionen ·": "Options ·",
  "Lieblingssender": "Favourite", "Umschalten durch": "Zap through", "Alle Sender": "All channels", "Schlaf-Timer": "Sleep timer",
  "Sender neu laden": "Reload channel", "Erst Lieblingssender markieren": "Mark favourites first", "★ Ja": "★ Yes",
  "Sender gerade nicht verfügbar": "Channel currently unavailable", "Neuer Versuch läuft automatisch ·": "Retrying automatically ·",
  "anderer Sender ·": "other channel ·", "Keine Senderliste gefunden": "No channel list found", "Musik": "Music",
  "Gute Nacht – zum Einschalten eine Taste drücken": "Good night – press any key to wake up", "Keine Programminformationen": "No programme information",
  "· beliebige Taste zum Abbrechen": "· press any key to cancel", "Sendeschluss": "Close-down",
  // ---------------------------------------------------------------- TV-Programm / Suche
  "Programm wird geladen …": "Loading guide …", "Noch keine Programmdaten": "No guide data yet", "Sendungen": "Shows", "Sendungen ·": "Shows ·",
  "Details ·": "Details ·", "Details · Erinnern": "Details · Remind", "Erinnerung": "Reminder", "Erinnerung für": "Reminder for",
  "Erinnerung gelöscht": "Reminder deleted", "Erinnerung löschen": "Delete reminder", "Erinnern": "Remind me", "Sender jetzt einschalten": "Watch channel now",
  "Für diesen Sender gibt es keine Programminformationen.": "There is no programme information for this channel.",
  "Durchsucht das TV-Programm der nächsten zwei Tage – z. B. „Tatort“, „Tagesschau“ oder „Fußball“.":
    "Searches the TV guide for the next two days – e.g. “Tatort”, “Tagesschau” or “football”.",
  "Titel eingeben …": "Enter a title …", "Nichts gefunden. Probier einen kürzeren Suchbegriff.": "Nothing found. Try a shorter search term.",
  "Die Sendung hat schon begonnen.": "The show has already started.", "Umschalten": "Switch",
  // ---------------------------------------------------------------- Eigene Medien / Player
  "Videos, Musik und Fotos von USB-Sticks, Festplatten oder aus dem Heimnetz (z. B. FRITZ!Box-Speicher, NAS, Windows-Freigabe).":
    "Videos, music and photos from USB sticks, hard drives or your home network (e.g. FRITZ!Box storage, NAS, Windows share).",
  "Suche Speicher …": "Looking for storage …", "Netzwerkfreigabe hinzufügen": "Add network share", "FRITZ!Box, NAS, Windows-PC": "FRITZ!Box, NAS, Windows PC",
  "Steck einen USB-Stick oder eine Festplatte an den Raspberry Pi – sie erscheint hier automatisch.":
    "Plug a USB stick or hard drive into the Raspberry Pi – it appears here automatically.",
  "Filme": "Movies", "Fotos": "Photos", "Ordner": "Folders", "Ordner zurück": "Up one folder", "Ordner nicht gefunden": "Folder not found",
  "z. B. fritz.box oder 192.168.178.20": "e.g. fritz.box or 192.168.178.20", "z. B. FRITZ.NAS oder Videos": "e.g. FRITZ.NAS or Videos",
  "Name im Netzwerk": "Network name", "Die Dateien bleiben auf dem Gerät im Netzwerk erhalten.": "The files stay on the network device.",
  "Diese Datei kann nicht abgespielt werden.": "This file can't be played.",
  "Unterstützt: MP4/MKV/WebM mit H.264 oder VP9, MP3, AAC, FLAC, OGG.": "Supported: MP4/MKV/WebM with H.264 or VP9, MP3, AAC, FLAC, OGG.",
  "Dieses Bild kann nicht angezeigt werden.": "This image can't be shown.", "Diashow gestartet": "Slideshow started", "Diashow angehalten": "Slideshow paused",
  "Pause ·": "Pause ·", "10 s ·": "10 s ·", "1 Min. ·": "1 min ·", "nächstes Video ·": "next video ·", "Titel wechseln ·": "change track ·",
  "Bild wechseln ·": "change picture ·", "Diashow an/aus ·": "slideshow on/off ·", "Als Nächstes:": "Up next:", "Vom Handy": "From phone",
  // ---------------------------------------------------------------- Radio / Wetter
  "Über 20 Sender live. Das Radio läuft weiter, während du durch die Oberfläche stöberst –": "20+ stations live. The radio keeps playing while you browse –",
  "auf den laufenden Sender stoppt es.": "on the playing station stops it.", "Lade Sender …": "Loading stations …", "Verbinde …": "Connecting …",
  "Nicht erreichbar": "Unreachable", "Radio · Live": "Radio · live", "Radio läuft": "Radio playing", "Deine Region": "Your region",
  "Pop & Charts": "Pop & charts", "Pop & Info": "Pop & news", "Oldies & Info": "Oldies & news", "Pop & Hits": "Pop & hits", "Pop & Kultur": "Pop & culture",
  "Junges Radio": "Youth radio", "Nachrichten": "News", "Kultur": "Culture", "Klassik": "Classical", "Rock": "Rock", "Hip-Hop & Pop": "Hip-hop & pop",
  "Hits": "Hits", "Lade Wetter …": "Loading weather …", "Ort ändern": "Change location", "Ort für das Wetter": "Weather location",
  "Stadt oder Ort, z. B. Köln": "City or town, e.g. Cologne", "Wie Bundesland": "Same as region", "Kein Ort gefunden.": "No place found.",
  "Wetterdaten: Open-Meteo.com": "Weather data: Open-Meteo.com", "Wetter": "Weather", "Wetter gerade nicht verfügbar": "Weather currently unavailable",
  "Sonnig": "Sunny", "Klar": "Clear", "Überwiegend sonnig": "Mostly sunny", "Teilweise bewölkt": "Partly cloudy", "Bedeckt": "Overcast", "Nebel": "Fog",
  "Nieselregen": "Drizzle", "Regen": "Rain", "Gefrierender Regen": "Freezing rain", "Schnee": "Snow", "Regenschauer": "Showers",
  "Schneeschauer": "Snow showers", "Gewitter": "Thunderstorm", "Ortssuche gerade nicht verfügbar": "Location search currently unavailable",
  // ---------------------------------------------------------------- Einstellungen: Übersicht
  "WLAN": "Wi-Fi", "Bild": "Picture", "Ton": "Sound", "Fernbedienung": "Remote", "Energie": "Energy", "Bluetooth": "Bluetooth",
  "Updates": "Updates", "System": "System", "Einrichtung": "Setup", "App Store, ein- und ausblenden": "App Store, show and hide",
  "Einstellungen · WLAN": "Settings · Wi-Fi", "Einstellungen · Bild": "Settings · Picture", "Einstellungen · Ton": "Settings · Sound",
  "Einstellungen · Sender": "Settings · Channels", "Einstellungen · Fernbedienung": "Settings · Remote", "Einstellungen · Bluetooth": "Settings · Bluetooth",
  "Einstellungen · Apps": "Settings · Apps", "Einstellungen · Updates": "Settings · Updates", "Einstellungen · System": "Settings · System",
  "Einstellungen · Fernbedienung · Handy": "Settings · Remote · Phone", "Einstellungen · Energie": "Settings · Energy",
  "Mit dem Internet verbunden": "Connected to the internet", "Über Kabel verbunden": "Connected via cable", "Über LAN-Kabel verbunden": "Connected via network cable",
  "Nicht verbunden": "Not connected", "nicht verbunden": "not connected", "Auflösung & Bildgröße": "Resolution & picture size",
  "Ausgabe & Lautstärke": "Output & volume", "Reihenfolge, ausblenden, eigene Liste": "Order, hide, own list",
  "TV-Fernbedienung & Handy": "TV remote & phone", "Ausschalten & Bildschirmschoner": "Auto-off & screensaver",
  "Kopfhörer, Lautsprecher, Controller": "Headphones, speakers, controllers", "System & Programmdaten": "System & guide data",
  "Informationen zu deinem Raspi-TV und Wartung.": "Information about your Raspi-TV and maintenance.",
  // ---------------------------------------------------------------- WLAN
  "Wähle dein Netzwerk aus. Das Passwort gibst du mit der Bildschirmtastatur ein.": "Choose your network. Enter the password with the on-screen keyboard.",
  "Verfügbare Netzwerke": "Available networks", "Keine Netzwerke gefunden. Steht der Router in der Nähe?": "No networks found. Is the router nearby?",
  "Du bist mit diesem Netzwerk verbunden.": "You're connected to this network.", "Verbunden mit": "Connected to", "Verbinden": "Connect",
  "Wähle unten ein Netzwerk aus.": "Choose a network below.", "Passwort": "Password", "Netzwerk nicht gefunden – bitte neu suchen.": "Network not found – please search again.",
  "Verbindung fehlgeschlagen – stimmt das Passwort?": "Connection failed – is the password right?",
  "Verbindung fehlgeschlagen – ist das Netzwerk in Reichweite?": "Connection failed – is the network in range?", "Ungültiges Passwort": "Invalid password",
  // ---------------------------------------------------------------- Bild
  "Auflösung": "Resolution", "Automatische Auflösung": "Automatic resolution", "Beste Auflösung des Fernsehers": "Best resolution for your TV",
  "Bildgröße": "Picture size", "Bildgröße (Rand)": "Picture size (borders)", "Mit ◀ ▶ ändern": "Change with ◀ ▶", "Auflösung gespeichert": "Resolution saved",
  "Bild in Ordnung?": "Does the picture look right?", "Sekunden die vorherige Auflösung wiederhergestellt.": "seconds the previous resolution is restored.",
  "Ohne Bestätigung wird in": "Without confirmation, in",
  "Normalerweise wählt Raspi-TV die beste Auflösung automatisch. Wird das Bild am Rand abgeschnitten, verkleinere die Bildgröße.":
    "Raspi-TV normally picks the best resolution automatically. If the edges are cut off, reduce the picture size.",
  "Auflösungen können gerade nicht gelesen werden.": "Resolutions can't be read right now.", "Kein Bildschirm erkannt.": "No display detected.",
  "Diese Auflösung wird nicht unterstützt.": "This resolution is not supported.", "Automatisch (empfohlen)": "Automatic (recommended)",
  // ---------------------------------------------------------------- Ton
  "Die Lautstärke des Fernsehers regelst du wie gewohnt mit der TV-Fernbedienung. Hier wählst du, wo der Ton herauskommt.":
    "Control the TV's volume as usual with the TV remote. Here you choose where the sound comes out.",
  "Ausgabe": "Output", "Lautstärke": "Volume", "Tonausgabe geändert": "Audio output changed",
  "Keine Tonausgabe gefunden. Ist der Fernseher eingeschaltet?": "No audio output found. Is the TV switched on?",
  "Vom Handy abspielen": "Play from your phone", "AirPlay": "AirPlay", "Musik vom iPhone, iPad oder Mac auf dem Fernseher abspielen": "Play music from iPhone, iPad or Mac on the TV",
  "Wird mit dem nächsten System-Update installiert": "Will be installed with the next system update",
  "AirPlay ist noch nicht installiert – bitte System aktualisieren.": "AirPlay is not installed yet – please update the system.",
  "Spotify Connect": "Spotify Connect", "Raspi-TV als Lautsprecher in der Spotify-App (Premium)": "Raspi-TV as a speaker in the Spotify app (Premium)",
  "Raspi-TV als Lautsprecher in der Spotify-App (Premium) – wird beim Einschalten eingerichtet": "Raspi-TV as a speaker in the Spotify app (Premium) – set up when you turn it on",
  "Wird eingerichtet …": "Setting up …", "Spotify Connect einrichten?": "Set up Spotify Connect?",
  "Raspi-TV lädt dafür ein kleines Zusatzprogramm (librespot, ca. 10 MB). Zum Abspielen brauchst du Spotify Premium.":
    "Raspi-TV downloads a small add-on for this (librespot, about 10 MB). You need Spotify Premium to play.",
  "Spotify Connect wird eingerichtet": "Setting up Spotify Connect", "Im Hintergrund weiter": "Continue in background",
  "Zum Einrichten braucht Raspi-TV eine Internetverbindung.": "Raspi-TV needs an internet connection for setup.",
  "Spotify Connect konnte nicht geladen werden – Internetverbindung prüfen.": "Spotify Connect couldn't be downloaded – check the internet connection.",
  "Spotify Connect konnte nicht installiert werden.": "Spotify Connect couldn't be installed.",
  "Videos & Fotos vom Handy (DLNA)": "Videos & photos from your phone (DLNA)",
  "Videos, Musik und Fotos vom Handy oder PC auf dem Fernseher abspielen": "Play videos, music and photos from your phone or PC on the TV",
  "Pause": "Paused",
  // ---------------------------------------------------------------- Sender
  "Ordne die Sender so, wie du sie am Fernseher haben möchtest.": "Arrange the channels the way you want them on your TV.",
  "auf einem Sender: verschieben oder ausblenden.": "on a channel: move or hide.", "▲▼ verschieben · OK fertig": "▲▼ move · OK done",
  "ausgeblendet": "hidden", "Verschieben": "Move", "Reihenfolge zurücksetzen": "Reset order", "Reihenfolge zurücksetzen?": "Reset order?",
  "Alle Sender werden wieder eingeblendet und wie ab Werk sortiert.": "All channels are shown again and sorted as at the factory.",
  "Alle Sender wieder einblenden, Standard-Reihenfolge": "Show all channels again, default order", "Zurückgesetzt": "Reset",
  "Eigene Senderliste (M3U)": "Own channel list (M3U)", "z. B. von einem TV-Server im Heimnetz": "e.g. from a TV server in your home network",
  "Adresse einer M3U-Senderliste, z. B. von einem TV-Server (Tvheadend, Jellyfin) oder Anbieter. Es werden Streams im Format HLS/MP4 unterstützt. Leer lassen zum Entfernen.":
    "Address of an M3U channel list, e.g. from a TV server (Tvheadend, Jellyfin) or provider. HLS/MP4 streams are supported. Leave empty to remove.",
  "Senderliste übernommen": "Channel list applied", "Mindestens ein Sender muss sichtbar bleiben.": "At least one channel must stay visible.",
  "In der Liste wurden keine Sender gefunden.": "No channels were found in the list.", "Ungültige Senderliste": "Invalid channel list",
  "Bitte eine Adresse beginnend mit http:// oder https:// eingeben.": "Please enter an address starting with http:// or https://.",
  "Hauptsender": "Main channels", "Regional": "Regional", "Doku & Wissen": "Docs & science", "Kinder": "Kids", "Unterhaltung": "Entertainment",
  "Sport": "Sports", "Reportage": "Reports",
  // ---------------------------------------------------------------- Fernbedienung / CEC / Handy
  "Raspi-TV wird mit der Fernbedienung deines Fernsehers bedient (HDMI-CEC). Alternativ geht das Handy oder eine Funk-Tastatur/Air-Maus.":
    "Raspi-TV is controlled with your TV's remote (HDMI-CEC). Alternatively use your phone or a wireless keyboard/air mouse.",
  "Verbindung zum Fernseher (HDMI-CEC)": "Connection to the TV (HDMI-CEC)", "Fernseher erkannt und eingeschaltet": "TV detected and on",
  "Fernseher erkannt (Standby)": "TV detected (standby)", "Bereit – drücke eine Taste auf der TV-Fernbedienung": "Ready – press a key on the TV remote",
  "· Am Fernseher HDMI-CEC einschalten (Anynet+, SimpLink, Bravia Sync, VIERA Link, EasyLink).": "· Turn on HDMI-CEC on the TV (Anynet+, SimpLink, Bravia Sync, VIERA Link, EasyLink).",
  "Nicht verfügbar · Am Fernseher HDMI-CEC einschalten (Anynet+, SimpLink, Bravia Sync, VIERA Link, EasyLink).": "Not available · Turn on HDMI-CEC on the TV (Anynet+, SimpLink, Bravia Sync, VIERA Link, EasyLink).",
  "Aktiv": "Active", "Handy als Fernbedienung": "Phone as remote", "Mit Touchpad und Tastatur – QR-Code scannen": "With touchpad and keyboard – scan the QR code",
  "Tasten": "Buttons", "Pfeile · OK": "Arrows · OK", "Auswählen · Bestätigen": "Select · Confirm", "Eine Ebene zurück · lang drücken: Startseite": "Go back · hold: home",
  "Home / Menü / Rot": "Home / Menu / Red", "Startseite – aus jeder App": "Home – from any app", "CH + / CH –": "CH + / CH –",
  "Sender wechseln · im Programm seitenweise blättern": "Change channel · page through the guide", "0 – 9": "0 – 9", "Sender direkt wählen": "Choose channel directly",
  "Guide / EPG": "Guide / EPG", "Info": "Info", "Infoleiste mit aktueller Sendung": "Info bar with the current show", "Grün": "Green", "Gelb": "Yellow", "Blau": "Blue",
  "Maus-Modus: Pfeile bewegen den Zeiger, OK klickt": "Mouse mode: arrows move the pointer, OK clicks", "Schließen / Vollbild verlassen": "Close / leave full screen",
  "Seite neu laden": "Reload page", "Play · Pause · Spulen": "Play · Pause · Seek", "Wiedergabe steuern": "Control playback",
  "Fernseher & Soundbar": "TV & soundbar", "HDMI-CEC nicht verfügbar": "HDMI-CEC not available",
  "Am Fernseher HDMI-CEC einschalten und Raspi-TV neu starten.": "Turn on HDMI-CEC on the TV and restart Raspi-TV.",
  "Fernseher mit Raspi-TV einschalten": "Turn on the TV with Raspi-TV", "Beim Start schaltet sich der Fernseher ein und wechselt auf Raspi-TV": "At start-up the TV turns on and switches to Raspi-TV",
  "Beim Einschalten zu Raspi-TV wechseln": "Switch to Raspi-TV when the TV turns on",
  "Schaltest du den Fernseher ein, erscheint sofort Raspi-TV (statt des letzten Eingangs)": "When you turn on the TV, Raspi-TV appears right away (instead of the last input)",
  "Lautstärke-Tasten": "Volume buttons", "Automatisch": "Automatic", "Fernseher": "TV", "Soundbar": "Soundbar", "Raspi-TV": "Raspi-TV",
  "Lautstärke testen": "Test volume", "Lauter, leiser und stumm ausprobieren": "Try louder, quieter and mute", "Leiser": "Quieter", "Lauter": "Louder", "Stumm": "Mute",
  "Hörst du die Änderung? Wenn nicht, unter „Lautstärke-Tasten“ ein anderes Gerät wählen.": "Can you hear the change? If not, choose another device under “Volume buttons”.",
  "Fernseher ausschalten": "Turn off the TV", "Fernseher ausschalten?": "Turn off the TV?",
  "Raspi-TV bleibt an. Schaltest du den Fernseher wieder ein, geht es hier weiter.": "Raspi-TV stays on. Turn the TV back on to continue here.",
  "HDMI-CEC ist nicht verfügbar.": "HDMI-CEC is not available.", "Kein Fernseher gefunden.": "No TV found.",
  "Scanne den Code mit der Kamera deines Handys. Dein Handy wird dann zur Fernbedienung – mit": "Scan the code with your phone's camera. Your phone then becomes a remote – with",
  "Touchpad": "Touchpad", "zum Klicken in Netflix & Co. und": "for clicking in Netflix & co. and", "Tastatur": "Keyboard",
  "für Logins und Suche. Handy und Raspi-TV müssen im selben Netz sein – ohne Heim-WLAN hilft das Fernbedienungs-WLAN unten.":
    "for logins and search. Phone and Raspi-TV must be on the same network – without home Wi-Fi, the remote Wi-Fi below helps.",
  "Kamera-App öffnen und auf den Code richten": "Open the camera app and point it at the code", "Link antippen – fertig": "Tap the link – done",
  "Tipp: „Zum Startbildschirm hinzufügen“, dann ist die Fernbedienung immer da": "Tip: “Add to Home Screen” keeps the remote at hand",
  "Adresse": "Address", "Neuen Code erstellen": "Create new code", "Bisher gekoppelte Handys funktionieren danach nicht mehr": "Previously paired phones will stop working",
  "Neuer Code erstellt": "New code created", "Neuen Code erstellen?": "Create new code?", "Neuer Code": "New code",
  "Alle bisher gekoppelten Handys müssen den neuen Code scannen.": "All paired phones need to scan the new code.",
  "Erst mit dem Internet/WLAN verbinden": "Connect to the internet/Wi-Fi first",
  "Ohne Heim-WLAN (z. B. nachts)": "Without home Wi-Fi (e.g. at night)",
  "Ist Raspi-TV per LAN-Kabel verbunden, kann er ein eigenes kleines WLAN nur für die Handy-Fernbedienung aufspannen – ohne Internet. So klappt die Fernbedienung auch, wenn das Heim-WLAN aus ist.":
    "If Raspi-TV is connected by network cable, it can open its own small Wi-Fi just for the phone remote – without internet. The remote then works even when the home Wi-Fi is off.",
  "Fernbedienungs-WLAN": "Remote Wi-Fi", "Nur nachts": "Only at night", "Immer an": "Always on", "Einschalten um": "Turn on at", "Ausschalten um": "Turn off at",
  "Handy einrichten": "Set up phone", "Zwei QR-Codes: WLAN beitreten, Fernbedienung öffnen": "Two QR codes: join Wi-Fi, open remote",
  "Handy fürs Fernbedienungs-WLAN einrichten": "Set up your phone for the remote Wi-Fi", "1 · WLAN beitreten": "1 · Join Wi-Fi", "2 · Fernbedienung öffnen": "2 · Open remote",
  "Danach „Zum Startbildschirm hinzufügen“ – z. B. als „TV Nacht“": "Then “Add to Home Screen” – e.g. as “TV night”",
  "Das Handy verbindet sich ab dann von selbst mit diesem WLAN. Es hat darüber kein Internet – fragt das Handy, ob es verbunden bleiben soll, „Ja“ wählen. Lädt die Fernbedienung nicht, kurz die mobilen Daten ausschalten.":
    "From then on the phone joins this Wi-Fi by itself. It has no internet there – if the phone asks whether to stay connected, choose “Yes”. If the remote doesn't load, briefly turn off mobile data.",
  "Neues Passwort": "New password", "Neues WLAN-Passwort?": "New Wi-Fi password?", "Alle Handys müssen danach den neuen WLAN-Code scannen.": "All phones then need to scan the new Wi-Fi code.",
  "Wird umgestellt …": "Switching …", "Wird gestartet …": "Starting …",
  "Benötigte Pakete (dnsmasq-base, nftables) konnten nicht installiert werden – Internet prüfen.": "Required packages couldn't be installed – check the internet.", "Startet gleich …": "Starting shortly …",
  "Das geht nur, wenn Raspi-TV per LAN-Kabel mit dem Router verbunden ist.": "This only works when Raspi-TV is connected to the router by network cable.",
  "Geht nur, wenn Raspi-TV per LAN-Kabel mit dem Router verbunden ist.": "Only works when Raspi-TV is connected to the router by network cable.",
  "Kein WLAN-Chip gefunden.": "No Wi-Fi chip found.",
  // ---------------------------------------------------------------- Bluetooth
  "Meine Geräte": "My devices", "Verfügbare Geräte": "Available devices", "Nach Geräten suchen": "Search for devices",
  "Keine Geräte gefunden.": "No devices found.", "Keine Geräte gekoppelt": "No devices paired", "Noch keine Geräte gekoppelt.": "No devices paired yet.",
  "Gerät(e) gekoppelt": "device(s) paired", "Das Gerät ist verbunden.": "The device is connected.", "Das Gerät ist gekoppelt, aber nicht verbunden.": "The device is paired but not connected.",
  "Versetze dein Gerät in den Kopplungsmodus (meist eine Taste lange gedrückt halten) und starte dann die Suche.":
    "Put your device into pairing mode (usually hold a button) and then start the search.",
  "Koppeln fehlgeschlagen – ist das Gerät im Kopplungsmodus?": "Pairing failed – is the device in pairing mode?",
  "Verbinden fehlgeschlagen – ist das Gerät eingeschaltet?": "Connecting failed – is the device switched on?",
  "Trennen": "Disconnect", "Koppeln": "Pair", "Vergessen": "Forget", "Verbunden": "Connected", "Gekoppelt": "Paired", "nicht gekoppelt": "not paired",
  // ---------------------------------------------------------------- Apps-Einstellungen
  "Lege fest, welche Apps unter „Mediathek“, „Filme & Serien“ und auf der Startseite erscheinen.": "Choose which apps appear under “On demand”, “Movies & series” and on the home screen.",
  "Über 50 weitere Apps und Programme wie Kodi installieren": "Install 50+ more apps and programs like Kodi", "Aus dem App Store": "From the App Store",
  "Mindestens eine App muss sichtbar bleiben.": "At least one app must stay visible.", "Internet": "Internet",
  "Werbeblocker für Webseiten": "Ad blocker for websites",
  "Blockiert Werbung und Tracker auf normalen Webseiten (z. B. in der App „Internet“). Streaming- und Mediathek-Apps sind ausgenommen, damit sie weiter laufen.":
    "Blocks ads and trackers on regular websites (e.g. in the “Internet” app). Streaming and on-demand apps are excluded so they keep working.",
  "Werbeblocker an – wirkt nach wenigen Sekunden": "Ad blocker on – takes effect in a few seconds", "Werbeblocker aus": "Ad blocker off",
  // ---------------------------------------------------------------- Updates
  "Halte Raspi-TV aktuell – wichtig für Browser und Streaming (DRM).": "Keep Raspi-TV up to date – important for the browser and streaming (DRM).",
  "System aktualisieren": "Update system", "Neueste Versionen von Browser, DRM und System installieren": "Install the latest browser, DRM and system versions",
  "Programmdaten aktualisieren": "Update guide data", "Sender-Adressen": "Channel addresses",
  "Werden automatisch alle 12 Stunden geprüft und bei Änderungen angepasst.": "Checked automatically every 12 hours and adjusted when they change.",
  "Das kann einige Minuten dauern. Du kannst währenddessen weiter fernsehen.": "This can take a few minutes. You can keep watching TV meanwhile.",
  "System ist auf dem neuesten Stand.": "The system is up to date.", "Aktualisierung fehlgeschlagen – Internetverbindung prüfen.": "Update failed – check the internet connection.",
  "Fertig – bitte neu starten (Einstellungen → System).": "Done – please restart (Settings → System).",
  "Die Daten kommen aus dem Internet und werden alle 6 Stunden aktualisiert.": "The data comes from the internet and is updated every 6 hours.",
  "Raspi-TV aktualisieren (USB-Stick)": "Update Raspi-TV (USB stick)", "Raspi-TV aktualisieren (Internet)": "Update Raspi-TV (internet)",
  "Suche Update auf USB-Sticks …": "Looking for updates on USB sticks …", "Kein Update-Paket gefunden": "No update package found",
  "Update wird installiert …": "Installing update …", "Bitte nicht ausschalten.": "Please don't turn off.", "Raspi-TV startet neu …": "Raspi-TV is restarting …",
  "Bitte nicht ausschalten. Klappt etwas nicht, kehrt Raspi-TV automatisch zur vorherigen Version zurück.": "Please don't turn off. If something goes wrong, Raspi-TV automatically returns to the previous version.",
  "Nach Updates suchen": "Check for updates", "Update-Adresse": "Update address", "Noch nicht gesucht": "Not checked yet",
  "Erst eine Update-Adresse eintragen": "Set an update address first", "Wo dein Update-Paket im Internet liegt (z. B. GitHub-Releases)": "Where your update package lives online (e.g. GitHub Releases)",
  "Automatisch installieren": "Install automatically", "Nachts zwischen 3 und 5 Uhr, wenn der Fernseher aus ist": "At night between 3 and 5 am, when the TV is off",
  "Gespeichert": "Saved", "Zur vorherigen Version zurück": "Go back to the previous version", "Update zurückgenommen": "Update rolled back",
  "Die neue Version ist nicht richtig gestartet. Raspi-TV ist deshalb automatisch zur vorherigen Version zurückgekehrt – deine Einstellungen sind unverändert.":
    "The new version didn't start properly, so Raspi-TV automatically went back to the previous version – your settings are unchanged.",
  "Raspi-TV lädt das Update, installiert es und startet neu. Klappt der Start nicht, geht es automatisch zurück zur jetzigen Version.":
    "Raspi-TV downloads the update, installs it and restarts. If it doesn't start properly, it automatically returns to the current version.",
  "Raspi-TV spielt die gesicherte Version ein und startet neu. Deine Einstellungen bleiben erhalten.": "Raspi-TV restores the saved version and restarts. Your settings are kept.",
  "Raspi-TV wird aktualisiert und startet danach neu. Deine Einstellungen bleiben erhalten.": "Raspi-TV will be updated and then restart. Your settings are kept.",
  "Keine Update-Adresse eingetragen.": "No update address set.", "Unter der Adresse liegt kein Raspi-TV-Update-Paket.": "There is no Raspi-TV update package at that address.",
  "Unter der Adresse liegt keine Zip-Datei.": "There is no zip file at that address.", "Update-Adresse nicht erreichbar.": "Update address not reachable.",
  "Bitte eine https-Adresse eingeben (z. B. von GitHub-Releases).": "Please enter an https address (e.g. from GitHub Releases).",
  "Das ist kein Raspi-TV-Update-Paket.": "This is not a Raspi-TV update package.", "Update-Paket ist zu groß.": "Update package is too large.",
  "Installation fehlgeschlagen – Details im Protokoll.": "Installation failed – details in the log.", "Update-Paket ohne Versionsnummer.": "Update package has no version number.",
  "Update-Datei nicht gefunden – Stick noch eingesteckt?": "Update file not found – is the stick still plugged in?", "Ungültige Update-Datei": "Invalid update file",
  "Kein Update gefunden.": "No update found.", "Wird vorbereitet": "Preparing", "Wird vorbereitet …": "Preparing …", "Update wird entpackt": "Unpacking update",
  "Aktuelle Version wird gesichert": "Saving the current version", "Dateien werden installiert": "Installing files", "Dienste werden aktualisiert": "Updating services",
  // ---------------------------------------------------------------- System
  "Gerätename": "Device name", "So heißt Raspi-TV im Heimnetz, bei AirPlay und Bluetooth": "How Raspi-TV appears on your network, AirPlay and Bluetooth",
  "Buchstaben, Ziffern und Bindestrich, z. B. „Wohnzimmer-TV“.": "Letters, digits and hyphens, e.g. “Living-Room-TV”.", "Name geändert": "Name changed",
  "Bitte 2–32 Zeichen: Buchstaben, Ziffern und Bindestrich (keine Umlaute/Leerzeichen).": "Please use 2–32 characters: letters, digits and hyphens (no spaces or special letters).",
  "IP-Adresse": "IP address", "Temperatur": "Temperature", "Speicher frei": "Storage free", "Arbeitsspeicher frei": "Memory free", "Wartung": "Maintenance",
  "Bei allen Apps abmelden": "Sign out of all apps", "Löscht Anmeldungen und gespeicherte Daten des Browsers": "Deletes logins and stored browser data",
  "Du musst dich danach bei Netflix, Prime Video & Co. neu anmelden.": "You'll need to sign in to Netflix, Prime Video & co. again.", "Daten werden gelöscht …": "Deleting data …",
  "Direkt Fernsehen starten": "Start with live TV", "Wie ein normaler Fernseher: Einschalten und der letzte Sender läuft": "Like a normal TV: turn on and the last channel plays",
  "Startet ab jetzt direkt mit Fernsehen": "Will now start with live TV", "Startet ab jetzt mit der Startseite": "Will now start with the home screen",
  "Ersteinrichtung erneut starten": "Run first-time setup again", "Region, Startverhalten und Handy neu einrichten": "Set up region, start-up and phone again",
  "Raspi-TV startet in etwa einer Minute neu.": "Raspi-TV restarts in about a minute.", "Raspi-TV wird ausgeschaltet …": "Raspi-TV is shutting down …",
  "Sichern & Wiederherstellen": "Back up & restore", "Auf USB-Stick sichern": "Back up to USB stick",
  "Einstellungen, Sender, Apps, Erinnerungen und gespeicherte WLANs": "Settings, channels, apps, reminders and saved Wi-Fi networks",
  "Bitte zuerst einen USB-Stick einstecken (FAT32 oder exFAT)": "Please plug in a USB stick first (FAT32 or exFAT)", "Sicherung wird gespeichert …": "Saving backup …",
  "Auf welchen Stick?": "Which stick?", "Sicherung wiederherstellen?": "Restore backup?", "Wiederherstellen": "Restore",
  "Kein USB-Stick gefunden.": "No USB stick found.", "Kein USB-Stick gefunden – bitte einen Stick einstecken.": "No USB stick found – please plug one in.",
  "Das ist keine gültige Raspi-TV-Sicherung.": "This is not a valid Raspi-TV backup.", "Sicherung nicht gefunden": "Backup not found",
  "Sicherung nicht gefunden – Stick noch eingesteckt?": "Backup not found – is the stick still plugged in?",
  "Auf diesen Stick kann nicht geschrieben werden (schreibgeschützt oder NTFS). Bitte einen FAT32/exFAT-Stick nehmen.":
    "Can't write to this stick (read-only or NTFS). Please use a FAT32/exFAT stick.",
  // ---------------------------------------------------------------- Energie / Bildschirmschoner
  "Spart Strom, wenn niemand schaut – wie bei einem modernen Fernseher.": "Saves power when nobody is watching – like a modern TV.",
  "Automatisch ausschalten": "Turn off automatically", "Ohne Bedienung schaltet Raspi-TV den Fernseher aus (mit 2 Minuten Vorwarnung)": "Without any input, Raspi-TV turns off the TV (with a 2-minute warning)",
  "Bildschirmschoner": "Screensaver", "Uhr und „Jetzt im TV“ auf der Startseite, wenn nichts passiert": "Clock and “On TV now” on the home screen when idle",
  "Bildschirmschoner ansehen": "Preview screensaver", "Nie": "Never", "Beliebige Taste drücken": "Press any key", "Jetzt im TV ·": "On TV now ·", "Spotify": "Spotify",
  // ---------------------------------------------------------------- Ersteinrichtung
  "Willkommen bei Raspi-TV": "Welcome to Raspi-TV", "In wenigen Schritten ist dein Fernseher bereit. Bedienung mit den": "Your TV is ready in a few steps. Use the",
  "deiner TV-Fernbedienung.": "on your TV remote.", "Los geht’s": "Let's go", "Wähle dein WLAN aus oder stecke ein LAN-Kabel ein.": "Choose your Wi-Fi or plug in a network cable.",
  "Über LAN-Kabel. Alles bereit.": "Via network cable. All set.", "Über LAN-Kabel.": "Via network cable.", "WLAN auswählen": "Choose Wi-Fi",
  "Erst mit dem WLAN verbinden": "Connect to Wi-Fi first", "Wo wohnst du?": "Where do you live?",
  "Dein Regionalprogramm landet dann auf Platz 3 – gleich nach Das Erste und ZDF.": "Your regional channel then goes to position 3 – right after Das Erste and ZDF.",
  "Was soll beim Einschalten kommen?": "What should appear when you turn it on?", "Wie ein normaler Fernseher – der letzte Sender läuft sofort.": "Like a normal TV – the last channel plays right away.",
  "Erst die Übersicht mit Live-TV, Mediathek, Apps und Medien.": "First the overview with live TV, on demand, apps and media.",
  "Praktisch zum Einloggen bei Netflix & Co.: Mit dem Handy tippst du Text und klickst über ein Touchpad. Scanne einfach den Code mit der Kamera. Das geht auch später unter Einstellungen → Fernbedienung.":
    "Handy for logging in to Netflix & co.: type text and click via a touchpad on your phone. Just scan the code with the camera. You can also do this later under Settings → Remote.",
  "Später einrichten": "Set up later", "Fertig – viel Spaß!": "All done – enjoy!", "Beim Einschalten": "At start-up",
  "Baden-Württemberg": "Baden-Württemberg", "Bayern": "Bavaria", "Thüringen": "Thuringia", "Niedersachsen": "Lower Saxony", "Nordrhein-Westfalen": "North Rhine-Westphalia",
  "Rheinland-Pfalz": "Rhineland-Palatinate", "Sachsen": "Saxony", "Sachsen-Anhalt": "Saxony-Anhalt", "Hessen": "Hesse", "Mecklenburg-Vorpommern": "Mecklenburg-Western Pomerania",
  // ---------------------------------------------------------------- Programme / Native
  "wird gestartet …": "is starting …", "Live-TV wird gestartet …": "Starting live TV …", "Programm": "Program", "Programm (wird installiert)": "Program (gets installed)",
  "Programm · Mediacenter": "Program · media center", "Programm · Retro-Spiele": "Program · retro games", "Programm · PC-Spiele streamen": "Program · stream PC games",
  "Es läuft schon eine Installation – bitte kurz warten.": "An installation is already running – please wait a moment.",
  "Es läuft gerade eine andere Installation. Bitte warte, bis sie fertig ist.": "Another installation is running. Please wait until it's finished.",
  "Zum Installieren braucht Raspi-TV eine Internetverbindung.": "Raspi-TV needs an internet connection to install.",
  "Das kann ein paar Minuten dauern. Du kannst dieses Fenster schließen – die Installation läuft weiter.": "This can take a few minutes. You can close this window – the installation keeps running.",
  "Wird heruntergeladen": "Downloading", "Wird installiert": "Installing", "Wird entfernt": "Removing", "Paketlisten werden geladen": "Loading package lists",
  "Erweiterungen werden installiert": "Installing extensions", "Wird aufgeräumt": "Cleaning up", "Paketquelle wird eingerichtet": "Setting up package source",
  "Paketquelle von Moonlight nicht erreichbar.": "Moonlight package source not reachable.", "Unbekanntes Programm": "Unknown program",
  // ---------------------------------------------------------------- App Store
  "Neue Apps für deinen Raspi-TV – alle kostenlos zu installieren. Manche Dienste brauchen ein eigenes Abo.": "New apps for your Raspi-TV – all free to install. Some services need their own subscription.",
  "Entdecken": "Discover", "Meine Apps": "My apps", "Mediatheken": "On demand", "Musik & Audio": "Music & audio", "Wissen": "Knowledge", "Spiele": "Games",
  "Heimnetz": "Home network", "Neu im Store": "New in store", "Ausgeblendet": "Hidden", "Eigene App": "Own app", "Beliebige Webadresse hinzufügen": "Add any web address",
  "Eigene App hinzufügen": "Add your own app", "Keine passende App gefunden.": "No matching app found.",
  "Jede Webseite kann eine App werden – z. B. dein Medienserver, ein Lieblingsportal oder ein Dienst, der hier noch fehlt.":
    "Any website can become an app – e.g. your media server, a favourite site or a service that's still missing here.",
  "Name, z. B. Mein NAS": "Name, e.g. My NAS", "Adresse, z. B. https://www.beispiel.de": "Address, e.g. https://www.example.com",
  "Bitte einen Namen eingeben.": "Please enter a name.", "Bitte eine gültige Adresse eingeben, z. B. http://192.168.178.20:8096": "Please enter a valid address, e.g. http://192.168.178.20:8096",
  "Es sind schon 30 eigene Apps angelegt.": "There are already 30 own apps.", "Unbekannte App": "Unknown app",
  "Web-App (offizielle Web-Version)": "Web app (official web version)", "Eigene Web-App": "Own web app", "Dienst im Hintergrund": "Background service",
  "Zu den Ton-Einstellungen": "Go to sound settings", "Kostenlos": "Free", "Abo": "Subscription", "Gratis & Abo": "Free & subscription",
  "Kostenlos & Kauf": "Free & purchase", "Kostenlos & Abo": "Free & subscription", "Eigene App ": "Own app ",
  "Vorinstalliert und kostenlos.": "Pre-installed and free.", "Vorinstalliert. Läuft über die offizielle Web-Version – mit deinem eigenen Konto.": "Pre-installed. Runs in the official web version – with your own account.",
  "Adresse deines Jellyfin-Servers": "Address of your Jellyfin server", "Adresse von Home Assistant": "Address of Home Assistant",
  "Abo · Serien & Filme": "Subscription · series & movies", "Abo · Sky-Serien & Filme": "Subscription · Sky series & movies", "Abo · Apple Originals": "Subscription · Apple Originals",
  "Abo · Telekom": "Subscription · Telekom", "Abo · Fernsehen": "Subscription · TV", "Fernsehen · Gratis & Abo": "TV · free & subscription", "Kostenlos · mit Werbung": "Free · with ads",
  "Gratis-Filme & Leihen": "Free movies & rentals", "Abo · Arthouse-Kino": "Subscription · arthouse cinema", "Abo · Klassiker der ARD": "Subscription · ARD classics",
  "Kostenlos · Sport & Doku": "Free · sports & docs", "Kostenlos · Politik & Doku": "Free · politics & docs", "Kostenlos · Filme": "Free · movies",
  "Musik · Gratis & Abo": "Music · free & subscription", "Musik · Abo": "Music · subscription", "Musik · Prime & Abo": "Music · Prime & subscription", "Musik · Kostenlos": "Music · free",
  "Hörspiele & Podcasts": "Audio dramas & podcasts", "Tausende Radiosender": "Thousands of radio stations", "Raspi-TV als Spotify-Lautsprecher": "Raspi-TV as a Spotify speaker",
  "Kostenlos · Spotify Premium": "Free · Spotify Premium", "Nachrichten der ARD": "ARD news", "Nachrichten des ZDF": "ZDF news", "Deutsche Welle": "Deutsche Welle",
  "Europa-Nachrichten": "European news", "Abo · Live-Sport": "Subscription · live sports", "Kostenlos · ARD": "Free · ARD", "Kostenlos & Abo ": "Free & subscription ",
  "Lach- und Sachgeschichten": "Laughing and learning stories", "Für Vorschulkinder": "For preschoolers", "Videos für Kinder": "Videos for kids",
  "Vorträge": "Talks", "Wissen von SWR & WDR": "Knowledge from SWR & WDR", "Bildung & Wissen": "Education & knowledge", "Raumfahrt · Englisch": "Space · English",
  "Cloud-Gaming · Beta": "Cloud gaming · beta", "Programm · Mediacenter ": "Program · media center", "Eigener Medienserver": "Own media server", "Smart Home": "Smart home",
  "Router-Oberfläche": "Router interface", "Fotos & Videos": "Photos & videos", "Webseiten öffnen": "Open websites",
  "Serien, Filme und Kinderprogramm aus dem Paramount-Universum.": "Series, movies and kids' shows from the Paramount universe.",
  "Serien, Filme und Live-Sport aus dem Sky-Angebot – monatlich kündbar.": "Series, movies and live sports from Sky – cancel monthly.",
  "Eigenproduktionen von Apple. Anmeldung mit deiner Apple-ID.": "Apple originals. Sign in with your Apple ID.",
  "Fernsehen, Mediathek und Serien der Telekom – Anmeldung mit deinem Telekom-Login.": "TV, on demand and series from Telekom – sign in with your Telekom login.",
  "Über 200 Fernsehsender per Internet, auch private Sender in HD.": "200+ TV channels over the internet, including private channels in HD.",
  "Fernsehen übers Internet – öffentlich-rechtliche Sender gratis, private im Abo.": "TV over the internet – public channels free, private ones with a subscription.",
  "Über 100 kostenlose Themensender und Filme auf Abruf – ganz ohne Anmeldung.": "100+ free themed channels and movies on demand – no sign-up needed.",
  "Kostenlose Filme mit Werbung, aktuelle Filme zum Leihen oder Kaufen.": "Free movies with ads, new movies to rent or buy.",
  "Handverlesene Filme aus aller Welt – Klassiker, Festivalfilme und Arthouse.": "Hand-picked films from around the world – classics, festival films and arthouse.",
  "Krimis, Serien und Kinderprogramm aus dem ARD-Archiv – Tatort-Klassiker inklusive.": "Crime, series and kids' shows from the ARD archive – Tatort classics included.",
  "Livestream und Mediathek von ServusTV: Dokus, Sport und Unterhaltung.": "ServusTV live stream and library: docs, sports and entertainment.",
  "Ereignisse live, Dokumentationen und Gesprächssendungen.": "Live events, documentaries and talk shows.",
  "Hunderte Spielfilme kostenlos mit Werbung – Action, Horror, Komödie.": "Hundreds of free movies with ads – action, horror, comedy.",
  "Kurzfilme, Musikvideos und Videos von Filmschaffenden.": "Short films, music videos and videos by filmmakers.",
  "Musik, Alben und Musikvideos – kostenlos mit Werbung oder im Abo.": "Music, albums and music videos – free with ads or by subscription.",
  "Über 100 Millionen Titel, Playlists und Podcasts.": "Over 100 million tracks, playlists and podcasts.",
  "Musik in hoher Klangqualität, kuratierte Playlists und Videos.": "High-quality music, curated playlists and videos.",
  "Mit Prime oder Music Unlimited – Alben, Playlists und Podcasts.": "With Prime or Music Unlimited – albums, playlists and podcasts.",
  "Die Apple-Musikbibliothek im Browser. Anmeldung mit deiner Apple-ID.": "The Apple Music library in the browser. Sign in with your Apple ID.",
  "Neue Künstler, DJ-Sets und Remixe.": "New artists, DJ sets and remixes.", "Hörspiele, Krimis, Podcasts und Dokus aller ARD-Sender.": "Audio dramas, crime, podcasts and docs from all ARD stations.",
  "Radiosender aus aller Welt und Podcasts. Für die wichtigsten deutschen Sender gibt es auch die Radio-Kachel auf der Startseite.":
    "Radio stations from around the world and podcasts. The main German stations are also on the Radio tile on the home screen.",
  "Raspi-TV erscheint in der Spotify-App am Handy als Lautsprecher. Musik am Handy aussuchen, auf „Geräte“ tippen, „Raspi-TV“ wählen – der Fernseher spielt, das Handy bleibt Fernbedienung. Titel und Cover erscheinen unten rechts auf dem Bildschirm.":
    "Raspi-TV shows up in the Spotify app on your phone as a speaker. Pick music on the phone, tap “Devices”, choose “Raspi-TV” – the TV plays, the phone stays the remote. Title and cover appear at the bottom right of the screen.",
  "Aktuelle Nachrichten, Sendungen und der Livestream von tagesschau24.": "Latest news, shows and the tagesschau24 live stream.",
  "heute, heute journal und aktuelle Berichte.": "heute, heute journal and current reports.", "Nachrichten, Börse und Videos von n-tv.": "News, markets and videos from n-tv.",
  "Nachrichten und Dokumentationen von WELT.": "News and documentaries from WELT.",
  "Nachrichten und Reportagen aus aller Welt – auch in vielen anderen Sprachen.": "News and reports from around the world – in many languages, too.",
  "Europäische Nachrichten rund um die Uhr im Livestream.": "European news around the clock as a live stream.",
  "Fußball, Basketball, Boxen und mehr live und auf Abruf.": "Football, basketball, boxing and more, live and on demand.",
  "3. Liga, Eishockey, Basketball und Frauenfußball live.": "3. Liga, ice hockey, basketball and women's football live.",
  "Livestreams, Zusammenfassungen und Ergebnisse der ARD.": "ARD live streams, highlights and results.",
  "Live-Sport abseits des Fußballs: Handball, Volleyball, Tischtennis und viel mehr.": "Live sports beyond football: handball, volleyball, table tennis and much more.",
  "Kinderserien und Wissenssendungen aus dem ZDF – ohne Werbung.": "Kids' series and science shows from ZDF – without ads.", "Serien und Videos von Super RTL.": "Series and videos from Super RTL.",
  "Lach- und Sachgeschichten, Filme und Spiele mit der Maus.": "Laughing and learning stories, films and games with the Mouse.",
  "Videos, Lieder und Spiele für die Kleinsten – vom KiKA.": "Videos, songs and games for the little ones – from KiKA.", "Kindgerechte Videos mit Elternbereich.": "Kid-friendly videos with a parents' area.",
  "Tausende Vorträge zu Wissenschaft, Technik und Gesellschaft – oft mit deutschen Untertiteln.": "Thousands of talks on science, technology and society.",
  "Dokus und Erklärfilme für Schule und Neugierige.": "Docs and explainer films for school and the curious.", "Bildungsfernsehen: Wissen, Geschichte, Sprachen.": "Educational TV: knowledge, history, languages.",
  "Raketenstarts live, Dokus und Serien der NASA (auf Englisch).": "Rocket launches live, NASA docs and series.",
  "Spielt deine eigenen Spiele klassischer Konsolen (NES, Game Boy, GBA, SNES, Mega Drive …). Spiele-Dateien vom USB-Stick laden – am besten mit Gamepad. Beenden über das RetroArch-Menü oder die Home-Taste.":
    "Plays your own games for classic consoles (NES, Game Boy, GBA, SNES, Mega Drive …). Load game files from a USB stick – best with a gamepad. Exit via the RetroArch menu or the Home button.",
  "Spiele vom Gaming-PC auf den Fernseher streamen (NVIDIA GameStream oder Sunshine). Wird aus der offiziellen Moonlight-Paketquelle installiert. Gamepad empfohlen.":
    "Stream games from your gaming PC to the TV (NVIDIA GameStream or Sunshine). Installed from the official Moonlight package source. Gamepad recommended.",
  "Spiele aus deiner Steam-/Epic-Bibliothek in der Cloud. Läuft im Browser – ob der Dienst den Pi akzeptiert, ist nicht garantiert. Gamepad empfohlen.":
    "Games from your Steam/Epic library in the cloud. Runs in the browser – it's not guaranteed the service accepts the Pi. Gamepad recommended.",
  "Mit Game Pass Ultimate Xbox-Spiele streamen. Läuft im Browser – nicht offiziell für den Pi. Gamepad nötig.": "Stream Xbox games with Game Pass Ultimate. Runs in the browser – not officially for the Pi. Gamepad needed.",
  "Das bekannte Mediacenter: Filme- und Serienbibliothek mit Covern, Netzwerkfreigaben, Erweiterungen. Bedienung mit Fernbedienung oder Gamepad – Home beendet Kodi.":
    "The well-known media center: movie and series library with covers, network shares, add-ons. Use the remote or a gamepad – Home exits Kodi.",
  "Filme und Serien von deinem Plex-Server – auch von unterwegs.": "Movies and series from your Plex server – also on the go.",
  "Dein eigener, freier Medienserver. Beim Installieren gibst du die Adresse deines Servers ein.": "Your own free media server. When installing you enter your server's address.",
  "Licht, Heizung und Geräte deines Smart Homes auf dem Fernseher.": "Lights, heating and devices of your smart home on the TV.",
  "Die Oberfläche deiner FRITZ!Box – z. B. für das Gäste-WLAN.": "Your FRITZ!Box interface – e.g. for the guest Wi-Fi.", "Deine Fotos und Alben groß auf dem Fernseher.": "Your photos and albums big on the TV.",
  "Suchen und beliebige Webseiten öffnen – mit Bildschirmtastatur und Maus-Modus (grüne Taste). Tipp: Unter Einstellungen → Apps gibt es einen Werbeblocker.":
    "Search and open any website – with the on-screen keyboard and mouse mode (green button). Tip: there's an ad blocker under Settings → Apps.",
  "Die App verschwindet von der Startseite. Deine Anmeldung beim Dienst bleibt gespeichert.": "The app disappears from the home screen. Your login with the service stays saved.",
  "Die App verschwindet von der Startseite. Im App Store kannst du sie jederzeit wieder anzeigen.": "The app disappears from the home screen. You can show it again any time in the App Store.",
  // ---------------------------------------------------------------- Hinweise / Fortschritt
  "Wird auf dem Fernseher geöffnet …": "Opening on the TV …", "OK zeigt Videos, Musik und Fotos": "OK shows videos, music and photos",
  "USB-Speicher erkannt": "USB storage detected", "Software-Update gefunden": "Software update found",
  "Das Gerät ist verbunden": "The device is connected", "Ungültige Einstellung": "Invalid setting", "Ungültige Einstellungen": "Invalid settings",
  "Ungültige Aktion": "Invalid action", "Ungültige Anfrage": "Invalid request", "Ungültige Datei": "Invalid file", "Ungültige Uhrzeit": "Invalid time",
  "Ungültiger Wert": "Invalid value", "Ungültiger Pfad": "Invalid path", "Ungültiger Ort": "Invalid location", "Unbekannte Quelle": "Unknown source",
  "Quelle nicht verfügbar – Stick eingesteckt?": "Source not available – is the stick plugged in?", "Datei zu groß": "File too large",
  "Bitte einen Suchbegriff eingeben.": "Please enter a search term.",
  // ---------------------------------------------------------------- Handy-Fernbedienung (remote.html)
  "Raspi-TV Fernbedienung": "Raspi-TV remote", "Nicht gekoppelt": "Not paired", "Keine Verbindung": "No connection", "Fernseher aus": "TV off",
  "Öffne auf dem Fernseher": "On the TV, open", "Einstellungen → Handy": "Settings → Phone", "und scanne den QR-Code mit der Kamera deines Handys.": "and scan the QR code with your phone's camera.",
  "Play/Pause": "Play/Pause", "CH –": "CH –", "CH +": "CH +", "TV an": "TV on", "TV aus": "TV off", "Zu Raspi-TV": "To Raspi-TV",
  "Mit einem Finger wischen bewegt den Mauszeiger.": "Swipe with one finger to move the pointer.", "Tippen = Klicken · Zwei Finger = Scrollen": "Tap = click · two fingers = scroll",
  "Klick": "Click", "Rechtsklick": "Right-click", "Suchen": "Search",
  "Wähle auf dem Fernseher zuerst ein Textfeld aus (z. B. E-Mail beim Netflix-Login). Dann hier tippen und senden.": "First select a text field on the TV (e.g. email in the Netflix login). Then type here and send.",
  "Text eingeben …": "Type text …", "An Fernseher senden": "Send to TV", "⌫ Löschen": "⌫ Delete", "⇥ Nächstes Feld": "⇥ Next field", "↵ Enter": "↵ Enter", "Gesendet": "Sent",
  "Tippe ins Feld und dann auf das": "Tap the field and then the", "Mikrofon": "microphone", "deiner Handy-Tastatur – einfach sagen, was du suchst.": "on your phone keyboard – just say what you're looking for.",
  "z. B. Tatort, Fußball, Katzenvideos …": "e.g. Tatort, football, cat videos …", "Erst einen Suchbegriff eingeben": "Enter a search term first",
  "Netflix": "Netflix", "YouTube": "YouTube", "ARD Mediathek": "ARD Mediathek", "ZDF Mediathek": "ZDF Mediathek",
  "Programm ·": "TV guide ·", "Sender ·": "Channels ·", "Läuft seit": "Started", "Tipp: Die": "Tip: The",
  "bringt dich aus jeder App zurück. Mit": "brings you back from any app. With", "öffnest du das TV-Programm.": "you open the TV guide.",
  "Sprache / Language": "Language / Sprache",
  "Internet für verbundene Geräte": "Internet for connected devices",
  "An – alle Geräte im WLAN surfen über das LAN-Kabel des Pi": "On – all devices on this Wi-Fi go online via the Pi's network cable",
  "Aus – das WLAN dient nur der Fernbedienung": "Off – this Wi-Fi is only for the remote",
  "Das Handy verbindet sich ab dann von selbst mit diesem WLAN und hat darüber Internet. Weitere Geräte (Tablet, Laptop) scannen einfach Code 1.":
    "From then on the phone joins this Wi-Fi by itself and has internet through it. Other devices (tablet, laptop) simply scan code 1.",
  "Ist Raspi-TV per LAN-Kabel verbunden, kann er ein eigenes WLAN aufspannen – für die Handy-Fernbedienung und auf Wunsch mit Internet für alle verbundenen Geräte. So klappt beides auch, wenn das Heim-WLAN aus ist.":
    "If Raspi-TV is connected by network cable, it can open its own Wi-Fi – for the phone remote and, if you like, with internet for all connected devices. Both then work even when the home Wi-Fi is off.",
  "Raspi-TV startet neu": "Raspi-TV is restarting", "Startanimation wird eingerichtet": "Setting up start-up animation",
  "Sender direkt wählen · nur 0: zurück zum vorherigen Sender": "Choose channel directly · 0 alone: previous channel", "Shopping": "Shopping",
  "Startanimation": "Start-up animation", "Animiertes Raspi-TV-Logo beim Einschalten · jede Taste überspringt sie": "Animated Raspi-TV logo when switching on · any key skips it",
  "Startanimation eingeschaltet": "Start-up animation on", "Startanimation ausgeschaltet": "Start-up animation off",
  "Angehalten": "Paused", "wird aufgenommen": "recording", "Zeitversetzt": "Time-shifted", "ZEITVERSETZT": "TIME-SHIFTED",
  "weiter": "resume", "30 s spulen": "skip 30 s", "Pause": "Pause", "Zurück zu Live": "Back to live",
  "Zeitversetzt nicht möglich – weiter live": "Time-shift not possible – continuing live", "Weiter live": "Continuing live",
  "Aufnahme lässt sich nicht abspielen – zurück zu Live": "Recording can't be played – back to live",
  "Sender ist verschlüsselt (DRM)": "Channel is encrypted (DRM)", "Format wird nicht unterstützt": "Format not supported",
  "Sender liefert kein HLS": "Channel doesn't provide HLS", "Zwischenspeicher voll (2 Stunden)": "Buffer full (2 hours)",
  "Speicherkarte fast voll": "SD card almost full", "Dieser Sender kann nicht angehalten werden": "This channel can't be paused",
  "Mitteilungen": "Notifications", "Anrufe auf dem Fernseher": "Calls on the TV", "Einstellungen · Mitteilungen": "Settings · Notifications",
  "Einschalt-Timer, Ausschalten, Bildschirmschoner": "Wake timer, auto-off, screensaver",
  "Raspi-TV blendet Wichtiges in jeder App ein – auch mitten im Film.": "Raspi-TV shows important things in every app – even in the middle of a film.",
  "Anrufe": "Calls", "Anrufe anzeigen": "Show calls",
  "Name bzw. Nummer des Anrufers erscheint in jeder App (FRITZ!Box)": "The caller's number appears in every app (FRITZ!Box)",
  "Verbunden mit der FRITZ!Box": "Connected to the FRITZ!Box", "Eingehende Anrufe erscheinen oben auf dem Bildschirm.": "Incoming calls appear at the top of the screen.",
  "Anrufmonitor der FRITZ!Box ist aus": "The FRITZ!Box call monitor is off",
  "Einmalig an einem Telefon der FRITZ!Box #96*5* wählen – danach klappt es von selbst.": "Dial #96*5* once on a phone connected to the FRITZ!Box – after that it works by itself.",
  "Keine FRITZ!Box gefunden": "No FRITZ!Box found",
  "Raspi-TV sucht unter der eingetragenen Adresse. Andere Router werden nicht unterstützt.": "Raspi-TV looks at the address entered. Other routers aren't supported.",
  "Ausgeschaltet": "Off", "Verbinde …": "Connecting …", "Bei Anruf Video anhalten": "Pause video on calls",
  "Live-TV wird zwischengespeichert, Apps pausieren – nach dem Telefonat einfach weiterschauen": "Live TV is buffered, apps pause – just keep watching after the call",
  "Adresse der FRITZ!Box": "FRITZ!Box address", "Nur ändern, wenn sie nicht „fritz.box“ heißt": "Only change if it isn't called “fritz.box”",
  "Testanruf anzeigen": "Show test call", "So sieht ein Anruf auf dem Fernseher aus": "This is how a call looks on the TV",
  "Meist „fritz.box“ oder „192.168.178.1“.": "Usually “fritz.box” or “192.168.178.1”.", "Ungültige Adresse": "Invalid address",
  "Einschalten": "Turn on", "Wartung": "Maintenance", "Einschalt-Timer": "Wake timer",
  "Schaltet Fernseher und Raspi-TV zur eingestellten Zeit ein – z. B. morgens die Nachrichten": "Turns on the TV and Raspi-TV at the set time – e.g. the news in the morning",
  "Uhrzeit": "Time", "◀ ▶ in 5-Minuten-Schritten · OK +1 Stunde": "◀ ▶ in 5-minute steps · OK +1 hour",
  "An welchen Tagen": "Which days", "OK wechselt": "OK changes", "Was soll laufen?": "What should play?", "Sender oder Startseite": "Channel or home screen",
  "Startseite": "Home screen", "Montag bis Freitag": "Monday to Friday", "Jeden Tag": "Every day", "Samstag und Sonntag": "Saturday and Sunday", "Nie": "Never",
  "Nachts automatisch neu starten": "Restart automatically at night",
  "Um 4 Uhr, wenn der Fernseher aus ist – hält Raspi-TV dauerhaft frisch": "At 4 am when the TV is off – keeps Raspi-TV fresh",
  "Ungültige Uhrzeit": "Invalid time", "Ungültige Tage": "Invalid days", "Unbekannter Sender": "Unknown channel",
  "Ohne Kamera: im Handy-Browser öffnen": "Without camera: open in the phone's browser",
  "Altes Android-Handy als feste Fernbedienung": "Old Android phone as a dedicated remote",
  "Die Raspi-TV-App (ab Android 4.4) steuert über": "The Raspi-TV app (Android 4.4+) controls via", "– ganz ohne WLAN.": "– no Wi-Fi needed.",
  "Sie kann als Startbildschirm des Handys eingestellt werden: Handy an = Fernbedienung.": "It can be set as the phone's home screen: phone on = remote.",
  "1 · App aufs Handy laden": "1 · Get the app onto the phone",
  "QR-Code mit dem Handy scannen (Handy kurz im WLAN) – oder die Datei raspi-tv-remote.apk vom PC kopieren": "Scan the QR code with the phone (briefly on Wi-Fi) – or copy raspi-tv-remote.apk from the PC",
  "2 · Handy-App koppeln": "2 · Pair phone app",
  "Macht Raspi-TV 3 Minuten lang sichtbar, dann in der App „Raspi-TV auswählen“": "Makes Raspi-TV visible for 3 minutes, then tap “Choose Raspi-TV” in the app",
  "Raspi-TV ist 3 Minuten lang sichtbar": "Raspi-TV is visible for 3 minutes", "Bluetooth-Empfang nicht bereit": "Bluetooth receiver not ready",
  "Gekoppelt · OK entfernt das Handy": "Paired · OK removes the phone", "Raspi-TV-App aufs Handy laden": "Get the Raspi-TV app onto the phone",
  "1. Handy kurz ins WLAN (Heim- oder Fernbedienungs-WLAN) und den Code scannen.": "1. Briefly connect the phone to Wi-Fi (home or remote Wi-Fi) and scan the code.",
  "2. Die Datei öffnen. Fragt Android nach „Unbekannte Herkunft“: in den Einstellungen erlauben.": "2. Open the file. If Android asks about “Unknown sources”, allow it in the settings.",
  "3. App öffnen – danach braucht sie kein WLAN mehr.": "3. Open the app – after that it doesn't need Wi-Fi.",
  "Das Handy kann Raspi-TV danach erst nach erneutem Koppeln steuern.": "The phone can only control Raspi-TV again after pairing again.",
  "Erst mit dem Heimnetz verbinden": "Connect to the home network first",
  "Design & Aufbau": "Look & layout", "Farben, Startseite, Animationen": "Colours, home screen, animations",
  "Einstellungen · Design & Aufbau": "Settings · Look & layout",
  "Such dir aus, wie Raspi-TV aussieht. Änderungen wirken sofort.": "Choose how Raspi-TV looks. Changes apply right away.",
  "Design": "Theme", "Akzentfarbe": "Accent colour", "Aufbau der Startseite": "Home screen layout", "Feinheiten": "Details",
  "Auf der Startseite zeigen": "Show on the home screen",
  "Mitternacht": "Midnight", "Dunkelblau – Standard": "Dark blue – default", "OLED Schwarz": "OLED black",
  "Tiefschwarz, für OLED-Fernseher": "Pure black, for OLED TVs", "Polarlicht": "Aurora", "Türkis und Violett": "Turquoise and violet",
  "Abendrot": "Sunset", "Warme Orangetöne": "Warm orange tones", "Wald": "Forest", "Ruhiges Grün": "Calm green",
  "Kino": "Cinema", "Dunkelrot wie im Kinosaal": "Dark red like a movie theatre", "Hell": "Light", "Für helle Räume am Tag": "For bright rooms during the day",
  "Automatisch": "Automatic", "Hell am Tag, abends dunkel": "Light during the day, dark in the evening",
  "Vom Design": "From theme", "Blau": "Blue", "Violett": "Violet", "Türkis": "Turquoise", "Grün": "Green", "Gold": "Gold",
  "Orange": "Orange", "Rot": "Red", "Pink": "Pink",
  "Klassisch": "Classic", "Große Kacheln, darunter Reihen": "Large tiles, rows below", "Kompakt": "Compact",
  "Mehr Sender auf einen Blick": "More channels at a glance", "Großes Bild der laufenden Sendung": "Big picture of the current show",
  "Seitenleiste": "Sidebar", "Menü links, Inhalte rechts": "Menu on the left, content on the right", "Minimal": "Minimal",
  "Große Uhr, nur das Wichtigste": "Big clock, just the essentials",
  "Hintergrund": "Background", "Leuchtend · Bewegt · Schlicht": "Glowing · Moving · Plain", "Leuchtend": "Glowing", "Bewegt": "Moving", "Schlicht": "Plain",
  "Animationen": "Animations", "Auf älteren Pis läuft „Reduziert“ oder „Aus“ flüssiger": "On older Pis “Reduced” or “Off” runs smoother",
  "Volle Animationen": "Full animations", "Reduziert": "Reduced", "Aus (am schnellsten)": "Off (fastest)",
  "Ecken": "Corners", "Form der Kacheln und Knöpfe": "Shape of tiles and buttons", "Rund": "Round", "Sehr rund": "Extra round", "Eckig": "Square",
  "Auf Standard zurücksetzen": "Reset to default", "Mitternacht · Klassisch · alles sichtbar": "Midnight · Classic · everything visible",
  "Zuletzt gesehene Sender und Videos": "Recently watched channels and videos", "Was gerade auf den Sendern läuft": "What's on right now",
  "Deine Apps als Reihe": "Your apps as a row", "Wetter": "Weather", "Temperatur oben rechts": "Temperature at the top right",
  "Suchfeld oben rechts": "Search box at the top right", "Jetzt auf": "Now on", "▶ Weiterschauen": "▶ Keep watching",
  "Kindersicherung": "Parental controls", "PIN, Kinder-Modus, Tageslimit": "PIN, kids mode, daily limit",
  "Einstellungen · Kindersicherung": "Settings · Parental controls", "Geschützt": "Protected", "PIN eingeben": "Enter PIN",
  "Im Kinder-Modus ist dieser Bereich gesperrt.": "This area is locked in kids mode.", "Die Einstellungen sind mit einem PIN geschützt.": "The settings are protected by a PIN.",
  "Kinder-Modus: PIN eingeben": "Kids mode: enter PIN", "Falscher PIN": "Wrong PIN", "Zu viele falsche Versuche – bitte 5 Minuten warten.": "Too many wrong attempts – please wait 5 minutes.",
  "Neuen PIN festlegen": "Set a new PIN", "4 Ziffern – merk ihn dir gut.": "4 digits – remember it well.", "PIN wiederholen": "Repeat PIN",
  "Zur Sicherheit noch einmal.": "Once more, to be sure.", "Die PINs stimmen nicht überein": "The PINs don't match", "PIN gespeichert": "PIN saved",
  "Kinder-Modus beenden": "Exit kids mode", "Bitte den PIN eingeben.": "Please enter the PIN.", "Kinder-Modus beendet": "Kids mode ended",
  "Schlafenszeit": "Bedtime", "Fernsehzeit für heute vorbei": "TV time is over for today", "Für heute ist Schluss – schlaf gut!": "That's it for today – sleep well!",
  "Morgen geht es weiter. Wie wäre es jetzt mit Spielen, Malen oder Lesen?": "More tomorrow. How about playing, drawing or reading now?",
  "Mit PIN: 30 Minuten länger": "With PIN: 30 more minutes", "Mit PIN: Kinder-Modus beenden": "With PIN: exit kids mode", "30 Minuten länger": "30 more minutes",
  "30 Minuten mehr – viel Spaß!": "30 more minutes – have fun!",
  "Mit einem PIN schützt du die Einstellungen. Im": "A PIN protects the settings. In", "Kinder-Modus": "kids mode",
  "sind nur Kindersender und Kinder-Apps zu sehen – auf Wunsch mit Tageslimit und Schlafenszeit. Beenden lässt er sich nur mit dem PIN.": "only kids' channels and apps are shown – optionally with a daily limit and bedtime. It can only be ended with the PIN.",
  "PIN ändern": "Change PIN", "PIN festlegen": "Set PIN", "4 Ziffern · schützt Einstellungen und Kinder-Modus": "4 digits · protects settings and kids mode",
  "Zuerst einen 4-stelligen PIN festlegen": "First set a 4-digit PIN", "Einstellungen mit PIN schützen": "Protect settings with PIN",
  "Ohne PIN lassen sich die Einstellungen nicht öffnen": "Settings can't be opened without the PIN", "Kinder-Modus einschalten": "Turn on kids mode",
  "Tageslimit im Kinder-Modus": "Daily limit in kids mode", "Kein Limit": "No limit",
  "Ab dieser Uhrzeit bis 6 Uhr ist Fernsehen im Kinder-Modus gesperrt": "From this time until 6 am, TV is locked in kids mode",
  "Kindersender": "Kids' channels", "Auswählen": "Choose", "PIN entfernen": "Remove PIN", "Schaltet die Kindersicherung ganz aus": "Turns parental controls off completely",
  "PIN entfernen?": "Remove PIN?", "Die Kindersicherung ist danach ganz aus.": "Parental controls will then be off completely.",
  "Kinder-Modus einschalten?": "Turn on kids mode?", "Danach sind nur Kindersender und Kinder-Apps zu sehen. Beenden geht nur mit dem PIN.": "Afterwards only kids' channels and apps are shown. Ending requires the PIN.",
  "Einschalten": "Turn on", "Kinder-Modus ist an": "Kids mode is on", "Diese Sender sind im Kinder-Modus zu sehen.": "These channels are shown in kids mode.",
  "Bitte zuerst einen PIN festlegen.": "Please set a PIN first.", "Der PIN muss aus 4 Ziffern bestehen.": "The PIN must have 4 digits.",
  "Aufnahmen": "Recordings", "Aufgenommene Sendungen": "Recorded shows", "Fertige Aufnahmen": "Finished recordings", "Läuft & geplant": "Recording & scheduled",
  "Nicht geklappt": "Didn't work", "Geplant": "Scheduled", "AUFNAHME": "RECORDING", "Abspielen": "Play", "Speicherort": "Storage location",
  "Noch keine Aufnahmen": "No recordings yet", "Im TV-Programm eine Sendung auswählen und „● Aufnehmen“ wählen.": "Choose a show in the TV guide and select “● Record”.",
  "Aufnahmen speichern auf": "Save recordings to", "Aufnahme beenden?": "Stop recording?", "Das bisher Aufgenommene bleibt erhalten.": "What has been recorded so far is kept.",
  "Beenden": "Stop", "Geplante Aufnahme löschen?": "Delete scheduled recording?", "Aufnahme löschen?": "Delete recording?", "Aufnahme gelöscht": "Recording deleted",
  "● Aufnehmen": "● Record", "● Ab jetzt aufnehmen": "● Record from now", "Aufnahme beenden": "Stop recording", "Aufnahme löschen": "Delete recording",
  "Aufnahme beendet": "Recording stopped", "Aufnahme läuft": "Recording", "Aufnehmen": "Record", "Sendung aufnehmen": "Record show", "● Läuft – beenden": "● Recording – stop",
  "Aufnahme startet …": "Starting recording …", "Aufnahme beendet – zu finden unter Eigene Medien → Aufnahmen": "Recording stopped – find it under My media → Recordings",
  "Speicherkarte": "SD card", "Sender nicht gefunden": "Channel not found", "Diese Sendung wird schon aufgenommen.": "This show is already being recorded.",
  "Die Sendung ist schon vorbei.": "The show is already over.", "Zu wenig Speicherplatz frei": "Not enough free storage",
  "Raspi-TV war zu der Zeit aus": "Raspi-TV was off at that time", "Läuft gerade – erst die Aufnahme beenden.": "Recording right now – stop it first.",
  "Nachrichten": "News", "Aktuelle Schlagzeilen (tagesschau, ZDF, DW …)": "Current headlines (tagesschau, ZDF, DW …)",
  "Nachrichtenquelle": "News source", "Für die Schlagzeilen auf der Startseite und im Bildschirmschoner": "For the headlines on the home screen and in the screensaver",
  "Ganzen Artikel lesen": "Read full article", "gerade eben": "just now",
  "Keine Fotos gefunden": "No photos found", "Steck einen USB-Stick mit Fotos an – dann laufen sie hier als Diashow.": "Plug in a USB stick with photos – they'll run here as a slideshow.",
  "Stil des Bildschirmschoners": "Screensaver style", "Uhr & Programm · Analoge Uhr · Fotos · Dunkel": "Clock & programme · Analogue clock · Photos · Dark",
  "Uhr & Programm": "Clock & programme", "Analoge Uhr": "Analogue clock", "Fotos vom USB-Stick": "Photos from USB stick", "Dunkel (schont OLED)": "Dark (OLED friendly)",
  "Nachrichten im Bildschirmschoner": "News in the screensaver", "Schlagzeilen laufen unten durchs Bild": "Headlines scroll along the bottom",
  "Systemmonitor": "System monitor", "Prozessor": "Processor", "Temperatur": "Temperature", "Arbeitsspeicher": "Memory",
  "Internet": "Internet", "Internet-Geschwindigkeit testen": "Test internet speed",
  "Misst Download, Upload und Antwortzeit (dauert ca. 20 Sekunden)": "Measures download, upload and latency (takes about 20 seconds)",
  "Antwortzeit …": "Latency …", "Download …": "Download …", "Upload …": "Upload …",
  "Reicht für alles, auch HD-Streaming auf mehreren Geräten.": "Enough for everything, even HD streaming on several devices.",
  "Reicht für HD-Streaming.": "Enough for HD streaming.", "Reicht für normale Bildqualität.": "Enough for normal picture quality.",
  "Eher langsam – Streams können ruckeln.": "Rather slow – streams may stutter.",
  "Das Netzteil ist zu schwach oder das Kabel zu dünn. Ein offizielles Raspberry-Pi-Netzteil verhindert Ruckler und Abstürze.": "The power supply is too weak or the cable too thin. An official Raspberry Pi power supply prevents stutters and crashes.",
  "Meist wegen Wärme oder Unterspannung. Ein Gehäuse mit Lüfter oder Kühlkörper hilft.": "Usually due to heat or undervoltage. A case with a fan or heatsink helps.",
  "Für gute Belüftung sorgen – nicht hinter dem Fernseher einklemmen.": "Make sure there's good ventilation – don't squeeze it behind the TV.",
  "Tonspur": "Audio track", "Untertitel": "Subtitles", "Bildformat": "Picture format", "Original": "Original", "Zoom (füllt das Bild)": "Zoom (fills the screen)",
  "Strecken": "Stretch", "Audiodeskription": "Audio description", "Klare Sprache": "Clear speech", "Originalton": "Original audio",
  "Deutsch": "German", "Englisch": "English", "Französisch": "French", "Aufnahme": "Recording", "Aufnahme beendet": "Recording stopped",
  "Test nicht möglich – ist Raspi-TV mit dem Internet verbunden?": "Test not possible – is Raspi-TV connected to the internet?",
  "Meine Lieblingssender": "My favourite channels",
  "Löschen": "Delete", "Im TV-Programm eine Sendung auswählen und „● Aufnehmen“ wählen.": "Choose a show in the TV guide and select “● Record”.",
  "Beim Fernsehen nimmt ▶ Optionen → Aufnehmen die laufende Sendung auf.": "While watching, ▶ Options → Record records the current show.",
  "Aufbau": "Layout", "Aussehen der Handy-App": "Phone app appearance", "Farben, Aufbau und Reiter der Handy-Fernbedienung": "Colours, layout and tabs of the phone remote",
  "Farben und Aufbau der Handy-Fernbedienung – für die Raspi-TV-App und die Fernbedienung im Browser.": "Colours and layout of the phone remote – for the Raspi-TV app and the remote in the browser.",
  "Das Handy übernimmt die Einstellung in wenigen Sekunden und merkt sie sich.": "The phone picks up the setting within seconds and remembers it.",
  "Farbschema": "Colour scheme", "Wie der Fernseher": "Same as the TV", "Folgt Design & Aufbau": "Follows Design & layout",
  "Steuerkreuz, Wippen, alle Tasten": "D-pad, rockers, all buttons", "Große Tasten": "Big buttons", "Weniger Knöpfe, leicht zu treffen": "Fewer buttons, easy to hit",
  "Wischfläche": "Swipe pad", "Wischen statt Steuerkreuz": "Swipe instead of a d-pad", "Wippen oben": "Rockers on top",
  "Lautstärke und Sender zuerst": "Volume and channels first", "Reiter unten": "Tabs at the bottom", "Vorschau": "Preview",
  "„Jetzt läuft“ oben": "“Now playing” on top", "Sender, Sendung und Fortschritt über dem Steuerkreuz": "Channel, show and progress above the d-pad",
  "Wippen": "Rockers", "Für Links- oder Rechtshänder": "For left- or right-handed use", "Lautstärke links": "Volume on the left", "Lautstärke rechts": "Volume on the right",
  "Form der Tasten": "Shape of the buttons", "Wie der Fernseher · Klassisch · alle Reiter": "Same as the TV · Classic · all tabs",
  "Reiter „Sender“": "“Channels” tab", "Senderliste mit Jetzt & Danach": "Channel list with now & next", "Reiter „Maus“": "“Mouse” tab",
  "Touchpad für Webseiten und Apps": "Touchpad for websites and apps", "Reiter „Tastatur“": "“Keyboard” tab", "Text eingeben, z. B. Passwörter": "Type text, e.g. passwords",
  "Reiter „Suchen“": "“Search” tab", "Sprachsuche im TV-Programm und in Apps": "Voice search in the guide and apps", "Aussehen": "Appearance",
  "Einstellungen · Fernbedienung · Handy-App": "Settings · Remote · Phone app",
  "Für Bastler": "For tinkerers", "Terminal": "Terminal",
  "Kommandozeile auf dem Pi · Benutzer admin, sudo mit Passwort raspitv · tippen mit USB-Tastatur oder Handy": "Command line on the Pi · user admin, sudo password raspitv · type with a USB keyboard or phone",
  "Werkzeug · Kommandozeile": "Tool · command line", "App · läuft im Hintergrund": "App · keeps playing in the background",
  "Spotify Web": "Spotify Web", "Musik · auch ohne Premium": "Music · works without Premium", "Premium": "Premium",
  "iPhone als Fernbedienung": "iPhone as a remote", "Apple-TV-Fernbedienung im Kontrollzentrum (HomeKit)": "Apple TV Remote in Control Center (HomeKit)",
  "iPhone-Fernbedienung (HomeKit)": "iPhone remote (HomeKit)", "Bereit zum Hinzufügen": "Ready to add", "Wird eingerichtet …": "Setting up …",
  "Startet …": "Starting …", "Aus · beim ersten Einschalten werden ca. 15 MB geladen": "Off · about 15 MB are downloaded the first time",
  "Wird eingerichtet": "Setting up", "Zur Home-App hinzufügen": "Add to the Home app", "So bedienst du Raspi-TV": "How to control Raspi-TV",
  "Kopplung zurücksetzen": "Reset pairing", "Kopplung zurücksetzen?": "Reset pairing?", "Zurücksetzen": "Reset", "Kopplung zurückgesetzt": "Pairing reset",
  "Neuer Code – das iPhone muss Raspi-TV neu hinzufügen (vorher in der Home-App entfernen)": "New code – the iPhone has to add Raspi-TV again (remove it in the Home app first)",
  "Raspi-TV muss danach in der Home-App neu hinzugefügt werden.": "Raspi-TV then has to be added again in the Home app.",
  "Das iPhone muss im selben WLAN sein wie Raspi-TV (Heim-WLAN oder Raspi-TV-WLAN).": "The iPhone must be on the same Wi-Fi as Raspi-TV (home Wi-Fi or Raspi-TV Wi-Fi).",
  "Einstellungen · Fernbedienung · iPhone": "Settings · Remote · iPhone", "Aussehen & iPhone": "Appearance & iPhone",
  //@NEW
};

const MONTHS = { Januar: "January", Februar: "February", März: "March", April: "April", Mai: "May", Juni: "June", Juli: "July", August: "August",
  September: "September", Oktober: "October", November: "November", Dezember: "December" };
const DAYS = { Montag: "Monday", Dienstag: "Tuesday", Mittwoch: "Wednesday", Donnerstag: "Thursday", Freitag: "Friday", Samstag: "Saturday", Sonntag: "Sunday" };

// Texte mit Namen/Zahlen darin
const I18N_PATTERNS = [
  [/^(Montag|Dienstag|Mittwoch|Donnerstag|Freitag|Samstag|Sonntag), (\d+)\. (\w+)$/, (m, d, n, mo) => `${DAYS[d]}, ${MONTHS[mo] || mo} ${n}`],
  [/^(Montag|Dienstag|Mittwoch|Donnerstag|Freitag|Samstag|Sonntag), (\d+)\.(\d+)\.?$/, (m, d, a, b) => `${DAYS[d]}, ${a}/${b}`],
  [/^Heute, (.+)$/, "Today, $1"], [/^Morgen, (.+)$/, "Tomorrow, $1"], [/^Stand: Heute, (.+) Uhr · (\d+) Sender$/, "Updated: today, $1 · $2 channels"],
  [/^Stand: (.+) · (\d+) Sender$/, "Updated: $1 · $2 channels"],
  [/^(\d+) Sender$/, "$1 channels"], [/^(\d+) gefunden$/, "$1 found"], [/^(.+) von (.+)$/, null],
  [/^Version (.+) installieren$/, "Install version $1"], [/^Version (.+) wiederherstellen$/, "Restore version $1"],
  [/^Version (.+) ist verfügbar \(installiert: (.+)\)$/, "Version $1 is available (installed: $2)"],
  [/^Raspi-TV ist aktuell \(Version (.+)\)\.?$/, "Raspi-TV is up to date (version $1)"], [/^Version (.+)$/, "Version $1"],
  [/^Gesichert am (.+) vor einem Update$/, "Saved on $1 before an update"], [/^Zu Version (.+) zurück\?$/, "Go back to version $1?"],
  [/^Version (.+) installieren\?$/, "Install version $1?"], [/^Fertig – Raspi-TV (.*) startet neu …$/, "Done – Raspi-TV $1 is restarting …"],
  [/^(.+) auf „(.+)“ · installiert ist Version (.+)$/, "$1 on “$2” · installed: version $3"],
  [/^Am PC „Update-Paket\.bat“ starten, die Datei raspi-tv-update\.zip auf einen USB-Stick kopieren und einstecken\. Installiert: Version (.+)$/,
    "On your PC, run “Update-Paket.bat”, copy raspi-tv-update.zip to a USB stick and plug it in. Installed: version $1"],
  [/^Wiederherstellen: (.+)$/, "Restore: $1"], [/^(.+) · Version (.+) · auf „(.+)“$/, "$1 · version $2 · on “$3”"],
  [/^Gesichert auf „(.+)“ \((.+)\)$/, "Saved to “$1” ($2)"], [/^(\d+) Einträge wiederhergestellt – Raspi-TV startet neu …$/, "$1 items restored – Raspi-TV is restarting …"],
  [/^Einstellungen vom (.+) werden übernommen, danach startet die Oberfläche neu\. Anmeldungen in Netflix & Co\. musst du neu eingeben\.$/,
    "Settings from $1 will be applied, then the interface restarts. You'll need to sign in to Netflix & co. again."],
  [/^Nächstes Mal (heute|morgen|Mo|Di|Mi|Do|Fr|Sa|So) um (\d\d:\d\d) Uhr$/, (m, d, t) => "Next: " + ({ heute: "today", morgen: "tomorrow", Mo: "Mon", Di: "Tue", Mi: "Wed", Do: "Thu", Fr: "Fri", Sa: "Sat", So: "Sun" }[d]) + " at " + t],
  [/^(.+) → Code eingeben \(gilt 15 Minuten\)$/, "$1 → enter the code (valid for 15 minutes)"],
  [/^Raspi-TV ist jetzt sichtbar – in der App „Raspi-TV auswählen“ tippen und „(.+)“ wählen$/, "Raspi-TV is now visible – in the app tap “Choose Raspi-TV” and pick “$1”"],
  [/^(.+) entfernen\?$/, "Remove $1?"],
  [/^Startseite: (.+)$/, (m, x) => "Home screen: " + tr(x)],
  [/^Jetzt auf (.+): (.+)$/, "Now on $1: $2"], [/^(.+) – (.+) · Danach: (.+)$/, "$1 – $2 · Next: $3"],
  [/^Heute geschaut: (\d+) Min\.$/, "Watched today: $1 min"], [/^Nur (\d+) Kindersender und Kinder-Apps · Beenden nur mit PIN$/, "Only $1 kids' channels and kids' apps · ends only with PIN"],
  [/^Aufnahme für (.+), (.+) geplant$/, "Recording scheduled for $1, $2"], [/^● Aufnahme läuft bis (.+) Uhr$/, "● Recording until $1"],
  [/^Gerade: (.+) · (.+) frei · Automatisch nimmt einen USB-Stick, wenn einer steckt$/, "Now: $1 · $2 free · Automatic uses a USB stick if one is plugged in"],
  [/^(\d+) Std\. (\d+) Min\.$/, "$1 h $2 min"], [/^(\d+) Std\.$/, "$1 h"],
  [/^vor (\d+) Min\.$/, "$1 min ago"], [/^vor (\d+) Std\.$/, "$1 h ago"], [/^(.+) frei$/, "$1 free"],
  [/^Unterspannung (gerade jetzt|seit dem Start) erkannt$/, (m, x) => "Undervoltage detected " + (x === "gerade jetzt" ? "right now" : "since start-up")],
  [/^Der Pi hat sich (gerade|zwischendurch) gedrosselt$/, (m, x) => "The Pi has throttled " + (x === "gerade" ? "right now" : "at times")],
  [/^Sehr warm \((\d+) °C\)$/, "Very warm ($1 °C)"], [/^Spur (\d+)$/, "Track $1"],
  [/^Aktiv – WLAN „(.+)“$/, "Active – Wi-Fi “$1”"], [/^Schaltet sich um (.+) Uhr ein$/, "Turns on at $1"], [/^(\d\d:\d\d) Uhr$/, "$1"],
  [/^Aktiv – in der Spotify-App unter „Geräte“ „(.+)“ wählen$/, "Active – in the Spotify app choose “$1” under “Devices”"],
  [/^Fertig! In der Spotify-App auf „Geräte“ tippen und „(.+)“ wählen\.$/, "Done! In the Spotify app tap “Devices” and choose “$1”."],
  [/^Aktiv – am iPhone im Kontrollzentrum „(.+)“ wählen$/, "Active – on the iPhone choose “$1” in Control Center"],
  [/^Aktiv – in Apps wie BubbleUPnP oder „Wiedergabe auf Gerät“ \(Windows\) „(.+)“ wählen$/, "Active – choose “$1” in apps like BubbleUPnP or “Cast to device” (Windows)"],
  [/^Handy-Fernbedienung, Funk-Tastatur und Air-Maus steuern (.+)$/, (m, x) => "Phone remote, wireless keyboard and air mouse control " +
    ({ "den Fernseher": "the TV", "die Soundbar": "the soundbar", "Raspi-TV selbst": "Raspi-TV itself" }[x] || x)],
  [/^Gefunden: (.+)$/, (m, x) => "Found: " + x.replace(/Fernseher „/g, "TV “").replace(/Soundbar „/g, "Soundbar “").replace(/^Fernseher$/, "TV")],
  [/^(.+) ist installiert – du findest (?:die App|es) auf der Startseite\.$/, "$1 is installed – you'll find it on the home screen."],
  [/^(.+) ist jetzt auf der Startseite\.$/, "$1 is now on the home screen."], [/^(.+) wurde entfernt\.$/, "$1 was removed."], [/^(.+) wurde ausgeblendet\.$/, "$1 was hidden."],
  [/^(.+) entfernen\?$/, "Remove $1?"], [/^(.+) ausblenden\?$/, "Hide $1?"], [/^(.+) einrichten$/, "Set up $1"],
  [/^Installiere (.+)$/, "Installing $1"], [/^Entferne (.+)$/, "Removing $1"], [/^(.+) wird gestartet …$/, "$1 is starting …"],
  [/^Zum Beenden: (.+)$/, null], [/^(.+) wird vom System gelöscht\. Einstellungen des Programms bleiben erhalten\.$/, "$1 will be removed from the system. The program's settings are kept."],
  [/^Liegt auf der Startseite unter „Apps“(.*)\.$/, (m, x) => "On the home screen under “Apps”" + (x.includes("Filme") ? " and under “Movies & series”" : x.includes("Mediathek") ? " and in “On demand”" : "") + "."],
  [/^Suche: „(.+)“ · (\d+) Treffer$/, "Search: “$1” · $2 results"], [/^Beta · (.+)$/, (m, x) => "Beta · " + tr(x)],
  [/^(.+) ist gerade nicht erreichbar\.$/, "$1 is currently unreachable."], [/^Ort gespeichert: (.+)$/, "Location saved: $1"],
  [/^(.+) · gefühlt (.+)$/, (m, a, b) => tr(a) + " · feels like " + b], [/^Wind (.+) · Luftfeuchte (.+)$/, "Wind $1 · humidity $2"], [/^Regen (\d+ %)$/, "Rain $1"],
  [/^Regen · gefühlt (.+)$/, "Rain · feels like $1"], [/^Weiter mit (.+)$/, "Continue with $1"], [/^Läuft seit (.+)$/, "Started $1"], [/^Beginnt um (.+)$/, "Starts at $1"],
  [/^Danach$/, "Next"], [/^Schlaf-Timer: Ausschalten in$/, "Sleep timer: off in"], [/^in (\d+) Min\.$/, "in $1 min"], [/^(\d+) Min\.$/, "$1 min"],
  [/^Nach (\d+) Minuten$/, "After $1 minutes"], [/^Nach (\d+) Stunden$/, "After $1 hours"], [/^Nach (\d+) Stunde$/, "After $1 hour"],
  [/^Ausgabe · (\d+ %)$/, "Output · $1"], [/^(\d+) Hz · aktuell$/, "$1 Hz · current"], [/^IP-Adresse (.+)$/, "IP address $1"],
  [/^Lautstärke (\d+) %$/, "Volume $1 %"], [/^Stumm · (\d+) %$/, "Muted · $1 %"], [/^(.+) ✓$/, (m, x) => tr(x) + " ✓"],
  [/^Verbindung fehlgeschlagen[:–] ?(.*)$/, "Connection failed: $1"], [/^Name konnte nicht geändert werden: (.*)$/, "Name couldn't be changed: $1"],
  [/^Erinnerung für „(.+)“ gesetzt$/, "Reminder set for “$1”"], [/^Letztes Update: (.+)$/, (m, x) => "Last update: " + tr(x)],
  [/^Neue Version läuft$/, "New version running"],
  [/^Verbunden mit (.+)$/, "Connected to $1"], [/^Aktiv – WLAN „(.+)“ · (\d+) Geräte? verbunden$/, (m, a, n) => `Active – Wi-Fi “${a}” · ${n} device${n === "1" ? "" : "s"} connected`], [/^Wird eingerichtet \(lädt (.+)\) …$/, "Setting up (downloading $1) …"],
  [/^WLAN konnte nicht (angelegt|gestartet) werden(.*?): (.*)$/, (m, a, h, e) => "Wi-Fi couldn't be " + (a === "angelegt" ? "created" : "started") + (h ? " " + h.replace("dnsmasq fehlt", "dnsmasq missing").replace("WLAN-Chip unterstützt den Zugangspunkt-Modus nicht", "Wi-Fi chip doesn't support access point mode") : "") + ": " + e], [/^(\d+) Sender · (.+)$/, "$1 channels · $2"],
];

function tr(s) {
  if (I18N.lang !== "en" || !s) return s;
  return trRaw(s).replace(/„([^“„]*)“/g, "“$1”");   // deutsche Anführungszeichen → englische
}
function trRaw(s) {
  const hit = I18N_EN[s];
  if (hit !== undefined) return hit;
  for (const [re, rep] of I18N_PATTERNS) {
    if (rep && re.test(s)) return s.replace(re, rep);
  }
  return s;
}

const I18N = {
  lang: "de",
  observer: null,
  done: new WeakSet(),

  set(lang) {
    lang = lang === "en" ? "en" : "de";
    try { localStorage.setItem("raspi-tv.lang", lang); } catch (_) {}
    if (lang === this.lang) return;
    const was = this.lang;
    this.lang = lang;
    document.documentElement.lang = lang;
    if (lang === "en") this.start();
    else if (was === "en") location.reload();   // zurück zu Deutsch: einfach neu laden
  },

  textNode(n) {
    const raw = n.nodeValue;
    const t = raw.replace(/\s+/g, " ").trim();
    if (!t || !/[A-Za-zÄÖÜäöüß]/.test(t)) return;
    const out = tr(t);
    if (out !== t) n.nodeValue = raw.match(/^\s*/)[0] + out + raw.match(/\s*$/)[0];
  },

  el(el) {
    for (const a of ["placeholder", "title", "aria-label"]) {
      const v = el.getAttribute && el.getAttribute(a);
      if (v) { const o = tr(v); if (o !== v) el.setAttribute(a, o); }
    }
  },

  walk(root) {
    if (root.nodeType === 3) return this.textNode(root);
    if (root.nodeType !== 1 || root.tagName === "SCRIPT" || root.tagName === "STYLE" || root.tagName === "TEXTAREA") return;
    this.el(root);
    const it = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
    let n;
    while ((n = it.nextNode())) {
      if (n.nodeType === 3) {
        const p = n.parentNode;
        if (p && (p.tagName === "SCRIPT" || p.tagName === "STYLE" || p.tagName === "TEXTAREA")) continue;
        this.textNode(n);
      } else this.el(n);
    }
  },

  start() {
    if (this.observer || !document.body) return;
    this.walk(document.body);
    document.title = tr(document.title);
    this.observer = new MutationObserver(muts => {
      for (const m of muts) {
        if (m.type === "characterData") this.textNode(m.target);
        else if (m.type === "attributes") this.el(m.target);
        else m.addedNodes.forEach(n => this.walk(n));
      }
    });
    this.observer.observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true,
      attributeFilter: ["placeholder", "title", "aria-label"] });
  },

  init() {
    let lang = "de";
    try { lang = localStorage.getItem("raspi-tv.lang") || "de"; } catch (_) {}
    const go = () => this.set(lang);
    if (document.body) go(); else document.addEventListener("DOMContentLoaded", go);
  },
};
I18N.init();
// Auf dem Fernseher (Port 8765) die eingestellte Sprache holen
if (location.port === "8765") {
  fetch("/api/config").then(r => r.json()).then(c => I18N.set(c.lang)).catch(() => {});
}
