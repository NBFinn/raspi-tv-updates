/* Raspi-TV OS – Startanimation der Oberfläche (einmal pro Einschalten)
 *
 * Ablauf: Leuchten blendet auf → Fernseher-Rahmen wird gezeichnet → Druckwelle →
 * Play-Dreieck ploppt mit Funkenregen → Schriftzug Buchstabe für Buchstabe →
 * Lichtstreifen → Begrüßung. Danach fliegt das Logo an seinen Platz oben links
 * (Startseite) oder zoomt „in den Fernseher hinein“ (Start mit Live-TV).
 *
 *   Intro.finish("home" | "tv")  -> Promise, wenn die Animation fertig ist
 *   Intro.skip()                 -> sofort entfernen
 * Jede Taste überspringt. Abschaltbar unter Einstellungen · System.
 */
"use strict";

const Intro = (() => {
  const KEY = "raspi-tv.intro";
  const MIN_MS = 2700;          // so lange läuft die Animation mindestens
  const MAX_MS = 9000;          // Sicherheitsnetz, falls der Start hängt
  let el = null, t0 = 0, closing = null, skipRequested = false;

  function shouldPlay() {
    try {
      if (sessionStorage.getItem(KEY)) return false;
      sessionStorage.setItem(KEY, "1");
    } catch (_) { return false; }
    if (/[?&]intro=1/.test(location.search)) return true;
    if (navigator.webdriver) return false;                 // automatische Tests
    if (matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches) return false;
    return true;
  }

  const CSS = `
  #intro{position:fixed;inset:0;z-index:9999;background:#090b11;overflow:hidden;
    display:grid;place-items:center;font-family:inherit;transition:background .6s ease, opacity .5s ease}
  #intro .glow{position:absolute;left:50%;top:46%;width:110vmin;height:110vmin;margin:-55vmin 0 0 -55vmin;
    background:radial-gradient(circle, rgba(109,93,252,.32) 0%, rgba(61,139,255,.12) 32%, transparent 62%);
    opacity:0;transform:scale(.6);animation:in-glow 1.1s cubic-bezier(.2,.8,.2,1) .05s forwards, in-breathe 3.2s ease-in-out 1.2s infinite}
  #intro .stage{position:relative;display:flex;flex-direction:column;align-items:center;gap:3.2vh;transform:translateY(-2vh)}
  #intro .mark{position:relative;width:min(15vw,27vh);aspect-ratio:1;will-change:transform}
  #intro .mark svg{position:absolute;inset:0;width:100%;height:100%;overflow:visible}
  #intro .frame{stroke-dasharray:1;stroke-dashoffset:1;animation:in-draw .9s cubic-bezier(.65,0,.35,1) .15s forwards;
    filter:drop-shadow(0 0 .6px #8fc0ff)}
  #intro .stand{transform-origin:32px 44px;transform:scaleX(0);animation:in-stand .45s cubic-bezier(.34,1.56,.64,1) .85s forwards}
  #intro .screen{opacity:0;animation:in-screen .9s ease .95s forwards}
  #intro .play{transform-origin:52px 44px;transform:scale(0) rotate(-35deg);
    animation:in-pop .7s cubic-bezier(.34,1.7,.5,1) 1.05s forwards}
  #intro .ring{position:absolute;left:50%;top:44%;width:150%;aspect-ratio:1;margin:-75% 0 0 -75%;
    border-radius:50%;border:2px solid rgba(150,195,255,.8);opacity:0;transform:scale(.3);
    animation:in-ring 1s cubic-bezier(.1,.7,.3,1) .95s forwards}
  #intro .ring.r2{border-width:1px;animation-delay:1.12s;animation-duration:1.25s}
  #intro .spark{position:absolute;left:52%;top:44%;width:1vmin;height:1vmin;margin:-.5vmin;border-radius:50%;
    background:#cfe3ff;box-shadow:0 0 1.2vmin .2vmin rgba(120,180,255,.9);opacity:0;
    animation:in-spark var(--d) cubic-bezier(.15,.8,.3,1) var(--w) forwards}
  #intro .word{display:flex;font-weight:800;font-size:min(7.2vw,12.5vh);letter-spacing:.01em;line-height:1;position:relative;overflow:hidden;padding:.06em .1em .1em}
  #intro .word span{display:inline-block;color:#f3f4f7;opacity:0;transform:translateY(.7em) scale(.92);filter:blur(6px);
    animation:in-letter .7s cubic-bezier(.2,.9,.25,1) forwards}
  #intro .word span.tv{background:linear-gradient(120deg,#a78bfa,#3d8bff 55%,#22d3ee);-webkit-background-clip:text;background-clip:text;color:transparent}
  #intro .word span.gap{width:.07em}
  #intro .sweep{position:absolute;top:-30%;bottom:-30%;width:28%;left:-40%;transform:skewX(-18deg);
    background:linear-gradient(90deg,transparent,rgba(255,255,255,.55),transparent);mix-blend-mode:overlay;
    animation:in-sweep 1s cubic-bezier(.5,0,.3,1) 1.75s forwards}
  #intro .greet{color:#9aa3b5;font-size:min(2.2vw,3.8vh);letter-spacing:.04em;opacity:0;transform:translateY(1vh);
    animation:in-fade .8s ease 2.05s forwards}
  #intro .bar{position:absolute;left:50%;bottom:11vh;width:14vw;height:3px;margin-left:-7vw;border-radius:3px;
    background:rgba(255,255,255,.08);overflow:hidden;opacity:0;animation:in-fade .6s ease 2.2s forwards}
  #intro .bar i{position:absolute;inset:0;width:35%;border-radius:3px;background:linear-gradient(90deg,transparent,#3d8bff,transparent);
    animation:in-load 1.3s ease-in-out infinite}
  #intro.out-home{background:transparent;pointer-events:none}
  #intro.out-home .glow,#intro.out-home .greet,#intro.out-home .bar,#intro.out-home .ring,#intro.out-home .spark{transition:opacity .35s ease;opacity:0!important;animation:none}
  #intro.out-home .mark,#intro.out-home .word{transition:transform .75s cubic-bezier(.7,0,.2,1), opacity .25s ease .6s}
  #intro.out-tv .stage{transition:transform .7s cubic-bezier(.7,0,.6,1), opacity .5s ease .2s;transform:scale(7);opacity:0}
  #intro.out-tv .glow,#intro.out-tv .greet,#intro.out-tv .bar{transition:opacity .3s;opacity:0!important;animation:none}
  #intro.gone{opacity:0}
  body.intro-on .topbar .brand .logo, body.intro-on .topbar .brand .brand-name{opacity:0}
  body.intro-done .topbar .brand .logo, body.intro-done .topbar .brand .brand-name{transition:opacity .2s ease}
  @keyframes in-glow{to{opacity:1;transform:scale(1)}}
  @keyframes in-breathe{0%,100%{filter:brightness(1)}50%{filter:brightness(1.25)}}
  @keyframes in-draw{to{stroke-dashoffset:0}}
  @keyframes in-stand{to{transform:scaleX(1)}}
  @keyframes in-screen{0%{opacity:0}100%{opacity:1}}
  @keyframes in-pop{to{transform:scale(1) rotate(0)}}
  @keyframes in-ring{0%{opacity:.9;transform:scale(.3)}100%{opacity:0;transform:scale(2.4)}}
  @keyframes in-spark{0%{opacity:1;transform:translate(0,0) scale(1.3)}70%{opacity:.9}100%{opacity:0;transform:translate(var(--x),var(--y)) scale(.4)}}
  @keyframes in-letter{to{opacity:1;transform:none;filter:none}}
  @keyframes in-sweep{to{left:120%}}
  @keyframes in-fade{to{opacity:1;transform:none}}
  @keyframes in-load{0%{transform:translateX(-100%)}100%{transform:translateX(290%)}}
  `;

  function greeting() {
    const h = new Date().getHours();
    return h < 5 ? "Gute Nacht" : h < 11 ? "Guten Morgen" : h < 17 ? "Guten Tag" : h < 22 ? "Guten Abend" : "Gute Nacht";
  }

  function build() {
    const style = document.createElement("style");
    style.id = "intro-css";
    style.textContent = CSS;
    document.head.appendChild(style);

    let sparks = "";
    for (let i = 0; i < 26; i++) {
      const a = (i / 26) * Math.PI * 2 + (i % 2) * 0.12;
      const r = 16 + (i * 37 % 19);                       // 16–34 vmin, deterministisch gestreut
      sparks += `<i class="spark" style="--x:${(Math.cos(a) * r).toFixed(1)}vmin;--y:${(Math.sin(a) * r * 0.8).toFixed(1)}vmin;` +
                `--d:${(0.9 + (i % 5) * 0.12).toFixed(2)}s;--w:${(1.08 + (i % 4) * 0.03).toFixed(2)}s"></i>`;
    }
    const letters = [..."Raspi"].map((c, i) => `<span style="animation-delay:${(1.3 + i * 0.06).toFixed(2)}s">${c}</span>`).join("") +
      `<span class="gap"></span>` +
      [..."TV"].map((c, i) => `<span class="tv" style="animation-delay:${(1.66 + i * 0.07).toFixed(2)}s">${c}</span>`).join("");

    el = document.createElement("div");
    el.id = "intro";
    el.setAttribute("aria-hidden", "true");
    el.innerHTML = `
      <div class="glow"></div>
      <div class="stage">
        <div class="mark">
          <div class="ring"></div><div class="ring r2"></div>
          ${sparks}
          <svg viewBox="0 0 96 96">
            <defs>
              <linearGradient id="in-g" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stop-color="#8B5CF6"/><stop offset=".55" stop-color="#3D7BFF"/><stop offset="1" stop-color="#22D3EE"/>
              </linearGradient>
            </defs>
            <path class="screen" d="M48 4C80 4 92 16 92 48s-12 44-44 44S4 80 4 48 16 4 48 4z" fill="url(#in-g)"/>
            <path class="frame" d="M48 4C80 4 92 16 92 48s-12 44-44 44S4 80 4 48 16 4 48 4z" fill="none" stroke="url(#in-g)" stroke-width="4" pathLength="1" stroke-linecap="round"/>
            <path class="play" d="M39 31.5c0-3 3.2-4.8 5.8-3.3l20.4 12.6c2.5 1.5 2.5 5.1 0 6.6L44.8 60c-2.6 1.6-5.8-.3-5.8-3.3z" fill="#fff"/>
            <path class="screen" style="animation-delay:1.45s" d="M70.5 22.5a14 14 0 0 1 5 6.2M68 28.4a7 7 0 0 1 2.4 3" stroke="#fff" stroke-opacity=".85" stroke-width="3.6" stroke-linecap="round" fill="none"/>
          </svg>
        </div>
        <div class="word">${letters}<i class="sweep"></i></div>
        <div class="greet">${greeting()}</div>
      </div>
      <div class="bar"><i></i></div>`;
    document.body.appendChild(el);
    document.body.classList.add("intro-on");
  }

  function remove() {
    if (!el) return;
    el.remove();
    el = null;
    const s = document.getElementById("intro-css");
    document.body.classList.remove("intro-on");
    document.body.classList.add("intro-done");
    // Stylesheet erst entfernen, wenn die Topbar wieder eingeblendet ist
    setTimeout(() => { if (s) s.remove(); document.body.classList.remove("intro-done"); }, 400);
    window.removeEventListener("keydown", onKey, true);
  }

  // Logo und Schriftzug an ihren Platz in der Kopfzeile fliegen lassen
  function flyTo(src, target) {
    if (!src || !target) return;
    const a = src.getBoundingClientRect(), b = target.getBoundingClientRect();
    if (!a.width || !b.width) return;
    const k = b.height / a.height;
    const dx = (b.left + b.width / 2) - (a.left + a.width / 2);
    const dy = (b.top + b.height / 2) - (a.top + a.height / 2);
    src.style.transformOrigin = "50% 50%";
    src.style.transform = `translate(${dx}px, ${dy}px) scale(${k})`;
  }

  function wait(ms) { return new Promise(r => setTimeout(r, ms)); }

  async function finish(mode) {
    if (!el) return;
    if (closing) return closing;
    closing = (async () => {
      if (!skipRequested) {
        const left = MIN_MS - (performance.now() - t0);
        if (left > 0) await Promise.race([wait(left), skipWait()]);
      }
      if (!el) return;
      if (skipRequested) { el.classList.add("gone"); await wait(250); remove(); return; }
      if (mode === "tv") {
        el.classList.add("out-tv");
        await wait(650);
        remove();
        return;
      }
      el.classList.add("out-home");
      window.dispatchEvent(new Event("raspi-intro-reveal"));
      // Kopfzeile ist unter dem Overlay schon gerendert
      flyTo(el.querySelector(".mark"), document.querySelector(".topbar .logo"));
      flyTo(el.querySelector(".word"), document.querySelector(".topbar .brand-name"));
      await wait(800);
      remove();
    })();
    return closing;
  }

  let skipResolve = null;
  function skipWait() { return new Promise(r => { skipResolve = r; }); }

  function onKey(e) {
    // Jede Taste überspringt – die Taste selbst soll aber nichts auslösen
    e.preventDefault();
    e.stopImmediatePropagation();
    skip();
  }

  function skip() {
    skipRequested = true;
    if (skipResolve) skipResolve();
    if (!closing && el) { el.classList.add("gone"); setTimeout(remove, 250); }
  }

  const active = shouldPlay();
  if (active && document.body) {
    t0 = performance.now();
    build();
    window.addEventListener("keydown", onKey, true);
    setTimeout(() => finish("home"), MAX_MS);
  }

  return {
    get active() { return !!el; },
    finish,
    skip,
  };
})();
