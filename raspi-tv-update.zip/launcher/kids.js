/* Raspi-TV OS – Kindersicherung: PIN-Abfrage, Kinder-Modus, Sperrbildschirm, Einstellungen */
"use strict";

const Kids = {
  st: { has_pin: false, lock_settings: true, kids_mode: false, blocked: "" },
  KEY: "raspi-tv.unlock",

  async load() {
    try { this.st = await API.get("/api/parental"); } catch (_) {}
    this.apply();
    return this.st;
  },

  get on() { return !!this.st.kids_mode; },

  apply() {
    document.documentElement.toggleAttribute("data-kids", this.on);
  },

  unlockToken() {
    try {
      const u = JSON.parse(sessionStorage.getItem(this.KEY) || "null");
      if (u && u.until > Date.now()) return u.token;
    } catch (_) {}
    return "";
  },
  rememberUnlock(r) {
    try { sessionStorage.setItem(this.KEY, JSON.stringify({ token: r.unlock, until: Date.now() + (r.valid - 30) * 1000 })); } catch (_) {}
  },
  forget() { try { sessionStorage.removeItem(this.KEY); } catch (_) {} },

  // Braucht diese Seite den PIN?
  guarded(name) {
    if (!this.st.has_pin) return false;
    const settings = name === "settings" || name === "setup" || ROUTES[name] && /^Einstellungen/.test(
      typeof ROUTES[name].crumb === "string" ? ROUTES[name].crumb : "");
    if (this.on) return settings || name === "store" || name === "appsearch" || name === "pcscreen" || name === "media" || name === "mediabrowse";
    return settings && this.st.lock_settings;
  },

  // PIN abfragen (mit Fernbedienungs-Ziffern oder dem Ziffernfeld). Liefert das Entsperr-Zeichen oder null.
  ask(title = "PIN eingeben", text = "") {
    return new Promise(resolve => {
      let pin = "", done = false;
      const pad = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "⌫", "0", "✓"];
      const { el, close } = openModal({
        title, top: false,
        html: `${text ? `<p>${esc(text)}</p>` : ""}
          <div class="pin-dots" id="pin-dots"><i></i><i></i><i></i><i></i></div>
          <div class="pin-msg" id="pin-msg"></div>
          <div class="pin-pad">${pad.map(k => `<button class="btn nav pin-k" data-key="pin-${k}" data-k="${k}">${k}</button>`).join("")}</div>`,
        buttons: [{ label: "Abbrechen", action: c => { finish(null); c(); } }],
        focus: '[data-k="1"]',
      });
      const dots = () => el.querySelectorAll("#pin-dots i").forEach((d, i) => d.classList.toggle("on", i < pin.length));
      const finish = v => {
        if (done) return;
        done = true;
        document.removeEventListener("keydown", onKey, true);
        resolve(v);
      };
      async function submit() {
        if (pin.length !== 4) return;
        try {
          const r = await API.post("/api/parental/verify", { pin });
          Kids.rememberUnlock(r);
          finish(r.unlock);
          close();
        } catch (e) {
          el.querySelector("#pin-msg").textContent = e.message;
          el.querySelector(".pin-dots").classList.remove("shake"); void el.offsetWidth;
          el.querySelector(".pin-dots").classList.add("shake");
          pin = ""; dots();
        }
      }
      function press(k) {
        if (k === "⌫") pin = pin.slice(0, -1);
        else if (k === "✓") return submit();
        else if (/^\d$/.test(k) && pin.length < 4) pin += k;
        dots();
        if (pin.length === 4) submit();
      }
      el.querySelectorAll("[data-k]").forEach(b => b.addEventListener("click", () => press(b.dataset.k)));
      // Ziffern der Fernbedienung direkt annehmen
      function onKey(e) {
        if (!document.contains(el)) return finish(null);
        if (/^[0-9]$/.test(e.key)) { press(e.key); e.preventDefault(); e.stopImmediatePropagation(); }
        else if (e.key === "Backspace") { press("⌫"); e.preventDefault(); e.stopImmediatePropagation(); }
      }
      document.addEventListener("keydown", onKey, true);
      // Schließen über Zurück
      const obs = new MutationObserver(() => { if (!document.contains(el)) { obs.disconnect(); finish(null); } });
      obs.observe($("#modals"), { childList: true });
    });
  },

  // Neuen PIN zweimal eingeben lassen
  async choosePin() {
    const first = await this.enterRaw("Neuen PIN festlegen", "4 Ziffern – merk ihn dir gut.");
    if (!first) return null;
    const second = await this.enterRaw("PIN wiederholen", "Zur Sicherheit noch einmal.");
    if (!second) return null;
    if (first !== second) { toast("Die PINs stimmen nicht überein", "error"); return null; }
    return first;
  },

  // Ziffern sammeln ohne Prüfung (für einen neuen PIN)
  enterRaw(title, text) {
    return new Promise(resolve => {
      let pin = "", done = false;
      const pad = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "⌫", "0", "✓"];
      const { el, close } = openModal({
        title,
        html: `<p>${esc(text)}</p><div class="pin-dots" id="pin-dots"><i></i><i></i><i></i><i></i></div>
          <div class="pin-pad">${pad.map(k => `<button class="btn nav pin-k" data-key="pinr-${k}" data-k="${k}">${k}</button>`).join("")}</div>`,
        buttons: [{ label: "Abbrechen", action: c => { fin(null); c(); } }],
        focus: '[data-k="1"]',
      });
      const fin = v => { if (done) return; done = true; document.removeEventListener("keydown", onKey, true); resolve(v); };
      const dots = () => el.querySelectorAll("#pin-dots i").forEach((d, i) => d.classList.toggle("on", i < pin.length));
      function press(k) {
        if (k === "⌫") pin = pin.slice(0, -1);
        else if (/^\d$/.test(k) && pin.length < 4) pin += k;
        dots();
        if (pin.length === 4 || k === "✓") { if (pin.length === 4) { const v = pin; setTimeout(() => { fin(v); close(); }, 150); } }
      }
      el.querySelectorAll("[data-k]").forEach(b => b.addEventListener("click", () => press(b.dataset.k)));
      function onKey(e) {
        if (!document.contains(el)) return fin(null);
        if (/^[0-9]$/.test(e.key)) { press(e.key); e.preventDefault(); e.stopImmediatePropagation(); }
      }
      document.addEventListener("keydown", onKey, true);
      const obs = new MutationObserver(() => { if (!document.contains(el)) { obs.disconnect(); fin(null); } });
      obs.observe($("#modals"), { childList: true });
    });
  },

  async leaveKidsMode() {
    const tok = this.unlockToken() || await this.ask("Kinder-Modus beenden", "Bitte den PIN eingeben.");
    if (!tok) return false;
    try {
      this.st = await API.post("/api/parental/set", { unlock: tok, kids_mode: false });
      this.apply();
      toast("Kinder-Modus beendet", "ok");
      return true;
    } catch (e) { toast(e.message, "error"); return false; }
  },
};

// Apps im Kinder-Modus: nur Kinder-Angebote
const _allAppsBase = allApps;
allApps = function () {   // eslint-disable-line no-global-assign
  const list = _allAppsBase();
  if (!Kids.on) return list;
  return list.filter(a => a.id === "kika" || a.sc === "kids" || /Kinder|Kids/i.test(a.kind || "") || (STORE.find(s => s.id === a.id) || {}).sc === "kids");
};

// ======================================================================
// Sperrbildschirm (Tageslimit / Schlafenszeit)
// ======================================================================
function renderKidsLock(view, token) {
  const why = Kids.st.blocked;
  const bed = why === "bedtime";
  view.innerHTML = `
    <div class="kidslock">
      <div class="kl-art">${bed ? "🌙" : "⏰"}</div>
      <h1>${bed ? "Schlafenszeit" : "Fernsehzeit für heute vorbei"}</h1>
      <p>${bed ? "Für heute ist Schluss – schlaf gut!" : "Morgen geht es weiter. Wie wäre es jetzt mit Spielen, Malen oder Lesen?"}</p>
      <div class="kl-actions">
        <button class="btn nav" data-key="kl-more" id="kl-more">Mit PIN: 30 Minuten länger</button>
        <button class="btn nav" data-key="kl-off" id="kl-off">Mit PIN: Kinder-Modus beenden</button>
      </div>
    </div>`;
  if (!why) { setTimeout(() => go("#/"), 0); return; }
  $("#kl-more").addEventListener("click", async () => {
    const tok = await Kids.ask("30 Minuten länger", "Bitte den PIN eingeben.");
    if (!tok) return;
    try { Kids.st = await API.post("/api/parental/extend", { unlock: tok, minutes: 30 }); toast("30 Minuten mehr – viel Spaß!", "ok"); go("#/"); }
    catch (e) { toast(e.message, "error"); }
  });
  $("#kl-off").addEventListener("click", async () => { if (await Kids.leaveKidsMode()) go("#/"); });
  // TV ausschalten, damit niemand weiterschaut
  if (!renderKidsLock.offSent) {
    renderKidsLock.offSent = true;
    setTimeout(() => { if (route() === "kidslock") API.post("/api/tv/standby").catch(() => {}); }, 60000);
  }
}

// ======================================================================
// Einstellungen · Kindersicherung
// ======================================================================
function renderParental(view, token) {
  view.innerHTML = `
    <div class="page">
      <h1>Kindersicherung</h1>
      <p class="lead">Mit einem PIN schützt du die Einstellungen. Im <b>Kinder-Modus</b> sind nur Kindersender und Kinder-Apps zu sehen –
        auf Wunsch mit Tageslimit und Schlafenszeit. Beenden lässt er sich nur mit dem PIN.</p>
      <div class="list" id="par-list"><div class="row static"><span class="spinner"></span></div></div>
    </div>`;
  const LIMITS = [0, 30, 45, 60, 90, 120, 180];
  const BEDS = ["", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30"];

  async function save(patch) {
    try {
      Kids.st = await API.post("/api/parental/set", Object.assign({ unlock: Kids.unlockToken() }, patch));
      Kids.apply(); draw();
    } catch (e) {
      if (/PIN/.test(e.message)) {
        const tok = await Kids.ask();
        if (tok) return save(patch);
      } else toast(e.message, "error");
    }
  }

  function draw() {
    if (token !== renderToken) return;
    const s = Kids.st;
    const key = Nav.current && Nav.current.dataset.key;
    $("#par-list").innerHTML = `
      ${valueRow("par-pin", ICON.lock, s.has_pin ? "PIN ändern" : "PIN festlegen", s.has_pin ? "4 Ziffern · schützt Einstellungen und Kinder-Modus" : "Zuerst einen 4-stelligen PIN festlegen", s.has_pin ? "••••" : "")}
      ${s.has_pin ? toggleRow("par-lock", ICON.gear, "Einstellungen mit PIN schützen", "Ohne PIN lassen sich die Einstellungen nicht öffnen", s.lock_settings) : ""}
      ${s.has_pin ? valueRow("par-kids", ICON.tv, s.kids_mode ? "Kinder-Modus beenden" : "Kinder-Modus einschalten",
          `Nur ${s.kids_channels.length} Kindersender und Kinder-Apps · Beenden nur mit PIN`, s.kids_mode ? "An" : "Aus", s.kids_mode ? "" : "primary") : ""}
      ${s.has_pin ? valueRow("par-limit", ICON.update, "Tageslimit im Kinder-Modus", `Heute geschaut: ${s.used_today} Min.`, s.limit_min ? s.limit_min + " Min." : "Kein Limit") : ""}
      ${s.has_pin ? valueRow("par-bed", ICON.power, "Schlafenszeit", "Ab dieser Uhrzeit bis 6 Uhr ist Fernsehen im Kinder-Modus gesperrt", s.bedtime ? s.bedtime + " Uhr" : "Aus") : ""}
      ${s.has_pin ? valueRow("par-ch", ICON.list, "Kindersender", s.kids_channels.join(", ") || "keine", "Auswählen") : ""}
      ${s.has_pin ? valueRow("par-rm", ICON.restart, "PIN entfernen", "Schaltet die Kindersicherung ganz aus", "", "danger") : ""}`;
    $("#par-pin").addEventListener("click", async () => {
      if (s.has_pin && !Kids.unlockToken() && !await Kids.ask("Aktuellen PIN eingeben")) return;
      const pin = await Kids.choosePin();
      if (pin) {
        await save({ new_pin: pin });
        // gleich entsperrt bleiben – den PIN hat man ja gerade eingegeben
        try { Kids.rememberUnlock(await API.post("/api/parental/verify", { pin })); } catch (_) {}
        toast("PIN gespeichert", "ok");
      }
    });
    if (s.has_pin) {
      $("#par-lock").addEventListener("click", () => save({ lock_settings: !s.lock_settings }));
      $("#par-kids").addEventListener("click", async () => {
        if (s.kids_mode) { if (await Kids.leaveKidsMode()) draw(); return; }
        if (!await confirmDialog("Kinder-Modus einschalten?", "Danach sind nur Kindersender und Kinder-Apps zu sehen. Beenden geht nur mit dem PIN.", "Einschalten")) return;
        try { Kids.st = await API.post("/api/parental/kids"); Kids.apply(); Kids.forget(); go("#/"); toast("Kinder-Modus ist an", "ok"); }
        catch (e) { toast(e.message, "error"); }
      });
      $("#par-limit").addEventListener("click", () => save({ limit_min: LIMITS[(LIMITS.indexOf(s.limit_min) + 1) % LIMITS.length] }));
      $("#par-bed").addEventListener("click", () => save({ bedtime: BEDS[(BEDS.indexOf(s.bedtime || "") + 1) % BEDS.length] }));
      $("#par-ch").addEventListener("click", pickChannels);
      $("#par-rm").addEventListener("click", async () => {
        if (!await confirmDialog("PIN entfernen?", "Die Kindersicherung ist danach ganz aus.", "Entfernen", "danger")) return;
        await save({ new_pin: "" });
      });
    }
    const again = key && view.querySelector(`[data-key="${key}"]`);
    if (again) Nav.focus(again, false); else Nav.restore();
  }

  async function pickChannels() {
    let all = [];
    try { all = (await API.get("/api/channels/settings")).channels || []; } catch (_) {}
    if (!all.length) all = TV.channels.length ? TV.channels : await TV.loadChannels();
    const chosen = new Set(Kids.st.kids_channels);
    const { el, close } = openModal({
      title: "Kindersender",
      html: `<p>Diese Sender sind im Kinder-Modus zu sehen.</p><div class="list mlist">${all.map((c, i) => `
        <button class="row nav" data-key="kc-${i}" data-name="${esc(c.name)}"><span class="icon">${ICON.live}</span>
          <span class="main"><div class="label">${esc(c.name)}</div><div class="desc">${esc(c.group || "")}</div></span>
          <span class="switch ${chosen.has(c.name) ? "on" : ""}"></span></button>`).join("")}</div>`,
      buttons: [{ label: "Abbrechen" }, { label: "Speichern", style: "primary", action: async c => { c(); await save({ kids_channels: [...chosen] }); } }],
      focus: ".mlist .row",
    });
    el.querySelectorAll("[data-name]").forEach(b => b.addEventListener("click", () => {
      const n = b.dataset.name;
      if (chosen.has(n)) chosen.delete(n); else chosen.add(n);
      b.querySelector(".switch").classList.toggle("on", chosen.has(n));
    }));
  }

  Kids.load().then(draw);
  pageTimers.push(setInterval(() => Kids.load().then(() => { if (!document.querySelector("#modals .modal")) draw(); }), 30000));
}
