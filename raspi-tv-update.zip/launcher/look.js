/* Raspi-TV OS – Design & Aufbau: Designs, Akzentfarben, Hintergrund, Bewegung, Ecken,
 * Aufbau der Startseite und sichtbare Bereiche. Einstellungen · Design & Aufbau. */
"use strict";

const Look = (() => {
  const THEMES = [
    { id: "midnight", name: "Mitternacht", sub: "Dunkelblau – Standard", accent: "blue", c: ["#0b0d12", "#151922", "#1c2230", "#3d8bff"] },
    { id: "oled", name: "OLED Schwarz", sub: "Tiefschwarz, für OLED-Fernseher", accent: "blue", c: ["#000000", "#0e0e11", "#1a1a20", "#3d8bff"] },
    { id: "aurora", name: "Polarlicht", sub: "Türkis und Violett", accent: "teal", c: ["#060a13", "#0f1524", "#2b1060", "#22d3ee"] },
    { id: "sunset", name: "Abendrot", sub: "Warme Orangetöne", accent: "orange", c: ["#120a0e", "#1d1318", "#45161f", "#fb923c"] },
    { id: "forest", name: "Wald", sub: "Ruhiges Grün", accent: "green", c: ["#08100b", "#111b15", "#10331f", "#34d399"] },
    { id: "cinema", name: "Kino", sub: "Dunkelrot wie im Kinosaal", accent: "red", c: ["#0c0909", "#191313", "#3d1010", "#f87171"] },
    { id: "light", name: "Hell", sub: "Für helle Räume am Tag", accent: "blue", c: ["#eceff5", "#ffffff", "#dfe5f0", "#2563eb"] },
    { id: "auto", name: "Automatisch", sub: "Hell am Tag, abends dunkel", accent: "blue", c: ["#eceff5", "#ffffff", "#0b0d12", "#3d8bff"] },
  ];
  const ACCENTS = [
    { id: "theme", name: "Vom Design", c: "conic-gradient(#3d8bff, #22d3ee, #34d399, #fbbf24, #fb923c, #f87171, #f472b6, #a78bfa, #3d8bff)" },
    { id: "blue", name: "Blau", c: "#3d8bff" }, { id: "violet", name: "Violett", c: "#a78bfa" },
    { id: "teal", name: "Türkis", c: "#22d3ee" }, { id: "green", name: "Grün", c: "#34d399" },
    { id: "gold", name: "Gold", c: "#fbbf24" }, { id: "orange", name: "Orange", c: "#fb923c" },
    { id: "red", name: "Rot", c: "#f87171" }, { id: "pink", name: "Pink", c: "#f472b6" },
  ];
  const LAYOUTS = [
    { id: "classic", name: "Klassisch", sub: "Große Kacheln, darunter Reihen" },
    { id: "compact", name: "Kompakt", sub: "Mehr Sender auf einen Blick" },
    { id: "cinema", name: "Kino", sub: "Großes Bild der laufenden Sendung" },
    { id: "sidebar", name: "Seitenleiste", sub: "Menü links, Inhalte rechts" },
    { id: "minimal", name: "Minimal", sub: "Große Uhr, nur das Wichtigste" },
  ];
  const BG = [["glow", "Leuchtend"], ["animated", "Bewegt"], ["plain", "Schlicht"]];
  const MOTION = [["full", "Volle Animationen"], ["reduced", "Reduziert"], ["off", "Aus (am schnellsten)"]];
  const CORNERS = [["round", "Rund"], ["soft", "Sehr rund"], ["square", "Eckig"]];
  const SECTIONS = [
    ["continue", "Weiterschauen", "Zuletzt gesehene Sender und Videos"],
    ["now", "Jetzt im Fernsehen", "Was gerade auf den Sendern läuft"],
    ["apps", "Apps", "Deine Apps als Reihe"],
    ["news", "Nachrichten", "Aktuelle Schlagzeilen (tagesschau, ZDF, DW …)"],
    ["weather", "Wetter", "Temperatur oben rechts"],
    ["search", "Sendung suchen", "Suchfeld oben rechts"],
  ];
  const CACHE = "raspi-tv.look";

  function cfg(c) {
    c = c || {};
    return {
      theme: c.theme || "midnight", accent: c.accent || "theme", background: c.background || "glow",
      motion: c.motion || "full", corners: c.corners || "round", home_layout: c.home_layout || "classic",
      home_sections: Object.assign({ continue: true, now: true, apps: true, weather: true, search: true, news: true }, c.home_sections || {}),
    };
  }

  function effectiveTheme(id) {
    if (id !== "auto") return id;
    const h = new Date().getHours();
    return h >= 7 && h < 19 ? "light" : "midnight";
  }

  let current = cfg();
  function apply(c) {
    current = cfg(c);
    const root = document.documentElement;
    const theme = effectiveTheme(current.theme);
    const t = THEMES.find(x => x.id === theme) || THEMES[0];
    root.dataset.theme = theme;
    root.dataset.accent = current.accent === "theme" ? t.accent : current.accent;
    root.dataset.bg = current.background;
    root.dataset.motion = current.motion;
    root.dataset.corners = current.corners;
    try { localStorage.setItem(CACHE, JSON.stringify(current)); } catch (_) {}
  }

  // Sofort beim Laden anwenden (kein Aufblitzen des Standard-Designs)
  try { apply(JSON.parse(localStorage.getItem(CACHE) || "null")); } catch (_) { apply(); }
  // „Automatisch“: zwischendurch prüfen, ob Tag oder Abend ist
  setInterval(() => { if (current.theme === "auto") apply(current); }, 5 * 60000);

  // Startseite: Aufbau-Klasse und ausgeblendete Bereiche
  function homeClasses() {
    const c = current;
    const cls = ["layout-" + c.home_layout];
    for (const [k] of SECTIONS) if (!c.home_sections[k]) cls.push("hide-" + k);
    return cls;
  }

  return { THEMES, ACCENTS, LAYOUTS, BG, MOTION, CORNERS, SECTIONS, apply, cfg, homeClasses, get current() { return current; } };
})();

// ======================================================================
// Einstellungen · Design & Aufbau
// ======================================================================
function renderLook(view, token) {
  const c = () => Look.cfg(state.config);
  const check = '<span class="on"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span>';
  const label = (list, v) => (list.find(o => o[0] === v) || list[0])[1];

  function swatch(t) {
    const [bg, panel, p2, acc] = t.c;
    const split = t.id === "auto" ? `background:linear-gradient(90deg, ${bg} 50%, #0b0d12 50%)` : `background:${bg}`;
    return `<span class="sw" style="${split}"><i class="a" style="background:${acc}"></i>
      <span class="r"><i style="background:${panel}"></i><i style="background:${p2}"></i><i style="background:${panel}"></i></span></span>`;
  }

  function wire(id) {
    if (id === "compact") return `<span class="wf"><span class="r s"><i></i><i></i><i></i><i></i><i></i><i></i></span>
      <span class="r"><i></i><i></i><i></i><i></i></span><span class="r"><i></i><i></i><i></i><i></i></span><span class="r s"><i></i><i></i><i></i></span></span>`;
    if (id === "cinema") return `<span class="wf"><i class="big x"></i><span class="r s"><i></i><i></i><i></i><i></i><i></i></span>
      <span class="r"><i></i><i></i><i></i></span></span>`;
    if (id === "sidebar") return `<span class="wf side"><span class="col"><i class="x"></i><i></i><i></i><i></i><i></i><i></i></span>
      <span class="main"><i class="big x"></i><span class="r"><i></i><i></i><i></i></span></span></span>`;
    if (id === "minimal") return `<span class="wf"><i class="clk"></i><span class="r t"><i class="x"></i><i></i><i></i><i></i></span>
      <span class="r t"><i></i><i></i><i></i></span></span>`;
    return `<span class="wf"><span class="r t"><i class="x"></i><i></i><i></i><i></i><i></i></span>
      <span class="r"><i></i><i></i><i></i></span><span class="r"><i></i><i></i><i></i><i></i></span></span>`;
  }

  view.innerHTML = `
    <div class="page wide">
      <h1>Design &amp; Aufbau</h1>
      <p class="lead">Such dir aus, wie Raspi-TV aussieht. Änderungen wirken sofort.</p>
      <h2>Design</h2>
      <div class="look-strip" id="lk-themes">${Look.THEMES.map(t => `
        <button class="look-card nav" data-key="lk-t-${t.id}" data-theme="${t.id}">${check}${swatch(t)}
          <span class="name">${esc(t.name)}</span><span class="sub">${esc(t.sub)}</span></button>`).join("")}</div>
      <h2>Akzentfarbe</h2>
      <div class="look-strip" id="lk-accents">${Look.ACCENTS.map(a => `
        <button class="look-card dot-card nav" data-key="lk-a-${a.id}" data-accent="${a.id}">${check}
          <span class="dot" style="background:${a.c}"></span><span class="name">${esc(a.name)}</span></button>`).join("")}</div>
      <h2>Aufbau der Startseite</h2>
      <div class="look-strip" id="lk-layouts">${Look.LAYOUTS.map(l => `
        <button class="look-card nav" data-key="lk-l-${l.id}" data-layout="${l.id}">${check}${wire(l.id)}
          <span class="name">${esc(l.name)}</span><span class="sub">${esc(l.sub)}</span></button>`).join("")}</div>
      <h2>Feinheiten</h2>
      <div class="list" id="lk-more"></div>
      <h2>Auf der Startseite zeigen</h2>
      <div class="list" id="lk-sections"></div>
    </div>`;

  async function save(patch) {
    const prev = state.config;
    state.config = Object.assign({}, state.config, patch);
    Look.apply(state.config);          // sofort zeigen …
    mark();
    try { state.config = await API.post("/api/config", patch); Look.apply(state.config); }
    catch (e) { state.config = prev; Look.apply(prev); mark(); toast(e.message, "error"); }
  }

  function mark() {
    const k = c();
    view.querySelectorAll("[data-theme]").forEach(b => b.classList.toggle("selected", b.dataset.theme === k.theme));
    view.querySelectorAll("[data-accent]").forEach(b => b.classList.toggle("selected", b.dataset.accent === k.accent));
    view.querySelectorAll("[data-layout]").forEach(b => b.classList.toggle("selected", b.dataset.layout === k.home_layout));
    drawRows();
  }

  function cycle(list, v) { const i = list.findIndex(o => o[0] === v); return list[(i + 1) % list.length][0]; }

  function drawRows() {
    const k = c();
    const focusKey = Nav.current && Nav.current.dataset.key;
    $("#lk-more").innerHTML = `
      ${valueRow("lk-bg", ICON.picture, "Hintergrund", "Leuchtend · Bewegt · Schlicht", label(Look.BG, k.background))}
      ${valueRow("lk-motion", ICON.eye, "Animationen", "Auf älteren Pis läuft „Reduziert“ oder „Aus“ flüssiger", label(Look.MOTION, k.motion))}
      ${valueRow("lk-corners", ICON.apps, "Ecken", "Form der Kacheln und Knöpfe", label(Look.CORNERS, k.corners))}
      ${valueRow("lk-news", ICON.list, "Nachrichtenquelle", "Für die Schlagzeilen auf der Startseite und im Bildschirmschoner", esc(newsName))}
      ${valueRow("lk-reset", ICON.restart, "Auf Standard zurücksetzen", "Mitternacht · Klassisch · alles sichtbar", "")}`;
    $("#lk-sections").innerHTML = Look.SECTIONS.map(([id, name, desc]) =>
      toggleRow("lk-s-" + id, ICON.list, name, desc, k.home_sections[id])).join("");
    $("#lk-bg").addEventListener("click", () => save({ background: cycle(Look.BG, c().background) }));
    $("#lk-motion").addEventListener("click", () => save({ motion: cycle(Look.MOTION, c().motion) }));
    $("#lk-corners").addEventListener("click", () => save({ corners: cycle(Look.CORNERS, c().corners) }));
    $("#lk-news").addEventListener("click", async () => {
      const ids = NEWS_IDS.map(x => x.id);
      const cur = state.config.news_source || (state.config.lang === "en" ? "dw_en" : "tagesschau");
      const next = ids[(ids.indexOf(cur) + 1) % ids.length];
      try { const r = await API.post("/api/news", { source: next }); state.config.news_source = next; newsName = r.source; drawRows(); }
      catch (e) { toast(e.message, "error"); }
    });
    $("#lk-reset").addEventListener("click", () => save({ theme: "midnight", accent: "theme", background: "glow", motion: "full",
      corners: "round", home_layout: "classic", home_sections: { continue: true, now: true, apps: true, weather: true, search: true, news: true } }));
    Look.SECTIONS.forEach(([id]) => $("#lk-s-" + id).addEventListener("click", () => {
      const s = Object.assign({}, c().home_sections);
      s[id] = !s[id];
      save({ home_sections: s });
    }));
    const again = focusKey && view.querySelector(`[data-key="${focusKey}"]`);
    if (again && (!Nav.current || !document.contains(Nav.current))) Nav.focus(again, false);
  }

  const NEWS_IDS = [{ id: "tagesschau", name: "tagesschau" }, { id: "zdf", name: "ZDFheute" }, { id: "dw", name: "Deutsche Welle" },
                    { id: "spiegel", name: "DER SPIEGEL" }, { id: "dw_en", name: "DW News (English)" }];
  let newsName = (NEWS_IDS.find(x => x.id === (state.config.news_source || (state.config.lang === "en" ? "dw_en" : "tagesschau"))) || NEWS_IDS[0]).name;
  view.querySelectorAll("[data-theme]").forEach(b => b.addEventListener("click", () => save({ theme: b.dataset.theme })));
  view.querySelectorAll("[data-accent]").forEach(b => b.addEventListener("click", () => save({ accent: b.dataset.accent })));
  view.querySelectorAll("[data-layout]").forEach(b => b.addEventListener("click", () => {
    save({ home_layout: b.dataset.layout });
    toast("Startseite: " + Look.LAYOUTS.find(l => l.id === b.dataset.layout).name, "ok");
  }));
  mark();
}
