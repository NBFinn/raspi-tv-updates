/* Raspi-TV OS – Navigation zwischen den Seiten, Tasten und Start */
"use strict";

// ======================================================================
// Seiten
// ======================================================================
const ROUTES = {
  pcscreen: { render: (v,t) => { if (typeof renderPCScreen === "function") return renderPCScreen(v,t); throw new Error("PC-Modul fehlt. Bitte Update erneut installieren."); }, crumb: "PC-Bildschirm" },
  profiles:    { render: (v,t) => { if (typeof renderProfiles === "function") return renderProfiles(v,t); throw new Error("Profil-Modul fehlt. Bitte Notfall-Admin öffnen und Update erneut installieren."); }, crumb: "Einstellungen · Benutzerprofile" },
  appsearch:   { render: (v,t) => { if (typeof renderAppSearch === "function") return renderAppSearch(v,t); throw new Error("App-Suchmodul fehlt. Bitte Update erneut installieren."); }, crumb: "Apps suchen" },
  home:        { render: renderHome, crumb: "" },
  guide:       { render: renderGuide, crumb: "TV-Programm" },
  apps:        { render: renderAppGroup, crumb: p => p.cat === "streaming" ? "Filme & Serien" : "Mediathek" },
  media:       { render: renderMedia, crumb: "Eigene Medien" },
  mediabrowse: { render: renderMediaBrowse, crumb: "Eigene Medien" },
  settings:    { render: renderSettings, crumb: "Einstellungen" },
  "round-displays": { render: (v, t) => renderRoundDisplays(v, t), crumb: "Einstellungen · Runde Displays" },
  wifi:        { render: renderWifi, crumb: "Einstellungen · WLAN" },
  display:     { render: renderDisplay, crumb: "Einstellungen · Bild" },
  sound:       { render: (v, t) => { renderSound(v, t); addAirplayRow(v, t); addSpotifyRow(v, t); addDlnaRow(v, t); }, crumb: "Einstellungen · Ton" },
  channels:    { render: renderChannelSettings, crumb: "Einstellungen · Sender" },
  remote:      { render: (v, t) => { renderRemoteSettings(v, t); addAppLookLink(v); addCecSection(v, t); }, crumb: "Einstellungen · Fernbedienung" },
  bluetooth:   { render: renderBluetooth, crumb: "Einstellungen · Bluetooth" },
  apps_settings: { render: (v, t) => { renderApps(v, t); addAdblockRow(v, t); }, crumb: "Einstellungen · Apps" },
  updates:     { render: (v, t) => { renderUpdates(v, t); addOnlineUpdateSection(v, t); addRollbackSection(v, t); }, crumb: "Einstellungen · Updates" },
  system:      { render: (v, t) => { renderSystem(v, t); addDeviceNameRow(v, t); addLanguageRow(v, t); addBackupSection(v, t); addSysmonSection(v, t); addTerminalRow(v); }, crumb: "Einstellungen · System" },
  phone:       { render: (v, t) => { renderPhone(v, t); addHotspotSection(v, t); addBtAppSection(v, t); addAppLookSection(v); }, crumb: "Einstellungen · Fernbedienung · Handy" },
  applook:     { render: renderAppLook, crumb: "Einstellungen · Fernbedienung · Handy-App" },
  iphone:      { render: renderIphone, crumb: "Einstellungen · Fernbedienung · iPhone" },
  energy:      { render: (v, t) => { renderEnergy(v, t); addSaverStyleRows(v, t); addWakeSection(v, t); }, crumb: "Einstellungen · Energie" },
  notify:      { render: renderNotify, crumb: "Einstellungen · Mitteilungen" },
  look:        { render: renderLook, crumb: "Einstellungen · Design & Aufbau" },
  recordings:  { render: renderRecordings, crumb: "Aufnahmen" },
  parental:    { render: renderParental, crumb: "Einstellungen · Kindersicherung" },
  kidslock:    { render: renderKidsLock, crumb: "" },
  setup:       { render: renderSetup, crumb: "Einrichtung" },
  search:      { render: renderSearch, crumb: "Sendung suchen" },
  radio:       { render: renderRadio, crumb: "Radio" },
  weather:     { render: renderWeather, crumb: "Wetter" },
  store:       { render: renderStore, crumb: "App Store" },
};

function parseRoute() {
  const h = (location.hash || "#/").replace(/^#\/?/, "");
  const parts = h.split("/").filter(Boolean);
  if (["profiles", "appsearch", "pcscreen"].includes(parts[0])) return { name: parts[0], params: {} };
  if (!parts.length) return { name: "home", params: {} };
  if (parts[0] === "guide") return { name: "guide", params: {} };
  if (parts[0] === "setup") return { name: "setup", params: {} };
  if (parts[0] === "search") return { name: "search", params: { q: parts[1] ? decodeURIComponent(parts[1]) : "" } };
  if (parts[0] === "radio") return { name: "radio", params: {} };
  if (parts[0] === "recordings") return { name: "recordings", params: {} };
  if (parts[0] === "kidslock") return { name: "kidslock", params: {} };
  if (parts[0] === "weather") return { name: "weather", params: {} };
  if (parts[0] === "store") return { name: "store", params: { cat: parts[1] || "discover", q: parts[2] ? decodeURIComponent(parts[2]) : "" } };
  if (parts[0] === "apps") return { name: "apps", params: { cat: parts[1] || "mediathek" } };
  if (parts[0] === "media") {
    if (parts.length === 1) return { name: "media", params: {} };
    return { name: "mediabrowse", params: { src: decodeURIComponent(parts[1]), path: parts.slice(2).map(decodeURIComponent).join("/") } };
  }
  if (parts[0] === "settings") {
    if (parts.length === 1) return { name: "settings", params: {} };
    const sub = parts[1] === "apps" ? "apps_settings" : parts[1];
    if (ROUTES[sub]) return { name: sub, params: {} };
  }
  return { name: "home", params: {} };
}

function route() { return parseRoute().name; }

function go(path) { location.hash = path; }

function back() {
  if (closeTopModal()) return;
  if (route() !== "home") history.back();
}

let renderToken = 0;
let pageTimers = [];
function clearPageTimers() { pageTimers.forEach(clearInterval); pageTimers = []; }

function render() {
  closeAllModals();
  clearPageTimers();
  renderToken++;
  const { name, params } = parseRoute();
  const r = ROUTES[name];
  Guide.active = false;
  ChannelSort.moving = null;
  $("#crumb").textContent = typeof r.crumb === "function" ? r.crumb(params) : r.crumb;
  $("#view").scrollTop = 0;
  $("#view").className = "view-" + name + " entering";
  clearTimeout(render.enterTimer);
  render.enterTimer = setTimeout(() => $("#view").classList.remove("entering"), 900);
  Nav.current = null;
  // Kindersicherung: geschützte Seiten erst nach PIN
  if (Kids.guarded(name) && !Kids.unlockToken()) {
    renderPinGate($("#view"), renderToken);
    renderHints(name);
    Nav.restore();
    return;
  }
  r.render($("#view"), renderToken, params);
  renderHints(name);
  Nav.restore();
}

function renderPinGate(view, token) {
  view.innerHTML = `<div class="page"><div class="pin-gate">${ICON.lock}<h1>Geschützt</h1>
      <p>${Kids.on ? "Im Kinder-Modus ist dieser Bereich gesperrt." : "Die Einstellungen sind mit einem PIN geschützt."}</p>
      <button class="btn primary nav" data-key="gate" id="gate">PIN eingeben</button></div></div>`;
  const askNow = async () => {
    const tok = await Kids.ask(Kids.on ? "Kinder-Modus: PIN eingeben" : "PIN eingeben");
    if (token !== renderToken) return;
    if (tok) render(); else if (!document.querySelector("#modals .modal")) Nav.restore();
  };
  $("#gate").addEventListener("click", askNow);
  setTimeout(askNow, 50);
}

function renderHints(name) {
  const H = {
    home: `<span><b>OK</b>Öffnen</span><span><b>Home</b>Startseite aus jeder App</span><span><b>Guide</b>TV-Programm</span>
           <span><i class="dot" style="background:#3cb043"></i>Maus-Modus</span><span><i class="dot" style="background:#e3b830"></i>Schließen</span>`,
    guide: `<span><b>OK</b>Details · Erinnern</span><span><b>◀ ▶</b>Sendungen</span><span><b>▲ ▼</b>Sender</span><span><b>CH ±</b>Seite</span><span><b>Zurück</b>Zurück</span>`,
    mediabrowse: `<span><b>OK</b>Öffnen</span><span><b>Zurück</b>Ordner zurück</span>`,
  };
  $("#hints").innerHTML = H[name] || `<span><b>OK</b>Auswählen</span><span><b>Zurück</b>Eine Ebene zurück</span><span><b>Home</b>Startseite</span>`;
}

// ======================================================================
// Tasten
// ======================================================================
document.addEventListener("keydown", e => {
  if (e.defaultPrevented) return;
  const typing = e.target.matches && e.target.matches("input, textarea");
  const cur = Nav.current;

  if (!typing && Guide.active && Guide.key(e)) return;
  if (!typing && ChannelSort.moving && ChannelSort.key(e)) return;

  if (cur && cur._adjust && (e.key === "ArrowLeft" || e.key === "ArrowRight")) {
    cur._adjust(e.key === "ArrowRight" ? 5 : -5);
    e.preventDefault();
    return;
  }

  switch (e.key) {
    case "ArrowLeft": Nav.move(-1, 0); break;
    case "ArrowRight": Nav.move(1, 0); break;
    case "ArrowUp": Nav.move(0, -1); break;
    case "ArrowDown": Nav.move(0, 1); break;
    case "Enter": case " ":
      if (typing) return;
      if (cur) activate(cur);
      break;
    case "Escape": back(); break;
    case "Backspace":
      if (typing) return;
      back();
      break;
    case "BrowserBack":
      if (closeTopModal()) break;
      return; // Browser geht selbst zurück
    case "g": case "G":
      if (typing) return;
      go("#/guide");
      break;
    default:
      if (!typing && route() === "home" && /^[0-9]$/.test(e.key) && !document.querySelector("#modals .modal")) {
        // Zifferntaste auf der Startseite: Sender direkt einschalten
        const n = parseInt(e.key, 10);
        if (n > 0) openChannel(n - 1);
        break;
      }
      return;
  }
  e.preventDefault();
});

function activate(el) {
  if (el.dataset.go) return go(el.dataset.go);
  el.click();
}

document.addEventListener("click", e => {
  const el = e.target.closest("[data-go]");
  if (el) { e.preventDefault(); go(el.dataset.go); }
});

document.addEventListener("mouseover", e => {
  const el = e.target.closest(".nav");
  if (el && Nav.items().includes(el) && el !== Nav.current) Nav.focus(el, false);
});

window.addEventListener("hashchange", render);

// Nach der Startanimation die Startseite noch einmal sichtbar „hereinfahren“ lassen
window.addEventListener("raspi-intro-reveal", () => {
  const v = $("#view");
  v.classList.remove("entering");
  void v.offsetWidth;
  v.classList.add("entering");
  clearTimeout(render.enterTimer);
  render.enterTimer = setTimeout(() => v.classList.remove("entering"), 900);
});

// ======================================================================
// Start
// ======================================================================
(async function init() {
  tick();
  setInterval(tick, 10000);
  try { state.config = await API.get("/api/config"); } catch (_) {}
  if (typeof Personal !== "undefined") Personal.sync();
  if (state.config.intro === false) Intro.skip();
  Look.apply(state.config);
  I18N.set(state.config.lang);
  await Kids.load();
  applyScale(state.config.ui_scale);
  Saver.init();
  await Store.refresh().catch(() => {});
  NativeRun.check();
  SpotifyNow.start();
  await refreshStatus();

  // Allererster Start: Einrichtungsassistent
  if (!state.config.setup_done && !location.hash.includes("settings")) {
    try { sessionStorage.setItem("raspi-tv.started", "1"); } catch (_) {}
    if (route() !== "setup") { location.replace("#/setup"); }
    render();
    Intro.finish("home");
    setInterval(refreshStatus, 5000);
    return;
  }

  // Wie ein Fernseher: nach dem Einschalten direkt Live-TV (wenn gewünscht und online)
  let firstStart = false;
  try { firstStart = !sessionStorage.getItem("raspi-tv.started"); sessionStorage.setItem("raspi-tv.started", "1"); } catch (_) {}
  if (firstStart && (state.config.startup || "tv") === "tv" && !location.hash.replace(/^#\/?/, "")) {
    await refreshStatus();
    if (state.network && state.network.online) {
      await Intro.finish("tv");
      location.replace("/tv.html");
      return;
    }
  }

  render();
  Intro.finish("home");
  refreshStatus();
  setInterval(refreshStatus, 5000);
})();
