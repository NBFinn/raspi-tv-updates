/* Live sound visualization: no fake/random levels and no microphone capture. */
"use strict";
const LiveSpectrum = {
  timer:null, previous:[],
  start(el) {
    clearTimeout(this.timer);
    this.previous=[];
    const tick=async()=>{
      if(Saver.el!==el)return;
      if(el.dataset.scene==='spectrum'){
        try{
          const data=await API.get('/api/audio-meter');
          if(Saver.el!==el)return;
          const canvas=el.querySelector('.spectrum-canvas');
          if(canvas){
            const ctx=canvas.getContext('2d');
            if(canvas.width!==innerWidth||canvas.height!==innerHeight){canvas.width=innerWidth;canvas.height=innerHeight;}
            ctx.clearRect(0,0,canvas.width,canvas.height);
            const bands=data.available&&data.fresh?data.bands:Array(10).fill(0);
            const gradient=ctx.createLinearGradient(0,innerHeight*.3,0,innerHeight*.75);
            gradient.addColorStop(0,'#80f0d2');gradient.addColorStop(1,'#4960dc');ctx.fillStyle=gradient;
            const width=innerWidth*.76/bands.length;
            bands.forEach((level,i)=>{const value=(this.previous[i]||0)*.55+level*.45;this.previous[i]=value;
              const height=Math.max(3,value*innerHeight*.35);ctx.fillRect(innerWidth*.12+i*width,innerHeight*.68-height,width*.68,height);});
            el.querySelector('.spectrum-status').textContent=data.error||(!data.available?'Verbinde mit Audio-Ausgang …':data.level>.005?'Reagiert auf den TV-Ton':'Warte auf Tonsignal');
          }
        }catch(e){const status=el.querySelector('.spectrum-status');if(status)status.textContent='Audio-Analyse nicht erreichbar.';}
      }
      if(Saver.el===el)this.timer=setTimeout(tick,100);
    };
    tick();
  },
  stop(){clearTimeout(this.timer);this.timer=null;}
};
const _ambientShow=Saver.showAmbient,_ambientHide=Saver.hide;
Saver.showAmbient=function(style){const result=_ambientShow.call(this,style);if(this.el)LiveSpectrum.start(this.el);return result;};
Saver.hide=function(){LiveSpectrum.stop();return _ambientHide.call(this);};

async function renderPCScreen(view,token){
  view.innerHTML='<div class="page wide"><h1>Windows-Bildschirm auf dem Fernseher</h1><p class="lead">Verbindung wird vorbereitet …</p></div>';
  try{
    const remote=await API.get('/api/remote');if(token!==renderToken)return;
    const address=remote.address?new URL(remote.address).hostname:'Keine Netzwerkadresse';
    view.innerHTML=`<div class="page wide"><h1>Dein PC auf dem großen Bildschirm</h1><p class="lead">PC und Raspi-TV mit demselben Netzwerk verbinden.</p>
      <div class="profile-grid"><article class="profile-card"><h2>1 · Am PC starten</h2><p>Im Windows-Paket „PC-Bildschirm“ die Datei <b>Starten.bat</b> öffnen. Im Browser Microsoft Edge oder Chrome verwenden.</p></article>
      <article class="profile-card"><h2>2 · Verbinden</h2><p>Pi-Adresse: <b>${esc(address)}</b></p><p>Handy-/PC-Kopplungscode: <b style="font-size:2.5vw;letter-spacing:.2em">${esc(remote.pin||'–')}</b></p></article>
      <article class="profile-card"><h2>3 · Bildschirm wählen</h2><p>Am PC „Bildschirm teilen“ anklicken und den gewünschten Bildschirm oder ein Fenster auswählen. Ton kann im Freigabedialog mit ausgewählt werden, sofern angeboten.</p></article></div>
      <p class="lead">Die Übertragung endet über „Beenden“ am PC oder Home am Fernseher. Die Auswahl auf dieser Seite ist eine Spiegelung des freigegebenen Bildes.</p>
      <button class="btn nav" data-key="pc-refresh" id="pc-refresh">Neuen Code anzeigen / aktualisieren</button></div>`;
    view.querySelector('#pc-refresh').onclick=()=>renderPCScreen(view,token);
    Nav.restore();
  }catch(e){if(token===renderToken)view.innerHTML=`<div class="page"><h1>PC-Bildschirm</h1><p>${esc(e.message)}</p></div>`;}
}
