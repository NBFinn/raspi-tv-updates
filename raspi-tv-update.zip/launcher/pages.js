/* Raspi-TV OS – Startseite, Programmführer, Eigene Medien und neue Einstellungen */
"use strict";

// ======================================================================
// Gemeinsame Daten: Sender & Programmführer
// ======================================================================
const TV = {
  channels: [],
  now: {},
  reminders: [],
  async loadChannels() {
    try { this.channels = await API.get("/api/channels"); } catch (_) {}
    return this.channels;
  },
  async loadNow() {
    try { this.now = await API.get("/api/epg/now"); } catch (_) {}
    return this.now;
  },
  async loadReminders() {
    try { this.reminders = (await API.get("/api/reminders")).reminders; } catch (_) {}
    return this.reminders;
  },
  recs: [],          // geplante/laufende Aufnahmen
  async loadRecs() {
    try { this.recs = (await API.get("/api/rec")).schedule; } catch (_) {}
    return this.recs;
  },
  lastChannel() {
    try { return Math.max(0, JSON.parse(localStorage.getItem("tv.channel") || "0")); } catch (_) { return 0; }
  },
};

function hhmm(ts) {
  const d = new Date(ts * 1000);
  return String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
}
function progress(p) {
  if (!p) return 0;
  const now = Date.now() / 1000;
  return Math.max(0, Math.min(100, (now - p.start) / (p.stop - p.start) * 100));
}
function dayLabel(ts) {
  const d = new Date(ts * 1000), t = new Date();
  const diff = Math.round((new Date(d.toDateString()) - new Date(t.toDateString())) / 86400000);
  return diff === 0 ? "Heute" : diff === 1 ? "Morgen" : diff === -1 ? "Gestern"
    : d.toLocaleDateString("de-DE", { weekday: "long", day: "numeric", month: "numeric" });
}
function openChannel(index) {
  showOverlay("Live-TV wird gestartet …");
  location.href = "/tv.html?ch=" + (index + 1);
}

// Senderlogo (helles Kärtchen, damit auch dunkle Logos lesbar sind)
const chLogo = (c, cls = "ch-logo") => c && c.logo ? `<span class="${cls}"><img src="${esc(c.logo)}" alt="" loading="lazy" onerror="this.parentNode.remove()"></span>` : "";

// ======================================================================
// Startseite
// ======================================================================
function renderHome(view, token) {
  const h = new Date().getHours();
  const greet = h < 5 ? "Gute Nacht" : h < 11 ? "Guten Morgen" : h < 17 ? "Guten Tag" : h < 22 ? "Guten Abend" : "Gute Nacht";
  const apps = allApps();
  const main = [
    { key: "live", icon: ICON.live, title: "Live-TV", sub: "Fernsehen", go: null, cls: "accent" },
    { key: "guide", icon: ICON.guide, title: "TV&#8209;Programm", sub: "Was läuft wann", go: "#/guide" },
    { key: "mediathek", icon: ICON.mediathek, title: "Mediathek", sub: "ARD, ZDF, ARTE & mehr", go: "#/apps/mediathek" },
    { key: "streaming", icon: ICON.film, title: "Filme & Serien", sub: "Netflix, Prime & mehr", go: "#/apps/streaming" },
    { key: "media", icon: ICON.folder, title: "Eigene Medien", sub: "USB & Heimnetz", go: "#/media" },
    { key: "radio", icon: ICON.music, title: "Radio", sub: "Über 20 Sender live", go: "#/radio" },
    { key: "settings", icon: ICON.gear, title: "Einstellungen", sub: "WLAN, Bild, Ton …", go: "#/settings" },
  ];
  Look.homeClasses().forEach(c => view.classList.add(c));
  view.innerHTML = `
    <div class="home-wrap">
      <div class="home-side">
        <div class="hero">
          ${main.map(m => `
            <button class="hero-tile nav ${m.cls || ""}" data-key="${m.key}" ${m.go ? `data-go="${m.go}"` : ""} id="hero-${m.key}">
              <span class="hero-icon">${m.icon}</span>
              <span class="hero-title">${m.title}</span>
              <span class="hero-sub" id="hero-sub-${m.key}">${esc(m.sub)}</span>
              ${m.key === "live" ? '<span class="hero-bar"><i id="hero-live-bar"></i></span>' : ""}
            </button>`).join("")}
        </div>
      </div>
      <div class="home-main">
        <div class="home-top">
          <div class="greeting">${greet}</div>
          <div class="home-actions">
            <button class="search-pill nav" data-key="home-pc" data-go="#/pcscreen">${ICON.picture}<span>PC-Bildschirm</span></button>
            <button class="search-pill nav" data-key="home-ambient" id="home-ambient">${ICON.music}<span>Musikansicht</span></button>
            <button class="search-pill nav" data-key="home-profile" data-go="#/profiles">${esc(typeof Personal === "undefined" ? "Profile" : Personal.name())}</button>
            <button class="search-pill nav" data-key="home-appsearch" data-go="#/appsearch">${ICON.apps}<span>Apps suchen</span></button>
            <button class="weather-chip nav" data-key="home-weather" data-go="#/weather" id="wchip" hidden></button>
            <button class="search-pill nav" data-key="home-search" data-go="#/search">${ICON.search}<span>Sendung suchen</span></button>
          </div>
        </div>
        <button class="banner nav" id="banner" data-key="banner" hidden>
          ${ICON.warn}
          <span><b>Keine Internetverbindung.</b> Verbinde den Raspi-TV mit deinem WLAN oder stecke ein LAN-Kabel ein.</span>
          <span class="cta">WLAN einrichten</span>
        </button>
        <div class="big-clock" id="big-clock"><div class="t" id="bc-time"></div><div class="d" id="bc-date"></div><div class="n" id="bc-now"></div></div>
        <button class="feature nav" data-key="feature" id="feature">
          <span class="feature-logo" id="ft-logo" hidden></span>
          <span class="feature-kicker"><em>Live</em><span id="ft-ch">Live-TV</span></span>
          <span class="feature-title" id="ft-title">Fernsehen</span>
          <span class="feature-meta" id="ft-meta"></span>
          <span class="feature-bar"><i id="ft-bar"></i></span>
          <span class="feature-cta">▶ Weiterschauen</span>
        </button>
        <div class="home-rest">
          <div class="section" id="sec-cont" hidden>Weiterschauen</div>
          <div class="strip" id="cont-strip" hidden></div>
          <div class="section" id="sec-fav" hidden>Meine Lieblingssender</div>
          <div class="strip" id="fav-strip" hidden></div>
          <div class="section" id="sec-now">Jetzt im Fernsehen</div>
          <div class="strip" id="now-strip"><div class="empty">Sender werden geladen …</div></div>
          <div class="section" id="sec-news" hidden>Nachrichten</div>
          <div class="strip" id="news-strip" hidden></div>
          <div class="section" id="sec-apps">Apps</div>
          <div class="strip" id="apps-strip">
            <button class="app-chip store-chip nav" data-key="app-store" data-go="#/store">${ICON.store}
              <span class="name">App Store</span><span class="kind">Neue Apps holen</span></button>
            ${apps.map(a => `
              <button class="app-chip nav" data-key="app-${a.id}" data-app="${a.id}" style="--c1:${a.c1};--c2:${a.c2}">
                <span class="name">${esc(a.name)}</span><span class="kind">${esc(a.kind)}</span>
              </button>`).join("")}
          </div>
        </div>
      </div>
    </div>`;
  $("#home-ambient", view).addEventListener("click", () => {
    // 6.0: Musikansicht mit bewegten Ambient-Szenen (ältere Animation als Ersatz)
    if (typeof VideoSaver === "undefined") return Saver.showAmbient();
    VideoSaver.show().then(ok => { if (ok === false) Saver.showAmbient(); });
  });
  // Große Uhr (Aufbau „Minimal")
  const clock = () => {
    const d = new Date();
    const tEl = $("#bc-time"); if (!tEl) return;
    tEl.textContent = String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
    $("#bc-date").textContent = d.toLocaleDateString(I18N.lang === "en" ? "en-GB" : "de-DE", { weekday: "long", day: "numeric", month: "long" });
  };
  clock();
  pageTimers.push(setInterval(clock, 10000));
  $("#feature").addEventListener("click", () => openChannel(TV.lastChannel()));
  if (!Kids.on) loadNewsStrip($("#news-strip"), token);
  view.querySelectorAll("[data-app]").forEach(el => el.addEventListener("click", () => openApp(el.dataset.app)));
  $("#hero-live").addEventListener("click", () => openChannel(TV.lastChannel()));
  loadWeatherChip($("#wchip"), token);
  $("#banner").addEventListener("click", () => go("#/settings/wifi"));
  updateBanner();

  Promise.all([TV.loadChannels(), TV.loadNow()]).then(() => {
    if (token !== renderToken) return;
    drawNow();
    pageTimers.push(setInterval(async () => { await TV.loadNow(); if (token === renderToken) drawNow(); }, 60000));
  });

  function drawNow() {
    const chans = TV.channels;
    const last = Math.min(TV.lastChannel(), Math.max(chans.length - 1, 0));
    const lc = chans[last];
    if (lc) {
      const e = TV.now[lc.name] || {};
      const p = e.now;
      $("#hero-sub-live").textContent = p ? `${lc.name}: ${p.title}` : `Weiter mit ${lc.name}`;
      $("#hero-live-bar").style.width = progress(p) + "%";
      // Titelbild (Aufbau „Kino“ / „Seitenleiste“) und Zeile unter der großen Uhr
      $("#ft-ch").textContent = (last + 1) + " · " + lc.name;
      $("#ft-title").textContent = p ? p.title : lc.name;
      $("#ft-meta").textContent = p ? hhmm(p.start) + " – " + hhmm(p.stop) + (e.next ? "  ·  Danach: " + e.next.title : "") : (lc.group || "Live");
      $("#ft-bar").style.width = progress(p) + "%";
      const lg = $("#ft-logo");
      if (lc.logo) { lg.hidden = false; lg.innerHTML = `<img src="${esc(lc.logo)}" alt="" onerror="this.parentNode.hidden=true">`; }
      $("#bc-now").innerHTML = p ? `Jetzt auf <b>${esc(lc.name)}</b>: ${esc(p.title)}` : `<b>${esc(lc.name)}</b> live`;
    }
    renderContinue($("#cont-strip"));
    const card = (c, i, key) => {
      const e = TV.now[c.name] || {};
      const p = e.now;
      return `<button class="now-card nav" data-key="${key}-${i}" data-ch="${i}">
        <span class="now-head"><b>${i + 1}</b>${chLogo(c)}${esc(c.name)}</span>
        <span class="now-title">${p ? esc(p.title) : "Live"}</span>
        <span class="now-time">${p ? hhmm(p.start) + " – " + hhmm(p.stop) : esc(c.group || "")}</span>
        <span class="bar"><i style="width:${progress(p)}%"></i></span>
      </button>`;
    };
    // Lieblingssender (im Fernsehen mit ▶ Optionen → Lieblingssender markiert)
    let favs = [];
    try { favs = JSON.parse(localStorage.getItem("tv.favs") || "[]"); } catch (_) {}
    const favIdx = chans.map((c, i) => i).filter(i => favs.includes(chans[i].name));
    $("#sec-fav").hidden = $("#fav-strip").hidden = !favIdx.length;
    $("#fav-strip").innerHTML = favIdx.map(i => card(chans[i], i, "fav")).join("");
    const list = chans.slice(0, 12);
    $("#now-strip").innerHTML = list.length ? list.map((c, i) => card(c, i, "now")).join("") : '<div class="empty">Keine Sender verfügbar.</div>';
    view.querySelectorAll("#now-strip [data-ch], #fav-strip [data-ch]").forEach(el => el.addEventListener("click", () => openChannel(+el.dataset.ch)));
    Nav.refocus();
  }
}

function updateBanner() {
  const b = $("#banner");
  if (!b) return;
  const offline = state.network && !state.network.online;
  const wasHidden = b.hidden;
  b.hidden = !offline;
  if (offline && wasHidden) Nav.focus(b, false);
  if (!offline && Nav.current === b) Nav.restore();
}

// ======================================================================
// Mediathek / Filme & Serien
// ======================================================================
function renderAppGroup(view, token, params) {
  const cat = params.cat === "streaming" ? "streaming" : "mediathek";
  const apps = allApps().filter(a => a.cat === cat);
  const info = cat === "streaming"
    ? "Diese Dienste brauchen ein eigenes Abo. Sie laufen über ihre offizielle Web-Version – die Bildqualität ist dort meist auf 720p begrenzt."
    : "Kostenlose Mediatheken und Videoangebote. Live-Sender findest du unter „Live-TV“.";
  view.innerHTML = `
    <div class="page wide">
      <h1>${cat === "streaming" ? "Filme &amp; Serien" : "Mediathek"}</h1>
      <p class="lead">${info}</p>
      <div class="app-grid">
        ${apps.map(a => `
          <button class="tile nav" data-key="app-${a.id}" data-app="${a.id}" style="--c1:${a.c1};--c2:${a.c2}">
            <span class="name">${esc(a.name)}</span><span class="kind">${esc(a.kind)}</span>
          </button>`).join("")}
        <button class="tile store-tile nav" data-key="app-store" data-go="#/store/${cat}">${ICON.store}
          <span class="name">Mehr Apps</span><span class="kind">Im App Store stöbern</span></button>
      </div>
    </div>`;
  view.querySelectorAll("[data-app]").forEach(el => el.addEventListener("click", () => openApp(el.dataset.app)));
}

// ======================================================================
// Programmübersicht (EPG)
// ======================================================================
const Guide = {
  SPAN: 3 * 3600,          // sichtbarer Zeitraum
  start: 0,                // linker Rand (Unix-Zeit)
  data: {},
  row: 0,
  focusTime: 0,
  cell: null,
  token: 0,
  active: false,

  async open(view, token) {
    this.token = token;
    this.active = true;
    const now = Date.now() / 1000;
    this.start = Math.floor(now / 1800) * 1800;
    this.focusTime = now;
    this.row = Math.min(TV.lastChannel(), 9999);
    view.innerHTML = `
      <div class="guide">
        <div class="guide-head">
          <button class="guide-search nav" data-key="g-search" id="g-search" data-go="#/search">${ICON.search}<span>Suchen</span></button>
          <div class="guide-day" id="g-day"></div>
          <div class="guide-times" id="g-times"></div>
        </div>
        <div class="guide-body" id="g-body"><div class="empty">Programm wird geladen …</div></div>
        <div class="guide-detail" id="g-detail"></div>
      </div>`;
    await Promise.all([TV.loadChannels(), TV.loadReminders(), TV.loadRecs()]);
    await this.load();
  },

  async load() {
    const from = this.start - 1800, to = this.start + this.SPAN + 3600;
    try {
      const r = await API.get(`/api/epg?from=${from}&to=${to}`);
      this.data = r.programs || {};
    } catch (_) {
      this.data = {};
    }
    if (this.token !== renderToken) return;
    if (!Object.keys(this.data).length) return this.empty();
    this.draw();
  },

  async empty() {
    let st = {};
    try { st = await API.get("/api/epg/status"); } catch (_) {}
    if (this.token !== renderToken) return;
    $("#g-body").innerHTML = `
      <div class="page"><div class="list">
        <div class="row static"><span class="icon">${ICON.guide}</span><span class="main">
          <div class="label">${st.running ? "Programmdaten werden geladen …" : "Noch keine Programmdaten"}</div>
          <div class="desc">${st.error ? "Letzter Versuch fehlgeschlagen: " + esc(st.error) : "Die Daten kommen aus dem Internet und werden alle 6 Stunden aktualisiert."}</div>
        </span>${st.running ? '<span class="spinner"></span>' : ""}</div>
        <button class="row nav primary" data-key="g-refresh" id="g-refresh"><span class="icon">${ICON.update}</span>
          <span class="main"><div class="label">Jetzt laden</div></span></button>
      </div></div>`;
    $("#g-refresh").addEventListener("click", async () => {
      await API.post("/api/epg/refresh").catch(() => {});
      toast("Programmdaten werden geladen …");
      setTimeout(() => { if (this.token === renderToken) this.load(); }, 8000);
    });
    Nav.restore();
  },

  px(ts) { return (ts - this.start) / this.SPAN * 100; },

  draw() {
    const chans = TV.channels;
    this.row = Math.min(this.row, chans.length - 1);
    $("#g-day").textContent = dayLabel(this.start);
    let times = "";
    for (let t = this.start; t < this.start + this.SPAN; t += 1800) {
      times += `<span style="left:${this.px(t)}%">${hhmm(t)}</span>`;
    }
    const nowX = this.px(Date.now() / 1000);
    $("#g-times").innerHTML = times + (nowX >= 0 && nowX <= 100 ? `<i class="g-now" style="left:${nowX}%"></i>` : "");
    const remind = new Set(TV.reminders.map(r => r.id));
    const recs = TV.recs.filter(r => r.status !== "failed");
    const isRec = (ch, p) => recs.some(r => r.channel === ch && r.start < p.stop && r.stop > p.start);
    const end = this.start + this.SPAN;
    $("#g-body").innerHTML = chans.map((c, ri) => {
      const progs = (this.data[c.name] || []).filter(p => p.stop > this.start && p.start < end);
      const cells = progs.length ? progs.map((p, pi) => {
        const l = Math.max(0, this.px(p.start)), r = Math.min(100, this.px(p.stop));
        const live = p.start <= Date.now() / 1000 && Date.now() / 1000 < p.stop;
        const rem = remind.has(c.name + "|" + p.start);
        const rec = isRec(c.name, p);
        return `<div class="g-cell${live ? " live" : ""}" data-r="${ri}" data-p="${pi}" style="left:${l}%;width:calc(${r - l}% - .25vw)">
          <b>${rec ? '<i class="rec-dot"></i>' : ""}${esc(p.title)}</b><span>${hhmm(p.start)}${rem ? " · " + ICON.bell : ""}</span></div>`;
      }).join("") : `<div class="g-cell none" data-r="${ri}" data-p="-1" style="left:0;width:calc(100% - .25vw)"><span>Keine Programminformationen</span></div>`;
      return `<div class="g-row" data-r="${ri}">
        <div class="g-ch"><b>${ri + 1}</b>${chLogo(c)}<span class="g-chname">${esc(c.name)}</span></div>
        <div class="g-line">${cells}${nowX >= 0 && nowX <= 100 ? `<i class="g-now" style="left:${nowX}%"></i>` : ""}</div>
      </div>`;
    }).join("");
    $("#g-body").querySelectorAll(".g-cell").forEach(el => el.addEventListener("click", () => {
      this.row = +el.dataset.r;
      this.select(el);
      this.details();
    }));
    this.focusRow(this.row, this.focusTime);
  },

  rowCells(ri) {
    return [...document.querySelectorAll(`.g-cell[data-r="${ri}"]`)];
  },

  progOf(el) {
    const c = TV.channels[+el.dataset.r];
    const pi = +el.dataset.p;
    if (!c || pi < 0) return null;
    const end = this.start + this.SPAN;
    return (this.data[c.name] || []).filter(p => p.stop > this.start && p.start < end)[pi] || null;
  },

  select(el) {
    if (this.cell) this.cell.classList.remove("focused");
    this.cell = el;
    el.classList.add("focused");
    const row = el.closest(".g-row");
    const body = $("#g-body");
    if (row.offsetTop < body.scrollTop) body.scrollTop = row.offsetTop;
    else if (row.offsetTop + row.offsetHeight > body.scrollTop + body.clientHeight)
      body.scrollTop = row.offsetTop + row.offsetHeight - body.clientHeight;
    this.showMini();
  },

  focusRow(ri, t) {
    const cells = this.rowCells(ri);
    if (!cells.length) return;
    let pick = cells[0];
    for (const el of cells) {
      const p = this.progOf(el);
      if (p && p.start <= t && t < p.stop) { pick = el; break; }
      if (p && p.start <= t) pick = el;
    }
    this.row = ri;
    this.select(pick);
  },

  showMini() {
    const p = this.cell && this.progOf(this.cell);
    const c = TV.channels[this.row];
    $("#g-detail").innerHTML = p ? `
      <div class="gd-time">${dayLabel(p.start)}, ${hhmm(p.start)} – ${hhmm(p.stop)} · ${esc(c.name)}${p.cat ? " · " + esc(p.cat) : ""}</div>
      <div class="gd-title">${esc(p.title)}</div>
      <div class="gd-desc">${esc(p.sub ? p.sub + (p.desc ? " – " : "") : "")}${esc((p.desc || "").slice(0, 260))}</div>
      <div class="gd-hint"><b>OK</b> Details · <b>◀ ▶</b> Sendungen · <b>▲ ▼</b> Sender · <b>CH±</b> Seite</div>`
      : `<div class="gd-title">${esc(c ? c.name : "")}</div><div class="gd-desc">Für diesen Sender gibt es keine Programminformationen. <b>OK</b> schaltet ihn ein.</div>`;
  },

  async shift(dir) {
    const now = Math.floor(Date.now() / 1000 / 1800) * 1800;
    const next = Math.min(now + 44 * 3600, Math.max(now - 3600, this.start + dir * 1800));
    if (next === this.start) return;
    this.start = next;
    await this.load();
  },

  key(e) {
    if (!this.active || document.querySelector("#modals .modal")) return false;
    const k = e.key;
    // Auswahl steht auf „Suchen“ (über der Tabelle)
    if (Nav.current && Nav.current.id === "g-search") {
      if (k !== "ArrowDown") return false;
      Nav.current.classList.remove("focused");
      Nav.current = null;
      this.focusRow(this.row, this.focusTime);
      e.preventDefault();
      return true;
    }
    if (k === "ArrowUp" && this.row === 0 && $("#g-search")) {
      if (this.cell) this.cell.classList.remove("focused");
      Nav.focus($("#g-search"), false);
      e.preventDefault();
      return true;
    }
    if (!this.cell) return false;
    const cells = this.rowCells(this.row);
    const idx = cells.indexOf(this.cell);
    const p = this.progOf(this.cell);
    if (k === "ArrowRight") {
      if (idx < cells.length - 1) {
        this.select(cells[idx + 1]);
        const np = this.progOf(this.cell);
        if (np) this.focusTime = Math.max(np.start, this.start);
      } else {
        // Ende des sichtbaren Zeitraums: eine Stunde weiter
        this.focusTime = (p ? p.stop : this.focusTime + 3600) + 1;
        this.shift(2);
      }
    } else if (k === "ArrowLeft") {
      if (idx > 0) {
        this.select(cells[idx - 1]);
        const np = this.progOf(this.cell);
        if (np) this.focusTime = Math.max(np.start, this.start);
      } else if (this.start > Math.floor(Date.now() / 1000 / 1800) * 1800 - 3600) {
        this.focusTime = (p ? p.start : this.focusTime) - 60;
        this.shift(-2);
      }
    } else if (k === "ArrowDown") {
      if (this.row < TV.channels.length - 1) this.focusRow(this.row + 1, this.focusTime);
    } else if (k === "ArrowUp") {
      if (this.row > 0) this.focusRow(this.row - 1, this.focusTime);
    } else if (k === "PageDown") {
      this.focusRow(Math.min(TV.channels.length - 1, this.row + 8), this.focusTime);
    } else if (k === "PageUp") {
      this.focusRow(Math.max(0, this.row - 8), this.focusTime);
    } else if (k === "Enter" || k === " ") {
      this.details();
    } else {
      return false;
    }
    e.preventDefault();
    return true;
  },

  details() {
    const p = this.cell && this.progOf(this.cell);
    const c = TV.channels[this.row];
    if (!c) return;
    if (!p) return openChannel(this.row);
    showProgram(c.name, this.row, p, () => { if (this.token === renderToken) this.draw(); });
  },
};

function renderGuide(view, token) {
  Guide.open(view, token);
}

// ======================================================================
// Eigene Medien
// ======================================================================
const MEDIA_FILTERS = [["all", "Alle"], ["video", "Videos"], ["audio", "Musik"], ["image", "Fotos"]];

function mediaHash(src, path) {
  return "#/media/" + encodeURIComponent(src) + (path ? "/" + path.split("/").map(encodeURIComponent).join("/") : "");
}

function renderMedia(view, token) {
  view.innerHTML = `
    <div class="page wide">
      <h1>Eigene Medien</h1>
      <p class="lead">Videos, Musik und Fotos von USB-Sticks, Festplatten oder aus dem Heimnetz (z. B. FRITZ!Box-Speicher, NAS, Windows-Freigabe).</p>
      <div class="source-grid" id="sources"><div class="empty">Suche Speicher …</div></div>
    </div>`;
  let lastJson = "";

  async function load() {
    let data;
    try { data = await API.get("/api/media/sources"); } catch (e) { return toast(e.message, "error"); }
    if (token !== renderToken) return;
    const json = JSON.stringify(data);
    if (json === lastJson) return;
    lastJson = json;
    const cards = data.sources.map(s => `
      <div class="source-wrap">
        <button class="source nav" data-key="src-${esc(s.id)}" data-src="${esc(s.id)}">
          <span class="src-icon">${s.kind === "usb" ? ICON.usb : ICON.network}</span>
          <span class="src-name">${esc(s.name)}</span>
          <span class="src-sub">${s.kind === "usb" ? "USB · " + fmtBytes(s.size) : esc(s.server + " / " + s.share) + (s.online ? "" : " · nicht verbunden")}</span>
        </button>
        ${s.kind === "net" ? `<button class="btn small nav" data-key="rm-${esc(s.id)}" data-rm="${esc(s.id)}">Entfernen</button>` : ""}
      </div>`).join("");
    const recCard = `<div class="source-wrap"><button class="source nav" data-key="src-rec" data-go="#/recordings">
        <span class="src-icon"><i class="rec-dot big"></i></span><span class="src-name">Aufnahmen</span>
        <span class="src-sub">Aufgenommene Sendungen</span></button></div>`;
    $("#sources").innerHTML = recCard + cards + `
      <div class="source-wrap"><button class="source add nav" data-key="src-add" id="src-add">
        <span class="src-icon">${ICON.plus}</span><span class="src-name">Netzwerkfreigabe hinzufügen</span>
        <span class="src-sub">FRITZ!Box, NAS, Windows-PC</span></button></div>
      ${data.sources.some(s => s.kind === "usb") ? "" : `<div class="hint-card">${ICON.usb}<span>Steck einen USB-Stick oder eine Festplatte an den Raspberry Pi – sie erscheint hier automatisch.</span></div>`}`;
    $("#sources").querySelectorAll("[data-src]").forEach(el => el.addEventListener("click", () => go(mediaHash(el.dataset.src, ""))));
    $("#sources").querySelectorAll("[data-rm]").forEach(el => el.addEventListener("click", async () => {
      if (!await confirmDialog("Freigabe entfernen?", "Die Dateien bleiben auf dem Gerät im Netzwerk erhalten.", "Entfernen", "danger")) return;
      try { await API.post("/api/media/shares/remove", { id: el.dataset.rm }); lastJson = ""; load(); } catch (e) { toast(e.message, "error"); }
    }));
    $("#src-add").addEventListener("click", addShareDialog);
    Nav.refocus();
  }

  function addShareDialog() {
    const { el, close } = openModal({
      title: "Netzwerkfreigabe hinzufügen",
      top: true,
      html: `<div class="form">
        <label>Rechner / NAS<input class="nav" id="sh-server" data-key="sh-server" placeholder="z. B. fritz.box oder 192.168.178.20" autocomplete="off" spellcheck="false"></label>
        <label>Freigabe<input class="nav" id="sh-share" data-key="sh-share" placeholder="z. B. FRITZ.NAS oder Videos" autocomplete="off" spellcheck="false"></label>
        <label>Benutzer (leer = Gast)<input class="nav" id="sh-user" data-key="sh-user" autocomplete="off" spellcheck="false"></label>
        <label>Passwort<input class="nav" id="sh-pass" data-key="sh-pass" type="password" autocomplete="off"></label>
        <label>Anzeigename (optional)<input class="nav" id="sh-name" data-key="sh-name" placeholder="z. B. Filme" autocomplete="off"></label>
      </div>`,
      buttons: [
        { label: "Abbrechen" },
        { label: "Verbinden", style: "primary", action: async () => {
          const body = { server: $("#sh-server", el).value, share: $("#sh-share", el).value,
                         user: $("#sh-user", el).value, password: $("#sh-pass", el).value, name: $("#sh-name", el).value };
          const btn = el.querySelector(".btn.primary");
          btn.textContent = "Verbinde …";
          try {
            await API.post("/api/media/shares/add", body);
            close(); toast("Freigabe verbunden", "ok"); lastJson = ""; load();
          } catch (e) { btn.textContent = "Verbinden"; toast(e.message, "error", 6000); }
        } },
      ],
      focus: "#sh-server",
    });
  }

  load();
  pageTimers.push(setInterval(load, 4000));
}

function renderMediaBrowse(view, token, params) {
  const src = params.src, path = params.path || "";
  let filter = "all";
  try { filter = sessionStorage.getItem("media.filter") || "all"; } catch (_) {}
  view.innerHTML = `
    <div class="media-head">
      <div class="crumbs" id="m-crumbs"></div>
      <div class="filters">${MEDIA_FILTERS.map(([k, l]) => `<button class="chip nav ${k === filter ? "on" : ""}" data-key="f-${k}" data-filter="${k}">${l}</button>`).join("")}</div>
    </div>
    <div class="media-grid" id="m-grid"><div class="empty">Lade …</div></div>`;
  let entries = [];

  view.querySelectorAll("[data-filter]").forEach(el => el.addEventListener("click", () => {
    filter = el.dataset.filter;
    try { sessionStorage.setItem("media.filter", filter); } catch (_) {}
    view.querySelectorAll("[data-filter]").forEach(b => b.classList.toggle("on", b === el));
    draw();
  }));

  function draw() {
    const shown = entries.filter(e => e.type === "dir" || filter === "all" || e.type === filter);
    const iconFor = t => t === "dir" ? ICON.folder : t === "video" ? ICON.video : t === "audio" ? ICON.music : ICON.photo;
    $("#m-grid").innerHTML = shown.length ? shown.map((e, i) => {
      const thumb = e.type === "dir"
        ? (e.cover ? `/media/thumb?src=${encodeURIComponent(src)}&path=${encodeURIComponent(e.cover)}` : null)
        : (e.type !== "audio" ? `/media/thumb?src=${encodeURIComponent(src)}&path=${encodeURIComponent(e.path)}` : null);
      return `<button class="m-item nav ${e.type}" data-key="m-${esc(e.path)}" data-i="${i}">
        <span class="m-thumb">${iconFor(e.type)}${thumb ? `<img loading="lazy" src="${thumb}" alt="" onerror="this.remove()">` : ""}</span>
        <span class="m-name">${esc(e.name)}</span>
        <span class="m-sub">${e.type === "dir" ? "Ordner" : fmtBytes(e.size)}</span>
      </button>`;
    }).join("") : `<div class="empty">${entries.length ? "In diesem Ordner gibt es keine passenden Dateien." : "Dieser Ordner enthält keine Videos, Musik oder Fotos."}</div>`;
    $("#m-grid").querySelectorAll("[data-i]").forEach(el => el.addEventListener("click", () => {
      const e = shown[+el.dataset.i];
      if (e.type === "dir") return go(mediaHash(src, e.path));
      showOverlay("Wird geöffnet …");
      location.href = `/player.html?src=${encodeURIComponent(src)}&path=${encodeURIComponent(e.path)}`;
    }));
    // Beim Öffnen eines Ordners steht die Auswahl auf dem ersten Eintrag (nicht auf den Filtern)
    const first = $("#m-grid .m-item");
    if (first && (!Nav.current || (Nav.current.classList.contains("chip") && !draw.done))) Nav.focus(first, false);
    else Nav.refocus();
    draw.done = true;
  }

  API.get(`/api/media/list?src=${encodeURIComponent(src)}&path=${encodeURIComponent(path)}`).then(r => {
    if (token !== renderToken) return;
    entries = r.entries;
    const parts = r.path ? r.path.split("/") : [];
    $("#m-crumbs").innerHTML = `<span>${ICON.folder}</span>` + [esc(src.startsWith("usb") ? "USB" : "Netzwerk")]
      .concat(parts.map(esc)).join(" <i>›</i> ");
    draw();
  }).catch(e => {
    if (token !== renderToken) return;
    $("#m-grid").innerHTML = `<div class="empty">${esc(e.message)}</div>`;
  });
}

// ======================================================================
// Einstellungen: Bild
// ======================================================================
function renderDisplay(view, token) {
  view.innerHTML = `
    <div class="page">
      <h1>Bild</h1>
      <p class="lead">Normalerweise wählt Raspi-TV die beste Auflösung automatisch. Wird das Bild am Rand abgeschnitten, verkleinere die Bildgröße.</p>
      <h2>Bildgröße (Rand)</h2>
      <div class="list">
        <div class="row nav slider" data-key="scale" id="scale" tabindex="-1">
          <span class="icon">${ICON.picture}</span>
          <span class="main"><div class="label">Bildgröße</div><div class="desc">Mit ◀ ▶ ändern</div></span>
          <span class="slider-track"><span class="slider-fill" id="sc-fill"></span><span class="slider-knob" id="sc-knob"></span></span>
          <span class="value" id="sc-val"></span>
        </div>
      </div>
      <h2>Auflösung</h2>
      <div class="list" id="modes"><div class="empty">Lade …</div></div>
    </div>`;
  let scale = state.config.ui_scale || 100, sendTimer;
  const drawScale = () => {
    const pct = (scale - 80) / 30 * 100;
    $("#sc-fill").style.width = pct + "%";
    $("#sc-knob").style.left = pct + "%";
    $("#sc-val").textContent = scale + " %";
  };
  drawScale();
  $("#scale")._adjust = d => {
    scale = Math.max(80, Math.min(110, scale + (d > 0 ? 1 : -1)));
    drawScale();
    applyScale(scale);
    clearTimeout(sendTimer);
    sendTimer = setTimeout(() => API.post("/api/display/scale", { scale }).then(r => { state.config.ui_scale = r.scale; }).catch(() => {}), 400);
  };

  function draw(info) {
    if (token !== renderToken) return;
    if (!info.available || !info.modes.length) {
      $("#modes").innerHTML = '<div class="empty">Auflösungen können gerade nicht gelesen werden.</div>';
      return;
    }
    const opts = [{ id: "auto", label: "Automatisch (empfohlen)", desc: "Beste Auflösung des Fernsehers" }];
    const want = ["60.00", "59.94", "50.00", "30.00", "25.00", "24.00"];
    for (const m of info.modes.slice(0, 12)) {
      for (const r of m.rates.filter(r => want.includes(r)).slice(0, 2)) {
        opts.push({ id: `${m.mode}@${r}`, label: m.mode.replace("x", " × "), desc: Math.round(+r) + " Hz" });
      }
    }
    const saved = info.saved === "auto" ? "auto" : (() => { const p = info.saved.split(" "); return p[2] ? `${p[1]}@${p[2]}` : p[1]; })();
    $("#modes").innerHTML = opts.map(o => `
      <button class="row nav" data-key="mode-${esc(o.id)}" data-mode="${esc(o.id)}">
        <span class="radio ${o.id === saved || (saved !== "auto" && saved === o.id.split("@")[0]) ? "on" : ""}"></span>
        <span class="main"><div class="label">${esc(o.label)}</div><div class="desc">${esc(o.desc)}${info.current === o.id ? " · aktuell" : ""}</div></span>
      </button>`).join("");
    $("#modes").querySelectorAll("[data-mode]").forEach(el => el.addEventListener("click", () => setMode(el.dataset.mode, saved)));
    Nav.refocus();
  }

  async function setMode(mode, previous) {
    try { draw(await API.post("/api/display", { mode })); } catch (e) { return toast(e.message, "error"); }
    if (mode === "auto") return toast("Automatische Auflösung", "ok");
    // Wie beim Fernseher: ohne Bestätigung nach 15 s zurück
    let left = 15, timer;
    const { el, close } = openModal({
      title: "Bild in Ordnung?",
      html: `<p>Ohne Bestätigung wird in <b id="cd">${left}</b> Sekunden die vorherige Auflösung wiederhergestellt.</p>`,
      buttons: [
        { label: "Zurücksetzen", action: c => { clearInterval(timer); c(); revert(); } },
        { label: "Behalten", style: "primary", action: c => { clearInterval(timer); c(); toast("Auflösung gespeichert", "ok"); } },
      ],
      focus: ".btn.primary",
    });
    timer = setInterval(() => {
      left--;
      const cd = $("#cd", el);
      if (cd) cd.textContent = left;
      if (left <= 0) { clearInterval(timer); close(); revert(); }
    }, 1000);
    async function revert() {
      try { draw(await API.post("/api/display", { mode: previous || "auto" })); } catch (_) {}
    }
  }

  API.get("/api/display").then(draw).catch(e => toast(e.message, "error"));
}

function applyScale(scale) {
  const s = (scale || 100) / 100;
  document.body.style.transform = s === 1 ? "" : `scale(${s})`;
}

// ======================================================================
// Einstellungen: Sender
// ======================================================================
const ChannelSort = { moving: null };

function renderChannelSettings(view, token) {
  view.innerHTML = `
    <div class="page">
      <h1>Sender</h1>
      <p class="lead">Ordne die Sender so, wie du sie am Fernseher haben möchtest. <b>OK</b> auf einem Sender: verschieben oder ausblenden.</p>
      <div class="list">
        <button class="row nav" data-key="m3u" id="ch-m3u"><span class="icon">${ICON.plus}</span>
          <span class="main"><div class="label">Eigene Senderliste (M3U)</div><div class="desc" id="m3u-desc">z. B. von einem TV-Server im Heimnetz</div></span></button>
        <button class="row nav" data-key="ch-reset" id="ch-reset"><span class="icon">${ICON.restart}</span>
          <span class="main"><div class="label">Reihenfolge zurücksetzen</div><div class="desc">Alle Sender wieder einblenden, Standard-Reihenfolge</div></span></button>
      </div>
      <h2>Senderliste</h2>
      <div class="list" id="ch-list"><div class="empty">Lade …</div></div>
    </div>`;
  let chans = [];
  ChannelSort.moving = null;

  function draw(data) {
    if (token !== renderToken) return;
    chans = data.channels;
    $("#m3u-desc").textContent = data.m3u ? "Aktiv: " + data.m3u : "z. B. von einem TV-Server im Heimnetz";
    let n = 0;
    $("#ch-list").innerHTML = chans.map((c, i) => `
      <button class="row nav ch-row ${c.hidden ? "muted" : ""} ${ChannelSort.moving === c.name ? "moving" : ""}" data-key="ch-${esc(c.name)}" data-i="${i}">
        <span class="chnum">${c.hidden ? "–" : ++n}</span>
        <span class="main"><div class="label">${esc(c.name)}</div><div class="desc">${esc(c.group || "")}${c.custom ? " · eigene Liste" : ""}</div></span>
        <span class="value">${ChannelSort.moving === c.name ? '<span class="badge accent">▲▼ verschieben · OK fertig</span>' : c.hidden ? '<span class="badge">ausgeblendet</span>' : ""}</span>
      </button>`).join("");
    $("#ch-list").querySelectorAll("[data-i]").forEach(el => el.addEventListener("click", () => choose(chans[+el.dataset.i])));
    Nav.refocus();
  }

  async function save() {
    try {
      draw(await API.post("/api/channels/config", {
        order: chans.map(c => c.name), hidden: chans.filter(c => c.hidden).map(c => c.name),
      }));
    } catch (e) { toast(e.message, "error"); }
  }

  function choose(c) {
    if (ChannelSort.moving) { ChannelSort.moving = null; save(); return; }
    openModal({
      title: c.name,
      buttons: [
        { label: "Abbrechen" },
        { label: c.hidden ? "Einblenden" : "Ausblenden", action: cl => { cl(); c.hidden = !c.hidden; save(); } },
        { label: "Verschieben", style: "primary", action: cl => {
          cl(); ChannelSort.moving = c.name; draw({ channels: chans, m3u: "" });
          const el = document.querySelector(`[data-key="ch-${CSS.escape(c.name)}"]`); if (el) Nav.focus(el);
        } },
      ],
      focus: ".btn.primary",
    });
  }

  ChannelSort.key = e => {
    if (!ChannelSort.moving || document.querySelector("#modals .modal")) return false;
    const i = chans.findIndex(c => c.name === ChannelSort.moving);
    if (e.key === "ArrowUp" || e.key === "ArrowDown" || e.key === "PageUp" || e.key === "PageDown") {
      const d = { ArrowUp: -1, ArrowDown: 1, PageUp: -5, PageDown: 5 }[e.key];
      const j = Math.max(0, Math.min(chans.length - 1, i + d));
      const [c] = chans.splice(i, 1);
      chans.splice(j, 0, c);
      draw({ channels: chans, m3u: "" });
      const el = document.querySelector(`[data-key="ch-${CSS.escape(c.name)}"]`); if (el) Nav.focus(el);
      e.preventDefault();
      return true;
    }
    if (e.key === "Escape" || e.key === "Backspace" || e.key === "BrowserBack") {
      ChannelSort.moving = null; save(); e.preventDefault(); return true;
    }
    return false;
  };

  $("#ch-reset").addEventListener("click", async () => {
    if (!await confirmDialog("Reihenfolge zurücksetzen?", "Alle Sender werden wieder eingeblendet und wie ab Werk sortiert.", "Zurücksetzen")) return;
    try { draw(await API.post("/api/channels/reset")); toast("Zurückgesetzt", "ok"); } catch (e) { toast(e.message, "error"); }
  });
  $("#ch-m3u").addEventListener("click", () => {
    const { el, close } = openModal({
      title: "Eigene Senderliste",
      top: true,
      html: `<p>Adresse einer M3U-Senderliste, z. B. von einem TV-Server (Tvheadend, Jellyfin) oder Anbieter.
             Es werden Streams im Format HLS/MP4 unterstützt. Leer lassen zum Entfernen.</p>
             <div class="field"><input class="nav" id="m3u" data-key="m3u-in" placeholder="http://192.168.178.20:9981/playlist" autocomplete="off" spellcheck="false"></div>`,
      buttons: [
        { label: "Abbrechen" },
        { label: "Übernehmen", style: "primary", action: async () => {
          try { draw(await API.post("/api/channels/m3u", { url: $("#m3u", el).value })); close(); toast("Senderliste übernommen", "ok"); }
          catch (e) { toast(e.message, "error", 6000); }
        } },
      ],
      focus: "#m3u",
    });
  });

  API.get("/api/channels/settings").then(draw).catch(e => toast(e.message, "error"));
}

// ======================================================================
// Einstellungen: Fernbedienung
// ======================================================================
function renderRemoteSettings(view, token) {
  view.innerHTML = `
    <div class="page">
      <h1>Fernbedienung</h1>
      <p class="lead">Raspi-TV wird mit der Fernbedienung deines Fernsehers bedient (HDMI-CEC). Alternativ geht das Handy oder eine Funk-Tastatur/Air-Maus.</p>
      <div class="list">
        <div class="row static"><span class="icon">${ICON.tv}</span><span class="main">
          <div class="label">Verbindung zum Fernseher (HDMI-CEC)</div><div class="desc" id="cec-desc">Prüfe …</div></span>
          <span class="value" id="cec-val"></span></div>
        <button class="row nav" data-key="phone" data-go="#/settings/phone"><span class="icon">${ICON.phone}</span>
          <span class="main"><div class="label">Handy als Fernbedienung</div><div class="desc">Mit Touchpad und Tastatur – QR-Code scannen</div></span></button>
      </div>
      <h2>Tasten</h2>
      <dl class="info keys">
        <dt>Pfeile · OK</dt><dd>Auswählen · Bestätigen</dd>
        <dt>Zurück</dt><dd>Eine Ebene zurück · lang drücken: Startseite</dd>
        <dt>Home / Menü / Rot</dt><dd>Startseite – aus jeder App</dd>
        <dt>CH + / CH –</dt><dd>Sender wechseln · im Programm seitenweise blättern</dd>
        <dt>0 – 9</dt><dd>Sender direkt wählen · nur 0: zurück zum vorherigen Sender</dd>
        <dt>Guide / EPG</dt><dd>TV-Programm</dd>
        <dt>Info</dt><dd>Infoleiste mit aktueller Sendung</dd>
        <dt>Grün</dt><dd>Maus-Modus: Pfeile bewegen den Zeiger, OK klickt</dd>
        <dt>Gelb</dt><dd>Schließen / Vollbild verlassen</dd>
        <dt>Blau</dt><dd>Seite neu laden</dd>
        <dt>Play · Pause · Spulen</dt><dd>Wiedergabe steuern</dd>
      </dl>
    </div>`;
  API.get("/api/cec").then(c => {
    if (token !== renderToken) return;
    $("#cec-desc").textContent = c.adapter
      ? (c.tv === "on" ? "Fernseher erkannt und eingeschaltet" : c.tv === "standby" ? "Fernseher erkannt (Standby)" : "Bereit – drücke eine Taste auf der TV-Fernbedienung")
      : "Nicht verfügbar";
    $("#cec-val").innerHTML = c.adapter && c.tv !== "unknown" ? '<span class="badge ok">Aktiv</span>' : '<span class="badge">Prüfen</span>';
    if (!c.adapter || c.tv === "unknown") {
      $("#cec-desc").textContent += " · Am Fernseher HDMI-CEC einschalten (Anynet+, SimpLink, Bravia Sync, VIERA Link, EasyLink).";
    }
  }).catch(() => {});
}

// ======================================================================
// Einstellungen: Updates
// ======================================================================
function renderUpdates(view, token) {
  view.innerHTML = `
    <div class="page">
      <h1>Updates</h1>
      <p class="lead">Halte Raspi-TV aktuell – wichtig für Browser und Streaming (DRM).</p>
      <div class="list">
        <button class="row nav" data-key="update" id="upd">
          <span class="icon">${ICON.update}</span>
          <span class="main"><div class="label">System aktualisieren</div><div class="desc" id="upd-desc">Neueste Versionen von Browser, DRM und System installieren</div></span>
          <span class="value" id="upd-val"></span>
        </button>
        <button class="row nav" data-key="epg" id="epg">
          <span class="icon">${ICON.guide}</span>
          <span class="main"><div class="label">Programmdaten aktualisieren</div><div class="desc" id="epg-desc">Prüfe …</div></span>
        </button>
        <div class="row static"><span class="icon">${ICON.list}</span><span class="main">
          <div class="label">Sender-Adressen</div><div class="desc">Werden automatisch alle 12 Stunden geprüft und bei Änderungen angepasst.</div></span></div>
      </div>
    </div>`;

  let poll = null;
  function drawUpdate(u) {
    if (token !== renderToken) return;
    if (u.running) {
      $("#upd-val").innerHTML = '<span class="spinner"></span>Läuft …';
      $("#upd-desc").textContent = (u.log || []).filter(Boolean).slice(-1)[0] || "Wird vorbereitet …";
      if (!poll) { poll = setInterval(() => API.get("/api/update").then(drawUpdate).catch(() => {}), 3000); pageTimers.push(poll); }
    } else {
      if (poll) { clearInterval(poll); poll = null; }
      if (u.rc === 0) {
        $("#upd-val").innerHTML = '<span class="badge ok">Fertig</span>';
        $("#upd-desc").textContent = u.reboot_required ? "Fertig – bitte neu starten (Einstellungen → System)." : "System ist auf dem neuesten Stand.";
      } else if (u.rc != null) {
        $("#upd-val").innerHTML = '<span class="badge">Fehler</span>';
        $("#upd-desc").textContent = "Aktualisierung fehlgeschlagen – Internetverbindung prüfen.";
      }
    }
  }
  function drawEpg(s) {
    if (token !== renderToken) return;
    $("#epg-desc").textContent = s.running ? "Wird gerade geladen …"
      : s.updated ? `Stand: ${dayLabel(s.updated)}, ${hhmm(s.updated)} Uhr · ${s.channels} Sender`
      : (s.error ? "Fehler: " + s.error : "Noch nicht geladen");
  }
  API.get("/api/update").then(drawUpdate).catch(() => {});
  API.get("/api/epg/status").then(drawEpg).catch(() => {});
  addUsbUpdateSection(view, token);

  $("#upd").addEventListener("click", async () => {
    if (state.network && !state.network.online) return toast("Dafür brauchst du Internet.", "error");
    if (!await confirmDialog("System aktualisieren?", "Das kann einige Minuten dauern. Du kannst währenddessen weiter fernsehen.", "Aktualisieren")) return;
    try { drawUpdate(await API.post("/api/update")); } catch (e) { toast(e.message, "error"); }
  });
  $("#epg").addEventListener("click", async () => {
    try { await API.post("/api/epg/refresh"); toast("Programmdaten werden geladen …"); } catch (e) { toast(e.message, "error"); }
    setTimeout(() => API.get("/api/epg/status").then(drawEpg).catch(() => {}), 1500);
  });
}
