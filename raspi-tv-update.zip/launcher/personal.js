/* Raspi-TV 5.4 – persönliche Profile und zentrale App-Suche. */
"use strict";
const Personal = {
  keys: ["tv.channel", "tv.recent", "tv.favs", "tv.favOnly"],
  name() {
    return ((state.config.profiles || []).find(p => p.id === state.config.active_profile) || {}).name || "Standard";
  },
  sync() {
    try {
      const current = localStorage.getItem("personal.active") || "default";
      const next = state.config.active_profile || "default";
      if (current !== next) {
        const saved = {};
        this.keys.forEach(k => { saved[k] = localStorage.getItem(k); });
        localStorage.setItem("personal.tv." + current, JSON.stringify(saved));
        const restore = JSON.parse(localStorage.getItem("personal.tv." + next) || "{}");
        this.keys.forEach(k => {
          if (typeof restore[k] === "string") localStorage.setItem(k, restore[k]);
          else localStorage.removeItem(k);
        });
      }
      localStorage.setItem("personal.active", next);
    } catch (_) { /* Oberfläche bleibt auch ohne Browser-Speicher bedienbar. */ }
  },
};

async function renderProfiles(view, token) {
  view.innerHTML = '<div class="page wide"><h1>Benutzerprofile</h1><p class="lead">Profile werden geladen …</p></div>';
  let data;
  try { data = await API.get("/api/profiles"); }
  catch (e) { if (token === renderToken) view.innerHTML = `<div class="page"><h1>Benutzerprofile</h1><p>${esc(e.message)}</p></div>`; return; }
  if (token !== renderToken) return;
  view.innerHTML = `<div class="page wide"><h1>Dein Raspi-TV</h1>
    <p class="lead">Bis zu acht Profile – jedes mit eigenen Sendern, eigenem Design, eigener Startseite und App-Auswahl, eigenen Schnellaktionen, eigener „Weiterschauen“-Liste und eigenem Spotify-Konto. Neue Profile übernehmen die aktuellen Einstellungen. Andere Streaming-Anmeldungen (Netflix, YouTube …) bleiben gemeinsam.</p>
    <div class="profile-grid">${data.profiles.map(p => `<article class="profile-card ${p.id === data.active ? "active" : ""}">
      <div class="profile-avatar">${esc(p.name.slice(0, 1).toUpperCase())}</div><h2>${esc(p.name)}</h2>
      <p>${p.id === data.active ? "Aktives Profil" : "Eigene Sender, Apps &amp; Spotify"}</p>
      <button class="btn nav" data-key="profile-${p.id}" data-switch="${p.id}" ${p.id === data.active ? "disabled" : ""}>Wechseln</button>
      <button class="btn nav" data-key="rename-${p.id}" data-rename="${p.id}">Umbenennen</button>
      ${p.id !== data.active ? `<button class="btn nav" data-key="delete-${p.id}" data-delete="${p.id}">Löschen</button>` : ""}</article>`).join("")}</div>
    <div class="profile-tools"><button class="btn primary nav" id="profile-new" data-key="profile-new" ${data.profiles.length >= 8 ? "disabled" : ""}>Neues Profil</button>
    <button class="btn nav" data-key="profile-channels" data-go="#/settings/channels">Sender bearbeiten</button>
    <button class="btn nav" data-key="profile-look" data-go="#/settings/look">Design bearbeiten</button></div></div>`;
  async function change(body, reload = false) {
    try {
      const updated = await API.post("/api/profiles", body);
      state.config.active_profile = updated.active;
      state.config.profiles = updated.profiles;
      if (reload) { location.href = "/#/"; location.reload(); }
      else if (token === renderToken) { await renderProfiles(view, token); Nav.restore(); }
    } catch (e) { toast(e.message, "error"); }
  }
  function nameDialog(profile) {
    const dialog = openModal({ title: profile ? "Profil umbenennen" : "Neues Profil",
      html: `<label for="profile-name">Profilname</label><input class="field nav" id="profile-name" maxlength="24" value="${esc(profile ? profile.name : "")}" autocomplete="off">`,
      focus: "#profile-name", buttons: [{ label: "Abbrechen" }, { label: "Speichern", style: "primary", action: async close => {
        const name = dialog.el.querySelector("input").value.trim();
        if (!name) return toast("Bitte einen Profilnamen eingeben.", "error");
        close(); await change({ action: profile ? "rename" : "create", id: profile && profile.id, name });
      } }] });
  }
  view.querySelector("#profile-new").onclick = () => nameDialog(null);
  view.querySelectorAll("[data-rename]").forEach(b => b.onclick = () => nameDialog(data.profiles.find(p => p.id === b.dataset.rename)));
  view.querySelectorAll("[data-switch]").forEach(b => b.onclick = () => { b.disabled = true; change({ action: "switch", id: b.dataset.switch }, true).finally(() => { b.disabled = false; }); });
  view.querySelectorAll("[data-delete]").forEach(b => b.onclick = async () => {
    const p = data.profiles.find(p => p.id === b.dataset.delete);
    if (await confirmDialog("Profil löschen?", `„${p.name}“ und seine persönlichen Einstellungen entfernen?`, "Löschen")) change({ action: "delete", id: p.id });
  });
  Nav.restore();
}

function appSearchResults(query, filter = "all") {
  const norm = s => String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase();
  const terms = norm(query).trim().split(/\s+/).filter(Boolean);
  const catalog = new Map(STORE.map(a => [a.id, a]));
  allApps().forEach(a => { if (!catalog.has(a.id)) catalog.set(a.id, a); });
  return [...catalog.values()].filter(a => {
    const installed = Store.isInstalled(a);
    if (filter === "installed" && !installed || filter === "available" && installed) return false;
    return terms.every(t => norm([a.name, a.kind, a.desc, a.sc].join(" ")).includes(t));
  }).sort((a, b) => Number(Store.isInstalled(b)) - Number(Store.isInstalled(a)) || a.name.localeCompare(b.name));
}

function renderAppSearch(view) {
  let filter = "all";
  view.innerHTML = `<div class="page wide"><h1>Welche App suchst du?</h1><p class="lead">Installierte Apps und den gesamten App-Katalog gemeinsam durchsuchen.</p>
    <label for="app-query">Name oder Thema</label><input id="app-query" class="field nav catalog-query" data-key="app-query" type="search" placeholder="Zum Beispiel Spotify, Filme oder Nachrichten" autocomplete="off">
    <div class="filters">${[["all", "Alle Apps"], ["installed", "Installiert"], ["available", "Verfügbar"]].map(([id, text]) => `<button class="chip nav ${id === filter ? "on" : ""}" data-key="filter-${id}" data-filter="${id}">${text}</button>`).join("")}</div>
    <p id="app-count" role="status" aria-live="polite"></p><div class="catalog-grid" id="app-results"></div></div>`;
  function draw() {
    const apps = appSearchResults(view.querySelector("input").value, filter);
    view.querySelector("#app-count").textContent = `${apps.length} Apps gefunden`;
    view.querySelector("#app-results").innerHTML = apps.length ? apps.map(a => `<article class="catalog-card"><h2>${esc(a.name)}</h2><p>${esc(a.kind)}</p><small>${Store.isInstalled(a) ? "Installiert" : "Im App-Katalog"}</small>
      <div>${Store.isInstalled(a) && !a.service ? `<button class="btn primary nav" data-key="launch-${esc(a.id)}" data-launch="${esc(a.id)}">Öffnen</button>` : ""}
      <button class="btn nav" data-key="details-${esc(a.id)}" data-details="${esc(a.id)}">Details</button></div></article>`).join("") : '<p class="lead">Keine passende App. Versuche einen anderen Suchbegriff oder Filter.</p>';
    view.querySelectorAll("[data-launch]").forEach(b => b.onclick = () => openApp(b.dataset.launch));
    view.querySelectorAll("[data-details]").forEach(b => b.onclick = () => storeDetail(apps.find(a => a.id === b.dataset.details), draw));
  }
  view.querySelector("input").oninput = draw;
  view.querySelectorAll("[data-filter]").forEach(b => b.onclick = () => {
    filter = b.dataset.filter;
    view.querySelectorAll("[data-filter]").forEach(x => x.classList.toggle("on", x === b));
    draw();
  });
  draw();
}
