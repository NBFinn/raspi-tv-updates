/* Raspi-TV – Wiedergabe eigener Videos, Musik und Fotos */
"use strict";

const $ = id => document.getElementById(id);
const qs = new URLSearchParams(location.search);
const SRC = qs.get("src") || "";
const CAST = qs.has("cast");   // vom Handy per DLNA geschickt
let path = qs.get("path") || "";
const video = $("video"), audio = $("audio"), photo = $("photo");
const ICON_PLAY = '<svg viewBox="0 0 24 24" fill="#fff"><path d="M7 4l13 8-13 8z"/></svg>';
const ICON_PAUSE = '<svg viewBox="0 0 24 24" fill="#fff"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>';
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (_) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) {} },
  del(k) { try { localStorage.removeItem(k); } catch (_) {} },
};

let playlist = [], index = 0, type = "video", osdTimer, toastTimer, slideTimer = null, saveTimer;
const fileUrl = p => `/media/file?src=${encodeURIComponent(SRC)}&path=${encodeURIComponent(p)}`;
const thumbUrl = p => `/media/thumb?src=${encodeURIComponent(SRC)}&path=${encodeURIComponent(p)}`;
const base = p => p.split("/").pop();
const pretty = p => CAST ? p : base(p).replace(/\.[^.]+$/, "").replace(/[._]+/g, " ");
function fmt(t) {
  if (!isFinite(t)) return "–:–";
  t = Math.floor(t);
  const h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), s = t % 60;
  return (h ? h + ":" + String(m).padStart(2, "0") : m) + ":" + String(s).padStart(2, "0");
}
function toast(msg) {
  const t = $("toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("show"), 2600);
}

// ---------------------------------------------------------------- Bedienleiste
const HINTS = {
  video: "<b>OK</b> Pause · <b>◀ ▶</b> 10 s · <b>▲ ▼</b> 1 Min. · <b>CH ±</b> nächstes Video · <b>Zurück</b> Ende",
  audio: "<b>OK</b> Pause · <b>◀ ▶</b> 10 s · <b>▲ ▼ / CH ±</b> Titel wechseln · <b>Zurück</b> Ende",
  image: "<b>◀ ▶</b> Bild wechseln · <b>OK</b> Diashow an/aus · <b>Zurück</b> Ende",
};
function media() { return type === "video" ? video : audio; }

function showOsd(ms = 3500) {
  updateOsd();
  $("osd").classList.add("show");
  document.body.style.cursor = "default";
  clearTimeout(osdTimer);
  const m = media();
  if (type === "image" || !m.paused) osdTimer = setTimeout(() => $("osd").classList.remove("show"), ms);
}

function updateOsd() {
  const p = playlist[index];
  if (!p) return;
  $("name").textContent = pretty(p.path);
  $("hint").innerHTML = HINTS[type];
  if (type === "image") {
    $("state").innerHTML = slideTimer ? ICON_PLAY : ICON_PAUSE;
    $("pos").textContent = `${index + 1} / ${playlist.length}`;
    $("bar").style.width = ((index + 1) / playlist.length * 100) + "%";
    return;
  }
  const m = media();
  $("state").innerHTML = m.paused ? ICON_PAUSE : ICON_PLAY;
  $("pos").textContent = `${fmt(m.currentTime)} / ${fmt(m.duration)}`;
  $("bar").style.width = (m.duration ? m.currentTime / m.duration * 100 : 0) + "%";
}

function flashSeek(sec) {
  const el = sec < 0 ? $("seek-l") : $("seek-r");
  el.textContent = (sec < 0 ? "⟲ " : "⟳ ") + Math.abs(sec) + " s";
  el.classList.add("show");
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove("show"), 700);
}

// ---------------------------------------------------------------- Laden
function load(i) {
  index = (i + playlist.length) % playlist.length;
  const p = playlist[index];
  type = p.type;
  if (p.type !== "image" && slideTimer) { clearInterval(slideTimer); slideTimer = null; }
  video.pause(); audio.pause();
  video.hidden = type !== "video";
  photo.hidden = type !== "image";
  $("music").hidden = type !== "audio";
  $("center").hidden = false;
  $("center").innerHTML = '<div class="spinner"></div>';

  if (type === "video") {
    video.src = p.url || fileUrl(p.path);
    const saved = CAST ? 0 : store.get("resume:" + SRC + ":" + p.path, 0);
    const resume = typeof saved === "object" && saved ? saved.t : saved;
    video.addEventListener("loadedmetadata", function once() {
      video.removeEventListener("loadedmetadata", once);
      if (resume > 30 && resume < video.duration - 60) {
        video.currentTime = resume;
        toast("Fortgesetzt bei " + fmt(resume));
      }
    });
    video.play().catch(() => {});
  } else if (type === "audio") {
    audio.src = p.url || fileUrl(p.path);
    $("m-title").textContent = pretty(p.path);
    $("m-folder").textContent = CAST ? (p.artist || "Vom Handy") : (path.split("/").slice(-2, -1)[0]) || "";
    const nxt = playlist[(index + 1) % playlist.length];
    $("m-next").innerHTML = playlist.length > 1 ? `Als Nächstes: <b>${pretty(nxt.path).replace(/</g, "&lt;")}</b>` : "";
    const art = $("art");
    art.style.backgroundImage = "";
    const img = new Image();
    img.onload = () => { art.style.backgroundImage = `url("${img.src}")`; art.querySelector("svg").style.display = "none"; };
    img.onerror = () => { art.querySelector("svg").style.display = ""; };
    if (CAST && !p.art) img.onerror(); else img.src = CAST ? p.art : thumbUrl(p.path);
    audio.play().catch(() => {});
    $("center").hidden = true;
  } else {
    photo.classList.remove("show", "kb");
    photo.onload = () => {
      $("center").hidden = true;
      requestAnimationFrame(() => { photo.classList.add("show"); if (slideTimer) photo.classList.add("kb"); });
    };
    photo.onerror = () => { $("center").innerHTML = "Dieses Bild kann nicht angezeigt werden."; };
    photo.src = p.url || fileUrl(p.path);
  }
  path = p.path;
  showOsd();
}

function mediaError(m) {
  m.addEventListener("error", () => {
    $("center").hidden = false;
    $("center").innerHTML = "Diese Datei kann nicht abgespielt werden.<br><small>Unterstützt: MP4/MKV/WebM mit H.264 oder VP9, MP3, AAC, FLAC, OGG.</small>";
    if (playlist.length > 1 && type === "audio") setTimeout(() => load(index + 1), 2500);
  });
}
mediaError(video); mediaError(audio);

[video, audio].forEach(m => {
  m.addEventListener("playing", () => { $("center").hidden = true; $("music").classList.add("playing"); updateOsd(); showOsd(2500); });
  m.addEventListener("waiting", () => { if (type === "video") { $("center").hidden = false; $("center").innerHTML = '<div class="spinner"></div>'; } });
  m.addEventListener("pause", () => { $("music").classList.remove("playing"); showOsd(); });
  m.addEventListener("timeupdate", () => {
    if ($("osd").classList.contains("show")) updateOsd();
    if (m === video && !CAST) {
      clearTimeout(saveTimer);
      saveTimer = setTimeout(() => store.set("resume:" + SRC + ":" + path,
        { t: video.currentTime, d: video.duration || 0, at: Date.now() }), 1000);
    }
  });
  m.addEventListener("ended", () => {
    if (CAST) { castReport("ended").catch(() => {}); showOsd(); return; }   // das Handy schickt den nächsten Titel
    if (m === video) store.del("resume:" + SRC + ":" + path);
    if (index < playlist.length - 1) load(index + 1);
    else if (m === audio) load(0);
    else close();
  });
});

function slideshow(on) {
  if (on) {
    slideTimer = setInterval(() => load(index + 1), 6000);
    toast("Diashow gestartet");
    photo.classList.add("kb");
  } else {
    clearInterval(slideTimer);
    slideTimer = null;
    toast("Diashow angehalten");
    photo.classList.remove("kb");
  }
  updateOsd();
}

function close() {
  video.pause(); audio.pause();
  if (CAST) castReport("closed");
  if (history.length > 1) history.back(); else location.href = "/#/media";
}

// ---------------------------------------------------------------- Tasten
document.addEventListener("keydown", e => {
  const k = e.key;
  const m = media();
  if (type === "image") {
    if (k === "ArrowRight" || k === "PageUp" || k === "ArrowDown") load(index + 1);
    else if (k === "ArrowLeft" || k === "PageDown" || k === "ArrowUp") load(index - 1);
    else if (k === "Enter" || k === " ") slideshow(!slideTimer);
    else if (k === "Escape" || k === "Backspace" || k === "BrowserBack") close();
    else return;
    e.preventDefault();
    return;
  }
  switch (k) {
    case "Enter": case " ":
      if (m.paused) m.play().catch(() => {}); else m.pause();
      showOsd();
      break;
    case "ArrowRight": m.currentTime = Math.min(m.duration || 0, m.currentTime + 10); flashSeek(10); showOsd(); break;
    case "ArrowLeft": m.currentTime = Math.max(0, m.currentTime - 10); flashSeek(-10); showOsd(); break;
    case "ArrowUp":
      if (type === "audio") load(index - 1); else { m.currentTime = Math.min(m.duration || 0, m.currentTime + 60); flashSeek(60); showOsd(); }
      break;
    case "ArrowDown":
      if (type === "audio") load(index + 1); else { m.currentTime = Math.max(0, m.currentTime - 60); flashSeek(-60); showOsd(); }
      break;
    case "PageUp": load(index + 1); break;
    case "PageDown": load(index - 1); break;
    case "i": case "I": showOsd(6000); break;
    case "Escape": case "Backspace": case "BrowserBack": close(); break;
    default: return;
  }
  e.preventDefault();
});
document.addEventListener("mousemove", () => showOsd());
document.addEventListener("click", () => { if (type === "image") load(index + 1); else { const m = media(); if (m.paused) m.play(); else m.pause(); } });

// ---------------------------------------------------------------- DLNA (vom Handy)
let castSeq = null, castCmd = 0, castSeek = 0;
function castState() {
  if (type === "image") return castSeq === null ? "idle" : "playing";
  const m = media();
  return m.error ? "error" : m.ended ? "ended" : m.paused ? "paused" : "playing";
}
async function castReport(state) {
  const m = type === "image" ? null : media();
  const body = { seq: castSeq, state: state || castState(), position: m ? m.currentTime || 0 : 0,
                 duration: m && isFinite(m.duration) ? m.duration : 0 };
  const r = await fetch("/api/cast/report", { method: "POST", keepalive: true,
    headers: { "Content-Type": "application/json", "X-Raspi-TV": "1" }, body: JSON.stringify(body) });
  return r.json();
}
async function castTick() {
  let r;
  try { r = await castReport(); } catch (_) { return; }
  if (!r.uri) return;
  if (r.seq !== castSeq) {
    castSeq = r.seq; castCmd = r.cmd_id; castSeek = r.seek_id;
    playlist = [{ path: r.title, type: r.kind, url: r.uri, art: r.art, artist: r.artist }];
    load(0);
    if (r.cmd === "pause") setTimeout(() => media().pause(), 300);
    return;
  }
  if (r.cmd_id !== castCmd) {
    castCmd = r.cmd_id;
    const m = type === "image" ? null : media();
    if (r.cmd === "stop") return close();
    if (m && r.cmd === "pause" && !m.paused) { m.pause(); showOsd(); }
    if (m && r.cmd === "play" && m.paused) { m.play().catch(() => {}); showOsd(); }
  }
  if (r.seek_id !== castSeek) {
    castSeek = r.seek_id;
    const m = type === "image" ? null : media();
    if (m) { m.currentTime = r.seek; showOsd(); }
  }
}

// ---------------------------------------------------------------- Start
(async function init() {
  try {
    const c = await (await fetch("/api/config")).json();
    const sc = (c.ui_scale || 100) / 100;
    if (sc !== 1) document.body.style.transform = `scale(${sc})`;
  } catch (_) {}
  if (CAST) {
    $("center").hidden = false;
    $("center").innerHTML = '<div class="spinner"></div>';
    castTick();
    setInterval(castTick, 700);
    return;
  }
  const dir = path.includes("/") ? path.slice(0, path.lastIndexOf("/")) : "";
  let entries = [];
  try {
    const r = await (await fetch(`/api/media/list?src=${encodeURIComponent(SRC)}&path=${encodeURIComponent(dir)}`)).json();
    entries = r.entries || [];
  } catch (_) {}
  const wanted = entries.find(e => e.path === path);
  const t = wanted ? wanted.type : (/\.(jpe?g|png|gif|webp|bmp)$/i.test(path) ? "image" : /\.(mp3|m4a|aac|flac|ogg|opus|wav)$/i.test(path) ? "audio" : "video");
  playlist = entries.filter(e => e.type === t);
  if (!playlist.length) playlist = [{ path, type: t }];
  load(Math.max(0, playlist.findIndex(e => e.path === path)));
})();
