/* Raspi-TV OS – Videorekorder: Aufnahmen ansehen, geplante Aufnahmen verwalten */
"use strict";

function fmtDur(sec) {
  sec = Math.max(0, Math.round(sec / 60));
  return sec >= 60 ? Math.floor(sec / 60) + " Std. " + (sec % 60 ? (sec % 60) + " Min." : "") : sec + " Min.";
}

// zusammengesetzte Zeilen (Sender · Zeit · Dauer · Größe) für die englische Oberfläche
function recL(s) {
  if (I18N.lang !== "en") return s;
  return s.replace(/\bHeute\b/g, "Today").replace(/\bMorgen\b/g, "Tomorrow").replace(/\bGestern\b/g, "Yesterday")
    .replace(/ Uhr\b/g, "").replace(/ Min\./g, " min").replace(/ Std\./g, " h").replace("Speicherkarte", "SD card");
}

function renderRecordings(view, token) {
  view.innerHTML = `
    <div class="page wide">
      <h1>Aufnahmen</h1>
      <p class="lead"><span>Im TV-Programm eine Sendung auswählen und „● Aufnehmen“ wählen.</span>
        <span>Beim Fernsehen nimmt ▶ Optionen → Aufnehmen die laufende Sendung auf.</span></p>
      <div id="rec-active"></div>
      <h2>Fertige Aufnahmen</h2>
      <div class="list" id="rec-done"><div class="row static"><span class="spinner"></span></div></div>
      <h2>Speicherort</h2>
      <div class="list" id="rec-where"></div>
    </div>`;
  let st = null, last = "";

  const when = ts => `${dayLabel(ts)}, ${hhmm(ts)}`;

  function draw() {
    if (token !== renderToken || !st) return;
    const key = Nav.current && Nav.current.dataset.key;
    const active = st.schedule.filter(i => i.status !== "failed");
    const failed = st.schedule.filter(i => i.status === "failed");
    $("#rec-active").innerHTML = (active.length ? `<h2>Läuft &amp; geplant</h2><div class="list">${active.map((i, n) => `
        <button class="row nav" data-key="ra-${n}" data-id="${esc(i.id)}">
          <span class="icon">${i.status === "recording" ? '<i class="rec-dot big"></i>' : ICON.update}</span>
          <span class="main"><div class="label">${esc(i.title)}</div>
            <div class="desc">${recL(esc(i.channel) + " · " + when(i.start) + " – " + hhmm(i.stop) + " Uhr")}</div></span>
          <span class="value">${i.status === "recording" ? '<span class="badge rec">AUFNAHME</span>' : "Geplant"}</span></button>`).join("")}</div>` : "")
      + (failed.length ? `<h2>Nicht geklappt</h2><div class="list">${failed.map((i, n) => `
        <button class="row nav" data-key="rf-${n}" data-id="${esc(i.id)}">
          <span class="icon">${ICON.warn}</span>
          <span class="main"><div class="label">${esc(i.title)}</div>
            <div class="desc">${recL(esc(i.channel) + " · " + when(i.start))} · ${esc(i.error || "Fehler")}</div></span>
          <span class="value">Entfernen</span></button>`).join("")}</div>` : "");

    $("#rec-done").innerHTML = st.recordings.length ? st.recordings.map((r, n) => `
      <div class="rec-item">
        <button class="row nav" data-key="rd-${n}" data-n="${n}">
          <span class="icon">${r.recording ? '<i class="rec-dot big"></i>' : ICON.video}</span>
          <span class="main"><div class="label">${esc(r.title)}</div>
            <div class="desc">${recL(esc(r.channel) + (r.channel ? " · " : "") + when(r.start) + (r.stop ? " · " + fmtDur(r.stop - r.start) : "") + " · " + fmtBytes(r.size) + " · " + esc(r.where))}</div></span>
          <span class="value">${r.recording ? '<span class="badge rec">LÄUFT</span>' : "Abspielen"}</span></button>
        <button class="btn small nav" data-key="rx-${n}" data-del="${n}">Löschen</button>
      </div>`).join("") : `<div class="row static"><span class="icon">${ICON.video}</span><span class="main">
        <div class="label">Noch keine Aufnahmen</div><div class="desc">Im TV-Programm eine Sendung auswählen und „● Aufnehmen“ wählen.</div></span></div>`;

    const t = st.targets.find(x => x.id === st.target);
    const prefName = st.pref === "auto" ? "Automatisch" : (st.targets.find(x => x.id === st.pref) || {}).name || st.pref;
    $("#rec-where").innerHTML = valueRow("rec-target", ICON.usb, "Aufnahmen speichern auf",
      (t ? `Gerade: ${esc(t.name)} · ${fmtBytes(t.free)} frei` : "Kein Speicher gefunden") + " · Automatisch nimmt einen USB-Stick, wenn einer steckt",
      esc(prefName));

    view.querySelectorAll("#rec-active [data-id]").forEach(el => el.addEventListener("click", async () => {
      const it = st.schedule.find(i => i.id === el.dataset.id);
      if (!it) return;
      const q = it.status === "recording" ? ["Aufnahme beenden?", "Das bisher Aufgenommene bleibt erhalten.", "Beenden"]
        : it.status === "failed" ? null : ["Geplante Aufnahme löschen?", it.title, "Löschen"];
      if (q && !await confirmDialog(q[0], q[1], q[2], "danger")) return;
      try { st = await API.post("/api/rec/cancel", { id: it.id }); last = ""; draw(); } catch (e) { toast(e.message, "error"); }
    }));
    view.querySelectorAll("#rec-done [data-n]").forEach(el => el.addEventListener("click", () => {
      const r = st.recordings[+el.dataset.n];
      location.href = `/player.html?src=${encodeURIComponent(r.src)}&path=${encodeURIComponent(r.path)}`;
    }));
    view.querySelectorAll("#rec-done [data-del]").forEach(el => el.addEventListener("click", async () => {
      const r = st.recordings[+el.dataset.del];
      if (!await confirmDialog("Aufnahme löschen?", r.title, "Löschen", "danger")) return;
      try { st = await API.post("/api/rec/delete", { src: r.src, path: r.path }); last = ""; draw(); toast("Aufnahme gelöscht"); }
      catch (e) { toast(e.message, "error"); }
    }));
    $("#rec-target").addEventListener("click", async () => {
      const opts = ["auto"].concat(st.targets.map(x => x.id));
      const next = opts[(opts.indexOf(st.pref) + 1) % opts.length];
      try { st = await API.post("/api/rec/target", { pref: next }); last = ""; draw(); } catch (e) { toast(e.message, "error"); }
    });
    const again = key && view.querySelector(`[data-key="${key}"]`);
    if (again) Nav.focus(again, false); else Nav.restore();
  }

  async function load() {
    try {
      const r = await API.get("/api/rec");
      const j = JSON.stringify(r);
      if (j === last) return;
      last = j; st = r; draw();
    } catch (e) { toast(e.message, "error"); }
  }
  load();
  pageTimers.push(setInterval(load, 4000));
}
