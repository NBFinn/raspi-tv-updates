/* Display diagnosis in normal TV settings; no admin credential in the browser. */
"use strict";

function renderRoundDisplays(view, token) {
  view.innerHTML = `<div class="page wide round-settings">
    <button class="btn nav" data-key="round-back" data-go="#/settings">Zurück zu Einstellungen</button>
    <h1>Runde Displays</h1>
    <p class="lead">Display bleibt leer? Prüfe die Anschlüsse und den Display-Dienst mit einem Klick.</p>
    <div class="round-overview">
      <div><span class="round-number">1</span><strong>Uhr & Albumcover</strong></div>
      <div><span class="round-number">2</span><strong>Lautstärkering</strong></div>
    </div>
    <section class="round-test-panel">
      <h2>Helligkeit</h2>
      <p>Dunkelt das Bild beider runden Displays ab. Die Beleuchtung selbst lässt sich bei diesen Platinen nicht regeln.</p>
      <div class="round-actions round-brightness">
        <button class="btn nav" data-key="rd-bright-down" id="rd-bright-down" aria-label="Dunkler">− Dunkler</button>
        <strong id="rd-bright-value" role="status" aria-live="polite"></strong>
        <button class="btn nav" data-key="rd-bright-up" id="rd-bright-up" aria-label="Heller">+ Heller</button>
      </div>
    </section>
    <section class="round-test-panel">
      <h2>Aussehen</h2>
      <p id="rd-hw">Anschluss wird geprüft …</p>
      <p>Die Farben folgen deinem Design und Hintergrundbild, bei Musik dem Albumcover. Beim Einschalten zeigen beide Displays eine Startanimation; Seitenwechsel, Ringe und Uhr sind animiert. Für flüssige Seitenwechsel die Übertragung auf 16 MHz oder mehr stellen – bei Bildfehlern zurück auf 4 MHz.</p>
      <div class="round-actions">
        <button class="btn nav" data-key="rd-colors" id="rd-colors"></button>
        <button class="btn nav" data-key="rd-intro" id="rd-intro"></button>
        <button class="btn nav" data-key="rd-motion" id="rd-motion"></button>
        <button class="btn nav" data-key="rd-clock" id="rd-clock"></button>
        <button class="btn nav" data-key="rd-vu" id="rd-vu"></button>
        <button class="btn nav" data-key="rd-pages" id="rd-pages">Seiten & Wechsel</button>
        <button class="btn nav" data-key="rd-speed" id="rd-speed"></button>
        <button class="btn nav" data-key="rd-intro-play" id="rd-intro-play">Startanimation jetzt zeigen</button>
        <button class="btn nav" data-key="rd-teensy-flash" id="rd-teensy-flash" hidden>Teensy-Firmware neu einspielen</button>
      </div>
    </section>
    <section class="round-test-panel">
      <h2>Display auswählen und testen</h2>
      <p>Wähle das Display, das leer bleibt. Der Test startet es auf denselben Pins neu und zeigt langsamer seine Nummer mit Farbfeldern. Nach 30 Sekunden kehrt die normale Anzeige zurück. Das andere Display und Musik laufen weiter.</p>
      <div class="round-actions">
        <button class="btn primary nav" data-key="rd-test-start-1" id="rd-test-start-1" disabled>Display 1 testen · Uhr / Albumcover</button>
        <button class="btn nav" data-key="rd-test-start-2" id="rd-test-start-2" disabled>Display 2 testen · Lautstärkering</button>
        <button class="btn nav" data-key="rd-test-stop" id="rd-test-stop" disabled>Test beenden</button>
      </div>
      <p id="rd-test-status" role="status" aria-live="polite">Test ist noch nicht gestartet.</p>
    </section>
    <p id="rd-status" role="status" aria-live="polite">Diagnosestatus wird geladen …</p>
    <div class="round-actions">
      <button class="btn primary nav" data-key="rd-start" id="rd-start" disabled>Display-Diagnose starten</button>
      <button class="btn nav" data-key="rd-usb" id="rd-usb" disabled>Bericht auf USB speichern</button>
      <button class="btn nav" data-key="rd-download" id="rd-download" disabled>Bericht herunterladen</button>
      <button class="btn nav" data-key="rd-show" id="rd-show" disabled aria-expanded="false">Bericht ansehen</button>
    </div>
    <div id="rd-usb-targets" class="list" hidden></div>
    <p id="rd-export-status" role="status" aria-live="polite"></p>
    <pre id="rd-report" hidden></pre>
    <p class="round-note">Die Diagnose liest nur den Zustand aus. Musik und Displays laufen währenddessen weiter. Deine GPIO-Belegung bleibt unverändert.</p>
  </div>`;
  const find = id => view.querySelector('#rd-' + id);
  let report = '', running = false, busy = true, polling = false, exporting = false;
  let test = {phase:'idle', active:false}, testBusy = false;
  const current = () => token === renderToken;
  async function request(action, extra = {}) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), ['usb', 'export'].includes(action) ? 70000 : 20000);
    try {
      const response = await fetch('/api/round-displays', {
        method: 'POST', headers: {'Content-Type': 'application/json', 'X-Raspi-TV': '1'},
        body: JSON.stringify({action, ...extra}), signal: controller.signal
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Display-Diagnose fehlgeschlagen.');
      return data;
    } catch (error) {
      if (error.name === 'AbortError') throw new Error('Keine Antwort erhalten. Bitte erneut versuchen.');
      throw error;
    } finally { clearTimeout(timeout); }
  }
  function controls() {
    find('start').disabled = busy || running || exporting;
    for (const id of ['usb', 'download', 'show']) find(id).disabled = busy || running || exporting || !report;
    for (const number of [1, 2]) find('test-start-' + number).disabled = busy || testBusy || test.active;
    find('test-stop').disabled = testBusy || !test.active || test.phase === 'stopping';
    Nav.refocus();
  }
  function showTest(data) {
    test = data || {phase:'idle', active:false};
    const number = test.display === 1 ? 1 : 2;
    const content = number === 1 ? 'Uhr oder Albumcover' : 'Lautstärkering';
    const messages = {
      idle:'Test ist noch nicht gestartet.',
      pending:'Display ' + number + ' wird neu gestartet. Warte auf die Bestätigung des Display-Dienstes …',
      running:'Testbild für Display ' + number + ' gesendet · noch ' + test.remaining + ' Sekunden. Siehst du die große ' + number + ' und die Farbfelder?',
      stopping:'Display ' + number + ': ' + content + ' wird wiederhergestellt …',
      finished:'Test beendet · Display ' + number + '. Bitte prüfe, ob die große ' + number + ' und danach ' + content + ' sichtbar waren.',
      error:'Test für Display ' + number + ' fehlgeschlagen: ' + (test.error || 'Bitte erneut versuchen oder eine Diagnose starten.')
    };
    find('test-status').textContent = messages[test.phase] || messages.error;
  }
  async function changeTest(action, extra = {}) {
    if (testBusy) return;
    testBusy = true; controls();
    try {
      const data = await request(action, extra);
      if (current()) showTest(data);
    } catch (error) { if (current()) find('test-status').textContent = error.message; }
    finally { if (current()) { testBusy = false; controls(); } }
  }
  let brightness = Number.isInteger(state.config.round_brightness) ? state.config.round_brightness : 100, brightBusy = false;
  function showBrightness() {
    find('bright-value').textContent = brightness + ' %';
    find('bright-down').disabled = brightBusy || brightness <= 10;
    find('bright-up').disabled = brightBusy || brightness >= 100;
  }
  async function changeBrightness(step) {
    const next = Math.min(100, Math.max(10, brightness + step));
    if (next === brightness || brightBusy) return;
    brightBusy = true; showBrightness();
    let failed = false;
    try {
      state.config = await API.post('/api/config', {round_brightness: next});
      brightness = next;
    } catch (error) { failed = true; }
    brightBusy = false;
    if (!current()) return;
    showBrightness();
    if (failed) find('bright-value').textContent = brightness + ' % · Speichern fehlgeschlagen';
    Nav.refocus();
  }
  function showLook() {
    find('colors').textContent = 'Farben: ' + (state.config.round_colors === 'classic' ? 'Klassisch Türkis' : 'Wie das Design');
    find('intro').textContent = 'Startanimation: ' + (state.config.round_intro === false ? 'Aus' : 'An');
    if (hwMode === 'teensy') {
      const t = [15, 24, 30, 40, 60].includes(state.config.round_teensy_mhz) ? state.config.round_teensy_mhz : 30;
      find('speed').textContent = 'Übertragung (Teensy): ' + t + ' MHz' + (t === 30 ? ' (Standard)' : '');
    } else {
      const mhz = [4, 8, 16, 32].includes(state.config.round_speed) ? state.config.round_speed : 4;
      find('speed').textContent = 'Übertragung: ' + mhz + ' MHz' + (mhz === 4 ? ' (sicher)' : mhz >= 16 ? ' (flüssig)' : '');
    }
    find('motion').textContent = 'Animationen: ' + (state.config.round_motion === 'off' ? 'Aus' : 'An');
    find('clock').textContent = 'Uhr: ' + CLOCKS[[0, 1, 2, 3].includes(state.config.round_clock) ? state.config.round_clock : 0];
    find('vu').textContent = 'VU-Meter: ' + VUS[[0, 1, 2].includes(state.config.round_vu) ? state.config.round_vu : 0];
    find('clock').hidden = find('vu').hidden = find('pages').hidden = hwMode !== 'teensy';     // nur mit Teensy
  }
  const CLOCKS = ['Analog', 'Radar', 'Retro-Ziffern', 'Kreisende Punkte'], VUS = ['Aus', 'Als eigene Seite', 'Immer bei Musik'];
  async function saveLook(patch) {
    try { state.config = await API.post('/api/config', patch); } catch (error) { toast(error.message, 'error'); }
    if (current()) showLook();
  }
  find('colors').onclick = () => saveLook({round_colors: state.config.round_colors === 'classic' ? 'design' : 'classic'});
  let hwMode = '';
  find('speed').onclick = () => {
    if (hwMode === 'teensy') {
      const tl = [15, 24, 30, 40, 60], tc = tl.includes(state.config.round_teensy_mhz) ? state.config.round_teensy_mhz : 30;
      const tn = tl[(tl.indexOf(tc) + 1) % tl.length];
      saveLook({round_teensy_mhz: tn});
      toast(`Teensy-Übertragung: ${tn} MHz – bei Streifen oder Bildfehlern niedriger stellen`, 'ok', 6000);
      return;
    }
    const list = [4, 8, 16, 32], cur = list.includes(state.config.round_speed) ? state.config.round_speed : 4;
    const next = list[(list.indexOf(cur) + 1) % list.length];
    saveLook({round_speed: next});
    toast(next === 4 ? 'Übertragung: 4 MHz (sicher)' : `Übertragung: ${next} MHz – bei Streifen oder Bildfehlern wieder zurückstellen`, 'ok', 6000);
  };
  find('motion').onclick = () => saveLook({round_motion: state.config.round_motion === 'off' ? 'full' : 'off'});
  find('intro').onclick = () => saveLook({round_intro: state.config.round_intro === false});
  find('pages').onclick = () => RoundPages.open();
  find('clock').onclick = () => saveLook({round_clock: (([0, 1, 2, 3].includes(state.config.round_clock) ? state.config.round_clock : 0) + 1) % 4});
  find('vu').onclick = () => {
    const next = (([0, 1, 2].includes(state.config.round_vu) ? state.config.round_vu : 0) + 1) % 3;
    saveLook({round_vu: next});
    if (next) toast('VU-Meter zeigen den Ton, den der Raspberry Pi abspielt – links und rechts je ein Display', 'ok', 6000);
  };
  find('teensy-flash').onclick = async () => {
    if (!await confirmDialog('Firmware neu einspielen?', 'Der Teensy startet dabei einmal neu. Die Displays sind etwa 20 Sekunden aus.', 'Einspielen')) return;
    try { await API.post('/api/round-displays/teensy-flash', {}); toast('Firmware wird eingespielt …', 'ok'); }
    catch (error) { toast(error.message, 'error'); }
  };
  find('intro-play').onclick = async () => {
    try { await API.post('/api/round-display/intro', {}); toast('Startanimation läuft auf den Displays', 'ok'); }
    catch (error) { toast(error.message, 'error'); }
  };
  showLook();
  // Automatische Teensy-Erkennung: was der Pi gerade an USB sieht
  function scanText(scan) {
    if (!scan || !scan.fresh) return 'Keine runden Displays gefunden. (Teensy-Suche läuft nach dem nächsten Neustart automatisch.)';
    if (scan.halfkay) return 'Teensy im Programmiermodus gefunden – die Firmware wird automatisch eingespielt …';
    if (scan.port) return 'Teensy gefunden an ' + scan.port + ' – Display-Dienst startet …';
    return 'Kein Teensy gefunden. Der Pi sucht alle 3 Sekunden an allen USB-Anschlüssen. Serielle USB-Geräte: '
      + (scan.ports && scan.ports.length ? scan.ports.join(', ') : 'keine') + '. Tipp: USB-Kabel mit Datenleitung verwenden (reine Ladekabel gehen nicht).';
  }
  API.get('/api/round-displays/hardware').then(h => {
    if (!current()) return;
    hwMode = h.mode;
    find('teensy-flash').hidden = h.mode !== 'teensy';
    showLook();
    find('hw').textContent = h.mode === 'teensy'
      ? (h.flashing ? 'Teensy 4.1: neue Firmware ' + h.flashing + ' wird eingespielt …'
        : 'Angeschlossen über Teensy 4.1 (USB) · Firmware ' + (h.firmware || '?') + ' – Animationen werden auf dem Teensy gezeichnet. Firmware-Updates kommen automatisch mit Raspi-TV-Updates.'
          + (h.resets ? ' ⚠ Der Teensy ist ' + h.resets + '-mal neu gestartet' + (h.reset ? ' (Grund: ' + h.reset + ')' : '') + '.' : '')
          + (h.power && (h.power.now || h.power.since_boot) ? ' ⚠ Der Pi meldet Unterspannung – das Netzteil ist zu schwach, dadurch startet auch der Teensy neu.' : '')
          + (h.crash ? ' Absturzbericht: ' + h.crash.slice(0, 160) : ''))
      : h.mode === 'gpio' ? 'Angeschlossen direkt an den GPIO-Pins des Raspberry Pi.' : scanText(h.scan);
  }).catch(() => { if (current()) find('hw').textContent = ''; });
  find('bright-down').onclick = () => changeBrightness(-10);
  find('bright-up').onclick = () => changeBrightness(10);
  showBrightness();
  for (const number of [1, 2]) find('test-start-' + number).onclick = () => changeTest('test-start', {display:number});
  find('test-stop').onclick = () => changeTest('test-stop');
  async function refresh() {
    if (polling || !current()) return;
    polling = true;
    try {
      const data = await request('status');
      if (!current()) return;
      if (!testBusy) showTest(data.test);
      running = data.running;
      report = !running && typeof data.report === 'string' ? data.report : '';
      find('report').textContent = report;
      find('status').textContent = running ? 'Display-Diagnose läuft … Du kannst diese Seite verlassen und später zurückkommen.'
        : data.error ? 'Diagnose fehlgeschlagen: ' + data.error
        : report ? 'Diagnose abgeschlossen' + (data.created ? ' · ' + data.created : '')
        : 'Bereit. Starte die Diagnose, wenn ein Display nicht richtig funktioniert.';
    } catch (error) {
      if (!current()) return;
      running = false;
      find('status').textContent = error.message;
    } finally {
      polling = false;
      if (current()) { busy = false; controls(); }
    }
  }
  find('start').onclick = async () => {
    if (busy || running || exporting) return;
    busy = true; report = ''; controls();
    find('report').textContent = ''; find('report').hidden = true;
    find('show').setAttribute('aria-expanded', 'false'); find('show').textContent = 'Bericht ansehen';
    find('usb-targets').hidden = true; find('usb-targets').replaceChildren();
    find('export-status').textContent = '';
    find('status').textContent = 'Display-Diagnose wird gestartet …';
    try { await request('start'); if (current()) await refresh(); }
    catch (error) { if (current()) find('status').textContent = error.message; }
    finally { if (current()) { busy = false; controls(); } }
  };
  find('show').onclick = () => {
    find('report').hidden = !find('report').hidden;
    find('show').setAttribute('aria-expanded', String(!find('report').hidden));
    find('show').textContent = find('report').hidden ? 'Bericht ansehen' : 'Bericht ausblenden';
  };
  find('download').onclick = () => {
    const link = document.createElement('a');
    const url = URL.createObjectURL(new Blob(['\ufeff' + report], {type: 'text/plain;charset=utf-8'}));
    link.href = url; link.download = 'raspi-tv-display-diagnose.txt'; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  find('usb').onclick = async () => {
    exporting = true; controls();
    const targets = find('usb-targets'); targets.replaceChildren(); targets.hidden = true;
    find('export-status').textContent = 'USB-Sticks werden gesucht …';
    try {
      const data = await request('usb'); if (!current()) return;
      find('export-status').textContent = data.drives.length ? 'Wähle den USB-Stick für das Support-Paket mit deinem Display-Bericht.'
        : 'Kein USB-Stick erkannt. Bitte einstecken und erneut „Bericht auf USB speichern“ wählen.';
      if (data.errors && data.errors.length) find('export-status').textContent += ' ' + data.errors.join(' ');
      for (const drive of data.drives) {
        const button = document.createElement('button');
        button.className = 'row nav'; button.dataset.key = 'rd-target-' + drive.id;
        button.textContent = 'Auf ' + drive.name + ' speichern';
        button.onclick = async () => {
          if (exporting) return;
          exporting = true; controls();
          targets.querySelectorAll('button').forEach(b => b.disabled = true);
          find('export-status').textContent = 'Support-Paket wird gespeichert …';
          try {
            const result = await request('export', {id: drive.id}); if (!current()) return;
            find('export-status').textContent = 'Gespeichert auf ' + result.device + ': ' + result.name;
          } catch (error) { if (current()) find('export-status').textContent = error.message; }
          finally {
            if (current()) { exporting = false; targets.querySelectorAll('button').forEach(b => b.disabled = false); controls(); }
          }
        };
        targets.appendChild(button);
      }
      targets.hidden = !data.drives.length;
    } catch (error) { if (current()) find('export-status').textContent = error.message; }
    finally { if (current()) { exporting = false; controls(); } }
  };
  refresh();
  pageTimers.push(setInterval(() => { if ((running || test.active) && !busy && !testBusy) refresh(); }, 1000));
}
