/* Raspi-TV OS – App Store
 *
 * Web-Apps: offizielle Web-Versionen der Dienste, laufen wie die vorinstallierten Apps
 *           im Vollbild (Home-Taste bringt zurück). "Installieren" legt sie auf die Startseite.
 * Programme: echte Linux-Programme (Kodi, RetroArch, Moonlight). Sie werden aus den
 *           Debian-/Raspberry-Pi-Paketquellen installiert und starten im Vollbild.
 */
"use strict";

const STORE_CATS = [
  ["discover", "Entdecken"],
  ["installed", "Meine Apps"],
  ["streaming", "Filme & Serien"],
  ["mediathek", "Mediatheken"],
  ["music", "Musik & Audio"],
  ["news", "Nachrichten"],
  ["sport", "Sport"],
  ["kids", "Kinder"],
  ["knowledge", "Wissen"],
  ["games", "Spiele"],
  ["home", "Heimnetz"],
];

// sc = Kategorie im Store · cat = wo die App außerhalb des Stores erscheint
// (mediathek / streaming = eigene Seiten, more = nur Startseite)
const STORE_EXTRA = [
  // Filme & Serien
  { id: "paramount",  sc: "streaming", cat: "streaming", name: "Paramount+",   kind: "Abo · Serien & Filme",      price: "Abo", url: "https://www.paramountplus.com/", c1: "#0b4fc4", c2: "#04173d", desc: "Serien, Filme und Kinderprogramm aus dem Paramount-Universum." },
  { id: "wow",        sc: "streaming", cat: "streaming", name: "WOW",          kind: "Abo · Sky-Serien & Filme",  price: "Abo", url: "https://www.wowtv.de/", c1: "#7a1fa8", c2: "#240833", desc: "Serien, Filme und Live-Sport aus dem Sky-Angebot – monatlich kündbar." },
  { id: "appletv",    sc: "streaming", cat: "streaming", name: "Apple TV+",    kind: "Abo · Apple Originals",     price: "Abo", url: "https://tv.apple.com/de", c1: "#3a3a3c", c2: "#0d0d0e", desc: "Eigenproduktionen von Apple. Anmeldung mit deiner Apple-ID." },
  { id: "magentatv",  sc: "streaming", cat: "streaming", name: "MagentaTV",    kind: "Abo · Telekom",             price: "Abo", url: "https://web.magentatv.de/", c1: "#b0006d", c2: "#3a0024", desc: "Fernsehen, Mediathek und Serien der Telekom – Anmeldung mit deinem Telekom-Login." },
  { id: "waipu",      sc: "streaming", cat: "streaming", name: "waipu.tv",     kind: "Abo · Fernsehen",           price: "Abo", url: "https://play.waipu.tv/", c1: "#0f5f8a", c2: "#05202f", desc: "Über 200 Fernsehsender per Internet, auch private Sender in HD." },
  { id: "zattoo",     sc: "streaming", cat: "streaming", name: "Zattoo",       kind: "Fernsehen · Gratis & Abo",  price: "Gratis & Abo", url: "https://zattoo.com/", c1: "#c4401a", c2: "#45150a", desc: "Fernsehen übers Internet – öffentlich-rechtliche Sender gratis, private im Abo." },
  { id: "plutotv",    sc: "streaming", cat: "streaming", name: "Pluto TV",     kind: "Kostenlos · mit Werbung",   price: "Kostenlos", url: "https://pluto.tv/de/live-tv", c1: "#1a1a6e", c2: "#07071f", desc: "Über 100 kostenlose Themensender und Filme auf Abruf – ganz ohne Anmeldung." },
  { id: "rakuten",    sc: "streaming", cat: "streaming", name: "Rakuten TV",   kind: "Gratis-Filme & Leihen",     price: "Kostenlos & Kauf", url: "https://www.rakuten.tv/de", c1: "#9e1030", c2: "#33050f", desc: "Kostenlose Filme mit Werbung, aktuelle Filme zum Leihen oder Kaufen." },
  { id: "mubi",       sc: "streaming", cat: "streaming", name: "MUBI",         kind: "Abo · Arthouse-Kino",       price: "Abo", url: "https://mubi.com/de", c1: "#16337a", c2: "#060f26", desc: "Handverlesene Filme aus aller Welt – Klassiker, Festivalfilme und Arthouse." },
  { id: "ardplus",    sc: "streaming", cat: "streaming", name: "ARD Plus",     kind: "Abo · Klassiker der ARD",   price: "Abo", url: "https://www.ardplus.de/", c1: "#1d4f91", c2: "#0b1d36", desc: "Krimis, Serien und Kinderprogramm aus dem ARD-Archiv – Tatort-Klassiker inklusive." },
  // Mediatheken
  { id: "servustv",   sc: "mediathek", cat: "mediathek", name: "ServusTV On",  kind: "Kostenlos · Sport & Doku",  price: "Kostenlos", url: "https://www.servustv.com/", c1: "#2f5d3a", c2: "#0e1f12", desc: "Livestream und Mediathek von ServusTV: Dokus, Sport und Unterhaltung." },
  { id: "phoenix",    sc: "mediathek", cat: "mediathek", name: "phoenix",      kind: "Kostenlos · Politik & Doku",price: "Kostenlos", url: "https://www.phoenix.de/", c1: "#00507a", c2: "#001b2a", desc: "Ereignisse live, Dokumentationen und Gesprächssendungen." },
  { id: "netzkino",   sc: "mediathek", cat: "mediathek", name: "Netzkino",     kind: "Kostenlos · Filme",         price: "Kostenlos", url: "https://www.netzkino.de/", c1: "#8a1c1c", c2: "#2b0808", desc: "Hunderte Spielfilme kostenlos mit Werbung – Action, Horror, Komödie." },
  { id: "vimeo",      sc: "mediathek", cat: "mediathek", name: "Vimeo",        kind: "Videos",                    price: "Kostenlos", url: "https://vimeo.com/", c1: "#0d5f84", c2: "#04202d", desc: "Kurzfilme, Musikvideos und Videos von Filmschaffenden." },
  // Musik & Audio
  { id: "ytmusic",    sc: "music", cat: "more", name: "YouTube Music",  kind: "Musik · Gratis & Abo",     price: "Gratis & Abo", url: "https://music.youtube.com/", c1: "#a5101a", c2: "#360507", desc: "Musik, Alben und Musikvideos – kostenlos mit Werbung oder im Abo." },
  { id: "deezer",     sc: "music", cat: "more", name: "Deezer",         kind: "Musik · Abo",              price: "Abo", url: "https://www.deezer.com/de/", c1: "#6d28d9", c2: "#220a47", desc: "Über 100 Millionen Titel, Playlists und Podcasts." },
  { id: "tidal",      sc: "music", cat: "more", name: "TIDAL",          kind: "Musik · Abo",              price: "Abo", url: "https://listen.tidal.com/", c1: "#262626", c2: "#000000", desc: "Musik in hoher Klangqualität, kuratierte Playlists und Videos." },
  { id: "amazonmusic",sc: "music", cat: "more", name: "Amazon Music",   kind: "Musik · Prime & Abo",      price: "Abo", url: "https://music.amazon.de/", c1: "#0b5c73", c2: "#031f27", desc: "Mit Prime oder Music Unlimited – Alben, Playlists und Podcasts." },
  { id: "applemusic", sc: "music", cat: "more", name: "Apple Music",    kind: "Musik · Abo",              price: "Abo", url: "https://music.apple.com/de/", c1: "#b3123c", c2: "#3b0614", desc: "Die Apple-Musikbibliothek im Browser. Anmeldung mit deiner Apple-ID." },
  { id: "soundcloud", sc: "music", cat: "more", name: "SoundCloud",     kind: "Musik · Kostenlos",        price: "Kostenlos", url: "https://soundcloud.com/", c1: "#b3410e", c2: "#3a1504", desc: "Neue Künstler, DJ-Sets und Remixe." },
  { id: "spotifyconnect", sc: "music", cat: "more", service: "spotify", name: "Spotify Connect", kind: "Raspi-TV als Spotify-Lautsprecher", price: "Kostenlos · Spotify Premium", c1: "#11733a", c2: "#05260f", size: "ca. 10 MB",
    desc: "Raspi-TV erscheint in der Spotify-App am Handy als Lautsprecher. Musik am Handy aussuchen, auf „Geräte“ tippen, „Raspi-TV“ wählen – der Fernseher spielt, das Handy bleibt Fernbedienung. Titel und Cover erscheinen unten rechts auf dem Bildschirm." },
  { id: "ardaudiothek",sc:"music", cat: "more", name: "ARD Audiothek",  kind: "Hörspiele & Podcasts",     price: "Kostenlos", url: "https://www.ardaudiothek.de/", c1: "#1d4f91", c2: "#0b1d36", desc: "Hörspiele, Krimis, Podcasts und Dokus aller ARD-Sender." },
  { id: "radiode",    sc: "music", cat: "more", name: "radio.de",       kind: "Tausende Radiosender",     price: "Kostenlos", url: "https://www.radio.de/", c1: "#0f6b5c", c2: "#04241f", desc: "Radiosender aus aller Welt und Podcasts. Für die wichtigsten deutschen Sender gibt es auch die Radio-Kachel auf der Startseite." },
  // Nachrichten
  { id: "tagesschau", sc: "news", cat: "mediathek", name: "tagesschau",  kind: "Nachrichten der ARD",      price: "Kostenlos", url: "https://www.tagesschau.de/", c1: "#0a3a6b", c2: "#031426", desc: "Aktuelle Nachrichten, Sendungen und der Livestream von tagesschau24." },
  { id: "zdfheute",   sc: "news", cat: "mediathek", name: "ZDFheute",    kind: "Nachrichten des ZDF",      price: "Kostenlos", url: "https://www.zdfheute.de/", c1: "#b3541a", c2: "#3a1a07", desc: "heute, heute journal und aktuelle Berichte." },
  { id: "ntv",        sc: "news", cat: "mediathek", name: "n-tv",        kind: "Nachrichten",              price: "Kostenlos", url: "https://www.n-tv.de/", c1: "#a01822", c2: "#33070b", desc: "Nachrichten, Börse und Videos von n-tv." },
  { id: "welt",       sc: "news", cat: "mediathek", name: "WELT",        kind: "Nachrichten",              price: "Kostenlos", url: "https://www.welt.de/", c1: "#123a5c", c2: "#06131f", desc: "Nachrichten und Dokumentationen von WELT." },
  { id: "dw",         sc: "news", cat: "mediathek", name: "DW",          kind: "Deutsche Welle",           price: "Kostenlos", url: "https://www.dw.com/de/", c1: "#05507f", c2: "#021b2b", desc: "Nachrichten und Reportagen aus aller Welt – auch in vielen anderen Sprachen." },
  { id: "euronews",   sc: "news", cat: "mediathek", name: "euronews",    kind: "Europa-Nachrichten",       price: "Kostenlos", url: "https://de.euronews.com/live", c1: "#1f3d73", c2: "#0a1426", desc: "Europäische Nachrichten rund um die Uhr im Livestream." },
  // Sport
  { id: "dazn",       sc: "sport", cat: "streaming", name: "DAZN",            kind: "Abo · Live-Sport",    price: "Abo", url: "https://www.dazn.com/", c1: "#2b2b2b", c2: "#050505", desc: "Fußball, Basketball, Boxen und mehr live und auf Abruf." },
  { id: "magentasport",sc:"sport", cat: "streaming", name: "MagentaSport",    kind: "Abo · Live-Sport",    price: "Abo", url: "https://www.magentasport.de/", c1: "#b0006d", c2: "#3a0024", desc: "3. Liga, Eishockey, Basketball und Frauenfußball live." },
  { id: "sportschau", sc: "sport", cat: "mediathek", name: "Sportschau",      kind: "Kostenlos · ARD",     price: "Kostenlos", url: "https://www.sportschau.de/", c1: "#0a3a6b", c2: "#031426", desc: "Livestreams, Zusammenfassungen und Ergebnisse der ARD." },
  { id: "sportdeutschland",sc:"sport",cat:"mediathek",name: "Sportdeutschland.TV", kind: "Kostenlos & Abo", price: "Gratis & Abo", url: "https://sportdeutschland.tv/", c1: "#14532d", c2: "#051c0f", desc: "Live-Sport abseits des Fußballs: Handball, Volleyball, Tischtennis und viel mehr." },
  // Kinder
  { id: "zdftivi",    sc: "kids", cat: "mediathek", name: "ZDFtivi",           kind: "Für Kinder",         price: "Kostenlos", url: "https://www.zdf.de/kinder", c1: "#b3541a", c2: "#3a1a07", desc: "Kinderserien und Wissenssendungen aus dem ZDF – ohne Werbung." },
  { id: "toggo",      sc: "kids", cat: "mediathek", name: "TOGGO",             kind: "Für Kinder",         price: "Kostenlos", url: "https://www.toggo.de/", c1: "#c2185b", c2: "#3d0720", desc: "Serien und Videos von Super RTL." },
  { id: "maus",       sc: "kids", cat: "mediathek", name: "Die Sendung mit der Maus", kind: "Lach- und Sachgeschichten", price: "Kostenlos", url: "https://www.wdrmaus.de/", c1: "#a64b00", c2: "#361800", desc: "Lach- und Sachgeschichten, Filme und Spiele mit der Maus." },
  { id: "kikaninchen",sc: "kids", cat: "mediathek", name: "KiKANiNCHEN",       kind: "Für Vorschulkinder", price: "Kostenlos", url: "https://www.kikaninchen.de/", c1: "#2e7d32", c2: "#0d2a0f", desc: "Videos, Lieder und Spiele für die Kleinsten – vom KiKA." },
  { id: "youtubekids",sc: "kids", cat: "mediathek", name: "YouTube Kids",      kind: "Videos für Kinder",  price: "Kostenlos", url: "https://www.youtubekids.com/", c1: "#b3121b", c2: "#3a0508", desc: "Kindgerechte Videos mit Elternbereich." },
  // Wissen
  { id: "ted",        sc: "knowledge", cat: "mediathek", name: "TED",          kind: "Vorträge",           price: "Kostenlos", url: "https://www.ted.com/", c1: "#b3141c", c2: "#360609", desc: "Tausende Vorträge zu Wissenschaft, Technik und Gesellschaft – oft mit deutschen Untertiteln." },
  { id: "planetschule",sc:"knowledge", cat: "mediathek", name: "Planet Schule", kind: "Wissen von SWR & WDR", price: "Kostenlos", url: "https://www.planet-schule.de/", c1: "#00566b", c2: "#001d24", desc: "Dokus und Erklärfilme für Schule und Neugierige." },
  { id: "ardalpha",   sc: "knowledge", cat: "mediathek", name: "ARD alpha",    kind: "Bildung & Wissen",   price: "Kostenlos", url: "https://www.ardalpha.de/", c1: "#1d4f91", c2: "#0b1d36", desc: "Bildungsfernsehen: Wissen, Geschichte, Sprachen." },
  { id: "nasaplus",   sc: "knowledge", cat: "mediathek", name: "NASA+",        kind: "Raumfahrt · Englisch", price: "Kostenlos", url: "https://plus.nasa.gov/", c1: "#0b3d91", c2: "#04163a", desc: "Raketenstarts live, Dokus und Serien der NASA (auf Englisch)." },
  // Spiele
  { id: "retroarch",  sc: "games", cat: "more", native: true, name: "RetroArch", kind: "Programm · Retro-Spiele", price: "Kostenlos", c1: "#3c3c8a", c2: "#11112b", size: "ca. 150 MB",
    desc: "Spielt deine eigenen Spiele klassischer Konsolen (NES, Game Boy, GBA, SNES, Mega Drive …). Spiele-Dateien vom USB-Stick laden – am besten mit Gamepad. Beenden über das RetroArch-Menü oder die Home-Taste." },
  { id: "moonlight",  sc: "games", cat: "more", native: true, beta: true, name: "Moonlight", kind: "Programm · PC-Spiele streamen", price: "Kostenlos", c1: "#3b4a5c", c2: "#10161d", size: "ca. 60 MB",
    desc: "Spiele vom Gaming-PC auf den Fernseher streamen (NVIDIA GameStream oder Sunshine). Wird aus der offiziellen Moonlight-Paketquelle installiert. Gamepad empfohlen." },
  { id: "geforcenow", sc: "games", cat: "more", beta: true, name: "GeForce NOW", kind: "Cloud-Gaming · Beta", price: "Gratis & Abo", url: "https://play.geforcenow.com/", c1: "#3f6b00", c2: "#132100", desc: "Spiele aus deiner Steam-/Epic-Bibliothek in der Cloud. Läuft im Browser – ob der Dienst den Pi akzeptiert, ist nicht garantiert. Gamepad empfohlen." },
  { id: "xcloud",     sc: "games", cat: "more", beta: true, name: "Xbox Cloud Gaming", kind: "Cloud-Gaming · Beta", price: "Abo", url: "https://www.xbox.com/de-DE/play", c1: "#107c10", c2: "#052905", desc: "Mit Game Pass Ultimate Xbox-Spiele streamen. Läuft im Browser – nicht offiziell für den Pi. Gamepad nötig." },
  // Medien & Heimnetz
  { id: "terminal",   sc: "home", cat: "more", local: true, name: "Terminal", kind: "Werkzeug · Kommandozeile", price: "Kostenlos", url: "/terminal.html", c1: "#2b3445", c2: "#0d1118",
    desc: "Eine echte Kommandozeile auf dem Pi, angemeldet als Wartungsbenutzer „admin“ (sudo mit Passwort raspitv). Tippen mit USB-Tastatur oder Handy (Fernbedienung → Tastatur). Die Sitzung läuft weiter, wenn du zur Startseite gehst." },
  { id: "kodi",       sc: "home", cat: "more", native: true, name: "Kodi", kind: "Programm · Mediacenter", price: "Kostenlos", c1: "#145a7a", c2: "#06202c", size: "ca. 300 MB",
    desc: "Das bekannte Mediacenter: Filme- und Serienbibliothek mit Covern, Netzwerkfreigaben, Erweiterungen. Bedienung mit Fernbedienung oder Gamepad – Home beendet Kodi." },
  { id: "plex",       sc: "home", cat: "more", name: "Plex",           kind: "Eigener Medienserver",     price: "Kostenlos", url: "https://app.plex.tv/", c1: "#7a5a00", c2: "#2a1f00", desc: "Filme und Serien von deinem Plex-Server – auch von unterwegs." },
  { id: "jellyfin",   sc: "home", cat: "more", name: "Jellyfin",       kind: "Eigener Medienserver",     price: "Kostenlos", c1: "#5b2a86", c2: "#1d0d2b",
    ask: { label: "Adresse deines Jellyfin-Servers", placeholder: "http://192.168.178.20:8096" }, desc: "Dein eigener, freier Medienserver. Beim Installieren gibst du die Adresse deines Servers ein." },
  { id: "homeassistant", sc: "home", cat: "more", name: "Home Assistant", kind: "Smart Home",          price: "Kostenlos", c1: "#0b5f86", c2: "#03202d",
    ask: { label: "Adresse von Home Assistant", placeholder: "http://homeassistant.local:8123" }, desc: "Licht, Heizung und Geräte deines Smart Homes auf dem Fernseher." },
  { id: "fritzbox",   sc: "home", cat: "more", name: "FRITZ!Box",      kind: "Router-Oberfläche",        price: "Kostenlos", url: "http://fritz.box/", c1: "#a3121c", c2: "#360609", desc: "Die Oberfläche deiner FRITZ!Box – z. B. für das Gäste-WLAN." },
  { id: "googlephotos", sc: "home", cat: "more", name: "Google Fotos", kind: "Fotos & Videos",          price: "Kostenlos", url: "https://photos.google.com/", c1: "#1a5fb4", c2: "#081f3d", desc: "Deine Fotos und Alben groß auf dem Fernseher." },
  { id: "web",        sc: "home", cat: "more", name: "Internet",       kind: "Webseiten öffnen",         price: "Kostenlos", url: "https://www.google.de/", c1: "#2a3446", c2: "#0d1119", desc: "Suchen und beliebige Webseiten öffnen – mit Bildschirmtastatur und Maus-Modus (grüne Taste). Tipp: Unter Einstellungen → Apps gibt es einen Werbeblocker." },
];

// Die vorinstallierten Apps gehören auch in den Store (dort ein-/ausblendbar)
const BUILTIN_SC = { ard: "mediathek", zdf: "mediathek", arte: "mediathek", "3sat": "mediathek", kika: "kids", joyn: "mediathek",
  youtube: "mediathek", twitch: "mediathek", netflix: "streaming", prime: "streaming", disney: "streaming", rtlplus: "streaming",
  crunchyroll: "streaming", spotify: "music" };
const STORE = [
  ...APPS.map(a => ({ ...a, sc: BUILTIN_SC[a.id] || a.cat, builtin: true,
    price: a.cat === "streaming" && a.id !== "spotify" ? "Abo" : a.id === "spotify" ? "Gratis & Abo" : "Kostenlos",
    desc: a.id === "spotify" ? "Vorinstalliert. Das normale Spotify (auch mit kostenlosem Konto) – die Musik läuft weiter, wenn du zur Startseite gehst, eine andere App öffnest oder den Fernseher ausschaltest. Pfeile und OK zum Auswählen, CH ± für den nächsten Titel."
      : a.cat === "streaming" ? "Vorinstalliert. Läuft über die offizielle Web-Version – mit deinem eigenen Konto." : "Vorinstalliert und kostenlos." })),
  ...STORE_EXTRA,
];
const FEATURED = ["kodi", "plutotv", "retroarch"];

// ======================================================================
// Zustand: installierte Apps
// ======================================================================
const Store = {
  native: {},       // id -> { installed, running }
  job: null,

  async refresh() {
    const s = await API.get("/api/store");
    state.config.store_apps = s.installed;
    state.config.custom_apps = s.custom;
    this.native = s.native || {};
    this.job = s.job;
    return s;
  },

  // Status einer Katalog-App: "builtin" | "hidden" | "installed" | "none"
  status(a) {
    if (a.custom) return "installed";
    if (a.service) return state.config[a.service] ? "installed" : "none";
    if (a.builtin) return state.config.hidden.includes(a.id) ? "hidden" : "builtin";
    if (a.native) return (this.native[a.id] || {}).installed ? "installed" : "none";
    if (a.ask) return (state.config.custom_apps || []).some(c => c.from === a.id) ? "installed" : "none";
    return (state.config.store_apps || []).includes(a.id) ? "installed" : "none";
  },
  isInstalled(a) { const s = this.status(a); return s === "installed" || s === "builtin"; },
};

function darken(hex, f = 0.3) {
  const n = parseInt(hex.slice(1), 16);
  const c = [n >> 16, (n >> 8) & 255, n & 255].map(v => Math.round(v * f));
  return "#" + c.map(v => v.toString(16).padStart(2, "0")).join("");
}

function customToApp(c) {
  let host = c.url;
  try { host = new URL(c.url).host; } catch (_) {}
  const base = c.from && STORE.find(s => s.id === c.from);
  return { id: c.id, cat: "more", sc: base ? base.sc : "home", name: c.name, kind: base ? base.kind : host, url: c.url,
    c1: c.c1, c2: darken(c.c1), custom: true, from: c.from, price: "Eigene App",
    desc: (base ? base.desc + " " : "") + "Adresse: " + c.url };
}

// Alle Apps, die auf Startseite & Co. erscheinen (in dieser Reihenfolge)
function allApps() {
  const list = APPS.filter(a => !state.config.hidden.includes(a.id));
  for (const id of state.config.store_apps || []) {
    const a = STORE_EXTRA.find(x => x.id === id && !x.native && !x.ask);
    if (a) list.push(a);
  }
  for (const a of STORE_EXTRA) if (a.native && (Store.native[a.id] || {}).installed) list.push(a);
  for (const c of state.config.custom_apps || []) list.push(customToApp(c));
  return list;
}

function findApp(id) {
  return STORE.find(a => a.id === id) || allApps().find(a => a.id === id);
}

// ======================================================================
// Programme (Kodi & Co.) starten – die Oberfläche wartet dahinter
// ======================================================================
const NativeRun = {
  overlay: null,
  timer: null,

  async launch(app) {
    try {
      const r = await API.post("/api/native/launch", { id: app.id });
      if (r.running) this.show(app.name);
    } catch (e) { toast(e.message, "error", 6000); }
  },

  show(name) {
    if (!this.overlay) {
      const o = this.overlay = document.createElement("div");
      o.className = "overlay native-run";
      document.body.appendChild(o);
    }
    this.overlay.innerHTML = `<div class="spinner"></div><div>${esc(name)} wird gestartet …</div>
      <div class="native-hint">Zum Beenden: <b>Home</b> auf der Fernbedienung – oder in ${esc(name)} „Beenden“ wählen.</div>`;
    clearInterval(this.timer);
    this.timer = setInterval(() => this.poll(), 2000);
  },

  async poll() {
    let r;
    try { r = await API.get("/api/native"); } catch (_) { return; }
    Saver.idleSince = Date.now();
    if (r.running) return;
    clearInterval(this.timer);
    this.timer = null;
    if (this.overlay) { this.overlay.remove(); this.overlay = null; }
    Nav.refocus();
  },

  async check() {   // nach einem Neustart der Oberfläche: läuft noch ein Programm?
    try { const r = await API.get("/api/native"); if (r.running) this.show(r.name); } catch (_) {}
  },
};

// ======================================================================
// Seite: App Store
// ======================================================================
function storeBadge(a) {
  const s = Store.status(a);
  if (s === "installed" || s === "builtin") return `<span class="st-badge ok">${ICON.check}Installiert</span>`;
  if (s === "hidden") return `<span class="st-badge">Ausgeblendet</span>`;
  return `<span class="st-badge">${a.beta ? "Beta · " : ""}${esc(a.price || "")}</span>`;
}

function storeCard(a, key) {
  return `<button class="store-card nav" data-key="${key}" data-sid="${esc(a.id)}" style="--c1:${a.c1};--c2:${a.c2 || darken(a.c1)}">
    ${a.native ? `<span class="st-type">${ICON.download}Programm</span>` : ""}
    ${storeBadge(a)}
    <span class="name">${esc(a.name)}</span><span class="kind">${esc(a.kind)}</span>
  </button>`;
}

function renderStore(view, token, params) {
  let cat = params.cat === "search" && params.q ? "search" : STORE_CATS.some(c => c[0] === params.cat) ? params.cat : "discover";
  view.innerHTML = `
    <div class="page wide store">
      <div class="store-head">
        <div><h1>App Store</h1>
          <p class="lead">Neue Apps für deinen Raspi-TV – alle kostenlos zu installieren. Manche Dienste brauchen ein eigenes Abo.</p></div>
      </div>
      <div class="filters store-cats">${STORE_CATS.map(([k, l]) =>
        `<button class="chip nav ${k === cat ? "on" : ""}" data-key="sc-${k}" data-cat="${k}">${l}</button>`).join("")}</div>
      <div id="store-body"></div>
    </div>`;
  view.querySelectorAll("[data-cat]").forEach(el => el.addEventListener("click", () => {
    if (el.dataset.cat === cat) return;
    history.replaceState(null, "", "#/store/" + el.dataset.cat);
    cat = el.dataset.cat;
    view.querySelectorAll("[data-cat]").forEach(c => c.classList.toggle("on", c === el));
    draw(true);
  }));

  function bind() {
    $("#store-body").querySelectorAll("[data-sid]").forEach(el =>
      el.addEventListener("click", () => storeDetail(findApp(el.dataset.sid), redraw)));
    const add = $("#store-add");
    if (add) add.addEventListener("click", () => customAppDialog(null, redraw));
  }

  function redraw() { if (token === renderToken) draw(false); }

  function draw(animate) {
    const body = $("#store-body");
    const focusKey = Nav.current && Nav.current.dataset.key;
    if (cat === "discover") {
      const feat = FEATURED.map(id => STORE.find(a => a.id === id));
      const rows = STORE_CATS.filter(([k]) => !["discover", "installed"].includes(k)).map(([k, l]) => {
        const apps = STORE.filter(a => a.sc === k);
        return `<div class="section">${l}</div><div class="strip">${apps.map(a => storeCard(a, `d-${k}-${a.id}`)).join("")}</div>`;
      }).join("");
      body.innerHTML = `<div class="store-featured">${feat.map((a, i) => `
          <button class="feat-card nav" data-key="feat-${a.id}" data-sid="${a.id}" style="--c1:${a.c1};--c2:${a.c2};--d:${i * 70}ms">
            <span class="feat-tag">${i === 0 ? "Empfehlung" : a.native ? "Programm" : "Neu im Store"}</span>
            <span class="name">${esc(a.name)}</span>
            <span class="desc">${esc(a.desc)}</span>
            ${storeBadge(a)}
          </button>`).join("")}</div>${rows}`;
    } else if (cat === "search") {
      const words = params.q.toLowerCase().split(/\s+/).filter(Boolean);
      const hits = STORE.filter(x => words.every(w => (x.name + " " + x.kind + " " + (x.desc || "")).toLowerCase().includes(w)));
      body.innerHTML = `<div class="section">Suche: „${esc(params.q)}“ · ${hits.length} Treffer</div>
        <div class="store-grid">${hits.map(x => storeCard(x, "s-" + x.id)).join("") || '<div class="empty">Keine passende App gefunden.</div>'}</div>`;
    } else if (cat === "installed") {
      const apps = allApps();
      const hidden = APPS.filter(a => state.config.hidden.includes(a.id)).map(a => STORE.find(s => s.id === a.id));
      body.innerHTML = `<div class="store-grid">${apps.map(a => storeCard(a.custom ? a : (STORE.find(s => s.id === a.id) || a), "i-" + a.id)).join("")}
          <button class="store-card add nav" data-key="i-add" id="store-add">${ICON.plus}<span class="name">Eigene App</span><span class="kind">Beliebige Webadresse hinzufügen</span></button>
        </div>
        ${hidden.length ? `<div class="section">Ausgeblendet</div><div class="store-grid">${hidden.map(a => storeCard(a, "h-" + a.id)).join("")}</div>` : ""}`;
    } else {
      const apps = STORE.filter(a => a.sc === cat);
      const customs = (state.config.custom_apps || []).map(customToApp).filter(a => a.sc === cat && !a.from);
      body.innerHTML = `<div class="store-grid">${apps.concat(customs).map(a => storeCard(a, "c-" + a.id)).join("")}
        ${cat === "home" ? `<button class="store-card add nav" data-key="c-add" id="store-add">${ICON.plus}<span class="name">Eigene App</span><span class="kind">Beliebige Webadresse hinzufügen</span></button>` : ""}</div>`;
    }
    body.classList.toggle("entering", !!animate);
    bind();
    const again = focusKey && body.querySelector(`[data-key="${CSS.escape(focusKey)}"]`);
    if (again) Nav.focus(again, false);
    else if (animate === undefined) Nav.focus(view.querySelector(".chip.on"), false);
    else Nav.refocus();
  }

  Store.refresh().catch(() => {}).then(() => { if (token === renderToken) draw(undefined); });
}

// ======================================================================
// App-Details: installieren, öffnen, entfernen
// ======================================================================
function storeDetail(a, onChange) {
  if (!a) return;
  const s = Store.status(a);
  const installed = s === "installed" || s === "builtin";
  const catName = (STORE_CATS.find(c => c[0] === a.sc) || [, ""])[1];
  const facts = [
    ["Kategorie", catName],
    ["Art", a.service ? "Dienst im Hintergrund" : a.native ? "Programm (wird installiert)" : a.custom ? "Eigene Web-App" : "Web-App (offizielle Web-Version)"],
    ["Kosten", a.price || "–"],
    a.size ? ["Größe", a.size] : null,
    a.builtin ? ["Herkunft", "Vorinstalliert"] : null,
  ].filter(Boolean);
  const buttons = [];
  if (a.native && Store.job && Store.job.running) {
    buttons.push({ label: "Schließen" });
  } else if (installed && a.service) {
    buttons.push({ label: "Ausschalten", action: c => { c(); spotifySet(false, () => onChange && onChange()); } });
    buttons.push({ label: "Zu den Ton-Einstellungen", style: "primary", action: c => { c(); go("#/settings/sound"); } });
  } else if (installed) {
    buttons.push({ label: a.builtin ? "Ausblenden" : "Entfernen", action: c => { c(); removeApp(a, onChange); } });
    buttons.push({ label: a.native ? "Starten" : "Öffnen", style: "primary", action: c => { c(); openApp(a.id); } });
  } else {
    buttons.push({ label: "Abbrechen" });
    buttons.push({ label: s === "hidden" ? "Wieder anzeigen" : a.service ? "Einschalten" : "Installieren", style: "primary", action: c => { c(); installApp(a, onChange); } });
  }
  openModal({
    title: "",
    html: `<div class="app-detail">
        <div class="ad-head" style="--c1:${a.c1};--c2:${a.c2 || darken(a.c1)}">
          <span class="name">${esc(a.name)}</span><span class="kind">${esc(a.kind)}</span>
          ${a.beta ? '<span class="st-badge">Beta</span>' : ""}
        </div>
        <p class="ad-desc">${esc(a.desc || "")}</p>
        <dl class="ad-facts">${facts.map(([k, v]) => `<dt>${k}</dt><dd>${esc(v)}</dd>`).join("")}</dl>
        ${a.native && Store.job && Store.job.running ? `<p class="ad-note">Es läuft gerade eine andere Installation. Bitte warte, bis sie fertig ist.</p>` : ""}
        ${installed && !a.native && !a.builtin ? `<p class="ad-note">Liegt auf der Startseite unter „Apps“${a.cat === "streaming" ? " und bei „Filme &amp; Serien“" : a.cat === "mediathek" ? " und in der „Mediathek“" : ""}.</p>` : ""}
      </div>`,
    buttons,
    focus: buttons.some(b => b.style === "primary") ? ".btn.primary" : undefined,
  });
}

async function installApp(a, onChange) {
  try {
    if (a.service) {
      return spotifySet(true, () => { onChange && onChange(); });
    } else if (a.builtin) {
      state.config = await API.post("/api/config", { hidden: state.config.hidden.filter(h => h !== a.id) });
    } else if (a.native) {
      await nativeJob(a, "install");
      return;
    } else if (a.ask) {
      return customAppDialog(a, onChange);
    } else {
      await API.post("/api/store/install", { id: a.id });
      await Store.refresh();
    }
    toast(`${a.name} ist installiert – du findest die App auf der Startseite.`, "ok", 4000);
    onChange && onChange();
    storeDetail(a, onChange);
  } catch (e) { toast(e.message, "error", 6000); }
}

async function removeApp(a, onChange) {
  const what = a.builtin ? "ausblenden" : "entfernen";
  if (a.builtin && allApps().length <= 1) return toast("Mindestens eine App muss sichtbar bleiben.", "error");
  if (!await confirmDialog(`${a.name} ${what}?`,
    a.native ? `${a.name} wird vom System gelöscht. Einstellungen des Programms bleiben erhalten.`
      : a.builtin ? "Die App verschwindet von der Startseite. Im App Store kannst du sie jederzeit wieder anzeigen."
      : "Die App verschwindet von der Startseite. Deine Anmeldung beim Dienst bleibt gespeichert.",
    a.builtin ? "Ausblenden" : "Entfernen", "danger")) return;
  try {
    if (a.builtin) {
      state.config = await API.post("/api/config", { hidden: [...state.config.hidden, a.id] });
    } else if (a.native) {
      return nativeJob(a, "remove", onChange);
    } else if (a.ask) {
      for (const c of (state.config.custom_apps || []).filter(c => c.from === a.id)) await API.post("/api/store/remove", { id: c.id });
      await Store.refresh();
    } else {
      await API.post("/api/store/remove", { id: a.id });
      await Store.refresh();
    }
    toast(`${a.name} wurde ${a.builtin ? "ausgeblendet" : "entfernt"}.`, "ok");
    onChange && onChange();
  } catch (e) { toast(e.message, "error", 6000); }
}

// Programme: Installation/Entfernung mit Fortschrittsanzeige
async function nativeJob(a, action, onChange) {
  if (action === "install" && state.network && !state.network.online)
    return toast("Zum Installieren braucht Raspi-TV eine Internetverbindung.", "error", 5000);
  try { await API.post(`/api/native/${action}`, { id: a.id }); }
  catch (e) { return toast(e.message, "error", 6000); }
  const { el, close } = openModal({
    title: (action === "install" ? "Installiere " : "Entferne ") + a.name,
    html: `<div class="job">
        <div class="job-bar"><i id="job-fill"></i></div>
        <div class="job-row"><span id="job-step">Wird vorbereitet …</span><b id="job-pct">0 %</b></div>
        <p class="ad-note">Das kann ein paar Minuten dauern. Du kannst dieses Fenster schließen – die Installation läuft weiter.</p>
      </div>`,
    buttons: [{ label: "Im Hintergrund weiter" }],
  });
  const t = setInterval(async () => {
    let s;
    try { s = await Store.refresh(); } catch (_) { return; }
    const j = s.job || {};
    if (document.contains(el)) {
      $("#job-fill", el).style.width = (j.percent || 0) + "%";
      $("#job-pct", el).textContent = (j.percent || 0) + " %";
      $("#job-step", el).textContent = j.error ? "Fehler" : (j.step || "…");
    }
    if (j.running) return;
    clearInterval(t);
    if (document.contains(el)) close();
    if (j.error) { toast(j.error, "error", 9000); }
    else {
      toast(action === "install" ? `${a.name} ist installiert – du findest es auf der Startseite.` : `${a.name} wurde entfernt.`, "ok", 5000);
      if (action === "install" && route() === "store") storeDetail(a, onChange);
    }
    onChange && onChange();
    if (route() === "home") render();
  }, 1000);
}

// Eigene App: Name + Adresse (oder Server-Adresse für Jellyfin & Co.)
function customAppDialog(base, onChange) {
  const PALETTE = ["#1d4ed8", "#7c3aed", "#b91c1c", "#047857", "#b45309", "#0e7490", "#be185d", "#334155"];
  const { el, close } = openModal({
    title: base ? base.name + " einrichten" : "Eigene App hinzufügen",
    top: true,
    html: `${base ? `<p>${esc(base.ask.label)}:</p>` : "<p>Jede Webseite kann eine App werden – z. B. dein Medienserver, ein Lieblingsportal oder ein Dienst, der hier noch fehlt.</p>"}
      ${base ? "" : `<div class="field"><input class="nav" id="ca-name" data-key="ca-name" placeholder="Name, z. B. Mein NAS" maxlength="30" autocomplete="off" spellcheck="false"></div>`}
      <div class="field"><input class="nav" id="ca-url" data-key="ca-url" placeholder="${esc(base ? base.ask.placeholder : "Adresse, z. B. https://www.beispiel.de")}" autocomplete="off" spellcheck="false" inputmode="url"></div>`,
    buttons: [
      { label: "Abbrechen" },
      { label: "Hinzufügen", style: "primary", action: async () => {
        const name = base ? base.name : $("#ca-name", el).value.trim();
        const url = $("#ca-url", el).value.trim();
        const color = base ? base.c1 : PALETTE[Math.abs([...name].reduce((h, ch) => h * 31 + ch.charCodeAt(0) | 0, 7)) % PALETTE.length];
        try {
          await API.post("/api/store/custom", { name, url, color, from: base ? base.id : "" });
          await Store.refresh();
          close();
          toast(`${name} ist jetzt auf der Startseite.`, "ok", 4000);
          onChange && onChange();
        } catch (e) { toast(e.message, "error", 6000); }
      } },
    ],
    focus: base ? "#ca-url" : "#ca-name",
  });
}
