/* Raspi-TV – Fernsehen (Live-TV mit freien, offiziellen Senderstreams) */
"use strict";

const $ = id => document.getElementById(id);
const video = $("video");
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (_) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) {} },
};

let channels = [];
let current = -1;
let hls = null;
let retryTimer = null, stallTimer = null, infoTimer = null, numTimer = null;
let numBuffer = "";
let prevChannel = -1;   // „0“ springt zurück zum vorherigen Sender
let listOpen = false, listFocus = 0;
let optOpen = false, optFocus = 0;
let favs = new Set(store.get("tv.favs", []));
let favOnly = store.get("tv.favOnly", false);
let sleepUntil = 0, sleepTick = null;
let standby = false;
let epgNow = {};        // aktuelle + nächste Sendung je Sender

function hhmm(ts) {
  const d = new Date(ts * 1000);
  return String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
}

async function loadEpg() {
  try { epgNow = await (await fetch("/api/epg/now", { cache: "no-store" })).json(); } catch (_) {}
  if ($("infobar").classList.contains("show")) fillInfo();
  renderList();
}   // Fernseher ist aus (per HDMI-CEC gemeldet) oder Schlaf-Timer abgelaufen

// ------------------------------------------------------------------ Wiedergabe
function stopPlayback() {
  clearTimeout(retryTimer);
  clearTimeout(stallTimer);
  if (hls) { hls.destroy(); hls = null; }
  video.removeAttribute("src");
  video.load();
}

function setLoading(on) { $("loading").classList.toggle("show", on); }

function showError() {
  setLoading(false);
  $("error").hidden = false;
  clearTimeout(retryTimer);
  retryTimer = setTimeout(() => { if (!standby) play(current, false); }, 20000);
}

function play(index, announce = true) {
  if (!channels.length) return;
  index = (index + channels.length) % channels.length;
  if (current >= 0 && current !== index) prevChannel = current;
  current = index;
  store.set("tv.channel", index);
  const ch = channels[index];
  const recent = store.get("tv.recent", []).filter(n => n !== ch.name);
  recent.unshift(ch.name);
  store.set("tv.recent", recent.slice(0, 8));

  tsReset();
  document.body.classList.add("switching");
  if (announce) showInfo();
  attachSource(ch.url, {}, showError);
  renderList();
  if (typeof renderRec === "function") try { renderRec(); } catch (_) {}
  reportNow();
}

// Dem Pi sagen, was läuft – für „Jetzt läuft“ und die Senderliste in der Handy-App
function reportNow() {
  const ch = channels[current];
  if (!ch || standby) return;
  apiPost("/api/tv/now", { name: ch.name, favs: [...favs] }).catch(() => {});
}
setInterval(reportNow, 30000);
window.addEventListener("pagehide", () => { apiPost("/api/tv/now", { name: null }).catch(() => {}); });

// Stream an das Video hängen (Live-Sender oder die Zeitversetzt-Aufnahme)
function attachSource(url, extra, onFatal) {
  stopPlayback();
  $("error").hidden = true;
  setLoading(true);
  // Kommt nach 15 s kein Bild, gilt der Sender als nicht verfügbar
  stallTimer = setTimeout(onFatal, 15000);
  if (window.Hls && Hls.isSupported()) {
    hls = new Hls(Object.assign({
      capLevelToPlayerSize: true,
      maxBufferLength: 20,
      liveSyncDurationCount: 3,
      manifestLoadingMaxRetry: 3,
      levelLoadingMaxRetry: 3,
      fragLoadingMaxRetry: 4,
    }, extra));
    hls.on(Hls.Events.ERROR, (_, data) => {
      if (!data.fatal) return;
      if (data.type === Hls.ErrorTypes.MEDIA_ERROR) { hls.recoverMediaError(); return; }
      onFatal();
    });
    restoreTracks();
    hls.loadSource(url);
    hls.attachMedia(video);
  } else {
    video.src = url;
  }
  video.play().catch(() => {});
}

// ------------------------------------------------------------------ Anhalten & zeitversetzt schauen
// Pause hält das Bild an, der Pi nimmt ab da auf. Weiter spielt die Aufnahme ab („zeitversetzt“),
// ◀ ▶ spulen 30 s, Zurück springt wieder zu Live.
const TS = { mode: "live", pausedAt: 0, timer: null, info: null, busy: false, lastAction: 0 };

function apiPost(path, body) {
  return fetch(path, { method: "POST", keepalive: true, headers: { "Content-Type": "application/json", "X-Raspi-TV": "1" },
                       body: JSON.stringify(body || {}) }).then(async r => {
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || "Fehler");
    return j;
  });
}

function tsReset() {
  if (TS.mode !== "live") apiPost("/api/timeshift/stop").catch(() => {});
  TS.mode = "live";
  TS.info = null;
  clearInterval(TS.timer);
  TS.timer = null;
  renderTs();
}

function fmtDelay(sec) {
  sec = Math.max(0, Math.round(sec));
  const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
  return (h ? h + ":" + String(m).padStart(2, "0") : m) + ":" + String(s).padStart(2, "0");
}

function tsDelay() {
  if (TS.mode === "paused") return (Date.now() - TS.pausedAt) / 1000;
  return (Date.now() - TS.pausedAt) / 1000 - (video.currentTime || 0);
}

function renderTs() {
  const b = $("ts");
  document.body.classList.toggle("shifted", TS.mode !== "live");
  if (TS.mode === "live") { b.hidden = true; $("info-live").textContent = "LIVE"; return; }
  b.hidden = false;
  b.classList.toggle("mini", TS.mode === "shift" && !video.paused && Date.now() - TS.lastAction > 5000);
  const paused = TS.mode === "paused" || video.paused;
  const err = TS.info && TS.info.error && TS.info.error !== "beendet" ? TS.info.error : "";
  let line;
  if (TS.mode === "paused") {
    line = err ? `<span><b>Angehalten</b></span><span>${esc(err)}</span>`
               : `<span><b>Angehalten</b></span><span>wird aufgenommen</span><span class="n">${fmtDelay(tsDelay())}</span>`;
  } else {
    line = `<span><b>${paused ? "Angehalten" : "Zeitversetzt"}</b></span><span class="n">−${fmtDelay(tsDelay())}</span>`;
  }
  const keys = TS.mode === "paused" ? "<i>▶❚❚</i><span>weiter</span><i>Zurück</i><span>Live</span>"
                                    : "<i>◀ ▶</i><span>30 s spulen</span><i>▶❚❚</i><span>Pause</span><i>Zurück</i><span>Live</span>";
  b.innerHTML = `<span class="ico">${paused ? "❚❚" : "⏪"}</span><span class="txt"><span class="l">${line}</span><small>${keys}</small></span>`;
  $("info-live").textContent = "ZEITVERSETZT";
}

async function tsPoll() {
  try { TS.info = await (await fetch("/api/timeshift", { cache: "no-store" })).json(); } catch (_) {}
  renderTs();
}

async function togglePause() {
  if (TS.busy) return;
  TS.lastAction = Date.now();
  const ch = channels[current];
  if (!ch) return;
  if (TS.mode === "live") {
    if (video.paused) { video.play().catch(() => {}); return; }
    video.pause();          // der „pause“-Handler startet die Aufnahme
    return;
  }
  if (TS.mode === "paused") return tsResume();
  // zeitversetzt: einfach anhalten/weiter, die Aufnahme läuft weiter
  if (video.paused) video.play().catch(() => {}); else video.pause();
  renderTs();
}

// Live-Bild wurde angehalten (Pause-Taste, Handy, eingehender Anruf …): ab hier aufnehmen
async function tsStartRecording() {
  const ch = channels[current];
  if (!ch || TS.mode !== "live" || standby) return;
  TS.lastAction = Date.now();
  TS.mode = "paused";
  TS.pausedAt = Date.now();
  TS.info = null;
  renderTs();
  clearInterval(TS.timer);
  TS.timer = setInterval(tsPoll, 1000);
  const behind = hls && Number.isFinite(hls.latency) ? hls.latency : 0;
  try { TS.info = await apiPost("/api/timeshift/start", { url: ch.url, behind }); }
  catch (e) { TS.info = { error: e.message }; }
  renderTs();
}

async function tsResume() {
  TS.busy = true;
  try {
    // auf das erste aufgenommene Stück warten (max. 15 s)
    for (let i = 0; i < 30; i++) {
      await tsPoll();
      if (!TS.info || TS.info.error || TS.info.ready || !TS.info.active) break;
      setLoading(true);
      await new Promise(r => setTimeout(r, 500));
    }
    const info = TS.info || {};
    if (!info.ready) {
      // Aufnahme klappt bei diesem Sender nicht: einfach live weiterschauen
      tsNotice(info.error ? "Zeitversetzt nicht möglich – weiter live" : "Weiter live");
      play(current, false);
      return;
    }
    TS.mode = "shift";
    attachSource(info.playlist || "/timeshift/index.m3u8", { startPosition: 0 }, () => {
      tsNotice("Aufnahme lässt sich nicht abspielen – zurück zu Live");
      play(current, false);
    });
    renderTs();
  } finally {
    TS.busy = false;
  }
}

function tsSeek(d) {
  if (TS.mode !== "shift") return false;
  TS.lastAction = Date.now();
  const sk = video.seekable;
  const end = sk && sk.length ? sk.end(sk.length - 1) : video.duration;
  const t = (video.currentTime || 0) + d;
  if (d > 0 && Number.isFinite(end) && t > end - 4) { goLive(); return true; }
  video.currentTime = Math.max(0, t);
  renderTs();
  return true;
}

function goLive() {
  tsNotice("Zurück zu Live");
  play(current, false);
}

function tsNotice(t) {
  const n = $("ts-note");
  n.textContent = t;
  n.hidden = false;
  clearTimeout(tsNotice.t);
  tsNotice.t = setTimeout(() => { n.hidden = true; }, 2500);
}

// ------------------------------------------------------------------ Aufnehmen
const REC = { items: [] };
function recOf(name) { return REC.items.find(i => i.status === "recording" && i.channel === name); }
async function recPoll() {
  try { REC.items = (await (await fetch("/api/rec", { cache: "no-store" })).json()).schedule || []; } catch (_) {}
  renderRec();
}
function renderRec() {
  const ch = channels[current];
  const on = !!(ch && recOf(ch.name));
  $("rec-ind").hidden = !on;
  $("info-rec").hidden = !on;
}
async function toggleRec() {
  const ch = channels[current];
  if (!ch) return;
  const r = recOf(ch.name);
  try {
    if (r) {
      REC.items = (await apiPost("/api/rec/cancel", { id: r.id })).schedule;
      tsNotice("Aufnahme beendet – zu finden unter Eigene Medien → Aufnahmen");
    } else {
      tsNotice("Aufnahme startet …");
      const res = await apiPost("/api/rec/now", { channel: ch.name });
      REC.items = res.schedule;
      tsNotice("● Aufnahme läuft bis " + hhmm(res.until) + " Uhr");
    }
  } catch (e) { tsNotice(e.message); }
  renderRec();
  if (optOpen) renderOptions();
}
setInterval(recPoll, 15000);
recPoll();

video.addEventListener("pause", () => {
  // nur ein echtes Anhalten eines laufenden Live-Bilds (nicht beim Umschalten/Laden)
  if (TS.mode === "live" && video.readyState >= 2 && !video.seeking && !document.body.classList.contains("switching")) tsStartRecording();
  renderTs();
});
video.addEventListener("play", renderTs);

// nächster/vorheriger Sender – auf Wunsch nur durch die Lieblingssender
function step(dir) {
  const pool = favOnly && favs.size
    ? channels.map((c, i) => i).filter(i => favs.has(channels[i].name))
    : channels.map((c, i) => i);
  if (!pool.length) return;
  const pos = pool.indexOf(current);
  if (pos >= 0) return play(pool[(pos + dir + pool.length) % pool.length]);
  // aktueller Sender ist kein Favorit: nächsten Favoriten in Richtung wählen
  const next = dir > 0 ? pool.find(i => i > current) : [...pool].reverse().find(i => i < current);
  play(next !== undefined ? next : (dir > 0 ? pool[0] : pool[pool.length - 1]));
}

video.addEventListener("playing", () => {
  document.body.classList.remove("switching");
  clearTimeout(stallTimer);
  setLoading(false);
  $("error").hidden = true;
});
video.addEventListener("waiting", () => setLoading(true));

// ------------------------------------------------------------------ Infoleiste
function clock() {
  const d = new Date();
  return String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
}

function fillInfo() {
  const ch = channels[current];
  if (!ch) return;
  const e = epgNow[ch.name] || {};
  const now = Date.now() / 1000;
  let cur = e.now, nxt = e.next;
  if (cur && cur.stop <= now) { cur = nxt && nxt.start <= now ? nxt : null; nxt = null; }
  $("info-num").textContent = current + 1;
  $("info-name").textContent = ch.name;
  const lg = $("info-logo");
  if (ch.logo) { lg.hidden = false; lg.querySelector("img").src = ch.logo; } else lg.hidden = true;
  $("info-fav").hidden = !favs.has(ch.name);
  $("info-show").textContent = cur ? cur.title : (ch.group ? ch.group : "Live");
  $("info-time").textContent = cur ? hhmm(cur.start) + " – " + hhmm(cur.stop) : "";
  $("info-bar").style.width = cur ? Math.min(100, (now - cur.start) / (cur.stop - cur.start) * 100) + "%" : "0";
  $("info-bar").parentElement.style.visibility = cur ? "visible" : "hidden";
  $("info-next").innerHTML = nxt ? `Danach <b>${hhmm(nxt.start)}</b> ${esc(nxt.title)}` : "";
  $("info-clock").textContent = clock();
}

function showInfo(ms = 5000) {
  if (!channels[current]) return;
  fillInfo();
  $("infobar").classList.add("show");
  clearTimeout(infoTimer);
  infoTimer = setTimeout(() => $("infobar").classList.remove("show"), ms);
}

// ------------------------------------------------------------------ Ziffern
function typeDigit(d) {
  if (numBuffer.length >= 3) numBuffer = "";
  numBuffer += d;
  const el = $("numentry");
  el.textContent = numBuffer + (numBuffer.length < String(channels.length).length ? "-" : "");
  el.hidden = false;
  clearTimeout(numTimer);
  const done = numBuffer.length >= String(channels.length).length;
  numTimer = setTimeout(commitNumber, numBuffer === "0" ? 900 : done ? 400 : 1600);
}

function commitNumber() {
  const raw = numBuffer;
  const n = parseInt(numBuffer, 10);
  numBuffer = "";
  $("numentry").hidden = true;
  if (raw === "0") { if (prevChannel >= 0) play(prevChannel); return; }
  if (n >= 1 && n <= channels.length) play(n - 1);
}

// ------------------------------------------------------------------ Senderliste
function esc(s) {
  return String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
}

function renderList() {
  if (!listOpen) return;
  const box = $("list-items");
  box.innerHTML = channels.map((ch, i) => `
    <div class="ch${i === current ? " current" : ""}${i === listFocus ? " focused" : ""}" data-i="${i}">
      <span class="n">${i + 1}</span>${ch.logo ? `<span class="lg"><img src="${esc(ch.logo)}" alt="" loading="lazy" onerror="this.parentNode.remove()"></span>` : ""}<span class="t">${esc(ch.name)}${(epgNow[ch.name] || {}).now ? `<small>${esc(epgNow[ch.name].now.title)}</small>` : ""}</span>
      ${favs.has(ch.name) ? '<span class="star">★</span>' : ""}
      <span class="g">${esc(ch.group || "")}</span>
    </div>`).join("");
  const f = box.querySelector(".focused");
  if (f) box.scrollTop = f.offsetTop - box.clientHeight / 2 + f.offsetHeight / 2;
}

function openList() {
  closeOptions();
  listOpen = true;
  listFocus = Math.max(current, 0);
  $("list").hidden = false;
  $("infobar").classList.remove("show");
  renderList();
}

function closeList() {
  listOpen = false;
  $("list").hidden = true;
}

// ------------------------------------------------------------------ Optionen
const SLEEP_STEPS = [0, 15, 30, 60, 90, 120];

function sleepLabel() {
  if (!sleepUntil) return "Aus";
  const min = Math.max(1, Math.round((sleepUntil - Date.now()) / 60000));
  return "in " + min + " Min.";
}

// ------------------------------------------------------------ Tonspur, Untertitel, Bildformat
const FITS = ["contain", "cover", "fill"];
const FIT_LABELS = { contain: "Original", cover: "Zoom (füllt das Bild)", fill: "Strecken" };
let fit = store.get("tv.fit", "contain");
if (!FITS.includes(fit)) fit = "contain";
video.style.objectFit = fit;
function setFit(d) {
  fit = FITS[(FITS.indexOf(fit) + (d > 0 ? 1 : FITS.length - 1)) % FITS.length];
  video.style.objectFit = fit;
  store.set("tv.fit", fit);
}

function trackName(t, i) {
  const n = (t.name || "").trim();
  const lang = (t.lang || "").toLowerCase();
  const L = { de: "Deutsch", deu: "Deutsch", ger: "Deutsch", en: "Englisch", eng: "Englisch", fr: "Französisch", fra: "Französisch", mis: "Ton", qks: "Klare Sprache", qad: "Audiodeskription" };
  if (/audiodeskription|audio description|\bad\b/i.test(n) || lang === "qad") return "Audiodeskription";
  if (/klare sprache/i.test(n) || lang === "qks") return "Klare Sprache";
  if (/original/i.test(n)) return "Originalton";
  return n || L[lang] || ("Spur " + (i + 1));
}

function audioItem() {
  if (!hls || !hls.audioTracks || hls.audioTracks.length < 2) return [];
  const list = hls.audioTracks;
  return [{ label: "Tonspur", value: trackName(list[hls.audioTrack] || {}, hls.audioTrack), arrows: true, change: d => {
    hls.audioTrack = (hls.audioTrack + (d > 0 ? 1 : list.length - 1)) % list.length;
    store.set("tv.audio." + channels[current].name, list[hls.audioTrack].lang || list[hls.audioTrack].name || "");
  } }];
}

function subtitleItem() {
  if (!hls || !hls.subtitleTracks || !hls.subtitleTracks.length) return [];
  const list = hls.subtitleTracks;
  const cur = hls.subtitleDisplay ? hls.subtitleTrack : -1;
  return [{ label: "Untertitel", value: cur < 0 ? "Aus" : trackName(list[cur] || {}, cur), arrows: true, change: d => {
    let i = cur + (d > 0 ? 1 : -1);
    if (i >= list.length) i = -1;
    if (i < -1) i = list.length - 1;
    if (i < 0) { hls.subtitleDisplay = false; hls.subtitleTrack = -1; }
    else { hls.subtitleTrack = i; hls.subtitleDisplay = true; }
    store.set("tv.subs", i >= 0);
  } }];
}

// gemerkte Tonspur / Untertitel nach dem Umschalten wieder setzen
function restoreTracks() {
  if (!hls) return;
  hls.on(Hls.Events.MANIFEST_PARSED, () => {
    const ch = channels[current];
    const want = ch && store.get("tv.audio." + ch.name, "");
    if (want && hls.audioTracks) {
      const i = hls.audioTracks.findIndex(t => (t.lang || t.name) === want);
      if (i >= 0) hls.audioTrack = i;
    }
    if (store.get("tv.subs", false) && hls.subtitleTracks && hls.subtitleTracks.length) {
      hls.subtitleTrack = 0; hls.subtitleDisplay = true;
    }
  });
}

function optionItems() {
  const ch = channels[current] || { name: "" };
  return [
    { label: "Lieblingssender", value: favs.has(ch.name) ? "★ Ja" : "Nein", toggle: toggleFav },
    { label: "Umschalten durch", value: favOnly ? "Lieblingssender" : "Alle Sender", toggle: () => {
        if (!favOnly && !favs.size) { flashOption("Erst Lieblingssender markieren"); return; }
        favOnly = !favOnly; store.set("tv.favOnly", favOnly);
      } },
    { label: "Schlaf-Timer", value: sleepLabel(), arrows: true, change: d => {
        const now = sleepUntil ? Math.round((sleepUntil - Date.now()) / 60000) : 0;
        let i = SLEEP_STEPS.findIndex(s => s >= now);
        if (i < 0) i = SLEEP_STEPS.length - 1;
        if (d > 0 && SLEEP_STEPS[i] <= now) i++;
        i = Math.max(0, Math.min(SLEEP_STEPS.length - 1, d > 0 ? i : i - 1));
        setSleep(SLEEP_STEPS[i]);
      } },
    ...(TS.mode !== "live" ? [{ label: "Zurück zu Live", value: "", toggle: () => { closeOptions(); goLive(); } }] : []),
    { label: "Aufnehmen", value: recOf(ch.name) ? "● Läuft – beenden" : "Sendung aufnehmen", toggle: () => { toggleRec(); } },
    ...audioItem(),
    ...subtitleItem(),
    { label: "Bildformat", value: FIT_LABELS[fit], arrows: true, change: d => setFit(d) },
    { label: "TV-Programm", value: "", toggle: () => { closeOptions(); goGuide(); } },
    { label: "Sender neu laden", value: "", toggle: () => { closeOptions(); play(current); } },
  ];
}

let flashText = "";
function flashOption(t) { flashText = t; renderOptions(); setTimeout(() => { flashText = ""; renderOptions(); }, 2000); }

function renderOptions() {
  if (!optOpen) return;
  const items = optionItems();
  optFocus = Math.min(optFocus, items.length - 1);
  $("opt-items").innerHTML = items.map((o, i) => `
    <div class="opt${i === optFocus ? " focused" : ""}" data-i="${i}">
      <span>${esc(o.label)}</span>
      <span class="v${o.arrows ? " arrows" : ""}">${esc(i === optFocus && flashText ? flashText : o.value)}</span>
    </div>`).join("");
}

function openOptions() {
  closeList();
  optOpen = true;
  optFocus = 0;
  $("options").hidden = false;
  $("infobar").classList.remove("show");
  renderOptions();
}

function closeOptions() {
  optOpen = false;
  $("options").hidden = true;
}

function toggleFav() {
  const ch = channels[current];
  if (!ch) return;
  if (favs.has(ch.name)) favs.delete(ch.name); else favs.add(ch.name);
  store.set("tv.favs", [...favs]);
  reportNow();
  if (!favs.size && favOnly) { favOnly = false; store.set("tv.favOnly", false); }
}

// ------------------------------------------------------------------ Schlaf-Timer
function setSleep(min, fromServer) {
  sleepUntil = min ? Date.now() + min * 60000 : 0;
  clearInterval(sleepTick);
  // der Pi merkt sich den Timer – so sieht und ändert ihn auch die Handy-App
  if (!fromServer) apiPost("/api/sleep", { minutes: Math.round(min || 0) }).catch(() => {});
  $("sleep").hidden = true;
  if (sleepUntil) sleepTick = setInterval(sleepCheck, 1000);
}

function sleepCheck() {
  const left = Math.round((sleepUntil - Date.now()) / 1000);
  if (left <= 60 && left > 0) {
    $("sleep").hidden = false;
    $("sleep").innerHTML = `Schlaf-Timer: Ausschalten in <b>${left} s</b> · beliebige Taste zum Abbrechen`;
  }
  if (left <= 0) {
    setSleep(0);
    const hour = new Date().getHours();
    goToSleep(hour >= 22 || hour < 5 ? "Gute Nacht – zum Einschalten eine Taste drücken" : "Ausgeschaltet – zum Einschalten eine Taste drücken");
    // Fernseher über HDMI-CEC ausschalten
    fetch("/api/tv/standby", { method: "POST", headers: { "Content-Type": "application/json", "X-Raspi-TV": "1" }, body: "{}" })
      .catch(() => {});
  }
  if (optOpen) renderOptions();
}

// ------------------------------------------------------------------ Fernseher aus / an
function goToSleep(text) {
  standby = true;
  tsReset();
  stopPlayback();
  closeList(); closeOptions();
  $("infobar").classList.remove("show");
  $("blackout-text").textContent = text || "";
  $("blackout").hidden = false;
}

function wakeUp() {
  if (!standby) return;
  standby = false;
  $("blackout").hidden = true;
  play(current);
}

async function pollTvPower() {
  try {
    const s = await (await fetch("/api/status", { cache: "no-store" })).json();
    if (s.kids_blocked) { tsReset(); stopPlayback(); location.href = "/#/kidslock"; return; }
    if ("sleep_left" in s) {
      const left = s.sleep_left;
      if (left && Math.abs(Date.now() + left * 1000 - sleepUntil) > 8000) setSleep(left / 60, true);
      else if (!left && sleepUntil && sleepUntil - Date.now() > 15000) setSleep(0, true);
    }
    if (s.tv === "standby" && !standby) goToSleep("");
    else if (s.tv === "on" && standby && !sleepUntil && $("blackout-text").textContent === "") wakeUp();
  } catch (_) {}
}

// ------------------------------------------------------------------ Tasten
function goHome() {
  tsReset();
  stopPlayback();
  location.href = "/";
}

function goGuide() {
  tsReset();
  stopPlayback();
  location.href = "/#/guide";
}

document.addEventListener("keydown", e => {
  const k = e.key;

  // Jede Taste weckt auf bzw. bricht den laufenden Schlaf-Countdown ab
  if (standby) { wakeUp(); e.preventDefault(); return; }
  if (!$("sleep").hidden) { setSleep(0); e.preventDefault(); return; }

  if (listOpen) {
    if (k === "ArrowUp") listFocus = (listFocus - 1 + channels.length) % channels.length;
    else if (k === "ArrowDown") listFocus = (listFocus + 1) % channels.length;
    else if (k === "PageUp") listFocus = Math.max(0, listFocus - 8);
    else if (k === "PageDown") listFocus = Math.min(channels.length - 1, listFocus + 8);
    else if (k === "Enter" || k === " ") { closeList(); play(listFocus); }
    else if (k === "ArrowRight") { closeList(); openOptions(); return e.preventDefault(); }
    else if (k === "Escape" || k === "Backspace" || k === "BrowserBack" || k === "ArrowLeft") closeList();
    else if (/^[0-9]$/.test(k)) { closeList(); typeDigit(k); }
    else return;
    renderList();
    e.preventDefault();
    return;
  }

  if (optOpen) {
    const items = optionItems();
    const o = items[optFocus];
    if (k === "ArrowUp") optFocus = (optFocus - 1 + items.length) % items.length;
    else if (k === "ArrowDown") optFocus = (optFocus + 1) % items.length;
    else if (k === "Enter" || k === " ") { o.change ? o.change(1) : o.toggle && o.toggle(); }
    else if (k === "ArrowRight") { if (o.change) o.change(1); }
    else if (k === "ArrowLeft") { if (o.change) o.change(-1); else closeOptions(); }
    else if (k === "Escape" || k === "Backspace" || k === "BrowserBack") closeOptions();
    else return;
    renderOptions();
    e.preventDefault();
    return;
  }

  switch (k) {
    case "ArrowUp": case "PageUp": step(1); break;
    case "ArrowDown": case "PageDown": step(-1); break;
    case "ArrowLeft": case "MediaRewind": if (!tsSeek(-30)) showInfo(); break;
    case "ArrowRight": case "MediaFastForward": if (!tsSeek(30)) openOptions(); break;
    case "Enter": openList(); break;
    case " ": case "MediaPlayPause": case "MediaPause": case "MediaPlay": case "p": case "P":
      togglePause();
      break;
    case "Escape": case "Backspace": case "BrowserBack":
      if (TS.mode !== "live") goLive(); else goHome();
      break;
    case "g": case "G": goGuide(); break;
    case "i": case "I": showInfo(8000); break;
    case "r": case "R": case "MediaRecord": toggleRec(); break;
    default:
      if (/^[0-9]$/.test(k)) { typeDigit(k); break; }
      return;
  }
  e.preventDefault();
});

// Maus: Klick öffnet die Senderliste, Klick in der Liste schaltet um
document.addEventListener("click", e => {
  if (standby) { wakeUp(); return; }
  const row = e.target.closest(".ch");
  if (row) { closeList(); play(+row.dataset.i); return; }
  const opt = e.target.closest(".opt");
  if (opt) {
    optFocus = +opt.dataset.i;
    const o = optionItems()[optFocus];
    o.change ? o.change(1) : o.toggle && o.toggle();
    renderOptions();
    return;
  }
  if (optOpen) { closeOptions(); return; }
  if (!listOpen) openList(); else closeList();
});
document.addEventListener("mousemove", () => { document.body.style.cursor = "default"; });

// Kein Zurück-in-die-Historie aus dem Fernsehen heraus: Zurück = Startseite
history.pushState(null, "", location.href);
window.addEventListener("popstate", goHome);

// Bei Verbindungsabbruch automatisch wieder einschalten
window.addEventListener("online", () => { if (!standby) play(current, false); });

// ------------------------------------------------------------------ Start
async function loadChannels() {
  for (const src of ["/api/channels", "channels.json"]) {
    try {
      const list = await (await fetch(src, { cache: "no-store" })).json();
      if (Array.isArray(list) && list.length) return list;
    } catch (_) {}
  }
  return [];
}

(async function init() {
  channels = await loadChannels();
  if (!channels.length) {
    $("error").hidden = false;
    $("error").querySelector(".error-title").textContent = "Keine Senderliste gefunden";
    return;
  }
  const qs = new URLSearchParams(location.search);
  const fromUrl = parseInt(qs.get("ch") || "", 10);
  const byName = qs.get("name") ? channels.findIndex(c => c.name === qs.get("name")) : -1;
  const start = byName >= 0 ? byName : Number.isInteger(fromUrl) ? fromUrl - 1 : store.get("tv.channel", 0);
  // gleiche Bildgröße wie die Oberfläche
  fetch("/api/config").then(r => r.json()).then(c => {
    const sc = (c.ui_scale || 100) / 100;
    if (sc !== 1) document.body.style.transform = `scale(${sc})`;
  }).catch(() => {});
  loadEpg();
  setInterval(loadEpg, 60000);
  play(Math.min(Math.max(start, 0), channels.length - 1));
  setInterval(() => { $("info-clock").textContent = clock(); }, 10000);
  setInterval(pollTvPower, 5000);
})();
