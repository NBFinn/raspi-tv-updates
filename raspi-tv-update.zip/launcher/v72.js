/* Raspi-TV 7.2: Nachtlautstärke, sanftes Ausblenden, Schnellaktionen, Prüfung nach Updates */
"use strict";
const I72 = (() => {
  const svg = d => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
  return { moon: svg('<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>'), clock: svg('<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>'),
           play: svg('<path d="M8 5.5l11 6.5-11 6.5z"/>') };
})();

// ======================================================================
// Einstellungen · Energie: Nachtlautstärke und sanftes Ausblenden
// ======================================================================
(function () {
  const r = ROUTES.energy.render;
  ROUTES.energy.render = (v, t) => { r(v, t); setTimeout(() => addNightRows(v, t), 0); };
})();
function addNightRows(view, token) {
  const page = view.querySelector(".page");
  if (!page || token !== renderToken || view.querySelector("#nv-box")) return;
  const box = document.createElement("div");
  box.id = "nv-box";
  page.appendChild(box);
  const FROM = ["19:00", "20:00", "21:00", "22:00", "23:00", "00:00"], TO = ["05:00", "06:00", "07:00", "08:00", "09:00", "10:00"];
  const MAX = [10, 15, 20, 25, 30, 35, 40, 50, 60];
  const cur = () => Object.assign({ on: false, from: "22:00", to: "07:00", max: 30 }, state.config.night_volume || {});
  const next = (list, v) => list[(list.indexOf(v) + 1) % list.length];
  async function save(patch) {
    try { state.config = await API.post("/api/config", patch); draw(); } catch (e) { toast(e.message, "error"); }
  }
  function draw() {
    if (token !== renderToken) return;
    const key = Nav.current && Nav.current.dataset.key, n = cur();
    box.innerHTML = `<h2>Nachts leiser</h2><div class="list">
      ${toggleRow("nv-on", I72.moon, "Nachtlautstärke", "Begrenzt nachts den Ton des Raspberry Pi – lauter drehen geht dann nur bis zum Höchstwert. Regelt der Fernseher die Lautstärke, hat das keine Wirkung.", n.on)}
      ${n.on ? valueRow("nv-from", I72.clock, "Von", "Ab dieser Uhrzeit gilt der Höchstwert", n.from + " Uhr")
        + valueRow("nv-to", I72.clock, "Bis", "Danach ist wieder jede Lautstärke möglich", n.to + " Uhr")
        + valueRow("nv-max", ICON.sound, "Höchstens", "Lauter wird es in dieser Zeit nicht", n.max + " %") : ""}
      ${toggleRow("nv-fade", ICON.sound, "Schlaf-Timer blendet sanft aus", "In der letzten Minute wird die Musik langsam leiser. Danach gilt wieder die alte Lautstärke.", state.config.sleep_fade !== false)}</div>`;
    $("#nv-on").addEventListener("click", () => save({ night_volume: Object.assign(n, { on: !n.on }) }));
    if (n.on) {
      $("#nv-from").addEventListener("click", () => save({ night_volume: Object.assign(n, { from: next(FROM, n.from) }) }));
      $("#nv-to").addEventListener("click", () => save({ night_volume: Object.assign(n, { to: next(TO, n.to) }) }));
      $("#nv-max").addEventListener("click", () => save({ night_volume: Object.assign(n, { max: next(MAX, n.max) }) }));
    }
    $("#nv-fade").addEventListener("click", () => save({ sleep_fade: state.config.sleep_fade === false }));
    const again = key && view.querySelector(`[data-key="${key}"]`);
    if (again && (!Nav.current || !document.contains(Nav.current))) Nav.focus(again, false);
  }
  draw();
}

// ======================================================================
// Schnellaktionen: mehrere Schritte auf einen Knopf im Schnellmenü (Info-Taste)
// ======================================================================
const Quick = {
  VOL: [null, 10, 15, 20, 25, 30, 35, 40, 50, 60, 70, 80],
  SLEEP: [null, 15, 30, 60, 90, 120],
  START_IDS: ["spotify", "youtube", "netflix", "ard", "zdf"],
  list() { return Array.isArray(state.config.quick_actions) ? state.config.quick_actions : []; },
  step(a, type) { const s = (a.steps || []).find(x => x.type === type); return s ? s.value : null; },
  starts() {
    const out = [[null, "Nichts"], ["radio:", "Radio (zuletzt gehört)"]];
    for (const id of this.START_IDS) { const app = findApp(id); if (app) out.push(["app:" + id, app.name]); }
    return out;
  },
  async savers() {
    const out = [[null, "Keiner"], ["", "Wie eingestellt"]];
    for (const s of await Media.scenes()) out.push(["video-" + s.id, "Ambient: " + s.name]);
    return out;
  },
  describe(a) {
    const parts = [];
    const v = this.step(a, "volume"), app = this.step(a, "app"), radio = this.step(a, "radio"), sv = this.step(a, "saver"), sl = this.step(a, "sleep");
    if (app) parts.push((findApp(app) || { name: app }).name);
    if (radio !== null) parts.push("Radio");
    if (v !== null) parts.push(v + " %");
    if (sv !== null) parts.push("Bildschirmschoner");
    if (sl) parts.push("aus in " + sl + " Min.");
    return parts.join(" · ") || "Keine Schritte";
  },
  // Reihenfolge: erst Lautstärke und Timer, dann starten, zuletzt der Bildschirmschoner
  async run(a) {
    const v = this.step(a, "volume"), app = this.step(a, "app"), radio = this.step(a, "radio"), sv = this.step(a, "saver"), sl = this.step(a, "sleep");
    const notes = [];
    if (v !== null) { try { await API.post("/api/quick/volume", { volume: v }); } catch (e) { notes.push(e.message); } }
    if (sl) { try { await API.post("/api/sleep", { minutes: sl }); } catch (e) { notes.push(e.message); } }
    if (radio !== null && typeof Radio !== "undefined" && (!Radio.current || Radio.state === "paused")) Radio.control("toggle");
    let leaves = false;
    if (app) { const x = findApp(app); leaves = !!x && app !== "spotify"; openApp(app); }
    toast(notes.length ? a.name + ": " + notes.join(" ") : a.name + " gestartet", notes.length ? "error" : "ok", notes.length ? 7000 : 2500);
    if (sv !== null && !leaves) setTimeout(() => {
      if (sv.startsWith("video")) VideoSaver.show(sv.length > 6 ? { scene: sv.slice(6) } : {});
      else if (typeof Saver !== "undefined") Saver.show();
    }, app ? 6000 : 800);
  },
  async saveAll(list) {
    state.config = await API.post("/api/config", { quick_actions: list });
  },
  manage() {
    const list = this.list();
    const { el, close } = openModal({
      title: "Schnellaktionen",
      html: `<p class="desc">Eine Schnellaktion erledigt mehrere Dinge auf einmal – z. B. „Musikabend“: Spotify öffnen, Lautstärke einstellen, Bildschirmschoner starten. Sie erscheint im Schnellmenü (Info-Taste).</p>
        <div class="list">${list.map((a, i) => valueRow("qa-" + i, ICON.star || ICON.check, esc(a.name), esc(this.describe(a)), "Ändern")).join("")}
        ${list.length < 8 ? valueRow("qa-new", ICON.plus || ICON.check, "Neue Schnellaktion", "Namen und Schritte festlegen", "") : ""}</div>`,
      buttons: [{ label: "Fertig", style: "primary" }],
      focus: list.length ? "#qa-0" : "#qa-new",
    });
    list.forEach((a, i) => el.querySelector("#qa-" + i).addEventListener("click", () => { close(); this.edit(i); }));
    const n = el.querySelector("#qa-new");
    if (n) n.addEventListener("click", () => { close(); this.edit(-1); });
  },
  async edit(index) {
    const list = this.list().map(a => JSON.parse(JSON.stringify(a)));
    const a = index >= 0 ? list[index] : { name: "Musikabend", steps: [] };
    const starts = this.starts(), savers = await this.savers();
    const val = { volume: this.step(a, "volume"), sleep: this.step(a, "sleep") || null, saver: this.step(a, "saver"),
      start: this.step(a, "app") ? "app:" + this.step(a, "app") : this.step(a, "radio") !== null ? "radio:" : null };
    const label = (pairs, v) => (pairs.find(p => p[0] === v) || pairs[0])[1];
    const cycle = (pairs, v) => pairs[(Math.max(0, pairs.findIndex(p => p[0] === v)) + 1) % pairs.length][0];
    const { el, close } = openModal({
      title: index >= 0 ? "Schnellaktion ändern" : "Neue Schnellaktion",
      html: `<div class="field"><input class="nav" id="qe-name" data-key="qe-name" maxlength="24" value="${esc(a.name)}" autocomplete="off" spellcheck="false" placeholder="Name"></div>
        <div class="list" id="qe-rows" style="margin-bottom:2vh"></div>`,
      buttons: [
        { label: "Speichern", style: "primary", action: async c => {
          const name = el.querySelector("#qe-name").value.trim().slice(0, 24);
          if (!name) return toast("Bitte einen Namen eingeben", "error");
          const steps = [];
          if (val.volume !== null) steps.push({ type: "volume", value: val.volume });
          if (val.sleep) steps.push({ type: "sleep", value: val.sleep });
          if (val.start && val.start.startsWith("app:")) steps.push({ type: "app", value: val.start.slice(4) });
          if (val.start === "radio:") steps.push({ type: "radio", value: "" });
          if (val.saver !== null) steps.push({ type: "saver", value: val.saver });
          if (!steps.length) return toast("Bitte mindestens einen Schritt wählen", "error");
          const item = { name, steps };
          if (index >= 0) list[index] = item; else list.push(item);
          try { await this.saveAll(list); c(); toast("Gespeichert – im Schnellmenü (Info-Taste) zu finden", "ok"); this.manage(); }
          catch (e) { toast(e.message, "error"); }
        } },
        ...(index >= 0 ? [{ label: "Löschen", style: "danger", action: async c => {
          list.splice(index, 1);
          try { await this.saveAll(list); c(); this.manage(); } catch (e) { toast(e.message, "error"); }
        } }] : []),
        { label: "Abbrechen", action: c => { c(); this.manage(); } },
      ],
      focus: "#qe-start",
    });
    const rows = el.querySelector("#qe-rows");
    const draw = keep => {
      rows.innerHTML =
        valueRow("qe-start", I72.play, "Starten", "Was geöffnet wird", esc(label(starts, val.start)))
        + valueRow("qe-vol", ICON.sound, "Lautstärke", "Nur für den Ton des Raspberry Pi", val.volume === null ? "Nicht ändern" : val.volume + " %")
        + valueRow("qe-saver", ICON.picture || ICON.eye, "Bildschirmschoner", "Startet kurz danach", esc(label(savers, val.saver)))
        + valueRow("qe-sleep", I72.moon, "Schlaf-Timer", "Schaltet später aus", val.sleep ? val.sleep + " Minuten" : "Aus");
      const on = (id, fn) => rows.querySelector("#" + id).addEventListener("click", () => { fn(); draw(id); });
      on("qe-start", () => { val.start = cycle(starts, val.start); });
      on("qe-vol", () => { val.volume = this.VOL[(this.VOL.indexOf(val.volume) + 1) % this.VOL.length]; });
      on("qe-saver", () => { val.saver = cycle(savers, val.saver); });
      on("qe-sleep", () => { val.sleep = this.SLEEP[(this.SLEEP.indexOf(val.sleep) + 1) % this.SLEEP.length]; });
      if (keep) Nav.focus(rows.querySelector("#" + keep), false);
    };
    draw();
  },
};

// Schnellmenü um die eigenen Aktionen erweitern
(function () {
  const open0 = QuickMenu.open.bind(QuickMenu);
  QuickMenu.open = function () {
    open0();
    const el = document.querySelector("#modals .modal.qm");
    if (!el || el.querySelector(".qm-own")) return;
    const row = document.createElement("div");
    row.className = "qm-row qm-own";
    const star = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.9-5.2-2.8-5.2 2.8 1-5.9L3.5 9.7l5.9-.8z"/></svg>';
    const plus = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>';
    row.innerHTML = Quick.list().map((a, i) =>
      `<button class="qm-b nav" data-key="qm-own-${i}" data-own="${i}"><span class="ic">${star}</span><b>${esc(a.name)}</b><small>${esc(Quick.describe(a))}</small></button>`).join("")
      + `<button class="qm-b nav" data-key="qm-own-edit" data-own="edit"><span class="ic">${plus}</span><b>Schnellaktionen</b><small>Anlegen & ändern</small></button>`;
    const first = el.querySelector(".qm-row");
    first.after(row);
    row.querySelectorAll("[data-own]").forEach(b => b.addEventListener("click", () => {
      const close = QuickMenu.close;
      if (close) close();
      if (b.dataset.own === "edit") return Quick.manage();
      const a = Quick.list()[+b.dataset.own];
      if (a) Quick.run(a);
    }));
  };
})();

// ======================================================================
// Prüfung nach Updates: sagt, was nach dem ersten Start der neuen Version nicht läuft
// ======================================================================
async function checkAfterUpdate() {
  let r;
  try { r = await API.get("/api/update-check"); } catch (_) { return; }
  if (!r || r.seen || !r.problems || !r.problems.length || document.querySelector("#modals .modal")) return;
  let snap = null;
  try { snap = ((await API.get("/api/rollback")).snapshots || [])[0] || null; } catch (_) {}
  openModal({
    title: "Nach dem Update auf " + r.version + " stimmt etwas nicht",
    html: `<ul class="uc-list">${r.problems.map(p => `<li>${esc(p)}</li>`).join("")}</ul>
      <p class="desc">Oft hilft ein Neustart. Bleibt es dabei, kannst du zur Version davor zurückkehren – deine Einstellungen bleiben erhalten.</p>`,
    buttons: [
      { label: "Neu starten", style: "primary", action: c => { c(); API.post("/api/update-check/ack").catch(() => {}); API.post("/api/reboot", {}).catch(e => toast(e.message, "error")); } },
      ...(snap ? [{ label: "Zurück zu " + snap.version, style: "danger", action: async c => {
        c();
        if (!await confirmDialog(`Zu Version ${snap.version} zurück?`, "Raspi-TV spielt die gesicherte Version ein und startet neu.", "Zurücksetzen", "danger")) return;
        try { await API.post("/api/update-check/ack"); await API.post("/api/rollback", { file: snap.file }); showOverlay("Raspi-TV startet neu …"); setTimeout(() => location.replace("/#/"), 20000); }
        catch (e) { toast(e.message, "error", 6000); }
      } }] : []),
      { label: "Später", action: c => { c(); API.post("/api/update-check/ack").catch(() => {}); } },
    ],
  });
}
setTimeout(checkAfterUpdate, 9000);
setInterval(checkAfterUpdate, 120000);
