/* Raspi-TV 7.3: Update mit sichtbarem Fortschritt, Seitenwahl der runden Displays,
 * automatische Sicherung auf USB-Stick, Diagnose-Paket */
"use strict";

// ======================================================================
// Update: sofort sichtbar, was passiert – Verbindung, Download, Entpacken, Sicherung, Installation, Neustart
// ======================================================================
updateProgressOverlay = function () {              // ersetzt die schlichte Anzeige aus extras4.js
  if (document.querySelector(".overlay.upd")) return;
  const o = document.createElement("div");
  o.className = "overlay upd";
  const PHASES = [["download", "Herunterladen"], ["unpack", "Entpacken"], ["backup", "Sichern"], ["install", "Installieren"], ["reboot", "Neustart"]];
  o.innerHTML = `<div class="upd-box">
      <div class="upd-kicker">Raspi-TV Update <span id="upd-ver"></span></div>
      <div class="upd-step" id="upd-step">Verbindung zum Update-Server …</div>
      <div class="upd-bar"><i id="upd-fill"></i></div>
      <div class="upd-sub" id="upd-sub">&nbsp;</div>
      <div class="upd-phases">${PHASES.map(p => `<span data-ph="${p[0]}">${p[1]}</span>`).join("")}</div>
      <div class="upd-note">Bitte nicht ausschalten. Klappt etwas nicht, kehrt Raspi-TV automatisch zur vorherigen Version zurück.</div>
    </div>`;
  document.body.appendChild(o);
  const q = s => o.querySelector(s);
  const phaseOf = s => {
    const step = s.step || "";
    if (s.done || /startet neu/.test(step)) return "reboot";
    if (s.phase === "download" || /^Download|Verbindung/.test(step)) return "download";
    if (/entpackt/.test(step)) return "unpack";
    if (/gesichert/.test(step)) return "backup";
    return "install";
  };
  const show = s => {
    const ph = phaseOf(s), idx = PHASES.findIndex(p => p[0] === ph);
    o.querySelectorAll("[data-ph]").forEach((el, i) => { el.className = i < idx ? "done" : i === idx ? "now" : ""; });
    q("#upd-ver").textContent = s.version ? "auf " + s.version : "";
    let pct = null, sub = " ", step = s.step || "…";
    const m = /(\d+)\s*\/\s*(\d+)/.exec(step);
    if (ph === "download") {
      if (s.total) { pct = s.pct; sub = `${(s.got / 1e6).toFixed(1).replace(".", ",")} von ${(s.total / 1e6).toFixed(1).replace(".", ",")} MB`; step = "Update wird heruntergeladen"; }
      else if (s.got) { sub = (s.got / 1e6).toFixed(1).replace(".", ",") + " MB geladen"; step = "Update wird heruntergeladen"; }
    } else if (m && +m[2] > 0) {
      pct = Math.min(100, Math.round(+m[1] * 100 / +m[2]));
      sub = `${m[1]} von ${m[2]}`;
      step = step.replace(/\s*\d+\s*\/\s*\d+.*/, "");
    }
    q("#upd-step").textContent = step;
    q("#upd-sub").textContent = pct != null ? pct + " %  ·  " + sub : sub;
    const fill = q("#upd-fill");
    fill.parentNode.classList.toggle("busy", pct == null);
    fill.style.width = pct != null ? pct + "%" : "";
  };
  const t = setInterval(async () => {
    try {
      const s = await API.get("/api/swupdate/status");
      if (s.error) { clearInterval(t); o.remove(); toast(s.error, "error", 9000); return; }
      show(s);
      if (s.done) {
        clearInterval(t);
        q("#upd-step").textContent = "Fertig – Raspi-TV " + (s.version || "") + " startet neu …";
        setTimeout(() => location.replace("/#/"), 25000);
      } else if (!s.running) { clearInterval(t); o.remove(); }
    } catch (_) { show({ step: "Raspi-TV startet neu …", done: true }); }
  }, 500);
};

// ======================================================================
// Runde Displays: Seiten wählen und Dauer pro Seite
// ======================================================================
const RoundPages = {
  D1: [[1, "Uhr, Cover oder Fernsehen", "Die Hauptseite: Uhr, bei Musik das Cover, beim Fernsehen die Sendung"], [16, "Wetter", "Temperatur, Regenwahrscheinlichkeit, Höchst- und Tiefstwert"],
       [2, "WLAN", "Signalstärke und Netzname"], [4, "System", "Auslastung, Temperatur, Speicher"]],
  D2: [[1, "Lautstärke", "Erscheint bei jeder Änderung trotzdem kurz"], [2, "Status", "Fehler und Hinweise"], [4, "Updates", "Version und neue Updates; bei einer Installation immer zu sehen"]],
  SECS: [5, 8, 10, 15, 20, 30, 60],
  get() {
    const p = state.config.round_pages;
    return Array.isArray(p) && p.length === 2 ? p.slice() : [23, 7];
  },
  secs() { return this.SECS.includes(state.config.round_page_sec) ? state.config.round_page_sec : 10; },
  open() {
    const { el } = openModal({
      title: "Seiten der runden Displays",
      html: `<p class="desc">Schlaf-Timer, VU-Meter, Titelwechsel und Hinweise erscheinen von selbst, wenn es etwas zu zeigen gibt.</p>
        <h2>Display 1</h2><div class="list" id="rp-1"></div><h2>Display 2</h2><div class="list" id="rp-2"></div>
        <div class="list" id="rp-s" style="margin:1.6vh 0 2vh"></div>`,
      buttons: [{ label: "Fertig", style: "primary" }],
      focus: "#rp-1-0",
    });
    const save = async patch => { try { state.config = await API.post("/api/config", patch); } catch (e) { toast(e.message, "error"); } };
    const draw = keep => {
      const pages = this.get();
      [this.D1, this.D2].forEach((list, d) => {
        el.querySelector("#rp-" + (d + 1)).innerHTML = list.map((p, i) => toggleRow(`rp-${d + 1}-${i}`, ICON.eye || ICON.check, p[1], p[2], !!(pages[d] & p[0]))).join("");
        list.forEach((p, i) => el.querySelector(`#rp-${d + 1}-${i}`).addEventListener("click", async () => {
          const next = this.get();
          next[d] ^= p[0];
          if (!next[d]) return toast("Mindestens eine Seite muss bleiben", "error");
          await save({ round_pages: next });
          draw(`rp-${d + 1}-${i}`);
        }));
      });
      el.querySelector("#rp-s").innerHTML = valueRow("rp-sec", ICON.update || ICON.check, "Wechsel alle", "Wie lange jede Seite zu sehen ist", this.secs() + " Sekunden");
      el.querySelector("#rp-sec").addEventListener("click", async () => {
        await save({ round_page_sec: this.SECS[(this.SECS.indexOf(this.secs()) + 1) % this.SECS.length] });
        draw("rp-sec");
      });
      if (keep) Nav.focus(el.querySelector("#" + keep), false);
    };
    draw();
  },
};

// ======================================================================
// Einstellungen · System: automatische Sicherung auf USB-Stick und Diagnose-Paket
// ======================================================================
(function () {
  const r = ROUTES.system.render;
  ROUTES.system.render = (v, t) => { r(v, t); setTimeout(() => addCareSection(v, t), 0); };
})();
function addCareSection(view, token) {
  const page = view.querySelector(".page");
  if (!page || token !== renderToken || view.querySelector("#care-box")) return;
  const box = document.createElement("div");
  box.id = "care-box";
  page.appendChild(box);
  let a = null, addr = "";
  const mb = n => n >= 1e9 ? (n / 1e9).toFixed(0) + " GB" : (n / 1e6).toFixed(0) + " MB";
  const when = t => t ? new Date(t * 1000).toLocaleString("de-DE", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) : "noch nie";
  async function load() { try { a = await API.get("/api/auto-backup"); draw(); } catch (_) {} }
  async function save(patch) {
    try { state.config = await API.post("/api/config", { auto_backup: patch }); await load(); } catch (e) { toast(e.message, "error"); }
  }
  function draw() {
    if (token !== renderToken || !a) return;
    const key = Nav.current && Nav.current.dataset.key;
    const stickTxt = a.name ? `${a.name}${a.size ? " (" + mb(a.size) + ")" : ""}${a.present ? " – steckt" : " – nicht eingesteckt"}` : "Kein Stick gewählt";
    box.innerHTML = `<h2>Automatische Sicherung</h2><div class="list">
      ${toggleRow("ab-on", ICON.download, "Auf USB-Stick sichern, sobald er steckt", "Einstellungen, Senderliste, Schnellaktionen und WLAN-Zugänge – höchstens einmal am Tag, die letzten 7 Sicherungen bleiben", a.on)}
      ${valueRow("ab-stick", ICON.usb || ICON.download, "Stick", a.sticks.length ? "OK wählt den nächsten eingesteckten Stick" : "Zum Auswählen einen USB-Stick einstecken (FAT32 oder exFAT)", esc(stickTxt))}
      <div class="row static"><span class="icon">${ICON.check}</span><span class="main"><div class="label">Letzte Sicherung: ${esc(when(a.last))}</div>
        <div class="desc">${esc(a.error ? "Fehler: " + a.error : a.last_file || "Wird beim nächsten Einstecken angelegt")}</div></span></div></div>
      <h2>Fehlersuche</h2><div class="list">
      ${valueRow("dg-make", ICON.system, "Diagnose-Paket erstellen", "Protokolle, Versionen, Teensy- und Bluetooth-Status in einer Datei – ohne Passwörter. Zum Weitergeben bei Problemen.", "")}</div>`;
    $("#ab-on").addEventListener("click", () => {
      if (!a.on && !a.name) {
        if (!a.sticks.length) return toast("Bitte zuerst einen USB-Stick einstecken", "error");
        return save({ on: true, name: a.sticks[0].name, size: a.sticks[0].size });
      }
      save({ on: !a.on, name: a.name, size: a.size });
    });
    $("#ab-stick").addEventListener("click", () => {
      if (!a.sticks.length) return toast("Kein USB-Stick eingesteckt", "error");
      const i = a.sticks.findIndex(s => s.name === a.name && s.size === a.size);
      const s = a.sticks[(i + 1) % a.sticks.length];
      save({ on: a.on, name: s.name, size: s.size });
    });
    $("#dg-make").addEventListener("click", makeDiagnose);
    const again = key && view.querySelector(`[data-key="${key}"]`);
    if (again && (!Nav.current || !document.contains(Nav.current))) Nav.focus(again, false);
  }
  async function makeDiagnose() {
    showOverlay("Diagnose-Paket wird erstellt …");
    let r;
    try { r = await API.post("/api/diagnose", {}); }
    catch (e) { document.querySelectorAll(".overlay").forEach(x => x.remove()); return toast(e.message, "error", 7000); }
    document.querySelectorAll(".overlay").forEach(x => x.remove());
    const url = addr ? addr + r.path : "";
    let qr = "";
    if (url && typeof qrcode === "function") { const q = qrcode(0, "M"); q.addData(url); q.make(); qr = q.createSvgTag({ cellSize: 8, margin: 2, scalable: true }); }
    openModal({
      title: "Diagnose-Paket ist fertig",
      html: `<div class="setup-split" style="gap:3vw;align-items:center">
          ${qr ? `<div class="qr" style="width:18vw;background:#fff;padding:.6vw;border-radius:1vw">${qr}</div>` : ""}
          <div>${r.usb ? `<p><b>Auf dem USB-Stick „${esc(r.usb.stick)}“ gespeichert:</b><br>${esc(r.usb.file)}</p>` : ""}
            ${url ? `<p>Am Handy oder PC im selben WLAN laden (${r.minutes} Minuten lang):</p><p class="desc">${esc(url)}</p>` : "<p>Zum Mitnehmen einen USB-Stick einstecken und das Paket noch einmal erstellen.</p>"}
            <p class="desc">Größe: ${(r.size / 1024).toFixed(0)} KB. Enthalten sind Protokolle, Versionen und Einstellungen – Passwörter, PINs und Schlüssel werden ausgeblendet.</p></div></div>`,
      buttons: [{ label: "Fertig", style: "primary" }],
    });
  }
  API.get("/api/remote").then(r => { addr = r.address || ""; }).catch(() => {});
  load();
  pageTimers.push(setInterval(load, 5000));
}

// ======================================================================
// 7.3.2 · Einstellungen · Energie: Pi 5 bleibt aus, wenn der Strom wieder da ist
// ======================================================================
(function () {
  const r = ROUTES.energy.render;
  ROUTES.energy.render = (v, t) => { r(v, t); setTimeout(() => addPowerWaitRow(v, t), 0); };
})();
function addPowerWaitRow(view, token) {
  const page = view.querySelector(".page");
  if (!page || token !== renderToken || view.querySelector("#pw-box")) return;
  const box = document.createElement("div");
  box.id = "pw-box";
  page.appendChild(box);
  let st = null;
  async function load() { try { st = await API.get("/api/power-wait"); draw(); } catch (_) {} }
  function draw() {
    if (token !== renderToken || !st) return;
    const key = Nav.current && Nav.current.dataset.key;
    const desc = !st.supported ? st.reason
      : st.pending ? "Wird beim nächsten Neustart übernommen."
      : "Nach einem Stromausfall oder dem Einschalten der Steckdosenleiste startet der Pi nicht von selbst – erst der Knopf am Pi schaltet ihn ein. Neustarts und Updates laufen weiter automatisch.";
    box.innerHTML = `<h2>Strom</h2><div class="list">${toggleRow("pw-on", ICON.power || ICON.system, "Aus bleiben, wenn der Strom wieder da ist", desc, st.enabled)}</div>`;
    $("#pw-on").addEventListener("click", toggle);
    const again = key && view.querySelector(`[data-key="${key}"]`);
    if (again && (!Nav.current || !document.contains(Nav.current))) Nav.focus(again, false);
  }
  async function toggle() {
    if (!st.supported) return toast(st.reason, "error", 6000);
    const on = !st.enabled;
    if (on && !await confirmDialog("Aus bleiben, wenn der Strom wieder da ist?",
      "Danach schaltet nur noch der Knopf am Raspberry Pi 5 ein – nicht die Fernbedienung, nicht das Handy und nicht der Wecker, solange der Pi ganz aus ist. "
      + "Standby funktioniert wie bisher. Die Einstellung wird im Startprogramm des Pi gespeichert und gilt nach einem Neustart.", "Einschalten", "primary")) return;
    showOverlay("Einstellung wird gespeichert …");
    try { st = await API.post("/api/power-wait", { on }); }
    catch (e) { document.querySelectorAll(".overlay").forEach(x => x.remove()); return toast(e.message, "error", 9000); }
    document.querySelectorAll(".overlay").forEach(x => x.remove());
    draw();
    if (await confirmDialog("Jetzt neu starten?", "Die Einstellung gilt erst nach einem Neustart. Bleibt der Pi dabei aus, einmal den Knopf am Pi drücken.", "Neu starten", "primary"))
      API.post("/api/reboot", {}).catch(e => toast(e.message, "error"));
  }
  load();
}
