/* Raspi-TV 7.4: Weiterschauen für YouTube & Mediatheken, Countdown und Bildschirmschoner der runden
 * Displays, Notfall-Abschaltung bei Stromausfall */
"use strict";

// ======================================================================
// Weiterschauen: angefangene Videos aus YouTube, Mediatheken & Co. (je Profil, vom Pi gemerkt)
// ======================================================================
const WebCont = {
  items: [], loaded: 0,
  async load() {
    try { this.items = (await API.get("/api/continue")).items || []; } catch (_) {}
    this.loaded = Date.now();
    return this.items;
  },
};
(function () {
  const base = renderContinue;
  renderContinue = function (container) {
    if (!container) return;
    const draw = () => {
      base(container);                                 // Sender und eigene Videos (wie bisher)
      const web = WebCont.items.slice(0, 8);
      if (!web.length) return;
      const sec = container.previousElementSibling;
      container.hidden = false; if (sec) sec.hidden = false;
      const html = web.map((it, i) => `<button class="cont-card nav" data-key="cont-w-${esc(it.key)}" data-w="${i}">
          <span class="cont-thumb">${ICON.video}${it.cover ? `<img loading="lazy" alt="" onerror="this.remove()" src="${esc(it.cover)}">` : ""}<em>${esc(it.site || "Web")}</em></span>
          <span class="cont-title">${esc(it.title || it.site || "Video")}</span>
          <span class="cont-sub">Noch ${it.left} Min.</span>
          <span class="bar"><i style="width:${Math.min(100, it.pos / it.dur * 100)}%"></i></span></button>`).join("");
      const live = container.querySelector(".cont-card");
      if (live && live.querySelector(".cont-thumb.live")) {
        // Sender bleiben vorne, angefangene Videos direkt dahinter
        const lastLive = [...container.querySelectorAll(".cont-card")].filter(c => c.querySelector(".cont-thumb.live")).pop();
        lastLive.insertAdjacentHTML("afterend", html);
      } else container.insertAdjacentHTML("afterbegin", html);
      container.querySelectorAll("[data-w]").forEach(el => el.addEventListener("click", () => {
        const it = web[+el.dataset.w];
        showOverlay((it.site || "Video") + " wird geöffnet …");
        setTimeout(() => { location.href = it.open; }, 250);
      }));
      // Lange OK / Menü-Taste: aus der Liste entfernen
      container.querySelectorAll("[data-w]").forEach(el => el.addEventListener("contextmenu", async e => {
        e.preventDefault();
        const it = web[+el.dataset.w];
        if (!await confirmDialog("Aus „Weiterschauen“ entfernen?", it.title || "", "Entfernen", "danger")) return;
        try { WebCont.items = (await API.post("/api/continue/remove", { key: it.key })).items || []; draw(); } catch (e2) { toast(e2.message, "error"); }
      }));
      if (typeof Nav !== "undefined") Nav.refocus();
    };
    draw();
    if (Date.now() - WebCont.loaded > 15000) WebCont.load().then(() => { if (document.contains(container)) draw(); });
  };
})();

// ======================================================================
// Runde Displays: Countdowns und Bildschirmschoner
// ======================================================================
const Countdown = {
  list() { return Array.isArray(state.config.round_countdowns) ? state.config.round_countdowns : []; },
  fmt(c) { const [y, m, d] = c.date.split("-"); return c.yearly ? `${d}.${m}. (jedes Jahr)` : `${d}.${m}.${y}`; },
  parse(text) {
    const m = /^\s*(\d{1,2})\.(\d{1,2})\.(\d{2,4})?\s*$/.exec(text || "");
    if (!m) return null;
    let y = m[3] ? +m[3] : new Date().getFullYear();
    if (y < 100) y += 2000;
    const d = new Date(y, +m[2] - 1, +m[1]);
    if (d.getMonth() !== +m[2] - 1 || d.getDate() !== +m[1]) return null;
    return `${y}-${String(+m[2]).padStart(2, "0")}-${String(+m[1]).padStart(2, "0")}`;
  },
  async save(list) { state.config = await API.post("/api/config", { round_countdowns: list }); },
  manage() {
    const list = this.list();
    const { el, close } = openModal({
      title: "Countdowns",
      html: `<p class="desc">Display 1 zählt die Tage bis zum nächsten Termin herunter – z. B. Urlaub, Geburtstag oder Silvester. Am Tag selbst gibt es ein kleines Feuerwerk.</p>
        <div class="list" style="margin-bottom:2vh">${list.map((c, i) => valueRow("cd-" + i, ICON.calendar || ICON.check, esc(c.name), esc(this.fmt(c)), "Ändern")).join("")}
        ${list.length < 8 ? valueRow("cd-new", ICON.plus || ICON.check, "Neuer Countdown", "Name und Datum eingeben", "") : ""}</div>`,
      buttons: [{ label: "Fertig", style: "primary" }],
      focus: list.length ? "#cd-0" : "#cd-new",
    });
    list.forEach((c, i) => el.querySelector("#cd-" + i).addEventListener("click", () => { close(); this.edit(i); }));
    const n = el.querySelector("#cd-new");
    if (n) n.addEventListener("click", () => { close(); this.edit(-1); });
  },
  edit(index) {
    const list = this.list().map(c => Object.assign({}, c));
    const c = index >= 0 ? list[index] : { name: "", date: "", yearly: false };
    const [y, m, d] = (c.date || "--").split("-");
    let yearly = !!c.yearly;
    const { el } = openModal({
      title: index >= 0 ? "Countdown ändern" : "Neuer Countdown",
      html: `<label for="cd-name">Name</label><input class="field nav" id="cd-name" data-key="cd-name" maxlength="24" value="${esc(c.name)}" placeholder="z. B. Urlaub" autocomplete="off">
        <label for="cd-date">Datum (TT.MM.JJJJ)</label><input class="field nav" id="cd-date" data-key="cd-date" maxlength="10" value="${c.date ? `${d}.${m}.${y}` : ""}" placeholder="24.12.2026" autocomplete="off" inputmode="numeric">
        <div class="list" id="cd-y" style="margin:1.4vh 0 2vh"></div>`,
      focus: "#cd-name",
      buttons: [
        { label: "Speichern", style: "primary", action: async close => {
          const name = el.querySelector("#cd-name").value.trim().slice(0, 24);
          const date = this.parse(el.querySelector("#cd-date").value);
          if (!name) return toast("Bitte einen Namen eingeben", "error");
          if (!date) return toast("Bitte das Datum als TT.MM.JJJJ eingeben, z. B. 24.12.2026", "error");
          const item = { name, date, yearly };
          if (index >= 0) list[index] = item; else list.push(item);
          try { await this.save(list); close(); this.manage(); } catch (e) { toast(e.message, "error"); }
        } },
        ...(index >= 0 ? [{ label: "Löschen", style: "danger", action: async close => {
          list.splice(index, 1);
          try { await this.save(list); close(); this.manage(); } catch (e) { toast(e.message, "error"); }
        } }] : []),
        { label: "Abbrechen", action: close => { close(); this.manage(); } },
      ],
    });
    const drawY = keep => {
      el.querySelector("#cd-y").innerHTML = toggleRow("cd-yearly", ICON.update || ICON.check, "Jedes Jahr", "Für Geburtstage und Feiertage – zählt danach zum nächsten Jahr weiter", yearly);
      el.querySelector("#cd-yearly").addEventListener("click", () => { yearly = !yearly; drawY(true); });
      if (keep) Nav.focus(el.querySelector("#cd-yearly"), false);
    };
    drawY();
  },
};

(function () {
  if (typeof RoundPages === "undefined") return;
  RoundPages.D1.push([32, "Countdown", "Tage bis zum nächsten Termin (Termine unter „Countdowns“)"]);
  RoundPages.D1.push([64, "Heute", "Wochentag, Datum, Kalenderwoche, Sonnenauf- und -untergang"],
                     [128, "Netz", "Internet erreichbar? Antwortzeit und IP-Adresse"]);
})();

// Knöpfe in Einstellungen · Runde Displays
(function () {
  const SAVER = [0, 5, 10, 15, 30, 60];
  const label = () => {
    const m = SAVER.includes(state.config.round_saver_min) ? state.config.round_saver_min : 0;
    return "Bildschirmschoner: " + (m ? "nach " + m + " Min." : "Aus");
  };
  const obs = new MutationObserver(() => {
    const pages = document.querySelector("#rd-pages");
    if (!pages || document.querySelector("#rd-cd")) return;
    pages.insertAdjacentHTML("afterend", `<button class="btn nav" data-key="rd-cd" id="rd-cd">Countdowns</button>
      <button class="btn nav" data-key="rd-saver" id="rd-saver">${label()}</button>`);
    const cd = document.querySelector("#rd-cd"), sv = document.querySelector("#rd-saver");
    cd.hidden = sv.hidden = pages.hidden;
    cd.onclick = () => Countdown.manage();
    sv.onclick = async () => {
      const cur = SAVER.includes(state.config.round_saver_min) ? state.config.round_saver_min : 0;
      try {
        state.config = await API.post("/api/config", { round_saver_min: SAVER[(SAVER.indexOf(cur) + 1) % SAVER.length] });
        sv.textContent = label();
        if (state.config.round_saver_min) toast("Ohne Bedienung und ohne Musik zeigen die Displays nach dieser Zeit nur noch ruhige, wandernde Lichter", "ok", 6000);
      } catch (e) { toast(e.message, "error"); }
    };
  });
  obs.observe(document.body, { childList: true, subtree: true });
})();

// ======================================================================
// Einstellungen · Energie: Notfall-Abschaltung bei Stromausfall
// ======================================================================
(function () {
  const r = ROUTES.energy.render;
  ROUTES.energy.render = (v, t) => { r(v, t); setTimeout(() => addPowerFailRows(v, t), 0); };
})();
function addPowerFailRows(view, token) {
  const page = view.querySelector(".page");
  if (!page || token !== renderToken || view.querySelector("#pf-box")) return;
  const box = document.createElement("div");
  box.id = "pf-box";
  page.appendChild(box);
  let st = null;
  const PINS = [4, 5, 6, 12, 13, 16, 17, 22, 23, 24, 25, 27];
  const pinLabel = n => `GPIO ${n} (Stift ${{ 4: 7, 5: 29, 6: 31, 12: 32, 13: 33, 16: 36, 17: 11, 22: 15, 23: 16, 24: 18, 25: 22, 27: 13 }[n]})`;
  async function load() { try { st = await API.get("/api/powerfail"); draw(); } catch (_) {} }
  async function save(patch) {
    const cur = { on: st.on, pin: st.pin, lost: st.lost, pull: st.pull, source: st.source, fast: st.fast };
    if (st.v_mains) cur.v_mains = st.v_mains;
    if (st.v_batt) cur.v_batt = st.v_batt;
    try { state.config = await API.post("/api/config", { powerfail: Object.assign(cur, patch) }); await load(); } catch (e) { toast(e.message, "error"); }
  }
  function draw() {
    if (token !== renderToken || !st) return;
    const key = Nav.current && Nav.current.dataset.key;
    const V = st.source === "voltage";
    const fmtV = v => v ? v.toFixed(2).replace(".", ",") + " V" : "–";
    const learned = st.v_mains && st.v_batt && st.v_mains - st.v_batt >= 0.08;
    const live = !st.on ? "" : st.error ? "Fehler: " + st.error
      : V && !st.service ? "Der Wächter startet gerade …"
      : V && st.need_learn ? "Erst einmessen (Netzteil und Akku)"
      : V ? `Gerade ${fmtV(st.volt)} – ${st.power === false ? "Strom weg!" : "Strom da"} (Schwelle ${fmtV(st.threshold)})${st.armed ? " · scharf" : " · wird gleich scharf"}`
      : !st.service ? "Der Wächter startet gerade …"
      : st.power === false ? (st.armed ? "Meldet gerade: Strom weg!" : "Meldet „Strom weg“ – noch nicht scharf. Einstellungen prüfen: so würde der Pi nie abschalten.")
      : `Meldet gerade: Strom da (Pin ist ${st.level === "high" ? "HIGH" : "LOW"})${st.armed ? " · scharf" : " · wird gleich scharf"}`;
    const clash = st.gpio_pins_used.includes(st.pin);
    const L = st.learn || {};
    const learnRows = V ? valueRow("pf-src", ICON.system, "Erkennung", "Ohne Kabel: der Pi 5 misst seine Eingangsspannung selbst. Läuft er nur noch auf dem Akku-Modul, sinkt sie.", "Spannung")
        + valueRow("pf-vm", ICON.power || ICON.system, "1. Mit Netzteil einmessen", L.which === "mains" ? L.msg : "Netzteil steckt am Modul, OK drücken", st.v_mains ? fmtV(st.v_mains) : "Noch nicht")
        + valueRow("pf-vb", ICON.warn, "2. Nur mit Akku einmessen", L.which === "batt" ? L.msg : "OK drücken, dann das Netzteil abziehen. Danach innerhalb einer Minute wieder einstecken.", st.v_batt ? fmtV(st.v_batt) : "Noch nicht")
        + (L.phase === "done" || L.phase === "error" ? `<div class="row static"><span class="icon">${L.phase === "error" ? ICON.warn : ICON.check}</span><span class="main"><div class="label">${esc(L.msg)}</div></span></div>` : "")
        + `<div class="row static"><span class="icon">${ICON.system}</span><span class="main"><div class="label">Gerade gemessen: ${fmtV(st.volt)}</div>
           <div class="desc">${learned ? `Unter ${fmtV((st.v_mains + st.v_batt) / 2)} gilt der Strom als weg (eine halbe Sekunde lang)` : "Erst beide Werte einmessen"}</div></span></div>`
      : valueRow("pf-src", ICON.system, "Erkennung", "Über ein Signal an einem GPIO-Pin (USV-Aufsatz oder Spannungsteiler am Netzteil)", "GPIO-Pin");
    box.innerHTML = `<h2>Stromausfall</h2><div class="list">
      ${toggleRow("pf-on", ICON.power || ICON.system, "Notfall-Abschaltung", "Braucht eine Notstromversorgung (Akku-Modul, USV-Aufsatz oder Kondensator-Modul), die den Pi noch einige Sekunden versorgt. Raspi-TV merkt den Ausfall, schreibt sofort alles auf die Karte und fährt herunter.", st.on)}
      ${learnRows}
      ${valueRow("pf-fast", ICON.power || ICON.system, "Abschalten", st.fast
        ? "Für Akku-Module, die den Pi nur kurz halten: alles auf die Karte schreiben und in unter 1 Sekunde aus"
        : "Normales Herunterfahren – dauert 5 bis 15 Sekunden, braucht eine Notstromversorgung, die so lange durchhält", st.fast ? "Blitzschnell" : "Normal")}
      ${V ? (st.on ? `<div class="row static"><span class="icon">${ICON.check}</span><span class="main"><div class="label">${esc(live)}</div></span></div>` : "")
        : st.on ? valueRow("pf-pin", ICON.system, "Signal-Pin", clash ? "Achtung: dieser Pin ist schon belegt" : "An diesem Pin meldet die Notstromversorgung den Ausfall", pinLabel(st.pin))
        + valueRow("pf-lost", ICON.warn, "Strom weg bedeutet", "Steht in der Anleitung der Notstromversorgung", st.lost === "low" ? "Pin LOW" : "Pin HIGH")
        + valueRow("pf-pull", ICON.system, "Widerstand", "„Nach oben“ passt für die meisten Module (offener Kollektor)", { up: "Nach oben (3,3 V)", down: "Nach unten (GND)", none: "Keiner" }[st.pull])
        + `<div class="row static"><span class="icon">${ICON.check}</span><span class="main"><div class="label">${esc(live)}</div>
           <div class="desc">Zum Testen: Netzteil der Notstromversorgung kurz ziehen – hier muss „Strom weg“ erscheinen (danach fährt der Pi herunter).</div></span></div>` : ""}
      </div>`;
    $("#pf-fast").addEventListener("click", () => save({ fast: !st.fast }));
    $("#pf-src").addEventListener("click", () => save({ source: V ? "gpio" : "voltage" }));
    if (V) {
      $("#pf-vm").addEventListener("click", async () => { try { st = await API.post("/api/powerfail/learn", { which: "mains" }); draw(); } catch (e) { toast(e.message, "error"); } });
      $("#pf-vb").addEventListener("click", async () => {
        if (!st.v_mains) { toast("Zuerst mit Netzteil einmessen", "error"); return; }
        try { st = await API.post("/api/powerfail/learn", { which: "batt" }); draw(); } catch (e) { toast(e.message, "error"); }
      });
    }
    $("#pf-on").addEventListener("click", async () => {
      if (!st.on && V && !learned) { toast("Erst mit Netzteil und mit Akku einmessen", "error"); return; }
      if (!st.on && !V && !await confirmDialog("Notfall-Abschaltung einschalten?",
        "Nur einschalten, wenn wirklich eine Notstromversorgung am Signal-Pin hängt. Ohne Modul kann ein offener Pin „Strom weg“ melden – dann fährt der Pi sofort herunter.", "Einschalten", "primary")) return;
      save({ on: !st.on });
    });
    if (st.on && !V) {
      $("#pf-pin").addEventListener("click", () => save({ pin: PINS[(PINS.indexOf(st.pin) + 1) % PINS.length] }));
      $("#pf-lost").addEventListener("click", () => save({ lost: st.lost === "low" ? "high" : "low" }));
      $("#pf-pull").addEventListener("click", () => save({ pull: { up: "down", down: "none", none: "up" }[st.pull] }));
    }
    const again = key && view.querySelector(`[data-key="${key}"]`);
    if (again && (!Nav.current || !document.contains(Nav.current))) Nav.focus(again, false);
  }
  load();
  pageTimers.push(setInterval(load, 1000));
}
