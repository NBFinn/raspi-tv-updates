/* Raspi-TV 7.5: abends dunklere runde Displays, Verlauf von Temperatur und Strom, Startzeit, Fernwartung */
"use strict";

// Startzeit: die Oberfläche meldet, dass sie bereit ist (einmal pro Systemstart zählt)
setTimeout(() => { API.post("/api/boot/ready", {}).catch(() => {}); }, 300);

const fmtNum = (v, d = 1) => (v == null ? "–" : Number(v).toFixed(d).replace(".", ","));

// ======================================================================
// Runde Displays: abends automatisch dunkler
// ======================================================================
const NightDim = {
  FROM: ["19:00", "20:00", "21:00", "22:00", "23:00"], TO: ["05:00", "06:00", "07:00", "08:00", "09:00"],
  LEVEL: [10, 20, 30, 40, 50, 60],
  cur() { return Object.assign({ on: false, from: "21:00", to: "07:00", level: 30 }, state.config.round_night_dim || {}); },
  label() { const n = this.cur(); return "Abends dunkler: " + (n.on ? `${n.from}–${n.to} Uhr, ${n.level} %` : "Aus"); },
  open(onChange) {
    const next = (list, v) => list[(list.indexOf(v) + 1) % list.length];
    const { el } = openModal({
      title: "Abends dunkler",
      html: `<p class="desc">Die runden Displays werden ab der gewählten Uhrzeit über 20 Minuten langsam dunkler und morgens wieder heller.</p><div class="list" id="nd-rows" style="margin-bottom:2vh"></div>`,
      buttons: [{ label: "Fertig", style: "primary" }],
      focus: "#nd-on",
    });
    const save = async patch => {
      try { state.config = await API.post("/api/config", { round_night_dim: Object.assign(this.cur(), patch) }); if (onChange) onChange(); }
      catch (e) { toast(e.message, "error"); }
    };
    const draw = keep => {
      const n = this.cur();
      el.querySelector("#nd-rows").innerHTML = toggleRow("nd-on", ICON.moon || ICON.eye || ICON.check, "Abends dunkler", "Gilt für beide runden Displays", n.on)
        + (n.on ? valueRow("nd-from", ICON.update || ICON.check, "Ab", "Ab dann wird es langsam dunkler", n.from + " Uhr")
          + valueRow("nd-to", ICON.update || ICON.check, "Bis", "Danach wieder normale Helligkeit", n.to + " Uhr")
          + valueRow("nd-level", ICON.eye || ICON.check, "Helligkeit nachts", "Höchstens so hell", n.level + " %") : "");
      const on = (id, fn) => { const b = el.querySelector("#" + id); if (b) b.addEventListener("click", async () => { await fn(); draw(id); }); };
      on("nd-on", () => save({ on: !n.on }));
      on("nd-from", () => save({ from: next(this.FROM, n.from) }));
      on("nd-to", () => save({ to: next(this.TO, n.to) }));
      on("nd-level", () => save({ level: next(this.LEVEL, n.level) }));
      if (keep) Nav.focus(el.querySelector("#" + keep), false);
    };
    draw();
  },
};
(function () {
  const obs = new MutationObserver(() => {
    const after = document.querySelector("#rd-saver");
    if (!after || document.querySelector("#rd-night")) return;
    after.insertAdjacentHTML("afterend", `<button class="btn nav" data-key="rd-night" id="rd-night">${esc(NightDim.label())}</button>`);
    const b = document.querySelector("#rd-night");
    b.hidden = after.hidden;
    b.onclick = () => NightDim.open(() => { b.textContent = NightDim.label(); });
  });
  obs.observe(document.body, { childList: true, subtree: true });
})();

// ======================================================================
// Einstellungen · System: Verlauf (Temperatur, Auslastung, Strom), Startzeit, Fernwartung
// ======================================================================
(function () {
  const r = ROUTES.system.render;
  ROUTES.system.render = (v, t) => { r(v, t); setTimeout(() => { addHealthSection(v, t); addSupportSection(v, t); }, 0); };
})();

function healthChart(h) {
  const W = 1000, H = 220, pad = 34, pts = h.points || [];
  if (pts.length < 2) return `<p class="desc">Noch zu wenige Messwerte – der Verlauf füllt sich jede Minute.</p>`;
  const t0 = pts[0].t, t1 = pts[pts.length - 1].t || t0 + 1;
  const x = t => pad + (W - pad * 2) * (t - t0) / Math.max(1, t1 - t0);
  const yT = v => H - pad - (H - pad * 2) * Math.max(0, Math.min(1, (v - 30) / 55));      // 30–85 °C
  const yC = v => H - pad - (H - pad * 2) * Math.max(0, Math.min(1, v / 100));
  const line = (key, y) => pts.filter(p => p[key] != null).map((p, i) => (i ? "L" : "M") + x(p.t).toFixed(1) + " " + y(p[key]).toFixed(1)).join(" ");
  const uv = pts.filter(p => p.uv).map(p => `<rect x="${(x(p.t) - 2).toFixed(1)}" y="${pad}" width="4" height="${H - pad * 2}" fill="#ef4444" opacity=".55"/>`).join("");
  const grid = [40, 60, 80].map(v => `<line x1="${pad}" x2="${W - pad}" y1="${yT(v)}" y2="${yT(v)}" stroke="rgba(255,255,255,.08)"/><text x="${pad - 6}" y="${yT(v) + 4}" text-anchor="end">${v}°</text>`).join("");
  const fmt = t => new Date(t * 1000).toLocaleString("de-DE", h.hours > 30 ? { weekday: "short", hour: "2-digit" } : { hour: "2-digit", minute: "2-digit" });
  return `<svg class="hist" viewBox="0 0 ${W} ${H}" role="img" aria-label="Verlauf Temperatur und Auslastung">
      ${grid}${uv}
      <path d="${line("cpu", yC)}" fill="none" stroke="#60a5fa" stroke-width="2" opacity=".75"/>
      <path d="${line("temp", yT)}" fill="none" stroke="#f59e0b" stroke-width="3"/>
      <text x="${pad}" y="${H - 8}">${esc(fmt(t0))}</text><text x="${W - pad}" y="${H - 8}" text-anchor="end">${esc(fmt(t1))}</text>
    </svg>
    <div class="hist-legend"><span><i style="background:#f59e0b"></i>Temperatur</span><span><i style="background:#60a5fa"></i>Auslastung</span><span><i style="background:#ef4444"></i>Unterspannung</span></div>`;
}

function addHealthSection(view, token) {
  const page = view.querySelector(".page");
  if (!page || token !== renderToken || view.querySelector("#hist-box")) return;
  const box = document.createElement("div");
  box.id = "hist-box";
  page.appendChild(box);
  let hours = 24, h = null, b = null;
  async function load() {
    try { [h, b] = await Promise.all([API.get("/api/health?h=" + hours), API.get("/api/boot")]); draw(); } catch (_) {}
  }
  function draw() {
    if (token !== renderToken || !h) return;
    const key = Nav.current && Nav.current.dataset.key;
    const last = b && b.last;
    const uvTxt = h.undervoltage_minutes ? `<b style="color:#f87171">Unterspannung: ${h.undervoltage_minutes} Min.</b> – Netzteil oder Kabel ist zu schwach`
      : "Keine Unterspannung";
    const thrTxt = h.throttled_minutes ? `, gedrosselt: ${h.throttled_minutes} Min. (zu heiß oder zu wenig Strom)` : "";
    const boot = last ? `Oberfläche nach <b>${fmtNum(last.ui)} s</b> bereit · Kernel ${fmtNum(last.kernel)} s · System ${fmtNum(last.userspace)} s · Raspi-TV-Dienst bei ${fmtNum(last.ctl)} s`
      : "Wird beim nächsten Start gemessen";
    const slow = last && last.slow && last.slow.length
      ? last.slow.slice(0, 5).map(s => `${esc(s.unit.replace(/\.service$/, ""))} ${fmtNum(s.sec)} s`).join(" · ") : "";
    const tuned = b && b.tuned && b.tuned.length ? "Abgeschaltet, weil unnötig: " + b.tuned.map(t => esc(t.unit.replace(/\.service$/, ""))).join(", ") : "";
    box.innerHTML = `<h2>Verlauf</h2>
      <div class="card hist-card">
        <div class="hist-head"><span>${esc(hours > 24 ? "Letzte 7 Tage" : "Letzte 24 Stunden")} · höchstens ${fmtNum(h.max_temp)} °C · ${uvTxt}${thrTxt}</span>
          <button class="btn nav" data-key="hist-range" id="hist-range">${hours > 24 ? "24 Stunden zeigen" : "7 Tage zeigen"}</button></div>
        ${healthChart(h)}
      </div>
      <h2>Startzeit</h2><div class="list">
        <div class="row static"><span class="icon">${ICON.update || ICON.check}</span><span class="main"><div class="label">${boot}</div>
          <div class="desc">${slow ? "Am längsten beim Start: " + slow : ""}${slow && tuned ? "<br>" : ""}${tuned}</div></span></div></div>`;
    $("#hist-range").addEventListener("click", () => { hours = hours > 24 ? 24 : 168; load(); });
    const again = key && view.querySelector(`[data-key="${key}"]`);
    if (again && (!Nav.current || !document.contains(Nav.current))) Nav.focus(again, false);
  }
  load();
  pageTimers.push(setInterval(load, 60000));
}

function addSupportSection(view, token) {
  const page = view.querySelector(".page");
  if (!page || token !== renderToken || view.querySelector("#fw-box")) return;
  const box = document.createElement("div");
  box.id = "fw-box";
  page.appendChild(box);
  let s = null;
  async function load() { try { s = await API.get("/api/support"); draw(); } catch (_) {} }
  async function save(patch) {
    try { state.config = await API.post("/api/config", { support: Object.assign({ on: s.on, repo: s.repo, auto: s.auto }, patch) }); await load(); }
    catch (e) { toast(e.message, "error", 6000); }
  }
  const when = t => new Date(t * 1000).toLocaleString("de-DE", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
  function ask(title, desc, value, type, done) {
    const { el, close } = openModal({
      title, html: `<p class="desc">${desc}</p><input class="field nav" id="fw-in" data-key="fw-in" type="${type}" value="${esc(value)}" autocomplete="off" spellcheck="false" style="margin-bottom:2vh">`,
      focus: "#fw-in",
      buttons: [{ label: "Speichern", style: "primary", action: async c => { if (await done(el.querySelector("#fw-in").value.trim()) !== false) c(); } },
                { label: "Abbrechen" }],
    });
    return { el, close };
  }
  function draw() {
    if (token !== renderToken || !s) return;
    const key = Nav.current && Nav.current.dataset.key;
    const last = s.last ? `Zuletzt gesendet: ${when(s.last.at)} (${esc(s.last.reason)})` : "Noch nichts gesendet";
    box.innerHTML = `<h2>Fernwartung</h2><div class="list">
      ${toggleRow("fw-on", ICON.system, "Fernwartung", "Raspi-TV lädt bei Problemen das Diagnose-Paket (ohne Passwörter) in dein privates GitHub-Repository – so kann es ohne USB-Stick ausgewertet werden.", s.on)}
      ${s.on ? valueRow("fw-repo", ICON.download, "Repository", "Privates Repository, z. B. NBFinn/raspi-tv-diagnose", esc(s.repo || "Nicht eingetragen"))
        + valueRow("fw-token", ICON.lock || ICON.system, "Zugangsschlüssel", "Feinkörniger GitHub-Schlüssel nur für dieses Repository, Recht „Contents: Read and write“", s.has_token ? "Eingetragen" : "Fehlt")
        + toggleRow("fw-auto", ICON.warn, "Bei Fehlern automatisch senden", "Nach einem fehlerhaften Update, bei einem Teensy-Absturz oder wenn ein Raspi-TV-Dienst ausfällt – höchstens alle 6 Stunden", s.auto)
        + valueRow("fw-send", ICON.download, "Jetzt senden", esc(last), "") : ""}</div>`;
    $("#fw-on").addEventListener("click", () => save({ on: !s.on, repo: s.repo || "NBFinn/raspi-tv-diagnose" }));
    if (s.on) {
      $("#fw-repo").addEventListener("click", () => ask("Repository", "Name wie auf GitHub: Besitzer/Repository. Das Repository muss privat sein.", s.repo || "NBFinn/raspi-tv-diagnose", "text",
        async v => { if (!/^[\w.-]+\/[\w.-]+$/.test(v)) { toast("Bitte als Besitzer/Repository eingeben", "error"); return false; } await save({ repo: v }); }));
      $("#fw-token").addEventListener("click", () => ask("Zugangsschlüssel", "Den Schlüssel am besten mit der Handy-App-Tastatur eintippen oder einfügen. Er wird nur auf dem Raspberry Pi gespeichert und nie wieder angezeigt. Leer lassen und speichern löscht ihn.", "", "password",
        async v => { try { s = await API.post("/api/support/token", { token: v }); draw(); toast(v ? "Zugangsschlüssel gespeichert" : "Zugangsschlüssel gelöscht", "ok"); } catch (e) { toast(e.message, "error", 7000); return false; } }));
      $("#fw-auto").addEventListener("click", () => save({ auto: !s.auto }));
      $("#fw-send").addEventListener("click", async () => {
        showOverlay("Diagnose-Paket wird gesendet …");
        try { const r = await API.post("/api/support/send", { reason: "manuell" }); toast(`Gesendet (${Math.round(r.size / 1024)} KB)`, "ok", 5000); }
        catch (e) { toast(e.message, "error", 8000); }
        document.querySelectorAll(".overlay").forEach(x => x.remove());
        load();
      });
    }
    const again = key && view.querySelector(`[data-key="${key}"]`);
    if (again && (!Nav.current || !document.contains(Nav.current))) Nav.focus(again, false);
  }
  load();
}
