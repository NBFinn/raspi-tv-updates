/* Raspi-TV 7.7: Fernseher-Erkennung – merkt, wenn der Fernseher ausgeht, und geht dann selbst in Standby */

// ======================================================================
// Einstellungen · Energie: „Mit dem Fernseher in Standby“
// ======================================================================
(function () {
  const r = ROUTES.energy.render;
  ROUTES.energy.render = (v, t) => { r(v, t); setTimeout(() => addTvDetectRows(v, t), 0); };
})();
function addTvDetectRows(view, token) {
  const page = view.querySelector(".page");
  if (!page || token !== renderToken || view.querySelector("#td-box")) return;
  const box = document.createElement("div");
  box.id = "td-box";
  const sig = view.querySelector("#sig-box");
  if (sig) sig.after(box); else page.appendChild(box);
  let s = null;
  const PINS = [4, 5, 6, 12, 13, 16, 17, 22, 23, 24, 25, 27];
  const STIFT = { 4: 7, 5: 29, 6: 31, 12: 32, 13: 33, 16: 36, 17: 11, 22: 15, 23: 16, 24: 18, 25: 22, 27: 13 };
  const DELAYS = [10, 20, 30, 60, 120];
  const NAMES = { hdmi: "HDMI-Leitung", cec: "HDMI-CEC", gpio: "USB-Strom vom Fernseher", shelly: "Steckdose mit Strommessung" };
  const when = t => new Date(t * 1000).toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
  async function load() { try { s = await API.get("/api/tv-detect"); draw(); } catch (_) {} }
  async function save(patch) {
    const cur = { auto_standby: s.auto_standby, wake: s.wake, delay: s.delay, gpio: s.gpio, shelly: s.shelly };
    try { state.config = await API.post("/api/config", { tv_detect: Object.assign(cur, patch) }); await load(); }
    catch (e) { toast(e.message, "error", 6000); }
  }
  function srcLine(name) {
    const x = s.sources[name];
    if (x.error) return { val: "Fehler", desc: x.error };
    if (!x.state) {
      const off = { gpio: !s.gpio.on, shelly: !s.shelly.host }[name];
      return { val: off ? "Nicht eingerichtet" : "Keine Antwort", desc: x.detail || (name === "cec" ? "Der Fernseher antwortet nicht auf CEC-Abfragen" : "") };
    }
    const now = x.state === "on" ? "Fernseher an" : "Fernseher aus";
    return { val: now, desc: (x.detail ? x.detail + " · " : "") + (x.seen_change ? "Hat das Aus- und Einschalten schon erkannt" : "Zum Testen: Fernseher mit seiner Fernbedienung ausschalten, nach einer halben Minute wieder an – dann hier schauen") };
  }
  function ask(title, desc, value, done) {
    const { el } = openModal({
      title, html: `<p class="desc">${desc}</p><input class="field nav" id="td-in" data-key="td-in" type="text" value="${esc(value)}" autocomplete="off" spellcheck="false" style="margin-bottom:2vh">`,
      focus: "#td-in",
      buttons: [{ label: "Speichern", style: "primary", action: async c => { if (await done(el.querySelector("#td-in").value.trim()) !== false) c(); } },
                { label: "Abbrechen" }],
    });
  }
  function draw() {
    if (token !== renderToken || !s) return;
    const key = Nav.current && Nav.current.dataset.key;
    const anyWorks = Object.values(s.sources).some(x => x.seen_change);
    const rows = ["hdmi", "cec", "gpio", "shelly"].map(n => {
      const l = srcLine(n);
      return `<div class="row static"><span class="icon">${s.sources[n].seen_change ? ICON.check : ICON.tv || ICON.system}</span>
        <span class="main"><div class="label">${esc(NAMES[n])}</div><div class="desc">${esc(l.desc)}</div></span>
        <span class="value">${esc(l.val)}${s.sources[n].seen_change ? " ✓" : ""}</span></div>`;
    }).join("");
    const clash = s.gpio.on && s.gpio_pins_used.includes(s.gpio.pin);
    const events = s.events.length ? s.events.slice(0, 4).map(e => `${when(e.at)} ${e.text}`).join(" · ") : "Noch nichts erkannt";
    box.innerHTML = `<h2>Mit dem Fernseher in Standby</h2><div class="list">
      ${toggleRow("td-auto", ICON.power || ICON.moon, "Raspi-TV geht mit dem Fernseher aus",
        "Wird der Fernseher mit seiner eigenen Fernbedienung ausgeschaltet, geht Raspi-TV kurz danach auch in Standby (Wiedergabe stoppt, Bild aus).", s.auto_standby)}
      ${toggleRow("td-wake", ICON.sun || ICON.power, "Und wacht mit ihm wieder auf", "Fernseher an → Raspi-TV ist sofort wieder da", s.wake)}
      ${valueRow("td-delay", ICON.clock || ICON.system, "Warten bis Standby", "So lange muss der Fernseher aus sein (verhindert Fehlalarm beim Umschalten)", s.delay + " s")}
      </div>
      <h2>Woran Raspi-TV es merkt</h2><div class="list">${rows}
      <div class="row static"><span class="icon">${anyWorks ? ICON.check : ICON.warn}</span><span class="main"><div class="label">${anyWorks ? "Erkennung funktioniert" : "Noch nicht getestet"}</div>
        <div class="desc">${esc(events)}</div></span></div>
      ${toggleRow("td-gpio", ICON.system, "USB-Strom des Fernsehers an GPIO", "Sicherste Methode ohne CEC: 5 V vom USB-Anschluss des Fernsehers über einen Optokoppler (z. B. PC817 mit 1 kΩ) an einen GPIO-Pin. Viele Fernseher schalten den USB-Strom im Standby ab.", s.gpio.on)}
      ${s.gpio.on ? valueRow("td-pin", ICON.system, "Pin", clash ? "Achtung: dieser Pin ist schon belegt" : "Ausgang des Optokopplers", `GPIO ${s.gpio.pin} (Stift ${STIFT[s.gpio.pin]})`)
        + valueRow("td-level", ICON.system, "Fernseher an bedeutet", "Optokoppler gegen GND: „LOW“ und Widerstand „nach oben“", s.gpio.on_level === "high" ? "Pin HIGH" : "Pin LOW")
        + valueRow("td-pull", ICON.system, "Widerstand", "", { up: "Nach oben (3,3 V)", down: "Nach unten (GND)", none: "Keiner" }[s.gpio.pull]) : ""}
      ${valueRow("td-shelly", ICON.wifi || ICON.system, "Shelly-Steckdose", "Steckdose mit Strommessung am Fernseher (Shelly Plug S / Plus Plug S): IP-Adresse eintragen", esc(s.shelly.host || "Keine"))}
      ${s.shelly.host ? valueRow("td-watts", ICON.power || ICON.system, "Fernseher an ab", "Im Standby braucht ein Fernseher meist unter 1 W, eingeschaltet 30–150 W", s.shelly.watts + " W") : ""}
      </div>`;
    $("#td-auto").addEventListener("click", () => save({ auto_standby: !s.auto_standby }));
    $("#td-wake").addEventListener("click", () => save({ wake: !s.wake }));
    $("#td-delay").addEventListener("click", () => save({ delay: DELAYS[(DELAYS.indexOf(s.delay) + 1) % DELAYS.length] }));
    $("#td-gpio").addEventListener("click", () => save({ gpio: Object.assign({}, s.gpio, { on: !s.gpio.on }) }));
    if (s.gpio.on) {
      $("#td-pin").addEventListener("click", () => save({ gpio: Object.assign({}, s.gpio, { pin: PINS[(PINS.indexOf(s.gpio.pin) + 1) % PINS.length] }) }));
      $("#td-level").addEventListener("click", () => save({ gpio: Object.assign({}, s.gpio, { on_level: s.gpio.on_level === "high" ? "low" : "high" }) }));
      $("#td-pull").addEventListener("click", () => save({ gpio: Object.assign({}, s.gpio, { pull: { up: "down", down: "none", none: "up" }[s.gpio.pull] }) }));
    }
    $("#td-shelly").addEventListener("click", () => ask("Shelly-Steckdose", "IP-Adresse oder Name der Steckdose im WLAN, z. B. 192.168.1.50. Leer lassen und speichern = nicht benutzen.", s.shelly.host,
      async v => { if (v && !/^[A-Za-z0-9.\-]+(:\d{1,5})?$/.test(v)) { toast("Bitte nur die Adresse eingeben, z. B. 192.168.1.50", "error"); return false; } await save({ shelly: Object.assign({}, s.shelly, { host: v }) }); }));
    const w = $("#td-watts");
    if (w) w.addEventListener("click", () => { const L = [5, 10, 15, 25, 40]; save({ shelly: Object.assign({}, s.shelly, { watts: L[(L.indexOf(s.shelly.watts) + 1) % L.length] }) }); });
    const again = key && view.querySelector(`[data-key="${key}"]`);
    if (again && (!Nav.current || !document.contains(Nav.current))) Nav.focus(again, false);
  }
  load();
  pageTimers.push(setInterval(load, 3000));
}
