/* Raspi-TV 7.8: Ton angleichen, Stimmen hervorheben, Bluetooth-Tonausgleich, Pflege und Heimnetz-Schutz */

// ======================================================================
// Einstellungen · Ton
// ======================================================================
(function () {
  const r = ROUTES.sound.render;
  ROUTES.sound.render = (v, t) => { r(v, t); setTimeout(() => addSoundFxRows(v, t), 0); };
  const s = ROUTES.system.render;
  ROUTES.system.render = (v, t) => { s(v, t); setTimeout(() => addCareRows(v, t), 0); };
})();

function _v78Keep(view, key) {
  const again = key && view.querySelector(`[data-key="${key}"]`);
  if (again && (!Nav.current || !document.contains(Nav.current))) Nav.focus(again, false);
}

function addSoundFxRows(view, token) {
  const page = view.querySelector(".page");
  if (!page || token !== renderToken || view.querySelector("#fx-box")) return;
  const box = document.createElement("div");
  box.id = "fx-box";
  const firstH2 = page.querySelector("h2");
  if (firstH2) firstH2.before(box); else page.appendChild(box);
  let bt = { devices: [], steps: [0] };
  async function load() { try { bt = await API.get("/api/bt-delay"); } catch (_) {} draw(); }
  async function saveCfg(patch) { try { state.config = await API.post("/api/config", patch); } catch (e) { toast(e.message, "error"); } draw(); }
  function draw() {
    if (token !== renderToken) return;
    const key = Nav.current && Nav.current.dataset.key;
    const c = state.config || {};
    box.innerHTML = `<h2>Klang beim Fernsehen</h2><div class="list">
      ${toggleRow("fx-level", ICON.sound, "Lautstärke angleichen", "Alle Sender und Mediatheken-Videos gleich laut – Musik- und Shoppingsender nicht mehr lauter als ARD, Werbung nicht mehr lauter als der Film.", !!c.audio_level)}
      ${toggleRow("fx-dialog", ICON.sound, "Stimmen hervorheben", "Sprache wird klarer und lauter, Bässe, Musik und Explosionen leiser – gut abends und bei leisem Ton.", !!c.audio_dialog)}
      </div>
      <p class="hint" style="margin:1.2vh 0 2vh;opacity:.7;font-size:.9em">Gilt für Live-TV, Mediatheken und eigene Videos. Apps wie Netflix oder YouTube regeln ihren Ton selbst.</p>
      ${bt.devices.length ? `<h2>Bluetooth-Kopfhörer</h2><div class="list">${bt.devices.map((d, i) =>
        valueRow("bt-delay-" + i, ICON.headset || ICON.sound, esc(d.name), "Ton kommt zu spät? Verzögerung so lange erhöhen, bis Lippen und Ton zusammenpassen. Wird für diesen Kopfhörer gemerkt.", d.ms ? d.ms + " ms" : "Aus")).join("")}</div>` : ""}`;
    $("#fx-level").addEventListener("click", () => saveCfg({ audio_level: !c.audio_level }));
    $("#fx-dialog").addEventListener("click", () => saveCfg({ audio_dialog: !c.audio_dialog }));
    bt.devices.forEach((d, i) => $("#bt-delay-" + i).addEventListener("click", async () => {
      const ms = bt.steps[(bt.steps.indexOf(d.ms) + 1) % bt.steps.length];
      try { bt = await API.post("/api/bt-delay", { mac: d.mac, ms }); } catch (e) { toast(e.message, "error"); }
      draw();
    }));
    _v78Keep(view, key);
  }
  draw();
  load();
  pageTimers.push(setInterval(load, 8000));
}

// ======================================================================
// Einstellungen · System: Pflege und Sicherheit
// ======================================================================
function addCareRows(view, token) {
  const page = view.querySelector(".page");
  if (!page || token !== renderToken || view.querySelector("#care78-box")) return;
  const box = document.createElement("div");
  box.id = "care78-box";
  page.appendChild(box);
  let care = null, guard = null;
  const when = t => new Date(t * 1000).toLocaleString("de-DE", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
  async function load() {
    try { [care, guard] = await Promise.all([API.get("/api/care"), API.get("/api/lan-guard")]); } catch (_) {}
    draw();
  }
  async function saveCfg(patch, then) {
    try { state.config = await API.post("/api/config", patch); if (then) await then(); } catch (e) { toast(e.message, "error"); }
    load();
  }
  const stateText = v => v === true ? "Aktiv" : v === false ? "Nicht verfügbar" : "Wird eingerichtet …";
  function draw() {
    if (token !== renderToken || !care || !guard) return;
    const key = Nav.current && Nav.current.dataset.key;
    const g = !guard.on ? "Aus" : guard.active ? "Aktiv" : guard.error ? "Fehler" : "Wird eingerichtet …";
    const gDesc = guard.error ? guard.error
      : guard.active ? `Nur Geräte aus deinem WLAN, dem Fernbedienungs-WLAN und VPN kommen an Raspi-TV heran${guard.blocked ? ` · ${guard.blocked} Zugriffe von außen abgewiesen` : ""}`
      : guard.on ? "Wird in Kürze eingerichtet"
      : "Raspi-TV nimmt Verbindungen von überall an";
    box.innerHTML = `<h2>Pflege</h2><div class="list">
      <div class="row static"><span class="icon">${ICON.check}</span><span class="main"><div class="label">SD-Karte schonen</div>
        <div class="desc">Protokolle klein, seltener schreiben, Browser-Zwischenspeicher im Arbeitsspeicher – die Karte hält länger</div></span><span class="value">${stateText(care.sd)}</span></div>
      <div class="row static"><span class="icon">${ICON.check}</span><span class="main"><div class="label">Absturz-Wächter</div>
        <div class="desc">Friert der Pi komplett ein, startet er nach 15 Sekunden von selbst neu</div></span><span class="value">${stateText(care.watchdog)}</span></div>
      ${toggleRow("care-night", ICON.restart, "Browser nachts auffrischen", "Im Standby zwischen 3 und 5 Uhr unbemerkt neu starten, damit Raspi-TV flott bleibt" + (care.refreshed ? ` · zuletzt ${when(care.refreshed)}` : ""), care.night_refresh)}
      </div>
      <h2>Sicherheit</h2><div class="list">
      ${toggleRow("care-lan", ICON.lock || ICON.system, "Zugriff nur aus dem Heimnetz", esc(gDesc), guard.on)}
      </div>`;
    $("#care-night").addEventListener("click", () => saveCfg({ night_refresh: !care.night_refresh }));
    $("#care-lan").addEventListener("click", async () => {
      if (guard.on && !await confirmDialog("Zugriff von überall erlauben?",
        "Dann kommen auch Geräte außerhalb deines Heimnetzes an Raspi-TV heran, z. B. über einen offenen Port am Router oder IPv6 aus dem Internet. Nur ausschalten, wenn du das wirklich brauchst.", "Ausschalten")) return;
      saveCfg({ lan_only: !guard.on }, () => API.post("/api/lan-guard/apply"));
    });
    _v78Keep(view, key);
  }
  load();
  pageTimers.push(setInterval(load, 10000));
}


// ======================================================================
// 7.8.4: Einstellungen · Energie: USB-Anschlüsse immer mit Strom
// ======================================================================
(function () {
  const r = ROUTES.energy.render;
  ROUTES.energy.render = (v, t) => { r(v, t); setTimeout(() => addUsbPowerRow(v, t), 0); };
})();
function addUsbPowerRow(view, token) {
  const page = view.querySelector(".page");
  if (!page || token !== renderToken || view.querySelector("#usbp-box")) return;
  const box = document.createElement("div");
  box.id = "usbp-box";
  const pf = view.querySelector("#pf-box");
  if (pf) pf.before(box); else page.appendChild(box);
  let st = null;
  async function load() { try { st = await API.get("/api/usb-power"); draw(); } catch (_) {} }
  function draw() {
    if (token !== renderToken || !st) return;
    const key = Nav.current && Nav.current.dataset.key;
    box.innerHTML = `<h2>USB</h2><div class="list">
      ${toggleRow("usbp-on", ICON.usb || ICON.power || ICON.system, "USB-Anschlüsse immer mit Strom",
        (st.error ? "Fehler: " + esc(st.error) + " · " : "") + "Auch wenn Raspi-TV im Standby oder der Pi ganz heruntergefahren ist – angeschlossene Geräte (z. B. die runden Displays) bleiben an." + (st.pi5 ? " Wirkt nach dem nächsten Neustart." : ""), st.always_on)}
      </div>`;
    $("#usbp-on").addEventListener("click", async () => {
      try { st = await API.post("/api/usb-power", { always_on: !st.always_on }); } catch (e) { toast(e.message, "error"); }
      draw();
    });
    _v78Keep(view, key);
  }
  load();
}
