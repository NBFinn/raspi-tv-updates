#!/bin/bash
# Raspi-TV: Software-Update anwenden (läuft als root, aufgerufen vom Systemdienst)
#
#   apply-update.sh <entpackter Projektordner>
#
# Schreibt Fortschritt nach /var/log/raspi-tv-swupdate.log
set -e
F="${1:?Ordner fehlt}"
TV_USER=tv
LOG=/var/log/raspi-tv-swupdate.log
step() { echo "STEP $*"; }

step "Dateien werden installiert"
bash "$F/system/install-files.sh" "$F" /

step "Einstellungen des TV-Benutzers"
for u in xinitrc:.xinitrc xbindkeysrc:.xbindkeysrc bash_profile:.bash_profile; do
	install -m 644 -o "$TV_USER" -g "$TV_USER" "/opt/raspi-tv/user/${u%%:*}" "/home/$TV_USER/${u##*:}"
done
install -d -m 755 /media/raspi-tv /var/cache/raspi-tv/thumbs
install -d -m 755 -o "$TV_USER" -g "$TV_USER" /var/log/raspi-tv

step "Fehlende Programme werden nachinstalliert"
PKGS="$(cat "$F"/image/stage-raspitv/*/00-packages-nr 2>/dev/null | tr -d '\r' | tr -s ' \n' ' ')"
MISSING=""
for p in $PKGS; do
	dpkg -s "$p" >/dev/null 2>&1 || MISSING="$MISSING $p"
done
if [ -n "$MISSING" ]; then
	echo "Fehlt:$MISSING"
	if apt-get update >/dev/null 2>&1 && DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends $MISSING; then
		echo "Nachinstalliert:$MISSING"
	else
		echo "WARNUNG: Programme konnten nicht installiert werden (kein Internet?):$MISSING"
	fi
fi
# AirPlay läuft nur auf Wunsch (vom Systemdienst gestartet)
systemctl disable --now shairport-sync >/dev/null 2>&1 || true

step "Dienste werden aktualisiert"
systemctl daemon-reload
for svc in raspi-tv-recovery raspi-tv-ctl raspi-tv-cec raspi-tv-wlan raspi-tv-btagent raspi-tv-update-check; do
	systemctl enable "$svc" >/dev/null 2>&1 || true
done

# Bootscreen neu ins Startsystem übernehmen (nur wenn er sich geändert hat)
# (Prüfsumme über Skript und Bilder)
BOOTSUM="$(cat "$F"/branding/plymouth/* 2>/dev/null | md5sum | cut -d' ' -f1)"
if [ "$BOOTSUM" != "$(cat /var/lib/raspi-tv/.plymouth-installed 2>/dev/null)" ]; then
	step "Startanimation wird eingerichtet"
	plymouth-set-default-theme raspitv >/dev/null 2>&1 || true
	update-initramfs -u -k all >/dev/null 2>&1 && echo "$BOOTSUM" >/var/lib/raspi-tv/.plymouth-installed || true
fi

# Nach dem Neustart prüfen, ob die neue Version läuft – sonst automatisch zurück
SNAP="$(ls -t /var/lib/raspi-tv-rollback/raspi-tv-*.tar.gz 2>/dev/null | head -1 || true)"
[ -n "$SNAP" ] && echo "$SNAP" >/var/lib/raspi-tv-rollback/pending

step "Raspi-TV startet neu"
if [ "${RASPI_TV_NO_REBOOT:-0}" != 1 ]; then
	systemctl reset-failed raspi-tv-reboot >/dev/null 2>&1 || true
	systemd-run --on-active=8 --unit=raspi-tv-reboot --collect /bin/systemctl reboot >/dev/null 2>&1 || true
fi
step "Fertig"
