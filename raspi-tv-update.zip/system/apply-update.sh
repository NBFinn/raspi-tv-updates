#!/bin/bash
# Raspi-TV: Software-Update anwenden (läuft als root, aufgerufen vom Systemdienst)
#
#   apply-update.sh <entpackter Projektordner>
#
# Schreibt Fortschritt nach /var/log/raspi-tv-swupdate.log
set -e
F="${1:?Ordner fehlt}"
TV_USER=tv
LOG=/var/log/raspi-tv-swupdate.log
step() { echo "STEP $*"; }

# 7.5: Neustart nur, wenn er wirklich nötig ist. Sonst werden nur die Raspi-TV-Dienste und der Browser
# neu gestartet – das Update ist dann in Sekunden statt in einer guten Minute durch.
REBOOT_WHY=""
need_reboot() { REBOOT_WHY="${REBOOT_WHY:+$REBOOT_WHY, }$*"; }
# Bildschirm-, Anmelde- und Gerätedateien: ändern sie sich, ist ein Neustart der sichere Weg
SUMFILES="/etc/X11/xorg.conf.d/99-raspi-tv.conf /etc/X11/raspi-tv /home/$TV_USER/.xinitrc /home/$TV_USER/.bash_profile /etc/systemd/system.conf.d /etc/systemd/user.conf.d"
sum_now() { for x in $SUMFILES; do [ -e "$x" ] && find "$x" -type f -exec md5sum {} + 2>/dev/null; done | sort | md5sum | cut -d' ' -f1; }
SUM_BEFORE="$(sum_now)"
[ -d /opt/raspi-tv ] || need_reboot "Erstinstallation"

step "Dateien werden installiert"
bash "$F/system/install-files.sh" "$F" /

step "Einstellungen des TV-Benutzers"
for u in xinitrc:.xinitrc xbindkeysrc:.xbindkeysrc bash_profile:.bash_profile; do
	install -m 644 -o "$TV_USER" -g "$TV_USER" "/opt/raspi-tv/user/${u%%:*}" "/home/$TV_USER/${u##*:}"
done
install -d -m 755 /media/raspi-tv /var/cache/raspi-tv/thumbs
install -d -m 755 -o "$TV_USER" -g "$TV_USER" /var/log/raspi-tv

step "Fehlende Programme werden nachinstalliert"
PKGS="$(cat "$F"/image/stage-raspitv/*/00-packages-nr 2>/dev/null | tr -d '\r' | tr -s ' \n' ' ')"
MISSING=""
for p in $PKGS; do
	dpkg -s "$p" >/dev/null 2>&1 || MISSING="$MISSING $p"
done
if [ -n "$MISSING" ]; then
	echo "Fehlt:$MISSING"
	if apt-get update >/dev/null 2>&1 && DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends $MISSING; then
		echo "Nachinstalliert:$MISSING"
		need_reboot "neue Programme"
	else
		echo "WARNUNG: Programme konnten nicht installiert werden (kein Internet?):$MISSING"
	fi
fi
# 6.3: Systemupdates (Raspberry Pi OS) gleich mit einspielen – abschaltbar unter
# Einstellungen · Updates · „Systemupdates mitinstallieren“. Nur „upgrade“ (entfernt nie Pakete),
# vorhandene Konfigurationsdateien bleiben erhalten. Ohne Internet geht es ohne Systemupdates weiter.
SYSUP="$(python3 -c 'import json;print(json.load(open("/var/lib/raspi-tv/config.json")).get("system_updates",True) is not False)' 2>/dev/null || echo True)"
if [ "$SYSUP" = True ] && [ "${RASPI_TV_NO_SYSTEM_UPDATES:-0}" != 1 ]; then
	step "Systemupdates werden gesucht"
	APTOPT=(-o DPkg::Lock::Timeout=300 -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold)
	if apt-get "${APTOPT[@]}" update >/dev/null 2>&1; then
		TOTAL="$(apt-get "${APTOPT[@]}" -s upgrade 2>/dev/null | grep -c '^Inst ' || true)"
		if [ "${TOTAL:-0}" -gt 0 ]; then
			echo "Systemupdates: $TOTAL Pakete"
			step "Systemupdates 0/$TOTAL"
			N=0
			set +e
			DEBIAN_FRONTEND=noninteractive apt-get "${APTOPT[@]}" -y upgrade 2>&1 | while IFS= read -r line; do
				echo "$line"
				case "$line" in
					"Setting up "*|"Richte "*) N=$((N + 1)); if [ "$N" -le "$TOTAL" ]; then echo "STEP Systemupdates $N/$TOTAL"; fi;;
				esac
			done
			RC=${PIPESTATUS[0]}
			set -e
			need_reboot "Systemupdates"
			if [ "$RC" -eq 0 ]; then
				echo "Systemupdates installiert ($TOTAL Pakete)"
			else
				echo "WARNUNG: Systemupdates unvollständig – Raspi-TV wird trotzdem aktualisiert"
				DEBIAN_FRONTEND=noninteractive dpkg --configure -a --force-confdef --force-confold >/dev/null 2>&1 || true
			fi
			apt-get "${APTOPT[@]}" -y autoclean >/dev/null 2>&1 || true
		else
			echo "System ist aktuell"
		fi
	else
		echo "WARNUNG: Paketquellen nicht erreichbar (kein Internet?) – ohne Systemupdates weiter"
	fi
fi

# AirPlay läuft nur auf Wunsch (vom Systemdienst gestartet)
systemctl disable --now shairport-sync >/dev/null 2>&1 || true

step "Dienste werden aktualisiert"
systemctl daemon-reload
udevadm control --reload-rules 2>/dev/null && udevadm trigger --subsystem-match=tty 2>/dev/null || true
for svc in raspi-tv-recovery raspi-tv-ctl raspi-tv-cec raspi-tv-wlan raspi-tv-btagent raspi-tv-update-check raspi-tv-teensy-watch raspi-tv-reboot-wake raspi-tv-powerfail; do
	systemctl enable "$svc" >/dev/null 2>&1 || true
done

# Bootscreen neu ins Startsystem übernehmen (nur wenn er sich geändert hat)
# (Prüfsumme über Skript und Bilder)
BOOTSUM="$(cat "$F"/branding/plymouth/* 2>/dev/null | md5sum | cut -d' ' -f1)"
if [ "$BOOTSUM" != "$(cat /var/lib/raspi-tv/.plymouth-installed 2>/dev/null)" ]; then
	step "Startanimation wird eingerichtet"
	plymouth-set-default-theme raspitv >/dev/null 2>&1 || true
	update-initramfs -u -k all >/dev/null 2>&1 && echo "$BOOTSUM" >/var/lib/raspi-tv/.plymouth-installed || true
	need_reboot "Startanimation"
fi

# Nach dem Neustart prüfen, ob die neue Version läuft – sonst automatisch zurück
SNAP="$(ls -t /var/lib/raspi-tv-rollback/raspi-tv-*.tar.gz 2>/dev/null | head -1 || true)"
[ -n "$SNAP" ] && echo "$SNAP" >/var/lib/raspi-tv-rollback/pending

[ "$SUM_BEFORE" = "$(sum_now)" ] || need_reboot "Bildschirm-Einstellungen"
[ -f /var/lib/raspi-tv/always-reboot-after-update ] && need_reboot "so eingestellt"
if [ "${RASPI_TV_NO_REBOOT:-0}" = 1 ]; then
	step "Fertig"
elif [ -n "$REBOOT_WHY" ]; then
	echo "Neustart nötig: $REBOOT_WHY"
	step "Raspi-TV startet neu"
	systemctl reset-failed raspi-tv-reboot >/dev/null 2>&1 || true
	systemd-run --on-active=8 --unit=raspi-tv-reboot --collect /bin/systemctl reboot >/dev/null 2>&1 || true
	step "Fertig"
else
	echo "Kein Neustart nötig – nur Raspi-TV wird neu geladen"
	# Die Prüfung übernimmt hier quick-restart.sh (ohne Neustart dazwischen)
	rm -f /var/lib/raspi-tv-rollback/pending
	step "Raspi-TV wird neu geladen"
	systemctl reset-failed raspi-tv-restart >/dev/null 2>&1 || true
	systemd-run --on-active=4 --unit=raspi-tv-restart --collect /bin/bash /opt/raspi-tv/quick-restart.sh "$SNAP" >/dev/null 2>&1 || true
	step "Fertig ohne Neustart"
fi
