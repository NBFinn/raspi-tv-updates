#!/usr/bin/env python3
"""Track short browser crashes and use a persistent safe start."""
import argparse
import json
import os
from pathlib import Path
import tempfile
import time

def load(path):
    try:
        value = json.loads(path.read_text())
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.guard-', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'w') as output:
            json.dump(value, output)
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)

def record(path, seconds, code, now=None):
    now = time.time() if now is None else now
    value = load(path)
    failures = [at for at in value.get('failures', []) if isinstance(at, (int, float)) and 0 <= now-at < 300]
    if seconds < 60 and code not in (0, 130, 143):
        failures.append(now)
    elif seconds >= 300:
        failures = []
    value.update(failures=failures, safe=bool(value.get('safe')) or len(failures) >= 3)
    save(path, value)
    return value

def mode(path, flag):
    return 'safe' if flag.exists() or load(path).get('safe') else 'normal'

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('mode', 'exit'))
    parser.add_argument('--seconds', type=int, default=0)
    parser.add_argument('--code', type=int, default=0)
    args = parser.parse_args()
    path = Path.home()/'.local/state/raspi-tv/browser-guard.json'
    if args.action == 'exit':
        record(path, args.seconds, args.code)
    else:
        print(mode(path, Path('/var/lib/raspi-tv/safe-mode')))

if __name__ == '__main__':
    main()
