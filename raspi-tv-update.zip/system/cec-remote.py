#!/usr/bin/env python3
"""Raspi-TV: TV-Fernbedienung über HDMI-CEC.

1. Meldet den Pi beim Fernseher als Abspielgerät "Raspi-TV" an.
2. Liest die Tasten der TV-Fernbedienung (Kernel-CEC-Eingabegerät) und
   übersetzt sie in Tastatur-/Mausbefehle, die der Browser versteht.

Belegung:
  Pfeile / OK        Navigieren / Auswählen
  Zurück (kurz)      Browser zurück
  Zurück (lang)      Startbildschirm
  Home/Menü, Rot     Startbildschirm
  Grün               Maus-Modus an/aus (Pfeile bewegen den Zeiger, OK klickt)
  Gelb               Esc (Fenster schließen, Vollbild verlassen)
  Blau               Seite neu laden
  Play/Pause/Stop    Leertaste (Wiedergabe/Pause)
  Vor-/Zurückspulen  Pfeil rechts/links
  Kanal +/-          Sender wechseln im Fernsehen / Bild auf/ab (im Maus-Modus: scrollen)
  0-9                Senderwahl
  Guide / EPG        TV-Programm
  Info               Infoleiste
"""
import glob
import json
import re
import select
import os
import subprocess
import sys
import threading
import time

import evdev
from evdev import UInput
from evdev import ecodes as e

LONG_PRESS = 0.8  # Sekunden
POWER_FILE = "/run/raspi-tv/tv-power"  # "on" / "standby" – liest die Oberfläche

HOME = "home"
MOUSE_TOGGLE = "mouse"
BACK = "back"

MAP = {
    e.KEY_UP: e.KEY_UP, e.KEY_DOWN: e.KEY_DOWN,
    e.KEY_LEFT: e.KEY_LEFT, e.KEY_RIGHT: e.KEY_RIGHT,
    e.KEY_OK: e.KEY_ENTER, e.KEY_SELECT: e.KEY_ENTER, e.KEY_ENTER: e.KEY_ENTER,
    e.KEY_EXIT: BACK, e.KEY_BACK: BACK,
    e.KEY_ROOT_MENU: HOME, e.KEY_HOMEPAGE: HOME, e.KEY_MENU: HOME,
    e.KEY_SETUP: HOME, e.KEY_CONTEXT_MENU: HOME, e.KEY_RED: HOME,
    e.KEY_GREEN: MOUSE_TOGGLE,
    e.KEY_YELLOW: e.KEY_ESC,
    e.KEY_BLUE: e.KEY_F5,
    e.KEY_PLAY: e.KEY_SPACE, e.KEY_PAUSE: e.KEY_SPACE,
    e.KEY_PLAYPAUSE: e.KEY_SPACE, e.KEY_STOP: e.KEY_SPACE,
    e.KEY_FASTFORWARD: e.KEY_RIGHT, e.KEY_FORWARD: e.KEY_RIGHT,
    e.KEY_REWIND: e.KEY_LEFT,
    e.KEY_CHANNELUP: e.KEY_PAGEUP, e.KEY_CHANNELDOWN: e.KEY_PAGEDOWN,
    e.KEY_EPG: e.KEY_G, e.KEY_PROGRAM: e.KEY_G, e.KEY_INFO: e.KEY_I,
    e.KEY_RECORD: e.KEY_R,
    **{getattr(e, f"KEY_NUMERIC_{i}"): getattr(e, f"KEY_{i}") for i in range(10)},
    **{getattr(e, f"KEY_{i}"): getattr(e, f"KEY_{i}") for i in range(10)},
}

CEC_ACTIONS = {
    "up": e.KEY_UP, "down": e.KEY_DOWN, "left": e.KEY_LEFT, "right": e.KEY_RIGHT,
    "ok": e.KEY_ENTER, "back": BACK, "home": HOME, "mouse": MOUSE_TOGGLE,
    "pageup": e.KEY_PAGEUP, "pagedown": e.KEY_PAGEDOWN, "playpause": e.KEY_SPACE,
    "volumeup": e.KEY_VOLUMEUP, "volumedown": e.KEY_VOLUMEDOWN, "mute": e.KEY_MUTE,
}
CEC_MAPPING_FILE = "/var/lib/raspi-tv/cec-mapping.json"
CEC_LAST_KEY = "/run/raspi-tv/cec-last-key.json"

def mapped_target(code):
    try:
        with open(CEC_MAPPING_FILE) as source:
            overrides = json.load(source)
        action = overrides.get(str(code))
        return CEC_ACTIONS.get(action, MAP.get(code))
    except (OSError, ValueError, AttributeError, TypeError):
        return MAP.get(code)

def record_cec_key(code):
    try:
        os.makedirs(os.path.dirname(CEC_LAST_KEY), exist_ok=True)
        temporary = CEC_LAST_KEY + ".tmp"
        with open(temporary, "w") as output:
            json.dump({"code": code, "name": str(e.KEY.get(code, code)), "at": time.time()}, output)
        os.replace(temporary, CEC_LAST_KEY)
    except OSError:
        pass

OUT_KEYS = sorted({v for v in MAP.values() if isinstance(v, int)} | {e.KEY_F8, e.KEY_BACK} | {value for value in CEC_ACTIONS.values() if isinstance(value, int)})
CAPS = {
    e.EV_KEY: OUT_KEYS + [e.BTN_LEFT, e.BTN_RIGHT],
    e.EV_REL: [e.REL_X, e.REL_Y, e.REL_WHEEL],
}


def log(*a):
    print(*a, flush=True)


# --- Fernseher an/aus erkennen -----------------------------------------------
_power = None


def set_power(state):
    """Zustand des Fernsehers merken, damit Fernsehen/Apps pausieren können."""
    global _power
    if state == _power:
        return
    _power = state
    try:
        os.makedirs(os.path.dirname(POWER_FILE), exist_ok=True)
        tmp = POWER_FILE + ".tmp"
        with open(tmp, "w") as f:
            f.write(state)
        os.replace(tmp, POWER_FILE)
    except OSError:
        pass
    log("Fernseher:", "aus (Standby)" if state == "standby" else "an")


def mark_input():
    """Letzte Bedienung merken (für das automatische Ausschalten)."""
    try:
        with open("/run/raspi-tv/last-input", "w") as f:
            f.write(str(int(time.time())))
    except OSError:
        pass


WAKE_MSGS = ("SET_STREAM_PATH", "ROUTING_CHANGE", "REQUEST_ACTIVE_SOURCE",
             "USER_CONTROL_PRESSED")


ACTIVE_DEV = None   # HDMI-Anschluss mit Fernseher (Pi 4/5: cec0 oder cec1)


def cec_monitor():
    """Liest den CEC-Verkehr mit: STANDBY vom Fernseher = aus, Umschalten auf uns = an."""
    while True:
        devs = [ACTIVE_DEV] if ACTIVE_DEV else sorted(glob.glob("/dev/cec*"))
        if not devs or not ACTIVE_DEV:
            time.sleep(5)   # erst, wenn feststeht, an welchem Anschluss der Fernseher hängt
            continue
        try:
            p = subprocess.Popen(["cec-ctl", "-d", devs[0], "--monitor"],
                                 stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                 text=True, bufsize=1)
        except OSError:
            time.sleep(30)
            continue
        for line in p.stdout:
            if not line.startswith("Received"):
                continue
            if "STANDBY" in line:
                set_power("standby")
            elif any(m in line for m in WAKE_MSGS):
                set_power("on")
                # Fernseher wurde eingeschaltet und fragt, wer senden will
                if "REQUEST_ACTIVE_SOURCE" in line and setting("cec_autoswitch", False):
                    threading.Thread(target=claim_active_source, args=(devs[0],), daemon=True).start()
            elif "REPORT_POWER_STATUS" in line:
                nxt = next(p.stdout, "")
                if "standby" in nxt:
                    set_power("standby")
                elif "pwr-state: on" in nxt:
                    set_power("on")
        p.wait()
        time.sleep(5)


def query_power(dev):
    out = subprocess.run(["cec-ctl", "-d", dev, "--to", "0", "--give-device-power-status"],
                         capture_output=True, text=True, timeout=15).stdout
    if "pwr-state: standby" in out or "pwr-state: to-standby" in out:
        set_power("standby")
    elif "pwr-state: on" in out or "pwr-state: to-on" in out:
        set_power("on")


CONFIG_FILE = "/var/lib/raspi-tv/config.json"


def setting(key, default):
    try:
        with open(CONFIG_FILE) as f:
            return json.load(f).get(key, default)
    except (OSError, ValueError):
        return default


def claim_active_source(dev, pa=None):
    if pa is None:
        out = subprocess.run(["cec-ctl", "-d", dev], capture_output=True, text=True).stdout
        m = re.search(r"Physical Address\s*:\s*([0-9a-f]\.[0-9a-f]\.[0-9a-f]\.[0-9a-f])", out)
        if not m or m.group(1) == "f.f.f.f":
            return
        pa = m.group(1)
    subprocess.run(["cec-ctl", "-d", dev, "--to", "0", "--image-view-on"], capture_output=True)
    subprocess.run(["cec-ctl", "-d", dev, "--to", "15", "--active-source", f"phys-addr={pa}"],
                   capture_output=True)


# --- CEC-Anmeldung -----------------------------------------------------------
def cec_register():
    """Als Abspielgerät anmelden und sich als aktive Quelle melden."""
    for dev in sorted(glob.glob("/dev/cec*")):
        subprocess.run(["cec-ctl", "-d", dev, "--playback", "--osd-name", "Raspi-TV"],
                       capture_output=True)
        out = subprocess.run(["cec-ctl", "-d", dev], capture_output=True, text=True).stdout
        m = re.search(r"Physical Address\s*:\s*([0-9a-f]\.[0-9a-f]\.[0-9a-f]\.[0-9a-f])", out)
        if not m or m.group(1) == "f.f.f.f":
            continue  # an diesem HDMI-Port hängt kein Fernseher
        pa = m.group(1)
        global ACTIVE_DEV
        ACTIVE_DEV = dev
        if setting("cec_wake_tv", True):   # Fernseher einschalten und auf Raspi-TV umschalten
            claim_active_source(dev, pa)
        log(f"CEC: angemeldet an {dev} (Adresse {pa})")
        try:
            query_power(dev)
        except (OSError, subprocess.SubprocessError):
            pass
        return True
    return False


def find_cec_inputs():
    devs = []
    for path in evdev.list_devices():
        d = evdev.InputDevice(path)
        name = (d.name or "").lower()
        if ("hdmi" in name or "cec" in name) and e.EV_KEY in d.capabilities():
            devs.append(d)
        else:
            d.close()
    return devs


NATIVE_PID_FILE = "/run/raspi-tv-native"


def stop_native_app():
    """Beendet ein laufendes App-Store-Programm. True, wenn eines lief."""
    try:
        with open(NATIVE_PID_FILE) as f:
            pid = int(f.read().strip())
        os.kill(pid, 0)
    except (OSError, ValueError):
        return False
    import signal
    log("Home: beende Programm", pid)
    try:
        os.killpg(pid, signal.SIGTERM)
    except OSError:
        return False
    return True


# --- Übersetzung -------------------------------------------------------------
class Translator:
    def __init__(self):
        self.ui = UInput(CAPS, name="raspi-tv-remote")
        self.mouse_mode = False
        self.back_down_at = None
        self.repeat = 0
        self.pressed = {}

    def tap(self, key):
        self.ui.write(e.EV_KEY, key, 1); self.ui.syn()
        self.ui.write(e.EV_KEY, key, 0); self.ui.syn()

    def home(self):
        # Läuft ein Programm aus dem App Store (Kodi, RetroArch …), beendet Home es –
        # dahinter wartet die Raspi-TV-Oberfläche.
        if stop_native_app():
            return
        # F8 erreicht die Erweiterung, ohne Chromiums native Home-Navigation auszulösen.
        self.tap(e.KEY_F8)

    def move(self, code, value):
        self.repeat = 0 if value == 1 else self.repeat + 1
        step = min(10 + 6 * self.repeat, 70)
        dx = {e.KEY_LEFT: -step, e.KEY_RIGHT: step}.get(code, 0)
        dy = {e.KEY_UP: -step, e.KEY_DOWN: step}.get(code, 0)
        self.ui.write(e.EV_REL, e.REL_X, dx)
        self.ui.write(e.EV_REL, e.REL_Y, dy)
        self.ui.syn()

    def handle(self, code, value):  # value: 1 = gedrückt, 2 = gehalten, 0 = losgelassen
        if value == 1:
            set_power("on")  # wer die Fernbedienung benutzt, hat den Fernseher an
            mark_input()
        if value == 1:
            record_cec_key(code)
        target = mapped_target(code)
        if value == 1:
            self.pressed[code] = target
        elif value == 0:
            target = self.pressed.pop(code, target)
        else:
            target = self.pressed.get(code, target)
        if target is None:
            return

        if target == BACK:
            if value == 1:
                self.back_down_at = time.monotonic()
            elif value == 0 and self.back_down_at is not None:
                held = time.monotonic() - self.back_down_at
                self.back_down_at = None
                self.home() if held >= LONG_PRESS else self.tap(e.KEY_BACK)
            return

        if value == 0 and target in (HOME, MOUSE_TOGGLE):
            return
        if target == HOME:
            if value == 1:
                self.home()
            return
        if target == MOUSE_TOGGLE:
            if value == 1:
                self.mouse_mode = not self.mouse_mode
                log("Maus-Modus", "an" if self.mouse_mode else "aus")
            return

        if self.mouse_mode:
            if target in (e.KEY_UP, e.KEY_DOWN, e.KEY_LEFT, e.KEY_RIGHT) and code in (
                    e.KEY_UP, e.KEY_DOWN, e.KEY_LEFT, e.KEY_RIGHT):
                if value:
                    self.move(target, value)
                return
            if target == e.KEY_ENTER:
                if value in (0, 1):
                    self.ui.write(e.EV_KEY, e.BTN_LEFT, value); self.ui.syn()
                return
            if target in (e.KEY_PAGEUP, e.KEY_PAGEDOWN):
                if value:
                    self.ui.write(e.EV_REL, e.REL_WHEEL, 2 if target == e.KEY_PAGEUP else -2)
                    self.ui.syn()
                return

        self.ui.write(e.EV_KEY, target, value)
        self.ui.syn()


def main():
    threading.Thread(target=cec_monitor, daemon=True).start()
    tr = Translator()
    registered = False
    while True:
        if not registered:
            registered = cec_register()
        devs = find_cec_inputs()
        if not devs:
            time.sleep(5)  # Fernseher aus / CEC noch nicht bereit
            continue
        for d in devs:
            try:
                d.grab()
            except OSError:
                pass
            log(f"Fernbedienung über {d.name} ({d.path})")
        try:
            fds = {d.fd: d for d in devs}
            while True:
                r, _, _ = select.select(fds, [], [], 30)
                if not r and not registered:
                    registered = cec_register()
                for fd in r:
                    for ev in fds[fd].read():
                        if ev.type == e.EV_KEY:
                            tr.handle(ev.code, ev.value)
        except OSError as err:
            log("Eingabegerät verloren:", err)
            registered = False
            for d in devs:
                try:
                    d.close()
                except OSError:
                    pass
            time.sleep(2)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
