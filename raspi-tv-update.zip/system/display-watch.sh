#!/usr/bin/env bash
# Raspi-TV: Bildschirm-Wächter (läuft in der grafischen Sitzung)
# Pi 4/5 haben zwei HDMI-Anschlüsse. Hängt der Fernseher am zweiten Anschluss (HDMI 1) oder war er
# beim Start aus, bekommt er sonst kein Bild. Jeder angeschlossene Bildschirm wird eingeschaltet
# und zeigt dasselbe Bild; abgezogene Anschlüsse werden abgeschaltet.

LOG=/var/log/raspi-tv/display.log
[ -w "${LOG%/*}" ] || LOG="$HOME/raspi-tv-display.log"
log() { echo "$(date '+%F %T') $*" >>"$LOG" 2>/dev/null; }

last=""
while sleep 3; do
  q="$(xrandr --query 2>/dev/null)" || continue
  [ "$q" = "$last" ] && continue
  last="$q"
  # aktiver Bildschirm = der mit Position (z. B. 1920x1080+0+0)
  main="$(printf '%s\n' "$q" | awk '/ connected/ && / [0-9]+x[0-9]+\+[0-9]+\+[0-9]+/ {print $1; exit}')"
  changed=0
  while read -r out state rest; do
    case "$state" in
      connected)
        if ! printf '%s' "$rest" | grep -qE '[0-9]+x[0-9]+\+[0-9]+\+[0-9]+'; then
          if [ -n "$main" ] && [ "$main" != "$out" ]; then
            xrandr --output "$out" --auto --same-as "$main" && log "eingeschaltet: $out (wie $main)"
          else
            xrandr --output "$out" --auto --primary && log "eingeschaltet: $out"
            main="$out"
          fi
          changed=1
        fi ;;
      disconnected)
        if printf '%s' "$rest" | grep -qE '[0-9]+x[0-9]+\+[0-9]+\+[0-9]+'; then
          xrandr --output "$out" --off && log "abgeschaltet: $out"
          changed=1
        fi ;;
    esac
  done < <(printf '%s\n' "$q" | grep -E '^[A-Za-z0-9-]+ (connected|disconnected)')
  [ "$changed" = 1 ] && last=""
done
