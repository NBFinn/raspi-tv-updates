"""Narrow local bridge from TV settings to the existing display diagnosis task.

The recovery credential stays on the server. No caller-supplied URL, command,
file path or generic maintenance action is accepted.
"""
import http.client
import json
from pathlib import Path
import re


class DisplaySettings:
    def __init__(self, error, key_file=Path('/var/lib/raspi-tv-recovery/admin.key'), port=8767):
        self.error, self.key_file, self.port = error, Path(key_file), port

    def _call(self, path, data=None):
        try:
            key = self.key_file.read_text(encoding='utf-8').strip()
        except OSError:
            raise self.error('Display-Diagnose noch nicht bereit. Bitte kurz warten und erneut versuchen.', 503)
        if not re.fullmatch(r'[0-9]{4}', key):
            raise self.error('Display-Diagnose nicht bereit. Bitte den Pi neu starten.', 503)
        # Detecting/mounting a stick and syncing the support ZIP can take longer
        # than reading an already running diagnosis task.
        timeout = 60 if path in ('/maintenance/usb', '/maintenance/support-export') else 15
        connection = http.client.HTTPConnection('127.0.0.1', self.port, timeout=timeout)
        try:
            connection.request('POST' if data is not None else 'GET', path,
                               body=json.dumps(data).encode() if data is not None else None,
                               headers={'X-Admin-Key': key, 'Content-Type': 'application/json'})
            response = connection.getresponse()
            raw = response.read(2 * 1024 * 1024 + 1)
            if len(raw) > 2 * 1024 * 1024:
                raise self.error('Der Display-Bericht ist zu groß.', 502)
            result = json.loads(raw)
            if not isinstance(result, dict):
                raise ValueError('Invalid service response')
            if response.status in (401, 403, 429):
                raise self.error('Display-Diagnose momentan nicht verfügbar. Bitte kurz warten und erneut versuchen.', 503)
            if response.status != 200:
                message = str(result.get('error') or 'Display-Diagnose fehlgeschlagen.')
                raise self.error(message.replace(key, '[ENTFERNT]'), 400)
            return result
        except (OSError, http.client.HTTPException, ValueError):
            raise self.error('Display-Diagnose nicht erreichbar. Bitte erneut versuchen.', 503)
        finally:
            connection.close()

    def _status(self):
        task = self._call('/maintenance/status').get('tasks', {}).get('round-displays') or {}
        result = task.get('result') or {}
        # Never forward unrelated maintenance tasks or recovery state.
        return {'running': bool(task.get('running')), 'error': task.get('error'),
                'report': result.get('report'), 'created': result.get('created'),
                'test': self._call('/maintenance/round-display-test')}

    def request(self, data):
        action = data.get('action', 'status')
        if not isinstance(action, str) or action not in ('status', 'start', 'usb', 'export', 'test-start', 'test-stop'):
            raise self.error('Unbekannte Display-Funktion.')
        allowed = {'action', 'id'} if action == 'export' else {'action', 'display'} if action == 'test-start' else {'action'}
        if set(data) - allowed:
            raise self.error('Ungültige Display-Anfrage.')
        if action == 'test-start' and (type(data.get('display', 2)) is not int or data.get('display', 2) not in (1, 2)):
            raise self.error('Bitte Display 1 oder Display 2 auswählen.')
        if action == 'status':
            return self._status()
        if action == 'start':
            self._call('/maintenance/round-displays', {})
            return {'ok': True}
        if action in ('test-start', 'test-stop'):
            payload = {'action': action.removeprefix('test-')}
            if action == 'test-start': payload['display'] = data.get('display', 2)
            return self._call('/maintenance/round-display-test', payload)
        if action == 'usb':
            return self._call('/maintenance/usb')
        identifier = data.get('id')
        if not isinstance(identifier, str) or not re.fullmatch(r'[0-9a-f]{24}', identifier):
            raise self.error('Bitte einen erkannten USB-Stick auswählen.')
        status = self._status()
        if status['running'] or not status['report']:
            raise self.error('Bitte zuerst die Display-Diagnose abschließen.')
        return self._call('/maintenance/support-export', {'id': identifier})
