"""Raspi-TV: Videos, Musik und Fotos vom Handy abspielen (DLNA / UPnP MediaRenderer).

Raspi-TV meldet sich im Heimnetz als Wiedergabegerät. Apps wie BubbleUPnP,
„Wiedergabe auf Gerät“ in Windows oder viele Galerie-/Medien-Apps können dann
Dateien direkt an den Fernseher schicken. Abgespielt wird im Raspi-TV-Player.

Bestandteile:
  * SSDP (Multicast 239.255.255.250:1900): Gerät ankündigen und auf Suchen antworten
  * HTTP auf Port 8768: Gerätebeschreibung, SOAP-Steuerung, GENA-Ereignisse
  * Brücke zum Player (/api/cast im Raspi-TV-Dienst)
"""
import email.utils
import http.client
import ipaddress
import json
import os
import random
import re
import socket
import struct
import threading
import time
import uuid as uuidlib
import xml.etree.ElementTree as ET
from html import escape
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlparse

PORT = 8768
SSDP_GROUP = "239.255.255.250"
SSDP_PORT = 1900
LAUNCHER = "http://127.0.0.1:8765/"

DEVICE_TYPE = "urn:schemas-upnp-org:device:MediaRenderer:1"
SVC = {
    "avt": ("urn:schemas-upnp-org:service:AVTransport:1", "urn:upnp-org:serviceId:AVTransport"),
    "rc": ("urn:schemas-upnp-org:service:RenderingControl:1", "urn:upnp-org:serviceId:RenderingControl"),
    "cm": ("urn:schemas-upnp-org:service:ConnectionManager:1", "urn:upnp-org:serviceId:ConnectionManager"),
}
SINK_TYPES = ["video/mp4", "video/webm", "video/x-matroska", "video/quicktime", "audio/mpeg", "audio/mp4", "audio/aac",
              "audio/x-m4a", "audio/flac", "audio/x-flac", "audio/ogg", "audio/wav", "audio/x-wav", "audio/L16",
              "image/jpeg", "image/png", "image/gif", "image/webp", "image/bmp"]
SINK = ",".join(f"http-get:*:{t}:*" for t in SINK_TYPES)

H = {}   # Haken vom Raspi-TV-Dienst: name(), enabled(), state_dir, request_nav(url), volume_get(), volume_set(v), mute_get(), mute_set(b), log(msg)

_lock = threading.Lock()
S = {"uri": "", "meta": "", "title": "", "artist": "", "art": "", "kind": "video", "transport": "NO_MEDIA_PRESENT",
     "position": 0.0, "duration": 0.0, "seq": 0, "cmd": None, "cmd_id": 0, "seek": 0.0, "player_seen": 0.0}
_subs = {}   # sid -> {"svc", "urls", "expires", "seq"}
_uuid = None


# --------------------------------------------------------------------------
# Hilfen
# --------------------------------------------------------------------------
def _log(msg):
    if "log" in H:
        H["log"](msg)


def device_uuid():
    global _uuid
    if _uuid:
        return _uuid
    p = os.path.join(H.get("state_dir", "/var/lib/raspi-tv"), "dlna-uuid")
    try:
        with open(p) as f:
            _uuid = f.read().strip()
    except OSError:
        _uuid = ""
    if not re.match(r"^[0-9a-f-]{36}$", _uuid or ""):
        _uuid = str(uuidlib.uuid4())
        try:
            with open(p, "w") as f:
                f.write(_uuid)
        except OSError:
            pass
    return _uuid


def _ip_for(peer):
    """Eigene Adresse, über die `peer` erreichbar ist (Heimnetz oder Fernbedienungs-WLAN)."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect((peer, 9))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return None


def _hms(sec):
    sec = max(0, int(sec or 0))
    return f"{sec // 3600}:{sec // 60 % 60:02d}:{sec % 60:02d}"


def _sec(hms):
    m = re.match(r"^(\d+):(\d{1,2}):(\d{1,2})(?:\.\d+)?$", hms or "")
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3)) if m else None


def _private_url(u):
    """Rückmeldungen (Ereignisse) nur an Geräte im lokalen Netz senden."""
    try:
        p = urlparse(u)
        ip = ipaddress.ip_address(p.hostname)
        return p.scheme == "http" and ip.is_private and not ip.is_loopback
    except (ValueError, TypeError):
        return False


def _media_url_ok(u):
    try:
        p = urlparse(u)
    except ValueError:
        return False
    if p.scheme not in ("http", "https") or not p.hostname:
        return False
    host = p.hostname.lower()
    if host in ("localhost",) or host.endswith(".localhost"):
        return False
    try:
        if ipaddress.ip_address(host).is_loopback:
            return False
    except ValueError:
        pass
    return True


def _parse_meta(meta, uri):
    """Titel, Art und Cover aus DIDL-Lite-Metadaten lesen."""
    title, artist, art, kind, mime = "", "", "", "", ""
    try:
        root = ET.fromstring(meta) if meta and meta.strip().startswith("<") else None
    except ET.ParseError:
        root = None
    if root is not None:
        for el in root.iter():
            tag = el.tag.split("}")[-1]
            txt = (el.text or "").strip()
            if tag == "title" and not title:
                title = txt
            elif tag in ("artist", "creator") and not artist:
                artist = txt
            elif tag == "albumArtURI" and not art:
                art = txt
            elif tag == "class" and not kind:
                kind = "image" if "imageItem" in txt else "audio" if "audioItem" in txt else "video" if "videoItem" in txt else ""
            elif tag == "res" and not mime:
                pi = el.get("protocolInfo", "")
                parts = pi.split(":")
                mime = parts[2] if len(parts) > 2 else ""
    if not kind and mime:
        kind = mime.split("/")[0] if mime.split("/")[0] in ("image", "audio", "video") else ""
    if not kind:
        path = urlparse(uri).path.lower()
        kind = ("image" if re.search(r"\.(jpe?g|png|gif|webp|bmp|heic)$", path)
                else "audio" if re.search(r"\.(mp3|m4a|aac|flac|ogg|opus|wav)$", path) else "video")
    if not title:
        title = unquote(os.path.basename(urlparse(uri).path)) or "Vom Handy"
    if art and not _media_url_ok(art):
        art = ""
    return title[:200], artist[:200], art, kind


# --------------------------------------------------------------------------
# Gerätebeschreibung (XML)
# --------------------------------------------------------------------------
def device_xml():
    name = escape(H["name"]() if "name" in H else "Raspi-TV")
    services = "".join(
        f"<service><serviceType>{t}</serviceType><serviceId>{i}</serviceId><SCPDURL>/dlna/{k}.xml</SCPDURL>"
        f"<controlURL>/dlna/ctl/{k}</controlURL><eventSubURL>/dlna/evt/{k}</eventSubURL></service>"
        for k, (t, i) in SVC.items())
    return f"""<?xml version="1.0" encoding="utf-8"?>
<root xmlns="urn:schemas-upnp-org:device-1-0" xmlns:dlna="urn:schemas-dlna-org:device-1-0">
<specVersion><major>1</major><minor>0</minor></specVersion>
<device>
<deviceType>{DEVICE_TYPE}</deviceType>
<friendlyName>{name}</friendlyName>
<manufacturer>Raspi-TV</manufacturer>
<modelName>Raspi-TV</modelName>
<modelDescription>Raspi-TV Medienwiedergabe</modelDescription>
<modelNumber>1</modelNumber>
<UDN>uuid:{device_uuid()}</UDN>
<dlna:X_DLNADOC>DMR-1.50</dlna:X_DLNADOC>
<serviceList>{services}</serviceList>
</device>
</root>"""


def _scpd(actions, variables):
    acts = ""
    for name, args in actions.items():
        a = "".join(f"<argument><name>{n}</name><direction>{d}</direction><relatedStateVariable>{v}</relatedStateVariable></argument>"
                    for n, d, v in args)
        acts += f"<action><name>{name}</name><argumentList>{a}</argumentList></action>" if a else f"<action><name>{name}</name></action>"
    vs = ""
    for name, (typ, events, extra) in variables.items():
        vs += f'<stateVariable sendEvents="{"yes" if events else "no"}"><name>{name}</name><dataType>{typ}</dataType>{extra}</stateVariable>'
    return ('<?xml version="1.0" encoding="utf-8"?><scpd xmlns="urn:schemas-upnp-org:service-1-0">'
            f"<specVersion><major>1</major><minor>0</minor></specVersion><actionList>{acts}</actionList>"
            f"<serviceStateTable>{vs}</serviceStateTable></scpd>")


def _allowed(*vals):
    return "<allowedValueList>" + "".join(f"<allowedValue>{v}</allowedValue>" for v in vals) + "</allowedValueList>"


IID = ("InstanceID", "in", "A_ARG_TYPE_InstanceID")
SCPD = {
    "avt": _scpd({
        "SetAVTransportURI": [IID, ("CurrentURI", "in", "AVTransportURI"), ("CurrentURIMetaData", "in", "AVTransportURIMetaData")],
        "SetNextAVTransportURI": [IID, ("NextURI", "in", "NextAVTransportURI"), ("NextURIMetaData", "in", "NextAVTransportURIMetaData")],
        "GetMediaInfo": [IID, ("NrTracks", "out", "NumberOfTracks"), ("MediaDuration", "out", "CurrentMediaDuration"),
                         ("CurrentURI", "out", "AVTransportURI"), ("CurrentURIMetaData", "out", "AVTransportURIMetaData"),
                         ("NextURI", "out", "NextAVTransportURI"), ("NextURIMetaData", "out", "NextAVTransportURIMetaData"),
                         ("PlayMedium", "out", "PlaybackStorageMedium"), ("RecordMedium", "out", "RecordStorageMedium"),
                         ("WriteStatus", "out", "RecordMediumWriteStatus")],
        "GetTransportInfo": [IID, ("CurrentTransportState", "out", "TransportState"),
                             ("CurrentTransportStatus", "out", "TransportStatus"), ("CurrentSpeed", "out", "TransportPlaySpeed")],
        "GetPositionInfo": [IID, ("Track", "out", "CurrentTrack"), ("TrackDuration", "out", "CurrentTrackDuration"),
                            ("TrackMetaData", "out", "CurrentTrackMetaData"), ("TrackURI", "out", "CurrentTrackURI"),
                            ("RelTime", "out", "RelativeTimePosition"), ("AbsTime", "out", "AbsoluteTimePosition"),
                            ("RelCount", "out", "RelativeCounterPosition"), ("AbsCount", "out", "AbsoluteCounterPosition")],
        "GetDeviceCapabilities": [IID, ("PlayMedia", "out", "PossiblePlaybackStorageMedia"),
                                  ("RecMedia", "out", "PossibleRecordStorageMedia"), ("RecQualityModes", "out", "PossibleRecordQualityModes")],
        "GetTransportSettings": [IID, ("PlayMode", "out", "CurrentPlayMode"), ("RecQualityMode", "out", "CurrentRecordQualityMode")],
        "GetCurrentTransportActions": [IID, ("Actions", "out", "CurrentTransportActions")],
        "Stop": [IID], "Pause": [IID], "Next": [IID], "Previous": [IID],
        "Play": [IID, ("Speed", "in", "TransportPlaySpeed")],
        "Seek": [IID, ("Unit", "in", "A_ARG_TYPE_SeekMode"), ("Target", "in", "A_ARG_TYPE_SeekTarget")],
    }, {
        "TransportState": ("string", False, _allowed("STOPPED", "PLAYING", "PAUSED_PLAYBACK", "TRANSITIONING", "NO_MEDIA_PRESENT")),
        "TransportStatus": ("string", False, _allowed("OK", "ERROR_OCCURRED")),
        "TransportPlaySpeed": ("string", False, _allowed("1")),
        "NumberOfTracks": ("ui4", False, ""), "CurrentMediaDuration": ("string", False, ""),
        "AVTransportURI": ("string", False, ""), "AVTransportURIMetaData": ("string", False, ""),
        "NextAVTransportURI": ("string", False, ""), "NextAVTransportURIMetaData": ("string", False, ""),
        "PlaybackStorageMedium": ("string", False, _allowed("NETWORK", "NONE")),
        "RecordStorageMedium": ("string", False, _allowed("NOT_IMPLEMENTED")),
        "RecordMediumWriteStatus": ("string", False, _allowed("NOT_IMPLEMENTED")),
        "CurrentTrack": ("ui4", False, ""), "CurrentTrackDuration": ("string", False, ""),
        "CurrentTrackMetaData": ("string", False, ""), "CurrentTrackURI": ("string", False, ""),
        "RelativeTimePosition": ("string", False, ""), "AbsoluteTimePosition": ("string", False, ""),
        "RelativeCounterPosition": ("i4", False, ""), "AbsoluteCounterPosition": ("i4", False, ""),
        "PossiblePlaybackStorageMedia": ("string", False, ""), "PossibleRecordStorageMedia": ("string", False, ""),
        "PossibleRecordQualityModes": ("string", False, ""), "CurrentPlayMode": ("string", False, _allowed("NORMAL")),
        "CurrentRecordQualityMode": ("string", False, _allowed("NOT_IMPLEMENTED")),
        "CurrentTransportActions": ("string", False, ""), "LastChange": ("string", True, ""),
        "A_ARG_TYPE_SeekMode": ("string", False, _allowed("REL_TIME", "ABS_TIME", "TRACK_NR")),
        "A_ARG_TYPE_SeekTarget": ("string", False, ""), "A_ARG_TYPE_InstanceID": ("ui4", False, ""),
    }),
    "rc": _scpd({
        "ListPresets": [IID, ("CurrentPresetNameList", "out", "PresetNameList")],
        "SelectPreset": [IID, ("PresetName", "in", "A_ARG_TYPE_PresetName")],
        "GetMute": [IID, ("Channel", "in", "A_ARG_TYPE_Channel"), ("CurrentMute", "out", "Mute")],
        "SetMute": [IID, ("Channel", "in", "A_ARG_TYPE_Channel"), ("DesiredMute", "in", "Mute")],
        "GetVolume": [IID, ("Channel", "in", "A_ARG_TYPE_Channel"), ("CurrentVolume", "out", "Volume")],
        "SetVolume": [IID, ("Channel", "in", "A_ARG_TYPE_Channel"), ("DesiredVolume", "in", "Volume")],
    }, {
        "PresetNameList": ("string", False, ""), "LastChange": ("string", True, ""), "Mute": ("boolean", False, ""),
        "Volume": ("ui2", False, "<allowedValueRange><minimum>0</minimum><maximum>100</maximum><step>1</step></allowedValueRange>"),
        "A_ARG_TYPE_Channel": ("string", False, _allowed("Master")), "A_ARG_TYPE_InstanceID": ("ui4", False, ""),
        "A_ARG_TYPE_PresetName": ("string", False, _allowed("FactoryDefaults")),
    }),
    "cm": _scpd({
        "GetProtocolInfo": [("Source", "out", "SourceProtocolInfo"), ("Sink", "out", "SinkProtocolInfo")],
        "GetCurrentConnectionIDs": [("ConnectionIDs", "out", "CurrentConnectionIDs")],
        "GetCurrentConnectionInfo": [("ConnectionID", "in", "A_ARG_TYPE_ConnectionID"), ("RcsID", "out", "A_ARG_TYPE_RcsID"),
                                     ("AVTransportID", "out", "A_ARG_TYPE_AVTransportID"), ("ProtocolInfo", "out", "A_ARG_TYPE_ProtocolInfo"),
                                     ("PeerConnectionManager", "out", "A_ARG_TYPE_ConnectionManager"),
                                     ("PeerConnectionID", "out", "A_ARG_TYPE_ConnectionID"), ("Direction", "out", "A_ARG_TYPE_Direction"),
                                     ("Status", "out", "A_ARG_TYPE_ConnectionStatus")],
    }, {
        "SourceProtocolInfo": ("string", True, ""), "SinkProtocolInfo": ("string", True, ""),
        "CurrentConnectionIDs": ("string", True, ""),
        "A_ARG_TYPE_ConnectionStatus": ("string", False, _allowed("OK", "ContentFormatMismatch", "InsufficientBandwidth", "UnreliableChannel", "Unknown")),
        "A_ARG_TYPE_ConnectionManager": ("string", False, ""), "A_ARG_TYPE_Direction": ("string", False, _allowed("Input", "Output")),
        "A_ARG_TYPE_ProtocolInfo": ("string", False, ""), "A_ARG_TYPE_ConnectionID": ("i4", False, ""),
        "A_ARG_TYPE_AVTransportID": ("i4", False, ""), "A_ARG_TYPE_RcsID": ("i4", False, ""),
    }),
}


# --------------------------------------------------------------------------
# Steuerung (SOAP)
# --------------------------------------------------------------------------
class Fault(Exception):
    def __init__(self, code, text):
        super().__init__(text)
        self.code, self.text = code, text


def _cmd(kind, **extra):
    S["cmd_id"] += 1
    S["cmd"] = kind
    S.update(extra)


def _open_player():
    if time.time() - S["player_seen"] > 4:
        H["request_nav"](LAUNCHER + f"player.html?cast={S['seq']}")


def avt_action(action, a):
    with _lock:
        if action == "SetAVTransportURI":
            uri = (a.get("CurrentURI") or "").strip()
            if not _media_url_ok(uri):
                raise Fault(716, "Resource not found")
            meta = a.get("CurrentURIMetaData") or ""
            S["title"], S["artist"], S["art"], S["kind"] = _parse_meta(meta, uri)
            S.update(uri=uri, meta=meta, seq=S["seq"] + 1, position=0.0, duration=0.0, transport="STOPPED")
            _log(f"DLNA: {S['kind']} „{S['title']}“")
            if S["kind"] == "image" or time.time() - S["player_seen"] < 4:
                # Fotos sofort zeigen; läuft schon etwas, direkt wechseln
                _cmd("play")
                S["transport"] = "TRANSITIONING"
                _open_player()
            changed = True
        elif action == "SetNextAVTransportURI":
            return {}
        elif action == "Play":
            if not S["uri"]:
                raise Fault(701, "Transition not available")
            _cmd("play")
            if S["transport"] in ("STOPPED", "NO_MEDIA_PRESENT"):
                S["transport"] = "TRANSITIONING"
            _open_player()
            changed = True
        elif action == "Pause":
            _cmd("pause")
            S["transport"] = "PAUSED_PLAYBACK"
            changed = True
        elif action == "Stop":
            _cmd("stop")
            S.update(transport="STOPPED", position=0.0)
            changed = True
        elif action == "Seek":
            target = _sec(a.get("Target", ""))
            if a.get("Unit") not in ("REL_TIME", "ABS_TIME") or target is None:
                raise Fault(710, "Seek mode not supported")
            _cmd(S["cmd"] or "play", seek=float(target))
            S["seek_id"] = S.get("seek_id", 0) + 1
            S["position"] = float(target)
            changed = True
        elif action in ("Next", "Previous"):
            return {}
        elif action == "GetTransportInfo":
            return {"CurrentTransportState": S["transport"], "CurrentTransportStatus": "OK", "CurrentSpeed": "1"}
        elif action == "GetPositionInfo":
            return {"Track": "1" if S["uri"] else "0", "TrackDuration": _hms(S["duration"]), "TrackMetaData": S["meta"],
                    "TrackURI": S["uri"], "RelTime": _hms(S["position"]), "AbsTime": _hms(S["position"]),
                    "RelCount": "2147483647", "AbsCount": "2147483647"}
        elif action == "GetMediaInfo":
            return {"NrTracks": "1" if S["uri"] else "0", "MediaDuration": _hms(S["duration"]), "CurrentURI": S["uri"],
                    "CurrentURIMetaData": S["meta"], "NextURI": "", "NextURIMetaData": "", "PlayMedium": "NETWORK",
                    "RecordMedium": "NOT_IMPLEMENTED", "WriteStatus": "NOT_IMPLEMENTED"}
        elif action == "GetDeviceCapabilities":
            return {"PlayMedia": "NETWORK", "RecMedia": "NOT_IMPLEMENTED", "RecQualityModes": "NOT_IMPLEMENTED"}
        elif action == "GetTransportSettings":
            return {"PlayMode": "NORMAL", "RecQualityMode": "NOT_IMPLEMENTED"}
        elif action == "GetCurrentTransportActions":
            acts = {"PLAYING": "Pause,Stop,Seek", "PAUSED_PLAYBACK": "Play,Stop,Seek", "STOPPED": "Play"}.get(S["transport"], "")
            return {"Actions": acts}
        else:
            raise Fault(401, "Invalid Action")
    if changed:
        notify_avt()
    return {}


def rc_action(action, a):
    if action == "GetVolume":
        return {"CurrentVolume": str(H["volume_get"]() if "volume_get" in H else 50)}
    if action == "SetVolume":
        try:
            v = max(0, min(100, int(a.get("DesiredVolume", ""))))
        except ValueError:
            raise Fault(402, "Invalid Args")
        if "volume_set" in H:
            H["volume_set"](v)
        return {}
    if action == "GetMute":
        return {"CurrentMute": "1" if H.get("mute_get", lambda: False)() else "0"}
    if action == "SetMute":
        if "mute_set" in H:
            H["mute_set"](a.get("DesiredMute", "0") in ("1", "true", "True"))
        return {}
    if action == "ListPresets":
        return {"CurrentPresetNameList": "FactoryDefaults"}
    if action == "SelectPreset":
        return {}
    raise Fault(401, "Invalid Action")


def cm_action(action, a):
    if action == "GetProtocolInfo":
        return {"Source": "", "Sink": SINK}
    if action == "GetCurrentConnectionIDs":
        return {"ConnectionIDs": "0"}
    if action == "GetCurrentConnectionInfo":
        return {"RcsID": "0", "AVTransportID": "0", "ProtocolInfo": "", "PeerConnectionManager": "",
                "PeerConnectionID": "-1", "Direction": "Input", "Status": "OK"}
    raise Fault(401, "Invalid Action")


ACTIONS = {"avt": avt_action, "rc": rc_action, "cm": cm_action}


def soap_response(svc, action, out):
    args = "".join(f"<{k}>{escape(str(v), quote=False)}</{k}>" for k, v in out.items())
    return (f'<?xml version="1.0" encoding="utf-8"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
            f's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body>'
            f'<u:{action}Response xmlns:u="{SVC[svc][0]}">{args}</u:{action}Response></s:Body></s:Envelope>')


def soap_fault(code, text):
    return ('<?xml version="1.0" encoding="utf-8"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
            's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><s:Fault><faultcode>s:Client</faultcode>'
            '<faultstring>UPnPError</faultstring><detail><UPnPError xmlns="urn:schemas-upnp-org:control-1-0">'
            f"<errorCode>{code}</errorCode><errorDescription>{escape(text)}</errorDescription></UPnPError></detail>"
            "</s:Fault></s:Body></s:Envelope>")


# --------------------------------------------------------------------------
# Ereignisse (GENA)
# --------------------------------------------------------------------------
def _last_change_avt():
    vals = {"TransportState": S["transport"], "CurrentTransportActions":
            {"PLAYING": "Pause,Stop,Seek", "PAUSED_PLAYBACK": "Play,Stop,Seek", "STOPPED": "Play"}.get(S["transport"], ""),
            "AVTransportURI": S["uri"], "CurrentTrackURI": S["uri"], "CurrentTrackDuration": _hms(S["duration"]),
            "CurrentMediaDuration": _hms(S["duration"]), "NumberOfTracks": "1" if S["uri"] else "0"}
    inner = "".join(f'<{k} val="{escape(str(v))}"/>' for k, v in vals.items())
    return f'<Event xmlns="urn:schemas-upnp-org:metadata-1-0/AVT/"><InstanceID val="0">{inner}</InstanceID></Event>'


def _last_change_rc():
    vol = H["volume_get"]() if "volume_get" in H else 50
    mute = "1" if H.get("mute_get", lambda: False)() else "0"
    return ('<Event xmlns="urn:schemas-upnp-org:metadata-1-0/RCS/"><InstanceID val="0">'
            f'<Volume channel="Master" val="{vol}"/><Mute channel="Master" val="{mute}"/></InstanceID></Event>')


def _propset(svc):
    if svc == "cm":
        props = {"SourceProtocolInfo": "", "SinkProtocolInfo": SINK, "CurrentConnectionIDs": "0"}
    else:
        props = {"LastChange": _last_change_avt() if svc == "avt" else _last_change_rc()}
    body = "".join(f"<e:property><{k}>{escape(v, quote=False)}</{k}></e:property>" for k, v in props.items())
    return f'<?xml version="1.0" encoding="utf-8"?><e:propertyset xmlns:e="urn:schemas-upnp-org:event-1-0">{body}</e:propertyset>'


def _send_event(sid, sub, body):
    for url in sub["urls"]:
        try:
            p = urlparse(url)
            c = http.client.HTTPConnection(p.hostname, p.port or 80, timeout=4)
            c.request("NOTIFY", p.path or "/", body=body.encode(), headers={
                "Content-Type": 'text/xml; charset="utf-8"', "NT": "upnp:event", "NTS": "upnp:propchange",
                "SID": sid, "SEQ": str(sub["seq"])})
            c.getresponse().read()
            c.close()
            break
        except (OSError, http.client.HTTPException):
            continue
    sub["seq"] = (sub["seq"] + 1) % 4294967295 or 1


def notify(svc):
    now = time.time()
    for sid, sub in list(_subs.items()):
        if sub["expires"] < now:
            _subs.pop(sid, None)
            continue
        if sub["svc"] == svc:
            threading.Thread(target=_send_event, args=(sid, sub, _propset(svc)), daemon=True).start()


def notify_avt():
    notify("avt")


# --------------------------------------------------------------------------
# Brücke zum Raspi-TV-Player (/api/cast)
# --------------------------------------------------------------------------
def player_report(data):
    """Der Player meldet Stand und holt sich Befehle ab."""
    changed = False
    with _lock:
        S["player_seen"] = time.time()
        st = data.get("state")
        if data.get("seq") == S["seq"]:
            try:
                S["position"] = max(0.0, float(data.get("position") or 0))
                S["duration"] = max(0.0, float(data.get("duration") or 0))
            except (TypeError, ValueError):
                pass
            new = {"playing": "PLAYING", "paused": "PAUSED_PLAYBACK", "ended": "STOPPED", "closed": "STOPPED",
                   "error": "STOPPED"}.get(st)
            if new and new != S["transport"] and not (S["transport"] == "TRANSITIONING" and st == "paused"):
                S["transport"] = new
                changed = True
            if st == "closed":
                S["player_seen"] = 0
        out = {"seq": S["seq"], "uri": S["uri"], "kind": S["kind"], "title": S["title"], "artist": S["artist"],
               "art": S["art"], "cmd": S["cmd"], "cmd_id": S["cmd_id"], "seek": S.get("seek", 0), "seek_id": S.get("seek_id", 0)}
    if changed:
        notify_avt()
    return out


# --------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = "Raspi-TV/1.0 UPnP/1.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, *_):
        pass

    def _send(self, code, body=b"", ctype="text/xml; charset=\"utf-8\"", extra=None):
        if isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def do_GET(self):
        if not H.get("enabled", lambda: True)():
            return self._send(404, "")
        p = self.path.split("?")[0]
        if p == "/dlna/desc.xml":
            return self._send(200, device_xml())
        m = re.match(r"^/dlna/(avt|rc|cm)\.xml$", p)
        if m:
            return self._send(200, SCPD[m.group(1)])
        return self._send(404, "")

    do_HEAD = do_GET

    def do_POST(self):
        m = re.match(r"^/dlna/ctl/(avt|rc|cm)$", self.path)
        if not m or not H.get("enabled", lambda: True)():
            return self._send(404, "")
        svc = m.group(1)
        length = min(int(self.headers.get("Content-Length") or 0), 512_000)
        raw = self.rfile.read(length)
        action = (self.headers.get("SOAPACTION") or "").strip('"').split("#")[-1]
        args = {}
        try:
            root = ET.fromstring(raw)
            body = next(el for el in root.iter() if el.tag.endswith("Body"))
            call = list(body)[0]
            action = call.tag.split("}")[-1] or action
            for el in call:
                args[el.tag.split("}")[-1]] = el.text or ""
        except (ET.ParseError, StopIteration, IndexError):
            return self._send(500, soap_fault(402, "Invalid Args"))
        try:
            out = ACTIONS[svc](action, args)
        except Fault as f:
            return self._send(500, soap_fault(f.code, f.text))
        except Exception as e:  # noqa: BLE001
            _log(f"DLNA-Fehler bei {action}: {e}")
            return self._send(500, soap_fault(501, "Action Failed"))
        return self._send(200, soap_response(svc, action, out), extra={"EXT": ""})

    def do_SUBSCRIBE(self):
        m = re.match(r"^/dlna/evt/(avt|rc|cm)$", self.path)
        if not m:
            return self._send(404, "")
        svc = m.group(1)
        timeout = 1800
        t = re.search(r"Second-(\d+)", self.headers.get("TIMEOUT", ""))
        if t:
            timeout = max(60, min(int(t.group(1)), 7200))
        sid = self.headers.get("SID")
        if sid:
            sub = _subs.get(sid)
            if not sub:
                return self._send(412, "")
            sub["expires"] = time.time() + timeout
        else:
            urls = [u for u in re.findall(r"<([^>]+)>", self.headers.get("CALLBACK", "")) if _private_url(u)]
            if not urls or self.headers.get("NT") != "upnp:event":
                return self._send(412, "")
            if len(_subs) > 50:   # alte Abos aufräumen
                for k in sorted(_subs, key=lambda k: _subs[k]["expires"])[:10]:
                    _subs.pop(k, None)
            sid = "uuid:" + str(uuidlib.uuid4())
            sub = _subs[sid] = {"svc": svc, "urls": urls[:3], "expires": time.time() + timeout, "seq": 0}
            threading.Timer(0.3, _send_event, args=(sid, sub, _propset(svc))).start()
        self._send(200, "", extra={"SID": sid, "TIMEOUT": f"Second-{timeout}"})

    def do_UNSUBSCRIBE(self):
        _subs.pop(self.headers.get("SID", ""), None)
        self._send(200, "")


# --------------------------------------------------------------------------
# SSDP (Ankündigen und Suchen beantworten)
# --------------------------------------------------------------------------
def _targets():
    u = "uuid:" + device_uuid()
    return [("upnp:rootdevice", u + "::upnp:rootdevice"), (u, u), (DEVICE_TYPE, u + "::" + DEVICE_TYPE)] + \
           [(t, u + "::" + t) for t, _ in SVC.values()]


def _ssdp_reply(sock, addr, st):
    ip = _ip_for(addr[0])
    if not ip:
        return
    for nt, usn in _targets():
        if st not in ("ssdp:all", nt):
            continue
        msg = ("HTTP/1.1 200 OK\r\nCACHE-CONTROL: max-age=1800\r\n"
               f"DATE: {email.utils.formatdate(usegmt=True)}\r\nEXT:\r\n"
               f"LOCATION: http://{ip}:{PORT}/dlna/desc.xml\r\nSERVER: Linux UPnP/1.0 Raspi-TV/1.0\r\n"
               f"ST: {nt}\r\nUSN: {usn}\r\nContent-Length: 0\r\n\r\n")
        try:
            sock.sendto(msg.encode(), addr)
        except OSError:
            pass


def ssdp_listener():
    while True:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            if hasattr(socket, "SO_REUSEPORT"):
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
            sock.bind(("", SSDP_PORT))
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP,
                            struct.pack("4sl", socket.inet_aton(SSDP_GROUP), socket.INADDR_ANY))
            while True:
                data, addr = sock.recvfrom(4096)
                if not H.get("enabled", lambda: True)():
                    continue
                txt = data.decode("utf-8", "replace")
                if not txt.startswith("M-SEARCH"):
                    continue
                st = re.search(r"(?im)^ST:\s*(.+?)\s*$", txt)
                mx = re.search(r"(?im)^MX:\s*(\d+)", txt)
                if st:
                    delay = random.uniform(0, min(int(mx.group(1)) if mx else 1, 2))
                    threading.Timer(delay, _ssdp_reply, args=(sock, addr, st.group(1))).start()
        except OSError as e:
            _log(f"DLNA: SSDP-Fehler {e}")
            time.sleep(30)


def _notify_all(nts):
    ip = _ip_for("192.0.2.1")
    if not ip:
        return
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
    for nt, usn in _targets():
        msg = (f"NOTIFY * HTTP/1.1\r\nHOST: {SSDP_GROUP}:{SSDP_PORT}\r\nCACHE-CONTROL: max-age=1800\r\n"
               f"LOCATION: http://{ip}:{PORT}/dlna/desc.xml\r\nNT: {nt}\r\nNTS: {nts}\r\n"
               f"SERVER: Linux UPnP/1.0 Raspi-TV/1.0\r\nUSN: {usn}\r\n\r\n")
        try:
            s.sendto(msg.encode(), (SSDP_GROUP, SSDP_PORT))
        except OSError:
            pass
    s.close()


def ssdp_announcer():
    was = None
    while True:
        on = H.get("enabled", lambda: True)()
        if on:
            _notify_all("ssdp:alive")
        elif was:
            _notify_all("ssdp:byebye")
        was = on
        time.sleep(60 if on else 15)


def start(hooks):
    H.update(hooks)
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    threading.Thread(target=ssdp_listener, daemon=True).start()
    threading.Thread(target=ssdp_announcer, daemon=True).start()
    _log(f"DLNA: bereit auf Port {PORT}")
