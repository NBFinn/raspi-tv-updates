#!/bin/bash
# Optional: temperaturabhaengiger Zweikabel-Luefter an GPIO26 (physischer Pin 37).
set -eu
if [ "$(id -u)" != 0 ]; then exec sudo bash "$0" "$@"; fi
exec python3 "$(cd -- "$(dirname -- "$0")" && pwd)/fan-setup.py" "$@"
