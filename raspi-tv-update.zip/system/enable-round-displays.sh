#!/bin/bash
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo 'Bitte mit sudo ausfuehren.'; exit 1; }
if [ ! -e /dev/spidev0.0 ] || [ ! -e /dev/spidev1.0 ]; then
    echo 'Fuer getrennte Kabel werden SPI0 und SPI1 benoetigt.'
    echo 'Boot-Konfiguration vorbereiten? Sicherung wird erstellt. JA eingeben:'
    read -r answer
    [ "$answer" = JA ] || exit 1
    config=/boot/firmware/config.txt
    [ -f "$config" ] || config=/boot/config.txt
    [ -f "$config" ] || { echo 'Keine Pi-Boot-Konfiguration gefunden.'; exit 1; }
    if ! grep -q '^# Raspi-TV separate round displays$' "$config"; then
        cp -p -- "$config" "$config.raspi-tv-round-$(date +%Y%m%d-%H%M%S).bak"
        printf '\n[all]\n# Raspi-TV separate round displays\ndtparam=spi=on\ndtoverlay=spi1-1cs\n' >> "$config"
    fi
    echo 'Bitte den Pi neu starten und danach dieses Skript erneut ausfuehren.'
    echo 'Falls SPI1 weiter fehlt: Boot-Konfiguration und andere SPI-Overlays pruefen.'
    exit 0
fi
if ! python3 -c 'import spidev,gpiozero,PIL' 2>/dev/null; then
    echo 'Installiere die optionalen Display-Werkzeuge (Internet erforderlich) ...'
    apt-get update
    apt-get install -y --no-install-recommends python3-pil python3-spidev python3-gpiozero python3-lgpio
fi
echo 'Nur fuer die neue Verkabelung ohne Verteiler (ab 5.8.1):'
echo 'Display 1: SPI0 CE0, DC GPIO25, RST GPIO27.'
echo 'Display 2: SPI1 CE0, DC GPIO24, RST GPIO23.'
echo 'Displays nur bei stromlosem Pi anschliessen. Sind sie korrekt angeschlossen? JA eingeben:'
read -r answer
[ "$answer" = JA ] || exit 1
install -d -m 755 /var/lib/raspi-tv-round
touch /var/lib/raspi-tv-round/enabled-separate-pins
systemctl enable raspi-tv-round.service
systemctl restart raspi-tv-round.service
echo 'Runde Displays aktiviert. Protokoll: journalctl -u raspi-tv-round -n 30'
