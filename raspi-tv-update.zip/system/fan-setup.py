"""Opt-in kernel thermal control for a two-wire fan through an active-high driver.
GPIO26 is reserved for this feature; no GPIO is accessed by this setup utility.
"""
import argparse
import datetime
import os
from pathlib import Path
import re
import shutil
import tempfile

GPIO=26
BEGIN='# BEGIN RASPI-TV FAN'
END='# END RASPI-TV FAN'


def updated_config(original,enabled=True,on=60):
    if isinstance(on,bool) or not isinstance(on,int) or not 45<=on<=80:
        raise ValueError('Einschalttemperatur muss zwischen 45 und 80 Grad liegen.')
    lines=original.splitlines(keepends=True)
    starts=[i for i,line in enumerate(lines) if line.strip()==BEGIN]
    ends=[i for i,line in enumerate(lines) if line.strip()==END]
    if starts or ends:
        if len(starts)!=1 or len(ends)!=1 or starts[0]>=ends[0]:
            raise ValueError('Beschaedigter Luefter-Konfigurationsblock; keine Aenderung.')
        first,last=starts[0],ends[0]
        # Do not remove user-owned settings accidentally inserted inside our block.
        managed=[line.strip() for line in lines[first+1:last] if line.strip()]
        if len(managed)!=2 or managed[0]!='[all]' or not re.fullmatch(r'dtoverlay=gpio-fan,gpiopin=26,temp=\d+,hyst=10000',managed[1]):
            raise ValueError('Der Luefterblock wurde manuell geaendert; keine Aenderung.')
        outside=''.join(lines[:first]+lines[last+1:])
        if re.search(r'^\s*dtoverlay\s*=\s*(?:gpio-fan|pwm-gpio-fan|pwm-fan)(?:\s*[,#]|\s*$)',outside,re.M):
            raise ValueError('Weitere Luefter-Konfiguration gefunden; bitte zuerst pruefen.')
        block=f'{BEGIN}\n[all]\ndtoverlay=gpio-fan,gpiopin={GPIO},temp={on*1000},hyst=10000\n{END}\n' if enabled else ''
        return ''.join(lines[:first])+block+''.join(lines[last+1:])
    if re.search(r'^\s*dtoverlay\s*=\s*(?:gpio-fan|pwm-gpio-fan|pwm-fan)(?:\s*[,#]|\s*$)',original,re.M):
        raise ValueError('Eine vorhandene Luefter-Konfiguration wird nicht ueberschrieben.')
    if not enabled:return original
    # Put the managed block at EOF, under [all], independent of the preceding Pi filter.
    separator='' if not original or original.endswith('\n') else '\n'
    return original+separator+f'{BEGIN}\n[all]\ndtoverlay=gpio-fan,gpiopin={GPIO},temp={on*1000},hyst=10000\n{END}\n'


def configure(path,enabled=True,on=60):
    path=Path(path).resolve(strict=True)
    original=path.read_text(encoding='utf-8')
    updated=updated_config(original,enabled,on)
    if updated==original:return None
    stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    backup=path.with_name(path.name+'.raspi-tv-fan-'+stamp+'.bak')
    shutil.copy2(path,backup)
    fd,name=tempfile.mkstemp(prefix='.raspi-tv-fan-',dir=path.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8',newline='\n') as output:
            output.write(updated);output.flush();os.fsync(output.fileno())
        os.chmod(name,path.stat().st_mode & 0o777)
        os.replace(name,path)
    finally:
        Path(name).unlink(missing_ok=True)
    return backup


def main():
    parser=argparse.ArgumentParser(description='Luefter an GPIO26 (Steckplatz 37) einrichten.')
    parser.add_argument('--disable',action='store_true',help='eigene Lueftersteuerung entfernen')
    parser.add_argument('--on',type=int,default=60,help='Einschalttemperatur 45-80 Grad, Standard 60')
    args=parser.parse_args()
    if os.geteuid()!=0:parser.exit(1,'Bitte mit sudo ausfuehren.\n')
    if not 45<=args.on<=80:parser.error('Temperatur muss zwischen 45 und 80 Grad liegen.')
    config=next((p for p in (Path('/boot/firmware/config.txt'),Path('/boot/config.txt')) if p.is_file()),None)
    if config is None:parser.exit(1,'Keine Pi-Boot-Konfiguration gefunden.\n')
    if not args.disable and not (config.resolve().parent/'overlays/gpio-fan.dtbo').is_file():
        parser.exit(1,'Das gpio-fan-Overlay fehlt auf diesem System. Keine Aenderung.\n')
    if args.disable:
        print('Die eigene Lueftersteuerung entfernen? Wirksam nach Neustart.')
    else:
        print('Zweikabel-Luefter: GPIO26 / Steckplatz 37 steuert NUR den Treiber-Eingang.')
        print('Motor NICHT direkt an GPIO anschliessen! Aktives HIGH schaltet ein.')
        print(f'Ein ab {args.on} Grad, aus nach Abkuehlung unter etwa {args.on-10} Grad.')
        print('Passendes 3,3-V-kompatibles MOSFET-/Transistormodul und Versorgung angeschlossen?')
    if input('Nur bei passender Einrichtung mit JA bestaetigen: ').strip()!='JA':
        print('Abgebrochen. Keine Aenderung.');return
    try:backup=configure(config,not args.disable,args.on)
    except (OSError,ValueError) as error:parser.exit(1,str(error)+'\n')
    if backup:print('Sicherung: '+str(backup))
    else:print('Die gewuenschte Konfiguration ist bereits vorhanden.')
    print('Bitte den Pi neu starten. Die Regelung laeuft danach im Linux-Kernel, auch ohne TV-Oberflaeche.')
    print('Zum Pruefen: Der Luefter muss beim Erreichen der Temperatur tatsaechlich anlaufen.')


if __name__=='__main__':main()
