# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Sender
# ==========================================================================
def _norm(s):
    s = (s or "").lower()
    for a, b in (("ä", "ae"), ("ö", "oe"), ("ü", "ue"), ("ß", "ss")):
        s = s.replace(a, b)
    s = re.sub(r"\.de$", "", s)
    s = re.sub(r"[^a-z0-9]", "", s)
    return re.sub(r"(hd|uhd)$", "", s) or s


def base_channels():
    chans = _read_json(os.path.join(T["ROOT"], "channels.json"), [])
    overrides = _read_json(T["CHANNEL_OVERRIDES"], {})
    region = _cfg().get("region")
    out = []
    for ch in chans:
        ch = dict(ch)
        var = (ch.pop("variants", None) or {}).get(region)   # Regionalversion fürs eigene Bundesland
        if var:
            ch["source"], ch["url"] = var["source"], var["url"]
        url = overrides.get(ch.get("source") or ch["name"])
        if url:
            ch["url"] = url
        out.append(ch)
    return out


def custom_channels():
    return _read_json(_state("custom-channels.json"), [])


def all_channels(include_hidden=False):
    cfg = _cfg()
    chans = base_channels() + custom_channels()
    by_name = {}
    for ch in chans:
        by_name.setdefault(ch["name"], ch)
    order = [n for n in cfg.get("channel_order", []) if n in by_name]
    rest = [ch["name"] for ch in chans if ch["name"] not in order]
    hidden = set(cfg.get("channel_hidden", []))
    result = []
    for name in order + rest:
        if name in [r["name"] for r in result]:
            continue
        ch = by_name[name]
        item = {"name": ch["name"], "group": ch.get("group", ""), "url": ch["url"],
                "custom": bool(ch.get("custom")), "logo": ch.get("logo", "")}
        if include_hidden:
            item["hidden"] = name in hidden
            result.append(item)
        elif name not in hidden:
            result.append(item)
    return result


def channels_settings():
    return {"channels": all_channels(True), "m3u": _cfg().get("custom_m3u", "")}


def channels_config(data):
    order, hidden = data.get("order"), data.get("hidden")
    for v in (order, hidden):
        if not isinstance(v, list) or not all(isinstance(x, str) and len(x) < 80 for x in v):
            raise _err("Ungültige Senderliste")
    names = {c["name"] for c in all_channels(True)}
    if len([n for n in names if n not in hidden]) == 0:
        raise _err("Mindestens ein Sender muss sichtbar bleiben.")
    cfg = _cfg()
    cfg["channel_order"] = order[:500]
    cfg["channel_hidden"] = hidden[:500]
    _save(cfg)
    return channels_settings()


def channels_reset(_data=None):
    cfg = _cfg()
    cfg.pop("channel_order", None)
    cfg.pop("channel_hidden", None)
    _save(cfg)
    return channels_settings()


def parse_m3u_list(text):
    out, cur = [], None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("#EXTINF"):
            name = line.rsplit(",", 1)[-1].strip()
            g = re.search(r'group-title="([^"]*)"', line)
            cur = {"name": name[:60], "group": (g.group(1) if g else "Eigene Sender")[:40] or "Eigene Sender"}
            lg = re.search(r'tvg-logo="(https?://[^"]+)"', line)
            if lg:
                cur["logo"] = lg.group(1)[:300]
        elif line and not line.startswith("#") and cur:
            if re.match(r"^https?://\S+$", line):
                cur["url"] = line
                cur["custom"] = True
                out.append(cur)
            cur = None
    return out


def channels_m3u(data):
    url = (data.get("url") or "").strip()
    cfg = _cfg()
    if not url:
        cfg.pop("custom_m3u", None)
        _save(cfg)
        _write_json(_state("custom-channels.json"), [])
        return channels_settings()
    if not re.match(r"^https?://[^\s]{4,500}$", url):
        raise _err("Bitte eine Adresse beginnend mit http:// oder https:// eingeben.")
    try:
        text = _download(url, limit=5_000_000, timeout=20).decode("utf-8", "replace")
    except Exception as e:  # noqa: BLE001
        raise _err(f"Liste konnte nicht geladen werden ({e.__class__.__name__}).")
    chans = parse_m3u_list(text)[:400]
    if not chans:
        raise _err("In der Liste wurden keine Sender gefunden.")
    known = {c["name"] for c in base_channels()}
    for c in chans:
        if c["name"] in known:
            c["name"] += " (eigen)"
    _write_json(_state("custom-channels.json"), chans)
    cfg["custom_m3u"] = url
    _save(cfg)
    return channels_settings()


# ==========================================================================
# Programmführer (EPG)
# ==========================================================================
EPG_SOURCES = [
    "https://epgshare01.online/epgshare01/epg_ripper_DE1.xml.gz",
    "https://epg.pw/xmltv/epg_DE.xml.gz",
]
EPG_BEFORE, EPG_AFTER = 4 * 3600, 48 * 3600
_epg = {"mtime": 0, "data": {"updated": 0, "programs": {}}}
_epg_state = {"running": False, "error": None}


def _xmltv_time(s):
    s = (s or "").strip()
    dt = datetime.strptime(s[:14], "%Y%m%d%H%M%S")
    ts = calendar.timegm(dt.timetuple())
    m = re.search(r"([+-])(\d{2})(\d{2})$", s)
    if m:
        off = int(m.group(2)) * 3600 + int(m.group(3)) * 60
        ts -= off if m.group(1) == "+" else -off
    return ts


def parse_xmltv(fileobj, channels, now=None):
    """XMLTV einlesen und nur die eigenen Sender im Zeitfenster behalten."""
    now = now or time.time()
    keys = {}
    for ch in channels:
        for k in [ch["name"], ch.get("source", "")] + list(ch.get("epg", [])):
            if k:
                keys.setdefault(_norm(k), ch["name"])
                keys.setdefault(k.lower(), ch["name"])
    idmap, programs = {}, {}
    for _, el in ET.iterparse(fileobj, events=("end",)):
        if el.tag == "channel":
            cid = el.get("id", "")
            names = [cid] + [d.text or "" for d in el.findall("display-name")]
            for n in names:
                hit = keys.get(n.lower()) or keys.get(_norm(n))
                if hit:
                    idmap[cid] = hit
                    break
            el.clear()
        elif el.tag == "programme":
            name = idmap.get(el.get("channel", ""))
            if name:
                try:
                    start, stop = _xmltv_time(el.get("start")), _xmltv_time(el.get("stop"))
                except (ValueError, TypeError):
                    el.clear()
                    continue
                if stop > now - EPG_BEFORE and start < now + EPG_AFTER:
                    txt = lambda tag: ((el.findtext(tag) or "").strip())  # noqa: E731
                    programs.setdefault(name, []).append([
                        start, stop, txt("title")[:120], txt("sub-title")[:160],
                        txt("desc")[:700], txt("category")[:40]])
            el.clear()
    for lst in programs.values():
        lst.sort(key=lambda p: p[0])
    return programs


def epg_update_once():
    if _epg_state["running"]:
        return
    _epg_state["running"] = True
    try:
        chans = _read_json(os.path.join(T["ROOT"], "channels.json"), []) + custom_channels()
        last_err = None
        for src in EPG_SOURCES:
            try:
                raw = _download(src, limit=120_000_000, timeout=90)
                with tempfile.TemporaryFile() as tmp:
                    tmp.write(gzip.decompress(raw) if raw[:2] == b"\x1f\x8b" else raw)
                    tmp.seek(0)
                    programs = parse_xmltv(tmp, chans)
                if programs:
                    _write_json(_state("epg.json"), {"updated": time.time(), "source": src, "programs": programs})
                    _epg_state["error"] = None
                    return
                last_err = "keine passenden Sender"
            except Exception as e:  # noqa: BLE001
                last_err = f"{src.split('/')[2]}: {e.__class__.__name__}"
        _epg_state["error"] = last_err
    finally:
        _epg_state["running"] = False


def epg_updater():
    time.sleep(20)
    while True:
        epg_update_once()
        time.sleep(1800 if _epg_state["error"] else 6 * 3600)


def _epg_data():
    path = _state("epg.json")
    try:
        mt = os.path.getmtime(path)
    except OSError:
        return {"updated": 0, "programs": {}}
    if mt != _epg["mtime"]:
        _epg["data"] = _read_json(path, {"updated": 0, "programs": {}})
        _epg["mtime"] = mt
    return _epg["data"]


def _prog(p):
    return {"start": p[0], "stop": p[1], "title": p[2], "sub": p[3], "desc": p[4], "cat": p[5]}


def epg_now():
    now = time.time()
    out = {}
    for name, lst in _epg_data().get("programs", {}).items():
        cur = nxt = None
        for i, p in enumerate(lst):
            if p[0] <= now < p[1]:
                cur = p
                nxt = lst[i + 1] if i + 1 < len(lst) else None
                break
            if p[0] > now:
                nxt = p
                break
        out[name] = {"now": _prog(cur) if cur else None, "next": _prog(nxt) if nxt else None}
    return out


def epg_range(query):
    now = time.time()
    try:
        t0 = float(query.get("from", [now - 1800])[0])
        t1 = float(query.get("to", [now + 4 * 3600])[0])
    except ValueError:
        raise _err("Ungültiger Zeitraum")
    t1 = min(t1, t0 + 26 * 3600)
    out = {}
    for name, lst in _epg_data().get("programs", {}).items():
        out[name] = [_prog(p) for p in lst if p[1] > t0 and p[0] < t1]
    return {"from": t0, "to": t1, "programs": out}


def epg_status():
    d = _epg_data()
    return {"updated": d.get("updated", 0), "source": d.get("source"),
            "channels": len(d.get("programs", {})), "running": _epg_state["running"],
            "error": _epg_state["error"]}


def epg_refresh(_data=None):
    threading.Thread(target=epg_update_once, daemon=True).start()
    return {"ok": True}


# ==========================================================================
# Erinnerungen
# ==========================================================================
_rem_lock = threading.Lock()


def _reminders():
    return _read_json(_state("reminders.json"), [])


def _save_reminders(lst):
    now = time.time()
    lst = [r for r in lst if r["start"] > now - 6 * 3600][:200]
    _write_json(_state("reminders.json"), lst)
    return lst


def reminders_list():
    return {"reminders": sorted(_reminders(), key=lambda r: r["start"])}


def reminders_add(data):
    try:
        ch = str(data["channel"])[:80]
        start, stop = int(data["start"]), int(data.get("stop") or 0)
        title = str(data.get("title", ""))[:120]
    except (KeyError, TypeError, ValueError):
        raise _err("Ungültige Erinnerung")
    if start < time.time() - 60:
        raise _err("Die Sendung hat schon begonnen.")
    rid = f"{ch}|{start}"
    with _rem_lock:
        lst = [r for r in _reminders() if r["id"] != rid]
        lst.append({"id": rid, "channel": ch, "start": start, "stop": stop, "title": title, "notified": False})
        _save_reminders(lst)
    return reminders_list()


def reminders_remove(data):
    rid = str(data.get("id", ""))
    with _rem_lock:
        _save_reminders([r for r in _reminders() if r["id"] != rid])
    return reminders_list()


def reminders_due(query, headers):
    """Fällige Erinnerungen (1 Min. vorher bis 5 Min. nach Beginn). Liest die Raspi-TV-Erweiterung."""
    if headers.get("X-Raspi-TV") != "1":
        raise _err("forbidden", 403)
    now = time.time()
    due = []
    with _rem_lock:
        lst = _reminders()
        for r in lst:
            if not r.get("notified") and r["start"] - 60 <= now <= r["start"] + 300:
                r["notified"] = True
                due.append(r)
        if due:
            _save_reminders(lst)
    return {"due": due}
