# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Eigene Medien
# ==========================================================================
MEDIA_ROOT = "/media/raspi-tv"
THUMB_DIR = "/var/cache/raspi-tv/thumbs"
FS_OK = {"vfat", "exfat", "ntfs", "ext4", "ext3", "ext2", "btrfs", "hfsplus"}
EXT = {
    "video": {".mp4", ".m4v", ".mkv", ".webm", ".mov", ".avi", ".ts", ".mpg", ".mpeg", ".wmv"},
    "audio": {".mp3", ".m4a", ".aac", ".flac", ".ogg", ".opus", ".wav", ".wma"},
    "image": {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".heic"},
}
_thumb_sem = threading.Semaphore(2)
_mount_lock = threading.Lock()


def _ftype(name):
    ext = os.path.splitext(name)[1].lower()
    for t, exts in EXT.items():
        if ext in exts:
            return t
    return None


def _tv_ids():
    try:
        import pwd
        pw = pwd.getpwnam(T["TV_USER"])
        return pw.pw_uid, pw.pw_gid
    except (KeyError, ImportError):
        return 1000, 1000


def _usb_devices():
    code, out, _ = T["run"](["lsblk", "-J", "-b", "-o",
                             "NAME,PATH,FSTYPE,LABEL,MOUNTPOINT,RM,HOTPLUG,SIZE,TYPE"], 10)
    if code != 0:
        return []
    try:
        tree = json.loads(out).get("blockdevices", [])
    except ValueError:
        return []
    found = []

    def walk(devs, parent_hot=False):
        for d in devs:
            hot = parent_hot or d.get("rm") in (True, "1", 1) or d.get("hotplug") in (True, "1", 1)
            if hot and d.get("fstype") in FS_OK and d.get("type") in ("part", "disk"):
                found.append(d)
            walk(d.get("children") or [], hot)
    walk(tree)
    return found


def _mount_usb(dev):
    mp = dev.get("mountpoint")
    if mp:
        return mp if mp.startswith(MEDIA_ROOT) else None  # z. B. Systemlaufwerk – nicht anfassen
    target = os.path.join(MEDIA_ROOT, "usb-" + re.sub(r"[^A-Za-z0-9_-]", "", dev["name"]))
    os.makedirs(target, exist_ok=True)
    fstype = "ntfs3" if dev["fstype"] == "ntfs" else dev["fstype"]
    uid, gid = _tv_ids()
    opts = "ro,nosuid,nodev,noexec"
    if fstype in ("vfat", "exfat", "ntfs3"):
        opts += f",uid={uid},gid={gid},iocharset=utf8" if fstype != "ntfs3" else f",uid={uid},gid={gid}"
    code, _, _ = T["run"](["mount", "-t", fstype, "-o", opts, dev["path"], target], 20)
    if code != 0:
        code, _, _ = T["run"](["mount", "-o", "ro,nosuid,nodev,noexec", dev["path"], target], 20)
    return target if code == 0 else None


def _cleanup_usb(present):
    for d in glob.glob(os.path.join(MEDIA_ROOT, "usb-*")):
        if d in present:
            continue
        if os.path.ismount(d):
            T["run"](["umount", "-l", d], 10)
        try:
            os.rmdir(d)
        except OSError:
            pass


def _share_dir(sid):
    return os.path.join(MEDIA_ROOT, "net-" + sid)


def _mount_share(sh):
    target = _share_dir(sh["id"])
    if os.path.ismount(target):
        return True, None
    os.makedirs(target, exist_ok=True)
    uid, gid = _tv_ids()
    cred = _state("shares", sh["id"] + ".cred")
    base = f"ro,nosuid,nodev,noexec,uid={uid},gid={gid},iocharset=utf8,soft,echo_interval=10"
    base += f",credentials={cred}" if os.path.exists(cred) else ",guest"
    last = ""
    for extra in ("", ",vers=3.0", ",vers=2.1", ",vers=2.0", ",vers=1.0"):
        code, out, err = T["run"](["mount", "-t", "cifs", f"//{sh['server']}/{sh['share']}", target,
                                   "-o", base + extra], 25)
        if code == 0:
            return True, None
        last = (err or out).strip()
    return False, last


def media_sources():
    os.makedirs(MEDIA_ROOT, exist_ok=True)
    out = []
    with _mount_lock:
        present = set()
        for dev in _usb_devices():
            mp = _mount_usb(dev)
            if mp:
                present.add(mp)
                size = int(dev.get("size") or 0)
                out.append({"id": os.path.basename(mp), "name": dev.get("label") or "USB-Stick",
                            "kind": "usb", "size": size, "online": True})
        _cleanup_usb(present)
        for sh in _cfg().get("shares", []):
            ok = os.path.ismount(_share_dir(sh["id"]))
            out.append({"id": "net-" + sh["id"], "name": sh["name"], "kind": "net",
                        "server": sh["server"], "share": sh["share"], "online": ok})
    return {"sources": out}


def _source_root(src):
    if not re.match(r"^(usb|net)-[A-Za-z0-9_-]{1,40}$", src or ""):
        raise _err("Unbekannte Quelle", 404)
    root = os.path.join(MEDIA_ROOT, src)
    if src.startswith("net-"):
        sh = next((s for s in _cfg().get("shares", []) if "net-" + s["id"] == src), None)
        if not sh:
            raise _err("Unbekannte Freigabe", 404)
        ok, err = _mount_share(sh)
        if not ok:
            raise _err("Freigabe nicht erreichbar – ist der Rechner/NAS eingeschaltet? " + (err or "")[:100], 502)
    if not os.path.isdir(root):
        raise _err("Quelle nicht verfügbar – Stick eingesteckt?", 404)
    return os.path.realpath(root)


def _resolve(src, rel):
    root = _source_root(src)
    path = os.path.realpath(os.path.join(root, (rel or "").lstrip("/")))
    if path != root and not path.startswith(root + os.sep):
        raise _err("Ungültiger Pfad", 403)
    return root, path


def _natural(s):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", s)]


def media_list(query):
    src = query.get("src", [""])[0]
    rel = query.get("path", [""])[0]
    root, path = _resolve(src, rel)
    if not os.path.isdir(path):
        raise _err("Ordner nicht gefunden", 404)
    dirs, files = [], []
    try:
        names = os.listdir(path)
    except OSError as e:
        raise _err(f"Ordner kann nicht gelesen werden ({e.strerror})", 500)
    for name in names:
        if name.startswith(".") or name in ("System Volume Information", "$RECYCLE.BIN", "lost+found"):
            continue
        full = os.path.join(path, name)
        relp = os.path.relpath(full, root)
        try:
            st = os.stat(full)
        except OSError:
            continue
        if os.path.isdir(full):
            cover = next((c for c in ("folder.jpg", "cover.jpg", "Folder.jpg", "Cover.jpg", "poster.jpg")
                          if os.path.exists(os.path.join(full, c))), None)
            dirs.append({"name": name, "path": relp, "type": "dir",
                         "cover": os.path.join(relp, cover) if cover else None})
        else:
            t = _ftype(name)
            if t:
                files.append({"name": name, "path": relp, "type": t, "size": st.st_size, "mtime": int(st.st_mtime)})
    dirs.sort(key=lambda e: _natural(e["name"]))
    files.sort(key=lambda e: _natural(e["name"]))
    parent = None if path == root else os.path.relpath(os.path.dirname(path), root)
    if parent == ".":
        parent = ""
    return {"src": src, "path": os.path.relpath(path, root) if path != root else "",
            "parent": parent, "entries": dirs + files}


def _thumb_path(path):
    st = os.stat(path)
    h = hashlib.sha1(f"{path}|{st.st_mtime}|{st.st_size}".encode()).hexdigest()
    return os.path.join(THUMB_DIR, h + ".jpg")


def make_thumb(path, kind):
    os.makedirs(THUMB_DIR, exist_ok=True)
    out = _thumb_path(path)
    if os.path.exists(out):
        return out
    vf = "scale=480:-2:force_original_aspect_ratio=decrease"
    with _thumb_sem:
        if os.path.exists(out):
            return out
        tmp = out + ".part.jpg"
        if kind == "video":
            attempts = [["-ss", "30"], ["-ss", "3"], []]
        else:
            attempts = [[]]
        for pre in attempts:
            cmd = ["ffmpeg", "-nostdin", "-loglevel", "error", "-y"] + pre + ["-i", path,
                   "-map", "0:v:0", "-frames:v", "1", "-vf", vf, "-q:v", "6", tmp]
            code, _, _ = T["run"](cmd, 25)
            if code == 0 and os.path.exists(tmp) and os.path.getsize(tmp) > 0:
                os.replace(tmp, out)
                return out
        try:
            os.remove(tmp)
        except OSError:
            pass
    return None


# ---- Dateien ausliefern (mit Range, damit Spulen funktioniert) -----------------
def serve_media(handler, path, query):
    src = query.get("src", [""])[0]
    rel = query.get("path", [""])[0]
    try:
        _, full = _resolve(src, rel)
    except Exception as e:  # noqa: BLE001
        return handler._json(getattr(e, "code", 404), {"error": str(e)})
    if not os.path.isfile(full):
        return handler._json(404, {"error": "Datei nicht gefunden"})
    if path == "/media/thumb":
        kind = _ftype(full)
        if kind not in ("video", "image", "audio"):
            return handler._json(404, {"error": "kein Vorschaubild"})
        thumb = make_thumb(full, kind)
        if not thumb:
            return handler._json(404, {"error": "kein Vorschaubild"})
        return _send_file(handler, thumb, "image/jpeg", cache=True)
    ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
    if full.lower().endswith(".mkv"):
        ctype = "video/webm"  # Chromium spielt Matroska (H.264/VP9) über den WebM-Pfad
    return _send_file(handler, full, ctype)


def _send_file(handler, full, ctype, cache=False):
    size = os.path.getsize(full)
    start, end = 0, size - 1
    rng = handler.headers.get("Range")
    status = 200
    if rng:
        m = re.match(r"bytes=(\d*)-(\d*)", rng)
        if m:
            if m.group(1):
                start = int(m.group(1))
                if m.group(2):
                    end = min(int(m.group(2)), size - 1)
            elif m.group(2):
                start = max(0, size - int(m.group(2)))
            if start > end or start >= size:
                handler.send_response(416)
                handler.send_header("Content-Range", f"bytes */{size}")
                handler.end_headers()
                return
            status = 206
    handler.send_response(status)
    handler.send_header("Content-Type", ctype)
    handler.send_header("Accept-Ranges", "bytes")
    handler.send_header("Content-Length", str(end - start + 1))
    if status == 206:
        handler.send_header("Content-Range", f"bytes {start}-{end}/{size}")
    if cache:
        handler.send_header("X-Raspi-Cache", "1")
    handler.end_headers()
    try:
        with open(full, "rb") as f:
            f.seek(start)
            left = end - start + 1
            while left > 0:
                chunk = f.read(min(262144, left))
                if not chunk:
                    break
                handler.wfile.write(chunk)
                left -= len(chunk)
    except (BrokenPipeError, ConnectionResetError):
        pass


# ---- Netzwerkfreigaben -----------------------------------------------------------
def shares_add(data):
    name = str(data.get("name") or "").strip()[:40]
    server = str(data.get("server") or "").strip().strip("/\\")
    share = str(data.get("share") or "").strip().strip("/\\")
    user = str(data.get("user") or "").strip()
    pw = str(data.get("password") or "")
    if server.startswith("smb:"):
        server = server[4:].strip("/")
    if "/" in server or "\\" in server:
        server, _, rest = server.replace("\\", "/").partition("/")
        share = share or rest
    if not re.match(r"^[A-Za-z0-9._-]{1,100}$", server):
        raise _err("Bitte Name oder IP-Adresse des Rechners/NAS eingeben (z. B. fritz.box oder 192.168.178.20).")
    if not re.match(r"^[^\x00-\x1f/\\]{1,100}$", share):
        raise _err("Bitte den Namen der Freigabe eingeben (z. B. FRITZ.NAS oder Videos).")
    if user and not re.match(r"^[^\x00-\x1f,]{1,100}$", user):
        raise _err("Ungültiger Benutzername")
    if "\n" in pw or len(pw) > 200:
        raise _err("Ungültiges Passwort")
    sid = hashlib.sha1(f"{server}/{share}/{time.time()}".encode()).hexdigest()[:10]
    sh = {"id": sid, "name": name or share, "server": server, "share": share, "user": user}
    if user:
        os.makedirs(_state("shares"), mode=0o700, exist_ok=True)
        cred = _state("shares", sid + ".cred")
        fd = os.open(cred, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(f"username={user}\npassword={pw}\n")
    ok, err = _mount_share(sh)
    if not ok:
        try:
            os.remove(_state("shares", sid + ".cred"))
        except OSError:
            pass
        try:
            os.rmdir(_share_dir(sid))
        except OSError:
            pass
        hint = "Benutzername/Passwort prüfen." if "13" in (err or "") or "denied" in (err or "").lower() \
            else "Name/Adresse und Freigabe prüfen."
        raise _err(f"Verbindung fehlgeschlagen – {hint}")
    cfg = _cfg()
    cfg.setdefault("shares", []).append(sh)
    _save(cfg)
    return media_sources()


def shares_remove(data):
    sid = str(data.get("id") or "").replace("net-", "", 1)
    cfg = _cfg()
    cfg["shares"] = [s for s in cfg.get("shares", []) if s["id"] != sid]
    _save(cfg)
    d = _share_dir(sid)
    if os.path.ismount(d):
        T["run"](["umount", "-l", d], 10)
    for p in (_state("shares", sid + ".cred"),):
        try:
            os.remove(p)
        except OSError:
            pass
    try:
        os.rmdir(d)
    except OSError:
        pass
    return media_sources()
