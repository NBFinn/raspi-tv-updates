# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Bild
# ==========================================================================
DISPLAY_FILE_NAME = "display-mode"


def _xrandr(args):
    return T["as_tv"](["env", "DISPLAY=:0", f"XAUTHORITY=/home/{T['TV_USER']}/.Xauthority", "xrandr"] + args, 15)


def display_info():
    code, out, err = _xrandr(["--query"])
    cfg = _cfg()
    info = {"output": None, "modes": [], "current": None, "saved": read_saved_mode(),
            "scale": cfg.get("ui_scale", 100), "available": code == 0}
    cur_out = None
    for line in out.splitlines():
        m = re.match(r"^(\S+) connected", line)
        if m:
            cur_out = m.group(1)
            if not info["output"]:
                info["output"] = cur_out
            continue
        if re.match(r"^\S", line):
            cur_out = None
            continue
        m = re.match(r"^\s+(\d+x\d+i?)\s+(.*)$", line)
        if m and cur_out == info["output"]:
            rates = []
            for r in re.findall(r"(\d+\.\d+)([ *+]*)", m.group(2)):
                rates.append(r[0])
                if "*" in r[1]:
                    info["current"] = f"{m.group(1)}@{r[0]}"
            info["modes"].append({"mode": m.group(1), "rates": rates})
    return info


def read_saved_mode():
    s = T["read_file"](_state(DISPLAY_FILE_NAME))
    return s or "auto"


def display_set(data):
    info = display_info()
    out = info["output"]
    if not out:
        raise _err("Kein Bildschirm erkannt.")
    mode = str(data.get("mode", "auto"))
    if mode == "auto":
        _xrandr(["--output", out, "--auto"])
        try:
            os.remove(_state(DISPLAY_FILE_NAME))
        except OSError:
            pass
    else:
        m = re.match(r"^(\d+x\d+i?)(?:@(\d+\.\d+))?$", mode)
        if not m or m.group(1) not in [x["mode"] for x in info["modes"]]:
            raise _err("Diese Auflösung wird nicht unterstützt.")
        args = ["--output", out, "--mode", m.group(1)] + (["--rate", m.group(2)] if m.group(2) else [])
        code, _, err = _xrandr(args)
        if code != 0:
            raise _err("Auflösung konnte nicht gesetzt werden: " + err.strip()[:100])
        os.makedirs(T["STATE_DIR"], exist_ok=True)
        with open(_state(DISPLAY_FILE_NAME), "w") as f:
            f.write(f"{out} {m.group(1)} {m.group(2) or ''}".strip())
    return display_info()


def display_scale(data):
    try:
        scale = int(data.get("scale"))
    except (TypeError, ValueError):
        raise _err("Ungültiger Wert")
    scale = max(80, min(110, scale))
    cfg = _cfg()
    cfg["ui_scale"] = scale
    _save(cfg)
    return {"scale": scale}


def cec_status():
    return {"adapter": bool(glob.glob("/dev/cec*")), "tv": T["tv_power"]()}


# ==========================================================================
# Routen
# ==========================================================================
GET_ROUTES = {
    "/api/channels": all_channels,
    "/api/channels/settings": channels_settings,
    "/api/epg/now": epg_now,
    "/api/epg/status": epg_status,
    "/api/reminders": reminders_list,
    "/api/media/sources": media_sources,
    "/api/display": display_info,
    "/api/cec": cec_status,
}
QUERY_ROUTES = {  # bekommen (query, headers)
    "/api/epg": lambda q, h: epg_range(q),
    "/api/reminders/due": reminders_due,
    "/api/media/list": lambda q, h: media_list(q),
}
POST_ROUTES = {
    "/api/channels/config": channels_config,
    "/api/channels/reset": channels_reset,
    "/api/channels/m3u": channels_m3u,
    "/api/epg/refresh": epg_refresh,
    "/api/reminders/add": reminders_add,
    "/api/reminders/remove": reminders_remove,
    "/api/media/shares/add": shares_add,
    "/api/media/shares/remove": shares_remove,
    "/api/display": display_set,
    "/api/display/scale": display_scale,
}
FILE_ROUTES = {"/media/file", "/media/thumb"}


def start_background():
    threading.Thread(target=epg_updater, daemon=True).start()


def thumb_url(src, rel):
    return f"/media/thumb?src={quote(src)}&path={quote(rel)}"
