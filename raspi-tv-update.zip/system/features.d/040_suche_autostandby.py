# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Suche im TV-Programm
# ==========================================================================
def epg_search(query):
    q = _norm((query.get("q", [""])[0] or "")[:60])
    if len(q) < 2:
        return {"results": []}
    now = time.time()
    order = {c["name"]: i for i, c in enumerate(all_channels())}
    res = []
    for name, lst in _epg_data().get("programs", {}).items():
        if name not in order:
            continue
        for p in lst:
            if p[1] <= now:
                continue
            if q in _norm(p[2]) or q in _norm(p[3]):
                d = _prog(p)
                d["channel"] = name
                d["index"] = order[name]
                res.append(d)
    res.sort(key=lambda r: (r["start"], r["index"]))
    return {"results": res[:60]}


# ==========================================================================
# Automatisch ausschalten (Auto-Standby) bei längerer Nichtbenutzung
# ==========================================================================
LAST_INPUT_FILE = "/run/raspi-tv/last-input"
_activity = {"last": time.time(), "left": None}


def touch_activity(_data=None):
    _activity["last"] = time.time()
    _activity["left"] = None
    return {"ok": True}


def last_input():
    try:
        return max(_activity["last"], os.path.getmtime(LAST_INPUT_FILE))
    except OSError:
        return _activity["last"]


def autooff_left():
    return _activity["left"]


def _set_tv_power(state):
    try:
        os.makedirs(os.path.dirname(T["TV_POWER_FILE"]), exist_ok=True)
        with open(T["TV_POWER_FILE"], "w") as f:
            f.write(state)
    except OSError:
        pass


def autooff_loop():
    while True:
        time.sleep(15)
        try:
            hours = int(_cfg().get("auto_off_hours", 4) or 0)
            if not hours or T["tv_power"]() == "standby":
                _activity["left"] = None
                continue
            left = last_input() + hours * 3600 - time.time()
            if left <= 0:
                _activity["left"] = None
                T["tv_standby"]()
                _set_tv_power("standby")
                touch_activity()
            elif left <= 120:
                _activity["left"] = int(left)   # Warnung wird in der Oberfläche angezeigt
            else:
                _activity["left"] = None
        except Exception:  # noqa: BLE001 – Hintergrundschleife darf nie sterben
            pass


QUERY_ROUTES["/api/epg/search"] = lambda q, h: epg_search(q)
OPEN_POST_ROUTES = {"/api/activity": touch_activity}   # harmlos, ohne Herkunftsprüfung (Erweiterung)
_old_start = start_background


def start_background():  # noqa: F811
    _old_start()
    threading.Thread(target=autooff_loop, daemon=True).start()
