# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Software-Update per USB-Stick
# ==========================================================================
import zipfile  # noqa: E402

UPDATE_DIR = "/var/cache/raspi-tv/update"
SWUPDATE_LOG = "/var/log/raspi-tv-swupdate.log"
_swu = {"running": False, "step": None, "done": False, "error": None, "version": None}


def _zip_names(zf):
    """Einträge mit normalisierten Pfaden (Windows-Zip nutzt manchmal Backslashes)."""
    out = []
    for info in zf.infolist():
        name = info.filename.replace("\\", "/").lstrip("/")
        parts = [p for p in name.split("/") if p not in ("", ".")]
        if not parts or ".." in parts:
            continue
        out.append((info, "/".join(parts)))
    return out


def _zip_root(names):
    """Ordner im Zip, in dem das Projekt liegt (system/tvctl.py)."""
    for n in names:
        if n.endswith("system/tvctl.py"):
            return n[: -len("system/tvctl.py")]
    return None


def _installed_version():
    for line in T["read_file"]("/etc/raspi-tv-release").splitlines():
        if line.startswith("VERSION="):
            return line.split("=", 1)[1].strip('"')
    return "?"


def swupdate_check():
    found = []
    for s in media_sources()["sources"]:
        if s["kind"] != "usb":
            continue
        root = os.path.join(MEDIA_ROOT, s["id"])
        try:
            names = os.listdir(root)
        except OSError:
            continue
        for n in sorted(names):
            if re.match(r"(?i)^raspi-tv-update.*\.zip$", n):
                path = os.path.join(root, n)
                ver = None
                try:
                    with zipfile.ZipFile(path) as zf:
                        names = _zip_names(zf)
                        r = _zip_root([x[1] for x in names])
                        if r is None:
                            continue
                        for info, nm in names:
                            if nm == r + "VERSION":
                                ver = zf.read(info).decode("utf-8", "replace").strip()[:20]
                except (zipfile.BadZipFile, OSError):
                    continue
                found.append({"src": s["id"], "file": n, "name": s["name"], "version": ver or "?",
                              "size": os.path.getsize(path)})
    return {"installed": _installed_version(), "found": found, "status": swupdate_status()}


def swupdate_status():
    tail = T["read_file"](SWUPDATE_LOG).splitlines()[-5:]
    return dict(_swu, log=tail)


def _swupdate_worker(zpath):
    try:
        shutil.rmtree(UPDATE_DIR, ignore_errors=True)
        os.makedirs(UPDATE_DIR)
        _swu["step"] = "Update wird entpackt"
        with zipfile.ZipFile(zpath) as zf:
            names = _zip_names(zf)
            root = _zip_root([n for _, n in names])
            if root is None:
                raise RuntimeError("Das ist kein Raspi-TV-Update-Paket.")
            total = 0
            for info, nm in names:
                # Ordner-Einträge (auch Windows-Zips mit "\\") und Browser-Zwischendateien überspringen
                if (not nm.startswith(root) or info.is_dir() or info.filename.endswith(("/", "\\"))
                        or "/_metadata/" in "/" + nm + "/"):
                    continue
                total += info.file_size
                if total > 300_000_000:
                    raise RuntimeError("Update-Paket ist zu groß.")
                dest = os.path.join(UPDATE_DIR, nm[len(root):])
                parent = os.path.dirname(dest)
                if os.path.isfile(parent):   # alter Fehler: Ordner war als Datei angelegt
                    os.remove(parent)
                os.makedirs(parent, exist_ok=True)
                with zf.open(info) as src, open(dest, "wb") as out:
                    shutil.copyfileobj(src, out)
        _unix_line_endings(UPDATE_DIR)
        for req in ("system/tvctl.py", "system/install-files.sh", "system/apply-update.sh", "launcher/index.html"):
            if not os.path.exists(os.path.join(UPDATE_DIR, req)):
                raise RuntimeError(f"Update-Paket unvollständig ({req} fehlt).")
        try:
            with open(os.path.join(UPDATE_DIR, "VERSION")) as f:
                _swu["version"] = f.read().strip()[:20]
        except OSError:
            pass
        _swu["step"] = "Aktuelle Version wird gesichert"
        snapshot = _rollback_snapshot()
        with open(SWUPDATE_LOG, "w") as log:
            p = subprocess.Popen(["bash", os.path.join(UPDATE_DIR, "system/apply-update.sh"), UPDATE_DIR],
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            for line in p.stdout:
                log.write(line)
                log.flush()
                if line.startswith("STEP "):
                    _swu["step"] = line[5:].strip()
            rc = p.wait()
        if rc != 0:
            raise RuntimeError("Installation fehlgeschlagen – Details im Protokoll.")
        if _swu.get("step") == "Fertig ohne Neustart":
            # 7.5: kein Neustart nötig – quick-restart.sh startet gleich Dienste und Browser neu und prüft danach
            _swu.update(done=True, quick=True, step="Raspi-TV wird neu geladen …")
            return
        _swu.update(done=True, quick=False, step="Raspi-TV startet neu …")
        # Neustart plant apply-update.sh; das hier ist nur der Rückfall.
        # Nach dem Start prüft raspi-tv-update-check, ob die neue Version läuft (sonst automatisch zurück).
        subprocess.Popen(["bash", "-c", "sleep 15; systemctl reboot"], start_new_session=True)
    except Exception as e:  # noqa: BLE001
        _swu["error"] = str(e)
    finally:
        _swu["running"] = False


def swupdate_install(data):
    if _swu["running"]:
        return swupdate_status()
    src, fname = str(data.get("src", "")), str(data.get("file", ""))
    if not re.match(r"(?i)^raspi-tv-update[^/\\]*\.zip$", fname):
        raise _err("Ungültige Update-Datei")
    root = _source_root(src)
    zpath = os.path.join(root, fname)
    if not os.path.isfile(zpath):
        raise _err("Update-Datei nicht gefunden – Stick noch eingesteckt?", 404)
    _swu.update(running=True, done=False, error=None, step="Wird vorbereitet", version=None)
    threading.Thread(target=_swupdate_worker, args=(zpath,), daemon=True).start()
    return swupdate_status()


import subprocess  # noqa: E402

GET_ROUTES["/api/swupdate"] = swupdate_check
GET_ROUTES["/api/swupdate/status"] = swupdate_status
POST_ROUTES["/api/swupdate/install"] = swupdate_install
