# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Wetter (Open-Meteo, kostenlos, ohne Anmeldung)
# ==========================================================================
REGION_CITIES = {
    "BW": ("Stuttgart", 48.78, 9.18), "BY": ("München", 48.14, 11.58), "BE": ("Berlin", 52.52, 13.40),
    "BB": ("Potsdam", 52.40, 13.06), "HB": ("Bremen", 53.08, 8.80), "HH": ("Hamburg", 53.55, 9.99),
    "HE": ("Frankfurt am Main", 50.11, 8.68), "MV": ("Rostock", 54.09, 12.10), "NI": ("Hannover", 52.37, 9.73),
    "NW": ("Köln", 50.94, 6.96), "RP": ("Mainz", 49.99, 8.27), "SL": ("Saarbrücken", 49.24, 6.99),
    "SN": ("Dresden", 51.05, 13.74), "ST": ("Magdeburg", 52.13, 11.62), "SH": ("Kiel", 54.32, 10.14),
    "TH": ("Erfurt", 50.98, 11.03),
}
_weather = {"key": None, "at": 0, "data": None}


def weather_place():
    cfg = _cfg()
    w = cfg.get("weather_place")
    if isinstance(w, dict) and "lat" in w:
        return w
    name, lat, lon = REGION_CITIES.get(cfg.get("region") or "", ("Berlin", 52.52, 13.40))
    return {"name": name, "lat": lat, "lon": lon}


def weather():
    place = weather_place()
    key = (round(place["lat"], 3), round(place["lon"], 3))
    if _weather["key"] == key and time.time() - _weather["at"] < 1200 and _weather["data"]:
        return _weather["data"]
    url = ("https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s"
           "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,relative_humidity_2m,is_day"
           "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max"
           "&timezone=Europe%%2FBerlin&forecast_days=6" % key)
    try:
        d = json.loads(_download(url, limit=200_000, timeout=15))
    except Exception:  # noqa: BLE001
        if _weather["data"]:
            return _weather["data"]
        raise _err("Wetter gerade nicht verfügbar", 503)
    cur = d.get("current", {})
    daily = d.get("daily", {})
    days = []
    for i, day in enumerate(daily.get("time", [])):
        days.append({"date": day, "code": daily["weather_code"][i], "max": daily["temperature_2m_max"][i],
                     "min": daily["temperature_2m_min"][i],
                     "rain": (daily.get("precipitation_probability_max") or [None] * 9)[i]})
    data = {"place": place["name"], "temp": cur.get("temperature_2m"), "feels": cur.get("apparent_temperature"),
            "code": cur.get("weather_code"), "wind": cur.get("wind_speed_10m"), "humidity": cur.get("relative_humidity_2m"),
            "day": cur.get("is_day", 1), "days": days, "at": time.time()}
    _weather.update(key=key, at=time.time(), data=data)
    return data


def weather_search(query):
    q = (query.get("q", [""])[0] or "").strip()[:60]
    if len(q) < 2:
        return {"results": []}
    url = "https://geocoding-api.open-meteo.com/v1/search?count=8&language=de&name=" + quote(q)
    try:
        d = json.loads(_download(url, limit=200_000, timeout=15))
    except Exception:  # noqa: BLE001
        raise _err("Ortssuche gerade nicht verfügbar", 503)
    res = []
    for r in d.get("results", []) or []:
        res.append({"name": r.get("name"), "lat": r.get("latitude"), "lon": r.get("longitude"),
                    "area": ", ".join(x for x in (r.get("admin1"), r.get("country")) if x)})
    return {"results": res}


def weather_set(data):
    cfg = _cfg()
    if data.get("reset"):
        cfg.pop("weather_place", None)
    else:
        try:
            place = {"name": str(data["name"])[:60], "lat": float(data["lat"]), "lon": float(data["lon"])}
        except (KeyError, TypeError, ValueError):
            raise _err("Ungültiger Ort")
        if not (-90 <= place["lat"] <= 90 and -180 <= place["lon"] <= 180):
            raise _err("Ungültiger Ort")
        cfg["weather_place"] = place
    _save(cfg)
    _weather["key"] = None
    return {"place": weather_place()}
