# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# AirPlay (Musik vom iPhone/Mac) & Gerätename
# ==========================================================================
def _airplay_running():
    code, out, _ = T["run"](["pgrep", "-u", T["TV_USER"], "-x", "shairport-sync"], 5)
    return code == 0


def airplay_start():
    if _airplay_running() or not shutil.which("shairport-sync"):
        return
    import pwd
    uid = pwd.getpwnam(T["TV_USER"]).pw_uid
    import socket
    name = _cfg().get("device_name") or socket.gethostname()
    subprocess.Popen(["runuser", "-u", T["TV_USER"], "--", "env", f"XDG_RUNTIME_DIR=/run/user/{uid}",
                      "shairport-sync", "-a", name, "-o", "pa"],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)


def airplay_stop():
    T["run"](["pkill", "-u", T["TV_USER"], "-x", "shairport-sync"], 5)


def airplay_status():
    return {"available": bool(shutil.which("shairport-sync")), "enabled": bool(_cfg().get("airplay")),
            "running": _airplay_running(), "name": _cfg().get("device_name") or __import__("socket").gethostname()}


def airplay_set(data):
    on = bool(data.get("enabled"))
    if on and not shutil.which("shairport-sync"):
        raise _err("AirPlay ist noch nicht installiert – bitte System aktualisieren.")
    cfg = _cfg()
    cfg["airplay"] = on
    _save(cfg)
    (airplay_start if on else airplay_stop)()
    time.sleep(0.5)
    return airplay_status()


def airplay_keeper():
    """Startet AirPlay nach dem Hochfahren (sobald der Ton des TV-Benutzers bereit ist) und hält es am Laufen."""
    time.sleep(25)
    while True:
        try:
            if _cfg().get("airplay") and not _airplay_running():
                airplay_start()
        except Exception:  # noqa: BLE001
            pass
        time.sleep(60)


def device_name_set(data):
    name = str(data.get("name") or "").strip()
    if not re.match(r"^[A-Za-z0-9][A-Za-z0-9-]{0,30}[A-Za-z0-9]$", name):
        raise _err("Bitte 2–32 Zeichen: Buchstaben, Ziffern und Bindestrich (keine Umlaute/Leerzeichen).")
    code, _, err = T["run"](["hostnamectl", "set-hostname", name], 15)
    if code != 0:
        raise _err("Name konnte nicht geändert werden: " + err.strip()[:80])
    try:
        with open("/etc/hosts") as f:
            hosts = f.read()
        hosts = re.sub(r"(?m)^127\.0\.1\.1\s+.*$", f"127.0.1.1\t{name}", hosts)
        if "127.0.1.1" not in hosts:
            hosts += f"127.0.1.1\t{name}\n"
        with open("/etc/hosts", "w") as f:
            f.write(hosts)
    except OSError:
        pass
    cfg = _cfg()
    cfg["device_name"] = name
    _save(cfg)
    T["run"](["systemctl", "restart", "avahi-daemon"], 15)
    if cfg.get("airplay"):
        airplay_stop()
        airplay_start()
    return {"name": name}


GET_ROUTES["/api/weather"] = weather
QUERY_ROUTES["/api/weather/search"] = lambda q, h: weather_search(q)
POST_ROUTES["/api/weather/place"] = weather_set
GET_ROUTES["/api/airplay"] = airplay_status
POST_ROUTES["/api/airplay"] = airplay_set
POST_ROUTES["/api/device-name"] = device_name_set
_old_start2 = start_background


def start_background():  # noqa: F811
    _old_start2()
    threading.Thread(target=airplay_keeper, daemon=True).start()
