# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# App Store
#   Web-Apps:  werden in der Konfiguration "installiert" (store_apps) und
#              erscheinen auf der Startseite. Der Katalog liegt im Launcher.
#   Eigene:    beliebige Webadresse als App (custom_apps).
#   Programme: echte Linux-Programme (Kodi, RetroArch, Moonlight) – werden
#              per apt installiert und als Vollbild über der Oberfläche gestartet.
# ==========================================================================
STORE_ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,31}$")
MOONLIGHT_LIST = "/etc/apt/sources.list.d/moonlight-game-streaming-moonlight-qt.list"
NATIVE_APPS = {
    "kodi": {"name": "Kodi", "pkgs": ["kodi"],
             "optional": ["kodi-inputstream-adaptive", "kodi-peripheral-joystick"],
             "bin": "kodi", "cmd": ["kodi", "-fs"], "procs": ["kodi.bin", "kodi"]},
    "retroarch": {"name": "RetroArch", "pkgs": ["retroarch"],
                  "optional": ["libretro-nestopia", "libretro-gambatte", "libretro-mgba", "libretro-snes9x",
                               "libretro-genesisplusgx", "libretro-desmume"],
                  "bin": "retroarch", "cmd": ["retroarch", "-f"], "procs": ["retroarch"]},
    "moonlight": {"name": "Moonlight", "pkgs": ["moonlight-qt"], "optional": [], "repo": "moonlight",
                  "bin": "moonlight-qt", "cmd": ["moonlight-qt"], "procs": ["moonlight-qt"]},
}
NATIVE_PID_FILE = "/run/raspi-tv-native"     # liest auch der Fernbedienungsdienst (Home beendet das Programm)
NATIVE_LOG = "/var/log/raspi-tv-store.log"
_job = {"running": False, "id": None, "action": None, "step": None, "percent": 0, "error": None, "done": False}
_native = {"id": None, "proc": None}
_apt_lock = threading.Lock()


def _valid_url(u):
    return isinstance(u, str) and len(u) <= 300 and re.match(r"^https?://[^\s\"'<>]+$", u) is not None


def store_state():
    cfg = _cfg()
    native = {k: {"installed": bool(shutil.which(v["bin"])), "running": _native["id"] == k and native_running()}
              for k, v in NATIVE_APPS.items()}
    return {"installed": cfg.get("store_apps", []), "custom": cfg.get("custom_apps", []),
            "native": native, "job": dict(_job)}


def store_install(data):
    app_id = str(data.get("id", ""))
    if not STORE_ID_RE.match(app_id) or app_id in NATIVE_APPS:
        raise _err("Unbekannte App")
    cfg = _cfg()
    lst = [a for a in cfg.get("store_apps", []) if a != app_id]
    lst.append(app_id)
    cfg["store_apps"] = lst[-80:]
    _save(cfg)
    return store_state()


def store_remove(data):
    app_id = str(data.get("id", ""))
    cfg = _cfg()
    cfg["store_apps"] = [a for a in cfg.get("store_apps", []) if a != app_id]
    cfg["custom_apps"] = [a for a in cfg.get("custom_apps", []) if a.get("id") != app_id]
    _save(cfg)
    return store_state()


def store_custom(data):
    name = str(data.get("name", "")).strip()[:30]
    url = str(data.get("url", "")).strip()
    if url and not re.match(r"^https?://", url, re.I):
        url = "http://" + url
    if not name:
        raise _err("Bitte einen Namen eingeben.")
    if not _valid_url(url):
        raise _err("Bitte eine gültige Adresse eingeben, z. B. http://192.168.178.20:8096")
    color = str(data.get("color", ""))
    if not re.match(r"^#[0-9a-fA-F]{6}$", color):
        color = "#334155"
    cfg = _cfg()
    lst = cfg.get("custom_apps", [])
    if len(lst) >= 30:
        raise _err("Es sind schon 30 eigene Apps angelegt.")
    app = {"id": "custom-" + hashlib.sha1((name + url + str(time.time())).encode()).hexdigest()[:8],
           "name": name, "url": url, "c1": color, "from": str(data.get("from", ""))[:32]}
    cfg["custom_apps"] = lst + [app]
    _save(cfg)
    return {"app": app, **store_state()}


# --- Programme (apt) -------------------------------------------------------
def _apt_env():
    env = dict(os.environ)
    env.update(DEBIAN_FRONTEND="noninteractive", APT_LISTCHANGES_FRONTEND="none", LC_ALL="C")
    return env


def _apt(args, log, lo, hi):
    """apt-get mit Fortschritt (APT::Status-Fd). Bildet 0–100 % auf lo–hi ab."""
    cmd = ["apt-get", "-y", "-o", "APT::Status-Fd=1", "-o", "Dpkg::Use-Pty=0",
           "-o", "DPkg::Lock::Timeout=300", "-o", "Dpkg::Options::=--force-confdef",
           "-o", "Dpkg::Options::=--force-confold"] + args
    log.write("$ " + " ".join(cmd) + "\n")
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, env=_apt_env())
    for line in p.stdout:
        log.write(line)
        log.flush()
        m = re.match(r"^(dlstatus|pmstatus):[^:]*:([\d.]+):(.*)$", line.strip())
        if m:
            pct = float(m.group(2))
            if m.group(1) == "dlstatus":
                _job["step"] = "Wird heruntergeladen"
                frac = pct / 200
            else:
                _job["step"] = "Wird installiert" if args[0] == "install" else "Wird entfernt"
                frac = 0.5 + pct / 200
            _job["percent"] = max(_job["percent"], int(lo + (hi - lo) * min(frac, 1)))
    return p.wait()


def _codename():
    for line in T["read_file"]("/etc/os-release").splitlines():
        if line.startswith("VERSION_CODENAME="):
            return line.split("=", 1)[1].strip().strip('"')
    return "trixie"


def _native_worker(app_id, action):
    app = NATIVE_APPS[app_id]
    try:
        with _apt_lock, open(NATIVE_LOG, "a") as log:
            log.write(f"\n=== {time.strftime('%Y-%m-%d %H:%M:%S')} {action} {app_id} ===\n")
            if action == "install":
                if app.get("repo") == "moonlight" and not os.path.exists(MOONLIGHT_LIST):
                    _job.update(step="Paketquelle wird eingerichtet", percent=2)
                    p = subprocess.run(
                        ["bash", "-c", "curl -1sLf 'https://dl.cloudsmith.io/public/moonlight-game-streaming/"
                         "moonlight-qt/setup.deb.sh' | env distro=raspbian codename=\"$1\" bash", "_", _codename()],
                        stdout=log, stderr=subprocess.STDOUT, env=_apt_env(), timeout=600)
                    if p.returncode != 0:
                        raise RuntimeError("Paketquelle von Moonlight nicht erreichbar.")
                else:
                    _job.update(step="Paketlisten werden geladen", percent=2)
                    _apt(["update"], log, 2, 8)
                _job["step"] = "Wird heruntergeladen"
                if _apt(["install"] + app["pkgs"], log, 8, 85) != 0:
                    if app.get("repo") == "moonlight":
                        try:
                            os.remove(MOONLIGHT_LIST)
                        except OSError:
                            pass
                    raise RuntimeError(f"{app['name']} konnte nicht installiert werden – "
                                       "für dieses System nicht verfügbar oder keine Verbindung.")
                opt = app.get("optional", [])
                for i, pkg in enumerate(opt):   # Zusätze einzeln – fehlt einer, ist das kein Fehler
                    _job["step"] = "Erweiterungen werden installiert"
                    _apt(["install", pkg], log, 85 + 14 * i / max(len(opt), 1), 85 + 14 * (i + 1) / max(len(opt), 1))
            else:
                native_stop()
                pkgs = [p for p in app["pkgs"] + app.get("optional", [])
                        if subprocess.run(["dpkg", "-s", p], capture_output=True).returncode == 0]
                if pkgs and _apt(["remove"] + pkgs, log, 5, 80) != 0:
                    raise RuntimeError(f"{app['name']} konnte nicht entfernt werden.")
                _job["step"] = "Wird aufgeräumt"
                _apt(["autoremove"], log, 80, 99)
                if app.get("repo") == "moonlight":
                    try:
                        os.remove(MOONLIGHT_LIST)
                    except OSError:
                        pass
        _job.update(done=True, percent=100, step="Fertig")
    except Exception as e:  # noqa: BLE001
        _job["error"] = str(e)
    finally:
        _job["running"] = False


def native_job(action):
    def handler(data):
        app_id = str(data.get("id", ""))
        if app_id not in NATIVE_APPS:
            raise _err("Unbekanntes Programm")
        if _job["running"]:
            raise _err("Es läuft schon eine Installation – bitte kurz warten.", 409)
        _job.update(running=True, id=app_id, action=action, step="Wird vorbereitet", percent=0,
                    error=None, done=False)
        threading.Thread(target=_native_worker, args=(app_id, action), daemon=True).start()
        return store_state()
    return handler


# --- Programme starten ------------------------------------------------------
def native_running():
    p = _native["proc"]
    return p is not None and p.poll() is None


def _native_watch(proc, app_id):
    while proc.poll() is None:
        touch_activity()            # während Kodi & Co. laufen, nicht automatisch ausschalten
        for _ in range(30):
            if proc.poll() is not None:
                break
            time.sleep(1)
    try:
        os.remove(NATIVE_PID_FILE)
    except OSError:
        pass
    if _native["proc"] is proc:
        _native.update(id=None, proc=None)
    touch_activity()
    if app_id == "kodi":
        # Kodi spricht selbst HDMI-CEC – danach meldet sich Raspi-TV wieder beim Fernseher an
        T["run"](["systemctl", "restart", "raspi-tv-cec"], 20)


def native_launch(data):
    import pwd
    app_id = str(data.get("id", ""))
    app = NATIVE_APPS.get(app_id)
    if not app:
        raise _err("Unbekanntes Programm")
    if not shutil.which(app["bin"]):
        raise _err(f"{app['name']} ist nicht installiert.")
    if native_running():
        return native_status()
    user = T["TV_USER"]
    uid = pwd.getpwnam(user).pw_uid
    log = open(f"/var/log/raspi-tv/native-{app_id}.log", "w") if os.path.isdir("/var/log/raspi-tv") \
        else subprocess.DEVNULL
    proc = subprocess.Popen(["runuser", "-u", user, "--", "env", f"XDG_RUNTIME_DIR=/run/user/{uid}", "DISPLAY=:0",
                             f"XAUTHORITY=/home/{user}/.Xauthority", f"HOME=/home/{user}"] + app["cmd"],
                            stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, start_new_session=True,
                            cwd=f"/home/{user}" if os.path.isdir(f"/home/{user}") else "/")
    _native.update(id=app_id, proc=proc)
    try:
        with open(NATIVE_PID_FILE, "w") as f:
            f.write(f"{proc.pid}\n")
    except OSError:
        pass
    threading.Thread(target=_native_watch, args=(proc, app_id), daemon=True).start()
    return native_status()


def native_stop(_data=None):
    p = _native["proc"]
    if p is not None and p.poll() is None:
        import signal
        try:
            os.killpg(p.pid, signal.SIGTERM)
            for _ in range(30):
                if p.poll() is not None:
                    break
                time.sleep(0.1)
            if p.poll() is None:
                os.killpg(p.pid, signal.SIGKILL)
        except OSError:
            pass
    return native_status()


def native_status():
    app_id = _native["id"] if native_running() else None
    return {"running": app_id, "name": NATIVE_APPS[app_id]["name"] if app_id else None}


GET_ROUTES["/api/store"] = store_state
POST_ROUTES["/api/store/install"] = store_install
POST_ROUTES["/api/store/remove"] = store_remove
POST_ROUTES["/api/store/custom"] = store_custom
POST_ROUTES["/api/native/install"] = native_job("install")
POST_ROUTES["/api/native/remove"] = native_job("remove")
POST_ROUTES["/api/native/launch"] = native_launch
POST_ROUTES["/api/native/stop"] = native_stop
GET_ROUTES["/api/native"] = native_status
