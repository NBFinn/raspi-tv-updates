# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Spotify Connect (librespot aus dem Raspotify-Paket)
#   Der Pi erscheint in der Spotify-App als Lautsprecher "Raspi-TV".
#   Wird beim ersten Einschalten installiert, läuft als TV-Benutzer über PipeWire.
# ==========================================================================
RASPOTIFY_DEB = "https://dtcooper.github.io/raspotify/raspotify-latest_{arch}.deb"
SPOTIFY_EVENT_FILE = "/home/{user}/.cache/raspi-tv/spotify.json"
SPOTIFY_HOOK = "/opt/raspi-tv/spotify-event.sh"


def _spotify_running():
    code, _, _ = T["run"](["pgrep", "-u", T["TV_USER"], "-x", "librespot"], 5)
    return code == 0


def _device_name():
    return _cfg().get("device_name") or __import__("socket").gethostname()


def spotify_start():
    if _spotify_running() or not shutil.which("librespot"):
        return
    import pwd
    user = T["TV_USER"]
    uid = pwd.getpwnam(user).pw_uid
    cache = f"/home/{user}/.cache/librespot"
    base = ["runuser", "-u", user, "--", "env", f"XDG_RUNTIME_DIR=/run/user/{uid}", f"HOME=/home/{user}",
            "librespot", "--name", _device_name(), "--device-type", "tv", "--bitrate", "320",
            "--initial-volume", "70", "--enable-volume-normalisation", "--cache", cache, "--disable-audio-cache"]
    if os.path.exists(SPOTIFY_HOOK):
        base += ["--onevent", SPOTIFY_HOOK]
    log = open("/var/log/raspi-tv/spotify.log", "a") if os.path.isdir("/var/log/raspi-tv") else subprocess.DEVNULL
    # Erst PulseAudio-Ausgabe (PipeWire), sonst ALSA (über pipewire-alsa ebenfalls PipeWire)
    for backend in (["--backend", "pulseaudio"], ["--backend", "alsa"]):
        p = subprocess.Popen(base + backend, stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                             start_new_session=True, cwd="/")
        time.sleep(2)
        if p.poll() is None:
            return


def spotify_stop():
    T["run"](["pkill", "-u", T["TV_USER"], "-x", "librespot"], 5)
    try:
        os.remove(SPOTIFY_EVENT_FILE.format(user=T["TV_USER"]))
    except OSError:
        pass


def spotify_now():
    """Was gerade über Spotify Connect läuft (schreibt das Ereignis-Skript)."""
    if not _cfg().get("spotify"):
        return {"playing": False}
    try:
        with open(SPOTIFY_EVENT_FILE.format(user=T["TV_USER"])) as f:
            ev = json.load(f)
    except (OSError, ValueError):
        return {"playing": False}
    state_ = ev.get("state")
    return {"playing": state_ == "playing", "paused": state_ == "paused", "title": ev.get("title", "")[:120],
            "artist": ev.get("artist", "")[:120], "album": ev.get("album", "")[:120],
            "cover": ev.get("cover", "") if str(ev.get("cover", "")).startswith("https://") else "",
            "duration": ev.get("duration", 0), "position": ev.get("position", 0), "at": ev.get("at", 0)}


def spotify_status():
    job = dict(_job) if _job.get("id") == "spotify" else None
    return {"available": bool(shutil.which("librespot")), "enabled": bool(_cfg().get("spotify")),
            "running": _spotify_running(), "name": _device_name(), "job": job}


def _spotify_install_worker():
    try:
        with _apt_lock, open(NATIVE_LOG, "a") as log:
            log.write(f"\n=== {time.strftime('%Y-%m-%d %H:%M:%S')} install spotify-connect ===\n")
            _, arch, _ = T["run"](["dpkg", "--print-architecture"], 10)
            arch = arch.strip() or "arm64"
            os.makedirs("/var/cache/raspi-tv", exist_ok=True)
            deb = "/var/cache/raspi-tv/raspotify.deb"
            _job.update(step="Wird heruntergeladen", percent=10)
            p = subprocess.run(["curl", "-fsSL", "--retry", "3", "-o", deb, RASPOTIFY_DEB.format(arch=arch)],
                               stdout=log, stderr=subprocess.STDOUT, timeout=600)
            if p.returncode != 0:
                raise RuntimeError("Spotify Connect konnte nicht geladen werden – Internetverbindung prüfen.")
            _job.update(step="Wird installiert", percent=40)
            if _apt(["install", deb], log, 40, 95) != 0:
                raise RuntimeError("Spotify Connect konnte nicht installiert werden.")
            # Der Systemdienst des Pakets bleibt aus – Raspi-TV startet librespot selbst (Ton über PipeWire)
            T["run"](["systemctl", "disable", "--now", "raspotify"], 30)
            try:
                os.remove(deb)
            except OSError:
                pass
        spotify_start()
        _job.update(done=True, percent=100, step="Fertig")
    except Exception as e:  # noqa: BLE001
        _job["error"] = str(e)
        cfg = _cfg()
        cfg["spotify"] = False
        _save(cfg)
    finally:
        _job["running"] = False


def spotify_set(data):
    on = bool(data.get("enabled"))
    cfg = _cfg()
    cfg["spotify"] = on
    _save(cfg)
    if not on:
        spotify_stop()
        return spotify_status()
    if shutil.which("librespot"):
        spotify_start()
        return spotify_status()
    if _job["running"]:
        raise _err("Es läuft schon eine Installation – bitte kurz warten.", 409)
    _job.update(running=True, id="spotify", action="install", step="Wird vorbereitet", percent=0,
                error=None, done=False)
    threading.Thread(target=_spotify_install_worker, daemon=True).start()
    return spotify_status()


def spotify_keeper():
    time.sleep(30)   # nach dem Hochfahren: Ton des TV-Benutzers abwarten
    while True:
        try:
            if _cfg().get("spotify") and not _job["running"] and not _spotify_running():
                spotify_start()
        except Exception:  # noqa: BLE001
            pass
        time.sleep(60)


_old_device_name_set = device_name_set


def device_name_set(data):  # noqa: F811 – neuer Name auch für Spotify Connect
    r = _old_device_name_set(data)
    if _cfg().get("spotify"):
        spotify_stop()
        spotify_start()
    return r


POST_ROUTES["/api/device-name"] = device_name_set
GET_ROUTES["/api/spotify"] = spotify_status
POST_ROUTES["/api/spotify"] = spotify_set
GET_ROUTES["/api/spotify/now"] = spotify_now
_old_start3 = start_background


def start_background():  # noqa: F811
    _old_start3()
    threading.Thread(target=spotify_keeper, daemon=True).start()
