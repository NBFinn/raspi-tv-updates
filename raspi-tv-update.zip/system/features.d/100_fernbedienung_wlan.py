# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Fernbedienungs-WLAN
#   Ist Raspi-TV per LAN-Kabel verbunden, ist sein WLAN-Chip frei. Er spannt dann
#   ein eigenes kleines WLAN auf – nur für die Handy-Fernbedienung, OHNE Internet
#   (Weiterleitung ins Heimnetz wird blockiert). Praktisch, wenn das Heim-WLAN
#   nachts abgeschaltet wird.
# ==========================================================================
HOTSPOT_CON = "raspi-tv-remote"
HOTSPOT_IP = "10.42.0.1"
HOTSPOT_NFT = f"""table inet raspitv_remote {{
  chain block_forward {{
    type filter hook forward priority -150; policy accept;
    iifname "{{dev}}" drop
    oifname "{{dev}}" drop
  }}
}}
"""
_hs = {"error": None, "active": False, "step": None}


def _hs_cfg():
    p = _state("hotspot.json")
    try:
        with open(p) as f:
            c = json.load(f)
    except (OSError, ValueError):
        c = {}
    changed = False
    if not c.get("password"):
        import secrets
        alphabet = "abcdefghjkmnpqrstuvwxyz23456789"
        c["password"] = "".join(secrets.choice(alphabet) for _ in range(10))
        changed = True
    c.setdefault("mode", "off")        # off | night | always
    c.setdefault("internet", False)    # Internet über das LAN-Kabel des Pi weitergeben
    c.setdefault("start", 21)
    c.setdefault("end", 7)
    if changed:
        _hs_save(c)
    return c


def _hs_save(c):
    _write_json(_state("hotspot.json"), c)
    try:
        os.chmod(_state("hotspot.json"), 0o600)
    except OSError:
        pass


def _hs_ssid():
    return (_device_name() + " Fernbedienung")[:32]


def _wifi_dev():
    code, out, _ = T["run"](["nmcli", "-t", "-f", "DEVICE,TYPE", "device"], 10)
    for line in out.splitlines():
        parts = T["nm_split"](line)
        if len(parts) >= 2 and parts[1] == "wifi":
            return parts[0]
    return None


def _hs_should_run(c, now=None):
    if c["mode"] == "always":
        return True
    if c["mode"] != "night":
        return False
    h = (now or datetime.now()).hour
    s, e = int(c["start"]), int(c["end"])
    return (h >= s or h < e) if s > e else (s <= h < e)


def _hs_active():
    code, out, _ = T["run"](["nmcli", "-t", "-f", "NAME", "connection", "show", "--active"], 10)
    return HOTSPOT_CON in out.splitlines()


HOTSPOT_LOG = "/var/log/raspi-tv/hotspot.log"
_hs_lock = threading.Lock()


def _hs_log(*parts):
    try:
        os.makedirs(os.path.dirname(HOTSPOT_LOG), exist_ok=True)
        with open(HOTSPOT_LOG, "a") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + " ".join(str(p) for p in parts) + "\n")
    except OSError:
        pass


def _nm_devices():
    _, out, _ = T["run"](["nmcli", "-t", "-f", "DEVICE,TYPE,STATE", "device"], 10)
    devs = []
    for line in out.splitlines():
        parts = T["nm_split"](line)
        if len(parts) >= 3:
            devs.append((parts[0], parts[1], parts[2]))
    return devs


def _eth_connected():
    # "connected" oder "connected (externally)" – Hauptsache, das LAN-Kabel steckt und hat eine Verbindung
    return any(t == "ethernet" and st.startswith("connected") for _, t, st in _nm_devices())


def _hs_ensure_packages():
    """dnsmasq (verteilt Adressen im Fernbedienungs-WLAN) und nftables (Internet-Sperre) bei Bedarf nachinstallieren."""
    missing = [pkg for pkg, binary in (("dnsmasq-base", "dnsmasq"), ("nftables", "nft")) if not shutil.which(binary)]
    if not missing:
        return
    _hs_log("Installiere", *missing)
    _hs["step"] = "Wird eingerichtet (lädt " + ", ".join(missing) + ") …"
    with _apt_lock:
        env = _apt_env()
        p = subprocess.run(["apt-get", "-y", "-o", "DPkg::Lock::Timeout=300", "install"] + missing,
                           capture_output=True, text=True, env=env, timeout=900)
        if p.returncode != 0:
            subprocess.run(["apt-get", "update"], capture_output=True, env=env, timeout=600)
            p = subprocess.run(["apt-get", "-y", "-o", "DPkg::Lock::Timeout=300", "install"] + missing,
                               capture_output=True, text=True, env=env, timeout=900)
        _hs_log("apt:", p.returncode, (p.stdout + p.stderr)[-600:])
    if p.returncode != 0:
        raise RuntimeError("Benötigte Pakete (" + ", ".join(missing) + ") konnten nicht installiert werden – Internet prüfen.")


def _hs_set_internet(dev, internet):
    """Ohne Internet-Freigabe sperrt eine Firewall-Regel die Weiterleitung ins Heimnetz/Internet.
    Mit Freigabe übernimmt NetworkManager (geteilte Verbindung) die Weiterleitung über das LAN-Kabel."""
    T["run"](["nft", "delete", "table", "inet", "raspitv_remote"], 10)
    if internet:
        T["run"](["sysctl", "-qw", "net.ipv4.ip_forward=1"], 10)
        _hs_log("Internet-Freigabe an")
        return
    p = subprocess.run(["nft", "-f", "-"], input=HOTSPOT_NFT.replace("{dev}", dev), text=True, capture_output=True)
    if p.returncode != 0:
        _hs_log("nft:", p.stderr)
        first = p.stderr.strip().splitlines()[0][:120] if p.stderr.strip() else ""
        raise RuntimeError("Sperre fürs Fernbedienungs-WLAN konnte nicht gesetzt werden" + (": " + first if first else "."))


def _hs_clients(dev):
    if not dev or not shutil.which("iw"):
        return None
    _, out, _ = T["run"](["iw", "dev", dev, "station", "dump"], 5)
    return out.count("Station ")


def _hs_up(c):
    dev = _wifi_dev()
    if not dev:
        raise RuntimeError("Kein WLAN-Chip gefunden.")
    if not _eth_connected():
        raise RuntimeError("Geht nur, wenn Raspi-TV per LAN-Kabel mit dem Router verbunden ist.")
    _hs_ensure_packages()
    _hs["step"] = "Wird gestartet …"
    # Erst festlegen, ob Internet weitergegeben wird, dann das WLAN einschalten
    _hs_set_internet(dev, c.get("internet"))
    # WLAN-Funk freigeben (ohne Ländereinstellung blockiert Raspberry Pi OS das WLAN)
    T["run"](["rfkill", "unblock", "wifi"], 10)
    T["run"](["nmcli", "radio", "wifi", "on"], 10)
    if shutil.which("iw"):
        _, reg, _ = T["run"](["iw", "reg", "get"], 10)
        if "country 00" in reg or not reg.strip():
            T["run"](["iw", "reg", "set", "DE"], 10)
    for _ in range(15):   # warten, bis der WLAN-Chip bereit ist
        st = next((s_ for d, _, s_ in _nm_devices() if d == dev), "")
        if st and st not in ("unavailable", "unmanaged"):
            break
        time.sleep(1)
    else:
        T["run"](["nmcli", "device", "set", dev, "managed", "yes"], 10)
        _hs_log("Gerätestatus vor dem Start:", st)
    T["run"](["nmcli", "connection", "delete", HOTSPOT_CON], 15)
    args = ["nmcli", "connection", "add", "type", "wifi", "ifname", dev, "con-name", HOTSPOT_CON,
            "autoconnect", "no", "ssid", _hs_ssid(),
            "802-11-wireless.mode", "ap", "802-11-wireless.band", "bg", "802-11-wireless.channel", "6",
            "ipv4.method", "shared", "ipv4.addresses", HOTSPOT_IP + "/24", "ipv4.never-default", "yes",
            "ipv6.method", "disabled",
            "wifi-sec.key-mgmt", "wpa-psk", "wifi-sec.psk", c["password"],
            "wifi-sec.proto", "rsn", "wifi-sec.pairwise", "ccmp", "wifi-sec.group", "ccmp", "wifi-sec.pmf", "1"]
    code, out, err = T["run"](args, 20)
    if code != 0:
        _hs_log("nmcli add:", code, out, err)
        raise RuntimeError("WLAN konnte nicht angelegt werden: " + (err or out).strip()[:120])
    last = ""
    for attempt in range(2):
        code, out, err = T["run"](["nmcli", "--wait", "30", "connection", "up", HOTSPOT_CON], 45)
        if code == 0:
            _hs_log("Fernbedienungs-WLAN aktiv auf", dev)
            return
        last = (err or out).strip()
        _hs_log("nmcli up (Versuch", attempt + 1, "):", code, last)
        T["run"](["nmcli", "device", "disconnect", dev], 15)
        time.sleep(3)
    hint = ""
    if "dnsmasq" in last.lower() or "ip configuration" in last.lower():
        hint = " (dnsmasq fehlt)"
    elif "secrets" in last.lower() or "802.1x" in last.lower():
        hint = " (WLAN-Chip unterstützt den Zugangspunkt-Modus nicht)"
    raise RuntimeError("WLAN konnte nicht gestartet werden" + hint + ": " + last[:140])


def _hs_down():
    if _hs_active():
        T["run"](["nmcli", "connection", "down", HOTSPOT_CON], 20)
    T["run"](["nft", "delete", "table", "inet", "raspitv_remote"], 10)


def hotspot_apply():
    if not _hs_lock.acquire(blocking=False):
        return   # läuft schon
    try:
        c = _hs_cfg()
        want = _hs_should_run(c)
        active = _hs_active()
        try:
            if want and not active:
                _hs_up(c)
            elif not want and active:
                _hs_down()
            _hs["error"] = None
        except Exception as e:  # noqa: BLE001
            _hs["error"] = str(e)
            _hs_log("Fehler:", e)
        _hs["active"] = _hs_active()
    finally:
        _hs["step"] = None
        _hs_lock.release()


def hotspot_status():
    c = _hs_cfg()
    ssid = _hs_ssid()
    token = T["remote_token"]()
    esc_ = lambda s: re.sub(r'([\;,:"])', r"\\\1", s)  # noqa: E731 – Sonderzeichen im WLAN-QR-Code
    active = _hs_active()
    return {"mode": c["mode"], "start": c["start"], "end": c["end"], "active": active, "internet": bool(c.get("internet")),
            "clients": _hs_clients(_wifi_dev()) if active else None,
            "ssid": ssid, "password": c["password"], "error": _hs["error"],
            "ethernet": _eth_connected(), "step": _hs.get("step"), "busy": _hs_lock.locked(),
            "wifi_qr": f"WIFI:T:WPA;S:{esc_(ssid)};P:{esc_(c['password'])};;",
            "remote_url": f"http://{HOTSPOT_IP}:{T['REMOTE_PORT']}/#{token}"}


def hotspot_set(data):
    c = _hs_cfg()
    if "mode" in data:
        if data["mode"] not in ("off", "night", "always"):
            raise _err("Ungültige Einstellung")
        c["mode"] = data["mode"]
    for k in ("start", "end"):
        if k in data:
            v = data[k]
            if not isinstance(v, int) or not 0 <= v <= 23:
                raise _err("Ungültige Uhrzeit")
            c[k] = v
    if "internet" in data:
        c["internet"] = bool(data["internet"])
        if _hs_active():   # sofort umstellen, ohne das WLAN neu zu starten
            try:
                _hs_set_internet(_wifi_dev(), c["internet"])
            except RuntimeError as e:
                raise _err(str(e))
    if data.get("new_password"):
        c["password"] = ""
        _hs_save(c)
        c = _hs_cfg()
        if _hs_active():
            _hs_down()
    _hs_save(c)
    _hs["error"] = None
    threading.Thread(target=hotspot_apply, daemon=True).start()   # Einrichten kann dauern – im Hintergrund
    time.sleep(0.3)
    return hotspot_status()


def hotspot_loop():
    time.sleep(20)
    while True:
        try:
            hotspot_apply()
        except Exception:  # noqa: BLE001
            pass
        time.sleep(30)


_old_device_name_set2 = device_name_set


def device_name_set(data):  # noqa: F811 – neuer Name auch für das Fernbedienungs-WLAN
    r = _old_device_name_set2(data)
    if _hs_active():
        _hs_down()
        hotspot_apply()
    return r


POST_ROUTES["/api/device-name"] = device_name_set
GET_ROUTES["/api/hotspot"] = hotspot_status
POST_ROUTES["/api/hotspot"] = hotspot_set
_old_start4 = start_background


def start_background():  # noqa: F811
    _old_start4()
    threading.Thread(target=hotspot_loop, daemon=True).start()
