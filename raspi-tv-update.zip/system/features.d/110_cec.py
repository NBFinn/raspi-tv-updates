# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Fernseher & Soundbar per HDMI-CEC
# ==========================================================================
_cec_cache = {"soundbar": None, "tvname": None, "at": 0}


_cec_sel = {"dev": None, "at": 0}
CEC_LOG = "/var/log/raspi-tv/cec.log"


def _cec_log(*parts):
    try:
        with open(CEC_LOG, "a") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + " ".join(str(p) for p in parts) + "\n")
    except OSError:
        pass


def _cec_dev():
    """Den HDMI-Anschluss nehmen, an dem wirklich ein Fernseher hängt (Pi 4/5 haben zwei: cec0 und cec1)."""
    devs = sorted(glob.glob("/dev/cec*"))
    if not devs:
        return None
    if _cec_sel["dev"] in devs and time.time() - _cec_sel["at"] < 300:
        return _cec_sel["dev"]
    chosen = None
    for d in devs:
        _, out, _ = T["run"](["cec-ctl", "-d", d], 6)
        m = re.search(r"Physical Address\s*:\s*([0-9a-f]\.[0-9a-f]\.[0-9a-f]\.[0-9a-f])", out)
        if m and m.group(1) != "f.f.f.f":
            chosen = d
            # noch nicht beim Fernseher angemeldet? Dann jetzt als Abspielgerät anmelden
            if re.search(r"Logical Address Mask\s*:\s*0x0000", out):
                T["run"](["cec-ctl", "-d", d, "--playback", "--osd-name", "Raspi-TV"], 10)
                _cec_log("angemeldet an", d)
            break
    chosen = chosen or devs[0]
    _cec_sel.update(dev=chosen, at=time.time())
    return chosen


def _cec(args, timeout=8, check=False):
    dev = _cec_dev()
    if not dev:
        raise _err("HDMI-CEC ist nicht verfügbar.")
    code, out, err = T["run"](["cec-ctl", "-d", dev] + args, timeout)
    nack = "Not Acknowledged" in out or "Not Acknowledged" in err or "Tx, Error" in out
    if check and (code != 0 or nack):
        _cec_log(dev, args, code, (out + err).strip()[-300:])
        _cec_sel["at"] = 0   # beim nächsten Mal Anschluss neu suchen
        raise _err("Der Fernseher antwortet nicht. Ist HDMI-CEC am Fernseher eingeschaltet "
                   "(Anynet+, SimpLink, Bravia Sync …)?")
    return code, out, err


def _cec_name(addr):
    try:
        code, out, _ = _cec(["--to", str(addr), "--give-osd-name"], 6)
    except Exception:  # noqa: BLE001
        return None
    m = re.search(r"name:\s*'?([^'\n]+)'?", out)
    return m.group(1).strip() if (code == 0 and m) else None


def _cec_devices(force=False):
    if force or time.time() - _cec_cache["at"] > 300:
        _cec_cache.update(soundbar=_cec_name(5), tvname=_cec_name(0), at=time.time())
    return _cec_cache


def _cec_key(cmd, to):
    _cec(["--to", str(to), "--user-control-pressed", f"ui-cmd={cmd}", "--user-control-released"], check=True)


def _phys_addr():
    code, out, _ = _cec([], 6)
    m = re.search(r"Physical Address\s*:\s*([0-9a-f]\.[0-9a-f]\.[0-9a-f]\.[0-9a-f])", out)
    return m.group(1) if m else None


def _volume_target():
    t = _cfg().get("volume_target", "auto")
    if t == "auto":
        # Mit Soundbar: die Soundbar (das klappt per CEC zuverlässig). Sonst Raspi-TV selbst –
        # viele Fernseher ignorieren Lautstärke-Befehle von angeschlossenen Geräten.
        if not _cec_dev():
            return "pi"
        return "soundbar" if _cec_devices()["soundbar"] else "pi"
    return t


def volume(data):
    action = data.get("action")
    if action not in ("up", "down", "mute"):
        raise _err("Ungültige Aktion")
    target = _volume_target()
    if target == "pi":
        if action == "mute":
            T["as_tv"](["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "toggle"], 10)
        else:
            T["as_tv"](["wpctl", "set-volume", "-l", "1.0", "@DEFAULT_AUDIO_SINK@",
                        "1%+" if action == "up" else "1%-"], 10)
        _, out, _ = T["as_tv"](["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"], 10)
        m = re.search(r"([\d.]+)", out)
        r = {"target": "pi", "volume": round(float(m.group(1)) * 100) if m else None, "muted": "MUTED" in out}
        _osd.update(volume=r["volume"], muted=r["muted"], at=time.time())
        return r
    cmd = {"up": "volume-up", "down": "volume-down", "mute": "mute"}[action]
    _cec_key(cmd, 5 if target == "soundbar" else 0)
    return {"target": target}


def cec_action(data):
    a = data.get("action")
    if a == "tv_on":
        _cec(["--to", "0", "--image-view-on"], check=True)
    elif a == "tv_off":
        _cec(["--to", "0", "--standby"], check=True)
        _set_tv_power("standby")
    elif a == "switch":
        pa = _phys_addr()
        if not pa or pa == "f.f.f.f":
            raise _err("Kein Fernseher gefunden.")
        _cec(["--to", "0", "--image-view-on"], check=True)
        _cec(["--to", "15", "--active-source", f"phys-addr={pa}"])
    elif a == "soundbar_off":
        _cec(["--to", "5", "--standby"])
    else:
        raise _err("Ungültige Aktion")
    return {"ok": True}


def cec_settings(data):
    cfg = _cfg()
    for k in ("cec_wake_tv", "cec_autoswitch"):
        if k in data:
            cfg[k] = bool(data[k])
    if "volume_target" in data:
        if data["volume_target"] not in ("auto", "tv", "soundbar", "pi"):
            raise _err("Ungültige Einstellung")
        cfg["volume_target"] = data["volume_target"]
    _save(cfg)
    return cec_status_full()


def cec_status_full():
    cfg = _cfg()
    dev = _cec_dev()
    d = _cec_devices() if dev else {"soundbar": None, "tvname": None}
    return {"adapter": bool(dev), "tv": T["tv_power"](), "tvname": d["tvname"], "soundbar": d["soundbar"],
            "wake_tv": cfg.get("cec_wake_tv", True), "autoswitch": cfg.get("cec_autoswitch", False),
            "volume_target": cfg.get("volume_target", "auto"), "volume_effective": _volume_target() if dev else "pi"}


GET_ROUTES["/api/cec"] = cec_status_full
POST_ROUTES["/api/cec"] = cec_settings
POST_ROUTES["/api/cec/action"] = cec_action
POST_ROUTES["/api/volume"] = volume
REMOTE_ROUTES_EXTRA = {
    "/r/volume": volume,
    "/r/cec": lambda d: cec_action(d) if d.get("action") in ("tv_on", "tv_off", "switch") else {"ok": False},
}
