# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Fernsteuerung der Oberfläche: Seite öffnen (Suche vom Handy, DLNA, …)
#   Die Browser-Erweiterung fragt alle 1,5 s nach und öffnet die Adresse im Vollbild.
# ==========================================================================
_nav = {"url": None, "at": 0}
_osd = {"volume": None, "muted": False, "at": 0}
LAUNCHER = "http://127.0.0.1:8765/"


def request_nav(url):
    _nav.update(url=url, at=time.time())


def nav_pending(_query, headers):
    if headers.get("X-Raspi-TV") != "1":
        raise _err("forbidden", 403)
    url, at = _nav["url"], _nav["at"]
    _nav.update(url=None)
    osd = None
    if _osd["at"] and time.time() - _osd["at"] < 3:
        osd = {"volume": _osd["volume"], "muted": _osd["muted"]}
        _osd["at"] = 0
    return {"url": url if url and time.time() - at < 20 else None, "osd": osd}


SEARCH_TARGETS = {
    "guide": lambda q: LAUNCHER + "#/search/" + quote(q, safe=""),
    "youtube": lambda q: "https://www.youtube.com/results?search_query=" + quote(q),
    "netflix": lambda q: "https://www.netflix.com/search?q=" + quote(q),
    "ard": lambda q: "https://www.ardmediathek.de/suche/" + quote(q, safe=""),
    "zdf": lambda q: "https://www.zdf.de/suche?q=" + quote(q),
    "store": lambda q: LAUNCHER + "#/store/search/" + quote(q, safe=""),
}


def remote_search(data):
    q = str(data.get("q", "")).strip()[:100]
    where = data.get("where", "guide")
    if not q or where not in SEARCH_TARGETS:
        raise _err("Bitte einen Suchbegriff eingeben.")
    touch_activity()
    request_nav(SEARCH_TARGETS[where](q))
    return {"ok": True}


QUERY_ROUTES["/api/nav/pending"] = nav_pending
REMOTE_ROUTES_EXTRA["/r/search"] = remote_search
