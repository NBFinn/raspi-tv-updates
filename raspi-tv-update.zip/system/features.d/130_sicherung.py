# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Einstellungen sichern & wiederherstellen (USB-Stick)
# ==========================================================================
NM_CONN_DIR = "/etc/NetworkManager/system-connections"
BACKUP_SKIP = re.compile(r"^(epg.*|.*\.tmp|.*\.log|cache.*|backups?)$")
BACKUP_NAME_RE = re.compile(r"(?i)^raspi-tv-sicherung[^/\\]*\.zip$")


def _usb_roots():
    return [(s["id"], s["name"], os.path.join(MEDIA_ROOT, s["id"]))
            for s in media_sources()["sources"] if s["kind"] == "usb"]


def _build_backup_zip(path):
    files = 0
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json", json.dumps({
            "raspi_tv_backup": 1, "version": _installed_version(), "created": time.time(),
            "device_name": _device_name()}, indent=2))
        for name in sorted(os.listdir(T["STATE_DIR"])):
            full = os.path.join(T["STATE_DIR"], name)
            if os.path.isfile(full) and not BACKUP_SKIP.match(name) and os.path.getsize(full) < 5_000_000:
                z.write(full, "state/" + name)
                files += 1
        if os.path.isdir(NM_CONN_DIR):
            for name in sorted(os.listdir(NM_CONN_DIR)):
                full = os.path.join(NM_CONN_DIR, name)
                try:
                    txt = open(full).read()
                except OSError:
                    continue
                if "type=wifi" in txt and "mode=ap" not in txt:   # gespeicherte WLANs, nicht das Fernbedienungs-WLAN
                    z.writestr("wifi/" + name, txt)
                    files += 1
    return files


def backup_create(data):
    roots = _usb_roots()
    if not roots:
        raise _err("Kein USB-Stick gefunden – bitte einen Stick einstecken.")
    src = str(data.get("src") or roots[0][0])
    root = next((r for r in roots if r[0] == src), None)
    if not root:
        raise _err("USB-Stick nicht gefunden.")
    mnt = root[2]
    fname = time.strftime("raspi-tv-sicherung-%Y-%m-%d-%H%M.zip")
    tmp = os.path.join("/var/cache/raspi-tv" if os.path.isdir("/var/cache/raspi-tv") else T["STATE_DIR"], fname)
    files = _build_backup_zip(tmp)
    code, _, err = T["run"](["mount", "-o", "remount,rw", mnt], 20)
    if code != 0:
        os.remove(tmp)
        raise _err("Auf diesen Stick kann nicht geschrieben werden (schreibgeschützt oder NTFS). "
                   "Bitte einen FAT32/exFAT-Stick nehmen.")
    try:
        shutil.copyfile(tmp, os.path.join(mnt, fname))
        T["run"](["sync"], 30)
    except OSError as e:
        raise _err(f"Speichern fehlgeschlagen: {e.strerror}")
    finally:
        T["run"](["mount", "-o", "remount,ro", mnt], 20)
        try:
            os.remove(tmp)
        except OSError:
            pass
    return {"ok": True, "file": fname, "stick": root[1], "files": files}


def backup_list():
    found = []
    for src, name, mnt in _usb_roots():
        try:
            entries = sorted(os.listdir(mnt), reverse=True)
        except OSError:
            continue
        for n in entries:
            if not BACKUP_NAME_RE.match(n):
                continue
            info = {"src": src, "file": n, "stick": name}
            try:
                with zipfile.ZipFile(os.path.join(mnt, n)) as z:
                    m = json.loads(z.read("manifest.json"))
                info.update(created=m.get("created"), version=m.get("version"), device=m.get("device_name"))
            except (KeyError, ValueError, zipfile.BadZipFile, OSError):
                continue
            found.append(info)
    return {"backups": found, "sticks": [{"src": s, "name": n} for s, n, _ in _usb_roots()]}


def backup_restore(data):
    fname = str(data.get("file", ""))
    if not BACKUP_NAME_RE.match(fname):
        raise _err("Ungültige Datei")
    path = os.path.join(_source_root(str(data.get("src", ""))), fname)
    if not os.path.isfile(path):
        raise _err("Sicherung nicht gefunden – Stick noch eingesteckt?", 404)
    safe = re.compile(r"^(state/[A-Za-z0-9._-]+|wifi/[^/\\]+\.nmconnection|manifest\.json)$")
    # vorher den aktuellen Stand lokal sichern
    try:
        _build_backup_zip(os.path.join(T["STATE_DIR"], "..", "raspi-tv-vor-wiederherstellung.zip"))
    except OSError:
        pass
    restored = 0
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        if "manifest.json" not in names or any(not safe.match(n) for n in names if not n.endswith("/")):
            raise _err("Das ist keine gültige Raspi-TV-Sicherung.")
        for n in names:
            if n.startswith("state/"):
                _write_bytes(os.path.join(T["STATE_DIR"], n[6:]), z.read(n), 0o600 if "token" in n or "hotspot" in n else 0o644)
                restored += 1
            elif n.startswith("wifi/") and os.path.isdir(NM_CONN_DIR):
                _write_bytes(os.path.join(NM_CONN_DIR, os.path.basename(n)), z.read(n), 0o600)
                restored += 1
    T["run"](["nmcli", "connection", "reload"], 20)
    # Oberfläche und Dienst mit den wiederhergestellten Einstellungen neu starten
    subprocess.Popen(["bash", "-c", "sleep 2; pkill -u tv -f raspi-tv-browser; systemctl restart raspi-tv-ctl"],
                     start_new_session=True)
    return {"ok": True, "restored": restored}


def _write_bytes(path, data, mode):
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
    os.chmod(tmp, mode)
    os.replace(tmp, path)


GET_ROUTES["/api/backup"] = backup_list
POST_ROUTES["/api/backup/create"] = backup_create
POST_ROUTES["/api/backup/restore"] = backup_restore
