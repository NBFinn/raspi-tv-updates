# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Rückkehr zur vorherigen Version + Updates übers Internet
# ==========================================================================
ROLLBACK_DIR = "/var/lib/raspi-tv-rollback"
ROLLBACK_PATHS = ["opt/raspi-tv", "etc/systemd/system/raspi-tv-ctl.service", "etc/systemd/system/raspi-tv-cec.service",
                  "etc/systemd/system/raspi-tv-wlan.service", "etc/systemd/system/raspi-tv-btagent.service",
                  "etc/chromium/policies/managed/raspi-tv.json", "etc/chromium-browser/policies/managed/raspi-tv.json",
                  "etc/X11/xorg.conf.d/99-raspi-tv.conf", "etc/X11/raspi-tv", "etc/raspi-tv-release",
                  "home/tv/.xinitrc", "home/tv/.xbindkeysrc", "home/tv/.bash_profile"]


def _ver_tuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", str(v))[:4]) or (0,)


def _rollback_snapshot():
    """Packt die laufende Version ein (die letzten zwei werden aufbewahrt)."""
    try:
        os.makedirs(ROLLBACK_DIR, exist_ok=True)
        ver = re.sub(r"[^0-9A-Za-z.]", "", _installed_version()) or "x"
        path = os.path.join(ROLLBACK_DIR, f"raspi-tv-{ver}-{time.strftime('%Y%m%d-%H%M%S')}.tar.gz")
        present = [p for p in ROLLBACK_PATHS if os.path.exists("/" + p)]
        if not present:
            return None
        code, _, _ = T["run"](["tar", "-czf", path, "-C", "/"] + present, 120)
        if code != 0:
            return None
        old = sorted(glob.glob(os.path.join(ROLLBACK_DIR, "raspi-tv-*.tar.gz")))
        for f in old[:-2]:
            os.remove(f)
        return path
    except OSError:
        return None


def rollback_list():
    out = []
    for f in sorted(glob.glob(os.path.join(ROLLBACK_DIR, "raspi-tv-*.tar.gz")), reverse=True):
        m = re.match(r"raspi-tv-(.+?)-(\d{8})-(\d{6})\.tar\.gz$", os.path.basename(f))
        if m:
            out.append({"file": os.path.basename(f), "version": m.group(1),
                        "date": f"{m.group(2)[6:8]}.{m.group(2)[4:6]}.{m.group(2)[:4]} {m.group(3)[:2]}:{m.group(3)[2:4]}"})
    rolled = os.path.exists(os.path.join(ROLLBACK_DIR, "rolled-back"))
    return {"snapshots": out, "auto_rolled_back": rolled}


def rollback_restore(data):
    name = os.path.basename(str(data.get("file", "")))
    path = os.path.join(ROLLBACK_DIR, name)
    if not re.match(r"^raspi-tv-[0-9A-Za-z.]+-\d{8}-\d{6}\.tar\.gz$", name) or not os.path.isfile(path):
        raise _err("Sicherung nicht gefunden")
    code, _, err = T["run"](["tar", "-xzf", path, "-C", "/"], 120)
    if code != 0:
        raise _err("Zurücksetzen fehlgeschlagen: " + err.strip()[:80])
    T["run"](["systemctl", "daemon-reload"], 30)
    subprocess.Popen(["bash", "-c", "sleep 3; systemctl reboot"], start_new_session=True)
    return {"ok": True}


def rollback_ack(_data=None):
    try:
        os.remove(os.path.join(ROLLBACK_DIR, "rolled-back"))
    except OSError:
        pass
    return {"ok": True}


# --- Updates übers Internet --------------------------------------------------
_online = {"checked": 0, "latest": None, "error": None, "busy": False}
ONLINE_ZIP = "/var/cache/raspi-tv/online-update.zip"
# 6.1.1: Standard-Adresse für Online-Updates; neue Versionen werden nachts automatisch installiert,
# solange in den Einstellungen nichts anderes eingetragen ist.
DEFAULT_UPDATE_URL = "https://raw.githubusercontent.com/NBFinn/raspi-tv-updates/main/raspi-tv-update.zip"


def _update_url(cfg):
    return cfg["update_url"] if "update_url" in cfg else DEFAULT_UPDATE_URL


def _update_auto(cfg):
    return cfg.get("update_auto", True) is not False


def _online_fetch():
    url = _update_url(_cfg())
    if not url:
        raise RuntimeError("Keine Update-Adresse eingetragen.")
    data = _download(url, limit=80_000_000, timeout=180)
    os.makedirs(os.path.dirname(ONLINE_ZIP), exist_ok=True)
    with open(ONLINE_ZIP + ".tmp", "wb") as f:
        f.write(data)
    os.replace(ONLINE_ZIP + ".tmp", ONLINE_ZIP)
    with zipfile.ZipFile(ONLINE_ZIP) as zf:
        names = _zip_names(zf)
        root = _zip_root([n for _, n in names])
        if root is None:
            raise RuntimeError("Unter der Adresse liegt kein Raspi-TV-Update-Paket.")
        ver = next((zf.read(i).decode("utf-8", "replace").strip()[:20] for i, n in names if n == root + "VERSION"), None)
    if not ver:
        raise RuntimeError("Update-Paket ohne Versionsnummer.")
    return ver


def online_check(_data=None):
    if _online["busy"]:
        return online_status()
    _online["busy"] = True
    try:
        _online.update(latest=_online_fetch(), error=None)
    except zipfile.BadZipFile:
        _online.update(latest=None, error="Unter der Adresse liegt keine Zip-Datei.")
    except Exception as e:  # noqa: BLE001
        _online.update(latest=None, error=str(e) if isinstance(e, RuntimeError) else "Update-Adresse nicht erreichbar.")
    finally:
        _online.update(busy=False, checked=time.time())
    return online_status()


def online_status():
    cfg = _cfg()
    inst = _installed_version()
    latest = _online["latest"]
    return {"url": _update_url(cfg), "auto": _update_auto(cfg), "installed": inst,
            "latest": latest, "newer": bool(latest and _ver_tuple(latest) > _ver_tuple(inst)),
            "checked": _online["checked"], "error": _online["error"], "busy": _online["busy"],
            "job": swupdate_status()}


def online_settings(data):
    cfg = _cfg()
    if "url" in data:
        url = str(data["url"]).strip()
        if url and not re.match(r"^https://[^\s\"'<>]+$", url):
            raise _err("Bitte eine https-Adresse eingeben (z. B. von GitHub-Releases).")
        cfg["update_url"] = url[:400]
        _online.update(latest=None, error=None, checked=0)
    if "auto" in data:
        cfg["update_auto"] = bool(data["auto"])
    _save(cfg)
    return online_status()


def online_install(_data=None):
    if _swu["running"]:
        return online_status()
    st = online_check()
    if not st["latest"]:
        raise _err(st["error"] or "Kein Update gefunden.")
    if not st["newer"]:
        raise _err(f"Raspi-TV ist aktuell (Version {st['installed']}).")
    _swu.update(running=True, done=False, error=None, step="Wird vorbereitet", version=st["latest"])
    threading.Thread(target=_swupdate_worker, args=(ONLINE_ZIP,), daemon=True).start()
    return online_status()


def online_loop():
    """Prüft einmal am Tag; installiert auf Wunsch nachts zwischen 3 und 5 Uhr."""
    time.sleep(120)
    while True:
        try:
            cfg = _cfg()
            if _update_url(cfg) and time.time() - _online["checked"] > 6 * 3600:
                online_check()
            h = datetime.now().hour
            if (_update_auto(cfg) and 3 <= h < 5 and _online["latest"] and not _swu["running"]
                    and _ver_tuple(_online["latest"]) > _ver_tuple(_installed_version())
                    and T["tv_power"]() != "on"):
                online_install()
        except Exception:  # noqa: BLE001
            pass
        time.sleep(600)


GET_ROUTES["/api/rollback"] = rollback_list
POST_ROUTES["/api/rollback"] = rollback_restore
POST_ROUTES["/api/rollback/ack"] = rollback_ack
GET_ROUTES["/api/online-update"] = online_status
POST_ROUTES["/api/online-update"] = online_settings
POST_ROUTES["/api/online-update/check"] = online_check
POST_ROUTES["/api/online-update/install"] = online_install
_old_start5 = start_background


def start_background():  # noqa: F811
    _old_start5()
    threading.Thread(target=online_loop, daemon=True).start()
