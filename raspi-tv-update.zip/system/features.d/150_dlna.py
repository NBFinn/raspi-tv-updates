# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# DLNA: Videos, Musik und Fotos vom Handy (siehe dlna.py)
# ==========================================================================
def _pi_volume_get():
    _, out, _ = T["as_tv"](["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"], 10)
    m = re.search(r"([\d.]+)", out)
    return round(float(m.group(1)) * 100) if m else 50


def _pi_volume_set(v):
    T["as_tv"](["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", f"{v / 100:.2f}"], 10)


def _pi_mute_get():
    _, out, _ = T["as_tv"](["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"], 10)
    return "MUTED" in out


def _pi_mute_set(on):
    T["as_tv"](["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "1" if on else "0"], 10)


def dlna_status():
    return {"enabled": _cfg().get("dlna", True), "name": _device_name()}


def dlna_set(data):
    cfg = _cfg()
    cfg["dlna"] = bool(data.get("enabled"))
    _save(cfg)
    return dlna_status()


def cast_report(data):
    import dlna
    touch_activity()
    return dlna.player_report(data)


def _dlna_start():
    try:
        import dlna
        dlna.start({"name": _device_name, "enabled": lambda: _cfg().get("dlna", True), "state_dir": T["STATE_DIR"],
                    "request_nav": request_nav, "volume_get": _pi_volume_get, "volume_set": _pi_volume_set,
                    "mute_get": _pi_mute_get, "mute_set": _pi_mute_set, "log": lambda m: print(m, flush=True)})
    except Exception as e:  # noqa: BLE001
        print("DLNA nicht gestartet:", e, flush=True)


GET_ROUTES["/api/dlna"] = dlna_status
POST_ROUTES["/api/dlna"] = dlna_set
POST_ROUTES["/api/cast/report"] = cast_report
_old_start6 = start_background


def start_background():  # noqa: F811
    _old_start6()
    _dlna_start()


# Handy-Fernbedienung: Sprache mitschicken
def _remote_ping(_data):
    return {"ok": True, "name": _device_name(), "tv": T["tv_power"](), "lang": _cfg().get("lang", "de")}


REMOTE_ROUTES_EXTRA["/r/ping"] = _remote_ping
