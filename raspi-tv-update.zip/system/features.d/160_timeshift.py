# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Live-TV anhalten (Timeshift, siehe timeshift.py)
# ==========================================================================
def _ts():
    import timeshift
    return timeshift


def timeshift_start(data):
    ts = _ts()
    try:
        return ts.start(str(data.get("url") or ""), float(data.get("behind") or 0),
                        log=lambda *a: print(*a, flush=True))
    except (ts.TimeshiftError, ValueError) as e:
        raise _err(str(e))


def timeshift_stop(_data=None):
    return _ts().stop()


def timeshift_status():
    return _ts().status()


def serve_prefix(handler, path):
    """GET-Pfade mit Präfix (z. B. /timeshift/v-123.ts). Gibt False zurück, wenn nicht zuständig."""
    if path.startswith("/timeshift/"):
        _ts().serve(handler, path, _send_file)
        return True
    return False


GET_ROUTES["/api/timeshift"] = timeshift_status
POST_ROUTES["/api/timeshift/start"] = timeshift_start
POST_ROUTES["/api/timeshift/stop"] = timeshift_stop
_old_start7 = start_background


def start_background():  # noqa: F811
    _old_start7()
    try:
        _ts()._clear()   # Reste vom letzten Mal
    except Exception:  # noqa: BLE001
        pass
