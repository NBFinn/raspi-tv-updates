# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Hinweise in jeder App (z. B. Anrufe) – werden über die Erweiterung abgeholt
# ==========================================================================
_notices = []          # [{id, at, notice}]
_notice_lock = threading.Lock()


def push_notice(notice, ttl=30):
    with _notice_lock:
        nid = int(time.time() * 1000)
        _notices.append({"id": nid, "at": time.time(), "ttl": ttl, "notice": dict(notice, id=nid)})
        del _notices[:-5]
    return nid


_nav_pending_base = nav_pending


def nav_pending(query, headers):  # noqa: F811
    out = _nav_pending_base(query, headers)
    with _notice_lock:
        now = time.time()
        _notices[:] = [n for n in _notices if now - n["at"] < n["ttl"]]
        if _notices:
            out["notice"] = _notices.pop(0)["notice"]
    return out


QUERY_ROUTES["/api/nav/pending"] = nav_pending


# ==========================================================================
# Anrufe anzeigen (FRITZ!Box-Anrufmonitor, Port 1012)
#   Einmalig am Telefon #96*5* wählen, dann meldet die FRITZ!Box jeden Anruf.
# ==========================================================================
CALLMON_PORT = 1012
_callmon = {"state": "off", "last": None, "error": ""}


def _callmon_cfg():
    c = _cfg().get("callmon") or {}
    return {"enabled": c.get("enabled", True), "pause": bool(c.get("pause", False)),
            "host": str(c.get("host") or "fritz.box")[:64]}


def _fmt_number(n):
    n = (n or "").strip()
    if not n:
        return ""
    if n.startswith("0049"):
        n = "0" + n[4:]
    elif n.startswith("+49"):
        n = "0" + n[3:]
    if re.match(r"^01[5-7]\d{7,9}$", n):        # Handynummer: 0170 1234567
        n = n[:4] + " " + n[4:]
    return n


def _call_notice(caller, callee, pause, test=False):
    lang = _cfg().get("lang", "de")
    num = _fmt_number(caller)
    title = num or ("Unknown number" if lang == "en" else "Unbekannte Nummer")
    sub_parts = []
    if callee:
        sub_parts.append(("on " if lang == "en" else "auf ") + _fmt_number(callee))
    if pause:
        sub_parts.append("video paused" if lang == "en" else "Video angehalten")
    if test:
        sub_parts.append("test" if lang == "en" else "Test")
    return {"kicker": "Incoming call" if lang == "en" else "Anruf", "title": title, "sub": " · ".join(sub_parts),
            "icon": "phone", "pause": bool(pause), "timeout": 30000, "tag": "call"}


def _callmon_handle(line):
    # 28.10.26 20:15:03;RING;0;01701234567;030123456;SIP0;
    parts = line.strip().split(";")
    if len(parts) < 3:
        return
    kind = parts[1]
    if kind == "RING":
        caller = parts[3] if len(parts) > 3 else ""
        callee = parts[4] if len(parts) > 4 else ""
        c = _callmon_cfg()
        _callmon["last"] = {"at": time.time(), "caller": _fmt_number(caller)}
        if T["tv_power"]() == "standby":
            return     # Fernseher ist aus – niemand schaut
        push_notice(_call_notice(caller, callee, c["pause"]), ttl=25)
    elif kind in ("CONNECT", "DISCONNECT"):
        push_notice({"close": "call"}, ttl=10)


def callmon_loop():
    import socket
    while True:
        c = _callmon_cfg()
        if not c["enabled"]:
            _callmon.update(state="off", error="")
            time.sleep(10)
            continue
        try:
            with socket.create_connection((c["host"], CALLMON_PORT), timeout=10) as s:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
                s.settimeout(60)
                _callmon.update(state="connected", error="")
                buf = b""
                # nur bei geänderter Adresse / Ausschalten neu verbinden
                while {k: v for k, v in _callmon_cfg().items() if k != "pause"} == {k: v for k, v in c.items() if k != "pause"}:
                    try:
                        chunk = s.recv(4096)
                    except socket.timeout:
                        continue
                    if not chunk:
                        break
                    buf += chunk
                    while b"\n" in buf:
                        line, buf = buf.split(b"\n", 1)
                        try:
                            _callmon_handle(line.decode("utf-8", "replace"))
                        except Exception:  # noqa: BLE001
                            pass
        except OSError as e:
            refused = isinstance(e, ConnectionRefusedError)
            _callmon.update(state="refused" if refused else "offline", error=str(e)[:120])
            time.sleep(60 if refused else 120)
            continue
        time.sleep(5)


def callmon_status():
    c = _callmon_cfg()
    return dict(c, state=_callmon["state"], last=_callmon["last"])


def callmon_set(data):
    cfg = _cfg()
    c = dict(cfg.get("callmon") or {})
    if "enabled" in data:
        c["enabled"] = bool(data["enabled"])
    if "pause" in data:
        c["pause"] = bool(data["pause"])
    if "host" in data:
        host = str(data["host"]).strip()
        if not re.match(r"^[A-Za-z0-9.-]{1,64}$", host):
            raise _err("Ungültige Adresse")
        c["host"] = host
    cfg["callmon"] = c
    _save(cfg)
    return callmon_status()


def callmon_test(_data=None):
    c = _callmon_cfg()
    push_notice(_call_notice("0170 1234567", "", c["pause"], test=True), ttl=25)
    return {"ok": True}


GET_ROUTES["/api/callmon"] = callmon_status
POST_ROUTES["/api/callmon"] = callmon_set
POST_ROUTES["/api/callmon/test"] = callmon_test
