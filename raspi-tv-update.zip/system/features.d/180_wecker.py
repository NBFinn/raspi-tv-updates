# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Einschalt-Timer (Wecker) und nächtlicher Neustart
# ==========================================================================
WAKE_DEFAULT = {"enabled": False, "time": "07:00", "days": [1, 2, 3, 4, 5], "channel": "", "nightly": False,
                "mode": "tv", "radio": "", "scene": "polarlicht", "gentle": True}


def wake_cfg():
    w = dict(WAKE_DEFAULT)
    w.update({k: v for k, v in (_cfg().get("wake") or {}).items() if k in WAKE_DEFAULT})
    return w


def wake_status():
    w = wake_cfg()
    w["next"] = _wake_next(w)
    w["channels"] = [c["name"] for c in all_channels()][:200]
    return w


def _wake_next(w, now=None):
    if not w["enabled"] or not w["days"]:
        return None
    now = now or datetime.now()
    hh, mm = (int(x) for x in w["time"].split(":"))
    for add in range(0, 8):
        d = datetime.fromtimestamp(now.timestamp() + add * 86400).replace(hour=hh, minute=mm, second=0, microsecond=0)
        if d.isoweekday() in w["days"] and d > now:
            return d.timestamp()
    return None


def wake_set(data):
    cfg = _cfg()
    w = wake_cfg()
    if "enabled" in data:
        w["enabled"] = bool(data["enabled"])
    if "nightly" in data:
        w["nightly"] = bool(data["nightly"])
    if "time" in data:
        if not re.match(r"^([01]\d|2[0-3]):[0-5]\d$", str(data["time"])):
            raise _err("Ungültige Uhrzeit")
        w["time"] = data["time"]
    if "days" in data:
        days = data["days"]
        if not isinstance(days, list) or not all(isinstance(d, int) and 1 <= d <= 7 for d in days):
            raise _err("Ungültige Tage")
        w["days"] = sorted(set(days))
    if "channel" in data:
        ch = str(data["channel"] or "")[:80]
        if ch and ch not in {c["name"] for c in all_channels()}:
            raise _err("Unbekannter Sender")
        w["channel"] = ch
    # 6.0: Wecker mit Radio oder Ambient-Szene, sanft lauter werdend
    if "mode" in data:
        if data["mode"] not in ("tv", "radio", "ambient"):
            raise _err("Ungültige Art")
        w["mode"] = data["mode"]
    if "radio" in data:
        w["radio"] = str(data["radio"] or "")[:80]
    if "scene" in data:
        if not re.fullmatch(r"[a-z0-9-]{1,40}", str(data["scene"])):
            raise _err("Ungültige Szene")
        w["scene"] = data["scene"]
    if "gentle" in data:
        w["gentle"] = bool(data["gentle"])
    cfg["wake"] = w
    _save(cfg)
    return wake_status()


def _wake_fire(w):
    touch_activity()
    try:
        _cec(["--to", "0", "--image-view-on"])
        pa = _phys_addr()
        if pa and pa != "f.f.f.f":
            _cec(["--to", "15", "--active-source", f"phys-addr={pa}"])
    except Exception:  # noqa: BLE001
        pass
    _set_tv_power("on")
    if w.get("mode") in ("radio", "ambient"):
        q = "mode=" + w["mode"] + "&scene=" + quote(w.get("scene") or "") + "&gentle=" + ("1" if w.get("gentle") else "0")
        if w["mode"] == "radio" and w.get("radio"):
            q += "&radio=" + quote(w["radio"])
        request_nav(LAUNCHER + "#/wakeup?" + q)
    elif w["channel"]:
        request_nav(LAUNCHER + "tv.html?name=" + quote(w["channel"]))
    else:
        request_nav(LAUNCHER)


def wake_loop():
    fired = None
    while True:
        time.sleep(20)
        try:
            w = wake_cfg()
            now = datetime.now()
            key = now.strftime("%Y-%m-%d %H:%M")
            if (w["enabled"] and now.isoweekday() in w["days"] and now.strftime("%H:%M") == w["time"]
                    and fired != key):
                fired = key
                _wake_fire(w)
            # Nachts um 4 Uhr neu starten (nur wenn niemand schaut und der Pi schon lange läuft)
            if (w["nightly"] and now.hour == 4 and now.minute < 30 and T["tv_power"]() != "on"
                    and time.time() - last_input() > 1800 and _uptime() > 20 * 3600):
                T["power"]("reboot")
                time.sleep(120)
        except Exception:  # noqa: BLE001
            pass


def _uptime():
    try:
        with open("/proc/uptime") as f:
            return float(f.read().split()[0])
    except (OSError, ValueError):
        return 0


GET_ROUTES["/api/wake"] = wake_status
POST_ROUTES["/api/wake"] = wake_set
_old_start8 = start_background


def start_background():  # noqa: F811
    _old_start8()
    threading.Thread(target=callmon_loop, daemon=True).start()
    threading.Thread(target=wake_loop, daemon=True).start()
