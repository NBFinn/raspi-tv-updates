# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Raspi-TV-App für ältere Android-Handys: Fernbedienung über Bluetooth
#   Die App verbindet sich per Bluetooth (RFCOMM, Kanal 22) und schickt pro Zeile
#   eine Anfrage als JSON: {"id": 1, "path": "/r/key", "data": {"key": "up"}}
#   Antwort: {"id": 1, "ok": true, "data": {...}} bzw. {"id": 1, "error": "…"}
#   Nur Handys, die während des Kopplungsfensters (3 Minuten, am Fernseher gestartet)
#   verbunden wurden, dürfen danach steuern.
# ==========================================================================
BT_REMOTE_CHANNEL = 22
_btr = {"window_until": 0, "clients": {}, "error": "", "listening": False}
_btr_connections = {}
_btr_lock = threading.Lock()


def _btr_allowed():
    return _read_json(_state("bt-remotes.json"), {})


def _btr_allow(mac, name=""):
    allowed = _btr_allowed()
    allowed[mac] = {"name": name or allowed.get(mac, {}).get("name") or mac, "added": time.time()}
    _write_json(_state("bt-remotes.json"), allowed)


def _bt_name(mac):
    try:
        _, out, _ = T["run"](["bluetoothctl", "info", mac], 2)
        m = re.search(r"^\s*(?:Alias|Name):\s*(.+)$", out, re.M)
        return m.group(1).strip() if m else ""
    except Exception:  # noqa: BLE001
        return ""


def btremote_window(_data=None):
    """Raspi-TV 3 Minuten lang sichtbar machen, damit das Handy ihn findet und koppeln darf."""
    T["bt_ready"]()
    T["run"](["bluetoothctl", "pairable", "on"], 10)
    T["run"](["bluetoothctl", "discoverable-timeout", "180"], 10)
    T["run"](["bluetoothctl", "discoverable", "on"], 10)
    _btr["window_until"] = time.time() + 180
    return btremote_status()


def btremote_status():
    left = max(0, int(_btr["window_until"] - time.time()))
    allowed = _btr_allowed()
    return {"listening": _btr["listening"], "error": _btr["error"], "window": left,
            "connected": [dict(mac=m, name=c) for m, c in _btr["clients"].items()],
            "phones": [dict(mac=m, name=v.get("name") or m) for m, v in allowed.items()],
            "name": _device_name(),
            "drops": [d for d in _btr.get("log", []) if d["at"] > time.time() - 86400 and d["reason"] != "vom Handy beendet"][-5:]}


def btremote_forget(data):
    mac = str(data.get("mac") or "")
    allowed = _btr_allowed()
    if mac in allowed:
        del allowed[mac]
        _write_json(_state("bt-remotes.json"), allowed)
        try:
            T["run"](["bluetoothctl", "remove", mac], 15)
        except Exception:  # noqa: BLE001
            pass
    return btremote_status()


def _btr_handle(conn, mac):
    import socket as so
    allowed = _btr_allowed()
    # Reconnecting must not wait for bluetoothctl before answering the phone.
    name = allowed.get(mac, {}).get("name") or mac
    conn.settimeout(120)
    if mac not in allowed:
        if time.time() < _btr["window_until"]:
            name = _bt_name(mac) or mac
            _btr_allow(mac, name)
        else:
            try:
                conn.settimeout(2)
                conn.sendall(json.dumps({"id": 0, "error": "pair", "message":
                         "Am Fernseher unter Einstellungen → Fernbedienung → Handy „Handy-App koppeln“ wählen."}).encode() + b"\n")
            finally:
                conn.close()
            return
    routes = T["REMOTE_ROUTES"]
    started = time.time()
    send_lock = threading.Lock()
    jobs = queue.Queue(maxsize=64)
    closed = threading.Event()
    state = {"hb": False, "reason": "getrennt"}

    def close_session(reason=None):
        if reason and not closed.is_set():
            state["reason"] = reason
        closed.set()
        try:
            conn.shutdown(so.SHUT_RDWR)
        except OSError:
            pass
        conn.close()

    with _btr_lock:
        old = _btr_connections.get(mac)
        _btr_connections[mac] = close_session
        _btr["clients"][mac] = name
    if old:
        old("durch neue Handy-Verbindung ersetzt")
    print("Bluetooth-Fernbedienung verbunden:", name, flush=True)

    def send(obj):
        data = json.dumps(obj, ensure_ascii=False).encode() + b"\n"
        with send_lock:
            if closed.is_set():
                raise OSError("Verbindung beendet")
            conn.sendall(data)

    def worker():
        # Befehle der Reihe nach ausführen (Tasten dürfen sich nicht überholen); langsame Befehle
        # (z. B. CEC) halten dabei die Herzschlag-Antworten nicht mehr auf.
        while not closed.is_set():
            try:
                req = jobs.get(timeout=0.5)
            except queue.Empty:
                continue
            if closed.is_set():
                return
            rid = req.get("id", 0) if isinstance(req, dict) else 0
            try:
                fn = routes.get(req.get("path")) if isinstance(req, dict) else None
                data = (req.get("data") or {}) if isinstance(req, dict) else None
                if not fn or not isinstance(data, dict):
                    raise _err("Unbekannte Anfrage", 404)
                touch_activity()
                out = {"id": rid, "ok": True, "data": fn(data)}
            except T["ApiError"] as e:
                out = {"id": rid, "error": str(e), "status": e.code}
            except Exception as e:  # noqa: BLE001
                out = {"id": rid, "error": f"Fehler: {e}", "status": 500}
            try:
                send(out)
            except OSError as e:
                close_session(f"Bluetooth-Senden fehlgeschlagen: {e}")
                return

    threading.Thread(target=worker, daemon=True).start()
    buf = b""
    # Ältere Apps melden sich nur alle 10 s (und nur im Vordergrund).
    try:
        while not closed.is_set():
            try:
                chunk = conn.recv(8192)
            except so.timeout:
                state["reason"] = "keine Antwort vom Handy (Zeitüberschreitung)"
                break
            if not chunk:
                if not closed.is_set():
                    state["reason"] = "vom Handy beendet"
                break
            buf += chunk
            if len(buf) > 262144:
                state["reason"] = "zu lange Anfrage"
                break
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                line = line.strip()
                if not line:
                    continue
                try:
                    req = json.loads(line)
                except ValueError:
                    send({"id": 0, "error": "Ungültige Anfrage", "status": 400})
                    continue
                if isinstance(req, dict) and req.get("path") == "/r/hb":
                    # Herzschlag der App (ab 1.11, alle 4 s): sofort beantworten
                    if not state["hb"]:
                        state["hb"] = True
                        conn.settimeout(30)
                    send({"id": req.get("id", -1), "ok": True, "data": {"t": int(time.time())}})
                    continue
                try:
                    jobs.put_nowait(req)
                except queue.Full:
                    send({"id": req.get("id", 0) if isinstance(req, dict) else 0, "error": "Raspi-TV ist beschäftigt", "status": 503})
    except OSError as e:
        if not closed.is_set():
            state["reason"] = f"Bluetooth-Fehler: {e.strerror or e}"
    finally:
        close_session()
        with _btr_lock:
            if _btr_connections.get(mac) is close_session:
                _btr_connections.pop(mac, None)
                _btr["clients"].pop(mac, None)
        _btr.setdefault("log", []).append({"at": int(time.time()), "name": name, "reason": state["reason"],
                                           "secs": int(time.time() - started)})
        del _btr["log"][:-20]
        print(f"Bluetooth-Fernbedienung getrennt: {name} ({state['reason']}, nach {int(time.time() - started)} s)", flush=True)


def btremote_loop():
    import socket as so
    import struct
    if not hasattr(so, "BTPROTO_RFCOMM"):
        _btr["error"] = "Python ohne Bluetooth-Unterstützung"
        return
    while True:
        srv = None
        try:
            T["bt_ready"]()
            srv = so.socket(so.AF_BLUETOOTH, so.SOCK_STREAM, so.BTPROTO_RFCOMM)
            try:
                # Verbindung nur nach Kopplung (BT_SECURITY = mittel)
                srv.setsockopt(274, 4, struct.pack("BB", 2, 0))
            except OSError:
                pass
            srv.bind(("00:00:00:00:00:00", BT_REMOTE_CHANNEL))
            srv.listen(2)
            _btr.update(listening=True, error="")
            while True:
                conn, addr = srv.accept()
                threading.Thread(target=_btr_handle, args=(conn, addr[0].upper()), daemon=True).start()
        except Exception as e:  # noqa: BLE001
            _btr.update(listening=False, error=str(e)[:160])
            try:
                if srv:
                    srv.close()
            except OSError:
                pass
            time.sleep(30)


GET_ROUTES["/api/btremote"] = btremote_status
POST_ROUTES["/api/btremote/window"] = btremote_window
POST_ROUTES["/api/btremote/forget"] = btremote_forget
_old_start9 = start_background


def start_background():  # noqa: F811
    _old_start9()
    threading.Thread(target=btremote_loop, daemon=True).start()
