# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Videorekorder (siehe recorder.py)
# ==========================================================================
def _rec():
    import recorder
    if not recorder._H:
        recorder.configure(state_file=_state("recordings.json"),
                           channels=lambda: all_channels(include_hidden=True),
                           usb_roots=_usb_roots, run=T["run"], log=lambda *a: print(*a, flush=True))
    return recorder


def rec_status():
    r = _rec()
    pref = _cfg().get("rec_target", "auto")
    ts = [{"id": t["id"], "name": t["name"], "free": t["free"], "kind": t["kind"]} for t in r.targets()]
    try:
        auto = r.pick_target(pref)["id"]
    except r.RecError:
        auto = None
    return {"schedule": r.schedule(), "recordings": r.recordings(), "targets": ts, "pref": pref, "target": auto}


def rec_plan(data):
    r = _rec()
    try:
        r.plan(str(data["channel"])[:80], int(data["start"]), int(data["stop"]), str(data.get("title") or "")[:120],
               pref=_cfg().get("rec_target", "auto"))
    except (KeyError, TypeError, ValueError):
        raise _err("Ungültige Aufnahme")
    except r.RecError as e:
        raise _err(str(e))
    return rec_status()


def rec_now(data):
    """Sofort aufnehmen – bis zum Ende der laufenden Sendung (mind. 15, sonst 60 Minuten)."""
    r = _rec()
    ch = str(data.get("channel") or "")[:80]
    if ch not in {c["name"] for c in all_channels(include_hidden=True)}:
        raise _err("Sender nicht gefunden")
    now = int(time.time())
    p = (epg_now().get(ch) or {}).get("now")
    stop = int(p["stop"]) if p and p["stop"] - now > 15 * 60 else now + 60 * 60
    title = p["title"] if p else ch
    try:
        r.plan(ch, now, stop, title, source="now", pref=_cfg().get("rec_target", "auto"))
        r.tick()
    except r.RecError as e:
        raise _err(str(e))
    st = rec_status()
    rid = f"{ch}|{now}"
    it = next((i for i in st["schedule"] if i["id"] == rid), None)
    if it and it["status"] == "failed":
        raise _err(it.get("error") or "Aufnahme nicht möglich")
    st["title"], st["until"] = title, stop
    return st


def rec_cancel(data):
    r = _rec()
    try:
        r.cancel(str(data.get("id") or ""))
    except r.RecError as e:
        raise _err(str(e))
    return rec_status()


def rec_delete(data):
    r = _rec()
    try:
        r.delete(str(data.get("src") or ""), str(data.get("path") or ""))
    except r.RecError as e:
        raise _err(str(e))
    return rec_status()


def rec_target(data):
    pref = str(data.get("pref") or "auto")
    if pref != "auto" and pref not in {t["id"] for t in _rec().targets()}:
        raise _err("Unbekannter Speicherort")
    cfg = _cfg()
    cfg["rec_target"] = pref
    _save(cfg)
    return rec_status()


_source_root_base = _source_root


def _source_root(src):  # noqa: F811 – Aufnahmen auf der Speicherkarte als eigene Quelle „rec“
    if src == "rec":
        import recorder
        os.makedirs(recorder.SD_DIR, exist_ok=True)
        return os.path.realpath(recorder.SD_DIR)
    return _source_root_base(src)


GET_ROUTES["/api/rec"] = rec_status
POST_ROUTES["/api/rec/plan"] = rec_plan
POST_ROUTES["/api/rec/now"] = rec_now
POST_ROUTES["/api/rec/cancel"] = rec_cancel
POST_ROUTES["/api/rec/delete"] = rec_delete
POST_ROUTES["/api/rec/target"] = rec_target
_old_start10 = start_background


def start_background():  # noqa: F811
    _old_start10()
    threading.Thread(target=_rec().loop, daemon=True).start()
