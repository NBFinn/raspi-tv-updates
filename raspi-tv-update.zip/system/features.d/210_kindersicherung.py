# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Kindersicherung: PIN, Kinder-Modus, Tageslimit und Schlafenszeit
# ==========================================================================
KIDS_DEFAULT_CHANNELS = ["KiKA", "Nickelodeon"]
_par = {"fails": 0, "locked_until": 0, "unlocks": {}, "minute": 0}
_par_lock = threading.Lock()


def _par_cfg():
    p = dict(_cfg().get("parental") or {})
    p.setdefault("lock_settings", True)
    p.setdefault("kids_mode", False)
    p.setdefault("limit_min", 0)
    p.setdefault("bedtime", "")
    p.setdefault("kids_channels", KIDS_DEFAULT_CHANNELS)
    return p


def _par_save(p):
    cfg = _cfg()
    cfg["parental"] = p
    _save(cfg)


def _pin_hash(pin, salt):
    return hashlib.sha256((salt + ":" + pin).encode()).hexdigest()


def _pin_ok(pin):
    p = _par_cfg()
    if not p.get("pin_hash"):
        return True
    pin = re.sub(r"\D", "", str(pin or ""))
    with _par_lock:
        if time.time() < _par["locked_until"]:
            raise _err("Zu viele falsche Versuche – bitte 5 Minuten warten.", 429)
        ok = hmac.compare_digest(_pin_hash(pin, p.get("pin_salt", "")), p["pin_hash"])
        if not ok:
            _par["fails"] += 1
            if _par["fails"] >= 5:
                _par.update(fails=0, locked_until=time.time() + 300)
        else:
            _par["fails"] = 0
    if not ok:
        time.sleep(0.6)
    return ok


def _usage_today():
    u = _read_json(_state("kids-usage.json"), {})
    return u if u.get("day") == time.strftime("%Y-%m-%d") else {"day": time.strftime("%Y-%m-%d"), "minutes": 0, "extra": 0}


def _kids_block():
    """Grund, warum gerade gesperrt ist (oder '')."""
    p = _par_cfg()
    if not p["kids_mode"]:
        return ""
    u = _usage_today()
    if p["limit_min"] and u["minutes"] >= p["limit_min"] + u.get("extra", 0):
        return "limit"
    bt = p.get("bedtime") or ""
    if re.match(r"^\d\d:\d\d$", bt):
        now = time.strftime("%H:%M")
        if now >= bt or now < "06:00":
            if time.time() > u.get("bed_ok_until", 0):
                return "bedtime"
    return ""


def parental_status():
    p = _par_cfg()
    u = _usage_today()
    return {"has_pin": bool(p.get("pin_hash")), "lock_settings": p["lock_settings"], "kids_mode": p["kids_mode"],
            "limit_min": p["limit_min"], "bedtime": p["bedtime"], "kids_channels": p["kids_channels"],
            "used_today": u["minutes"], "extra_today": u.get("extra", 0), "blocked": _kids_block()}


def _unlock_ok(data):
    """Gültiger PIN oder frisches Entsperr-Zeichen aus dem gleichen Gerät."""
    tok = str(data.get("unlock") or "")
    with _par_lock:
        until = _par["unlocks"].get(tok, 0)
    if tok and until > time.time():
        return True
    return _pin_ok(data.get("pin"))


def parental_verify(data):
    if not _pin_ok(data.get("pin")):
        raise _err("Falscher PIN", 403)
    tok = secrets.token_urlsafe(16)
    with _par_lock:
        now = time.time()
        _par["unlocks"] = {k: v for k, v in _par["unlocks"].items() if v > now}
        _par["unlocks"][tok] = now + 15 * 60
    return {"ok": True, "unlock": tok, "valid": 15 * 60}


def parental_set(data):
    p = _par_cfg()
    if p.get("pin_hash") and not _unlock_ok(data):
        raise _err("Falscher PIN", 403)
    if "new_pin" in data:
        pin = str(data.get("new_pin") or "")
        if pin == "":
            for k in ("pin_hash", "pin_salt"):
                p.pop(k, None)
            p["kids_mode"] = False
        else:
            if not re.match(r"^\d{4}$", pin):
                raise _err("Der PIN muss aus 4 Ziffern bestehen.")
            salt = secrets.token_hex(8)
            p.update(pin_salt=salt, pin_hash=_pin_hash(pin, salt))
    if "lock_settings" in data:
        p["lock_settings"] = bool(data["lock_settings"])
    if "limit_min" in data:
        if data["limit_min"] not in (0, 30, 45, 60, 90, 120, 180):
            raise _err("Ungültiges Limit")
        p["limit_min"] = data["limit_min"]
    if "bedtime" in data:
        bt = str(data["bedtime"] or "")
        if bt and not re.match(r"^([01]\d|2[0-3]):[0-5]\d$", bt):
            raise _err("Ungültige Uhrzeit")
        p["bedtime"] = bt
    if "kids_channels" in data:
        names = {c["name"] for c in all_channels(include_hidden=True)}
        lst = [n for n in data["kids_channels"] if isinstance(n, str) and n in names][:60] if isinstance(data["kids_channels"], list) else None
        if lst is None:
            raise _err("Ungültige Senderliste")
        p["kids_channels"] = lst
    if "kids_mode" in data:
        if data["kids_mode"] and not p.get("pin_hash"):
            raise _err("Bitte zuerst einen PIN festlegen.")
        p["kids_mode"] = bool(data["kids_mode"])
    _par_save(p)
    return parental_status()


def parental_kids_on(_data=None):
    """Kinder-Modus einschalten geht ohne PIN (ausschalten nur mit PIN)."""
    p = _par_cfg()
    if not p.get("pin_hash"):
        raise _err("Bitte zuerst einen PIN festlegen.")
    p["kids_mode"] = True
    _par_save(p)
    return parental_status()


def parental_extend(data):
    """Mit PIN: heute 30 Minuten länger bzw. Schlafenszeit für eine Stunde aufheben."""
    if not _unlock_ok(data):
        raise _err("Falscher PIN", 403)
    u = _usage_today()
    u["extra"] = u.get("extra", 0) + int(data.get("minutes") or 30)
    u["bed_ok_until"] = time.time() + 3600
    _write_json(_state("kids-usage.json"), u)
    return parental_status()


def parental_loop():
    """Zählt im Kinder-Modus die Fernsehzeit und schickt bei Ablauf zum Sperrbildschirm."""
    last_block = ""
    while True:
        time.sleep(60)
        try:
            p = _par_cfg()
            if not p["kids_mode"]:
                last_block = ""
                continue
            watching = T["tv_power"]() != "standby" and time.time() - last_input() < 45 * 60
            if watching:
                u = _usage_today()
                u["minutes"] = u.get("minutes", 0) + 1
                _write_json(_state("kids-usage.json"), u)
            block = _kids_block()
            if block and block != last_block:
                request_nav(LAUNCHER + "#/kidslock")
            last_block = block
        except Exception:  # noqa: BLE001
            pass


# Im Kinder-Modus liefert die Senderliste nur die Kindersender (gilt für Fernsehen und TV-Programm)
_all_channels_base = all_channels


def all_channels(include_hidden=False):  # noqa: F811
    lst = _all_channels_base(include_hidden)
    p = _par_cfg()
    if p["kids_mode"] and not include_hidden:
        allowed = set(p["kids_channels"])
        lst = [c for c in lst if c["name"] in allowed]
    return lst


GET_ROUTES["/api/channels"] = all_channels
GET_ROUTES["/api/parental"] = parental_status
POST_ROUTES["/api/parental/verify"] = parental_verify
POST_ROUTES["/api/parental/set"] = parental_set
POST_ROUTES["/api/parental/kids"] = parental_kids_on
POST_ROUTES["/api/parental/extend"] = parental_extend
_old_start11 = start_background


def start_background():  # noqa: F811
    _old_start11()
    threading.Thread(target=parental_loop, daemon=True).start()


def _status_with_kids():
    s = {"network": T["network_status"](), "tv": T["tv_power"](), "time": time.time(), "autooff": autooff_left()}
    s["kids"] = _par_cfg()["kids_mode"]
    s["kids_blocked"] = _kids_block()
    return s


GET_ROUTES["/api/status"] = _status_with_kids
