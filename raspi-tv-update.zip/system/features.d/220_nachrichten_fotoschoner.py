# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Nachrichten (Schlagzeilen per RSS) für Startseite und Bildschirmschoner
# ==========================================================================
NEWS_SOURCES = {
    "tagesschau": ("tagesschau", "https://www.tagesschau.de/index~rss2.xml"),
    "zdf": ("ZDFheute", "https://www.zdf.de/rss/zdf/nachrichten"),
    "dw": ("Deutsche Welle", "https://rss.dw.com/rdf/rss-de-top"),
    "dw_en": ("DW News (English)", "https://rss.dw.com/rdf/rss-en-top"),
    "spiegel": ("DER SPIEGEL", "https://www.spiegel.de/schlagzeilen/index.rss"),
}
_news = {"at": 0, "src": None, "items": [], "error": ""}


def _strip_html(s):
    s = re.sub(r"<[^>]+>", " ", s or "")
    s = s.replace("&nbsp;", " ").replace("&amp;", "&").replace("&quot;", '"').replace("&#39;", "'")
    return re.sub(r"\s+", " ", s).strip()


def parse_rss(data):
    """RSS 2.0, RDF und Atom: [{title, desc, link, date}]"""
    root = ET.fromstring(data)
    out = []
    for el in root.iter():
        tag = el.tag.split("}")[-1]
        if tag not in ("item", "entry"):
            continue
        f = {c.tag.split("}")[-1]: c for c in el}
        title = _strip_html((f.get("title").text if f.get("title") is not None else "") or "")
        if not title:
            continue
        desc_el = f.get("description") if f.get("description") is not None else f.get("summary")
        link_el = f.get("link")
        link = ""
        if link_el is not None:
            link = (link_el.text or link_el.get("href") or "").strip()
        date = ""
        for k in ("pubDate", "date", "updated", "published"):
            if f.get(k) is not None and f[k].text:
                date = f[k].text.strip()
                break
        ts = 0
        try:
            from email.utils import parsedate_to_datetime
            ts = parsedate_to_datetime(date).timestamp()
        except Exception:  # noqa: BLE001
            try:
                ts = datetime.fromisoformat(date.replace("Z", "+00:00")).timestamp()
            except Exception:  # noqa: BLE001
                ts = 0
        out.append({"title": title[:200], "desc": _strip_html(desc_el.text if desc_el is not None else "")[:300],
                    "link": link if re.match(r"^https?://", link) else "", "time": ts})
    return out[:30]


def news(_query=None, _headers=None):
    src = _cfg().get("news_source") or ("dw_en" if _cfg().get("lang") == "en" else "tagesschau")
    if src not in NEWS_SOURCES:
        src = "tagesschau"
    if _news["src"] == src and time.time() - _news["at"] < 15 * 60 and _news["items"]:
        return {"source": NEWS_SOURCES[src][0], "id": src, "items": _news["items"]}
    try:
        items = parse_rss(_download(NEWS_SOURCES[src][1], limit=3_000_000, timeout=15))
        _news.update(at=time.time(), src=src, items=items, error="")
    except Exception as e:  # noqa: BLE001
        _news["error"] = str(e)[:120]
        if _news["src"] != src:
            _news["items"] = []
    return {"source": NEWS_SOURCES[src][0], "id": src, "items": _news["items"], "error": _news["error"],
            "sources": [{"id": k, "name": v[0]} for k, v in NEWS_SOURCES.items()]}


def news_set(data):
    src = str(data.get("source") or "")
    if src not in NEWS_SOURCES:
        raise _err("Unbekannte Quelle")
    cfg = _cfg()
    cfg["news_source"] = src
    _save(cfg)
    _news["at"] = 0
    return news()


GET_ROUTES["/api/news"] = news
POST_ROUTES["/api/news"] = news_set


# ==========================================================================
# Bildschirmschoner: Fotos von USB-Sticks
# ==========================================================================
def saver_photos():
    import random
    found = []
    for sid, _name, mnt in _usb_roots():
        for dirpath, dirnames, files in os.walk(mnt):
            depth = dirpath[len(mnt):].count(os.sep)
            dirnames[:] = [d for d in dirnames if not d.startswith(".") and depth < 4 and d != "System Volume Information"]
            for f in files:
                if _ftype(f) == "image":
                    found.append({"src": sid, "path": os.path.relpath(os.path.join(dirpath, f), mnt)})
            if len(found) > 3000:
                break
    random.shuffle(found)
    return {"photos": found[:150]}


GET_ROUTES["/api/saver/photos"] = saver_photos
