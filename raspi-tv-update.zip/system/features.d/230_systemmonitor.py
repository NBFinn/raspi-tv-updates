# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Systemmonitor und Internet-Geschwindigkeitstest
# ==========================================================================
_cpu_prev = {"t": None}


def _cpu_percent():
    try:
        with open("/proc/stat") as f:
            vals = [int(x) for x in f.readline().split()[1:]]
    except (OSError, ValueError):
        return None
    idle, total = vals[3] + (vals[4] if len(vals) > 4 else 0), sum(vals)
    prev = _cpu_prev["t"]
    _cpu_prev["t"] = (idle, total)
    if not prev or total == prev[1]:
        return None
    return round(100 * (1 - (idle - prev[0]) / (total - prev[1])), 1)


def sysmon():
    out = {"cpu": _cpu_percent(), "cores": os.cpu_count() or 1, "load": os.getloadavg()[0] if hasattr(os, "getloadavg") else None}
    try:
        with open("/sys/class/thermal/thermal_zone0/temp") as f:
            out["temp"] = int(f.read().strip()) / 1000
    except (OSError, ValueError):
        out["temp"] = None
    try:
        mem = {}
        with open("/proc/meminfo") as f:
            for line in f:
                k, v = line.split(":", 1)
                mem[k] = int(v.split()[0]) * 1024
        out["mem_total"], out["mem_free"] = mem.get("MemTotal", 0), mem.get("MemAvailable", 0)
    except (OSError, ValueError):
        pass
    try:
        du = shutil.disk_usage("/")
        out["disk_total"], out["disk_free"] = du.total, du.free
    except OSError:
        pass
    # Raspberry Pi: Unterspannung / Drosselung (vcgencmd get_throttled)
    thr = None
    if shutil.which("vcgencmd"):
        code, o, _ = T["run"](["vcgencmd", "get_throttled"], 5)
        m = re.search(r"0x([0-9a-fA-F]+)", o or "")
        if code == 0 and m:
            v = int(m.group(1), 16)
            thr = {"undervoltage_now": bool(v & 0x1), "throttled_now": bool(v & 0x4 or v & 0x2),
                   "undervoltage_past": bool(v & 0x10000), "throttled_past": bool(v & 0x40000 or v & 0x20000)}
    out["throttle"] = thr
    try:
        with open("/proc/uptime") as f:
            out["uptime"] = float(f.read().split()[0])
    except (OSError, ValueError):
        pass
    return out


SPEED_DOWN = "https://speed.cloudflare.com/__down?bytes=50000000"
SPEED_UP = "https://speed.cloudflare.com/__up"
SPEED_PING = "https://speed.cloudflare.com/__down?bytes=0"
_speed = {"running": False, "phase": "", "down": None, "up": None, "ping": None, "at": 0, "error": ""}


def _speed_worker():
    import urllib.request as ur
    try:
        # Antwortzeit (kleinster von 5 Versuchen)
        _speed["phase"] = "ping"
        pings = []
        for _ in range(5):
            t0 = time.time()
            with ur.urlopen(ur.Request(SPEED_PING, headers={"User-Agent": "Raspi-TV"}), timeout=10) as r:
                r.read()
            pings.append((time.time() - t0) * 1000)
        _speed["ping"] = round(min(pings))
        # Herunterladen: höchstens 10 Sekunden
        _speed["phase"] = "down"
        t0, got = time.time(), 0
        with ur.urlopen(ur.Request(SPEED_DOWN, headers={"User-Agent": "Raspi-TV"}), timeout=20) as r:
            while time.time() - t0 < 10:
                chunk = r.read(256 * 1024)
                if not chunk:
                    break
                got += len(chunk)
                _speed["down"] = round(got * 8 / max(0.001, time.time() - t0) / 1e6, 1)
        # Hochladen: 8 MB (klappt das nicht, bleibt das Download-Ergebnis stehen)
        _speed["phase"] = "up"
        try:
            blob = os.urandom(8 * 1024 * 1024)
            t0 = time.time()
            req = ur.Request(SPEED_UP, data=blob, method="POST", headers={"User-Agent": "Raspi-TV", "Content-Type": "application/octet-stream"})
            with ur.urlopen(req, timeout=40) as r:
                r.read()
            _speed["up"] = round(len(blob) * 8 / max(0.001, time.time() - t0) / 1e6, 1)
        except Exception:  # noqa: BLE001
            _speed["up"] = None
        _speed.update(error="", at=time.time())
    except Exception as e:  # noqa: BLE001
        print("Geschwindigkeitstest:", e, flush=True)
        _speed.update(error="Test nicht möglich – ist Raspi-TV mit dem Internet verbunden?", at=time.time())
    finally:
        _speed.update(running=False, phase="")


def speedtest_start(_data=None):
    if not _speed["running"]:
        _speed.update(running=True, phase="ping", down=None, up=None, ping=None, error="")
        threading.Thread(target=_speed_worker, daemon=True).start()
    return dict(_speed)


GET_ROUTES["/api/sysmon"] = sysmon
GET_ROUTES["/api/speedtest"] = lambda: dict(_speed)
POST_ROUTES["/api/speedtest"] = speedtest_start


# Handy-Fernbedienung: Akzentfarbe des gewählten Designs mitschicken
_ACCENT_HEX = {"blue": ("#3d8bff", "#2563eb", "#1d4ed8"), "violet": ("#a78bfa", "#7c3aed", "#6d28d9"),
               "green": ("#34d399", "#047857", "#065f46"), "orange": ("#fb923c", "#c2410c", "#9a3412"),
               "red": ("#f87171", "#dc2626", "#b91c1c"), "pink": ("#f472b6", "#be185d", "#9d174d"),
               "teal": ("#22d3ee", "#0e7490", "#155e75"), "gold": ("#fbbf24", "#b45309", "#92400e")}
_THEME_ACCENT = {"midnight": "blue", "oled": "blue", "aurora": "teal", "sunset": "orange", "forest": "green",
                 "cinema": "red", "light": "blue", "auto": "blue"}
_remote_ping_base = _remote_ping


def _remote_ping(data):  # noqa: F811
    out = _remote_ping_base(data)
    cfg = _cfg()
    acc = cfg.get("accent") or "theme"
    if acc == "theme":
        acc = _THEME_ACCENT.get(cfg.get("theme") or "midnight", "blue")
    a, f1, f2 = _ACCENT_HEX.get(acc, _ACCENT_HEX["blue"])
    out["accent"] = {"a": a, "f1": f1, "f2": f2}
    return out


REMOTE_ROUTES_EXTRA["/r/ping"] = _remote_ping
