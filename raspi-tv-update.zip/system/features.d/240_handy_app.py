# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Handy-App 1.3: „Jetzt läuft“, Senderliste, Umschalten, Aufnehmen, Schlaf-Timer
#   Alles läuft über REMOTE_ROUTES – also per WLAN und genauso per Bluetooth.
# ==========================================================================
_tvnow = {"name": None, "at": 0, "favs": []}
_sleep = {"until": 0}


def tv_now_report(data):
    """tv.html meldet den laufenden Sender (beim Umschalten und alle 30 s)."""
    name = data.get("name")
    _tvnow["name"] = str(name)[:80] if name else None
    _tvnow["at"] = time.time() if name else 0
    favs = data.get("favs")
    if isinstance(favs, list):
        _tvnow["favs"] = [str(f)[:80] for f in favs[:200]]
    return {"ok": True}


def _watching():
    return _tvnow["name"] if _tvnow["name"] and time.time() - _tvnow["at"] < 75 else None


def _sleep_left():
    left = _sleep["until"] - time.time()
    return int(left) if _sleep["until"] and left > 0 else None


def _slim(p):
    return {"title": p["title"], "start": p["start"], "stop": p["stop"]} if p else None


def remote_state(_data=None):
    name = _watching()
    rec = None
    try:
        rec = next((i for i in _rec().schedule() if i["status"] == "recording"), None)
    except Exception:  # noqa: BLE001 – ohne Rekorder trotzdem antworten
        pass
    out = {"tv": T["tv_power"](), "channel": None, "now": None, "next": None, "sleep_left": _sleep_left(),
           "recording": {"channel": rec["channel"], "title": rec["title"], "stop": rec["stop"]} if rec else None,
           "time": int(time.time())}
    if name:
        ch = next((c for c in all_channels() if c["name"] == name), None)
        e = epg_now().get(name) or {}
        out.update(channel={"name": name, "logo": (ch or {}).get("logo", ""),
                            "num": next((i + 1 for i, c in enumerate(all_channels()) if c["name"] == name), None)},
                   now=_slim(e.get("now")), next=_slim(e.get("next")))
    return out


def remote_channels(_data=None):
    epg = epg_now()
    favs = set(_tvnow["favs"])
    recs = set()
    try:
        recs = {i["channel"] for i in _rec().schedule() if i["status"] == "recording"}
    except Exception:  # noqa: BLE001
        pass
    lst = []
    for i, c in enumerate(all_channels()):
        e = epg.get(c["name"]) or {}
        lst.append({"num": i + 1, "name": c["name"], "logo": c.get("logo", ""), "fav": c["name"] in favs,
                    "rec": c["name"] in recs, "now": _slim(e.get("now")), "next": _slim(e.get("next"))})
    return {"channels": lst, "current": _watching(), "time": int(time.time())}


def remote_channel(data):
    name = str(data.get("name") or "")[:80]
    if name not in {c["name"] for c in all_channels()}:
        raise _err("Sender nicht gefunden")
    touch_activity()
    if T["tv_power"]() == "standby":
        try:
            cec_action({"action": "tv_on"})
        except Exception:  # noqa: BLE001
            pass
    request_nav(LAUNCHER + "tv.html?name=" + quote(name, safe=""))
    _tvnow.update(name=name, at=time.time())
    return {"ok": True}


def remote_record(data):
    """Läuft auf dem Sender schon eine Aufnahme → beenden, sonst sofort aufnehmen."""
    name = str(data.get("name") or _watching() or "")[:80]
    if not name:
        raise _err("Am Fernseher läuft gerade kein Sender")
    r = _rec()
    running = next((i for i in r.schedule() if i["status"] == "recording" and i["channel"] == name), None)
    if running:
        rec_cancel({"id": running["id"]})
        return {"ok": True, "recording": False, "title": running["title"]}
    st = rec_now({"channel": name})
    return {"ok": True, "recording": True, "title": st.get("title"), "until": st.get("until")}


def remote_sleep(data):
    try:
        minutes = max(0, min(240, int(data.get("minutes", 0))))
    except (TypeError, ValueError):
        raise _err("Ungültige Zeit")
    _sleep["until"] = time.time() + minutes * 60 if minutes else 0
    return {"ok": True, "sleep_left": _sleep_left()}


def sleep_loop():
    while True:
        time.sleep(10)
        try:
            if _sleep["until"] and time.time() >= _sleep["until"]:
                _sleep["until"] = 0
                T["tv_standby"]()
                _set_tv_power("standby")
                touch_activity()
        except Exception:  # noqa: BLE001 – Hintergrundschleife darf nie sterben
            pass


# Die letzten 2 Minuten des Schlaf-Timers zeigt der Fernseher wie die Abschalt-Warnung an
_autooff_left_base = autooff_left


def autooff_left():  # noqa: F811
    a, s = _autooff_left_base(), _sleep_left()
    if s is not None and s <= 120:
        return s if a is None else min(a, s)
    return a


_old_start12 = start_background


def start_background():  # noqa: F811
    _old_start12()
    threading.Thread(target=sleep_loop, daemon=True).start()


POST_ROUTES["/api/tv/now"] = tv_now_report
GET_ROUTES["/api/sleep"] = lambda: {"sleep_left": _sleep_left()}
POST_ROUTES["/api/sleep"] = remote_sleep
REMOTE_ROUTES_EXTRA["/r/state"] = remote_state
REMOTE_ROUTES_EXTRA["/r/channels"] = remote_channels
REMOTE_ROUTES_EXTRA["/r/channel"] = remote_channel
REMOTE_ROUTES_EXTRA["/r/record"] = remote_record
REMOTE_ROUTES_EXTRA["/r/sleep"] = remote_sleep
_status_sleep_base = _status_with_kids


def _status_with_kids():  # noqa: F811
    s = _status_sleep_base()
    s["sleep_left"] = _sleep_left()
    return s


GET_ROUTES["/api/status"] = _status_with_kids


# ==========================================================================
# Aussehen der Handy-App – wird am Fernseher eingestellt, per WLAN/Bluetooth aufs Handy
# übertragen und dort gespeichert (gilt also auch, wenn der Pi gerade nicht erreichbar ist).
# ==========================================================================
APP_TABS = ("channels", "touch", "keys", "search", "gamepad")
APP_LOOK_DEFAULT = {"theme": "tv", "accent": "tv", "layout": "classic", "hand": "right", "corners": "tv",
                    "nowbar": True, "tabs": {k: True for k in APP_TABS}}
APP_LOOK_CHECKS = {
    "theme": lambda v: v in ("tv", "midnight", "oled", "aurora", "sunset", "forest", "cinema", "light"),
    "accent": lambda v: v in ("tv", "blue", "violet", "teal", "green", "gold", "orange", "red", "pink"),
    "layout": lambda v: v in ("classic", "big", "swipe", "top"),
    "hand": lambda v: v in ("right", "left"),
    "corners": lambda v: v in ("tv", "round", "soft", "square"),
    "nowbar": lambda v: isinstance(v, bool),
    "tabs": lambda v: isinstance(v, dict) and all(k in APP_TABS and isinstance(x, bool) for k, x in v.items()),
}


def app_look():
    cfg = _cfg()
    raw = dict(APP_LOOK_DEFAULT)
    saved = cfg.get("app_look") or {}
    if isinstance(saved, dict):
        raw.update({k: v for k, v in saved.items() if k in APP_LOOK_CHECKS and APP_LOOK_CHECKS[k](v)})
    tabs = dict(APP_LOOK_DEFAULT["tabs"])
    tabs.update(raw.get("tabs") or {})
    theme = raw["theme"]
    if theme == "tv":
        theme = cfg.get("theme") or "midnight"
        if theme == "auto":
            theme = "light" if 7 <= time.localtime().tm_hour < 19 else "midnight"
    if theme not in ("midnight", "oled", "aurora", "sunset", "forest", "cinema", "light"):
        theme = "midnight"
    acc = raw["accent"]
    if acc == "tv":
        acc = cfg.get("accent") or "theme"
        if acc == "theme":
            acc = _THEME_ACCENT.get(cfg.get("theme") or "midnight", "blue")
    if raw["accent"] == "tv" and raw["theme"] != "tv":
        acc = _THEME_ACCENT.get(theme, "blue")      # eigenes Handy-Design bringt seine Farbe mit
    a, f1, f2 = _ACCENT_HEX.get(acc, _ACCENT_HEX["blue"])
    corners = raw["corners"] if raw["corners"] != "tv" else (cfg.get("corners") or "round")
    out = {"theme": theme, "accent": {"a": a, "f1": f1, "f2": f2}, "layout": raw["layout"], "hand": raw["hand"],
           "corners": corners, "nowbar": raw["nowbar"], "tabs": tabs}
    out["v"] = hashlib.sha1(json.dumps(out, sort_keys=True).encode()).hexdigest()[:10]
    return out


_remote_ping_look = _remote_ping


def _remote_ping(data):  # noqa: F811
    out = _remote_ping_look(data)
    out["look"] = app_look()
    out["accent"] = out["look"]["accent"]
    return out


REMOTE_ROUTES_EXTRA["/r/ping"] = _remote_ping
GET_ROUTES["/api/applook"] = lambda: {"look": app_look(), "saved": dict(APP_LOOK_DEFAULT, **(_cfg().get("app_look") or {}))}
