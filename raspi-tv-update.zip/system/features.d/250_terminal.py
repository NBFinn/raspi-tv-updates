# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Terminal (Einstellungen · System · Terminal und Apps → Terminal)
#   Echte Shell auf dem Pi im Fernseher. Die Sitzung läuft weiter, wenn man die Seite verlässt.
#   Angemeldet als Wartungsbenutzer (admin, sudo mit Passwort), damit nicht jeder mit der
#   Fernbedienung Root-Rechte hat.
# ==========================================================================
TERMINAL_USER = "admin"
TERM_APPS = ("shell", "spotify")


def _term():
    import terminal
    return terminal


def _user_env(user):
    import pwd
    pw = pwd.getpwnam(user)
    return pw, {"HOME": pw.pw_dir, "USER": user, "LOGNAME": user, "SHELL": pw.pw_shell or "/bin/bash",
                "TERM": "xterm-256color", "COLORTERM": "truecolor", "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8",
                "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
                "XDG_RUNTIME_DIR": f"/run/user/{pw.pw_uid}"}


def _shell_cmd():
    """Login-Shell des Wartungsbenutzers – ohne ihn (Entwicklungsrechner) die eigene Shell."""
    for user in (TERMINAL_USER, T["TV_USER"]):
        try:
            _, env = _user_env(user)
        except KeyError:
            continue
        if os.geteuid() == 0 and shutil.which("runuser"):
            return ["runuser", "-l", user], env, env["HOME"]
    env = {k: v for k, v in os.environ.items() if k not in ("DISPLAY", "WAYLAND_DISPLAY")}
    env.update(TERM="xterm-256color", COLORTERM="truecolor")
    return ["bash", "-l"], env, os.path.expanduser("~")


def _term_session(sid):
    s = _term().get(sid)
    if not s:
        raise _err("Sitzung nicht gefunden", 404)
    return s


def term_start(data):
    app = data.get("app", "shell")
    if app not in TERM_APPS:
        raise _err("Unbekannt")
    cols, rows = data.get("cols", 100), data.get("rows", 30)
    if app == "spotify":
        argv, env, cwd = _ncspot_cmd()
        s = _term().start("spotify", argv, env, cwd, cols, rows, "Spotify")
    else:
        argv, env, cwd = _shell_cmd()
        if data.get("restart"):
            _term().stop("shell")
            time.sleep(0.3)
        s = _term().start("shell", argv, env, cwd, cols, rows, "Terminal")
    touch_activity()
    return s.info()


def term_read(query, headers):
    if headers.get("X-Raspi-TV") != "1":
        raise _err("forbidden", 403)
    s = _term_session((query.get("id") or [""])[0])
    try:
        since = int((query.get("since") or ["0"])[0])
    except ValueError:
        since = 0
    out = s.read(since, 20)
    if s.id == "spotify":
        auth = _ncspot_auth(s)
        out["auth_url"] = auth["url"] if auth else None
        out["auth_step"] = auth["step"] if auth else 0
    return out


def term_write(data):
    s = _term_session(str(data.get("id") or ""))
    text = data.get("data")
    if not isinstance(text, str) or len(text) > 65536:
        raise _err("Ungültig")
    s.write(text)
    touch_activity()
    return {"ok": True}


def term_resize(data):
    _term_session(str(data.get("id") or "")).resize(data.get("cols"), data.get("rows"))
    return {"ok": True}


def term_stop(data):
    sid = str(data.get("id") or "")
    if sid in TERM_APPS:
        _term().stop(sid)
    return {"ok": True}


POST_ROUTES["/api/term/start"] = term_start
POST_ROUTES["/api/term/write"] = term_write
POST_ROUTES["/api/term/resize"] = term_resize
POST_ROUTES["/api/term/stop"] = term_stop
QUERY_ROUTES["/api/term/read"] = term_read
GET_ROUTES["/api/term"] = lambda: {"sessions": _term().all_info()}
