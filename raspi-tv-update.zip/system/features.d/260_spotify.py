# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Spotify als App auf dem Fernseher (ncspot)
#   Spotify gibt es für den Raspberry Pi nicht als offizielles Programm. ncspot ist ein
#   schlanker Spotify-Player (librespot, braucht Spotify Premium). Er läuft in einer
#   dauerhaften Terminal-Sitzung: Musik spielt weiter, auch auf der Startseite und in
#   anderen Apps. Steuerung mit der Fernbedienung (Pfeile, OK, Zurück, Pause, CH ±).
# ==========================================================================
# 1.5.0: Spotify hat Ende Oktober 2026 die Rückmeldeadresse von ncspot geändert (/ncspot_login) –
# ältere Versionen scheitern bei der zweiten Anmeldung mit „redirect_uri: Not matching configuration“.
NCSPOT_VERSION = "1.5.0"
NCSPOT_STAMP = "/usr/local/lib/raspi-tv-ncspot.version"
NCSPOT_URL = "https://github.com/hrkfdn/ncspot/releases/download/v{v}/ncspot-v{v}-linux-{arch}.tar.gz"
NCSPOT_BIN = "/usr/local/bin/ncspot"
NCSPOT_DEPS = ("libpulse0", "libssl3t64")

_ANSI = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b\][^\x07]*\x07|\x1b[()][A-Z0-9]")

NCSPOT_CONFIG = '''# Von Raspi-TV verwaltet – wird beim Start von Spotify überschrieben.
use_nerdfont = false
notify = false
gapless = true
volnorm = true
bitrate = 320
backend = "pulseaudio"
initial_screen = "library"
library_tabs = ["tracks", "albums", "artists", "playlists", "podcasts"]

[keybindings]
"Space" = "playpause"
"PageUp" = "previous"
"PageDown" = "next"
"g" = "focus library"
"i" = "focus queue"
"r" = "focus search"
"F5" = "focus search"
"q" = "noop"

[theme]
background = "#121212"
primary = "#f2f2f2"
secondary = "#a7a7a7"
title = "#1ed760"
playing = "#1ed760"
playing_selected = "#1ed760"
playing_bg = "#121212"
highlight = "#ffffff"
highlight_bg = "#2f6b45"
error = "#ffffff"
error_bg = "#c0392b"
statusbar = "#121212"
statusbar_progress = "#1ed760"
statusbar_bg = "#1ed760"
cmdline = "#ffffff"
cmdline_bg = "#181818"
search_match = "#1ed760"
'''


def _ncspot_bin():
    return shutil.which("ncspot") or (NCSPOT_BIN if os.access(NCSPOT_BIN, os.X_OK) else None)


def _ncspot_cmd():
    exe = _ncspot_bin()
    if not exe:
        raise _err("Spotify ist noch nicht installiert")
    try:
        pw, env = _user_env(T["TV_USER"])
        user = T["TV_USER"]
    except KeyError:
        pw, user = None, None
        env = {k: v for k, v in os.environ.items() if k not in ("DISPLAY", "WAYLAND_DISPLAY")}
        env.update(TERM="xterm-256color", COLORTERM="truecolor")
    home = env.get("HOME") or os.path.expanduser("~")
    cfgdir = os.path.join(home, ".config", "ncspot")
    try:
        os.makedirs(cfgdir, exist_ok=True)
        with open(os.path.join(cfgdir, "config.toml"), "w") as f:
            f.write(NCSPOT_CONFIG)
        if pw and os.geteuid() == 0:
            for d in (os.path.join(home, ".config"), cfgdir, os.path.join(cfgdir, "config.toml")):
                os.chown(d, pw.pw_uid, pw.pw_gid)
    except OSError:
        pass
    env["BROWSER"] = "/bin/true"     # Anmelde-Link nicht selbst öffnen – die Oberfläche zeigt ihn an
    if user and os.geteuid() == 0 and shutil.which("runuser"):
        return ["runuser", "-u", user, "--", "env"] + [f"{k}={v}" for k, v in env.items()] + [exe], env, home
    return [exe], env, home


def _listen_ports():
    """Lokale TCP-Ports im Zustand LISTEN (ohne sich zu verbinden – das würde die Anmeldung stören)."""
    ports = set()
    for f in ("/proc/net/tcp", "/proc/net/tcp6"):
        try:
            with open(f) as fh:
                next(fh, None)
                for line in fh:
                    parts = line.split()
                    if len(parts) > 3 and parts[3] == "0A":
                        ports.add(int(parts[1].rsplit(":", 1)[1], 16))
        except (OSError, ValueError):
            pass
    return ports


_AUTH_RE = re.compile(r"https://accounts\.spotify\.com/authorize\?[^\s\"'<>\x00-\x1f]+(?=\s)")


def _ncspot_auth(s):
    """Offene Spotify-Anmeldung: der letzte Anmelde-Link, dessen Rückmelde-Port ncspot gerade offen hat.
    ncspot fragt zweimal (Wiedergabe, danach Bibliothek/Playlists) – jeweils mit eigenem Port."""
    raw = bytes(s.buf)
    if b"accounts.spotify.com/authorize" not in raw:
        return None
    text = _ANSI.sub("", raw.decode("utf-8", "replace"))
    urls = []
    for m in _AUTH_RE.finditer(text):
        if m.group(0) not in urls:
            urls.append(m.group(0))
    if not urls:
        return None
    ports = _listen_ports()
    for i in range(len(urls) - 1, -1, -1):
        q = parse_qs(urlparse(urls[i]).query)
        try:
            port = urlparse((q.get("redirect_uri") or [""])[0]).port
        except ValueError:
            port = None
        if port and port in ports:
            return {"url": urls[i], "step": i + 1}
    return None


def _ncspot_sock_paths():
    paths = []
    try:
        import pwd
        uid = pwd.getpwnam(T["TV_USER"]).pw_uid
        home = pwd.getpwnam(T["TV_USER"]).pw_dir
    except KeyError:
        uid, home = os.getuid(), os.path.expanduser("~")
    for pat in (f"/run/user/{uid}/ncspot/*.sock", f"/run/user/{uid}/ncspot*.sock", f"/tmp/ncspot-{uid}/*.sock",
                f"{home}/.cache/ncspot/*.sock"):
        paths += glob.glob(pat)
    return paths


def _ncspot_ipc(cmd=None):
    """Status über die IPC-Schnittstelle von ncspot lesen (eine JSON-Zeile) und ggf. Befehl schicken."""
    import socket as _s
    for path in _ncspot_sock_paths():
        try:
            c = _s.socket(_s.AF_UNIX, _s.SOCK_STREAM)
            c.settimeout(1.0)
            c.connect(path)
            if cmd:
                c.sendall((cmd + "\n").encode())
            buf = b""
            while b"\n" not in buf and len(buf) < 65536:
                part = c.recv(8192)
                if not part:
                    break
                buf += part
            c.close()
            line = buf.split(b"\n", 1)[0]
            return json.loads(line) if line else {}
        except (OSError, ValueError):
            continue
    return None


def _ncspot_now():
    s = _term().get("spotify")
    if not s or not s.alive:
        return None
    st = _ncspot_ipc()
    if not st:
        return None
    mode = st.get("mode")
    playing = isinstance(mode, dict) and "Playing" in mode
    paused = isinstance(mode, dict) and "Paused" in mode
    p = st.get("playable") or {}
    artists = p.get("artists") or []
    cover = p.get("cover_url") or ""
    return {"playing": playing, "paused": paused, "title": str(p.get("title") or "")[:120],
            "artist": ", ".join(str(a) for a in artists)[:120] if isinstance(artists, list) else str(artists)[:120],
            "album": str(p.get("album") or "")[:120], "cover": cover if str(cover).startswith("https://") else "",
            "duration": int(p.get("duration") or 0), "position": 0, "at": int(time.time()), "app": True}


_spotify_now_base = spotify_now


def spotify_now():  # noqa: F811
    n = _ncspot_now()
    if n and (n["playing"] or n["paused"]):
        return n
    return _spotify_now_base()


def _ncspot_outdated():
    """Von Raspi-TV installiertes ncspot, aber nicht die aktuelle Version → neu laden."""
    if _ncspot_bin() != NCSPOT_BIN:
        return False
    try:
        with open(NCSPOT_STAMP) as f:
            return f.read().strip() != NCSPOT_VERSION
    except OSError:
        return True


def ncspot_status():
    job = dict(_job) if _job.get("id") == "ncspot" else None
    s = _term().get("spotify")
    _, arch, _ = T["run"](["dpkg", "--print-architecture"], 10)
    return {"installed": bool(_ncspot_bin()), "update": _ncspot_outdated(), "running": bool(s and s.alive), "job": job,
            "supported": (arch.strip() or "arm64") in ("arm64", "amd64"), "version": NCSPOT_VERSION}


def _ncspot_install_worker():
    try:
        with _apt_lock, open(NATIVE_LOG, "a") as log:
            log.write(f"\n=== {time.strftime('%Y-%m-%d %H:%M:%S')} install ncspot ===\n")
            _job.update(step="Wird vorbereitet", percent=5)
            # Offizielles Release von GitHub (64-Bit) – die Paketquellen haben oft eine ältere Version
            _, arch, _ = T["run"](["dpkg", "--print-architecture"], 10)
            arch = {"arm64": "arm64", "amd64": "x86_64"}.get(arch.strip() or "arm64")
            if not arch:
                raise RuntimeError("Spotify braucht ein 64-Bit-System (Raspberry Pi 3, 4 oder 5 mit 64-Bit-Image).")
            for i, dep in enumerate(NCSPOT_DEPS):
                _job.update(step="Wird vorbereitet", percent=10 + i * 4)
                _apt(["install", "--no-install-recommends", dep], log, 10 + i * 4, 12 + i * 4)
            os.makedirs("/var/cache/raspi-tv", exist_ok=True)
            tgz = "/var/cache/raspi-tv/ncspot.tar.gz"
            _job.update(step="Wird heruntergeladen", percent=45)
            p = subprocess.run(["curl", "-fsSL", "--retry", "3", "-o", tgz, NCSPOT_URL.format(v=NCSPOT_VERSION, arch=arch)],
                               stdout=log, stderr=subprocess.STDOUT, timeout=600)
            if p.returncode != 0:
                raise RuntimeError("Spotify konnte nicht geladen werden – Internetverbindung prüfen.")
            _job.update(step="Wird installiert", percent=80)
            tmp = tempfile.mkdtemp(prefix="ncspot-")
            p = subprocess.run(["tar", "xzf", tgz, "-C", tmp], stdout=log, stderr=subprocess.STDOUT, timeout=120)
            exe = next((os.path.join(d, f) for d, _, fs in os.walk(tmp) for f in fs if f == "ncspot"), None)
            if p.returncode != 0 or not exe:
                raise RuntimeError("Spotify-Paket ist beschädigt.")
            # laufendes Spotify beenden und die Datei austauschen (auch während sie benutzt wird)
            _term().stop("spotify")
            shutil.copy(exe, NCSPOT_BIN + ".new")
            os.chmod(NCSPOT_BIN + ".new", 0o755)
            os.replace(NCSPOT_BIN + ".new", NCSPOT_BIN)
            os.makedirs(os.path.dirname(NCSPOT_STAMP), exist_ok=True)
            with open(NCSPOT_STAMP, "w") as f:
                f.write(NCSPOT_VERSION + "\n")
            shutil.rmtree(tmp, ignore_errors=True)
            try:
                os.remove(tgz)
            except OSError:
                pass
            _, missing, _ = T["run"](["sh", "-c", f"ldd {NCSPOT_BIN} | grep 'not found' || true"], 20)
            if missing.strip():
                log.write("Fehlende Bibliotheken:\n" + missing)
                raise RuntimeError("Spotify fehlen Systembibliotheken: " + missing.strip().split()[0])
        _job.update(done=True, percent=100, step="Fertig")
    except Exception as e:  # noqa: BLE001
        _job["error"] = str(e)
    finally:
        _job["running"] = False


def ncspot_install(_data=None):
    if _ncspot_bin() and not _ncspot_outdated():
        return ncspot_status()
    if _job["running"]:
        raise _err("Es läuft schon eine Installation – bitte kurz warten.", 409)
    _job.update(running=True, id="ncspot", action="install", step="Wird vorbereitet", percent=0, error=None, done=False)
    threading.Thread(target=_ncspot_install_worker, daemon=True).start()
    return ncspot_status()


def ncspot_ctl(data):
    cmd = data.get("cmd")
    if cmd not in ("playpause", "next", "previous", "stop"):
        raise _err("Ungültig")
    if _ncspot_ipc(cmd) is None:
        s = _term().get("spotify")
        keys = {"playpause": " ", "next": "\x1b[6~", "previous": "\x1b[5~", "stop": "S"}
        if not s or not s.alive:
            raise _err("Spotify läuft nicht")
        s.write(keys[cmd])
    return {"ok": True}


def ncspot_quit(_data=None):
    _term().stop("spotify")
    return {"ok": True}


GET_ROUTES["/api/spotify/now"] = spotify_now
GET_ROUTES["/api/ncspot"] = ncspot_status
POST_ROUTES["/api/ncspot/install"] = ncspot_install
POST_ROUTES["/api/ncspot/ctl"] = ncspot_ctl
POST_ROUTES["/api/ncspot/quit"] = ncspot_quit


# ==========================================================================
# Spotify im eigenen Hintergrund-Tab (open.spotify.com)
#   Die Erweiterung meldet, was gerade läuft – für die Leiste auf der Startseite.
# ==========================================================================
_webnow = {"now": None, "at": 0}


def spotify_webnow(query, headers):
    if headers.get("X-Raspi-TV") != "1":
        raise _err("forbidden", 403)
    try:
        n = json.loads((query.get("d") or ["null"])[0])
    except ValueError:
        n = None
    if isinstance(n, dict) and n.get("title"):
        cover = str(n.get("cover") or "")
        _webnow.update(at=time.time(), now={
            "playing": bool(n.get("playing")), "paused": not n.get("playing"), "title": str(n["title"])[:120],
            "artist": str(n.get("artist") or "")[:120], "album": "", "duration": 0, "position": 0,
            "cover": cover if cover.startswith("https://") else "", "at": int(time.time()), "web": True})
    else:
        _webnow.update(at=time.time(), now=None)
    return {"ok": True}


_spotify_now_app = spotify_now


def spotify_now():  # noqa: F811
    if _webnow["now"] and time.time() - _webnow["at"] < 20:
        return _webnow["now"]
    return _spotify_now_app()


QUERY_ROUTES["/api/spotify/webnow"] = spotify_webnow
GET_ROUTES["/api/spotify/now"] = spotify_now
