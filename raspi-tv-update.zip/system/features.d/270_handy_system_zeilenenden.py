# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Handy-App: Raspberry Pi ausschalten / neu starten (WLAN und Bluetooth)
# ==========================================================================
def remote_system(data):
    action = data.get("action")
    if action not in ("shutdown", "reboot"):
        raise _err("Ungültig")
    push_notice({"kicker": "Handy-Fernbedienung",
                 "title": "Raspberry Pi startet neu" if action == "reboot" else "Raspberry Pi wird ausgeschaltet",
                 "sub": "Einen Moment …" if action == "reboot" else "Zum Einschalten kurz den Strom trennen"}, ttl=20)
    threading.Timer(2.5, T["power"], [action]).start()     # Hinweis noch kurz am Fernseher zeigen
    return {"ok": True}


REMOTE_ROUTES_EXTRA["/r/system"] = remote_system


# ==========================================================================
# Update-Pakete von Windows: Zeilenenden reparieren
#   Unter Windows bearbeitete Dateien haben oft CRLF-Zeilenenden. Shell-Skripte (z. B. der
#   Browser-Start) laufen damit unter Linux nicht – deshalb vor dem Installieren umwandeln.
# ==========================================================================
_TEXT_EXT = (".sh", ".py", ".js", ".cjs", ".mjs", ".html", ".css", ".json", ".service", ".txt", ".md", ".conf", ".toml")
_TEXT_NAMES = ("xinitrc", "xbindkeysrc", "bash_profile", "VERSION", "00-packages-nr")


def _unix_line_endings(root):
    n = 0
    for d, _, files in os.walk(root):
        for f in files:
            if not (f.endswith(_TEXT_EXT) or f in _TEXT_NAMES):
                continue
            p = os.path.join(d, f)
            try:
                with open(p, "rb") as fh:
                    data = fh.read()
                if b"\r" in data or data.startswith(b"\xef\xbb\xbf"):
                    with open(p, "wb") as fh:
                        fh.write(data.removeprefix(b"\xef\xbb\xbf").replace(b"\r\n", b"\n").replace(b"\r", b"\n"))
                    n += 1
            except OSError:
                pass
    return n
