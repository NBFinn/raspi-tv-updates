# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# iPhone-Fernbedienung (HomeKit, Dienst raspi-tv-homekit)
#   Einstellungen → Fernbedienung → iPhone. HAP-python wird beim ersten Einschalten aus dem
#   Internet geladen (nach /var/lib/raspi-tv/pylib, das System bleibt unverändert).
# ==========================================================================
HK_PYLIB = "/var/lib/raspi-tv/pylib"
HK_INFO = "/run/raspi-tv/homekit.json"
HK_VERSION = "5.1.0"
HK_INPUTS = {1: "", 2: "tv.html", 3: "#/guide", 4: "#/radio", 5: "#/media"}


def _hk_installed():
    return os.path.isdir(os.path.join(HK_PYLIB, "pyhap")) and os.path.isdir(os.path.join(HK_PYLIB, "zeroconf"))


def _hk_running():
    code, out, _ = T["run"](["systemctl", "is-active", "raspi-tv-homekit"], 10)
    return out.strip() == "active"


def homekit_status():
    info = {}
    try:
        with open(HK_INFO) as f:
            info = json.load(f)
    except (OSError, ValueError):
        pass
    running = _hk_running()
    job = dict(_job) if _job.get("id") == "homekit" else None
    return {"enabled": bool(_cfg().get("homekit")), "installed": _hk_installed(), "running": running,
            "pin": info.get("pin") if running else None, "uri": info.get("uri") if running else None,
            "paired": bool(info.get("paired")) if running else False, "clients": info.get("clients", 0),
            "addresses": info.get("addresses", []), "job": job}


def _hk_service(on):
    T["run"](["systemctl", "enable" if on else "disable", "--now", "raspi-tv-homekit"], 60)


def _hk_install_worker():
    try:
        with _apt_lock, open(NATIVE_LOG, "a") as log:
            log.write(f"\n=== {time.strftime('%Y-%m-%d %H:%M:%S')} install HomeKit ===\n")
            _job.update(step="Wird vorbereitet", percent=5)
            code, _, _ = T["run"](["python3", "-m", "pip", "--version"], 30)
            if code != 0:
                _apt(["install", "--no-install-recommends", "python3-pip"], log, 5, 40)
            _job.update(step="Wird heruntergeladen", percent=45)
            os.makedirs(HK_PYLIB, exist_ok=True)
            p = subprocess.run(["python3", "-m", "pip", "install", "--disable-pip-version-check", "--no-cache-dir",
                                "--break-system-packages", "--upgrade", "--target", HK_PYLIB, f"HAP-python=={HK_VERSION}"],
                               stdout=log, stderr=subprocess.STDOUT, timeout=1200)
            if p.returncode != 0 or not _hk_installed():
                raise RuntimeError("HomeKit konnte nicht geladen werden – Internetverbindung prüfen.")
            _job.update(step="Wird gestartet", percent=90)
            if _cfg().get("homekit"):
                _hk_service(True)
        _job.update(done=True, percent=100, step="Fertig")
    except Exception as e:  # noqa: BLE001
        _job["error"] = str(e)
    finally:
        _job["running"] = False


def homekit_set(data):
    on = bool(data.get("on"))
    cfg = _cfg()
    cfg["homekit"] = on
    T["save_config"](cfg)
    if on and not _hk_installed():
        if _job["running"]:
            raise _err("Es läuft schon eine Installation – bitte kurz warten.", 409)
        _job.update(running=True, id="homekit", action="install", step="Wird vorbereitet", percent=0, error=None, done=False)
        threading.Thread(target=_hk_install_worker, daemon=True).start()
    else:
        _hk_service(on)
    return homekit_status()


def homekit_reset(_data=None):
    """Kopplung löschen: neuer Code, das iPhone muss neu hinzugefügt werden."""
    T["run"](["systemctl", "stop", "raspi-tv-homekit"], 30)
    for f in ("homekit.state", "homekit-code.json"):
        try:
            os.remove(os.path.join("/var/lib/raspi-tv", f))
        except OSError:
            pass
    try:
        os.remove(HK_INFO)
    except OSError:
        pass
    if _cfg().get("homekit") and _hk_installed():
        T["run"](["systemctl", "start", "raspi-tv-homekit"], 30)
    return homekit_status()


def hk_key(data):
    T["VINPUT"].key(str(data.get("key")))
    touch_activity()
    return {"ok": True}


def hk_power(data):
    touch_activity()
    if data.get("on"):
        try:
            cec_action({"action": "tv_on"})
        except Exception:  # noqa: BLE001
            pass
        _set_tv_power("on")
    else:
        T["tv_standby"]()
        _set_tv_power("standby")
    return {"ok": True}


def hk_input(data):
    try:
        ident = int(data.get("id"))
    except (TypeError, ValueError):
        raise _err("Ungültig")
    if ident not in HK_INPUTS:
        raise _err("Ungültig")
    touch_activity()
    request_nav(LAUNCHER + HK_INPUTS[ident])
    return {"ok": True}


GET_ROUTES["/api/homekit"] = homekit_status
POST_ROUTES["/api/homekit"] = homekit_set
POST_ROUTES["/api/homekit/reset"] = homekit_reset
POST_ROUTES["/api/hk/key"] = hk_key
POST_ROUTES["/api/hk/power"] = hk_power
POST_ROUTES["/api/hk/input"] = hk_input


# Benutzerprofile: nur persönliche Darstellung und Sender, keine Konten/Systemrechte.
PROFILE_KEYS = ("theme", "accent", "background", "wallpaper", "wallpaper_rotate", "motion", "corners", "home_layout",
                "home_sections", "ui_scale", "channel_order", "channel_hidden")
_profile_lock = threading.RLock()


def _profile_data(cfg):
    return json.loads(json.dumps({k: cfg[k] for k in PROFILE_KEYS if k in cfg}))


def _profile_init(cfg):
    if not cfg.get("profiles"):
        cfg["profiles"] = [{"id": "default", "name": "Standard", "settings": _profile_data(cfg)}]
        cfg["active_profile"] = "default"


def profiles_status():
    with _profile_lock:
        cfg = _cfg()
        _profile_init(cfg)
        return {"active": cfg["active_profile"],
                "profiles": [{"id": p["id"], "name": p["name"]} for p in cfg["profiles"]]}


def profiles_change(data):
    with _profile_lock:
        cfg = _cfg()
        _profile_init(cfg)
        profiles = cfg["profiles"]
        action = data.get("action")
        target = next((p for p in profiles if p["id"] == data.get("id")), None)
        if action in ("create", "rename"):
            name = str(data.get("name") or "").strip()
            if not name or len(name) > 24 or any(ord(c) < 32 for c in name):
                raise _err("Bitte einen Profilnamen mit 1 bis 24 Zeichen eingeben.")
            if any(p["name"].casefold() == name.casefold() and (action == "create" or p is not target) for p in profiles):
                raise _err("Dieser Profilname ist bereits vergeben.")
        if action == "create":
            if len(profiles) >= 8:
                raise _err("Es sind höchstens acht Profile möglich.")
            profiles.append({"id": secrets.token_hex(8), "name": name, "settings": _profile_data(cfg)})
        elif action == "rename" and target:
            target["name"] = name
        elif action == "switch" and target:
            current = next(p for p in profiles if p["id"] == cfg["active_profile"])
            current["settings"] = _profile_data(cfg)
            for key in PROFILE_KEYS:
                cfg.pop(key, None)
            cfg.update(target["settings"])
            cfg["active_profile"] = target["id"]
            _tvnow.update(name=None, at=0, favs=[])
        elif action == "delete" and target:
            if target["id"] == cfg["active_profile"]:
                raise _err("Bitte zuerst zu einem anderen Profil wechseln.")
            profiles.remove(target)
        else:
            raise _err("Ungültige Profilaktion.")
        _save(cfg)
        return profiles_status()


GET_ROUTES["/api/profiles"] = profiles_status
POST_ROUTES["/api/profiles"] = profiles_change


# Multimedia routes share the existing phone pairing and local API boundaries.
_media_lock = threading.RLock()
_media_module = None
_audio_meter = None
_mirror = None
_gamepad = None


def _load_media():
    global _media_module
    with _media_lock:
        if _media_module is None:
            import importlib.util
            spec = importlib.util.spec_from_file_location("raspitv_multimedia", os.path.join(os.path.dirname(__file__), "multimedia.py"))
            _media_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(_media_module)
        return _media_module


def audio_meter_status():
    global _audio_meter
    with _media_lock:
        if _audio_meter is None: _audio_meter = _load_media().AudioMeter(T)
    return _audio_meter.poll()


def mirror_request(data, viewer=False):
    global _mirror
    with _media_lock:
        if _mirror is None: _mirror = _load_media().Mirror(request_nav)
    try: return _mirror.request(data, viewer)
    except ValueError as e: raise _err(str(e))


def gamepad_request(data):
    global _gamepad
    with _media_lock:
        if _gamepad is None: _gamepad = _load_media().Gamepad()
    try: return _gamepad.request(data)
    except (ValueError, OSError) as e: raise _err(str(e), 503 if isinstance(e,OSError) else 400)


GET_ROUTES["/api/audio-meter"] = audio_meter_status
POST_ROUTES["/api/mirror"] = lambda d: mirror_request(d, True)
REMOTE_ROUTES_EXTRA["/r/mirror"] = mirror_request
REMOTE_ROUTES_EXTRA["/r/gamepad"] = gamepad_request


# A read-only state feed for optional round displays. No audio or volume changes.
_round_lock = threading.Lock()
_round_volume = {"at": 0, "volume": None, "muted": False, "target": "pi"}


def round_display_state():
    with _round_lock:
        cfg = _cfg()
        target = cfg.get("volume_target", "auto")
        if target == "auto": target = "soundbar" if _cec_cache.get("soundbar") else "pi"
        if target == "pi" and (time.monotonic()-_round_volume["at"] > 1 or _round_volume["target"] != target):
            _, out, _ = T["as_tv"](["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"], 2)
            match = re.search(r"Volume:\s*([0-9.]+)", out)
            _round_volume.update(at=time.monotonic(), target=target,
                volume=min(100,max(0,round(float(match.group(1))*100))) if match else None,
                muted="MUTED" in out)
        elif target != "pi":
            # CEC control without an audio-status reply does not reveal the TV's percentage.
            _round_volume.update(at=time.monotonic(),target=target,volume=None,muted=False)
        current = spotify_now()
        brightness = cfg.get("round_brightness", 100)
        return {"music": current, "volume": _round_volume["volume"], "muted": _round_volume["muted"],
                "target": target, "time": int(time.time()),
                "brightness": brightness if type(brightness) is int and 10 <= brightness <= 100 else 100,
                "palette": _round_palette(cfg), "intro": cfg.get("round_intro", True) is not False,
                "intro_seq": _round_intro["seq"], "version": _installed_version(),
                "motion": cfg.get("round_motion", "full"), "update": _round_update(cfg),
                "spi_hz": (cfg.get("round_speed") if cfg.get("round_speed") in (4, 8, 16, 32) else 4) * 1_000_000,
                "teensy_hz": (cfg.get("round_teensy_mhz") if cfg.get("round_teensy_mhz") in (15, 24, 30, 40, 60) else 30) * 1_000_000}


def _round_update(cfg):
    """Kurzfassung für die Update-Seite der runden Displays."""
    inst = _installed_version()
    latest = _online.get("latest")
    return {"installed": inst, "latest": latest,
            "newer": bool(latest and _ver_tuple(latest) > _ver_tuple(inst)),
            "checked": _online.get("checked") or 0, "error": bool(_online.get("error")),
            "auto": _update_auto(cfg), "online": bool(_update_url(cfg)),
            "running": bool(_swu.get("running")), "step": str(_swu.get("step") or "")[:40]}


# 6.0: Farben der runden Displays folgen dem Design (Hintergrundbild bzw. Akzentfarbe)
_ROUND_ACCENTS = {"blue": "#3d8bff", "violet": "#a78bfa", "teal": "#22d3ee", "green": "#34d399", "gold": "#fbbf24",
                  "orange": "#fb923c", "red": "#f87171", "pink": "#f472b6"}
_ROUND_THEMES = {"midnight": ("#0b0d12", "blue"), "oled": ("#000000", "blue"), "aurora": ("#060a13", "teal"),
                 "sunset": ("#120a0e", "orange"), "forest": ("#08100b", "green"), "cinema": ("#0c0909", "red"),
                 "light": ("#0b0d12", "blue"), "auto": ("#0b0d12", "blue")}
_round_walls = {"at": 0, "list": []}
_round_intro = {"seq": 0}


def _round_wallpapers():
    if time.monotonic() - _round_walls["at"] > 300 or not _round_walls["list"]:
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "launcher", "media", "wallpapers.json")
        _round_walls.update(at=time.monotonic(), list=_read_json(path, []) or [])
    return _round_walls["list"]


def _round_palette(cfg):
    if cfg.get("round_colors") == "classic":
        return {"accent": "#57dcc7", "bg": "#050b16", "source": "classic"}
    bg, theme_accent = _ROUND_THEMES.get(cfg.get("theme") or "midnight", _ROUND_THEMES["midnight"])
    accent = _ROUND_ACCENTS.get(cfg.get("accent") or "theme")
    if accent:
        return {"accent": accent, "bg": bg, "source": "accent"}
    background = cfg.get("background") or "wallpaper"
    walls = _round_wallpapers() if background == "wallpaper" else []
    if walls:
        if cfg.get("wallpaper_rotate"):
            day = int((time.time() - time.timezone) // 86400)
            wall = walls[day % len(walls)]
        else:
            wall = next((w for w in walls if w.get("id") == (cfg.get("wallpaper") or "aurora-nordlicht")), walls[0])
        if re.fullmatch(r"#[0-9a-fA-F]{6}", str(wall.get("accent", ""))):
            return {"accent": wall["accent"], "bg": bg, "source": "wallpaper"}
    return {"accent": _ROUND_ACCENTS[theme_accent], "bg": bg, "source": "theme"}


def round_intro_play(_data):
    _round_intro["seq"] += 1
    return {"ok": True}


GET_ROUTES["/api/round-display"] = round_display_state
POST_ROUTES["/api/round-display/intro"] = round_intro_play


# Protokoll der Hintergrund-Musik (Erweiterung → /var/log/raspi-tv/spotify-bg.log)
SPOTIFY_BG_LOG = "/var/log/raspi-tv/spotify-bg.log"


def spotify_bglog(query, headers):
    if headers.get("X-Raspi-TV") != "1":
        raise _err("forbidden", 403)
    try:
        e = json.loads((query.get("e") or ["{}"])[0])
    except ValueError:
        e = {}
    if not isinstance(e, dict):
        e = {}
    line = time.strftime("%Y-%m-%d %H:%M:%S ") + " ".join(
        f"{k}={str(v)[:120]}" for k, v in list(e.items())[:8]) + f" tv={T['tv_power']()}\n"
    try:
        os.makedirs(os.path.dirname(SPOTIFY_BG_LOG), exist_ok=True)
        if os.path.exists(SPOTIFY_BG_LOG) and os.path.getsize(SPOTIFY_BG_LOG) > 200_000:
            os.replace(SPOTIFY_BG_LOG, SPOTIFY_BG_LOG + ".1")
        with open(SPOTIFY_BG_LOG, "a") as f:
            f.write(line)
    except OSError:
        pass
    return {"ok": True}


QUERY_ROUTES["/api/spotify/bglog"] = spotify_bglog
