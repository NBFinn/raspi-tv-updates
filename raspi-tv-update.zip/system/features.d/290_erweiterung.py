# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Raspi-TV-Erweiterung im Browser überwachen
#   Die Erweiterung meldet sich alle 30 s mit ihrer Version. Läuft nach einem Update noch die
#   alte Version, zeigt der Status die Abweichung. Laufende Musik wird nicht neu gestartet.
#   Ohne Meldung weiß die Oberfläche, dass Hintergrund-Apps (Spotify) gerade nicht gehen.
# ==========================================================================
_ext = {"version": None, "at": 0, "restarted": 0}
EXT_MANIFEST = "/opt/raspi-tv/extension/manifest.json"


def _ext_disk_version():
    try:
        with open(EXT_MANIFEST) as f:
            return json.load(f).get("version")
    except (OSError, ValueError):
        return None


def ext_hello(query, headers):
    if headers.get("X-Raspi-TV") != "1":
        raise _err("forbidden", 403)
    _ext.update(version=str((query.get("v") or [""])[0])[:20] or None, at=time.time())
    return {"ok": True}


def ext_status():
    age = time.time() - _ext["at"] if _ext["at"] else None
    disk = _ext_disk_version()
    return {"version": _ext["version"], "disk_version": disk, "seen_ago": int(age) if age is not None else None,
            "ok": age is not None and age < 90 and (not disk or _ext["version"] == disk)}


QUERY_ROUTES["/api/ext/hello"] = ext_hello
GET_ROUTES["/api/ext"] = ext_status
