# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# Handy-App 1.6: Mini-Player (Spotify und Radio) – auch per Bluetooth
#   Zustand: Spotify meldet die Erweiterung (/api/spotify/webnow), Radio die Startseite.
#   Befehle holt die Erweiterung mit der Navigations-Abfrage ab (alle 0,7 s).
# ==========================================================================
_radio_now = {"now": None, "at": 0}
_web_media = {}
_web_media_lock = threading.Lock()


def media_webnow(query, headers):
    """Erweiterung: was in YouTube, Mediatheken, Netflix … gerade läuft."""
    if headers.get("X-Raspi-TV") != "1":
        raise _err("forbidden", 403)
    try:
        n = json.loads((query.get("d") or ["null"])[0])
    except ValueError:
        n = None
    if not isinstance(n, dict) or type(n.get("tab")) is not int or n["tab"] < 0:
        raise _err("Ungültige Medienmeldung")
    with _web_media_lock:
        cutoff = time.time() - 20
        for tab in list(_web_media):
            if _web_media[tab]["at"] < cutoff:
                del _web_media[tab]
        if n.get("title"):
            cover = str(n.get("cover") or "")
            _web_media[n["tab"]] = {"at": time.time(), "now": {
                "tab": n["tab"], "title": str(n["title"])[:120], "artist": str(n.get("artist") or "")[:80],
                "cover": cover if cover.startswith("https://") else "", "playing": bool(n.get("playing")),
                "site": str(n.get("site") or "")[:40]}}
            while len(_web_media) > 32:
                del _web_media[min(_web_media, key=lambda tab: _web_media[tab]["at"])]
        else:
            _web_media.pop(n["tab"], None)
    return {"ok": True}


QUERY_ROUTES["/api/media/webnow"] = media_webnow
_media_cmds = []
_media_cmd_lock = threading.Lock()


def radio_now_report(data):
    if data.get("name"):
        logo = str(data.get("logo") or "")
        _radio_now.update(at=time.time(), now={"title": str(data["name"])[:80],
                                               "artist": "Radio · " + (str(data.get("genre") or "")[:60] or "Live"),
                                               "cover": logo if logo.startswith(("https://", "http://", "/")) else "",
                                               "playing": data.get("state") in ("playing", "loading")})
    else:
        _radio_now.update(at=time.time(), now=None)
    return {"ok": True}


def _pi_volume():
    state = round_display_state()
    return {"level": state["volume"], "muted": state["muted"]} if state["target"] == "pi" else None


def remote_media(_data=None):
    """Was gerade läuft – zuerst, was tatsächlich spielt (Spotify, Video im Browser, Radio), sonst Pausiertes."""
    t = time.time()
    cands = []
    if _webnow["now"] and t - _webnow["at"] < 20:
        cands.append(("spotify", _webnow["now"]))
    with _web_media_lock:
        cands.extend(("web", report["now"]) for report in sorted(_web_media.values(), key=lambda r:r["at"], reverse=True)
                     if t - report["at"] < 20)
    if _radio_now["now"] and t - _radio_now["at"] < 600:
        cands.append(("radio", _radio_now["now"]))
    playing = [c for c in cands if c[1].get("playing")]
    src, now = (playing or cands or [(None, None)])[0]
    ext = ext_status()
    out = {"source": src, "volume": None, "target": _volume_target(), "ext_ok": ext["ok"]}
    if now and src == "web":
        out["site"] = now.get("site")
        out["tab"] = now["tab"]
    if now:
        cover = now.get("cover") or ""
        if cover.startswith("/"):
            cover = ""     # Senderlogos vom Pi kennt das Handy nicht über Bluetooth
        out.update(title=now.get("title"), artist=now.get("artist"), cover=cover, playing=bool(now.get("playing")))
    try:
        out["volume"] = _pi_volume()
    except Exception:  # noqa: BLE001
        pass
    return out


def remote_media_ctl(data):
    cmd = data.get("cmd")
    if cmd not in ("toggle", "next", "previous"):
        raise _err("Ungültig")
    st = remote_media()
    target = data.get("source") or st["source"] or "spotify"
    if target not in ("spotify", "radio", "web"):
        raise _err("Ungültig")
    if target == "web" and (st["source"] != "web" or "tab" not in st):
        raise _err("Das Video ist nicht mehr verfügbar.")
    with _media_cmd_lock:
        _media_cmds.append({"target": target, "cmd": cmd, "at": time.time(), "tab": st.get("tab")})
        del _media_cmds[:-5]
    touch_activity()
    return remote_media()


_nav_pending_media = nav_pending


def nav_pending(query, headers):  # noqa: F811
    out = _nav_pending_media(query, headers)
    now = time.time()
    with _media_cmd_lock:
        _media_cmds[:] = [c for c in _media_cmds if now - c["at"] < 10]
        if _media_cmds:
            c = _media_cmds.pop(0)
            out["media"] = {"target": c["target"], "cmd": c["cmd"]}
            if c["target"] == "web":
                out["media"]["tab"] = c["tab"]
    return out


QUERY_ROUTES["/api/nav/pending"] = nav_pending
POST_ROUTES["/api/radio/now"] = radio_now_report
REMOTE_ROUTES_EXTRA["/r/media"] = remote_media
REMOTE_ROUTES_EXTRA["/r/media/ctl"] = remote_media_ctl


# ==========================================================================
# „Teilen → Raspi-TV“ aus der Android-App: Link am Fernseher öffnen
# ==========================================================================
_URL_RE = re.compile(r"https?://[^\s<>\"']+")


def _open_target(text):
    """(Adresse, Beschreibung) für einen geteilten Text."""
    m = _URL_RE.search(text or "")
    if not m:
        q = (text or "").strip()[:100]
        if not q:
            raise _err("Nichts zum Öffnen")
        return SEARCH_TARGETS["youtube"](q), "YouTube-Suche"
    url = m.group(0).rstrip(".,;)!?")
    u = urlparse(url)
    host = (u.hostname or "").lower()
    if host in ("youtu.be",):
        vid = u.path.strip("/").split("/")[0]
        t = parse_qs(u.query).get("t", [""])[0]
        return f"https://www.youtube.com/watch?v={quote(vid)}" + (f"&t={quote(t)}" if t else ""), "YouTube"
    if host == "youtube.com" or host.endswith(".youtube.com"):
        if u.path.startswith("/shorts/"):
            return "https://www.youtube.com/watch?v=" + quote(u.path.split("/")[2]), "YouTube"
        return url.replace("://m.youtube.com", "://www.youtube.com"), "YouTube"
    if host == "open.spotify.com" or host == "spotify.link":
        return url, "Spotify"
    for name, part in (("Netflix", "netflix."), ("ARD Mediathek", "ardmediathek."), ("ZDF", "zdf."), ("ARTE", "arte."),
                       ("Twitch", "twitch."), ("Prime Video", "primevideo."), ("Disney+", "disneyplus.")):
        if part in host:
            return url, name
    return url, "Webseite"


def remote_open(data):
    url, what = _open_target(str(data.get("text") or data.get("url") or "")[:2000])
    touch_activity()
    if T["tv_power"]() == "standby":
        try:
            cec_action({"action": "tv_on"})
        except Exception:  # noqa: BLE001
            pass
    request_nav(url)
    return {"ok": True, "url": url, "what": what}


REMOTE_ROUTES_EXTRA["/r/open"] = remote_open
