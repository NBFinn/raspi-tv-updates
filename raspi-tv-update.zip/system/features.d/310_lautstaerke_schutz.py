# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 6.3.1: Lautstärke-Schutz
#   Wird der Fernseher ausgeschaltet, verschwindet der HDMI-Tonausgang. PipeWire weicht dann auf
#   einen Ersatzausgang aus (oder setzt den HDMI-Ausgang beim Wiederkommen neu), der mit 100 %
#   startet. Ein solcher Sprung auf 100 %, den niemand ausgelöst hat, wird sofort auf den letzten
#   Wert zurückgesetzt; Anzeige (runde Displays, Handy-App) zeigt solange den gemerkten Wert.
# ==========================================================================
_vol_guard = {"saved": {}, "last": None, "user_at": 0.0, "dummy": False, "shown": None, "fixed": 0}


def _sink_now():
    _, info, _ = T["as_tv"](["wpctl", "inspect", "@DEFAULT_AUDIO_SINK@"], 5)
    name = re.search(r'node\.name = "([^"]*)"', info or "")
    desc = re.search(r'node\.description = "([^"]*)"', info or "")
    _, out, _ = T["as_tv"](["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"], 5)
    vol = re.search(r"Volume:\s*([0-9.]+)", out or "")
    return (name.group(1) if name else ""), (desc.group(1) if desc else ""), (float(vol.group(1)) if vol else None)


def _sink_is_dummy(name, desc):
    return not name or name.startswith("auto_null") or "dummy" in desc.lower()


def volume_guard_step(now=None):
    now = now or time.time()
    name, desc, vol = _sink_now()
    g = _vol_guard
    if vol is None:
        return
    if _sink_is_dummy(name, desc):
        g["dummy"] = True
        return
    saved = g["saved"].get(name)
    user = now - g["user_at"] < 15
    if (saved is not None and vol >= 0.99 and saved < 0.9 and not user):
        T["as_tv"](["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", f"{saved:.2f}"], 5)
        g["fixed"] += 1
        print(f"Lautstärke-Schutz: {name} sprang auf 100 % – zurück auf {round(saved * 100)} %", flush=True)
        vol = saved
    g["saved"][name] = vol
    g["last"], g["dummy"], g["shown"] = name, False, round(vol * 100)


def volume_guard_loop():
    while True:
        try:
            volume_guard_step()
        except Exception:  # noqa: BLE001
            pass
        time.sleep(2)


def _guard_mark_user():
    _vol_guard["user_at"] = time.time()


_old_volume_631 = volume


def volume(data):  # noqa: F811
    _guard_mark_user()
    r = _old_volume_631(data)
    _guard_mark_user()
    return r


POST_ROUTES["/api/volume"] = volume
_old_pi_volume_set_631 = _pi_volume_set


def _pi_volume_set(v):  # noqa: F811
    _guard_mark_user()
    _old_pi_volume_set_631(v)


_old_round_state_631 = round_display_state


def round_display_state():  # noqa: F811
    st = _old_round_state_631()
    # Ersatzausgang (Fernseher aus): letzten echten Wert zeigen statt 100 %
    if _vol_guard["dummy"] and _vol_guard["shown"] is not None and st.get("target") == "pi":
        st["volume"] = _vol_guard["shown"]
    return st


GET_ROUTES["/api/round-display"] = round_display_state
_old_start13 = start_background


def start_background():  # noqa: F811
    _old_start13()
    threading.Thread(target=volume_guard_loop, daemon=True).start()
REMOTE_ROUTES_EXTRA["/r/volume"] = volume


def _audio_set_marked(data):
    _guard_mark_user()
    return T["audio_set"](data)


POST_ROUTES["/api/audio"] = _audio_set_marked
