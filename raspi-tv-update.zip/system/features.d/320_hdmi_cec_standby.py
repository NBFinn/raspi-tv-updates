# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 6.4: HDMI-Signal im Standby abschalten
#   Viele Fernseher (z. B. ältere Medion) nehmen den CEC-Aus-Befehl nicht an, gehen aber nach
#   einigen Minuten ohne Bildsignal selbst in Standby. Raspi-TV schaltet deshalb im Standby das
#   Bild (DPMS) ab. Jede Taste – Fernbedienung, Handy-App, iPhone – oder das Einschalten über
#   Raspi-TV bringt das Bild sofort zurück. Abschaltbar: Einstellungen · Energie.
# ==========================================================================
def _x(cmd):
    return T["as_tv"](["env", "DISPLAY=:0", f"XAUTHORITY=/home/{T['TV_USER']}/.Xauthority"] + cmd, 10)


_signal = {"off": False}


def hdmi_signal(on):
    _signal["off"] = not on
    if on:
        _x(["xset", "dpms", "force", "on"])
        _x(["xset", "-dpms"])            # keine automatische Bildabschaltung im Betrieb
    else:
        _x(["xset", "+dpms"])
        _x(["xset", "dpms", "0", "0", "0"])
        _x(["xset", "dpms", "force", "off"])


def _signal_off_wanted():
    return _cfg().get("standby_signal_off", True) is not False


def _install_signal_hooks():
    std0 = T["tv_standby"]

    def tv_standby_signal():
        r = std0()
        if _signal_off_wanted():
            # kurz warten, damit der CEC-Befehl (falls der Fernseher ihn doch kann) noch durchgeht
            threading.Timer(2, lambda: hdmi_signal(False)).start()
        return r

    T["tv_standby"] = tv_standby_signal


_old_set_tv_power_64 = _set_tv_power


def _set_tv_power(state):  # noqa: F811
    _old_set_tv_power_64(state)
    if state == "on":
        threading.Thread(target=hdmi_signal, args=(True,), daemon=True).start()


_old_cec_action_64 = cec_action


def cec_action(data):  # noqa: F811
    if data.get("action") == "tv_on":
        threading.Thread(target=hdmi_signal, args=(True,), daemon=True).start()
    elif data.get("action") == "tv_off" and _signal_off_wanted():
        try:
            r = _old_cec_action_64(data)
        except Exception:  # noqa: BLE001 – Fernseher ohne CEC-Aus: trotzdem Bild abschalten
            r = {"ok": True, "signal_off": True}
        _set_tv_power("standby")
        threading.Timer(2, lambda: hdmi_signal(False)).start()
        return r
    return _old_cec_action_64(data)


POST_ROUTES["/api/cec/action"] = cec_action
REMOTE_ROUTES_EXTRA["/r/cec"] = lambda d: cec_action(d) if d.get("action") in ("tv_on", "tv_off", "switch") else {"ok": False}
_old_start14 = start_background


def start_background():  # noqa: F811
    _install_signal_hooks()
    _old_start14()

def _activity_key(data=None):
    # Taste am Fernseher gedrückt, während das Bild aus ist: X schaltet das Bild selbst ein –
    # Zustand nachziehen. (Nur echte Tasten, nicht das Abfragen der Handy-App.)
    if _signal["off"]:
        _signal["off"] = False
        _set_tv_power("on")
    return touch_activity(data)


OPEN_POST_ROUTES["/api/activity"] = _activity_key


# ==========================================================================
# 6.4: Ein/Aus über HDMI-CEC für neue und ältere Fernseher
#   Mehrere Varianten nacheinander: direkt an den Fernseher, an alle Geräte (Broadcast), „Text View
#   On“ für ältere Geräte und „Active Source“ (manche Fernseher wachen nur damit auf). Fehlt der
#   Kernel-CEC-Anschluss (/dev/cec*), wird cec-client (libcec) versucht. Klappt Aus trotzdem nicht,
#   schaltet Raspi-TV das Bildsignal ab (siehe oben).
# ==========================================================================
def _cec_client(cmd):
    if not shutil.which("cec-client"):
        return False
    try:
        r = subprocess.run(["cec-client", "-s", "-d", "1"], input=cmd + "\n", capture_output=True, text=True, timeout=15)
        return r.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def _cec_try(variants):
    ok = False
    for args in variants:
        try:
            _cec(args, check=True)
            ok = True
        except Exception:  # noqa: BLE001
            continue
    return ok


def _cec_tv_on():
    if not _cec_dev():
        return _cec_client("on 0") and (_cec_client("as") or True)
    ok = _cec_try([["--to", "0", "--image-view-on"], ["--to", "0", "--text-view-on"]])
    try:
        pa = _phys_addr()
        if pa and pa != "f.f.f.f":
            _cec(["--to", "15", "--active-source", f"phys-addr={pa}"])
    except Exception:  # noqa: BLE001
        pass
    return ok


def _cec_tv_off():
    if not _cec_dev():
        return _cec_client("standby 0")
    return _cec_try([["--to", "0", "--standby"], ["--to", "15", "--standby"]])


_old_cec_action_64b = _old_cec_action_64


def _old_cec_action_64(data):  # noqa: F811 – Grundfunktion für den Bildsignal-Wrapper oben
    a = data.get("action")
    if a == "tv_on":
        if not _cec_tv_on():
            raise _err("Der Fernseher antwortet nicht. Ist HDMI-CEC am Fernseher eingeschaltet?")
        return {"ok": True}
    if a == "tv_off":
        ok = _cec_tv_off()
        _set_tv_power("standby")
        if not ok:
            raise _err("Der Fernseher nimmt den Aus-Befehl nicht an.")
        return {"ok": True}
    return _old_cec_action_64b(data)


def _install_cec_standby():
    def tv_standby_variants():
        try:
            _cec_tv_off()
        except Exception:  # noqa: BLE001
            pass
        return {"ok": True}
    T["tv_standby"] = tv_standby_variants


_old_start15 = start_background


def start_background():  # noqa: F811
    _install_cec_standby()      # zuerst: der Bildsignal-Haken (start14) baut darauf auf
    _old_start15()


# 7.0: Anschlussart der runden Displays (Teensy 4.1 per USB oder GPIO) für die Einstellungen
def round_hardware(_q=None, _h=None):
    st = _read_json("/var/lib/raspi-tv-round/teensy.json", {}) or {}
    if st.get("connected"):
        return {"mode": "teensy", "firmware": st.get("firmware", ""), "port": st.get("port", ""),
                "flashing": st.get("flashing", ""), "resets": st.get("resets", 0), "crash": st.get("crash", ""),
                "reset": st.get("reset", ""), "power": st.get("power")}
    scan = _read_json("/var/lib/raspi-tv-round/teensy-scan.json", {}) or {}
    return {"mode": "gpio" if os.path.exists("/var/lib/raspi-tv-round/enabled-separate-pins") else "none",
            "scan": {"halfkay": scan.get("halfkay", ""), "ports": scan.get("ports", []), "port": scan.get("port", ""),
                     "fresh": time.time() - scan.get("at", 0) < 30}}


GET_ROUTES["/api/round-displays/hardware"] = round_hardware
