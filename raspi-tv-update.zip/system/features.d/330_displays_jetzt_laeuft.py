# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.0.2: Runde Displays zeigen alles, was gerade läuft – nicht nur Spotify Connect
#   Gleiche Quellen wie die Handy-App: Spotify (Connect/ncspot und Web-Player), Videos im Browser
#   (YouTube, Mediatheken …) und Radio. Vorher kam nur an, was die Startseite gerade meldete.
# ==========================================================================
_SITE_LABELS = {"youtube": "YOUTUBE", "netflix": "NETFLIX", "ard": "ARD", "zdf": "ZDF", "arte": "ARTE",
                "twitch": "TWITCH", "prime": "PRIME VIDEO", "disney": "DISNEY+", "spotify": "SPOTIFY"}


def _now_playing():
    t = time.time()
    cands = []
    sp = spotify_now()
    if sp.get("title") and (sp.get("playing") or sp.get("paused")):
        cands.append(("SPOTIFY", sp))
    if _webnow["now"] and t - _webnow["at"] < 20:
        cands.append(("SPOTIFY", _webnow["now"]))
    with _web_media_lock:
        for report in sorted(_web_media.values(), key=lambda r: r["at"], reverse=True):
            if t - report["at"] < 20:
                site = str(report["now"].get("site") or "").lower()
                label = next((v for k, v in _SITE_LABELS.items() if k in site), (site.upper()[:14] or "VIDEO"))
                cands.append((label, report["now"]))
    if _radio_now["now"] and t - _radio_now["at"] < 600:
        cands.append(("RADIO", _radio_now["now"]))
    playing = [c for c in cands if c[1].get("playing")]
    label, now = (playing or cands or [(None, None)])[0]
    if not now:
        return {"playing": False}
    cover = str(now.get("cover") or "")
    if cover.startswith("/"):
        cover = "http://127.0.0.1:8765" + cover     # Senderlogo vom Pi selbst
    return {"playing": bool(now.get("playing")), "paused": not now.get("playing"),
            "title": str(now.get("title") or "")[:120], "artist": str(now.get("artist") or "")[:120],
            "cover": cover, "source": label}


_old_round_state_702 = round_display_state


def round_display_state():  # noqa: F811
    st = _old_round_state_702()
    try:
        st["music"] = _now_playing()
    except Exception:  # noqa: BLE001
        pass
    try:
        st["tv"] = T["tv_power"]()      # 'standby' → Nachtmodus auf den runden Displays
    except Exception:  # noqa: BLE001
        pass
    return st


GET_ROUTES["/api/round-display"] = round_display_state


def round_teensy_flash(_data=None):
    """Einstellungen: Teensy-Firmware erneut einspielen (der Display-Dienst übernimmt das)."""
    os.makedirs("/var/lib/raspi-tv-round", exist_ok=True)
    with open("/var/lib/raspi-tv-round/teensy-force-flash", "w") as f:
        f.write(str(int(time.time())))
    T["run"](["systemctl", "restart", "raspi-tv-round.service"], 15)
    return {"ok": True}


POST_ROUTES["/api/round-displays/teensy-flash"] = round_teensy_flash
