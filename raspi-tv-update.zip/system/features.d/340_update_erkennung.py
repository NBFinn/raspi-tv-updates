# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.1.4: Updates schneller erkennen
#   Statt alle 6 Stunden das ganze Paket zu laden, liest Raspi-TV alle 10 Minuten nur die kleine
#   Datei version.json neben dem Paket. Bei GitHub über die API – die liefert neue Versionen sofort
#   (raw.githubusercontent.com hält alte Dateien bis zu 5 Minuten im Zwischenspeicher).
#   Das Paket selbst wird erst beim Installieren geladen.
# ==========================================================================
_GH_RAW = re.compile(r"^https://raw\.githubusercontent\.com/([^/]+)/([^/]+)/([^/]+)/(.+)$")


def _gh_api(url):
    m = _GH_RAW.match(url)
    if not m:
        return None
    owner, repo, ref, path = m.groups()
    return f"https://api.github.com/repos/{owner}/{repo}/contents/{path}?ref={ref}"


def _fetch(url, limit, timeout, raw_api=False):
    headers = {"User-Agent": "Raspi-TV/1.0", "Cache-Control": "no-cache"}
    if raw_api:
        headers["Accept"] = "application/vnd.github.raw"
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise RuntimeError("Datei zu groß")
    return data


def _quick_latest(url):
    """Version aus version.json neben dem Paket (None, wenn es keine gibt)."""
    side = url.rsplit("/", 1)[0] + "/version.json"
    for candidate, api in ((_gh_api(side), True), (side, False)):
        if not candidate:
            continue
        try:
            info = json.loads(_fetch(candidate, 4096, 15, api))
            ver = str(info.get("version", "")).strip()
            if re.fullmatch(r"[0-9][0-9.]{0,18}", ver):
                return ver
        except Exception:  # noqa: BLE001
            continue
    return None


def _online_fetch():  # noqa: F811 – Paket laden (bei GitHub über die API, immer die neueste Fassung)
    url = _update_url(_cfg())
    if not url:
        raise RuntimeError("Keine Update-Adresse eingetragen.")
    api = _gh_api(url)
    try:
        data = _fetch(api, 80_000_000, 300, True) if api else _download(url, limit=80_000_000, timeout=180)
    except Exception:  # noqa: BLE001 – API nicht erreichbar/Limit: normaler Download
        data = _download(url, limit=80_000_000, timeout=180)
    os.makedirs(os.path.dirname(ONLINE_ZIP), exist_ok=True)
    with open(ONLINE_ZIP + ".tmp", "wb") as f:
        f.write(data)
    os.replace(ONLINE_ZIP + ".tmp", ONLINE_ZIP)
    with zipfile.ZipFile(ONLINE_ZIP) as zf:
        names = _zip_names(zf)
        root = _zip_root([n for _, n in names])
        if root is None:
            raise RuntimeError("Unter der Adresse liegt kein Raspi-TV-Update-Paket.")
        ver = next((zf.read(i).decode("utf-8", "replace").strip()[:20] for i, n in names if n == root + "VERSION"), None)
    if not ver:
        raise RuntimeError("Update-Paket ohne Versionsnummer.")
    _online["zip_version"] = ver
    return ver


def online_check(_data=None):  # noqa: F811
    if _online["busy"]:
        return online_status()
    _online["busy"] = True
    try:
        url = _update_url(_cfg())
        quick = _quick_latest(url) if url else None
        _online.update(latest=quick or _online_fetch(), error=None)
    except zipfile.BadZipFile:
        _online.update(latest=None, error="Unter der Adresse liegt keine Zip-Datei.")
    except Exception as e:  # noqa: BLE001
        _online.update(latest=None, error=str(e) if isinstance(e, RuntimeError) else "Update-Adresse nicht erreichbar.")
    finally:
        _online.update(busy=False, checked=time.time())
    return online_status()


def online_install(_data=None):  # noqa: F811
    if _swu["running"]:
        return online_status()
    st = online_check()
    if not st["latest"]:
        raise _err(st["error"] or "Kein Update gefunden.")
    if not st["newer"]:
        raise _err(f"Raspi-TV ist aktuell (Version {st['installed']}).")
    try:
        ver = _online_fetch()           # jetzt erst das Paket laden
    except Exception as e:  # noqa: BLE001
        raise _err(str(e) if isinstance(e, RuntimeError) else "Update-Paket konnte nicht geladen werden.")
    if _ver_tuple(ver) <= _ver_tuple(_installed_version()):
        raise _err("Das Update-Paket ist noch nicht verfügbar – bitte in ein paar Minuten noch einmal versuchen.")
    _swu.update(running=True, done=False, error=None, step="Wird vorbereitet", version=ver)
    threading.Thread(target=_swupdate_worker, args=(ONLINE_ZIP,), daemon=True).start()
    return online_status()


def online_loop():  # noqa: F811
    """Alle 10 Minuten nachsehen (kleine Datei), installiert auf Wunsch nachts zwischen 3 und 5 Uhr."""
    time.sleep(45)
    while True:
        try:
            cfg = _cfg()
            if _update_url(cfg) and time.time() - _online["checked"] > 600:
                online_check()
            h = datetime.now().hour
            if (_update_auto(cfg) and 3 <= h < 5 and _online["latest"] and not _swu["running"]
                    and _ver_tuple(_online["latest"]) > _ver_tuple(_installed_version())
                    and T["tv_power"]() != "on"):
                online_install()
        except Exception:  # noqa: BLE001
            pass
        time.sleep(60)


POST_ROUTES["/api/online-update/check"] = online_check
POST_ROUTES["/api/online-update/install"] = online_install
