# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.1.6: Die Handy-App aktualisiert sich über Raspi-TV (auch nur per Bluetooth)
#   /r/app-info   → Version der mitgelieferten App (launcher/raspi-tv-remote.apk.json) und Prüfsummen
#   /r/app-chunk  → Stück der App bzw. der Oberfläche (remote.html) als Base64, höchstens 3 KB
#   Neue Oberfläche: die App übernimmt sie sofort; neue App: Android fragt einmal „Installieren?“
# ==========================================================================
_APP_FILES = {"apk": "raspi-tv-remote.apk", "ui": "remote.html"}
_app_cache = {}


def _app_file(what):
    name = _APP_FILES.get(str(what))
    if not name:
        raise _err("Unbekannte Datei", 404)
    full = os.path.join(T["ROOT"], name)
    mtime = os.path.getmtime(full)
    hit = _app_cache.get(name)
    if not hit or hit[0] != mtime:
        with open(full, "rb") as f:
            raw = f.read()
        hit = (mtime, raw, hashlib.sha256(raw).hexdigest())
        _app_cache[name] = hit
    return hit[1], hit[2]


def remote_app_info(_data=None):
    meta = _read_json(os.path.join(T["ROOT"], "raspi-tv-remote.apk.json"), {}) or {}
    out = {"code": int(meta.get("code") or 0), "name": str(meta.get("name") or "")}
    for what in _APP_FILES:
        try:
            raw, sha = _app_file(what)
            out[what] = {"size": len(raw), "sha256": sha}
        except OSError:
            pass
    return out


def remote_app_chunk(data):
    import base64
    raw, sha = _app_file(data.get("what"))
    try:
        off = max(0, int(data.get("off", 0)))
        # App 1.10+ advances by the actual decoded length. Small complete lines
        # leave room for heartbeats on slow RFCOMM links (1.11 watchdog: 13 s).
        size = min(3072, max(1, int(data.get("len", 3072))))
    except (TypeError, ValueError):
        raise _err("Ungültiger Bereich")
    return {"off": off, "total": len(raw), "sha256": sha, "b64": base64.b64encode(raw[off:off + size]).decode()}


REMOTE_ROUTES_EXTRA["/r/app-info"] = remote_app_info
REMOTE_ROUTES_EXTRA["/r/app-chunk"] = remote_app_chunk
