# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.2.0: Uhren und VU-Meter auf den runden Displays, Nachtlautstärke, sanftes Ausblenden,
#        Rückmeldung bei Musikbefehlen, Schnellaktionen, Prüfung nach Updates
# ==========================================================================
_round_state_72 = round_display_state


def round_display_state():  # noqa: F811
    st = _round_state_72()
    cfg = _cfg()
    st["clock"] = cfg.get("round_clock") if cfg.get("round_clock") in (0, 1, 2, 3) else 0
    st["vu"] = cfg.get("round_vu") if cfg.get("round_vu") in (0, 1, 2) else 0
    return st


GET_ROUTES["/api/round-display"] = round_display_state
