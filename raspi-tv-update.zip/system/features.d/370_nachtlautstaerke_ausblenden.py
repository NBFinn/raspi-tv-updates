# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ---- Nachtlautstärke: zwischen zwei Uhrzeiten wird der Ton des Pi auf einen Höchstwert begrenzt
def _night_cfg():
    n = _cfg().get("night_volume") or {}
    return {"on": bool(n.get("on")), "from": n.get("from", "22:00"), "to": n.get("to", "07:00"),
            "max": n.get("max", 30) if type(n.get("max", 30)) is int else 30}


def night_active(now=None, cfg=None):
    n = cfg or _night_cfg()
    if not n["on"]:
        return False
    t = time.localtime(now or time.time())
    cur = t.tm_hour * 60 + t.tm_min
    a, b = (int(x[:2]) * 60 + int(x[3:]) for x in (n["from"], n["to"]))
    return a <= cur < b if a < b else (cur >= a or cur < b) if a != b else False


def night_volume_step():
    n = _night_cfg()
    if not night_active(cfg=n) or _volume_target() != "pi" or _fade["active"]:
        return False
    vol = _pi_volume_get()
    if vol > n["max"]:
        _pi_volume_set(n["max"])
        return True
    return False


# ---- Schlaf-Timer: in der letzten Minute wird die Musik langsam leiser (danach wieder wie vorher)
_fade = {"active": False, "start": None}


def _fade_volume(left, start, span=60):
    """Lautstärke für „left“ Sekunden vor dem Ausschalten: von start sanft auf 10 % davon."""
    k = max(0.0, min(1.0, left / span))
    return max(1, round(start * (0.1 + 0.9 * k * k * (3 - 2 * k))))


def sleep_loop():  # noqa: F811 – ersetzt die 10-Sekunden-Schleife (wird beim Start über den Namen gestartet)
    tick = 0
    while True:
        time.sleep(1)
        tick += 1
        try:
            until = _sleep["until"]
            left = until - time.time() if until else None
            fade = _cfg().get("sleep_fade", True) is not False and _volume_target() == "pi"
            if left is not None and 0 < left <= 60 and fade:
                if not _fade["active"]:
                    _fade.update(active=True, start=_pi_volume_get())
                _pi_volume_set(_fade_volume(left, _fade["start"]))
            elif _fade["active"] and left is None:
                # Timer wurde abgebrochen: Lautstärke zurück
                _pi_volume_set(_fade["start"])
                _fade.update(active=False, start=None)
            if until and time.time() >= until:
                _sleep["until"] = 0
                T["tv_standby"]()
                _set_tv_power("standby")
                touch_activity()
                if _fade["active"]:
                    time.sleep(4)                    # erst nach dem Ausschalten wieder auf den alten Wert
                    _pi_volume_set(_fade["start"])
                    _fade.update(active=False, start=None)
            if tick % 5 == 0:
                night_volume_step()
        except Exception:  # noqa: BLE001 – Hintergrundschleife darf nie sterben
            pass


def night_status():
    n = _night_cfg()
    n["active"] = night_active(cfg=n)
    n["fade"] = _cfg().get("sleep_fade", True) is not False
    return n


GET_ROUTES["/api/night-volume"] = night_status
