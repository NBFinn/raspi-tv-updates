# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ---- Rückmeldung bei Musikbefehlen: erst „ok“, wenn der Fernseher den Befehl wirklich abgeholt hat
_media_ctl_72 = remote_media_ctl
_nav_pending_72 = nav_pending
_nav_seen = {"at": 0.0}


def nav_pending(query, headers):  # noqa: F811
    _nav_seen["at"] = time.time()
    return _nav_pending_72(query, headers)


QUERY_ROUTES["/api/nav/pending"] = nav_pending


def _media_cmd_waiting(stamp):
    with _media_cmd_lock:
        return any(c["at"] == stamp for c in _media_cmds)


def remote_media_ctl(data):  # noqa: F811
    cmd = data.get("cmd")
    before = remote_media()
    if time.time() - _nav_seen["at"] > 20:
        raise _err("Der Browser am Fernseher antwortet nicht – läuft Raspi-TV gerade (kein Standby, keine andere App im Vollbild)?", 503)
    out = _media_ctl_72(data)
    with _media_cmd_lock:
        stamp = _media_cmds[-1]["at"] if _media_cmds else None
    end = time.time() + 2.5
    while stamp and _media_cmd_waiting(stamp) and time.time() < end:
        time.sleep(0.1)
    if stamp and _media_cmd_waiting(stamp):
        with _media_cmd_lock:
            _media_cmds[:] = [c for c in _media_cmds if c["at"] != stamp]
        raise _err("Der Fernseher hat den Befehl nicht abgeholt. Bitte noch einmal versuchen.", 503)
    src = out.get("source") or before.get("source")
    if cmd == "next" and src in ("spotify", "radio") and before.get("title"):
        # „Weiter“ gilt erst als ausgeführt, wenn wirklich ein anderer Titel läuft
        end = time.time() + 3.0
        while time.time() < end:
            now = remote_media()
            if now.get("title") != before.get("title") or now.get("artist") != before.get("artist"):
                return now
            time.sleep(0.2)
        raise _err("Spotify hat nicht weitergeschaltet – letzter Titel der Liste, Werbung oder kein Premium?" if src == "spotify"
                   else "Der Sender hat nicht gewechselt.", 409)
    return remote_media()


REMOTE_ROUTES_EXTRA["/r/media/ctl"] = remote_media_ctl
if "REMOTE_ROUTES" in T:
    T["REMOTE_ROUTES"]["/r/media/ctl"] = remote_media_ctl
