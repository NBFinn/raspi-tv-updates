# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ---- Schnellaktionen („Musikabend“): mehrere Schritte auf einen Knopf im Schnellmenü
QUICK_STEPS = {
    "app": lambda v: isinstance(v, str) and re.fullmatch(r"[a-z0-9_-]{1,40}", v) is not None,
    "radio": lambda v: isinstance(v, str) and len(v) <= 80,
    "volume": lambda v: type(v) is int and 0 <= v <= 100,
    "saver": lambda v: isinstance(v, str) and re.fullmatch(r"[a-z0-9-]{0,48}", v) is not None,
    "sleep": lambda v: type(v) is int and v in (15, 30, 60, 90, 120),
    "wallpaper": lambda v: isinstance(v, str) and re.fullmatch(r"[a-z0-9-]{1,48}", v) is not None,
}


def quick_actions_valid(v):
    if not isinstance(v, list) or len(v) > 8:
        return False
    for a in v:
        if not isinstance(a, dict) or set(a) - {"name", "steps"}:
            return False
        name, steps = a.get("name"), a.get("steps")
        if not isinstance(name, str) or not 1 <= len(name.strip()) <= 24 or not isinstance(steps, list) or len(steps) > 6:
            return False
        for s in steps:
            if not isinstance(s, dict) or set(s) != {"type", "value"} or s["type"] not in QUICK_STEPS \
                    or not QUICK_STEPS[s["type"]](s["value"]):
                return False
    return True


def quick_volume(data):
    """Lautstärke direkt setzen (Schritt einer Schnellaktion) – nur für den Ton des Pi."""
    try:
        v = max(0, min(100, int(data.get("volume"))))
    except (TypeError, ValueError):
        raise _err("Ungültige Lautstärke")
    if _volume_target() != "pi":
        raise _err("Die Lautstärke regelt der Fernseher – sie lässt sich nicht fest einstellen.", 409)
    n = _night_cfg()
    if night_active(cfg=n):
        v = min(v, n["max"])
    _pi_volume_set(v)
    _vol_guard["user_at"] = time.time()
    return {"volume": v}


POST_ROUTES["/api/quick/volume"] = quick_volume
