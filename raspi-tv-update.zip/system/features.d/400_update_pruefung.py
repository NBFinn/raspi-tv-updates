# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ---- Prüfung nach Updates: läuft nach dem ersten Start einer neuen Version wirklich alles?
UPDATE_CHECK_FILE = "update-check.json"


def update_check_run(wait=150, sleep=time.sleep):
    ver = _installed_version()
    rec = _read_json(_state(UPDATE_CHECK_FILE), {}) or {}
    if rec.get("version") == ver:
        return rec
    sleep(wait)
    problems = []
    if time.time() - _nav_seen["at"] > 30:
        problems.append("Die Oberfläche am Fernseher meldet sich nicht (Browser nicht gestartet oder eingefroren).")
    else:
        ext = ext_status()
        if not ext["ok"]:
            problems.append("Die Browser-Steuerung (Raspi-TV-Erweiterung) antwortet nicht – Home-Taste, Handy-Befehle "
                            "und Bildschirmtastatur gehen dann nicht."
                            + (f" Geladen ist Version {ext['version']}, erwartet wird {ext['disk_version']}."
                               if ext.get("version") and ext.get("disk_version") and ext["version"] != ext["disk_version"] else ""))
    try:
        hw = round_hardware()
        bundled = T["read_file"]("/opt/raspi-tv/teensy/version").strip()
        if hw.get("mode") == "teensy" and hw.get("firmware") and bundled \
                and _ver_tuple(hw["firmware"]) < _ver_tuple(bundled):
            problems.append(f"Der Teensy hat noch Firmware {hw['firmware']} statt {bundled} – das Einspielen hat nicht geklappt.")
    except Exception:  # noqa: BLE001
        pass
    if not _btr["listening"] and _btr["error"]:
        problems.append("Der Bluetooth-Empfang für die Handy-App ist nicht bereit: " + _btr["error"])
    rec = {"version": ver, "previous": rec.get("version", ""), "at": int(time.time()),
           "problems": problems, "seen": not problems}
    _write_json(_state(UPDATE_CHECK_FILE), rec)
    print("Prüfung nach Update auf", ver + ":", "; ".join(problems) or "alles in Ordnung", flush=True)
    return rec


def update_check_status():
    rec = _read_json(_state(UPDATE_CHECK_FILE), {}) or {}
    return {"version": rec.get("version", ""), "previous": rec.get("previous", ""), "at": rec.get("at", 0),
            "problems": rec.get("problems", []), "seen": bool(rec.get("seen", True))}


def update_check_ack(_data=None):
    rec = _read_json(_state(UPDATE_CHECK_FILE), {}) or {}
    rec["seen"] = True
    _write_json(_state(UPDATE_CHECK_FILE), rec)
    return update_check_status()


GET_ROUTES["/api/update-check"] = update_check_status
POST_ROUTES["/api/update-check/ack"] = update_check_ack
_old_start16 = start_background


def start_background():  # noqa: F811
    _old_start16()

    def run():
        try:
            update_check_run()
        except Exception as e:  # noqa: BLE001
            print("Prüfung nach Update:", e, flush=True)
    threading.Thread(target=run, daemon=True).start()
