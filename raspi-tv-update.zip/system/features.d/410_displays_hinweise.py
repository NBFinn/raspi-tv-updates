# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.3.0: Runde Displays – Wetter, Titel-Fortschritt, TV-Seite, Schlaf-Timer, Hinweise, Seitenwahl;
#        Update mit sichtbarem Download; Sicherung auf USB-Stick; Diagnose-Paket; Strom-Warnung
# ==========================================================================
_round_notice = {"seq": 0, "kind": "i", "title": "", "text": ""}


def round_notify(kind, title, text=""):
    """Kurzer Hinweis auf den runden Displays (kind: i Info, k erledigt, w Warnung, r Aufnahme)."""
    _round_notice.update(seq=_round_notice["seq"] + 1, kind=kind if kind in ("i", "k", "w", "r") else "i",
                         title=str(title)[:38], text=str(text)[:94], at=time.time())
