# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ---- Position und Länge des laufenden Titels (melden Spotify-Tab und Videoseiten über die Erweiterung)
_media_pos = {"spotify": None, "web": {}}
_spotify_webnow_73 = spotify_webnow
_media_webnow_73 = media_webnow


def _pos_from(query):
    try:
        n = json.loads((query.get("d") or ["null"])[0])
        pos, dur = n.get("pos"), n.get("dur")
        if type(pos) in (int, float) and type(dur) in (int, float) and 0 <= pos <= dur and 0 < dur < 86400:
            return {"pos": float(pos), "dur": float(dur), "at": time.time(), "tab": n.get("tab")}
    except (ValueError, AttributeError, TypeError):
        pass
    return None


def spotify_webnow(query, headers):  # noqa: F811
    out = _spotify_webnow_73(query, headers)
    _media_pos["spotify"] = _pos_from(query)
    return out


def media_webnow(query, headers):  # noqa: F811
    out = _media_webnow_73(query, headers)
    p = _pos_from(query)
    if p and type(p["tab"]) is int:
        _media_pos["web"][p["tab"]] = p
        for tab in [t for t, v in _media_pos["web"].items() if time.time() - v["at"] > 30]:
            del _media_pos["web"][tab]
    return out


QUERY_ROUTES["/api/spotify/webnow"] = spotify_webnow
QUERY_ROUTES["/api/media/webnow"] = media_webnow


def _music_position(music):
    """(Position ms, Länge ms) zum gerade gezeigten Titel – None, wenn unbekannt (Radio, Live-Streams)."""
    if not music.get("title"):
        return None
    cand = []
    if music.get("source") == "SPOTIFY" and _media_pos["spotify"]:
        cand.append(_media_pos["spotify"])
    elif music.get("source") not in ("SPOTIFY", "RADIO"):
        cand.extend(sorted(_media_pos["web"].values(), key=lambda v: v["at"], reverse=True)[:1])
    for p in cand:
        if time.time() - p["at"] < 12:
            pos = p["pos"] + (time.time() - p["at"] if music.get("playing") else 0)
            return int(min(pos, p["dur"]) * 1000), int(p["dur"] * 1000)
    return None
