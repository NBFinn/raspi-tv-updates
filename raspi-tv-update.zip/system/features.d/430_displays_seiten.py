# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ---- Schlaf-Timer: Gesamtdauer merken (für den ablaufenden Ring)
_remote_sleep_73 = remote_sleep


def remote_sleep(data):  # noqa: F811
    out = _remote_sleep_73(data)
    _sleep["total"] = (out.get("sleep_left") or 0)
    return out


POST_ROUTES["/api/sleep"] = remote_sleep
REMOTE_ROUTES_EXTRA["/r/sleep"] = remote_sleep

ROUND_PAGES_DEFAULT = (0x37, 0x07)       # Display 1: Uhr/Cover/TV, WLAN, System, Wetter – Display 2: Lautstärke, Status, Updates
_round_state_73 = round_display_state


def round_display_state():  # noqa: F811
    st = _round_state_73()
    cfg = _cfg()
    try:
        w = _weather["data"] if _weather.get("data") and time.time() - _weather["at"] < 3 * 3600 else None
        if w and w.get("temp") is not None:
            day0 = (w.get("days") or [{}])[0]
            st["weather"] = {"temp": round(w["temp"]), "code": int(w.get("code") or 0), "rain": day0.get("rain"),
                             "max": round(day0["max"]) if day0.get("max") is not None else round(w["temp"]),
                             "min": round(day0["min"]) if day0.get("min") is not None else round(w["temp"]),
                             "day": bool(w.get("day", 1)), "place": str(w.get("place") or "")[:26]}
    except Exception:  # noqa: BLE001
        pass
    try:
        pos = _music_position(st.get("music") or {})
        if pos:
            st["music"]["position"], st["music"]["duration"] = pos
    except Exception:  # noqa: BLE001
        pass
    try:
        name = _watching()
        if name:
            now = (epg_now().get(name) or {}).get("now") or {}
            st["channel"] = {"name": name, "title": str(now.get("title") or "")[:90],
                             "start": now.get("start") or 0, "stop": now.get("stop") or 0}
    except Exception:  # noqa: BLE001
        pass
    left = _sleep_left()
    if left:
        st["sleep"] = {"left": left, "total": max(left, int(_sleep.get("total") or 0))}
    try:
        nxt = _wake_next(wake_cfg())
        if nxt and nxt - time.time() < 24 * 3600:
            st["wake"] = time.strftime("%H:%M", time.localtime(nxt))
    except Exception:  # noqa: BLE001
        pass
    pages = cfg.get("round_pages")
    ok = isinstance(pages, list) and len(pages) == 2 and all(type(x) is int for x in pages)
    st["pages"] = list(pages) if ok else list(ROUND_PAGES_DEFAULT)
    st["page_sec"] = cfg.get("round_page_sec") if cfg.get("round_page_sec") in (5, 8, 10, 15, 20, 30, 60) else 10
    if _round_notice["seq"] and time.time() - _round_notice.get("at", 0) < 20:
        st["notice"] = {k: _round_notice[k] for k in ("seq", "kind", "title", "text")}
    return st


GET_ROUTES["/api/round-display"] = round_display_state
