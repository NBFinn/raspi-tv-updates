# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ---- Update: sofort sichtbar – erst Verbindung, dann Download mit Fortschritt, dann Installation
def _download_progress(url, dest, limit, timeout, raw_api, progress):
    headers = {"User-Agent": "Raspi-TV/1.0", "Cache-Control": "no-cache"}
    if raw_api:
        headers["Accept"] = "application/vnd.github.raw"
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r, open(dest, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        got = 0
        while True:
            chunk = r.read(65536)
            if not chunk:
                break
            got += len(chunk)
            if got > limit:
                raise RuntimeError("Datei zu groß")
            f.write(chunk)
            progress(got, total)
    return got


def _online_fetch_progress():
    url = _update_url(_cfg())
    if not url:
        raise RuntimeError("Keine Update-Adresse eingetragen.")
    expected = 0
    try:                                   # Größe aus version.json (GitHub liefert oft keine Länge mit)
        side = url.rsplit("/", 1)[0] + "/version.json"
        info = json.loads(_fetch(_gh_api(side) or side, 4096, 15, bool(_gh_api(side))))
        expected = int(info.get("size") or 0)
    except Exception:  # noqa: BLE001
        pass

    def progress(got, total):
        total = total or expected
        _swu.update(got=got, total=total, pct=min(100, int(got * 100 / total)) if total else None)
        if total:
            # Zehntel-Megabyte – so zeigen es auch die runden Displays („1,2 von 2,1 MB“)
            _swu["step"] = f"Download {round(got / 100000)}/{max(1, round(total / 100000))}"
        else:
            _swu["step"] = f"Download {got / 1e6:.1f} MB"

    os.makedirs(os.path.dirname(ONLINE_ZIP), exist_ok=True)
    tmp = ONLINE_ZIP + ".tmp"
    api = _gh_api(url)
    try:
        _download_progress(api or url, tmp, 80_000_000, 300, bool(api), progress)
    except RuntimeError:
        raise
    except Exception:  # noqa: BLE001 – API nicht erreichbar/Limit: normaler Download
        _download_progress(url, tmp, 80_000_000, 180, False, progress)
    os.replace(tmp, ONLINE_ZIP)
    with zipfile.ZipFile(ONLINE_ZIP) as zf:
        names = _zip_names(zf)
        root = _zip_root([n for _, n in names])
        if root is None:
            raise RuntimeError("Unter der Adresse liegt kein Raspi-TV-Update-Paket.")
        ver = next((zf.read(i).decode("utf-8", "replace").strip()[:20] for i, n in names if n == root + "VERSION"), None)
    if not ver:
        raise RuntimeError("Update-Paket ohne Versionsnummer.")
    _online["zip_version"] = ver
    return ver


def _online_install_worker():
    try:
        st = online_check()
        if not st["latest"]:
            raise RuntimeError(st["error"] or "Kein Update gefunden.")
        if not st["newer"]:
            raise RuntimeError(f"Raspi-TV ist aktuell (Version {st['installed']}).")
        _swu.update(step="Download beginnt", phase="download", version=st["latest"])
        try:
            ver = _online_fetch_progress()
        except RuntimeError:
            raise
        except Exception:  # noqa: BLE001
            raise RuntimeError("Update-Paket konnte nicht geladen werden – Internetverbindung prüfen.")
        if _ver_tuple(ver) <= _ver_tuple(_installed_version()):
            raise RuntimeError("Das Update-Paket ist noch nicht verfügbar – bitte in ein paar Minuten noch einmal versuchen.")
        _swu.update(step="Update wird entpackt", phase="install", pct=None, version=ver)
    except Exception as e:  # noqa: BLE001
        _swu.update(running=False, error=str(e), phase=None, pct=None)
        return
    _swupdate_worker(ONLINE_ZIP)          # entpacken, sichern, installieren (setzt running=False am Ende)


def online_install(_data=None):  # noqa: F811 – antwortet sofort; den Fortschritt zeigt /api/swupdate/status
    if _swu["running"]:
        return online_status()
    _swu.update(running=True, done=False, error=None, step="Verbindung zum Update-Server …", phase="download",
                pct=None, got=0, total=0, version=None)
    threading.Thread(target=_online_install_worker, daemon=True).start()
    return online_status()


POST_ROUTES["/api/online-update/install"] = online_install
