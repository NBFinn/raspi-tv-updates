# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ---- Sicherung auf USB-Stick: automatisch, sobald der gewählte Stick steckt (höchstens einmal am Tag)
AUTO_BACKUP_KEEP = 7


def _auto_backup_cfg():
    a = _cfg().get("auto_backup") or {}
    return {"on": bool(a.get("on")), "name": str(a.get("name") or ""), "size": int(a.get("size") or 0)}


def auto_backup_status():
    a = _auto_backup_cfg()
    rec = _read_json(_state("auto-backup.json"), {}) or {}
    sticks = [{"id": s["id"], "name": s["name"], "size": s.get("size", 0)} for s in media_sources()["sources"] if s["kind"] == "usb"]
    a.update(last=rec.get("at", 0), last_file=rec.get("file", ""), error=rec.get("error", ""), sticks=sticks,
             present=any(s["name"] == a["name"] and s["size"] == a["size"] for s in sticks))
    return a


def auto_backup_step(now=None):
    a = _auto_backup_cfg()
    if not a["on"] or not a["name"]:
        return None
    now = now or time.time()
    rec = _read_json(_state("auto-backup.json"), {}) or {}
    if time.strftime("%Y-%m-%d", time.localtime(rec.get("at", 0))) == time.strftime("%Y-%m-%d", time.localtime(now)):
        return None
    stick = next((s for s in media_sources()["sources"]
                  if s["kind"] == "usb" and s["name"] == a["name"] and s.get("size", 0) == a["size"]), None)
    if not stick:
        return None
    try:
        out = backup_create({"src": stick["id"]})
    except Exception as e:  # noqa: BLE001
        if rec.get("error") != str(e):
            _write_json(_state("auto-backup.json"), dict(rec, error=str(e)))
        return None
    mnt = os.path.join(MEDIA_ROOT, stick["id"])
    try:                                   # alte Sicherungen aufräumen (die neuesten bleiben)
        old = sorted(n for n in os.listdir(mnt) if BACKUP_NAME_RE.match(n))[:-AUTO_BACKUP_KEEP]
        if old and T["run"](["mount", "-o", "remount,rw", mnt], 20)[0] == 0:
            try:
                for n in old:
                    os.remove(os.path.join(mnt, n))
                T["run"](["sync"], 30)
            finally:
                T["run"](["mount", "-o", "remount,ro", mnt], 20)
    except OSError:
        pass
    _write_json(_state("auto-backup.json"), {"at": now, "file": out["file"], "error": ""})
    push_notice({"kicker": "Sicherung", "title": "Einstellungen gesichert",
                 "sub": f"auf „{stick['name']}“ – der Stick kann wieder abgezogen werden", "timeout": 8000, "tag": "backup"}, ttl=20)
    round_notify("k", "Gesichert", f"Einstellungen auf {stick['name']} gespeichert")
    return out


GET_ROUTES["/api/auto-backup"] = auto_backup_status
