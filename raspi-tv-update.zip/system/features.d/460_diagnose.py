# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ---- Diagnose-Paket: Protokolle, Versionen und Teensy-Status in einer Datei (ohne Passwörter)
DIAG_ZIP = "/var/cache/raspi-tv/raspi-tv-diagnose.zip"
_DIAG_SECRET = re.compile(r"pass|pin|token|secret|psk|key|code|cookie|auth|credential", re.I)
_diag = {"at": 0}


def _diag_clean(obj):
    if isinstance(obj, dict):
        return {k: ("***" if _DIAG_SECRET.search(str(k)) and v not in (None, "", False, True) else _diag_clean(v))
                for k, v in obj.items()}
    if isinstance(obj, list):
        return [_diag_clean(v) for v in obj]
    return obj


def _diag_cmd(cmd, timeout=20, limit=400_000):
    try:
        code, out, err = T["run"](cmd, timeout)
        text = (out or "") + (("\n[stderr]\n" + err) if err and err.strip() else "")
        return text[-limit:] if text.strip() else f"(keine Ausgabe, Code {code})"
    except Exception as e:  # noqa: BLE001
        return f"(nicht verfügbar: {e})"


def diagnose_create(_data=None):
    os.makedirs(os.path.dirname(DIAG_ZIP), exist_ok=True)
    tmp = DIAG_ZIP + ".tmp"
    parts = {}

    def add(name, fn):
        try:
            v = fn()
            parts[name] = v if isinstance(v, str) else json.dumps(v, indent=1, ensure_ascii=False, default=str)
        except Exception as e:  # noqa: BLE001
            parts[name] = f"(Fehler: {e})"

    model = T["read_file"]("/proc/device-tree/model").strip("\x00\n ")
    add("uebersicht.txt", lambda: "\n".join([
        "Raspi-TV Diagnose " + time.strftime("%Y-%m-%d %H:%M:%S"),
        "Version: " + _installed_version(), "Gerät: " + model,
        "Teensy-Firmware (mitgeliefert): " + T["read_file"]("/opt/raspi-tv/teensy/version").strip(),
        "", "== uname ==", _diag_cmd(["uname", "-a"]), "== Laufzeit ==", _diag_cmd(["uptime"]),
        "== Strom (vcgencmd get_throttled) ==", _diag_cmd(["vcgencmd", "get_throttled"]),
        "== Temperatur ==", _diag_cmd(["vcgencmd", "measure_temp"]),
        "== Speicher ==", _diag_cmd(["free", "-m"]), "== Datenträger ==", _diag_cmd(["df", "-h"]),
        "== Dienste ==", _diag_cmd(["systemctl", "list-units", "raspi-tv-*", "--all", "--no-pager", "--plain"])]))
    add("protokoll-seit-start.txt", lambda: _diag_cmd(["journalctl", "-b", "--no-pager", "-o", "short-iso", "-n", "4000", "-u", "raspi-tv-*"], 40))
    add("protokoll-vorheriger-start.txt", lambda: _diag_cmd(["journalctl", "-b", "-1", "--no-pager", "-o", "short-iso", "-n", "2000", "-u", "raspi-tv-*"], 40))
    add("kernel.txt", lambda: _diag_cmd(["dmesg", "--ctime"], 20, 150_000))
    add("usb.txt", lambda: _diag_cmd(["lsusb", "-t"]) + "\n" + _diag_cmd(["lsusb"]))
    add("bluetooth.txt", lambda: _diag_cmd(["bluetoothctl", "show"]) + "\n" + _diag_cmd(["bluetoothctl", "devices"]))
    add("bluetooth-handy.json", lambda: {"listening": _btr["listening"], "error": _btr["error"],
                                         "connected": list(_btr["clients"].values()), "log": _btr.get("log", [])})
    add("teensy.json", lambda: {"status": _read_json("/var/lib/raspi-tv-round/teensy.json", {}),
                                "suche": _read_json("/var/lib/raspi-tv-round/teensy-scan.json", {}),
                                "einspielen": _read_json("/var/lib/raspi-tv-round/teensy-flash.json", {})})
    add("update.json", lambda: {"online": {k: v for k, v in online_status().items() if k != "job"}, "job": dict(_swu),
                                "pruefung": update_check_status(), "erweiterung": ext_status()})
    add("update-protokoll.txt", lambda: T["read_file"](SWUPDATE_LOG)[-200_000:])
    add("einstellungen.json", lambda: _diag_clean(_cfg()))
    # 7.5: Startzeit und Verlauf (Temperatur, Strom) der letzten 7 Tage
    add("startzeit.json", lambda: globals()["boot_times"]() if "boot_times" in globals() else "(noch nicht gemessen)")
    add("startzeit-dienste.txt", lambda: _diag_cmd(["systemd-analyze", "blame", "--no-pager"], 30, 60_000)
        + "\n== kritischer Pfad ==\n" + _diag_cmd(["systemd-analyze", "critical-chain", "--no-pager"], 30, 60_000))
    add("verlauf-7-tage.json", lambda: globals()["health_history"]({"h": ["168"]}) if "health_history" in globals() else "(noch keine Daten)")
    add("zustand.json", lambda: {"display": round_display_state(), "musik": remote_media(), "netz": _diag_cmd(["ip", "-brief", "addr"])})
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for name, text in parts.items():
            z.writestr(name, text)
    os.replace(tmp, DIAG_ZIP)
    _diag["at"] = time.time()
    out = {"ok": True, "size": os.path.getsize(DIAG_ZIP), "path": "/raspi-tv-diagnose.zip", "usb": None, "minutes": 30}
    roots = _usb_roots()
    if roots:                              # zusätzlich auf den USB-Stick legen, wenn einer steckt
        mnt = roots[0][2]
        fname = time.strftime("raspi-tv-diagnose-%Y-%m-%d-%H%M.zip")
        if T["run"](["mount", "-o", "remount,rw", mnt], 20)[0] == 0:
            try:
                shutil.copyfile(DIAG_ZIP, os.path.join(mnt, fname))
                T["run"](["sync"], 30)
                out["usb"] = {"stick": roots[0][1], "file": fname}
            except OSError:
                pass
            finally:
                T["run"](["mount", "-o", "remount,ro", mnt], 20)
    return out


_serve_prefix_73 = serve_prefix


def serve_prefix(handler, path):  # noqa: F811
    if path == "/raspi-tv-diagnose.zip":
        # 30 Minuten lang im Heimnetz abrufbar, danach gelöscht
        if os.path.isfile(DIAG_ZIP) and time.time() - _diag["at"] < 1800:
            _send_file(handler, DIAG_ZIP, "application/zip")
        else:
            try:
                os.remove(DIAG_ZIP)
            except OSError:
                pass
            handler._json(404, {"error": "Diagnose-Paket abgelaufen – bitte neu erstellen."})
        return True
    return _serve_prefix_73(handler, path)


POST_ROUTES["/api/diagnose"] = diagnose_create
