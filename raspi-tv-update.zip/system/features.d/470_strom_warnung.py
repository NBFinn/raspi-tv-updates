# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ---- Strom-Anzeige: Unterspannung sofort am Fernseher und auf den Displays melden
_power = {"warned": 0.0, "now": False, "count": 0}


def _undervoltage_now():
    if not shutil.which("vcgencmd"):
        return None
    code, o, _ = T["run"](["vcgencmd", "get_throttled"], 5)
    m = re.search(r"0x([0-9a-fA-F]+)", o or "")
    return bool(int(m.group(1), 16) & 0x1) if code == 0 and m else None


def power_step(now=None, low=None):
    now = now or time.time()
    low = _undervoltage_now() if low is None else low
    _power["now"] = bool(low)
    if not low:
        return False
    _power["count"] += 1
    if now - _power["warned"] < 1800:      # höchstens alle 30 Minuten
        return False
    _power["warned"] = now
    push_notice({"kicker": "Stromversorgung", "title": "Der Raspberry Pi bekommt zu wenig Spannung",
                 "sub": "Netzteil oder Kabel ist zu schwach – das kann Abstürze und Neustarts (auch des Teensy) auslösen. "
                        "Originalnetzteil und kurzes, dickes Kabel verwenden.", "timeout": 15000, "tag": "power"}, ttl=40)
    round_notify("w", "Unterspannung", "Netzteil oder Kabel des Pi ist zu schwach")
    return True


GET_ROUTES["/api/power"] = lambda: {"undervoltage": _power["now"], "count": _power["count"], "warned": _power["warned"]}


def _watch_73():
    seen = None
    tick = 0
    while True:
        time.sleep(5)
        tick += 1
        try:
            running = {i["id"]: i for i in _rec().schedule() if i["status"] == "recording"}
            if seen is not None:
                for rid, it in running.items():
                    if rid not in seen:
                        round_notify("r", "Aufnahme läuft", f"{it.get('title') or 'Sendung'} · {it.get('channel') or ''}")
            seen = set(running)
        except Exception:  # noqa: BLE001
            pass
        try:
            if tick % 4 == 0:
                power_step()
            if tick % 6 == 0:
                auto_backup_step()
            if tick % 240 == 1:            # Wetter für die Displays frisch halten (alle 20 Minuten)
                weather()
        except Exception:  # noqa: BLE001
            pass


_update_check_run_73 = update_check_run


def update_check_run(wait=150, sleep=time.sleep):  # noqa: F811
    before = (_read_json(_state(UPDATE_CHECK_FILE), {}) or {}).get("version")
    rec = _update_check_run_73(wait, sleep)
    if before and before != rec.get("version"):
        if rec.get("problems"):
            round_notify("w", "Update " + rec["version"], rec["problems"][0])
        else:
            round_notify("k", "Update installiert", f"Raspi-TV {rec['version']} läuft – alles in Ordnung")
    return rec


_old_start17 = start_background


def start_background():  # noqa: F811
    _old_start17()
    threading.Thread(target=_watch_73, daemon=True).start()
