# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.3.2: Pi 5 bleibt aus, wenn der Strom (wieder) da ist – erst der Knopf am Pi schaltet ein
#   Einstellung im Startprogramm des Pi 5 (EEPROM): POWER_OFF_ON_HALT=1 + WAIT_FOR_POWER_BUTTON=1
#   (ab Bootloader 22.01.2025). Neustarts laufen weiter von selbst (raspi-tv-reboot-wake.service).
# ==========================================================================
POWER_WAIT_MIN = (2025, 1, 22)
POWER_WAIT_STATE = "power-wait.json"


def _eeprom_config():
    code, out, _ = T["run"](["rpi-eeprom-config"], 30)
    return out if code == 0 and out else None


def _eeprom_value(text, key):
    m = re.search(rf"^\s*{key}\s*=\s*(\S+)", text or "", re.M)
    return m.group(1) if m else None


def _eeprom_set(text, values):
    """Schlüssel in der Bootloader-Konfiguration setzen (vorhandene Zeilen ersetzen, sonst im [all]-Teil ergänzen)."""
    lines = (text or "[all]\n").splitlines()
    for key, val in values.items():
        hit = [i for i, l in enumerate(lines) if re.match(rf"\s*{key}\s*=", l)]
        if hit:
            lines[hit[0]] = f"{key}={val}"
            for i in reversed(hit[1:]):
                del lines[i]
        else:
            at = next((i for i, l in enumerate(lines) if l.strip() == "[all]"), None)
            if at is None:
                lines = ["[all]"] + lines
                at = 0
            lines.insert(at + 1, f"{key}={val}")
    return "\n".join(lines) + "\n"


def _date_tuple(text):
    m = re.search(r"(20\d\d)[/-](\d\d)[/-](\d\d)", text or "")
    return tuple(int(x) for x in m.groups()) if m else None


def _weekday_date(text):
    """„Wed 22 Jan 2025 …“ aus rpi-eeprom-update → (2025, 1, 22)"""
    m = re.search(r"(\d{1,2}) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) (20\d\d)", text or "")
    if not m:
        return None
    return int(m.group(3)), "JanFebMarAprMayJunJulAugSepOctNovDec".index(m.group(2)) // 3 + 1, int(m.group(1))


def power_wait_status():
    model = T["read_file"]("/proc/device-tree/model").strip("\x00\n ")
    out = {"supported": False, "enabled": False, "model": model, "reason": "", "pending": False,
           "bootloader": "", "needs_update": False}
    if "Raspberry Pi 5" not in model and "Compute Module 5" not in model:
        out["reason"] = "Nur der Raspberry Pi 5 kann auf seinen Ein-Knopf warten."
        return out
    if not shutil.which("rpi-eeprom-config"):
        out["reason"] = "Das Programm rpi-eeprom fehlt – bitte Systemupdates installieren."
        return out
    cfg = _eeprom_config()
    if cfg is None:
        out["reason"] = "Die Einstellungen des Pi-Startprogramms lassen sich nicht lesen."
        return out
    cur = _date_tuple(T["run"](["vcgencmd", "bootloader_version"], 5)[1])
    out["bootloader"] = "%02d.%02d.%d" % (cur[2], cur[1], cur[0]) if cur else ""
    rec = _read_json(_state(POWER_WAIT_STATE), {}) or {}
    out["pending"] = bool(rec.get("pending"))
    out["needs_update"] = bool(cur and cur < POWER_WAIT_MIN)
    out["supported"] = True
    out["enabled"] = _eeprom_value(cfg, "WAIT_FOR_POWER_BUTTON") == "1" and (
        _eeprom_value(cfg, "POWER_OFF_ON_HALT") == "1" or globals().get("usb_always_on", lambda: False)())
    if out["pending"] and rec.get("want") is not None:
        if out["enabled"] == bool(rec["want"]):          # nach dem Neustart übernommen
            _write_json(_state(POWER_WAIT_STATE), dict(rec, pending=False))
            out["pending"] = False
        else:
            out["enabled"] = bool(rec["want"])
    return out


def power_wait_set(data):
    on = bool(data.get("on"))
    st = power_wait_status()
    if not st["supported"]:
        raise _err(st["reason"] or "Nicht möglich", 409)
    if on and st["needs_update"]:
        # das mitgelieferte neueste Startprogramm muss die Einstellung kennen
        latest = _weekday_date(next((l for l in (T["run"](["rpi-eeprom-update"], 30)[1] or "").splitlines() if "LATEST" in l), ""))
        if not latest or latest < POWER_WAIT_MIN:
            raise _err("Das Startprogramm des Pi 5 ist zu alt für diese Einstellung. Bitte zuerst unter Updates die "
                       "Systemupdates installieren und dann noch einmal versuchen.", 409)
    cfg = _eeprom_config()
    if cfg is None:
        raise _err("Die Einstellungen des Pi-Startprogramms lassen sich nicht lesen.", 500)
    rec = _read_json(_state(POWER_WAIT_STATE), {}) or {}
    if on:
        if "halt_before" not in rec:
            rec["halt_before"] = _eeprom_value(cfg, "POWER_OFF_ON_HALT") or "0"
        new = _eeprom_set(cfg, {"POWER_OFF_ON_HALT": "1", "WAIT_FOR_POWER_BUTTON": "1"})
    else:
        halt = rec.pop("halt_before", "0")
        if (_cfg().get("powerfail") or {}).get("on") is True:
            halt = "1"                     # Notfall-Abschaltung braucht „ganz aus“ (USB stromlos)
        new = _eeprom_set(cfg, {"POWER_OFF_ON_HALT": halt, "WAIT_FOR_POWER_BUTTON": "0"})
    tmp = _state("eeprom-new.conf")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(new)
    code, out, err = T["run"](["rpi-eeprom-config", "--apply", tmp], 180)
    try:
        os.remove(tmp)
    except OSError:
        pass
    if code != 0:
        raise _err("Die Einstellung konnte nicht gespeichert werden: " + ((err or out or "").strip().splitlines() or ["unbekannter Fehler"])[-1][:160], 500)
    rec.update(pending=True, want=on, at=int(time.time()))
    _write_json(_state(POWER_WAIT_STATE), rec)
    return dict(power_wait_status(), reboot=True)


GET_ROUTES["/api/power-wait"] = power_wait_status
POST_ROUTES["/api/power-wait"] = power_wait_set
