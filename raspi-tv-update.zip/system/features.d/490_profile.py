# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.4.0: Profile trennen (Startseite, Apps, Schnellaktionen, Spotify-Konto), Weiterschauen für
#        YouTube und Mediatheken, Countdown und Bildschirmschoner der runden Displays,
#        Notfall-Abschaltung bei Stromausfall
# ==========================================================================
PROFILE_KEYS = PROFILE_KEYS + ("startup", "hidden", "quick_actions")   # noqa: F811
_profile_evt = {"seq": 0, "from": None, "to": None, "at": 0}
_profiles_change_74 = profiles_change


_PROFILE_NEW_74 = ("startup", "hidden", "quick_actions")
_PROFILE_DEFAULTS_74 = {"startup": "tv", "hidden": [], "quick_actions": []}


def profiles_change(data):  # noqa: F811
    with _profile_lock:
        # Profile von vor 7.4 kennen Startseite, Apps und Schnellaktionen noch nicht: einmal mit den
        # bisherigen gemeinsamen Werten füllen, damit beim Wechsel nichts verloren geht
        cfg = _cfg()
        changed = False
        for p in cfg.get("profiles") or []:
            for k in _PROFILE_NEW_74:
                if k not in p.setdefault("settings", {}):
                    p["settings"][k] = json.loads(json.dumps(cfg.get(k, _PROFILE_DEFAULTS_74[k])))
                    changed = True
        if changed:
            _save(cfg)
    before = _cfg().get("active_profile") or "default"
    out = _profiles_change_74(data)
    if data.get("action") == "switch" and out["active"] != before:
        # die Erweiterung tauscht das Spotify-Konto (Anmelde-Cookies) und lädt Spotify neu
        _profile_evt.update(seq=_profile_evt["seq"] + 1, at=time.time(), **{"from": before, "to": out["active"]})
        name = next((p["name"] for p in out["profiles"] if p["id"] == out["active"]), "")
        round_notify("i", "Profil " + name, "Startseite, Apps, Schnellaktionen und Spotify gewechselt")
    if data.get("action") == "delete":
        try:                                   # Weiterschauen-Liste des gelöschten Profils mit entfernen
            with _cont_lock:
                if _cont_load().pop(data.get("id"), None) is not None:
                    _cont_save(force=True)
        except (OSError, KeyError):
            pass
    return out


POST_ROUTES["/api/profiles"] = profiles_change
_nav_pending_74 = nav_pending


def nav_pending(query, headers):  # noqa: F811
    out = _nav_pending_74(query, headers)
    if _profile_evt["seq"] and time.time() - _profile_evt["at"] < 30:
        out["profile"] = {"seq": _profile_evt["seq"], "from": _profile_evt["from"], "to": _profile_evt["to"]}
    return out


QUERY_ROUTES["/api/nav/pending"] = nav_pending
