# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ---- Weiterschauen: angefangene Videos auf YouTube, in Mediatheken usw. (je Profil)
CONT_FILE = "continue.json"
CONT_MAX = 12
_cont_lock = threading.Lock()
_cont = {"data": None, "saved": 0.0, "dirty": False}
_CONT_SKIP = ("music.youtube.com", "open.spotify.com", "127.0.0.1")


def _cont_load():
    if _cont["data"] is None:
        d = _read_json(_state(CONT_FILE), {}) or {}
        _cont["data"] = d if isinstance(d, dict) else {}
    return _cont["data"]


def _cont_save(force=False):
    if _cont["dirty"] or force:
        if force or time.time() - _cont["saved"] > 20:
            _write_json(_state(CONT_FILE), _cont["data"] or {})
            _cont.update(saved=time.time(), dirty=False)


def _cont_key(url):
    try:
        u = urlparse(url)
    except ValueError:
        return None
    host = (u.hostname or "").lower()
    if u.scheme not in ("http", "https") or not host or host.endswith(_CONT_SKIP) or host in _CONT_SKIP:
        return None
    host = host[4:] if host.startswith("www.") else host
    if host in ("youtube.com", "m.youtube.com"):
        v = (parse_qs(u.query).get("v") or [""])[0]
        return "yt:" + v if re.fullmatch(r"[\w-]{6,20}", v) else None
    if host == "youtu.be":
        v = u.path.strip("/")
        return "yt:" + v if re.fullmatch(r"[\w-]{6,20}", v) else None
    path = u.path.rstrip("/")
    return host + path if len(path) > 1 else None


def _cont_url(e):
    if e["key"].startswith("yt:"):
        return f"https://www.youtube.com/watch?v={e['key'][3:]}&t={max(0, int(e['pos']) - 5)}s"
    return e["url"]


def _cont_profile():
    return _cfg().get("active_profile") or "default"


def continue_record(now):
    """Aus der Meldung eines Tabs (Erweiterung) die Weiterschauen-Liste pflegen."""
    url, pos, dur = now.get("url"), now.get("pos"), now.get("dur")
    if not isinstance(url, str) or type(pos) not in (int, float) or type(dur) not in (int, float):
        return
    key = _cont_key(url)
    if not key or dur < 240 or dur > 6 * 3600:          # kurze Clips und Live-Sendungen nicht merken
        return
    with _cont_lock:
        lst = _cont_load().setdefault(_cont_profile(), [])
        old = next((e for e in lst if e["key"] == key), None)
        if dur - pos < max(60, dur * 0.05):              # zu Ende geschaut
            if old:
                lst.remove(old)
                _cont["dirty"] = True
                _cont_save(force=True)
            return
        if pos < 60 and not old:
            return
        e = old or {"key": key}
        changed = old is None or abs(e.get("pos", 0) - pos) > 5
        e.update(url=url.split("#")[0][:500], pos=int(pos), dur=int(dur), at=int(time.time()),
                 title=str(now.get("title") or "")[:120], site=str(now.get("site") or "")[:40],
                 cover=str(now.get("cover") or "")[:500] if str(now.get("cover") or "").startswith("https://") else e.get("cover", ""))
        if not old:
            lst.insert(0, e)
        else:
            lst.sort(key=lambda x: -x["at"])
        del lst[CONT_MAX:]
        if changed:
            _cont["dirty"] = True
        _cont_save(force=not old)


_media_webnow_74 = media_webnow


def media_webnow(query, headers):  # noqa: F811
    out = _media_webnow_74(query, headers)
    try:
        continue_record(json.loads((query.get("d") or ["null"])[0]) or {})
    except (ValueError, TypeError, AttributeError):
        pass
    return out


QUERY_ROUTES["/api/media/webnow"] = media_webnow


def continue_list():
    with _cont_lock:
        lst = list(_cont_load().get(_cont_profile(), []))
    return {"items": [dict(e, open=_cont_url(e), left=max(1, round((e["dur"] - e["pos"]) / 60))) for e in lst]}


def continue_remove(data):
    with _cont_lock:
        lst = _cont_load().get(_cont_profile(), [])
        lst[:] = [e for e in lst if e["key"] != data.get("key")]
        _cont["dirty"] = True
        _cont_save(force=True)
    return continue_list()


def continue_pos(query, headers):
    """Für die Erweiterung: an welcher Stelle diese Seite zuletzt war (nur Seiten ohne eigenes ?t=)."""
    if headers.get("X-Raspi-TV") != "1":
        raise _err("forbidden", 403)
    key = _cont_key((query.get("u") or [""])[0])
    with _cont_lock:
        e = next((x for x in _cont_load().get(_cont_profile(), []) if x["key"] == key), None) if key else None
    return {"pos": max(0, e["pos"] - 5) if e else None}


GET_ROUTES["/api/continue"] = continue_list
POST_ROUTES["/api/continue/remove"] = continue_remove
QUERY_ROUTES["/api/continue/pos"] = continue_pos
