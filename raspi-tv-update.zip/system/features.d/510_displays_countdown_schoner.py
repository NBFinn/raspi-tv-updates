# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ---- Runde Displays: Countdown und Bildschirmschoner
def countdowns_valid(v):
    if not isinstance(v, list) or len(v) > 8:
        return False
    for c in v:
        if not isinstance(c, dict) or set(c) - {"name", "date", "yearly"}:
            return False
        if not isinstance(c.get("name"), str) or not 1 <= len(c["name"].strip()) <= 24:
            return False
        if not isinstance(c.get("date"), str) or not re.fullmatch(r"\d{4}-\d\d-\d\d", c["date"]):
            return False
        try:
            time.strptime(c["date"], "%Y-%m-%d")
        except ValueError:
            return False
        if not isinstance(c.get("yearly", False), bool):
            return False
    return True


def _countdown_next(items, today=None):
    """Nächster Termin: (Name, Tage bis dahin) – jährliche Termine (Geburtstag, Silvester) rollen weiter."""
    import datetime as dt
    today = today or dt.date.today()
    best = None
    for c in items or []:
        try:
            d = dt.date(*map(int, c["date"].split("-")))
        except (ValueError, KeyError, TypeError):
            continue
        if c.get("yearly"):
            try:
                d = d.replace(year=today.year)
            except ValueError:                             # 29. Februar
                d = dt.date(today.year, 3, 1)
            if d < today:
                try:
                    d = d.replace(year=today.year + 1)
                except ValueError:
                    d = dt.date(today.year + 1, 3, 1)
        days = (d - today).days
        if 0 <= days <= 999 and (best is None or days < best[1]):
            best = (c["name"].strip()[:24], days)
    return best


_round_state_74 = round_display_state


def round_display_state():  # noqa: F811
    st = _round_state_74()
    cfg = _cfg()
    nxt = _countdown_next(cfg.get("round_countdowns"))
    if nxt:
        st["countdown"] = {"name": nxt[0], "days": nxt[1]}
    mins = cfg.get("round_saver_min") if cfg.get("round_saver_min") in (0, 5, 10, 15, 30, 60) else 0
    idle = time.time() - last_input()
    music = (st.get("music") or {}).get("playing")
    busy = bool(_swu.get("running")) or (st.get("update") or {}).get("running")
    st["saver"] = bool(mins and idle > mins * 60 and not music and not busy)
    return st


GET_ROUTES["/api/round-display"] = round_display_state
