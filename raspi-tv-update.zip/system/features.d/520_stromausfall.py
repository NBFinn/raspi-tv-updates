# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ---- Notfall-Abschaltung bei Stromausfall (Dienst raspi-tv-powerfail)
POWERFAIL_STATUS = "/run/raspi-tv-powerfail.json"
POWERFAIL_EVENT = "/var/lib/raspi-tv/powerfail-event.json"


def powerfail_valid(v):
    volt = lambda x: x is None or (type(x) in (int, float) and 3.5 <= x <= 5.8)
    return (isinstance(v, dict) and set(v) <= {"on", "pin", "lost", "pull", "source", "v_mains", "v_batt", "fast"}
            and isinstance(v.get("on", False), bool) and isinstance(v.get("fast", True), bool)
            and type(v.get("pin", 6)) is int and 2 <= v.get("pin", 6) <= 27 and v.get("pin", 6) != 26
            and v.get("lost", "low") in ("low", "high") and v.get("pull", "up") in ("up", "down", "none")
            and v.get("source", "gpio") in ("gpio", "voltage") and volt(v.get("v_mains")) and volt(v.get("v_batt")))


def powerfail_status():
    p = _cfg().get("powerfail") or {}
    st = _read_json(POWERFAIL_STATUS, {}) or {}
    return {"on": p.get("on") is True, "pin": p.get("pin", 6), "lost": p.get("lost", "low"), "pull": p.get("pull", "up"),
            "source": p.get("source", "gpio"), "fast": p.get("fast") is not False, "v_mains": p.get("v_mains"), "v_batt": p.get("v_batt"),
            "service": time.time() - st.get("at", 0) < 15, "power": st.get("power"), "level": st.get("level"),
            "volt": st.get("volt") if st.get("volt") is not None else _pf_read_volt_cached(), "threshold": st.get("threshold"),
            "need_learn": bool(st.get("need_learn")), "learn": dict(_pf_learn),
            "armed": bool(st.get("armed")), "error": st.get("error", ""), "gpio_pins_used": _gpio_used()}


# ---- 7.8.1: Stromausfall an der Spannung erkennen (Pi 5 misst seine Eingangsspannung selbst)
POWERFAIL_PAUSE = "/run/raspi-tv-powerfail-pause"
_pf_learn = {"which": None, "phase": "", "msg": ""}
_pf_volt = {"at": 0, "v": None}


def _pf_read_volt():
    code, out, _ = T["run"](["vcgencmd", "pmic_read_adc", "EXT5V_V"], 3)
    m = re.search(r"=\s*([\d.]+)\s*V", out or "")
    return float(m.group(1)) if code == 0 and m else None


def _pf_read_volt_cached():
    if time.time() - _pf_volt["at"] > 1:
        _pf_volt.update(at=time.time(), v=_pf_read_volt())
    return _pf_volt["v"]


def _pf_pause():
    try:
        with open(POWERFAIL_PAUSE, "w") as f:
            f.write("1")
    except OSError:
        pass


def _pf_sample(secs=3.0):
    vals = []
    end = time.time() + secs
    while time.time() < end:
        v = _pf_read_volt()
        if v is not None:
            vals.append(v)
        time.sleep(0.15)
    vals.sort()
    return round(vals[len(vals) // 2], 3) if vals else None


def _pf_learn_job(which):
    try:
        _pf_pause()
        if which == "mains":
            _pf_learn.update(phase="measure", msg="Messe mit Netzteil …")
            v = _pf_sample()
        else:
            p = _cfg().get("powerfail") or {}
            vm = p.get("v_mains")
            _pf_learn.update(phase="unplug", msg="Jetzt das Netzteil vom Modul abziehen …")
            end = time.time() + 20
            while time.time() < end:                       # warten, bis die Spannung fällt
                _pf_pause()
                v = _pf_read_volt()
                if vm and v is not None and v < vm - 0.05:
                    break
                time.sleep(0.2)
            time.sleep(1.5)
            _pf_pause()
            _pf_learn.update(phase="measure", msg="Messe nur mit Akku …")
            v = _pf_sample()
            _pf_pause()
        if v is None:
            _pf_learn.update(phase="error", msg="Spannung lässt sich nicht messen (geht nur beim Raspberry Pi 5)")
            return
        cfg = _cfg()
        pf = dict(cfg.get("powerfail") or {})
        pf["v_mains" if which == "mains" else "v_batt"] = v
        cfg["powerfail"] = pf
        _save(cfg)
        vm, vb = pf.get("v_mains"), pf.get("v_batt")
        de = lambda x: f"{x:.2f}".replace(".", ",")
        if vm and vb and vm - vb < 0.08:
            msg = f"{de(v)} V gemessen – Netzteil und Akku liegen zu dicht beieinander ({de(vm)} / {de(vb)} V). So lässt sich ein Ausfall nicht sicher erkennen."
        elif which == "batt":
            msg = f"Nur Akku: {de(v)} V. Netzteil wieder einstecken – fertig."
        else:
            msg = f"Mit Netzteil: {de(v)} V. Jetzt Schritt 2."
        _pf_learn.update(phase="done", msg=msg)
    except Exception as e:  # noqa: BLE001
        _pf_learn.update(phase="error", msg=str(e)[:160])
    finally:
        _pf_learn["which"] = None


def powerfail_learn(data):
    which = (data or {}).get("which")
    if which not in ("mains", "batt"):
        raise T["ApiError"]("Ungültig")
    if _pf_learn["which"]:
        return powerfail_status()
    _pf_learn.update(which=which, phase="start", msg="")
    threading.Thread(target=_pf_learn_job, args=(which,), daemon=True).start()
    time.sleep(0.1)
    return powerfail_status()


POST_ROUTES["/api/powerfail/learn"] = powerfail_learn


def _gpio_used():
    used = [26]                                            # Lüfter
    if os.path.exists("/var/lib/raspi-tv-round/enabled-separate-pins"):
        # runde Displays direkt am Pi: SPI0 (8–11), SPI1 (16, 18–21), DC 24/25, RST 23/27
        used += [8, 9, 10, 11, 16, 18, 19, 20, 21, 23, 24, 25, 27]
    return sorted(set(used))


GET_ROUTES["/api/powerfail"] = powerfail_status


def _powerfail_boot_notice():
    ev = _read_json(POWERFAIL_EVENT, None)
    if not ev:
        return
    try:
        os.remove(POWERFAIL_EVENT)
    except OSError:
        pass
    when = time.strftime("%d.%m. um %H:%M", time.localtime(ev.get("at", time.time())))
    time.sleep(20)
    push_notice({"kicker": "Stromausfall", "title": "Raspi-TV wurde rechtzeitig heruntergefahren",
                 "sub": f"Der Strom war am {when} weg. Alle Einstellungen sind gespeichert.", "timeout": 12000, "tag": "powerfail"}, ttl=120)
    round_notify("w", "Stromausfall", f"am {when} – sauber heruntergefahren")


_old_start18 = start_background


def start_background():  # noqa: F811
    _old_start18()
    threading.Thread(target=_powerfail_boot_notice, daemon=True).start()

    def flush_continue():
        while True:
            time.sleep(30)
            try:
                with _cont_lock:
                    _cont_save()
            except Exception:  # noqa: BLE001
                pass
    threading.Thread(target=flush_continue, daemon=True).start()
