# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ---- Notfall-Abschaltung bei Stromausfall (Dienst raspi-tv-powerfail)
POWERFAIL_STATUS = "/run/raspi-tv-powerfail.json"
POWERFAIL_EVENT = "/var/lib/raspi-tv/powerfail-event.json"


def powerfail_valid(v):
    return (isinstance(v, dict) and set(v) <= {"on", "pin", "lost", "pull"} and isinstance(v.get("on", False), bool)
            and type(v.get("pin", 6)) is int and 2 <= v.get("pin", 6) <= 27 and v.get("pin", 6) != 26
            and v.get("lost", "low") in ("low", "high") and v.get("pull", "up") in ("up", "down", "none"))


def powerfail_status():
    p = _cfg().get("powerfail") or {}
    st = _read_json(POWERFAIL_STATUS, {}) or {}
    return {"on": p.get("on") is True, "pin": p.get("pin", 6), "lost": p.get("lost", "low"), "pull": p.get("pull", "up"),
            "service": time.time() - st.get("at", 0) < 15, "power": st.get("power"), "level": st.get("level"),
            "armed": bool(st.get("armed")), "error": st.get("error", ""), "gpio_pins_used": _gpio_used()}


def _gpio_used():
    used = [26]                                            # Lüfter
    if os.path.exists("/var/lib/raspi-tv-round/enabled-separate-pins"):
        # runde Displays direkt am Pi: SPI0 (8–11), SPI1 (16, 18–21), DC 24/25, RST 23/27
        used += [8, 9, 10, 11, 16, 18, 19, 20, 21, 23, 24, 25, 27]
    return sorted(set(used))


GET_ROUTES["/api/powerfail"] = powerfail_status


def _powerfail_boot_notice():
    ev = _read_json(POWERFAIL_EVENT, None)
    if not ev:
        return
    try:
        os.remove(POWERFAIL_EVENT)
    except OSError:
        pass
    when = time.strftime("%d.%m. um %H:%M", time.localtime(ev.get("at", time.time())))
    time.sleep(20)
    push_notice({"kicker": "Stromausfall", "title": "Raspi-TV wurde rechtzeitig heruntergefahren",
                 "sub": f"Der Strom war am {when} weg. Alle Einstellungen sind gespeichert.", "timeout": 12000, "tag": "powerfail"}, ttl=120)
    round_notify("w", "Stromausfall", f"am {when} – sauber heruntergefahren")


_old_start18 = start_background


def start_background():  # noqa: F811
    _old_start18()
    threading.Thread(target=_powerfail_boot_notice, daemon=True).start()

    def flush_continue():
        while True:
            time.sleep(30)
            try:
                with _cont_lock:
                    _cont_save()
            except Exception:  # noqa: BLE001
                pass
    threading.Thread(target=flush_continue, daemon=True).start()
