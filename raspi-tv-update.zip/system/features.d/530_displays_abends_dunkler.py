# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.5.0: Runde Displays werden abends von selbst dunkler (sanfter Übergang über 20 Minuten)
#   config "round_night_dim": {"on": bool, "from": "21:00", "to": "07:00", "level": 30}
# ==========================================================================
NIGHT_DIM_RAMP = 20 * 60


def night_dim_valid(v):
    return (isinstance(v, dict) and set(v) <= {"on", "from", "to", "level"} and isinstance(v.get("on", False), bool)
            and all(isinstance(v.get(k, "00:00"), str) and re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", v.get(k, "00:00"))
                    for k in ("from", "to"))
            and type(v.get("level", 30)) is int and 5 <= v.get("level", 30) <= 100)


def night_dim_factor(cfg, now=None):
    """0 = Tag (normale Helligkeit), 1 = Nacht; dazwischen gleitend über 20 Minuten."""
    if not cfg or not cfg.get("on"):
        return 0.0
    t = time.localtime(now or time.time())
    cur = t.tm_hour * 3600 + t.tm_min * 60 + t.tm_sec
    a, b = (int(x[:2]) * 3600 + int(x[3:5]) * 60 for x in (cfg.get("from", "21:00"), cfg.get("to", "07:00")))
    if a == b:
        return 0.0
    day = 86400
    since_a = (cur - a) % day          # Sekunden seit Beginn der Nacht
    night_len = (b - a) % day
    if since_a < night_len:            # nachts: am Anfang langsam dunkler werden
        return min(1.0, since_a / NIGHT_DIM_RAMP)
    since_b = (cur - b) % day          # tagsüber: nach dem Ende langsam wieder heller
    return max(0.0, 1.0 - since_b / NIGHT_DIM_RAMP)


_round_state_75 = round_display_state


def round_display_state():  # noqa: F811
    st = _round_state_75()
    cfg = _cfg().get("round_night_dim") or {}
    f = night_dim_factor(cfg)
    if f > 0:
        base = st.get("brightness", 100) if type(st.get("brightness")) is int else 100
        night = min(base, cfg.get("level", 30) if type(cfg.get("level", 30)) is int else 30)
        st["brightness"] = max(5, round(base + (night - base) * f))
        st["night_dim"] = round(f, 2)
    return st


GET_ROUTES["/api/round-display"] = round_display_state
