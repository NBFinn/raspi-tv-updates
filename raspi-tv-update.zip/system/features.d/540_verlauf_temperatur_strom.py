# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.5.0: Verlauf von Temperatur, Auslastung und Stromversorgung (7 Tage, jede Minute ein Messpunkt)
# ==========================================================================
HEALTH_FILE = "health.json"
HEALTH_KEEP = 7 * 24 * 60
_health = {"rows": None, "saved": 0.0, "stat": None}
_health_lock = threading.Lock()


def _health_rows():
    if _health["rows"] is None:
        rows = _read_json(_state(HEALTH_FILE), [])
        _health["rows"] = [r for r in rows if isinstance(r, list) and len(r) == 5] if isinstance(rows, list) else []
    return _health["rows"]


def _cpu_sample():
    try:
        with open("/proc/stat") as f:
            v = [int(x) for x in f.readline().split()[1:]]
    except (OSError, ValueError):
        return None
    idle, total = v[3] + (v[4] if len(v) > 4 else 0), sum(v)
    prev, _health["stat"] = _health["stat"], (idle, total)
    if not prev or total <= prev[1]:
        return None
    return round(100 * (1 - (idle - prev[0]) / (total - prev[1])))


def health_sample(now=None):
    """Ein Messpunkt: [Zeit, °C, CPU %, Unterspannung 0/1, Drosselung 0/1]."""
    now = int(now or time.time())
    try:
        with open("/sys/class/thermal/thermal_zone0/temp") as f:
            temp = round(int(f.read().strip()) / 1000, 1)
    except (OSError, ValueError):
        temp = None
    uv = thr = 0
    if shutil.which("vcgencmd"):
        code, o, _ = T["run"](["vcgencmd", "get_throttled"], 5)
        m = re.search(r"0x([0-9a-fA-F]+)", o or "")
        if code == 0 and m:
            v = int(m.group(1), 16)
            uv, thr = int(bool(v & 0x1)), int(bool(v & 0x6))
    row = [now, temp, _cpu_sample(), uv, thr]
    with _health_lock:
        rows = _health_rows()
        rows.append(row)
        del rows[:-HEALTH_KEEP]
        if now - _health["saved"] > 600:                  # alle 10 Minuten auf die Karte
            _write_json(_state(HEALTH_FILE), rows)
            _health["saved"] = now
    return row


def health_history(query=None, headers=None):
    hours = 24
    try:
        hours = max(1, min(168, int(((query or {}).get("h") or ["24"])[0])))
    except (TypeError, ValueError):
        pass
    since = time.time() - hours * 3600
    with _health_lock:
        rows = [r for r in _health_rows() if r[0] >= since]
    # auf höchstens 240 Punkte zusammenfassen (Mittel- und Höchstwert je Abschnitt)
    step = max(60, hours * 3600 // 240)
    buckets = {}
    for t, temp, cpu, uv, thr in rows:
        b = buckets.setdefault(int(t // step * step), {"temp": [], "cpu": [], "uv": 0, "thr": 0})
        if temp is not None:
            b["temp"].append(temp)
        if cpu is not None:
            b["cpu"].append(cpu)
        b["uv"] |= uv
        b["thr"] |= thr
    points = [{"t": t, "temp": round(sum(b["temp"]) / len(b["temp"]), 1) if b["temp"] else None,
               "temp_max": max(b["temp"]) if b["temp"] else None,
               "cpu": round(sum(b["cpu"]) / len(b["cpu"])) if b["cpu"] else None, "uv": b["uv"], "thr": b["thr"]}
              for t, b in sorted(buckets.items())]
    # Zeiträume mit Unterspannung zum Auflisten
    events, cur = [], None
    for t, _temp, _cpu, uv, _thr in rows:
        if uv and not cur:
            cur = [t, t]
        elif uv:
            cur[1] = t
        elif cur:
            events.append(cur)
            cur = None
    if cur:
        events.append(cur)
    temps = [p["temp_max"] for p in points if p["temp_max"] is not None]
    return {"hours": hours, "step": step, "points": points, "undervoltage": events[-20:],
            "max_temp": max(temps) if temps else None,
            "throttled_minutes": sum(1 for r in rows if r[4]), "undervoltage_minutes": sum(1 for r in rows if r[3])}


QUERY_ROUTES["/api/health"] = health_history


def _health_loop():
    while True:
        try:
            health_sample()
        except Exception:  # noqa: BLE001
            pass
        time.sleep(60)
