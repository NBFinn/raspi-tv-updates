# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.5.0: Startzeit messen (System, Dienste, Oberfläche) und unnötige Bremsen beim Hochfahren lösen
# ==========================================================================
BOOT_FILE = "boot-times.json"
_boot = {"ctl_up": None, "ui_ready": None}


def _uptime():
    try:
        with open("/proc/uptime") as f:
            return float(f.read().split()[0])
    except (OSError, ValueError):
        return None


_boot["ctl_up"] = _uptime()          # Zeitpunkt, an dem der Systemdienst geladen wurde


def _boot_id():
    return T["read_file"]("/proc/sys/kernel/random/boot_id").strip()


def _parse_analyze(text):
    """„Startup finished in 3.2s (kernel) + 9.8s (userspace) = 13.0s“ → {kernel, userspace}"""
    out = {}
    for mins, val, unit, part in re.findall(r"(?:(\d+)min ?)?(?:([\d.]+)(s|ms))? \((\w+)\)", text or ""):
        if not mins and not val:
            continue
        sec = int(mins or 0) * 60 + (float(val) * (0.001 if unit == "ms" else 1) if val else 0)
        out[part] = round(out.get(part, 0) + sec, 1)
    return out


def _parse_blame(text, top=8):
    rows = []
    for line in (text or "").splitlines():
        m = re.match(r"\s*(?:(\d+)min )?([\d.]+)(s|ms) (\S+)", line)
        if m:
            sec = (int(m.group(1) or 0) * 60) + float(m.group(2)) * (0.001 if m.group(3) == "ms" else 1)
            rows.append({"unit": m.group(4), "sec": round(sec, 1)})
    rows.sort(key=lambda r: -r["sec"])
    return rows[:top]


def boot_ready(_data=None):
    """Die Oberfläche meldet sich nach dem Laden – einmal pro Systemstart wird die Zeit festgehalten."""
    if _boot["ui_ready"] is None:
        _boot["ui_ready"] = _uptime()
        threading.Thread(target=_boot_record, daemon=True).start()
    return {"ok": True}


def _boot_record():
    time.sleep(5)
    code, o, _ = T["run"](["systemd-analyze", "time"], 20)
    parts = _parse_analyze(o if code == 0 else "")
    blame = _parse_blame(T["run"](["systemd-analyze", "blame", "--no-pager"], 30)[1])
    rec = {"at": int(time.time()), "boot": _boot_id(), "kernel": parts.get("kernel"), "userspace": parts.get("userspace"),
           "ctl": round(_boot["ctl_up"], 1) if _boot["ctl_up"] else None,
           "ui": round(_boot["ui_ready"], 1) if _boot["ui_ready"] else None, "slow": blame}
    hist = _read_json(_state(BOOT_FILE), [])
    hist = [h for h in hist if isinstance(h, dict) and h.get("boot") != rec["boot"]] if isinstance(hist, list) else []
    hist.append(rec)
    _write_json(_state(BOOT_FILE), hist[-10:])


def boot_times():
    hist = _read_json(_state(BOOT_FILE), [])
    hist = hist if isinstance(hist, list) else []
    rec = _read_json(_state("boot-tuning.json"), {}) or {}
    return {"last": hist[-1] if hist else None, "history": hist, "tuned": rec.get("done", [])}


GET_ROUTES["/api/boot"] = boot_times
POST_ROUTES["/api/boot/ready"] = boot_ready


# Dienste, die auf einem Raspi-TV nichts tun, das Hochfahren aber aufhalten können
BOOT_TUNING = (
    ("ModemManager.service", "kein Mobilfunk-Modem"),
    ("systemd-networkd-wait-online.service", "wartet auf ein Netz, das Raspi-TV nicht nutzt"),
    ("cups.service", "Druckerdienst"), ("cups-browsed.service", "Druckersuche"),
    ("triggerhappy.service", "Tastenkürzel-Dienst (Raspi-TV hat eigene)"),
)


def boot_tune():
    """Einmal je Version: unnötige Dienste abschalten (nur wenn installiert und sicher unbenutzt)."""
    rec = _read_json(_state("boot-tuning.json"), {}) or {}
    ver = _installed_version()
    if rec.get("version") == ver:
        return rec
    done = list(rec.get("done", []))
    for unit, why in BOOT_TUNING:
        code, out, _ = T["run"](["systemctl", "is-enabled", unit], 10)
        if code != 0 or (out or "").strip() not in ("enabled", "enabled-runtime"):
            continue
        if unit == "systemd-networkd-wait-online.service":
            if T["run"](["systemctl", "is-active", "--quiet", "systemd-networkd.service"], 10)[0] == 0:
                continue                       # das Netz läuft wirklich über systemd-networkd: nicht anfassen
        if unit == "ModemManager.service" and glob.glob("/dev/cdc-wdm*"):
            continue                           # es steckt doch ein Modem
        if T["run"](["systemctl", "disable", unit], 20)[0] == 0:
            done.append({"unit": unit, "why": why})
            print("Schnellerer Start:", unit, "abgeschaltet –", why, flush=True)
    rec = {"version": ver, "done": done}
    _write_json(_state("boot-tuning.json"), rec)
    return rec
