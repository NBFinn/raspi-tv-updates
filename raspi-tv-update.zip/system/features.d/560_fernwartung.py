# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.5.0: Fernwartung – bei einem Fehler das Diagnose-Paket selbst in ein privates GitHub-Repository laden
#   (nur wenn eingeschaltet). config "support": {"on": bool, "repo": "name/repo", "auto": bool}
#   Der Zugangsschlüssel liegt getrennt in /var/lib/raspi-tv/support-token (nur root kann ihn lesen)
#   und wird nie über die Oberfläche zurückgegeben.
# ==========================================================================
SUPPORT_TOKEN = "/var/lib/raspi-tv/support-token"
SUPPORT_LOG = "support.json"
SUPPORT_MIN_GAP = 6 * 3600               # automatisch höchstens alle 6 Stunden
_support_lock = threading.Lock()


def support_valid(v):
    return (isinstance(v, dict) and set(v) <= {"on", "repo", "auto"} and isinstance(v.get("on", False), bool)
            and isinstance(v.get("auto", True), bool)
            and isinstance(v.get("repo", ""), str) and re.fullmatch(r"([\w.-]{1,39}/[\w.-]{1,100})?", v.get("repo", "")) is not None)


def _support_cfg():
    s = _cfg().get("support") or {}
    return {"on": s.get("on") is True, "repo": s.get("repo") or "", "auto": s.get("auto", True) is not False}


def _support_token():
    try:
        with open(SUPPORT_TOKEN) as f:
            return f.read().strip()
    except OSError:
        return ""


def support_status():
    s = _support_cfg()
    log = _read_json(_state(SUPPORT_LOG), {}) or {}
    s.update(has_token=bool(_support_token()), last=log.get("last"), history=log.get("history", [])[-8:])
    return s


def support_token_set(data):
    tok = str(data.get("token") or "").strip()
    if tok and not re.fullmatch(r"(github_pat_|ghp_)[A-Za-z0-9_]{20,250}", tok):
        raise _err("Das sieht nicht wie ein GitHub-Zugangsschlüssel aus (beginnt mit github_pat_ oder ghp_).")
    if tok:
        os.makedirs(os.path.dirname(SUPPORT_TOKEN), exist_ok=True)
        fd = os.open(SUPPORT_TOKEN + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(tok)
            f.flush()
            os.fsync(f.fileno())
        os.replace(SUPPORT_TOKEN + ".tmp", SUPPORT_TOKEN)
    else:
        try:
            os.remove(SUPPORT_TOKEN)
        except OSError:
            pass
    return support_status()


def _gh_put(repo, path, content, message, token):
    import base64
    body = json.dumps({"message": message, "content": base64.b64encode(content).decode()}).encode()
    req = urllib.request.Request(f"https://api.github.com/repos/{repo}/contents/{quote(path)}", data=body, method="PUT",
                                 headers={"Authorization": "Bearer " + token, "Accept": "application/vnd.github+json",
                                          "User-Agent": "Raspi-TV", "X-GitHub-Api-Version": "2022-11-28"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        msg = {401: "Zugangsschlüssel ungültig oder abgelaufen", 403: "Zugangsschlüssel darf nicht in dieses Repository schreiben",
               404: "Repository nicht gefunden (oder der Schlüssel sieht es nicht)",
               422: "Datei zu groß oder ungültig"}.get(e.code, f"GitHub antwortet mit Fehler {e.code}")
        raise _err(msg, 502)
    except OSError:
        raise _err("GitHub ist nicht erreichbar – Internetverbindung prüfen.", 502)


def support_send(data=None, reason="manuell"):
    """Diagnose-Paket erstellen und hochladen. Gibt den Pfad im Repository zurück."""
    s = _support_cfg()
    if not s["on"] or not s["repo"]:
        raise _err("Fernwartung ist nicht eingeschaltet.", 409)
    token = _support_token()
    if not token:
        raise _err("Es ist noch kein Zugangsschlüssel eingetragen.", 409)
    reason = str((data or {}).get("reason") or reason)[:60]
    with _support_lock:
        diagnose_create()
        with open(DIAG_ZIP, "rb") as f:
            blob = f.read()
        if len(blob) > 50_000_000:
            raise _err("Diagnose-Paket zu groß.", 413)
        slug = re.sub(r"[^a-z0-9]+", "-", reason.lower()).strip("-")[:40] or "fehler"
        path = time.strftime("diagnose/%Y-%m-%d_%H%M%S_") + f"{_installed_version()}_{slug}.zip"
        _gh_put(s["repo"], path, blob, f"Raspi-TV {_installed_version()}: Diagnose ({reason})", token)
        log = _read_json(_state(SUPPORT_LOG), {}) or {}
        entry = {"at": int(time.time()), "reason": reason, "path": path, "size": len(blob)}
        log["last"] = entry
        log["history"] = (log.get("history") or [])[-30:] + [entry]
        _write_json(_state(SUPPORT_LOG), log)
    round_notify("k", "Diagnose gesendet", reason)
    return {"ok": True, "path": path, "size": len(blob)}


def support_auto(reason):
    """Automatisch senden (wenn erlaubt), höchstens alle 6 Stunden."""
    s = _support_cfg()
    if not (s["on"] and s["auto"] and s["repo"] and _support_token()):
        return None
    last = ((_read_json(_state(SUPPORT_LOG), {}) or {}).get("last") or {}).get("at", 0)
    if time.time() - last < SUPPORT_MIN_GAP:
        return None
    try:
        return support_send(reason=reason)
    except Exception as e:  # noqa: BLE001
        print("Fernwartung: Senden fehlgeschlagen –", e, flush=True)
        return None


GET_ROUTES["/api/support"] = support_status
POST_ROUTES["/api/support/token"] = support_token_set
POST_ROUTES["/api/support/send"] = lambda data: support_send(data)


# Auslöser: Prüfung nach Update meldet Probleme, Teensy-Absturz, abgestürzter Raspi-TV-Dienst
_update_check_run_75 = update_check_run


def update_check_run(wait=150, sleep=time.sleep):  # noqa: F811
    rec = _update_check_run_75(wait, sleep)
    if rec.get("problems"):
        threading.Thread(target=support_auto, args=("Update " + rec.get("version", "") + " mit Problemen",), daemon=True).start()
    return rec


def _support_watch():
    seen_crash = (_read_json("/var/lib/raspi-tv-round/teensy.json", {}) or {}).get("crash") or ""
    while True:
        time.sleep(120)
        try:
            crash = (_read_json("/var/lib/raspi-tv-round/teensy.json", {}) or {}).get("crash") or ""
            if crash and crash != seen_crash:
                seen_crash = crash
                support_auto("Teensy abgestürzt")
            code, out, _ = T["run"](["systemctl", "list-units", "raspi-tv-*", "--state=failed", "--plain", "--no-legend"], 15)
            failed = [l.split()[0] for l in (out or "").splitlines() if l.strip()]
            if failed:
                support_auto("Dienst ausgefallen: " + failed[0].replace(".service", ""))
        except Exception:  # noqa: BLE001
            pass
