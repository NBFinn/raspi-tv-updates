# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.6.0: Suche in allen öffentlich-rechtlichen Mediatheken auf einmal (ARD, ZDF, arte, 3sat, Dritte …)
#   Datenquelle: MediathekViewWeb (freie Filmliste), https://mediathekviewweb.de/api/query
# ==========================================================================
MV_API = "https://mediathekviewweb.de/api/query"
MV_PAGE = 30
_mv_cache = {}
_MV_SKIP = re.compile(r"audiodeskription|hörfassung|gebärdensprache|\(dgs\)|klare sprache|trailer|teaser", re.I)


def _mv_query(q, offset):
    body = json.dumps({"queries": [{"fields": ["title", "topic"], "query": q}], "sortBy": "timestamp", "sortOrder": "desc",
                       "future": False, "offset": offset, "size": MV_PAGE * 2, "duration_min": 120}).encode()
    # Der Dienst erwartet JSON mit Content-Type text/plain
    req = urllib.request.Request(MV_API, data=body, method="POST",
                                 headers={"Content-Type": "text/plain", "User-Agent": "Raspi-TV/1.0 (Mediatheken-Suche)"})
    try:
        with urllib.request.urlopen(req, timeout=12) as r:
            data = json.loads(r.read(4_000_000))
    except (OSError, ValueError):
        raise _err("Die Mediatheken-Suche ist gerade nicht erreichbar – bitte später noch einmal versuchen.", 502)
    if data.get("err"):
        raise _err("Die Mediatheken-Suche hat einen Fehler gemeldet.", 502)
    return data.get("result") or {}


def _mv_item(r):
    url = r.get("url_video_hd") or r.get("url_video") or r.get("url_video_low") or ""
    if not url.startswith(("http://", "https://")):
        return None
    return {"id": str(r.get("id") or url)[:80], "channel": str(r.get("channel") or "")[:20],
            "topic": str(r.get("topic") or "")[:120], "title": str(r.get("title") or "")[:160],
            "desc": str(r.get("description") or "").strip()[:600], "ts": int(r.get("timestamp") or 0),
            "dur": int(r.get("duration") or 0), "url": url, "url_sd": r.get("url_video") or url,
            "web": r.get("url_website") or "", "sub": r.get("url_subtitle") or ""}


def mediathek_search(query, headers=None):
    q = re.sub(r"\s+", " ", (query.get("q") or [""])[0]).strip()[:80]
    try:
        offset = max(0, min(600, int((query.get("offset") or ["0"])[0])))
    except ValueError:
        offset = 0
    if len(q) < 2:
        return {"results": [], "total": 0, "more": False}
    key = (q.lower(), offset)
    hit = _mv_cache.get(key)
    if hit and time.time() - hit[0] < 600:
        return hit[1]
    res = _mv_query(q, offset)
    keep_special = bool(_MV_SKIP.search(q))         # wer danach sucht, bekommt sie auch
    items, seen = [], set()
    for r in res.get("results") or []:
        it = _mv_item(r)
        if not it or (not keep_special and _MV_SKIP.search(it["title"] + " " + it["topic"])):
            continue
        dup = (it["title"].lower(), it["dur"] // 60)      # dieselbe Sendung auf mehreren Kanälen nur einmal
        if dup in seen:
            continue
        seen.add(dup)
        items.append(it)
        if len(items) >= MV_PAGE:
            break
    total = int((res.get("queryInfo") or {}).get("totalResults") or 0)
    out = {"results": items, "total": total, "more": offset + MV_PAGE * 2 < total, "next": offset + MV_PAGE * 2}
    if len(_mv_cache) > 60:
        _mv_cache.clear()
    _mv_cache[key] = (time.time(), out)
    return out


QUERY_ROUTES["/api/mediathek/search"] = mediathek_search


# ---- Weiterschauen für Mediathek-Videos (laufen im eigenen Player von Raspi-TV)
def mediathek_progress(data):
    url, link = str(data.get("video") or ""), str(data.get("link") or "")
    pos, dur = data.get("pos"), data.get("dur")
    if not url.startswith(("http://", "https://")) or not link.startswith("/player.html?") or len(link) > 1500 \
            or type(pos) not in (int, float) or type(dur) not in (int, float):
        raise _err("Ungültige Angaben")
    key = "mv:" + hashlib.sha1(url.encode()).hexdigest()[:16]
    if dur < 240 or dur > 6 * 3600:
        return {"ok": True}
    with _cont_lock:
        lst = _cont_load().setdefault(_cont_profile(), [])
        old = next((e for e in lst if e["key"] == key), None)
        if dur - pos < max(60, dur * 0.05):
            if old:
                lst.remove(old)
                _cont_save(force=True)
            return {"ok": True}
        if pos < 60 and not old:
            return {"ok": True}
        e = old or {"key": key}
        e.update(url=link, pos=int(pos), dur=int(dur), at=int(time.time()), cover="",
                 title=str(data.get("title") or "")[:120], site=str(data.get("site") or "Mediathek")[:40])
        if not old:
            lst.insert(0, e)
        else:
            lst.sort(key=lambda x: -x["at"])
        del lst[CONT_MAX:]
        _cont["dirty"] = True
        _cont_save(force=not old)
    return {"ok": True}


POST_ROUTES["/api/mediathek/progress"] = mediathek_progress
