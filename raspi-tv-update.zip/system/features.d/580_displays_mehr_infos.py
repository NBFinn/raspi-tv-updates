# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.6.0: Mehr Seiten auf den runden Displays – „Heute“ (Datum, Kalenderwoche, Sonnenauf- und
#   -untergang), „Netz“ (Internet, Antwortzeit, IP-Adresse), „Programm“ (nächste Aufnahme und
#   Erinnerung) und „Verbunden“ (Handy, Fernbedienungs-WLAN)
# ==========================================================================
ROUND_PAGES_DEFAULT = (0xF7, 0x1F)       # alle Seiten an (Countdown/Wetter erscheinen nur mit Daten)
_netinfo = {"at": 0.0, "ip": "", "ping": -1, "hs_at": 0.0, "hs": -1}


def _local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("192.0.2.1", 9))             # nichts wird gesendet – nur die Absenderadresse ermitteln
            return s.getsockname()[0]
        finally:
            s.close()
    except OSError:
        return ""


def _ping_ms():
    """Antwortzeit ins Internet: Verbindungsaufbau zu einem großen DNS-Dienst (kein ICMP nötig)."""
    best = None
    for host in ("1.1.1.1", "8.8.8.8"):
        t = time.monotonic()
        try:
            with socket.create_connection((host, 443), timeout=2):
                ms = int((time.monotonic() - t) * 1000)
                best = ms if best is None else min(best, ms)
                break
        except OSError:
            continue
    return -1 if best is None else max(1, best)


def _netinfo_refresh():
    now = time.time()
    if now - _netinfo["at"] > 60:
        _netinfo.update(at=now, ip=_local_ip(), ping=_ping_ms())
    if now - _netinfo["hs_at"] > 30:
        try:
            _netinfo["hs"] = (_hs_clients(_wifi_dev()) or 0) if _hs_active() else -1
        except Exception:  # noqa: BLE001
            _netinfo["hs"] = -1
        _netinfo["hs_at"] = now


def _netinfo_loop():
    while True:
        try:
            _netinfo_refresh()
        except Exception:  # noqa: BLE001
            pass
        time.sleep(15)


def _next_programs(now=None):
    now = now or time.time()
    out = {}
    try:
        rec = next((i for i in _rec().schedule() if i["status"] == "planned" and i["start"] > now - 60), None)
        if rec:
            out["rec"] = {"start": int(rec["start"]), "title": str(rec.get("title") or "")[:90], "channel": str(rec.get("channel") or "")[:38]}
    except Exception:  # noqa: BLE001
        pass
    try:
        rem = min((r for r in _reminders() if r.get("start", 0) > now - 60), key=lambda r: r["start"], default=None)
        if rem:
            out["rem"] = {"start": int(rem["start"]), "title": str(rem.get("title") or "")[:90], "channel": str(rem.get("channel") or "")[:38]}
    except Exception:  # noqa: BLE001
        pass
    return out


_round_state_76 = round_display_state


def round_display_state():  # noqa: F811
    st = _round_state_76()
    st["net"] = {"ip": _netinfo["ip"], "ping": _netinfo["ping"], "hotspot": _netinfo["hs"],
                 "phone": next(iter(_btr["clients"].values()), "") if _btr.get("clients") else ""}
    st.update(_next_programs())
    try:
        w = _weather["data"] if _weather.get("data") and time.time() - _weather["at"] < 6 * 3600 else None
        day0 = ((w or {}).get("days") or [{}])[0]
        if day0.get("sunrise"):
            st["sun"] = {"rise": day0["sunrise"], "set": day0.get("sunset", "")}
    except Exception:  # noqa: BLE001
        pass
    return st


GET_ROUTES["/api/round-display"] = round_display_state
_old_start20 = start_background


def _round_pages_migrate_76():
    """Wer die Seiten schon einmal gewählt hat, bekommt die neuen Seiten einmalig dazu."""
    with _profile_lock:
        cfg = _cfg()
        pages = cfg.get("round_pages")
        if cfg.get("round_pages_v76") or not (isinstance(pages, list) and len(pages) == 2):
            return
        cfg["round_pages"] = [pages[0] | 0xC0, pages[1] | 0x18]
        cfg["round_pages_v76"] = True
        _save(cfg)


def start_background():  # noqa: F811
    _old_start20()
    try:
        _round_pages_migrate_76()
    except Exception as e:  # noqa: BLE001
        print("Seiten der runden Displays:", e, flush=True)
    threading.Thread(target=_netinfo_loop, daemon=True).start()
