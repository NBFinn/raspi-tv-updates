# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.5.0: Hintergrundaufgaben der neuen Teile starten
# ==========================================================================
_old_start19 = start_background


def start_background():  # noqa: F811
    _old_start19()
    threading.Thread(target=_health_loop, daemon=True).start()
    threading.Thread(target=_support_watch, daemon=True).start()

    def tune():
        time.sleep(90)                    # erst wenn alles läuft
        try:
            boot_tune()
        except Exception as e:  # noqa: BLE001
            print("Schnellerer Start:", e, flush=True)
    threading.Thread(target=tune, daemon=True).start()
