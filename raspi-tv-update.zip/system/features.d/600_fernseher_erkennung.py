# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.7.0: Merken, ob der Fernseher aus ist – und dann selbst in Standby gehen
#   Quellen (jede zählt nur, wenn sie wirklich einen Wechsel an → aus gesehen hat):
#    - HDMI-Hotplug: viele Fernseher ziehen im Standby die Hotplug-Leitung weg (ohne CEC)
#    - CEC: regelmäßige Abfrage „bist du an?“ (in cec-remote.py)
#    - GPIO: 5 V vom USB-Anschluss des Fernsehers über Optokoppler an einen Pin (ohne CEC, sicher)
#    - Shelly-Steckdose: Stromverbrauch des Fernsehers (ohne CEC, sicher)
#   Fernseher aus (für „delay“ Sekunden) → Raspi-TV geht in Standby.
#   Fernseher wieder an → Raspi-TV wacht auf (abschaltbar).
# ==========================================================================
TV_DETECT_DEFAULT = {"auto_standby": True, "wake": True, "delay": 20,
                     "gpio": {"on": False, "pin": 17, "on_level": "high", "pull": "down"},
                     "shelly": {"host": "", "watts": 15}}


def tv_detect_valid(v):
    if not isinstance(v, dict) or not set(v) <= {"auto_standby", "wake", "delay", "gpio", "shelly"}:
        return False
    if not isinstance(v.get("auto_standby", True), bool) or not isinstance(v.get("wake", True), bool):
        return False
    if type(v.get("delay", 20)) is not int or not 5 <= v.get("delay", 20) <= 600:
        return False
    g = v.get("gpio", {})
    if not isinstance(g, dict) or not set(g) <= {"on", "pin", "on_level", "pull"} or not isinstance(g.get("on", False), bool):
        return False
    if type(g.get("pin", 17)) is not int or not 2 <= g.get("pin", 17) <= 27 or g.get("pin", 17) == 26:
        return False
    if g.get("on_level", "high") not in ("high", "low") or g.get("pull", "down") not in ("up", "down", "none"):
        return False
    s = v.get("shelly", {})
    if not isinstance(s, dict) or not set(s) <= {"host", "watts"}:
        return False
    if not isinstance(s.get("host", ""), str) or not re.fullmatch(r"[A-Za-z0-9.\-]{0,253}(:\d{1,5})?", s.get("host", "")):
        return False
    return type(s.get("watts", 15)) in (int, float) and 1 <= s.get("watts", 15) <= 500


def _tvd_cfg():
    c = _cfg().get("tv_detect") or {}
    out = dict(TV_DETECT_DEFAULT)
    out.update({k: c[k] for k in ("auto_standby", "wake", "delay") if k in c})
    out["gpio"] = dict(TV_DETECT_DEFAULT["gpio"], **(c.get("gpio") or {}))
    out["shelly"] = dict(TV_DETECT_DEFAULT["shelly"], **(c.get("shelly") or {}))
    return out


class _TvSource:
    """Eine Erkennungsquelle: entprellt (Zustand muss eine Weile stabil sein) und merkt sich, ob sie
    schon einmal einen echten Wechsel gesehen hat – erst dann ist sie verlässlich."""

    def __init__(self, name):
        self.name = name
        self.raw = None          # True = an, False = aus, None = unbekannt
        self.raw_since = 0.0
        self.stable = None
        self.seen_change = False
        self.detail = ""
        self.error = ""

    def feed(self, val, now):
        if val != self.raw:
            self.raw, self.raw_since = val, now
        return self

    def settle(self, now, off_delay, on_delay=3):
        """Gibt "off"/"on" zurück, wenn der stabile Zustand gerade gewechselt hat."""
        if self.raw is None:
            return None
        need = off_delay if self.raw is False else on_delay
        if self.raw == self.stable or now - self.raw_since < need:
            return None
        before, self.stable = self.stable, self.raw
        if before is None:           # erster Wert nach dem Start: nur merken, nichts auslösen
            return None
        self.seen_change = True
        return "on" if self.raw else "off"


_tvd = {"src": {n: _TvSource(n) for n in ("hdmi", "cec", "gpio", "shelly")}, "events": [],
        "pin": None, "pin_key": None, "shelly_at": 0.0}


def _tvd_event(text):
    _tvd["events"] = (_tvd["events"] + [{"at": int(time.time()), "text": text}])[-8:]
    print("Fernseher-Erkennung:", text, flush=True)


def _hdmi_ports():
    """{"HDMI-A-1": True/False} aus /sys/class/drm (Hotplug-Leitung des Fernsehers)."""
    ports = {}
    for p in sorted(glob.glob("/sys/class/drm/card*-HDMI-A-*/status")):
        try:
            with open(p) as f:
                st = f.read().strip()
        except OSError:
            continue
        name = p.split("/")[-2].split("-", 1)[1]
        ports[name] = st == "connected"
    return ports


def _hdmi_state():
    ports = _hdmi_ports()
    src = _tvd["src"]["hdmi"]
    src.detail = ", ".join(f"{k}: {'verbunden' if v else 'getrennt'}" for k, v in ports.items())
    if not ports:
        src.error = "Kein HDMI-Anschluss gefunden"
        return None
    src.error = ""
    return any(ports.values())


def _gpio_state(g):
    src = _tvd["src"]["gpio"]
    if not g.get("on"):
        if _tvd["pin"]:
            try:
                _tvd["pin"].close()
            except Exception:  # noqa: BLE001
                pass
        _tvd["pin"] = _tvd["pin_key"] = None
        src.error = src.detail = ""
        return None
    key = (g["pin"], g["pull"])
    if _tvd["pin_key"] != key:
        if _tvd["pin"]:
            try:
                _tvd["pin"].close()
            except Exception:  # noqa: BLE001
                pass
        _tvd["pin"] = None
        try:
            import importlib.util
            path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "powerfail.py")
            spec = importlib.util.spec_from_file_location("raspi_tv_powerfail", path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            _tvd["pin"] = mod.Pin(g["pin"], g["pull"])
            src.error = ""
        except Exception as e:  # noqa: BLE001
            src.error = f"GPIO {g['pin']} nicht lesbar: {e}"[:160]
        _tvd["pin_key"] = key
    if not _tvd["pin"]:
        return None
    try:
        high = bool(_tvd["pin"].read())
    except Exception as e:  # noqa: BLE001
        src.error = f"GPIO lesen: {e}"[:160]
        return None
    src.detail = f"GPIO {g['pin']} ist {'HIGH' if high else 'LOW'}"
    return high == (g["on_level"] == "high")


def _shelly_watts(host):
    """Momentanleistung einer Shelly-Steckdose (Gen2/Gen3/Plus, sonst Gen1)."""
    for path, pick in (("/rpc/Switch.GetStatus?id=0", lambda d: d.get("apower")),
                       ("/status", lambda d: (d.get("meters") or [{}])[0].get("power"))):
        try:
            with urllib.request.urlopen(f"http://{host}{path}", timeout=3) as r:
                w = pick(json.loads(r.read().decode() or "{}"))
            if isinstance(w, (int, float)):
                return float(w)
        except Exception:  # noqa: BLE001
            continue
    return None


def _shelly_state(s, now):
    src = _tvd["src"]["shelly"]
    if not s.get("host"):
        src.error = src.detail = ""
        return None
    if now - _tvd["shelly_at"] < 5:              # höchstens alle 5 s fragen
        return src.raw
    _tvd["shelly_at"] = now
    w = _shelly_watts(s["host"])
    if w is None:
        src.error = f"Steckdose {s['host']} antwortet nicht"
        src.detail = ""
        return None
    src.error = ""
    src.detail = f"{w:.1f} W (an ab {s['watts']} W)"
    return w >= s["watts"]


def _cec_state():
    """CEC fragt cec-remote.py selbst regelmäßig ab und schreibt tv-power; hier nur die Anzeige."""
    src = _tvd["src"]["cec"]
    try:
        with open("/run/raspi-tv/cec-poll") as f:
            st = f.read().strip()
    except OSError:
        src.detail = ""
        return None
    src.detail = {"on": "Fernseher meldet: an", "standby": "Fernseher meldet: Standby"}.get(st, "Fernseher antwortet nicht")
    return {"on": True, "standby": False}.get(st)


def _tvd_follow_power():
    """Stellt jemand anderes (CEC-Dienst) den Zustand um, das Bild passend nachziehen – sonst bliebe es
    nach „Fernseher wieder an“ schwarz, weil der Standby-Wächter es immer wieder abschaltet."""
    p = T["tv_power"]()
    last, _tvd["power"] = _tvd.get("power"), p
    if p == last or last is None:
        return
    if p == "on" and _signal["off"]:
        hdmi_signal(True)
    elif p == "standby" and not _signal["off"] and _signal_off_wanted():
        hdmi_signal(False)


def _tvd_tick(now):
    _tvd_follow_power()
    c = _tvd_cfg()
    vals = {"hdmi": _hdmi_state(), "cec": _cec_state(), "gpio": _gpio_state(c["gpio"]), "shelly": _shelly_state(c["shelly"], now)}
    changes = []
    for name, v in vals.items():
        ch = _tvd["src"][name].feed(v, now).settle(now, c["delay"])
        if ch:
            changes.append((name, ch))
    labels = {"hdmi": "HDMI", "cec": "CEC", "gpio": "USB-Strom (GPIO)", "shelly": "Steckdose"}
    for name, ch in changes:
        if name == "cec":
            continue                  # CEC stellt den Zustand schon selbst um (cec-remote.py)
        standby = T["tv_power"]() == "standby"
        if ch == "off":
            if c["auto_standby"] and not standby:
                _tvd_event(f"Fernseher aus ({labels[name]}) – Raspi-TV geht in Standby")
                T["tv_standby"]()
                _set_tv_power("standby")
                touch_activity()
            else:
                _tvd_event(f"Fernseher aus ({labels[name]})")
        elif ch == "on":
            if c["wake"] and standby:
                _tvd_event(f"Fernseher an ({labels[name]}) – Raspi-TV wacht auf")
                _set_tv_power("on")
                touch_activity()
            else:
                _tvd_event(f"Fernseher an ({labels[name]})")


def _tvd_loop():
    time.sleep(20)                 # nach dem Start erst alles hochkommen lassen
    while True:
        try:
            _tvd_tick(time.time())
        except Exception as e:  # noqa: BLE001 – Hintergrundschleife darf nie sterben
            print("Fernseher-Erkennung:", e, flush=True)
        time.sleep(2)


def tv_detect_status():
    c = _tvd_cfg()
    srcs = {}
    for name, s in _tvd["src"].items():
        srcs[name] = {"state": None if s.raw is None else ("on" if s.raw else "off"),
                      "seen_change": s.seen_change, "detail": s.detail, "error": s.error}
    c.update(sources=srcs, events=_tvd["events"][::-1], tv=T["tv_power"](), gpio_pins_used=_gpio_used())
    return c


GET_ROUTES["/api/tv-detect"] = tv_detect_status
_old_start21 = start_background


def start_background():  # noqa: F811
    _old_start21()
    threading.Thread(target=_tvd_loop, daemon=True).start()
