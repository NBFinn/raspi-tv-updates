# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.7.1: Sender ohne Signal automatisch ausblenden
#   Raspi-TV prüft alle Sender selbst (Senderliste → Videoliste → erstes Videostück). Wer zweimal
#   hintereinander nichts liefert (abgeschaltet, nur im Ausland, Sonderkanal gerade leer), verschwindet
#   aus der Senderliste und taucht von selbst wieder auf, sobald er wieder sendet.
#    - alle Sender: 2 Minuten nach dem Start, danach alle 6 Stunden
#    - Sender ohne Signal: alle 30 Minuten (Sonderkanäle senden nur zu bestimmten Zeiten)
#    - bleibt beim Fernsehen ein Sender schwarz, wird er sofort geprüft
#   Ist das Internet weg, wird nichts ausgeblendet.
# ==========================================================================
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urljoin
import urllib.error

CHAN_HEALTH = "channel-health.json"
_CK_UA = "Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
_ck = {"data": None, "running": False, "done": 0, "total": 0, "last_full": 0, "last_dead": 0, "lock": threading.Lock(),
       "offline": False}


def _ck_data():
    if _ck["data"] is None:
        d = _read_json(_state(CHAN_HEALTH), {}) or {}
        _ck["data"] = d if isinstance(d, dict) else {}
    return _ck["data"]


def _ck_save():
    with _ck["lock"]:
        data = dict(_ck_data())
    try:
        _write_json(_state(CHAN_HEALTH), data)
    except OSError:
        pass


def _ck_get(url, rng=False, limit=400_000):
    hdr = {"User-Agent": _CK_UA}
    if rng:
        hdr["Range"] = "bytes=0-8191"
    req = urllib.request.Request(url, headers=hdr)
    with urllib.request.urlopen(req, timeout=8) as r:
        return r.geturl(), r.read(limit)


def channel_probe(url):
    """(True, "") wenn Bild kommen würde, sonst (False, Grund)."""
    try:
        final, body = _ck_get(url)
    except urllib.error.HTTPError as e:
        return False, "Gesperrt (nur im Ausland?)" if e.code in (401, 403, 451) else f"Server meldet Fehler {e.code}"
    except Exception:  # noqa: BLE001
        return False, "Nicht erreichbar"
    text = body.decode("utf-8", "replace")
    if "#EXTM3U" not in text[:2048]:
        return (True, "") if body else (False, "Sendet nichts")
    for _ in range(4):
        lines = [l.strip() for l in text.splitlines()]
        if any(l.startswith("#EXT-X-STREAM-INF") for l in lines):
            nxt = None
            for i, l in enumerate(lines):
                if l.startswith("#EXT-X-STREAM-INF"):
                    nxt = next((x for x in lines[i + 1:] if x and not x.startswith("#")), None)
                    break
            if not nxt:
                return False, "Senderliste leer"
            try:
                final, body = _ck_get(urljoin(final, nxt))
            except urllib.error.HTTPError as e:
                return False, "Gesperrt (nur im Ausland?)" if e.code in (401, 403, 451) else f"Server meldet Fehler {e.code}"
            except Exception:  # noqa: BLE001
                return False, "Nicht erreichbar"
            text = body.decode("utf-8", "replace")
            continue
        segs = [l for l in lines if l and not l.startswith("#")]
        if not segs:
            return False, "Sendet gerade nicht"
        try:
            _ck_get(urljoin(final, segs[-1]), rng=True, limit=8192)
            return True, ""
        except urllib.error.HTTPError as e:
            return False, "Gesperrt (nur im Ausland?)" if e.code in (401, 403, 451) else "Video nicht abrufbar"
        except Exception:  # noqa: BLE001
            return False, "Video nicht abrufbar"
    return False, "Zu viele Weiterleitungen"


def _ck_online():
    for host in ("1.1.1.1", "8.8.8.8"):
        try:
            socket.create_connection((host, 443), timeout=4).close()
            return True
        except OSError:
            continue
    return False


def _ck_record(url, ok, why, strong=False):
    now = int(time.time())
    with _ck["lock"]:
        d = _ck_data()
        e = d.get(url) or {"fails": 0}
        if ok:
            d[url] = {"ok": True, "fails": 0, "at": now}
        else:
            fails = max(e.get("fails", 0) + 1, 2 if strong else 0)
            d[url] = {"ok": False, "fails": fails, "at": now, "why": why}


def channel_dead(url):
    e = _ck_data().get(url)
    return bool(e) and not e.get("ok") and e.get("fails", 0) >= 2


def _ck_run(only_dead=False):
    if _ck["running"]:
        return False
    chans = {c["url"]: c for c in _all_channels_dead_base(True)}
    urls = [u for u in chans if not only_dead or channel_dead(u) or not (_ck_data().get(u) or {}).get("ok", True)]
    if not urls:
        return False
    _ck.update(running=True, done=0, total=len(urls))
    try:
        if not _ck_online():
            _ck["offline"] = True
            return False
        _ck["offline"] = False
        results = {}

        def one(u):
            r = channel_probe(u)
            _ck["done"] += 1
            return u, r
        with ThreadPoolExecutor(max_workers=12) as ex:
            for u, r in ex.map(one, urls):
                results[u] = r
        bad = sum(1 for ok, _ in results.values() if not ok)
        # fällt (fast) alles aus, liegt es am Internet und nicht an den Sendern
        if len(results) >= 20 and bad > 0.8 * len(results) and not _ck_online():
            _ck["offline"] = True
            return False
        for u, (ok, why) in results.items():
            _ck_record(u, ok, why)
        # Einträge für Adressen, die es nicht mehr gibt, aufräumen
        with _ck["lock"]:
            for u in [u for u in _ck_data() if u not in chans]:
                _ck_data().pop(u, None)
        _ck["last_dead" if only_dead else "last_full"] = int(time.time())
        _ck_save()
        print(f"Senderprüfung: {len(results) - bad} von {len(results)} senden", flush=True)
        return True
    finally:
        _ck["running"] = False


def _ck_loop():
    time.sleep(120)
    while True:
        try:
            now = time.time()
            if now - _ck["last_full"] > 6 * 3600:
                _ck_run()
            elif now - max(_ck["last_dead"], _ck["last_full"]) > 30 * 60:
                _ck_run(only_dead=True)
        except Exception as e:  # noqa: BLE001
            print("Senderprüfung:", e, flush=True)
            _ck["running"] = False
        time.sleep(60)


def channel_check_status():
    d = _ck_data()
    chans = _all_channels_dead_base(True)
    dead = [c["name"] for c in chans if channel_dead(c["url"])]
    return {"running": _ck["running"], "done": _ck["done"], "total": _ck["total"], "last": _ck["last_full"] or None,
            "offline": _ck["offline"], "dead": len(dead), "count": len(chans),
            "hide": _cfg().get("channel_hide_dead", True) is not False}


def channel_check_start(_data=None):
    if _ck["running"]:
        return channel_check_status()
    threading.Thread(target=_ck_run, daemon=True).start()
    time.sleep(0.2)
    return channel_check_status()


def channel_no_signal(data):
    """Der Fernseher meldet: bei diesem Sender kommt kein Bild. Sofort nachprüfen."""
    url = str((data or {}).get("url") or "")
    if not url.startswith(("http://", "https://")):
        return {"dead": False}
    if not any(c["url"] == url for c in _all_channels_dead_base(True)):
        return {"dead": False}
    ok, why = channel_probe(url)
    if not ok and _ck_online():
        _ck_record(url, False, why, strong=True)
        _ck_save()
        return {"dead": True, "why": why}
    if ok:
        _ck_record(url, True, "")
    return {"dead": False}


# Senderliste: Sender ohne Signal ausblenden (in den Einstellungen sichtbar und markiert)
_all_channels_dead_base = all_channels


def all_channels(include_hidden=False):  # noqa: F811
    lst = _all_channels_dead_base(include_hidden)
    if include_hidden:
        for c in lst:
            e = _ck_data().get(c["url"])
            if channel_dead(c["url"]):
                c["dead"] = True
                c["why"] = (e or {}).get("why", "")
        return lst
    if _cfg().get("channel_hide_dead", True) is False:
        return lst
    out = [c for c in lst if not channel_dead(c["url"])]
    return out or lst


GET_ROUTES["/api/channels"] = all_channels
GET_ROUTES["/api/channels/check"] = channel_check_status
POST_ROUTES["/api/channels/check"] = channel_check_start
POST_ROUTES["/api/channels/no-signal"] = channel_no_signal
_old_start22 = start_background


def start_background():  # noqa: F811
    _old_start22()
    threading.Thread(target=_ck_loop, daemon=True).start()
