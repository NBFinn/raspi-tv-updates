# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.8.0: Ton passt nicht zum Bild bei Bluetooth-Kopfhörern
#   Bluetooth-Ton kommt je nach Kopfhörer 100–300 ms zu spät. Raspi-TV meldet diese Verzögerung
#   dem Tonsystem (PipeWire: „latency offset“ des Kopfhörer-Ausgangs). Der Browser hält dann das Bild
#   genau so lange zurück – Lippen und Ton passen wieder. Der Wert wird je Kopfhörer gemerkt.
# ==========================================================================
BT_DELAY_STEPS = [0, 50, 100, 150, 200, 250, 300, 400, 500]
_btd = {"applied": {}}


def bt_delay_valid(v):
    return (isinstance(v, dict) and len(v) <= 40
            and all(isinstance(k, str) and re.fullmatch(r"[0-9A-F]{2}(:[0-9A-F]{2}){5}", k) for k in v)
            and all(type(x) is int and 0 <= x <= 1000 for x in v.values()))


def _bt_cards():
    """Verbundene Bluetooth-Tongeräte: [{mac, name, card, ports: {port: offset_ms}}]."""
    code, out, _ = T["as_tv"](["env", "LC_ALL=C", "pactl", "list", "cards"], 10)
    if code != 0:
        return []
    cards, cur, in_ports = [], None, False
    for line in out.splitlines():
        s = line.strip()
        if line.startswith("Card #"):
            cur, in_ports = None, False
            continue
        if s.startswith("Name: "):
            name = s[6:]
            m = re.fullmatch(r"bluez_card\.([0-9A-F]{2}(?:_[0-9A-F]{2}){5})", name)
            cur = {"mac": m.group(1).replace("_", ":"), "name": "", "card": name, "ports": {}} if m else None
            if cur:
                cards.append(cur)
            continue
        if not cur:
            continue
        if s.startswith("device.description = "):
            cur["name"] = s.split("=", 1)[1].strip().strip('"')
        elif s == "Ports:":
            in_ports = True
        elif s.startswith("Active Profile") or s.startswith("Profiles:"):
            in_ports = False
        elif in_ports:
            m = re.match(r"([\w.-]+): .*latency offset: (-?\d+) usec", s)
            if m and "output" in m.group(1):
                cur["ports"][m.group(1)] = round(int(m.group(2)) / 1000)
    return cards


def _bt_delay_cfg():
    d = _cfg().get("bt_delay") or {}
    return d if isinstance(d, dict) else {}


def bt_delay_apply():
    want = _bt_delay_cfg()
    for c in _bt_cards():
        ms = int(want.get(c["mac"], 0))
        for port, cur in c["ports"].items():
            if cur != ms:
                T["as_tv"](["pactl", "set-port-latency-offset", c["card"], port, str(ms * 1000)], 10)
                print(f"Bluetooth-Tonausgleich: {c['name'] or c['mac']} {port} = {ms} ms", flush=True)


def bt_delay_status():
    want = _bt_delay_cfg()
    devs = [{"mac": c["mac"], "name": c["name"] or c["mac"], "ms": int(want.get(c["mac"], 0))} for c in _bt_cards() if c["ports"]]
    return {"devices": devs, "steps": BT_DELAY_STEPS}


def bt_delay_set(data):
    mac = str((data or {}).get("mac", "")).upper()
    ms = (data or {}).get("ms")
    if not re.fullmatch(r"[0-9A-F]{2}(:[0-9A-F]{2}){5}", mac) or type(ms) is not int or not 0 <= ms <= 1000:
        raise T["ApiError"]("Ungültige Angabe")
    cfg = _cfg()
    d = dict(cfg.get("bt_delay") or {})
    if ms:
        d[mac] = ms
    else:
        d.pop(mac, None)
    cfg["bt_delay"] = d
    _save(cfg)
    bt_delay_apply()
    return bt_delay_status()


def _bt_delay_loop():
    time.sleep(30)
    while True:
        try:
            if _bt_delay_cfg():
                bt_delay_apply()       # Kopfhörer neu verbunden → Wert wieder setzen
        except Exception as e:  # noqa: BLE001
            print("Bluetooth-Tonausgleich:", e, flush=True)
        time.sleep(6)


GET_ROUTES["/api/bt-delay"] = bt_delay_status
POST_ROUTES["/api/bt-delay"] = bt_delay_set
_old_start23 = start_background


def start_background():  # noqa: F811
    _old_start23()
    threading.Thread(target=_bt_delay_loop, daemon=True).start()
