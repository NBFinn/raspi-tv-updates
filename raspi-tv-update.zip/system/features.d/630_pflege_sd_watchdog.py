# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.8.0: Länger halten, nie hängen bleiben
#   - SD-Karte schonen: Protokolle klein halten und seltener schreiben, Dateizugriffszeiten nicht
#     mitschreiben, Daten länger im Arbeitsspeicher sammeln, Browser-Zwischenspeicher im RAM
#     (start-browser.sh). Die Karte hält länger und geht bei Stromausfall seltener kaputt.
#   - Absturz-Wächter: Friert der Pi komplett ein, startet ihn der eingebaute Watchdog nach 15 s neu.
#   - Browser nachts auffrischen: im Standby zwischen 3 und 5 Uhr unbemerkt neu starten (Chromium
#     wird nach vielen Stunden träge und braucht immer mehr Speicher).
# ==========================================================================
CARE_FILES = {
    "/etc/systemd/journald.conf.d/raspi-tv.conf":
        "# Raspi-TV: SD-Karte schonen\n[Journal]\nSystemMaxUse=48M\nSyncIntervalSec=10m\nCompress=yes\nMaxRetentionSec=14day\n",
    "/etc/sysctl.d/90-raspi-tv.conf":
        "# Raspi-TV: SD-Karte schonen (seltener schreiben, kaum auslagern)\nvm.swappiness=10\nvm.dirty_writeback_centisecs=1500\nvm.dirty_expire_centisecs=3000\n",
}
WATCHDOG_FILE = "/etc/systemd/system.conf.d/raspi-tv-watchdog.conf"
WATCHDOG_CONF = "# Raspi-TV: Absturz-Wächter (Pi startet neu, wenn das System einfriert)\n[Manager]\nRuntimeWatchdogSec=15s\nRebootWatchdogSec=2min\n"
CARE_STATE = "care.json"
_care = {"sd": None, "watchdog": None, "fstab": None, "errors": []}


def _care_write(path, text):
    """Schreibt nur, wenn sich etwas ändert. True = geändert."""
    try:
        with open(path) as f:
            if f.read() == text:
                return False
    except OSError:
        pass
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        f.write(text)
    os.replace(tmp, path)
    return True


def _fstab_root_opts(text):
    """fstab: beim Wurzel-Dateisystem (ext4) noatime und commit=60 ergänzen. Gibt neuen Text oder None."""
    out, changed = [], False
    for line in text.splitlines():
        parts = line.split()
        if len(parts) >= 4 and not line.lstrip().startswith("#") and parts[1] == "/" and parts[2] == "ext4":
            opts = [o for o in parts[3].split(",") if o]
            add = [o for o in ("noatime", "commit=60") if o not in opts and not (o == "commit=60" and any(x.startswith("commit=") for x in opts))]
            if add:
                opts = [o for o in opts if o != "relatime"] + add
                parts[3] = ",".join(opts)
                line = "\t".join(parts)
                changed = True
        out.append(line)
    return ("\n".join(out) + "\n") if changed else None


def care_setup():
    errs = []
    # SD-Karte schonen
    try:
        ch = [p for p, t in CARE_FILES.items() if _care_write(p, t)]
        if "/etc/systemd/journald.conf.d/raspi-tv.conf" in ch:
            T["run"](["systemctl", "restart", "systemd-journald"], 30)
        if "/etc/sysctl.d/90-raspi-tv.conf" in ch:
            T["run"](["sysctl", "-q", "-p", "/etc/sysctl.d/90-raspi-tv.conf"], 10)
        try:
            with open("/etc/fstab") as f:
                old = f.read()
            new = _fstab_root_opts(old)
            if new:
                shutil.copy2("/etc/fstab", "/etc/fstab.raspi-tv-backup")
                _care_write("/etc/fstab", new)
                T["run"](["systemctl", "daemon-reload"], 30)
            T["run"](["mount", "-o", "remount,noatime,commit=60", "/"], 15)
            _care["fstab"] = True
        except OSError as e:
            errs.append(f"fstab: {e}")
        _care["sd"] = True
    except OSError as e:
        _care["sd"] = False
        errs.append(f"SD-Karte schonen: {e}")
    # Absturz-Wächter
    if os.path.exists("/dev/watchdog") or os.path.exists("/dev/watchdog0"):
        try:
            if _care_write(WATCHDOG_FILE, WATCHDOG_CONF):
                T["run"](["systemctl", "daemon-reexec"], 60)
            _care["watchdog"] = True
        except OSError as e:
            _care["watchdog"] = False
            errs.append(f"Watchdog: {e}")
    else:
        _care["watchdog"] = False
        errs.append("Kein Hardware-Watchdog gefunden")
    _care["errors"] = errs


# ---- Browser nachts auffrischen
def _browser_age():
    code, out, _ = T["run"](["pgrep", "-o", "-u", T["TV_USER"], "-f", "raspi-tv-browser"], 10)
    pid = out.strip().splitlines()[0] if code == 0 and out.strip() else ""
    if not pid:
        return None
    code, out, _ = T["run"](["ps", "-o", "etimes=", "-p", pid], 10)
    try:
        return int(out.strip())
    except ValueError:
        return None


def _audio_playing():
    code, out, _ = T["as_tv"](["pactl", "list", "sink-inputs", "short"], 10)
    return code == 0 and bool(out.strip())


def night_refresh_due(now=None):
    """Im Standby, 3–5 Uhr, Browser läuft schon > 12 h, heute noch nicht aufgefrischt, kein Ton."""
    now = now or time.time()
    lt = time.localtime(now)
    if not 3 <= lt.tm_hour < 5 or _cfg().get("night_refresh", True) is False:
        return False
    if T["tv_power"]() != "standby":
        return False
    st = _read_json(_state(CARE_STATE), {}) or {}
    if now - st.get("refreshed", 0) < 20 * 3600:
        return False
    age = _browser_age()
    return age is not None and age > 12 * 3600 and not _audio_playing()


def night_refresh():
    st = _read_json(_state(CARE_STATE), {}) or {}
    st["refreshed"] = int(time.time())
    _write_json(_state(CARE_STATE), st)
    print("Browser wird nachts aufgefrischt (Standby)", flush=True)
    T["run"](["pkill", "-u", T["TV_USER"], "-f", "raspi-tv-browser"], 10)   # start-browser.sh startet ihn neu


def _care_loop():
    time.sleep(150)
    try:
        care_setup()
    except Exception as e:  # noqa: BLE001
        _care["errors"] = [str(e)]
    while True:
        try:
            if night_refresh_due():
                night_refresh()
        except Exception as e:  # noqa: BLE001
            print("Nachts auffrischen:", e, flush=True)
        time.sleep(300)


def care_status():
    st = _read_json(_state(CARE_STATE), {}) or {}
    return {"sd": _care["sd"], "watchdog": _care["watchdog"], "errors": _care["errors"],
            "night_refresh": _cfg().get("night_refresh", True) is not False, "refreshed": st.get("refreshed")}


GET_ROUTES["/api/care"] = care_status
_old_start24 = start_background


def start_background():  # noqa: F811
    _old_start24()
    threading.Thread(target=_care_loop, daemon=True).start()
