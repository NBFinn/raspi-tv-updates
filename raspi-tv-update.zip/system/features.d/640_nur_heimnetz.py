# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.8.0: Zugriff nur aus dem eigenen Netz
#   Eine kleine Firewall (nftables, eigene Tabelle „raspitv_guard“) nimmt neue Verbindungen nur aus
#   dem Heimnetz, dem Fernbedienungs-WLAN, VPN-Netzen (z. B. Tailscale) und den eigenen IPv6-Netzen an.
#   Alles von außen (offener Port am Router, IPv6 direkt aus dem Internet) wird verworfen.
#   Antworten auf Verbindungen, die der Pi selbst aufbaut (Streams, Updates), sind nicht betroffen.
# ==========================================================================
LAN4 = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "169.254.0.0/16", "100.64.0.0/10", "127.0.0.0/8"]
LAN6 = ["::1/128", "fe80::/10", "fc00::/7"]
_guard = {"rules": None, "error": "", "active": False}


def _own_nets():
    """Eigene Netze (IPv4 und IPv6) aus „ip addr“ – damit Geräte im Heimnetz mit öffentlicher
    IPv6-Adresse (gleiches Netz wie der Pi) weiter rein dürfen."""
    import ipaddress
    v4, v6 = [], []
    for fam, lst in (("-4", v4), ("-6", v6)):
        code, out, _ = T["run"](["ip", "-o", fam, "addr", "show", "scope", "global"], 10)
        for m in re.finditer(r"inet6? ([0-9a-fA-F:.]+/\d+)", out if code == 0 else ""):
            try:
                net = ipaddress.ip_interface(m.group(1)).network
            except ValueError:
                continue
            if net.prefixlen < (8 if fam == "-4" else 32):   # viel zu groß – nicht als „eigenes Netz“ zählen
                continue
            if str(net) not in lst:
                lst.append(str(net))
    return v4, v6


def _merge(nets):
    """Überlappende Netze zusammenfassen (nftables lehnt überlappende Intervalle ab)."""
    import ipaddress
    out = list(ipaddress.collapse_addresses(ipaddress.ip_network(n) for n in nets))
    return [str(n) for n in out]


def lan_guard_rules(v4_extra=(), v6_extra=()):
    v4 = ", ".join(_merge(LAN4 + list(v4_extra)))
    v6 = ", ".join(_merge(LAN6 + list(v6_extra)))
    return f"""table inet raspitv_guard {{
  set lan4 {{ type ipv4_addr; flags interval; elements = {{ {v4} }} }}
  set lan6 {{ type ipv6_addr; flags interval; elements = {{ {v6} }} }}
  chain input {{
    type filter hook input priority 0; policy accept;
    iif "lo" accept
    ct state established,related accept
    meta l4proto {{ icmp, ipv6-icmp }} accept
    udp dport {{ 67, 68, 546, 547, 5353 }} accept
    ip saddr @lan4 accept
    ip6 saddr @lan6 accept
    ct state new counter drop
  }}
}}
"""


def _guard_on():
    return _cfg().get("lan_only", True) is not False


def lan_guard_apply():
    if not shutil.which("nft"):
        _guard.update(active=False, error="nftables fehlt")
        return
    if not _guard_on():
        if _guard["active"] or _guard["rules"] is None:
            T["run"](["nft", "delete", "table", "inet", "raspitv_guard"], 10)
        _guard.update(active=False, rules="", error="")
        return
    rules = lan_guard_rules(*_own_nets())
    if rules == _guard["rules"] and _guard["active"]:
        return
    # in einem Rutsch ersetzen (atomar): Tabelle anlegen, leeren, neu füllen
    p = subprocess.run(["nft", "-f", "-"], input="add table inet raspitv_guard\ndelete table inet raspitv_guard\n" + rules,
                       text=True, capture_output=True)
    if p.returncode != 0:
        _guard.update(active=False, error=(p.stderr.strip().splitlines() or ["Fehler"])[0][:160])
        print("Nur Heimnetz:", p.stderr.strip(), flush=True)
        return
    _guard.update(active=True, rules=rules, error="")


def lan_guard_status():
    blocked = None
    if _guard["active"]:
        code, out, _ = T["run"](["nft", "list", "table", "inet", "raspitv_guard"], 10)
        m = re.search(r"counter packets (\d+)", out or "")
        blocked = int(m.group(1)) if m else None
    return {"on": _guard_on(), "active": _guard["active"], "error": _guard["error"], "blocked": blocked}


def _guard_loop():
    time.sleep(20)
    while True:
        try:
            lan_guard_apply()          # neue IPv6-Präfixe vom Router (ändern sich bei manchen Anbietern täglich)
        except Exception as e:  # noqa: BLE001
            _guard["error"] = str(e)[:160]
        time.sleep(120)


GET_ROUTES["/api/lan-guard"] = lan_guard_status
POST_ROUTES["/api/lan-guard/apply"] = lambda _d=None: (lan_guard_apply(), lan_guard_status())[1]
_old_start25 = start_background


def start_background():  # noqa: F811
    _old_start25()
    threading.Thread(target=_guard_loop, daemon=True).start()
