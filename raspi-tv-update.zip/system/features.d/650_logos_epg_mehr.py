# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.8.0: Sender-Logos auf dem Pi speichern, Programmdaten für Österreich/Schweiz/UK
# ==========================================================================
LOGO_DIR = "logos"
_LOGO_MAGIC = ((b"\x89PNG", "image/png", ".png"), (b"\xff\xd8", "image/jpeg", ".jpg"),
               (b"GIF8", "image/gif", ".gif"), (b"RIFF", "image/webp", ".webp"))
_logo = {"allowed": set(), "at": 0, "fail": {}}


def _logo_allowed(url):
    """Nur Logos aus der eigenen Senderliste laden (kein offener Durchreiche-Dienst)."""
    if time.time() - _logo["at"] > 300:
        try:
            _logo["allowed"] = {c.get("logo") for c in all_channels(True) if c.get("logo")}
        except Exception:  # noqa: BLE001
            pass
        _logo["at"] = time.time()
    return url in _logo["allowed"]


def logo_file(url):
    """Pfad der gespeicherten Datei (lädt sie beim ersten Mal). None, wenn es nicht klappt."""
    h = hashlib.sha1(url.encode()).hexdigest()[:20]
    d = _state(LOGO_DIR)
    for _, ctype, ext in _LOGO_MAGIC:
        p = os.path.join(d, h + ext)
        if os.path.isfile(p):
            return p, ctype
    if time.time() - _logo["fail"].get(h, 0) < 6 * 3600 or not url.startswith(("http://", "https://")):
        return None
    try:
        data = _download(url, limit=1_500_000, timeout=8)
    except Exception:  # noqa: BLE001
        _logo["fail"][h] = time.time()
        return None
    for magic, ctype, ext in _LOGO_MAGIC:
        if data.startswith(magic) and (magic != b"RIFF" or data[8:12] == b"WEBP"):
            os.makedirs(d, exist_ok=True)
            p = os.path.join(d, h + ext)
            with open(p + ".tmp", "wb") as f:
                f.write(data)
            os.replace(p + ".tmp", p)
            return p, ctype
    _logo["fail"][h] = time.time()      # SVG oder etwas anderes: nicht speichern
    return None


_serve_prefix_78 = serve_prefix


def serve_prefix(handler, path):  # noqa: F811
    if path == "/logo":
        url = (parse_qs(handler.path.partition("?")[2]).get("u") or [""])[0]
        if not _logo_allowed(url):
            handler._json(404, {"error": "unbekannt"})
            return True
        got = logo_file(url)
        if not got:
            # nicht speicherbar (z. B. SVG): direkt vom Original laden lassen
            handler.send_response(302)
            handler.send_header("Location", url)
            handler.end_headers()
            return True
        _send_file(handler, got[0], got[1], cache=True)
        return True
    return _serve_prefix_78(handler, path)


# ---- Programmdaten: zusätzliche Quellen für Sender, die die Hauptquelle nicht kennt
EPG_EXTRA = [
    "https://epgshare01.online/epgshare01/epg_ripper_AT1.xml.gz",
    "https://epgshare01.online/epgshare01/epg_ripper_CH1.xml.gz",
    "https://epgshare01.online/epgshare01/epg_ripper_UK1.xml.gz",
]
_epg_update_base_78 = epg_update_once


def epg_update_once():  # noqa: F811
    _epg_update_base_78()
    if _epg_state["error"]:
        return
    try:
        data = _read_json(_state("epg.json"), {}) or {}
        progs = data.get("programs") or {}
        chans = [c for c in _read_json(os.path.join(T["ROOT"], "channels.json"), []) + custom_channels()
                 if c["name"] not in progs]
        added = 0
        for src in EPG_EXTRA:
            if not chans:
                break
            try:
                raw = _download(src, limit=120_000_000, timeout=90)
                with tempfile.TemporaryFile() as tmp:
                    tmp.write(gzip.decompress(raw) if raw[:2] == b"\x1f\x8b" else raw)
                    tmp.seek(0)
                    more = parse_xmltv(tmp, chans)
            except Exception as e:  # noqa: BLE001
                print("Programmdaten (zusätzlich):", src.split("/")[-1], e.__class__.__name__, flush=True)
                continue
            for name, lst in more.items():
                if name not in progs:
                    progs[name] = lst
                    added += 1
            chans = [c for c in chans if c["name"] not in progs]
        if added:
            data["programs"] = progs
            _write_json(_state("epg.json"), data)
            print(f"Programmdaten: {added} weitere Sender aus Zusatzquellen", flush=True)
    except Exception as e:  # noqa: BLE001
        print("Programmdaten (zusätzlich):", e, flush=True)
