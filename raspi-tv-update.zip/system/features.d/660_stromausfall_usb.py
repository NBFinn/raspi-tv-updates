# Raspi-TV – Teil von features.py (wird dort der Reihe nach in denselben Namensraum geladen,
# daher keine eigenen Imports nötig; spätere Teile dürfen frühere Funktionen erweitern).
# flake8: noqa

# ==========================================================================
# 7.8.3: Bei Stromausfall alle USB-Anschlüsse stromlos
#   - sofort beim Ausfall: powerfail.py schaltet mit uhubctl alle USB-Anschlüsse ab
#   - danach bleiben sie aus: Der Pi 5 lässt die 5 V an USB nach dem Herunterfahren sonst an. Mit
#     POWER_OFF_ON_HALT=1 (Startprogramm/EEPROM) schaltet er nach dem Herunterfahren ganz ab.
#     Das setzt Raspi-TV von selbst, sobald die Notfall-Abschaltung an ist (wirkt ab dem nächsten Neustart).
# ==========================================================================
_pfusb = {"halt": None, "checked": 0, "error": ""}


def _pf_is_pi5():
    m = T["read_file"]("/proc/device-tree/model")
    return "Raspberry Pi 5" in m or "Compute Module 5" in m


def powerfail_usb_ensure():
    if (_cfg().get("powerfail") or {}).get("on") is not True or not _pf_is_pi5() or not shutil.which("rpi-eeprom-config"):
        return
    cfg = _eeprom_config()
    if cfg is None:
        _pfusb["error"] = "Startprogramm-Einstellungen nicht lesbar"
        return
    rec = _read_json(_state(POWER_WAIT_STATE), {}) or {}
    if _eeprom_value(cfg, "POWER_OFF_ON_HALT") == "1":
        if rec.pop("halt_pending", None):
            _write_json(_state(POWER_WAIT_STATE), rec)
        _pfusb["halt"] = True
        return
    if rec.get("halt_pending") == "1":           # schon gesetzt, wirkt nach dem nächsten Neustart
        _pfusb["halt"] = True
        return
    new = _eeprom_set(cfg, {"POWER_OFF_ON_HALT": "1"})
    tmp = _state("eeprom-new.conf")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(new)
    code, out, err = T["run"](["rpi-eeprom-config", "--apply", tmp], 180)
    try:
        os.remove(tmp)
    except OSError:
        pass
    if code == 0:
        if "halt_before" not in rec:
            rec["halt_before"] = _eeprom_value(cfg, "POWER_OFF_ON_HALT") or "0"
        rec["halt_pending"] = "1"
        _write_json(_state(POWER_WAIT_STATE), rec)
        _pfusb.update(halt=True, error="")
        print("Stromausfall: Pi 5 schaltet nach dem Herunterfahren jetzt ganz ab (USB stromlos)", flush=True)
    else:
        _pfusb["error"] = ((err or out or "").strip().splitlines() or ["Fehler"])[-1][:160]


_powerfail_status_78 = powerfail_status


def powerfail_status():  # noqa: F811
    st = _powerfail_status_78()
    st["usb"] = {"tool": bool(shutil.which("uhubctl")), "halt": _pfusb["halt"], "error": _pfusb["error"],
                 "pi5": _pf_is_pi5()}
    return st


def _pfusb_loop():
    time.sleep(90)
    last = None
    while True:
        on = (_cfg().get("powerfail") or {}).get("on") is True
        if on and (last is not True or time.time() - _pfusb["checked"] > 6 * 3600):
            try:
                powerfail_usb_ensure()
            except Exception as e:  # noqa: BLE001
                _pfusb["error"] = str(e)[:160]
            _pfusb["checked"] = time.time()
        last = on
        time.sleep(30)


GET_ROUTES["/api/powerfail"] = powerfail_status
_old_start26 = start_background


def start_background():  # noqa: F811
    _old_start26()
    threading.Thread(target=_pfusb_loop, daemon=True).start()


# ==========================================================================
# 7.8.4: USB-Anschlüsse haben immer Strom – auch wenn der Pi heruntergefahren ist (Standard)
#   Der Pi 5 lässt die 5 V an USB nach dem Herunterfahren an, solange POWER_OFF_ON_HALT=0 ist.
#   Raspi-TV setzt das zurück, falls es vorher (Stromausfall/„Aus bleiben“) auf 1 gestellt wurde.
#   „Aus bleiben, wenn der Strom wieder da ist“ funktioniert weiter (WAIT_FOR_POWER_BUTTON).
#   Ausschaltbar unter Einstellungen · Energie („USB-Strom, wenn der Pi aus ist“).
# ==========================================================================
def usb_always_on():
    return _cfg().get("usb_always_on", True) is not False


def _eeprom_apply(values):
    cfg = _eeprom_config()
    if cfg is None:
        return False, "Startprogramm-Einstellungen nicht lesbar"
    if all(_eeprom_value(cfg, k) == v or (v == "0" and _eeprom_value(cfg, k) is None) for k, v in values.items()):
        return True, ""
    tmp = _state("eeprom-new.conf")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(_eeprom_set(cfg, values))
    code, out, err = T["run"](["rpi-eeprom-config", "--apply", tmp], 180)
    try:
        os.remove(tmp)
    except OSError:
        pass
    return code == 0, "" if code == 0 else ((err or out or "").strip().splitlines() or ["Fehler"])[-1][:160]


_powerfail_usb_ensure_783 = powerfail_usb_ensure


def powerfail_usb_ensure():  # noqa: F811
    if not usb_always_on():
        return _powerfail_usb_ensure_783()


def usb_power_ensure():
    """POWER_OFF_ON_HALT passend zur Einstellung setzen (wirkt ab dem nächsten Neustart)."""
    if not _pf_is_pi5() or not shutil.which("rpi-eeprom-config"):
        return
    rec = _read_json(_state(POWER_WAIT_STATE), {}) or {}
    if usb_always_on():
        ok, err = _eeprom_apply({"POWER_OFF_ON_HALT": "0"})
        if ok and (rec.pop("halt_pending", None) or "halt_before" in rec):
            rec["halt_before"] = "0"
            _write_json(_state(POWER_WAIT_STATE), rec)
        _pfusb.update(halt=False, error=err)
    else:
        powerfail_usb_ensure()


_power_wait_set_783 = power_wait_set


def power_wait_set(data):  # noqa: F811
    out = _power_wait_set_783(data)
    if usb_always_on():
        ok, err = _eeprom_apply({"POWER_OFF_ON_HALT": "0"})      # Knopf-Warten ja, USB aber an lassen
        if not ok:
            raise _err("Die Einstellung konnte nicht gespeichert werden: " + err, 500)
    return out


def usb_power_status():
    return {"always_on": usb_always_on(), "pi5": _pf_is_pi5(), "error": _pfusb["error"]}


def usb_power_set(data):
    on = (data or {}).get("always_on")
    if not isinstance(on, bool):
        raise T["ApiError"]("Ungültig")
    cfg = _cfg()
    cfg["usb_always_on"] = on
    _save(cfg)
    usb_power_ensure()
    return usb_power_status()


def _usbpower_loop():
    time.sleep(100)
    while True:
        try:
            usb_power_ensure()
        except Exception as e:  # noqa: BLE001
            _pfusb["error"] = str(e)[:160]
        time.sleep(6 * 3600)


_powerfail_status_784 = powerfail_status


def powerfail_status():  # noqa: F811
    st = _powerfail_status_784()
    st["usb"]["always_on"] = usb_always_on()
    return st


GET_ROUTES["/api/powerfail"] = powerfail_status
GET_ROUTES["/api/usb-power"] = usb_power_status
POST_ROUTES["/api/usb-power"] = usb_power_set
POST_ROUTES["/api/power-wait"] = power_wait_set
_old_start27 = start_background


def start_background():  # noqa: F811
    _old_start27()
    threading.Thread(target=_usbpower_loop, daemon=True).start()
