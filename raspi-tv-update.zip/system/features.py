#!/usr/bin/env python3
"""Raspi-TV OS – Zusatzfunktionen des Systemdienstes.

  * Programmführer (EPG) aus frei verfügbaren XMLTV-Daten
  * Erinnerungen an Sendungen
  * Senderverwaltung (Reihenfolge, ausblenden, eigene M3U-Liste)
  * Eigene Medien von USB-Sticks und Netzwerkfreigaben (SMB) mit Vorschaubildern
  * Bildeinstellungen (Auflösung, Oberflächengröße)

Wird von tvctl.py geladen; tvctl übergibt mit bind() seine Hilfsfunktionen.
"""
import calendar
import glob
import gzip
import hashlib
import hmac
import secrets
import json
import queue
import mimetypes
import os
import re
import shutil
import tempfile
import threading
import time
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime
from urllib.parse import parse_qs, quote, urlparse

T = {}  # Namensraum von tvctl (live, damit Tests Werte austauschen können)


def bind(ns):
    global T
    T = ns


def _err(msg, code=400):
    return T["ApiError"](msg, code)


def _state(*parts):
    return os.path.join(T["STATE_DIR"], *parts)


def _cfg():
    return T["load_config"]()


def _save(cfg):
    T["save_config"](cfg)


def _write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, ensure_ascii=False)
    os.replace(tmp, path)


def _read_json(path, default):
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def _download(url, limit=80_000_000, timeout=60):
    req = urllib.request.Request(url, headers={"User-Agent": "Raspi-TV/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise _err("Datei zu groß")
    return data


# ==========================================================================
# Sender
# ==========================================================================
def _norm(s):
    s = (s or "").lower()
    for a, b in (("ä", "ae"), ("ö", "oe"), ("ü", "ue"), ("ß", "ss")):
        s = s.replace(a, b)
    s = re.sub(r"\.de$", "", s)
    s = re.sub(r"[^a-z0-9]", "", s)
    return re.sub(r"(hd|uhd)$", "", s) or s


def base_channels():
    chans = _read_json(os.path.join(T["ROOT"], "channels.json"), [])
    overrides = _read_json(T["CHANNEL_OVERRIDES"], {})
    region = _cfg().get("region")
    out = []
    for ch in chans:
        ch = dict(ch)
        var = (ch.pop("variants", None) or {}).get(region)   # Regionalversion fürs eigene Bundesland
        if var:
            ch["source"], ch["url"] = var["source"], var["url"]
        url = overrides.get(ch.get("source") or ch["name"])
        if url:
            ch["url"] = url
        out.append(ch)
    return out


def custom_channels():
    return _read_json(_state("custom-channels.json"), [])


def all_channels(include_hidden=False):
    cfg = _cfg()
    chans = base_channels() + custom_channels()
    by_name = {}
    for ch in chans:
        by_name.setdefault(ch["name"], ch)
    order = [n for n in cfg.get("channel_order", []) if n in by_name]
    rest = [ch["name"] for ch in chans if ch["name"] not in order]
    hidden = set(cfg.get("channel_hidden", []))
    result = []
    for name in order + rest:
        if name in [r["name"] for r in result]:
            continue
        ch = by_name[name]
        item = {"name": ch["name"], "group": ch.get("group", ""), "url": ch["url"],
                "custom": bool(ch.get("custom")), "logo": ch.get("logo", "")}
        if include_hidden:
            item["hidden"] = name in hidden
            result.append(item)
        elif name not in hidden:
            result.append(item)
    return result


def channels_settings():
    return {"channels": all_channels(True), "m3u": _cfg().get("custom_m3u", "")}


def channels_config(data):
    order, hidden = data.get("order"), data.get("hidden")
    for v in (order, hidden):
        if not isinstance(v, list) or not all(isinstance(x, str) and len(x) < 80 for x in v):
            raise _err("Ungültige Senderliste")
    names = {c["name"] for c in all_channels(True)}
    if len([n for n in names if n not in hidden]) == 0:
        raise _err("Mindestens ein Sender muss sichtbar bleiben.")
    cfg = _cfg()
    cfg["channel_order"] = order[:500]
    cfg["channel_hidden"] = hidden[:500]
    _save(cfg)
    return channels_settings()


def channels_reset(_data=None):
    cfg = _cfg()
    cfg.pop("channel_order", None)
    cfg.pop("channel_hidden", None)
    _save(cfg)
    return channels_settings()


def parse_m3u_list(text):
    out, cur = [], None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("#EXTINF"):
            name = line.rsplit(",", 1)[-1].strip()
            g = re.search(r'group-title="([^"]*)"', line)
            cur = {"name": name[:60], "group": (g.group(1) if g else "Eigene Sender")[:40] or "Eigene Sender"}
            lg = re.search(r'tvg-logo="(https?://[^"]+)"', line)
            if lg:
                cur["logo"] = lg.group(1)[:300]
        elif line and not line.startswith("#") and cur:
            if re.match(r"^https?://\S+$", line):
                cur["url"] = line
                cur["custom"] = True
                out.append(cur)
            cur = None
    return out


def channels_m3u(data):
    url = (data.get("url") or "").strip()
    cfg = _cfg()
    if not url:
        cfg.pop("custom_m3u", None)
        _save(cfg)
        _write_json(_state("custom-channels.json"), [])
        return channels_settings()
    if not re.match(r"^https?://[^\s]{4,500}$", url):
        raise _err("Bitte eine Adresse beginnend mit http:// oder https:// eingeben.")
    try:
        text = _download(url, limit=5_000_000, timeout=20).decode("utf-8", "replace")
    except Exception as e:  # noqa: BLE001
        raise _err(f"Liste konnte nicht geladen werden ({e.__class__.__name__}).")
    chans = parse_m3u_list(text)[:400]
    if not chans:
        raise _err("In der Liste wurden keine Sender gefunden.")
    known = {c["name"] for c in base_channels()}
    for c in chans:
        if c["name"] in known:
            c["name"] += " (eigen)"
    _write_json(_state("custom-channels.json"), chans)
    cfg["custom_m3u"] = url
    _save(cfg)
    return channels_settings()


# ==========================================================================
# Programmführer (EPG)
# ==========================================================================
EPG_SOURCES = [
    "https://epgshare01.online/epgshare01/epg_ripper_DE1.xml.gz",
    "https://epg.pw/xmltv/epg_DE.xml.gz",
]
EPG_BEFORE, EPG_AFTER = 4 * 3600, 48 * 3600
_epg = {"mtime": 0, "data": {"updated": 0, "programs": {}}}
_epg_state = {"running": False, "error": None}


def _xmltv_time(s):
    s = (s or "").strip()
    dt = datetime.strptime(s[:14], "%Y%m%d%H%M%S")
    ts = calendar.timegm(dt.timetuple())
    m = re.search(r"([+-])(\d{2})(\d{2})$", s)
    if m:
        off = int(m.group(2)) * 3600 + int(m.group(3)) * 60
        ts -= off if m.group(1) == "+" else -off
    return ts


def parse_xmltv(fileobj, channels, now=None):
    """XMLTV einlesen und nur die eigenen Sender im Zeitfenster behalten."""
    now = now or time.time()
    keys = {}
    for ch in channels:
        for k in [ch["name"], ch.get("source", "")] + list(ch.get("epg", [])):
            if k:
                keys.setdefault(_norm(k), ch["name"])
                keys.setdefault(k.lower(), ch["name"])
    idmap, programs = {}, {}
    for _, el in ET.iterparse(fileobj, events=("end",)):
        if el.tag == "channel":
            cid = el.get("id", "")
            names = [cid] + [d.text or "" for d in el.findall("display-name")]
            for n in names:
                hit = keys.get(n.lower()) or keys.get(_norm(n))
                if hit:
                    idmap[cid] = hit
                    break
            el.clear()
        elif el.tag == "programme":
            name = idmap.get(el.get("channel", ""))
            if name:
                try:
                    start, stop = _xmltv_time(el.get("start")), _xmltv_time(el.get("stop"))
                except (ValueError, TypeError):
                    el.clear()
                    continue
                if stop > now - EPG_BEFORE and start < now + EPG_AFTER:
                    txt = lambda tag: ((el.findtext(tag) or "").strip())  # noqa: E731
                    programs.setdefault(name, []).append([
                        start, stop, txt("title")[:120], txt("sub-title")[:160],
                        txt("desc")[:700], txt("category")[:40]])
            el.clear()
    for lst in programs.values():
        lst.sort(key=lambda p: p[0])
    return programs


def epg_update_once():
    if _epg_state["running"]:
        return
    _epg_state["running"] = True
    try:
        chans = _read_json(os.path.join(T["ROOT"], "channels.json"), []) + custom_channels()
        last_err = None
        for src in EPG_SOURCES:
            try:
                raw = _download(src, limit=120_000_000, timeout=90)
                with tempfile.TemporaryFile() as tmp:
                    tmp.write(gzip.decompress(raw) if raw[:2] == b"\x1f\x8b" else raw)
                    tmp.seek(0)
                    programs = parse_xmltv(tmp, chans)
                if programs:
                    _write_json(_state("epg.json"), {"updated": time.time(), "source": src, "programs": programs})
                    _epg_state["error"] = None
                    return
                last_err = "keine passenden Sender"
            except Exception as e:  # noqa: BLE001
                last_err = f"{src.split('/')[2]}: {e.__class__.__name__}"
        _epg_state["error"] = last_err
    finally:
        _epg_state["running"] = False


def epg_updater():
    time.sleep(20)
    while True:
        epg_update_once()
        time.sleep(1800 if _epg_state["error"] else 6 * 3600)


def _epg_data():
    path = _state("epg.json")
    try:
        mt = os.path.getmtime(path)
    except OSError:
        return {"updated": 0, "programs": {}}
    if mt != _epg["mtime"]:
        _epg["data"] = _read_json(path, {"updated": 0, "programs": {}})
        _epg["mtime"] = mt
    return _epg["data"]


def _prog(p):
    return {"start": p[0], "stop": p[1], "title": p[2], "sub": p[3], "desc": p[4], "cat": p[5]}


def epg_now():
    now = time.time()
    out = {}
    for name, lst in _epg_data().get("programs", {}).items():
        cur = nxt = None
        for i, p in enumerate(lst):
            if p[0] <= now < p[1]:
                cur = p
                nxt = lst[i + 1] if i + 1 < len(lst) else None
                break
            if p[0] > now:
                nxt = p
                break
        out[name] = {"now": _prog(cur) if cur else None, "next": _prog(nxt) if nxt else None}
    return out


def epg_range(query):
    now = time.time()
    try:
        t0 = float(query.get("from", [now - 1800])[0])
        t1 = float(query.get("to", [now + 4 * 3600])[0])
    except ValueError:
        raise _err("Ungültiger Zeitraum")
    t1 = min(t1, t0 + 26 * 3600)
    out = {}
    for name, lst in _epg_data().get("programs", {}).items():
        out[name] = [_prog(p) for p in lst if p[1] > t0 and p[0] < t1]
    return {"from": t0, "to": t1, "programs": out}


def epg_status():
    d = _epg_data()
    return {"updated": d.get("updated", 0), "source": d.get("source"),
            "channels": len(d.get("programs", {})), "running": _epg_state["running"],
            "error": _epg_state["error"]}


def epg_refresh(_data=None):
    threading.Thread(target=epg_update_once, daemon=True).start()
    return {"ok": True}


# ==========================================================================
# Erinnerungen
# ==========================================================================
_rem_lock = threading.Lock()


def _reminders():
    return _read_json(_state("reminders.json"), [])


def _save_reminders(lst):
    now = time.time()
    lst = [r for r in lst if r["start"] > now - 6 * 3600][:200]
    _write_json(_state("reminders.json"), lst)
    return lst


def reminders_list():
    return {"reminders": sorted(_reminders(), key=lambda r: r["start"])}


def reminders_add(data):
    try:
        ch = str(data["channel"])[:80]
        start, stop = int(data["start"]), int(data.get("stop") or 0)
        title = str(data.get("title", ""))[:120]
    except (KeyError, TypeError, ValueError):
        raise _err("Ungültige Erinnerung")
    if start < time.time() - 60:
        raise _err("Die Sendung hat schon begonnen.")
    rid = f"{ch}|{start}"
    with _rem_lock:
        lst = [r for r in _reminders() if r["id"] != rid]
        lst.append({"id": rid, "channel": ch, "start": start, "stop": stop, "title": title, "notified": False})
        _save_reminders(lst)
    return reminders_list()


def reminders_remove(data):
    rid = str(data.get("id", ""))
    with _rem_lock:
        _save_reminders([r for r in _reminders() if r["id"] != rid])
    return reminders_list()


def reminders_due(query, headers):
    """Fällige Erinnerungen (1 Min. vorher bis 5 Min. nach Beginn). Liest die Raspi-TV-Erweiterung."""
    if headers.get("X-Raspi-TV") != "1":
        raise _err("forbidden", 403)
    now = time.time()
    due = []
    with _rem_lock:
        lst = _reminders()
        for r in lst:
            if not r.get("notified") and r["start"] - 60 <= now <= r["start"] + 300:
                r["notified"] = True
                due.append(r)
        if due:
            _save_reminders(lst)
    return {"due": due}


# ==========================================================================
# Eigene Medien
# ==========================================================================
MEDIA_ROOT = "/media/raspi-tv"
THUMB_DIR = "/var/cache/raspi-tv/thumbs"
FS_OK = {"vfat", "exfat", "ntfs", "ext4", "ext3", "ext2", "btrfs", "hfsplus"}
EXT = {
    "video": {".mp4", ".m4v", ".mkv", ".webm", ".mov", ".avi", ".ts", ".mpg", ".mpeg", ".wmv"},
    "audio": {".mp3", ".m4a", ".aac", ".flac", ".ogg", ".opus", ".wav", ".wma"},
    "image": {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".heic"},
}
_thumb_sem = threading.Semaphore(2)
_mount_lock = threading.Lock()


def _ftype(name):
    ext = os.path.splitext(name)[1].lower()
    for t, exts in EXT.items():
        if ext in exts:
            return t
    return None


def _tv_ids():
    try:
        import pwd
        pw = pwd.getpwnam(T["TV_USER"])
        return pw.pw_uid, pw.pw_gid
    except (KeyError, ImportError):
        return 1000, 1000


def _usb_devices():
    code, out, _ = T["run"](["lsblk", "-J", "-b", "-o",
                             "NAME,PATH,FSTYPE,LABEL,MOUNTPOINT,RM,HOTPLUG,SIZE,TYPE"], 10)
    if code != 0:
        return []
    try:
        tree = json.loads(out).get("blockdevices", [])
    except ValueError:
        return []
    found = []

    def walk(devs, parent_hot=False):
        for d in devs:
            hot = parent_hot or d.get("rm") in (True, "1", 1) or d.get("hotplug") in (True, "1", 1)
            if hot and d.get("fstype") in FS_OK and d.get("type") in ("part", "disk"):
                found.append(d)
            walk(d.get("children") or [], hot)
    walk(tree)
    return found


def _mount_usb(dev):
    mp = dev.get("mountpoint")
    if mp:
        return mp if mp.startswith(MEDIA_ROOT) else None  # z. B. Systemlaufwerk – nicht anfassen
    target = os.path.join(MEDIA_ROOT, "usb-" + re.sub(r"[^A-Za-z0-9_-]", "", dev["name"]))
    os.makedirs(target, exist_ok=True)
    fstype = "ntfs3" if dev["fstype"] == "ntfs" else dev["fstype"]
    uid, gid = _tv_ids()
    opts = "ro,nosuid,nodev,noexec"
    if fstype in ("vfat", "exfat", "ntfs3"):
        opts += f",uid={uid},gid={gid},iocharset=utf8" if fstype != "ntfs3" else f",uid={uid},gid={gid}"
    code, _, _ = T["run"](["mount", "-t", fstype, "-o", opts, dev["path"], target], 20)
    if code != 0:
        code, _, _ = T["run"](["mount", "-o", "ro,nosuid,nodev,noexec", dev["path"], target], 20)
    return target if code == 0 else None


def _cleanup_usb(present):
    for d in glob.glob(os.path.join(MEDIA_ROOT, "usb-*")):
        if d in present:
            continue
        if os.path.ismount(d):
            T["run"](["umount", "-l", d], 10)
        try:
            os.rmdir(d)
        except OSError:
            pass


def _share_dir(sid):
    return os.path.join(MEDIA_ROOT, "net-" + sid)


def _mount_share(sh):
    target = _share_dir(sh["id"])
    if os.path.ismount(target):
        return True, None
    os.makedirs(target, exist_ok=True)
    uid, gid = _tv_ids()
    cred = _state("shares", sh["id"] + ".cred")
    base = f"ro,nosuid,nodev,noexec,uid={uid},gid={gid},iocharset=utf8,soft,echo_interval=10"
    base += f",credentials={cred}" if os.path.exists(cred) else ",guest"
    last = ""
    for extra in ("", ",vers=3.0", ",vers=2.1", ",vers=2.0", ",vers=1.0"):
        code, out, err = T["run"](["mount", "-t", "cifs", f"//{sh['server']}/{sh['share']}", target,
                                   "-o", base + extra], 25)
        if code == 0:
            return True, None
        last = (err or out).strip()
    return False, last


def media_sources():
    os.makedirs(MEDIA_ROOT, exist_ok=True)
    out = []
    with _mount_lock:
        present = set()
        for dev in _usb_devices():
            mp = _mount_usb(dev)
            if mp:
                present.add(mp)
                size = int(dev.get("size") or 0)
                out.append({"id": os.path.basename(mp), "name": dev.get("label") or "USB-Stick",
                            "kind": "usb", "size": size, "online": True})
        _cleanup_usb(present)
        for sh in _cfg().get("shares", []):
            ok = os.path.ismount(_share_dir(sh["id"]))
            out.append({"id": "net-" + sh["id"], "name": sh["name"], "kind": "net",
                        "server": sh["server"], "share": sh["share"], "online": ok})
    return {"sources": out}


def _source_root(src):
    if not re.match(r"^(usb|net)-[A-Za-z0-9_-]{1,40}$", src or ""):
        raise _err("Unbekannte Quelle", 404)
    root = os.path.join(MEDIA_ROOT, src)
    if src.startswith("net-"):
        sh = next((s for s in _cfg().get("shares", []) if "net-" + s["id"] == src), None)
        if not sh:
            raise _err("Unbekannte Freigabe", 404)
        ok, err = _mount_share(sh)
        if not ok:
            raise _err("Freigabe nicht erreichbar – ist der Rechner/NAS eingeschaltet? " + (err or "")[:100], 502)
    if not os.path.isdir(root):
        raise _err("Quelle nicht verfügbar – Stick eingesteckt?", 404)
    return os.path.realpath(root)


def _resolve(src, rel):
    root = _source_root(src)
    path = os.path.realpath(os.path.join(root, (rel or "").lstrip("/")))
    if path != root and not path.startswith(root + os.sep):
        raise _err("Ungültiger Pfad", 403)
    return root, path


def _natural(s):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", s)]


def media_list(query):
    src = query.get("src", [""])[0]
    rel = query.get("path", [""])[0]
    root, path = _resolve(src, rel)
    if not os.path.isdir(path):
        raise _err("Ordner nicht gefunden", 404)
    dirs, files = [], []
    try:
        names = os.listdir(path)
    except OSError as e:
        raise _err(f"Ordner kann nicht gelesen werden ({e.strerror})", 500)
    for name in names:
        if name.startswith(".") or name in ("System Volume Information", "$RECYCLE.BIN", "lost+found"):
            continue
        full = os.path.join(path, name)
        relp = os.path.relpath(full, root)
        try:
            st = os.stat(full)
        except OSError:
            continue
        if os.path.isdir(full):
            cover = next((c for c in ("folder.jpg", "cover.jpg", "Folder.jpg", "Cover.jpg", "poster.jpg")
                          if os.path.exists(os.path.join(full, c))), None)
            dirs.append({"name": name, "path": relp, "type": "dir",
                         "cover": os.path.join(relp, cover) if cover else None})
        else:
            t = _ftype(name)
            if t:
                files.append({"name": name, "path": relp, "type": t, "size": st.st_size, "mtime": int(st.st_mtime)})
    dirs.sort(key=lambda e: _natural(e["name"]))
    files.sort(key=lambda e: _natural(e["name"]))
    parent = None if path == root else os.path.relpath(os.path.dirname(path), root)
    if parent == ".":
        parent = ""
    return {"src": src, "path": os.path.relpath(path, root) if path != root else "",
            "parent": parent, "entries": dirs + files}


def _thumb_path(path):
    st = os.stat(path)
    h = hashlib.sha1(f"{path}|{st.st_mtime}|{st.st_size}".encode()).hexdigest()
    return os.path.join(THUMB_DIR, h + ".jpg")


def make_thumb(path, kind):
    os.makedirs(THUMB_DIR, exist_ok=True)
    out = _thumb_path(path)
    if os.path.exists(out):
        return out
    vf = "scale=480:-2:force_original_aspect_ratio=decrease"
    with _thumb_sem:
        if os.path.exists(out):
            return out
        tmp = out + ".part.jpg"
        if kind == "video":
            attempts = [["-ss", "30"], ["-ss", "3"], []]
        else:
            attempts = [[]]
        for pre in attempts:
            cmd = ["ffmpeg", "-nostdin", "-loglevel", "error", "-y"] + pre + ["-i", path,
                   "-map", "0:v:0", "-frames:v", "1", "-vf", vf, "-q:v", "6", tmp]
            code, _, _ = T["run"](cmd, 25)
            if code == 0 and os.path.exists(tmp) and os.path.getsize(tmp) > 0:
                os.replace(tmp, out)
                return out
        try:
            os.remove(tmp)
        except OSError:
            pass
    return None


# ---- Dateien ausliefern (mit Range, damit Spulen funktioniert) -----------------
def serve_media(handler, path, query):
    src = query.get("src", [""])[0]
    rel = query.get("path", [""])[0]
    try:
        _, full = _resolve(src, rel)
    except Exception as e:  # noqa: BLE001
        return handler._json(getattr(e, "code", 404), {"error": str(e)})
    if not os.path.isfile(full):
        return handler._json(404, {"error": "Datei nicht gefunden"})
    if path == "/media/thumb":
        kind = _ftype(full)
        if kind not in ("video", "image", "audio"):
            return handler._json(404, {"error": "kein Vorschaubild"})
        thumb = make_thumb(full, kind)
        if not thumb:
            return handler._json(404, {"error": "kein Vorschaubild"})
        return _send_file(handler, thumb, "image/jpeg", cache=True)
    ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
    if full.lower().endswith(".mkv"):
        ctype = "video/webm"  # Chromium spielt Matroska (H.264/VP9) über den WebM-Pfad
    return _send_file(handler, full, ctype)


def _send_file(handler, full, ctype, cache=False):
    size = os.path.getsize(full)
    start, end = 0, size - 1
    rng = handler.headers.get("Range")
    status = 200
    if rng:
        m = re.match(r"bytes=(\d*)-(\d*)", rng)
        if m:
            if m.group(1):
                start = int(m.group(1))
                if m.group(2):
                    end = min(int(m.group(2)), size - 1)
            elif m.group(2):
                start = max(0, size - int(m.group(2)))
            if start > end or start >= size:
                handler.send_response(416)
                handler.send_header("Content-Range", f"bytes */{size}")
                handler.end_headers()
                return
            status = 206
    handler.send_response(status)
    handler.send_header("Content-Type", ctype)
    handler.send_header("Accept-Ranges", "bytes")
    handler.send_header("Content-Length", str(end - start + 1))
    if status == 206:
        handler.send_header("Content-Range", f"bytes {start}-{end}/{size}")
    if cache:
        handler.send_header("X-Raspi-Cache", "1")
    handler.end_headers()
    try:
        with open(full, "rb") as f:
            f.seek(start)
            left = end - start + 1
            while left > 0:
                chunk = f.read(min(262144, left))
                if not chunk:
                    break
                handler.wfile.write(chunk)
                left -= len(chunk)
    except (BrokenPipeError, ConnectionResetError):
        pass


# ---- Netzwerkfreigaben -----------------------------------------------------------
def shares_add(data):
    name = str(data.get("name") or "").strip()[:40]
    server = str(data.get("server") or "").strip().strip("/\\")
    share = str(data.get("share") or "").strip().strip("/\\")
    user = str(data.get("user") or "").strip()
    pw = str(data.get("password") or "")
    if server.startswith("smb:"):
        server = server[4:].strip("/")
    if "/" in server or "\\" in server:
        server, _, rest = server.replace("\\", "/").partition("/")
        share = share or rest
    if not re.match(r"^[A-Za-z0-9._-]{1,100}$", server):
        raise _err("Bitte Name oder IP-Adresse des Rechners/NAS eingeben (z. B. fritz.box oder 192.168.178.20).")
    if not re.match(r"^[^\x00-\x1f/\\]{1,100}$", share):
        raise _err("Bitte den Namen der Freigabe eingeben (z. B. FRITZ.NAS oder Videos).")
    if user and not re.match(r"^[^\x00-\x1f,]{1,100}$", user):
        raise _err("Ungültiger Benutzername")
    if "\n" in pw or len(pw) > 200:
        raise _err("Ungültiges Passwort")
    sid = hashlib.sha1(f"{server}/{share}/{time.time()}".encode()).hexdigest()[:10]
    sh = {"id": sid, "name": name or share, "server": server, "share": share, "user": user}
    if user:
        os.makedirs(_state("shares"), mode=0o700, exist_ok=True)
        cred = _state("shares", sid + ".cred")
        fd = os.open(cred, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(f"username={user}\npassword={pw}\n")
    ok, err = _mount_share(sh)
    if not ok:
        try:
            os.remove(_state("shares", sid + ".cred"))
        except OSError:
            pass
        try:
            os.rmdir(_share_dir(sid))
        except OSError:
            pass
        hint = "Benutzername/Passwort prüfen." if "13" in (err or "") or "denied" in (err or "").lower() \
            else "Name/Adresse und Freigabe prüfen."
        raise _err(f"Verbindung fehlgeschlagen – {hint}")
    cfg = _cfg()
    cfg.setdefault("shares", []).append(sh)
    _save(cfg)
    return media_sources()


def shares_remove(data):
    sid = str(data.get("id") or "").replace("net-", "", 1)
    cfg = _cfg()
    cfg["shares"] = [s for s in cfg.get("shares", []) if s["id"] != sid]
    _save(cfg)
    d = _share_dir(sid)
    if os.path.ismount(d):
        T["run"](["umount", "-l", d], 10)
    for p in (_state("shares", sid + ".cred"),):
        try:
            os.remove(p)
        except OSError:
            pass
    try:
        os.rmdir(d)
    except OSError:
        pass
    return media_sources()


# ==========================================================================
# Bild
# ==========================================================================
DISPLAY_FILE_NAME = "display-mode"


def _xrandr(args):
    return T["as_tv"](["env", "DISPLAY=:0", f"XAUTHORITY=/home/{T['TV_USER']}/.Xauthority", "xrandr"] + args, 15)


def display_info():
    code, out, err = _xrandr(["--query"])
    cfg = _cfg()
    info = {"output": None, "modes": [], "current": None, "saved": read_saved_mode(),
            "scale": cfg.get("ui_scale", 100), "available": code == 0}
    cur_out = None
    for line in out.splitlines():
        m = re.match(r"^(\S+) connected", line)
        if m:
            cur_out = m.group(1)
            if not info["output"]:
                info["output"] = cur_out
            continue
        if re.match(r"^\S", line):
            cur_out = None
            continue
        m = re.match(r"^\s+(\d+x\d+i?)\s+(.*)$", line)
        if m and cur_out == info["output"]:
            rates = []
            for r in re.findall(r"(\d+\.\d+)([ *+]*)", m.group(2)):
                rates.append(r[0])
                if "*" in r[1]:
                    info["current"] = f"{m.group(1)}@{r[0]}"
            info["modes"].append({"mode": m.group(1), "rates": rates})
    return info


def read_saved_mode():
    s = T["read_file"](_state(DISPLAY_FILE_NAME))
    return s or "auto"


def display_set(data):
    info = display_info()
    out = info["output"]
    if not out:
        raise _err("Kein Bildschirm erkannt.")
    mode = str(data.get("mode", "auto"))
    if mode == "auto":
        _xrandr(["--output", out, "--auto"])
        try:
            os.remove(_state(DISPLAY_FILE_NAME))
        except OSError:
            pass
    else:
        m = re.match(r"^(\d+x\d+i?)(?:@(\d+\.\d+))?$", mode)
        if not m or m.group(1) not in [x["mode"] for x in info["modes"]]:
            raise _err("Diese Auflösung wird nicht unterstützt.")
        args = ["--output", out, "--mode", m.group(1)] + (["--rate", m.group(2)] if m.group(2) else [])
        code, _, err = _xrandr(args)
        if code != 0:
            raise _err("Auflösung konnte nicht gesetzt werden: " + err.strip()[:100])
        os.makedirs(T["STATE_DIR"], exist_ok=True)
        with open(_state(DISPLAY_FILE_NAME), "w") as f:
            f.write(f"{out} {m.group(1)} {m.group(2) or ''}".strip())
    return display_info()


def display_scale(data):
    try:
        scale = int(data.get("scale"))
    except (TypeError, ValueError):
        raise _err("Ungültiger Wert")
    scale = max(80, min(110, scale))
    cfg = _cfg()
    cfg["ui_scale"] = scale
    _save(cfg)
    return {"scale": scale}


def cec_status():
    return {"adapter": bool(glob.glob("/dev/cec*")), "tv": T["tv_power"]()}


# ==========================================================================
# Routen
# ==========================================================================
GET_ROUTES = {
    "/api/channels": all_channels,
    "/api/channels/settings": channels_settings,
    "/api/epg/now": epg_now,
    "/api/epg/status": epg_status,
    "/api/reminders": reminders_list,
    "/api/media/sources": media_sources,
    "/api/display": display_info,
    "/api/cec": cec_status,
}
QUERY_ROUTES = {  # bekommen (query, headers)
    "/api/epg": lambda q, h: epg_range(q),
    "/api/reminders/due": reminders_due,
    "/api/media/list": lambda q, h: media_list(q),
}
POST_ROUTES = {
    "/api/channels/config": channels_config,
    "/api/channels/reset": channels_reset,
    "/api/channels/m3u": channels_m3u,
    "/api/epg/refresh": epg_refresh,
    "/api/reminders/add": reminders_add,
    "/api/reminders/remove": reminders_remove,
    "/api/media/shares/add": shares_add,
    "/api/media/shares/remove": shares_remove,
    "/api/display": display_set,
    "/api/display/scale": display_scale,
}
FILE_ROUTES = {"/media/file", "/media/thumb"}


def start_background():
    threading.Thread(target=epg_updater, daemon=True).start()


def thumb_url(src, rel):
    return f"/media/thumb?src={quote(src)}&path={quote(rel)}"


# ==========================================================================
# Suche im TV-Programm
# ==========================================================================
def epg_search(query):
    q = _norm((query.get("q", [""])[0] or "")[:60])
    if len(q) < 2:
        return {"results": []}
    now = time.time()
    order = {c["name"]: i for i, c in enumerate(all_channels())}
    res = []
    for name, lst in _epg_data().get("programs", {}).items():
        if name not in order:
            continue
        for p in lst:
            if p[1] <= now:
                continue
            if q in _norm(p[2]) or q in _norm(p[3]):
                d = _prog(p)
                d["channel"] = name
                d["index"] = order[name]
                res.append(d)
    res.sort(key=lambda r: (r["start"], r["index"]))
    return {"results": res[:60]}


# ==========================================================================
# Automatisch ausschalten (Auto-Standby) bei längerer Nichtbenutzung
# ==========================================================================
LAST_INPUT_FILE = "/run/raspi-tv/last-input"
_activity = {"last": time.time(), "left": None}


def touch_activity(_data=None):
    _activity["last"] = time.time()
    _activity["left"] = None
    return {"ok": True}


def last_input():
    try:
        return max(_activity["last"], os.path.getmtime(LAST_INPUT_FILE))
    except OSError:
        return _activity["last"]


def autooff_left():
    return _activity["left"]


def _set_tv_power(state):
    try:
        os.makedirs(os.path.dirname(T["TV_POWER_FILE"]), exist_ok=True)
        with open(T["TV_POWER_FILE"], "w") as f:
            f.write(state)
    except OSError:
        pass


def autooff_loop():
    while True:
        time.sleep(15)
        try:
            hours = int(_cfg().get("auto_off_hours", 4) or 0)
            if not hours or T["tv_power"]() == "standby":
                _activity["left"] = None
                continue
            left = last_input() + hours * 3600 - time.time()
            if left <= 0:
                _activity["left"] = None
                T["tv_standby"]()
                _set_tv_power("standby")
                touch_activity()
            elif left <= 120:
                _activity["left"] = int(left)   # Warnung wird in der Oberfläche angezeigt
            else:
                _activity["left"] = None
        except Exception:  # noqa: BLE001 – Hintergrundschleife darf nie sterben
            pass


QUERY_ROUTES["/api/epg/search"] = lambda q, h: epg_search(q)
OPEN_POST_ROUTES = {"/api/activity": touch_activity}   # harmlos, ohne Herkunftsprüfung (Erweiterung)
_old_start = start_background


def start_background():  # noqa: F811
    _old_start()
    threading.Thread(target=autooff_loop, daemon=True).start()


# ==========================================================================
# Software-Update per USB-Stick
# ==========================================================================
import zipfile  # noqa: E402

UPDATE_DIR = "/var/cache/raspi-tv/update"
SWUPDATE_LOG = "/var/log/raspi-tv-swupdate.log"
_swu = {"running": False, "step": None, "done": False, "error": None, "version": None}


def _zip_names(zf):
    """Einträge mit normalisierten Pfaden (Windows-Zip nutzt manchmal Backslashes)."""
    out = []
    for info in zf.infolist():
        name = info.filename.replace("\\", "/").lstrip("/")
        parts = [p for p in name.split("/") if p not in ("", ".")]
        if not parts or ".." in parts:
            continue
        out.append((info, "/".join(parts)))
    return out


def _zip_root(names):
    """Ordner im Zip, in dem das Projekt liegt (system/tvctl.py)."""
    for n in names:
        if n.endswith("system/tvctl.py"):
            return n[: -len("system/tvctl.py")]
    return None


def _installed_version():
    for line in T["read_file"]("/etc/raspi-tv-release").splitlines():
        if line.startswith("VERSION="):
            return line.split("=", 1)[1].strip('"')
    return "?"


def swupdate_check():
    found = []
    for s in media_sources()["sources"]:
        if s["kind"] != "usb":
            continue
        root = os.path.join(MEDIA_ROOT, s["id"])
        try:
            names = os.listdir(root)
        except OSError:
            continue
        for n in sorted(names):
            if re.match(r"(?i)^raspi-tv-update.*\.zip$", n):
                path = os.path.join(root, n)
                ver = None
                try:
                    with zipfile.ZipFile(path) as zf:
                        names = _zip_names(zf)
                        r = _zip_root([x[1] for x in names])
                        if r is None:
                            continue
                        for info, nm in names:
                            if nm == r + "VERSION":
                                ver = zf.read(info).decode("utf-8", "replace").strip()[:20]
                except (zipfile.BadZipFile, OSError):
                    continue
                found.append({"src": s["id"], "file": n, "name": s["name"], "version": ver or "?",
                              "size": os.path.getsize(path)})
    return {"installed": _installed_version(), "found": found, "status": swupdate_status()}


def swupdate_status():
    tail = T["read_file"](SWUPDATE_LOG).splitlines()[-5:]
    return dict(_swu, log=tail)


def _swupdate_worker(zpath):
    try:
        shutil.rmtree(UPDATE_DIR, ignore_errors=True)
        os.makedirs(UPDATE_DIR)
        _swu["step"] = "Update wird entpackt"
        with zipfile.ZipFile(zpath) as zf:
            names = _zip_names(zf)
            root = _zip_root([n for _, n in names])
            if root is None:
                raise RuntimeError("Das ist kein Raspi-TV-Update-Paket.")
            total = 0
            for info, nm in names:
                # Ordner-Einträge (auch Windows-Zips mit "\\") und Browser-Zwischendateien überspringen
                if (not nm.startswith(root) or info.is_dir() or info.filename.endswith(("/", "\\"))
                        or "/_metadata/" in "/" + nm + "/"):
                    continue
                total += info.file_size
                if total > 300_000_000:
                    raise RuntimeError("Update-Paket ist zu groß.")
                dest = os.path.join(UPDATE_DIR, nm[len(root):])
                parent = os.path.dirname(dest)
                if os.path.isfile(parent):   # alter Fehler: Ordner war als Datei angelegt
                    os.remove(parent)
                os.makedirs(parent, exist_ok=True)
                with zf.open(info) as src, open(dest, "wb") as out:
                    shutil.copyfileobj(src, out)
        _unix_line_endings(UPDATE_DIR)
        for req in ("system/tvctl.py", "system/install-files.sh", "system/apply-update.sh", "launcher/index.html"):
            if not os.path.exists(os.path.join(UPDATE_DIR, req)):
                raise RuntimeError(f"Update-Paket unvollständig ({req} fehlt).")
        try:
            with open(os.path.join(UPDATE_DIR, "VERSION")) as f:
                _swu["version"] = f.read().strip()[:20]
        except OSError:
            pass
        _swu["step"] = "Aktuelle Version wird gesichert"
        snapshot = _rollback_snapshot()
        with open(SWUPDATE_LOG, "w") as log:
            p = subprocess.Popen(["bash", os.path.join(UPDATE_DIR, "system/apply-update.sh"), UPDATE_DIR],
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            for line in p.stdout:
                log.write(line)
                log.flush()
                if line.startswith("STEP "):
                    _swu["step"] = line[5:].strip()
            rc = p.wait()
        if rc != 0:
            raise RuntimeError("Installation fehlgeschlagen – Details im Protokoll.")
        _swu.update(done=True, step="Raspi-TV startet neu …")
        # Neustart plant apply-update.sh; das hier ist nur der Rückfall.
        # Nach dem Start prüft raspi-tv-update-check, ob die neue Version läuft (sonst automatisch zurück).
        subprocess.Popen(["bash", "-c", "sleep 15; systemctl reboot"], start_new_session=True)
    except Exception as e:  # noqa: BLE001
        _swu["error"] = str(e)
    finally:
        _swu["running"] = False


def swupdate_install(data):
    if _swu["running"]:
        return swupdate_status()
    src, fname = str(data.get("src", "")), str(data.get("file", ""))
    if not re.match(r"(?i)^raspi-tv-update[^/\\]*\.zip$", fname):
        raise _err("Ungültige Update-Datei")
    root = _source_root(src)
    zpath = os.path.join(root, fname)
    if not os.path.isfile(zpath):
        raise _err("Update-Datei nicht gefunden – Stick noch eingesteckt?", 404)
    _swu.update(running=True, done=False, error=None, step="Wird vorbereitet", version=None)
    threading.Thread(target=_swupdate_worker, args=(zpath,), daemon=True).start()
    return swupdate_status()


import subprocess  # noqa: E402

GET_ROUTES["/api/swupdate"] = swupdate_check
GET_ROUTES["/api/swupdate/status"] = swupdate_status
POST_ROUTES["/api/swupdate/install"] = swupdate_install


# ==========================================================================
# Wetter (Open-Meteo, kostenlos, ohne Anmeldung)
# ==========================================================================
REGION_CITIES = {
    "BW": ("Stuttgart", 48.78, 9.18), "BY": ("München", 48.14, 11.58), "BE": ("Berlin", 52.52, 13.40),
    "BB": ("Potsdam", 52.40, 13.06), "HB": ("Bremen", 53.08, 8.80), "HH": ("Hamburg", 53.55, 9.99),
    "HE": ("Frankfurt am Main", 50.11, 8.68), "MV": ("Rostock", 54.09, 12.10), "NI": ("Hannover", 52.37, 9.73),
    "NW": ("Köln", 50.94, 6.96), "RP": ("Mainz", 49.99, 8.27), "SL": ("Saarbrücken", 49.24, 6.99),
    "SN": ("Dresden", 51.05, 13.74), "ST": ("Magdeburg", 52.13, 11.62), "SH": ("Kiel", 54.32, 10.14),
    "TH": ("Erfurt", 50.98, 11.03),
}
_weather = {"key": None, "at": 0, "data": None}


def weather_place():
    cfg = _cfg()
    w = cfg.get("weather_place")
    if isinstance(w, dict) and "lat" in w:
        return w
    name, lat, lon = REGION_CITIES.get(cfg.get("region") or "", ("Berlin", 52.52, 13.40))
    return {"name": name, "lat": lat, "lon": lon}


def weather():
    place = weather_place()
    key = (round(place["lat"], 3), round(place["lon"], 3))
    if _weather["key"] == key and time.time() - _weather["at"] < 1200 and _weather["data"]:
        return _weather["data"]
    url = ("https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s"
           "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,relative_humidity_2m,is_day"
           "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max"
           "&timezone=Europe%%2FBerlin&forecast_days=6" % key)
    try:
        d = json.loads(_download(url, limit=200_000, timeout=15))
    except Exception:  # noqa: BLE001
        if _weather["data"]:
            return _weather["data"]
        raise _err("Wetter gerade nicht verfügbar", 503)
    cur = d.get("current", {})
    daily = d.get("daily", {})
    days = []
    for i, day in enumerate(daily.get("time", [])):
        days.append({"date": day, "code": daily["weather_code"][i], "max": daily["temperature_2m_max"][i],
                     "min": daily["temperature_2m_min"][i],
                     "rain": (daily.get("precipitation_probability_max") or [None] * 9)[i]})
    data = {"place": place["name"], "temp": cur.get("temperature_2m"), "feels": cur.get("apparent_temperature"),
            "code": cur.get("weather_code"), "wind": cur.get("wind_speed_10m"), "humidity": cur.get("relative_humidity_2m"),
            "day": cur.get("is_day", 1), "days": days, "at": time.time()}
    _weather.update(key=key, at=time.time(), data=data)
    return data


def weather_search(query):
    q = (query.get("q", [""])[0] or "").strip()[:60]
    if len(q) < 2:
        return {"results": []}
    url = "https://geocoding-api.open-meteo.com/v1/search?count=8&language=de&name=" + quote(q)
    try:
        d = json.loads(_download(url, limit=200_000, timeout=15))
    except Exception:  # noqa: BLE001
        raise _err("Ortssuche gerade nicht verfügbar", 503)
    res = []
    for r in d.get("results", []) or []:
        res.append({"name": r.get("name"), "lat": r.get("latitude"), "lon": r.get("longitude"),
                    "area": ", ".join(x for x in (r.get("admin1"), r.get("country")) if x)})
    return {"results": res}


def weather_set(data):
    cfg = _cfg()
    if data.get("reset"):
        cfg.pop("weather_place", None)
    else:
        try:
            place = {"name": str(data["name"])[:60], "lat": float(data["lat"]), "lon": float(data["lon"])}
        except (KeyError, TypeError, ValueError):
            raise _err("Ungültiger Ort")
        if not (-90 <= place["lat"] <= 90 and -180 <= place["lon"] <= 180):
            raise _err("Ungültiger Ort")
        cfg["weather_place"] = place
    _save(cfg)
    _weather["key"] = None
    return {"place": weather_place()}


# ==========================================================================
# AirPlay (Musik vom iPhone/Mac) & Gerätename
# ==========================================================================
def _airplay_running():
    code, out, _ = T["run"](["pgrep", "-u", T["TV_USER"], "-x", "shairport-sync"], 5)
    return code == 0


def airplay_start():
    if _airplay_running() or not shutil.which("shairport-sync"):
        return
    import pwd
    uid = pwd.getpwnam(T["TV_USER"]).pw_uid
    import socket
    name = _cfg().get("device_name") or socket.gethostname()
    subprocess.Popen(["runuser", "-u", T["TV_USER"], "--", "env", f"XDG_RUNTIME_DIR=/run/user/{uid}",
                      "shairport-sync", "-a", name, "-o", "pa"],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)


def airplay_stop():
    T["run"](["pkill", "-u", T["TV_USER"], "-x", "shairport-sync"], 5)


def airplay_status():
    return {"available": bool(shutil.which("shairport-sync")), "enabled": bool(_cfg().get("airplay")),
            "running": _airplay_running(), "name": _cfg().get("device_name") or __import__("socket").gethostname()}


def airplay_set(data):
    on = bool(data.get("enabled"))
    if on and not shutil.which("shairport-sync"):
        raise _err("AirPlay ist noch nicht installiert – bitte System aktualisieren.")
    cfg = _cfg()
    cfg["airplay"] = on
    _save(cfg)
    (airplay_start if on else airplay_stop)()
    time.sleep(0.5)
    return airplay_status()


def airplay_keeper():
    """Startet AirPlay nach dem Hochfahren (sobald der Ton des TV-Benutzers bereit ist) und hält es am Laufen."""
    time.sleep(25)
    while True:
        try:
            if _cfg().get("airplay") and not _airplay_running():
                airplay_start()
        except Exception:  # noqa: BLE001
            pass
        time.sleep(60)


def device_name_set(data):
    name = str(data.get("name") or "").strip()
    if not re.match(r"^[A-Za-z0-9][A-Za-z0-9-]{0,30}[A-Za-z0-9]$", name):
        raise _err("Bitte 2–32 Zeichen: Buchstaben, Ziffern und Bindestrich (keine Umlaute/Leerzeichen).")
    code, _, err = T["run"](["hostnamectl", "set-hostname", name], 15)
    if code != 0:
        raise _err("Name konnte nicht geändert werden: " + err.strip()[:80])
    try:
        with open("/etc/hosts") as f:
            hosts = f.read()
        hosts = re.sub(r"(?m)^127\.0\.1\.1\s+.*$", f"127.0.1.1\t{name}", hosts)
        if "127.0.1.1" not in hosts:
            hosts += f"127.0.1.1\t{name}\n"
        with open("/etc/hosts", "w") as f:
            f.write(hosts)
    except OSError:
        pass
    cfg = _cfg()
    cfg["device_name"] = name
    _save(cfg)
    T["run"](["systemctl", "restart", "avahi-daemon"], 15)
    if cfg.get("airplay"):
        airplay_stop()
        airplay_start()
    return {"name": name}


GET_ROUTES["/api/weather"] = weather
QUERY_ROUTES["/api/weather/search"] = lambda q, h: weather_search(q)
POST_ROUTES["/api/weather/place"] = weather_set
GET_ROUTES["/api/airplay"] = airplay_status
POST_ROUTES["/api/airplay"] = airplay_set
POST_ROUTES["/api/device-name"] = device_name_set
_old_start2 = start_background


def start_background():  # noqa: F811
    _old_start2()
    threading.Thread(target=airplay_keeper, daemon=True).start()


# ==========================================================================
# App Store
#   Web-Apps:  werden in der Konfiguration "installiert" (store_apps) und
#              erscheinen auf der Startseite. Der Katalog liegt im Launcher.
#   Eigene:    beliebige Webadresse als App (custom_apps).
#   Programme: echte Linux-Programme (Kodi, RetroArch, Moonlight) – werden
#              per apt installiert und als Vollbild über der Oberfläche gestartet.
# ==========================================================================
STORE_ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,31}$")
MOONLIGHT_LIST = "/etc/apt/sources.list.d/moonlight-game-streaming-moonlight-qt.list"
NATIVE_APPS = {
    "kodi": {"name": "Kodi", "pkgs": ["kodi"],
             "optional": ["kodi-inputstream-adaptive", "kodi-peripheral-joystick"],
             "bin": "kodi", "cmd": ["kodi", "-fs"], "procs": ["kodi.bin", "kodi"]},
    "retroarch": {"name": "RetroArch", "pkgs": ["retroarch"],
                  "optional": ["libretro-nestopia", "libretro-gambatte", "libretro-mgba", "libretro-snes9x",
                               "libretro-genesisplusgx", "libretro-desmume"],
                  "bin": "retroarch", "cmd": ["retroarch", "-f"], "procs": ["retroarch"]},
    "moonlight": {"name": "Moonlight", "pkgs": ["moonlight-qt"], "optional": [], "repo": "moonlight",
                  "bin": "moonlight-qt", "cmd": ["moonlight-qt"], "procs": ["moonlight-qt"]},
}
NATIVE_PID_FILE = "/run/raspi-tv-native"     # liest auch der Fernbedienungsdienst (Home beendet das Programm)
NATIVE_LOG = "/var/log/raspi-tv-store.log"
_job = {"running": False, "id": None, "action": None, "step": None, "percent": 0, "error": None, "done": False}
_native = {"id": None, "proc": None}
_apt_lock = threading.Lock()


def _valid_url(u):
    return isinstance(u, str) and len(u) <= 300 and re.match(r"^https?://[^\s\"'<>]+$", u) is not None


def store_state():
    cfg = _cfg()
    native = {k: {"installed": bool(shutil.which(v["bin"])), "running": _native["id"] == k and native_running()}
              for k, v in NATIVE_APPS.items()}
    return {"installed": cfg.get("store_apps", []), "custom": cfg.get("custom_apps", []),
            "native": native, "job": dict(_job)}


def store_install(data):
    app_id = str(data.get("id", ""))
    if not STORE_ID_RE.match(app_id) or app_id in NATIVE_APPS:
        raise _err("Unbekannte App")
    cfg = _cfg()
    lst = [a for a in cfg.get("store_apps", []) if a != app_id]
    lst.append(app_id)
    cfg["store_apps"] = lst[-80:]
    _save(cfg)
    return store_state()


def store_remove(data):
    app_id = str(data.get("id", ""))
    cfg = _cfg()
    cfg["store_apps"] = [a for a in cfg.get("store_apps", []) if a != app_id]
    cfg["custom_apps"] = [a for a in cfg.get("custom_apps", []) if a.get("id") != app_id]
    _save(cfg)
    return store_state()


def store_custom(data):
    name = str(data.get("name", "")).strip()[:30]
    url = str(data.get("url", "")).strip()
    if url and not re.match(r"^https?://", url, re.I):
        url = "http://" + url
    if not name:
        raise _err("Bitte einen Namen eingeben.")
    if not _valid_url(url):
        raise _err("Bitte eine gültige Adresse eingeben, z. B. http://192.168.178.20:8096")
    color = str(data.get("color", ""))
    if not re.match(r"^#[0-9a-fA-F]{6}$", color):
        color = "#334155"
    cfg = _cfg()
    lst = cfg.get("custom_apps", [])
    if len(lst) >= 30:
        raise _err("Es sind schon 30 eigene Apps angelegt.")
    app = {"id": "custom-" + hashlib.sha1((name + url + str(time.time())).encode()).hexdigest()[:8],
           "name": name, "url": url, "c1": color, "from": str(data.get("from", ""))[:32]}
    cfg["custom_apps"] = lst + [app]
    _save(cfg)
    return {"app": app, **store_state()}


# --- Programme (apt) -------------------------------------------------------
def _apt_env():
    env = dict(os.environ)
    env.update(DEBIAN_FRONTEND="noninteractive", APT_LISTCHANGES_FRONTEND="none", LC_ALL="C")
    return env


def _apt(args, log, lo, hi):
    """apt-get mit Fortschritt (APT::Status-Fd). Bildet 0–100 % auf lo–hi ab."""
    cmd = ["apt-get", "-y", "-o", "APT::Status-Fd=1", "-o", "Dpkg::Use-Pty=0",
           "-o", "DPkg::Lock::Timeout=300", "-o", "Dpkg::Options::=--force-confdef",
           "-o", "Dpkg::Options::=--force-confold"] + args
    log.write("$ " + " ".join(cmd) + "\n")
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, env=_apt_env())
    for line in p.stdout:
        log.write(line)
        log.flush()
        m = re.match(r"^(dlstatus|pmstatus):[^:]*:([\d.]+):(.*)$", line.strip())
        if m:
            pct = float(m.group(2))
            if m.group(1) == "dlstatus":
                _job["step"] = "Wird heruntergeladen"
                frac = pct / 200
            else:
                _job["step"] = "Wird installiert" if args[0] == "install" else "Wird entfernt"
                frac = 0.5 + pct / 200
            _job["percent"] = max(_job["percent"], int(lo + (hi - lo) * min(frac, 1)))
    return p.wait()


def _codename():
    for line in T["read_file"]("/etc/os-release").splitlines():
        if line.startswith("VERSION_CODENAME="):
            return line.split("=", 1)[1].strip().strip('"')
    return "trixie"


def _native_worker(app_id, action):
    app = NATIVE_APPS[app_id]
    try:
        with _apt_lock, open(NATIVE_LOG, "a") as log:
            log.write(f"\n=== {time.strftime('%Y-%m-%d %H:%M:%S')} {action} {app_id} ===\n")
            if action == "install":
                if app.get("repo") == "moonlight" and not os.path.exists(MOONLIGHT_LIST):
                    _job.update(step="Paketquelle wird eingerichtet", percent=2)
                    p = subprocess.run(
                        ["bash", "-c", "curl -1sLf 'https://dl.cloudsmith.io/public/moonlight-game-streaming/"
                         "moonlight-qt/setup.deb.sh' | env distro=raspbian codename=\"$1\" bash", "_", _codename()],
                        stdout=log, stderr=subprocess.STDOUT, env=_apt_env(), timeout=600)
                    if p.returncode != 0:
                        raise RuntimeError("Paketquelle von Moonlight nicht erreichbar.")
                else:
                    _job.update(step="Paketlisten werden geladen", percent=2)
                    _apt(["update"], log, 2, 8)
                _job["step"] = "Wird heruntergeladen"
                if _apt(["install"] + app["pkgs"], log, 8, 85) != 0:
                    if app.get("repo") == "moonlight":
                        try:
                            os.remove(MOONLIGHT_LIST)
                        except OSError:
                            pass
                    raise RuntimeError(f"{app['name']} konnte nicht installiert werden – "
                                       "für dieses System nicht verfügbar oder keine Verbindung.")
                opt = app.get("optional", [])
                for i, pkg in enumerate(opt):   # Zusätze einzeln – fehlt einer, ist das kein Fehler
                    _job["step"] = "Erweiterungen werden installiert"
                    _apt(["install", pkg], log, 85 + 14 * i / max(len(opt), 1), 85 + 14 * (i + 1) / max(len(opt), 1))
            else:
                native_stop()
                pkgs = [p for p in app["pkgs"] + app.get("optional", [])
                        if subprocess.run(["dpkg", "-s", p], capture_output=True).returncode == 0]
                if pkgs and _apt(["remove"] + pkgs, log, 5, 80) != 0:
                    raise RuntimeError(f"{app['name']} konnte nicht entfernt werden.")
                _job["step"] = "Wird aufgeräumt"
                _apt(["autoremove"], log, 80, 99)
                if app.get("repo") == "moonlight":
                    try:
                        os.remove(MOONLIGHT_LIST)
                    except OSError:
                        pass
        _job.update(done=True, percent=100, step="Fertig")
    except Exception as e:  # noqa: BLE001
        _job["error"] = str(e)
    finally:
        _job["running"] = False


def native_job(action):
    def handler(data):
        app_id = str(data.get("id", ""))
        if app_id not in NATIVE_APPS:
            raise _err("Unbekanntes Programm")
        if _job["running"]:
            raise _err("Es läuft schon eine Installation – bitte kurz warten.", 409)
        _job.update(running=True, id=app_id, action=action, step="Wird vorbereitet", percent=0,
                    error=None, done=False)
        threading.Thread(target=_native_worker, args=(app_id, action), daemon=True).start()
        return store_state()
    return handler


# --- Programme starten ------------------------------------------------------
def native_running():
    p = _native["proc"]
    return p is not None and p.poll() is None


def _native_watch(proc, app_id):
    while proc.poll() is None:
        touch_activity()            # während Kodi & Co. laufen, nicht automatisch ausschalten
        for _ in range(30):
            if proc.poll() is not None:
                break
            time.sleep(1)
    try:
        os.remove(NATIVE_PID_FILE)
    except OSError:
        pass
    if _native["proc"] is proc:
        _native.update(id=None, proc=None)
    touch_activity()
    if app_id == "kodi":
        # Kodi spricht selbst HDMI-CEC – danach meldet sich Raspi-TV wieder beim Fernseher an
        T["run"](["systemctl", "restart", "raspi-tv-cec"], 20)


def native_launch(data):
    import pwd
    app_id = str(data.get("id", ""))
    app = NATIVE_APPS.get(app_id)
    if not app:
        raise _err("Unbekanntes Programm")
    if not shutil.which(app["bin"]):
        raise _err(f"{app['name']} ist nicht installiert.")
    if native_running():
        return native_status()
    user = T["TV_USER"]
    uid = pwd.getpwnam(user).pw_uid
    log = open(f"/var/log/raspi-tv/native-{app_id}.log", "w") if os.path.isdir("/var/log/raspi-tv") \
        else subprocess.DEVNULL
    proc = subprocess.Popen(["runuser", "-u", user, "--", "env", f"XDG_RUNTIME_DIR=/run/user/{uid}", "DISPLAY=:0",
                             f"XAUTHORITY=/home/{user}/.Xauthority", f"HOME=/home/{user}"] + app["cmd"],
                            stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, start_new_session=True,
                            cwd=f"/home/{user}" if os.path.isdir(f"/home/{user}") else "/")
    _native.update(id=app_id, proc=proc)
    try:
        with open(NATIVE_PID_FILE, "w") as f:
            f.write(f"{proc.pid}\n")
    except OSError:
        pass
    threading.Thread(target=_native_watch, args=(proc, app_id), daemon=True).start()
    return native_status()


def native_stop(_data=None):
    p = _native["proc"]
    if p is not None and p.poll() is None:
        import signal
        try:
            os.killpg(p.pid, signal.SIGTERM)
            for _ in range(30):
                if p.poll() is not None:
                    break
                time.sleep(0.1)
            if p.poll() is None:
                os.killpg(p.pid, signal.SIGKILL)
        except OSError:
            pass
    return native_status()


def native_status():
    app_id = _native["id"] if native_running() else None
    return {"running": app_id, "name": NATIVE_APPS[app_id]["name"] if app_id else None}


GET_ROUTES["/api/store"] = store_state
POST_ROUTES["/api/store/install"] = store_install
POST_ROUTES["/api/store/remove"] = store_remove
POST_ROUTES["/api/store/custom"] = store_custom
POST_ROUTES["/api/native/install"] = native_job("install")
POST_ROUTES["/api/native/remove"] = native_job("remove")
POST_ROUTES["/api/native/launch"] = native_launch
POST_ROUTES["/api/native/stop"] = native_stop
GET_ROUTES["/api/native"] = native_status


# ==========================================================================
# Spotify Connect (librespot aus dem Raspotify-Paket)
#   Der Pi erscheint in der Spotify-App als Lautsprecher "Raspi-TV".
#   Wird beim ersten Einschalten installiert, läuft als TV-Benutzer über PipeWire.
# ==========================================================================
RASPOTIFY_DEB = "https://dtcooper.github.io/raspotify/raspotify-latest_{arch}.deb"
SPOTIFY_EVENT_FILE = "/home/{user}/.cache/raspi-tv/spotify.json"
SPOTIFY_HOOK = "/opt/raspi-tv/spotify-event.sh"


def _spotify_running():
    code, _, _ = T["run"](["pgrep", "-u", T["TV_USER"], "-x", "librespot"], 5)
    return code == 0


def _device_name():
    return _cfg().get("device_name") or __import__("socket").gethostname()


def spotify_start():
    if _spotify_running() or not shutil.which("librespot"):
        return
    import pwd
    user = T["TV_USER"]
    uid = pwd.getpwnam(user).pw_uid
    cache = f"/home/{user}/.cache/librespot"
    base = ["runuser", "-u", user, "--", "env", f"XDG_RUNTIME_DIR=/run/user/{uid}", f"HOME=/home/{user}",
            "librespot", "--name", _device_name(), "--device-type", "tv", "--bitrate", "320",
            "--initial-volume", "70", "--enable-volume-normalisation", "--cache", cache, "--disable-audio-cache"]
    if os.path.exists(SPOTIFY_HOOK):
        base += ["--onevent", SPOTIFY_HOOK]
    log = open("/var/log/raspi-tv/spotify.log", "a") if os.path.isdir("/var/log/raspi-tv") else subprocess.DEVNULL
    # Erst PulseAudio-Ausgabe (PipeWire), sonst ALSA (über pipewire-alsa ebenfalls PipeWire)
    for backend in (["--backend", "pulseaudio"], ["--backend", "alsa"]):
        p = subprocess.Popen(base + backend, stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                             start_new_session=True, cwd="/")
        time.sleep(2)
        if p.poll() is None:
            return


def spotify_stop():
    T["run"](["pkill", "-u", T["TV_USER"], "-x", "librespot"], 5)
    try:
        os.remove(SPOTIFY_EVENT_FILE.format(user=T["TV_USER"]))
    except OSError:
        pass


def spotify_now():
    """Was gerade über Spotify Connect läuft (schreibt das Ereignis-Skript)."""
    if not _cfg().get("spotify"):
        return {"playing": False}
    try:
        with open(SPOTIFY_EVENT_FILE.format(user=T["TV_USER"])) as f:
            ev = json.load(f)
    except (OSError, ValueError):
        return {"playing": False}
    state_ = ev.get("state")
    return {"playing": state_ == "playing", "paused": state_ == "paused", "title": ev.get("title", "")[:120],
            "artist": ev.get("artist", "")[:120], "album": ev.get("album", "")[:120],
            "cover": ev.get("cover", "") if str(ev.get("cover", "")).startswith("https://") else "",
            "duration": ev.get("duration", 0), "position": ev.get("position", 0), "at": ev.get("at", 0)}


def spotify_status():
    job = dict(_job) if _job.get("id") == "spotify" else None
    return {"available": bool(shutil.which("librespot")), "enabled": bool(_cfg().get("spotify")),
            "running": _spotify_running(), "name": _device_name(), "job": job}


def _spotify_install_worker():
    try:
        with _apt_lock, open(NATIVE_LOG, "a") as log:
            log.write(f"\n=== {time.strftime('%Y-%m-%d %H:%M:%S')} install spotify-connect ===\n")
            _, arch, _ = T["run"](["dpkg", "--print-architecture"], 10)
            arch = arch.strip() or "arm64"
            os.makedirs("/var/cache/raspi-tv", exist_ok=True)
            deb = "/var/cache/raspi-tv/raspotify.deb"
            _job.update(step="Wird heruntergeladen", percent=10)
            p = subprocess.run(["curl", "-fsSL", "--retry", "3", "-o", deb, RASPOTIFY_DEB.format(arch=arch)],
                               stdout=log, stderr=subprocess.STDOUT, timeout=600)
            if p.returncode != 0:
                raise RuntimeError("Spotify Connect konnte nicht geladen werden – Internetverbindung prüfen.")
            _job.update(step="Wird installiert", percent=40)
            if _apt(["install", deb], log, 40, 95) != 0:
                raise RuntimeError("Spotify Connect konnte nicht installiert werden.")
            # Der Systemdienst des Pakets bleibt aus – Raspi-TV startet librespot selbst (Ton über PipeWire)
            T["run"](["systemctl", "disable", "--now", "raspotify"], 30)
            try:
                os.remove(deb)
            except OSError:
                pass
        spotify_start()
        _job.update(done=True, percent=100, step="Fertig")
    except Exception as e:  # noqa: BLE001
        _job["error"] = str(e)
        cfg = _cfg()
        cfg["spotify"] = False
        _save(cfg)
    finally:
        _job["running"] = False


def spotify_set(data):
    on = bool(data.get("enabled"))
    cfg = _cfg()
    cfg["spotify"] = on
    _save(cfg)
    if not on:
        spotify_stop()
        return spotify_status()
    if shutil.which("librespot"):
        spotify_start()
        return spotify_status()
    if _job["running"]:
        raise _err("Es läuft schon eine Installation – bitte kurz warten.", 409)
    _job.update(running=True, id="spotify", action="install", step="Wird vorbereitet", percent=0,
                error=None, done=False)
    threading.Thread(target=_spotify_install_worker, daemon=True).start()
    return spotify_status()


def spotify_keeper():
    time.sleep(30)   # nach dem Hochfahren: Ton des TV-Benutzers abwarten
    while True:
        try:
            if _cfg().get("spotify") and not _job["running"] and not _spotify_running():
                spotify_start()
        except Exception:  # noqa: BLE001
            pass
        time.sleep(60)


_old_device_name_set = device_name_set


def device_name_set(data):  # noqa: F811 – neuer Name auch für Spotify Connect
    r = _old_device_name_set(data)
    if _cfg().get("spotify"):
        spotify_stop()
        spotify_start()
    return r


POST_ROUTES["/api/device-name"] = device_name_set
GET_ROUTES["/api/spotify"] = spotify_status
POST_ROUTES["/api/spotify"] = spotify_set
GET_ROUTES["/api/spotify/now"] = spotify_now
_old_start3 = start_background


def start_background():  # noqa: F811
    _old_start3()
    threading.Thread(target=spotify_keeper, daemon=True).start()


# ==========================================================================
# Fernbedienungs-WLAN
#   Ist Raspi-TV per LAN-Kabel verbunden, ist sein WLAN-Chip frei. Er spannt dann
#   ein eigenes kleines WLAN auf – nur für die Handy-Fernbedienung, OHNE Internet
#   (Weiterleitung ins Heimnetz wird blockiert). Praktisch, wenn das Heim-WLAN
#   nachts abgeschaltet wird.
# ==========================================================================
HOTSPOT_CON = "raspi-tv-remote"
HOTSPOT_IP = "10.42.0.1"
HOTSPOT_NFT = f"""table inet raspitv_remote {{
  chain block_forward {{
    type filter hook forward priority -150; policy accept;
    iifname "{{dev}}" drop
    oifname "{{dev}}" drop
  }}
}}
"""
_hs = {"error": None, "active": False, "step": None}


def _hs_cfg():
    p = _state("hotspot.json")
    try:
        with open(p) as f:
            c = json.load(f)
    except (OSError, ValueError):
        c = {}
    changed = False
    if not c.get("password"):
        import secrets
        alphabet = "abcdefghjkmnpqrstuvwxyz23456789"
        c["password"] = "".join(secrets.choice(alphabet) for _ in range(10))
        changed = True
    c.setdefault("mode", "off")        # off | night | always
    c.setdefault("internet", False)    # Internet über das LAN-Kabel des Pi weitergeben
    c.setdefault("start", 21)
    c.setdefault("end", 7)
    if changed:
        _hs_save(c)
    return c


def _hs_save(c):
    _write_json(_state("hotspot.json"), c)
    try:
        os.chmod(_state("hotspot.json"), 0o600)
    except OSError:
        pass


def _hs_ssid():
    return (_device_name() + " Fernbedienung")[:32]


def _wifi_dev():
    code, out, _ = T["run"](["nmcli", "-t", "-f", "DEVICE,TYPE", "device"], 10)
    for line in out.splitlines():
        parts = T["nm_split"](line)
        if len(parts) >= 2 and parts[1] == "wifi":
            return parts[0]
    return None


def _hs_should_run(c, now=None):
    if c["mode"] == "always":
        return True
    if c["mode"] != "night":
        return False
    h = (now or datetime.now()).hour
    s, e = int(c["start"]), int(c["end"])
    return (h >= s or h < e) if s > e else (s <= h < e)


def _hs_active():
    code, out, _ = T["run"](["nmcli", "-t", "-f", "NAME", "connection", "show", "--active"], 10)
    return HOTSPOT_CON in out.splitlines()


HOTSPOT_LOG = "/var/log/raspi-tv/hotspot.log"
_hs_lock = threading.Lock()


def _hs_log(*parts):
    try:
        os.makedirs(os.path.dirname(HOTSPOT_LOG), exist_ok=True)
        with open(HOTSPOT_LOG, "a") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + " ".join(str(p) for p in parts) + "\n")
    except OSError:
        pass


def _nm_devices():
    _, out, _ = T["run"](["nmcli", "-t", "-f", "DEVICE,TYPE,STATE", "device"], 10)
    devs = []
    for line in out.splitlines():
        parts = T["nm_split"](line)
        if len(parts) >= 3:
            devs.append((parts[0], parts[1], parts[2]))
    return devs


def _eth_connected():
    # "connected" oder "connected (externally)" – Hauptsache, das LAN-Kabel steckt und hat eine Verbindung
    return any(t == "ethernet" and st.startswith("connected") for _, t, st in _nm_devices())


def _hs_ensure_packages():
    """dnsmasq (verteilt Adressen im Fernbedienungs-WLAN) und nftables (Internet-Sperre) bei Bedarf nachinstallieren."""
    missing = [pkg for pkg, binary in (("dnsmasq-base", "dnsmasq"), ("nftables", "nft")) if not shutil.which(binary)]
    if not missing:
        return
    _hs_log("Installiere", *missing)
    _hs["step"] = "Wird eingerichtet (lädt " + ", ".join(missing) + ") …"
    with _apt_lock:
        env = _apt_env()
        p = subprocess.run(["apt-get", "-y", "-o", "DPkg::Lock::Timeout=300", "install"] + missing,
                           capture_output=True, text=True, env=env, timeout=900)
        if p.returncode != 0:
            subprocess.run(["apt-get", "update"], capture_output=True, env=env, timeout=600)
            p = subprocess.run(["apt-get", "-y", "-o", "DPkg::Lock::Timeout=300", "install"] + missing,
                               capture_output=True, text=True, env=env, timeout=900)
        _hs_log("apt:", p.returncode, (p.stdout + p.stderr)[-600:])
    if p.returncode != 0:
        raise RuntimeError("Benötigte Pakete (" + ", ".join(missing) + ") konnten nicht installiert werden – Internet prüfen.")


def _hs_set_internet(dev, internet):
    """Ohne Internet-Freigabe sperrt eine Firewall-Regel die Weiterleitung ins Heimnetz/Internet.
    Mit Freigabe übernimmt NetworkManager (geteilte Verbindung) die Weiterleitung über das LAN-Kabel."""
    T["run"](["nft", "delete", "table", "inet", "raspitv_remote"], 10)
    if internet:
        T["run"](["sysctl", "-qw", "net.ipv4.ip_forward=1"], 10)
        _hs_log("Internet-Freigabe an")
        return
    p = subprocess.run(["nft", "-f", "-"], input=HOTSPOT_NFT.replace("{dev}", dev), text=True, capture_output=True)
    if p.returncode != 0:
        _hs_log("nft:", p.stderr)
        first = p.stderr.strip().splitlines()[0][:120] if p.stderr.strip() else ""
        raise RuntimeError("Sperre fürs Fernbedienungs-WLAN konnte nicht gesetzt werden" + (": " + first if first else "."))


def _hs_clients(dev):
    if not dev or not shutil.which("iw"):
        return None
    _, out, _ = T["run"](["iw", "dev", dev, "station", "dump"], 5)
    return out.count("Station ")


def _hs_up(c):
    dev = _wifi_dev()
    if not dev:
        raise RuntimeError("Kein WLAN-Chip gefunden.")
    if not _eth_connected():
        raise RuntimeError("Geht nur, wenn Raspi-TV per LAN-Kabel mit dem Router verbunden ist.")
    _hs_ensure_packages()
    _hs["step"] = "Wird gestartet …"
    # Erst festlegen, ob Internet weitergegeben wird, dann das WLAN einschalten
    _hs_set_internet(dev, c.get("internet"))
    # WLAN-Funk freigeben (ohne Ländereinstellung blockiert Raspberry Pi OS das WLAN)
    T["run"](["rfkill", "unblock", "wifi"], 10)
    T["run"](["nmcli", "radio", "wifi", "on"], 10)
    if shutil.which("iw"):
        _, reg, _ = T["run"](["iw", "reg", "get"], 10)
        if "country 00" in reg or not reg.strip():
            T["run"](["iw", "reg", "set", "DE"], 10)
    for _ in range(15):   # warten, bis der WLAN-Chip bereit ist
        st = next((s_ for d, _, s_ in _nm_devices() if d == dev), "")
        if st and st not in ("unavailable", "unmanaged"):
            break
        time.sleep(1)
    else:
        T["run"](["nmcli", "device", "set", dev, "managed", "yes"], 10)
        _hs_log("Gerätestatus vor dem Start:", st)
    T["run"](["nmcli", "connection", "delete", HOTSPOT_CON], 15)
    args = ["nmcli", "connection", "add", "type", "wifi", "ifname", dev, "con-name", HOTSPOT_CON,
            "autoconnect", "no", "ssid", _hs_ssid(),
            "802-11-wireless.mode", "ap", "802-11-wireless.band", "bg", "802-11-wireless.channel", "6",
            "ipv4.method", "shared", "ipv4.addresses", HOTSPOT_IP + "/24", "ipv4.never-default", "yes",
            "ipv6.method", "disabled",
            "wifi-sec.key-mgmt", "wpa-psk", "wifi-sec.psk", c["password"],
            "wifi-sec.proto", "rsn", "wifi-sec.pairwise", "ccmp", "wifi-sec.group", "ccmp", "wifi-sec.pmf", "1"]
    code, out, err = T["run"](args, 20)
    if code != 0:
        _hs_log("nmcli add:", code, out, err)
        raise RuntimeError("WLAN konnte nicht angelegt werden: " + (err or out).strip()[:120])
    last = ""
    for attempt in range(2):
        code, out, err = T["run"](["nmcli", "--wait", "30", "connection", "up", HOTSPOT_CON], 45)
        if code == 0:
            _hs_log("Fernbedienungs-WLAN aktiv auf", dev)
            return
        last = (err or out).strip()
        _hs_log("nmcli up (Versuch", attempt + 1, "):", code, last)
        T["run"](["nmcli", "device", "disconnect", dev], 15)
        time.sleep(3)
    hint = ""
    if "dnsmasq" in last.lower() or "ip configuration" in last.lower():
        hint = " (dnsmasq fehlt)"
    elif "secrets" in last.lower() or "802.1x" in last.lower():
        hint = " (WLAN-Chip unterstützt den Zugangspunkt-Modus nicht)"
    raise RuntimeError("WLAN konnte nicht gestartet werden" + hint + ": " + last[:140])


def _hs_down():
    if _hs_active():
        T["run"](["nmcli", "connection", "down", HOTSPOT_CON], 20)
    T["run"](["nft", "delete", "table", "inet", "raspitv_remote"], 10)


def hotspot_apply():
    if not _hs_lock.acquire(blocking=False):
        return   # läuft schon
    try:
        c = _hs_cfg()
        want = _hs_should_run(c)
        active = _hs_active()
        try:
            if want and not active:
                _hs_up(c)
            elif not want and active:
                _hs_down()
            _hs["error"] = None
        except Exception as e:  # noqa: BLE001
            _hs["error"] = str(e)
            _hs_log("Fehler:", e)
        _hs["active"] = _hs_active()
    finally:
        _hs["step"] = None
        _hs_lock.release()


def hotspot_status():
    c = _hs_cfg()
    ssid = _hs_ssid()
    token = T["remote_token"]()
    esc_ = lambda s: re.sub(r'([\;,:"])', r"\\\1", s)  # noqa: E731 – Sonderzeichen im WLAN-QR-Code
    active = _hs_active()
    return {"mode": c["mode"], "start": c["start"], "end": c["end"], "active": active, "internet": bool(c.get("internet")),
            "clients": _hs_clients(_wifi_dev()) if active else None,
            "ssid": ssid, "password": c["password"], "error": _hs["error"],
            "ethernet": _eth_connected(), "step": _hs.get("step"), "busy": _hs_lock.locked(),
            "wifi_qr": f"WIFI:T:WPA;S:{esc_(ssid)};P:{esc_(c['password'])};;",
            "remote_url": f"http://{HOTSPOT_IP}:{T['REMOTE_PORT']}/#{token}"}


def hotspot_set(data):
    c = _hs_cfg()
    if "mode" in data:
        if data["mode"] not in ("off", "night", "always"):
            raise _err("Ungültige Einstellung")
        c["mode"] = data["mode"]
    for k in ("start", "end"):
        if k in data:
            v = data[k]
            if not isinstance(v, int) or not 0 <= v <= 23:
                raise _err("Ungültige Uhrzeit")
            c[k] = v
    if "internet" in data:
        c["internet"] = bool(data["internet"])
        if _hs_active():   # sofort umstellen, ohne das WLAN neu zu starten
            try:
                _hs_set_internet(_wifi_dev(), c["internet"])
            except RuntimeError as e:
                raise _err(str(e))
    if data.get("new_password"):
        c["password"] = ""
        _hs_save(c)
        c = _hs_cfg()
        if _hs_active():
            _hs_down()
    _hs_save(c)
    _hs["error"] = None
    threading.Thread(target=hotspot_apply, daemon=True).start()   # Einrichten kann dauern – im Hintergrund
    time.sleep(0.3)
    return hotspot_status()


def hotspot_loop():
    time.sleep(20)
    while True:
        try:
            hotspot_apply()
        except Exception:  # noqa: BLE001
            pass
        time.sleep(30)


_old_device_name_set2 = device_name_set


def device_name_set(data):  # noqa: F811 – neuer Name auch für das Fernbedienungs-WLAN
    r = _old_device_name_set2(data)
    if _hs_active():
        _hs_down()
        hotspot_apply()
    return r


POST_ROUTES["/api/device-name"] = device_name_set
GET_ROUTES["/api/hotspot"] = hotspot_status
POST_ROUTES["/api/hotspot"] = hotspot_set
_old_start4 = start_background


def start_background():  # noqa: F811
    _old_start4()
    threading.Thread(target=hotspot_loop, daemon=True).start()


# ==========================================================================
# Fernseher & Soundbar per HDMI-CEC
# ==========================================================================
_cec_cache = {"soundbar": None, "tvname": None, "at": 0}


_cec_sel = {"dev": None, "at": 0}
CEC_LOG = "/var/log/raspi-tv/cec.log"


def _cec_log(*parts):
    try:
        with open(CEC_LOG, "a") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + " ".join(str(p) for p in parts) + "\n")
    except OSError:
        pass


def _cec_dev():
    """Den HDMI-Anschluss nehmen, an dem wirklich ein Fernseher hängt (Pi 4/5 haben zwei: cec0 und cec1)."""
    devs = sorted(glob.glob("/dev/cec*"))
    if not devs:
        return None
    if _cec_sel["dev"] in devs and time.time() - _cec_sel["at"] < 300:
        return _cec_sel["dev"]
    chosen = None
    for d in devs:
        _, out, _ = T["run"](["cec-ctl", "-d", d], 6)
        m = re.search(r"Physical Address\s*:\s*([0-9a-f]\.[0-9a-f]\.[0-9a-f]\.[0-9a-f])", out)
        if m and m.group(1) != "f.f.f.f":
            chosen = d
            # noch nicht beim Fernseher angemeldet? Dann jetzt als Abspielgerät anmelden
            if re.search(r"Logical Address Mask\s*:\s*0x0000", out):
                T["run"](["cec-ctl", "-d", d, "--playback", "--osd-name", "Raspi-TV"], 10)
                _cec_log("angemeldet an", d)
            break
    chosen = chosen or devs[0]
    _cec_sel.update(dev=chosen, at=time.time())
    return chosen


def _cec(args, timeout=8, check=False):
    dev = _cec_dev()
    if not dev:
        raise _err("HDMI-CEC ist nicht verfügbar.")
    code, out, err = T["run"](["cec-ctl", "-d", dev] + args, timeout)
    nack = "Not Acknowledged" in out or "Not Acknowledged" in err or "Tx, Error" in out
    if check and (code != 0 or nack):
        _cec_log(dev, args, code, (out + err).strip()[-300:])
        _cec_sel["at"] = 0   # beim nächsten Mal Anschluss neu suchen
        raise _err("Der Fernseher antwortet nicht. Ist HDMI-CEC am Fernseher eingeschaltet "
                   "(Anynet+, SimpLink, Bravia Sync …)?")
    return code, out, err


def _cec_name(addr):
    try:
        code, out, _ = _cec(["--to", str(addr), "--give-osd-name"], 6)
    except Exception:  # noqa: BLE001
        return None
    m = re.search(r"name:\s*'?([^'\n]+)'?", out)
    return m.group(1).strip() if (code == 0 and m) else None


def _cec_devices(force=False):
    if force or time.time() - _cec_cache["at"] > 300:
        _cec_cache.update(soundbar=_cec_name(5), tvname=_cec_name(0), at=time.time())
    return _cec_cache


def _cec_key(cmd, to):
    _cec(["--to", str(to), "--user-control-pressed", f"ui-cmd={cmd}", "--user-control-released"], check=True)


def _phys_addr():
    code, out, _ = _cec([], 6)
    m = re.search(r"Physical Address\s*:\s*([0-9a-f]\.[0-9a-f]\.[0-9a-f]\.[0-9a-f])", out)
    return m.group(1) if m else None


def _volume_target():
    t = _cfg().get("volume_target", "auto")
    if t == "auto":
        # Mit Soundbar: die Soundbar (das klappt per CEC zuverlässig). Sonst Raspi-TV selbst –
        # viele Fernseher ignorieren Lautstärke-Befehle von angeschlossenen Geräten.
        if not _cec_dev():
            return "pi"
        return "soundbar" if _cec_devices()["soundbar"] else "pi"
    return t


def volume(data):
    action = data.get("action")
    if action not in ("up", "down", "mute"):
        raise _err("Ungültige Aktion")
    target = _volume_target()
    if target == "pi":
        if action == "mute":
            T["as_tv"](["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "toggle"], 10)
        else:
            T["as_tv"](["wpctl", "set-volume", "-l", "1.0", "@DEFAULT_AUDIO_SINK@",
                        "1%+" if action == "up" else "1%-"], 10)
        _, out, _ = T["as_tv"](["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"], 10)
        m = re.search(r"([\d.]+)", out)
        r = {"target": "pi", "volume": round(float(m.group(1)) * 100) if m else None, "muted": "MUTED" in out}
        _osd.update(volume=r["volume"], muted=r["muted"], at=time.time())
        return r
    cmd = {"up": "volume-up", "down": "volume-down", "mute": "mute"}[action]
    _cec_key(cmd, 5 if target == "soundbar" else 0)
    return {"target": target}


def cec_action(data):
    a = data.get("action")
    if a == "tv_on":
        _cec(["--to", "0", "--image-view-on"], check=True)
    elif a == "tv_off":
        _cec(["--to", "0", "--standby"], check=True)
        _set_tv_power("standby")
    elif a == "switch":
        pa = _phys_addr()
        if not pa or pa == "f.f.f.f":
            raise _err("Kein Fernseher gefunden.")
        _cec(["--to", "0", "--image-view-on"], check=True)
        _cec(["--to", "15", "--active-source", f"phys-addr={pa}"])
    elif a == "soundbar_off":
        _cec(["--to", "5", "--standby"])
    else:
        raise _err("Ungültige Aktion")
    return {"ok": True}


def cec_settings(data):
    cfg = _cfg()
    for k in ("cec_wake_tv", "cec_autoswitch"):
        if k in data:
            cfg[k] = bool(data[k])
    if "volume_target" in data:
        if data["volume_target"] not in ("auto", "tv", "soundbar", "pi"):
            raise _err("Ungültige Einstellung")
        cfg["volume_target"] = data["volume_target"]
    _save(cfg)
    return cec_status_full()


def cec_status_full():
    cfg = _cfg()
    dev = _cec_dev()
    d = _cec_devices() if dev else {"soundbar": None, "tvname": None}
    return {"adapter": bool(dev), "tv": T["tv_power"](), "tvname": d["tvname"], "soundbar": d["soundbar"],
            "wake_tv": cfg.get("cec_wake_tv", True), "autoswitch": cfg.get("cec_autoswitch", False),
            "volume_target": cfg.get("volume_target", "auto"), "volume_effective": _volume_target() if dev else "pi"}


GET_ROUTES["/api/cec"] = cec_status_full
POST_ROUTES["/api/cec"] = cec_settings
POST_ROUTES["/api/cec/action"] = cec_action
POST_ROUTES["/api/volume"] = volume
REMOTE_ROUTES_EXTRA = {
    "/r/volume": volume,
    "/r/cec": lambda d: cec_action(d) if d.get("action") in ("tv_on", "tv_off", "switch") else {"ok": False},
}


# ==========================================================================
# Fernsteuerung der Oberfläche: Seite öffnen (Suche vom Handy, DLNA, …)
#   Die Browser-Erweiterung fragt alle 1,5 s nach und öffnet die Adresse im Vollbild.
# ==========================================================================
_nav = {"url": None, "at": 0}
_osd = {"volume": None, "muted": False, "at": 0}
LAUNCHER = "http://127.0.0.1:8765/"


def request_nav(url):
    _nav.update(url=url, at=time.time())


def nav_pending(_query, headers):
    if headers.get("X-Raspi-TV") != "1":
        raise _err("forbidden", 403)
    url, at = _nav["url"], _nav["at"]
    _nav.update(url=None)
    osd = None
    if _osd["at"] and time.time() - _osd["at"] < 3:
        osd = {"volume": _osd["volume"], "muted": _osd["muted"]}
        _osd["at"] = 0
    return {"url": url if url and time.time() - at < 20 else None, "osd": osd}


SEARCH_TARGETS = {
    "guide": lambda q: LAUNCHER + "#/search/" + quote(q, safe=""),
    "youtube": lambda q: "https://www.youtube.com/results?search_query=" + quote(q),
    "netflix": lambda q: "https://www.netflix.com/search?q=" + quote(q),
    "ard": lambda q: "https://www.ardmediathek.de/suche/" + quote(q, safe=""),
    "zdf": lambda q: "https://www.zdf.de/suche?q=" + quote(q),
    "store": lambda q: LAUNCHER + "#/store/search/" + quote(q, safe=""),
}


def remote_search(data):
    q = str(data.get("q", "")).strip()[:100]
    where = data.get("where", "guide")
    if not q or where not in SEARCH_TARGETS:
        raise _err("Bitte einen Suchbegriff eingeben.")
    touch_activity()
    request_nav(SEARCH_TARGETS[where](q))
    return {"ok": True}


QUERY_ROUTES["/api/nav/pending"] = nav_pending
REMOTE_ROUTES_EXTRA["/r/search"] = remote_search


# ==========================================================================
# Einstellungen sichern & wiederherstellen (USB-Stick)
# ==========================================================================
NM_CONN_DIR = "/etc/NetworkManager/system-connections"
BACKUP_SKIP = re.compile(r"^(epg.*|.*\.tmp|.*\.log|cache.*|backups?)$")
BACKUP_NAME_RE = re.compile(r"(?i)^raspi-tv-sicherung[^/\\]*\.zip$")


def _usb_roots():
    return [(s["id"], s["name"], os.path.join(MEDIA_ROOT, s["id"]))
            for s in media_sources()["sources"] if s["kind"] == "usb"]


def _build_backup_zip(path):
    files = 0
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json", json.dumps({
            "raspi_tv_backup": 1, "version": _installed_version(), "created": time.time(),
            "device_name": _device_name()}, indent=2))
        for name in sorted(os.listdir(T["STATE_DIR"])):
            full = os.path.join(T["STATE_DIR"], name)
            if os.path.isfile(full) and not BACKUP_SKIP.match(name) and os.path.getsize(full) < 5_000_000:
                z.write(full, "state/" + name)
                files += 1
        if os.path.isdir(NM_CONN_DIR):
            for name in sorted(os.listdir(NM_CONN_DIR)):
                full = os.path.join(NM_CONN_DIR, name)
                try:
                    txt = open(full).read()
                except OSError:
                    continue
                if "type=wifi" in txt and "mode=ap" not in txt:   # gespeicherte WLANs, nicht das Fernbedienungs-WLAN
                    z.writestr("wifi/" + name, txt)
                    files += 1
    return files


def backup_create(data):
    roots = _usb_roots()
    if not roots:
        raise _err("Kein USB-Stick gefunden – bitte einen Stick einstecken.")
    src = str(data.get("src") or roots[0][0])
    root = next((r for r in roots if r[0] == src), None)
    if not root:
        raise _err("USB-Stick nicht gefunden.")
    mnt = root[2]
    fname = time.strftime("raspi-tv-sicherung-%Y-%m-%d-%H%M.zip")
    tmp = os.path.join("/var/cache/raspi-tv" if os.path.isdir("/var/cache/raspi-tv") else T["STATE_DIR"], fname)
    files = _build_backup_zip(tmp)
    code, _, err = T["run"](["mount", "-o", "remount,rw", mnt], 20)
    if code != 0:
        os.remove(tmp)
        raise _err("Auf diesen Stick kann nicht geschrieben werden (schreibgeschützt oder NTFS). "
                   "Bitte einen FAT32/exFAT-Stick nehmen.")
    try:
        shutil.copyfile(tmp, os.path.join(mnt, fname))
        T["run"](["sync"], 30)
    except OSError as e:
        raise _err(f"Speichern fehlgeschlagen: {e.strerror}")
    finally:
        T["run"](["mount", "-o", "remount,ro", mnt], 20)
        try:
            os.remove(tmp)
        except OSError:
            pass
    return {"ok": True, "file": fname, "stick": root[1], "files": files}


def backup_list():
    found = []
    for src, name, mnt in _usb_roots():
        try:
            entries = sorted(os.listdir(mnt), reverse=True)
        except OSError:
            continue
        for n in entries:
            if not BACKUP_NAME_RE.match(n):
                continue
            info = {"src": src, "file": n, "stick": name}
            try:
                with zipfile.ZipFile(os.path.join(mnt, n)) as z:
                    m = json.loads(z.read("manifest.json"))
                info.update(created=m.get("created"), version=m.get("version"), device=m.get("device_name"))
            except (KeyError, ValueError, zipfile.BadZipFile, OSError):
                continue
            found.append(info)
    return {"backups": found, "sticks": [{"src": s, "name": n} for s, n, _ in _usb_roots()]}


def backup_restore(data):
    fname = str(data.get("file", ""))
    if not BACKUP_NAME_RE.match(fname):
        raise _err("Ungültige Datei")
    path = os.path.join(_source_root(str(data.get("src", ""))), fname)
    if not os.path.isfile(path):
        raise _err("Sicherung nicht gefunden – Stick noch eingesteckt?", 404)
    safe = re.compile(r"^(state/[A-Za-z0-9._-]+|wifi/[^/\\]+\.nmconnection|manifest\.json)$")
    # vorher den aktuellen Stand lokal sichern
    try:
        _build_backup_zip(os.path.join(T["STATE_DIR"], "..", "raspi-tv-vor-wiederherstellung.zip"))
    except OSError:
        pass
    restored = 0
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        if "manifest.json" not in names or any(not safe.match(n) for n in names if not n.endswith("/")):
            raise _err("Das ist keine gültige Raspi-TV-Sicherung.")
        for n in names:
            if n.startswith("state/"):
                _write_bytes(os.path.join(T["STATE_DIR"], n[6:]), z.read(n), 0o600 if "token" in n or "hotspot" in n else 0o644)
                restored += 1
            elif n.startswith("wifi/") and os.path.isdir(NM_CONN_DIR):
                _write_bytes(os.path.join(NM_CONN_DIR, os.path.basename(n)), z.read(n), 0o600)
                restored += 1
    T["run"](["nmcli", "connection", "reload"], 20)
    # Oberfläche und Dienst mit den wiederhergestellten Einstellungen neu starten
    subprocess.Popen(["bash", "-c", "sleep 2; pkill -u tv -f raspi-tv-browser; systemctl restart raspi-tv-ctl"],
                     start_new_session=True)
    return {"ok": True, "restored": restored}


def _write_bytes(path, data, mode):
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data)
    os.chmod(tmp, mode)
    os.replace(tmp, path)


GET_ROUTES["/api/backup"] = backup_list
POST_ROUTES["/api/backup/create"] = backup_create
POST_ROUTES["/api/backup/restore"] = backup_restore


# ==========================================================================
# Rückkehr zur vorherigen Version + Updates übers Internet
# ==========================================================================
ROLLBACK_DIR = "/var/lib/raspi-tv-rollback"
ROLLBACK_PATHS = ["opt/raspi-tv", "etc/systemd/system/raspi-tv-ctl.service", "etc/systemd/system/raspi-tv-cec.service",
                  "etc/systemd/system/raspi-tv-wlan.service", "etc/systemd/system/raspi-tv-btagent.service",
                  "etc/chromium/policies/managed/raspi-tv.json", "etc/chromium-browser/policies/managed/raspi-tv.json",
                  "etc/X11/xorg.conf.d/99-raspi-tv.conf", "etc/X11/raspi-tv", "etc/raspi-tv-release",
                  "home/tv/.xinitrc", "home/tv/.xbindkeysrc", "home/tv/.bash_profile"]


def _ver_tuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", str(v))[:4]) or (0,)


def _rollback_snapshot():
    """Packt die laufende Version ein (die letzten zwei werden aufbewahrt)."""
    try:
        os.makedirs(ROLLBACK_DIR, exist_ok=True)
        ver = re.sub(r"[^0-9A-Za-z.]", "", _installed_version()) or "x"
        path = os.path.join(ROLLBACK_DIR, f"raspi-tv-{ver}-{time.strftime('%Y%m%d-%H%M%S')}.tar.gz")
        present = [p for p in ROLLBACK_PATHS if os.path.exists("/" + p)]
        if not present:
            return None
        code, _, _ = T["run"](["tar", "-czf", path, "-C", "/"] + present, 120)
        if code != 0:
            return None
        old = sorted(glob.glob(os.path.join(ROLLBACK_DIR, "raspi-tv-*.tar.gz")))
        for f in old[:-2]:
            os.remove(f)
        return path
    except OSError:
        return None


def rollback_list():
    out = []
    for f in sorted(glob.glob(os.path.join(ROLLBACK_DIR, "raspi-tv-*.tar.gz")), reverse=True):
        m = re.match(r"raspi-tv-(.+?)-(\d{8})-(\d{6})\.tar\.gz$", os.path.basename(f))
        if m:
            out.append({"file": os.path.basename(f), "version": m.group(1),
                        "date": f"{m.group(2)[6:8]}.{m.group(2)[4:6]}.{m.group(2)[:4]} {m.group(3)[:2]}:{m.group(3)[2:4]}"})
    rolled = os.path.exists(os.path.join(ROLLBACK_DIR, "rolled-back"))
    return {"snapshots": out, "auto_rolled_back": rolled}


def rollback_restore(data):
    name = os.path.basename(str(data.get("file", "")))
    path = os.path.join(ROLLBACK_DIR, name)
    if not re.match(r"^raspi-tv-[0-9A-Za-z.]+-\d{8}-\d{6}\.tar\.gz$", name) or not os.path.isfile(path):
        raise _err("Sicherung nicht gefunden")
    code, _, err = T["run"](["tar", "-xzf", path, "-C", "/"], 120)
    if code != 0:
        raise _err("Zurücksetzen fehlgeschlagen: " + err.strip()[:80])
    T["run"](["systemctl", "daemon-reload"], 30)
    subprocess.Popen(["bash", "-c", "sleep 3; systemctl reboot"], start_new_session=True)
    return {"ok": True}


def rollback_ack(_data=None):
    try:
        os.remove(os.path.join(ROLLBACK_DIR, "rolled-back"))
    except OSError:
        pass
    return {"ok": True}


# --- Updates übers Internet --------------------------------------------------
_online = {"checked": 0, "latest": None, "error": None, "busy": False}
ONLINE_ZIP = "/var/cache/raspi-tv/online-update.zip"
# 6.1.1: Standard-Adresse für Online-Updates; neue Versionen werden nachts automatisch installiert,
# solange in den Einstellungen nichts anderes eingetragen ist.
DEFAULT_UPDATE_URL = "https://raw.githubusercontent.com/NBFinn/raspi-tv-updates/main/raspi-tv-update.zip"


def _update_url(cfg):
    return cfg["update_url"] if "update_url" in cfg else DEFAULT_UPDATE_URL


def _update_auto(cfg):
    return cfg.get("update_auto", True) is not False


def _online_fetch():
    url = _update_url(_cfg())
    if not url:
        raise RuntimeError("Keine Update-Adresse eingetragen.")
    data = _download(url, limit=80_000_000, timeout=180)
    os.makedirs(os.path.dirname(ONLINE_ZIP), exist_ok=True)
    with open(ONLINE_ZIP + ".tmp", "wb") as f:
        f.write(data)
    os.replace(ONLINE_ZIP + ".tmp", ONLINE_ZIP)
    with zipfile.ZipFile(ONLINE_ZIP) as zf:
        names = _zip_names(zf)
        root = _zip_root([n for _, n in names])
        if root is None:
            raise RuntimeError("Unter der Adresse liegt kein Raspi-TV-Update-Paket.")
        ver = next((zf.read(i).decode("utf-8", "replace").strip()[:20] for i, n in names if n == root + "VERSION"), None)
    if not ver:
        raise RuntimeError("Update-Paket ohne Versionsnummer.")
    return ver


def online_check(_data=None):
    if _online["busy"]:
        return online_status()
    _online["busy"] = True
    try:
        _online.update(latest=_online_fetch(), error=None)
    except zipfile.BadZipFile:
        _online.update(latest=None, error="Unter der Adresse liegt keine Zip-Datei.")
    except Exception as e:  # noqa: BLE001
        _online.update(latest=None, error=str(e) if isinstance(e, RuntimeError) else "Update-Adresse nicht erreichbar.")
    finally:
        _online.update(busy=False, checked=time.time())
    return online_status()


def online_status():
    cfg = _cfg()
    inst = _installed_version()
    latest = _online["latest"]
    return {"url": _update_url(cfg), "auto": _update_auto(cfg), "installed": inst,
            "latest": latest, "newer": bool(latest and _ver_tuple(latest) > _ver_tuple(inst)),
            "checked": _online["checked"], "error": _online["error"], "busy": _online["busy"],
            "job": swupdate_status()}


def online_settings(data):
    cfg = _cfg()
    if "url" in data:
        url = str(data["url"]).strip()
        if url and not re.match(r"^https://[^\s\"'<>]+$", url):
            raise _err("Bitte eine https-Adresse eingeben (z. B. von GitHub-Releases).")
        cfg["update_url"] = url[:400]
        _online.update(latest=None, error=None, checked=0)
    if "auto" in data:
        cfg["update_auto"] = bool(data["auto"])
    _save(cfg)
    return online_status()


def online_install(_data=None):
    if _swu["running"]:
        return online_status()
    st = online_check()
    if not st["latest"]:
        raise _err(st["error"] or "Kein Update gefunden.")
    if not st["newer"]:
        raise _err(f"Raspi-TV ist aktuell (Version {st['installed']}).")
    _swu.update(running=True, done=False, error=None, step="Wird vorbereitet", version=st["latest"])
    threading.Thread(target=_swupdate_worker, args=(ONLINE_ZIP,), daemon=True).start()
    return online_status()


def online_loop():
    """Prüft einmal am Tag; installiert auf Wunsch nachts zwischen 3 und 5 Uhr."""
    time.sleep(120)
    while True:
        try:
            cfg = _cfg()
            if _update_url(cfg) and time.time() - _online["checked"] > 6 * 3600:
                online_check()
            h = datetime.now().hour
            if (_update_auto(cfg) and 3 <= h < 5 and _online["latest"] and not _swu["running"]
                    and _ver_tuple(_online["latest"]) > _ver_tuple(_installed_version())
                    and T["tv_power"]() != "on"):
                online_install()
        except Exception:  # noqa: BLE001
            pass
        time.sleep(600)


GET_ROUTES["/api/rollback"] = rollback_list
POST_ROUTES["/api/rollback"] = rollback_restore
POST_ROUTES["/api/rollback/ack"] = rollback_ack
GET_ROUTES["/api/online-update"] = online_status
POST_ROUTES["/api/online-update"] = online_settings
POST_ROUTES["/api/online-update/check"] = online_check
POST_ROUTES["/api/online-update/install"] = online_install
_old_start5 = start_background


def start_background():  # noqa: F811
    _old_start5()
    threading.Thread(target=online_loop, daemon=True).start()


# ==========================================================================
# DLNA: Videos, Musik und Fotos vom Handy (siehe dlna.py)
# ==========================================================================
def _pi_volume_get():
    _, out, _ = T["as_tv"](["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"], 10)
    m = re.search(r"([\d.]+)", out)
    return round(float(m.group(1)) * 100) if m else 50


def _pi_volume_set(v):
    T["as_tv"](["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", f"{v / 100:.2f}"], 10)


def _pi_mute_get():
    _, out, _ = T["as_tv"](["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"], 10)
    return "MUTED" in out


def _pi_mute_set(on):
    T["as_tv"](["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "1" if on else "0"], 10)


def dlna_status():
    return {"enabled": _cfg().get("dlna", True), "name": _device_name()}


def dlna_set(data):
    cfg = _cfg()
    cfg["dlna"] = bool(data.get("enabled"))
    _save(cfg)
    return dlna_status()


def cast_report(data):
    import dlna
    touch_activity()
    return dlna.player_report(data)


def _dlna_start():
    try:
        import dlna
        dlna.start({"name": _device_name, "enabled": lambda: _cfg().get("dlna", True), "state_dir": T["STATE_DIR"],
                    "request_nav": request_nav, "volume_get": _pi_volume_get, "volume_set": _pi_volume_set,
                    "mute_get": _pi_mute_get, "mute_set": _pi_mute_set, "log": lambda m: print(m, flush=True)})
    except Exception as e:  # noqa: BLE001
        print("DLNA nicht gestartet:", e, flush=True)


GET_ROUTES["/api/dlna"] = dlna_status
POST_ROUTES["/api/dlna"] = dlna_set
POST_ROUTES["/api/cast/report"] = cast_report
_old_start6 = start_background


def start_background():  # noqa: F811
    _old_start6()
    _dlna_start()


# Handy-Fernbedienung: Sprache mitschicken
def _remote_ping(_data):
    return {"ok": True, "name": _device_name(), "tv": T["tv_power"](), "lang": _cfg().get("lang", "de")}


REMOTE_ROUTES_EXTRA["/r/ping"] = _remote_ping


# ==========================================================================
# Live-TV anhalten (Timeshift, siehe timeshift.py)
# ==========================================================================
def _ts():
    import timeshift
    return timeshift


def timeshift_start(data):
    ts = _ts()
    try:
        return ts.start(str(data.get("url") or ""), float(data.get("behind") or 0),
                        log=lambda *a: print(*a, flush=True))
    except (ts.TimeshiftError, ValueError) as e:
        raise _err(str(e))


def timeshift_stop(_data=None):
    return _ts().stop()


def timeshift_status():
    return _ts().status()


def serve_prefix(handler, path):
    """GET-Pfade mit Präfix (z. B. /timeshift/v-123.ts). Gibt False zurück, wenn nicht zuständig."""
    if path.startswith("/timeshift/"):
        _ts().serve(handler, path, _send_file)
        return True
    return False


GET_ROUTES["/api/timeshift"] = timeshift_status
POST_ROUTES["/api/timeshift/start"] = timeshift_start
POST_ROUTES["/api/timeshift/stop"] = timeshift_stop
_old_start7 = start_background


def start_background():  # noqa: F811
    _old_start7()
    try:
        _ts()._clear()   # Reste vom letzten Mal
    except Exception:  # noqa: BLE001
        pass


# ==========================================================================
# Hinweise in jeder App (z. B. Anrufe) – werden über die Erweiterung abgeholt
# ==========================================================================
_notices = []          # [{id, at, notice}]
_notice_lock = threading.Lock()


def push_notice(notice, ttl=30):
    with _notice_lock:
        nid = int(time.time() * 1000)
        _notices.append({"id": nid, "at": time.time(), "ttl": ttl, "notice": dict(notice, id=nid)})
        del _notices[:-5]
    return nid


_nav_pending_base = nav_pending


def nav_pending(query, headers):  # noqa: F811
    out = _nav_pending_base(query, headers)
    with _notice_lock:
        now = time.time()
        _notices[:] = [n for n in _notices if now - n["at"] < n["ttl"]]
        if _notices:
            out["notice"] = _notices.pop(0)["notice"]
    return out


QUERY_ROUTES["/api/nav/pending"] = nav_pending


# ==========================================================================
# Anrufe anzeigen (FRITZ!Box-Anrufmonitor, Port 1012)
#   Einmalig am Telefon #96*5* wählen, dann meldet die FRITZ!Box jeden Anruf.
# ==========================================================================
CALLMON_PORT = 1012
_callmon = {"state": "off", "last": None, "error": ""}


def _callmon_cfg():
    c = _cfg().get("callmon") or {}
    return {"enabled": c.get("enabled", True), "pause": bool(c.get("pause", False)),
            "host": str(c.get("host") or "fritz.box")[:64]}


def _fmt_number(n):
    n = (n or "").strip()
    if not n:
        return ""
    if n.startswith("0049"):
        n = "0" + n[4:]
    elif n.startswith("+49"):
        n = "0" + n[3:]
    if re.match(r"^01[5-7]\d{7,9}$", n):        # Handynummer: 0170 1234567
        n = n[:4] + " " + n[4:]
    return n


def _call_notice(caller, callee, pause, test=False):
    lang = _cfg().get("lang", "de")
    num = _fmt_number(caller)
    title = num or ("Unknown number" if lang == "en" else "Unbekannte Nummer")
    sub_parts = []
    if callee:
        sub_parts.append(("on " if lang == "en" else "auf ") + _fmt_number(callee))
    if pause:
        sub_parts.append("video paused" if lang == "en" else "Video angehalten")
    if test:
        sub_parts.append("test" if lang == "en" else "Test")
    return {"kicker": "Incoming call" if lang == "en" else "Anruf", "title": title, "sub": " · ".join(sub_parts),
            "icon": "phone", "pause": bool(pause), "timeout": 30000, "tag": "call"}


def _callmon_handle(line):
    # 28.10.26 20:15:03;RING;0;01701234567;030123456;SIP0;
    parts = line.strip().split(";")
    if len(parts) < 3:
        return
    kind = parts[1]
    if kind == "RING":
        caller = parts[3] if len(parts) > 3 else ""
        callee = parts[4] if len(parts) > 4 else ""
        c = _callmon_cfg()
        _callmon["last"] = {"at": time.time(), "caller": _fmt_number(caller)}
        if T["tv_power"]() == "standby":
            return     # Fernseher ist aus – niemand schaut
        push_notice(_call_notice(caller, callee, c["pause"]), ttl=25)
    elif kind in ("CONNECT", "DISCONNECT"):
        push_notice({"close": "call"}, ttl=10)


def callmon_loop():
    import socket
    while True:
        c = _callmon_cfg()
        if not c["enabled"]:
            _callmon.update(state="off", error="")
            time.sleep(10)
            continue
        try:
            with socket.create_connection((c["host"], CALLMON_PORT), timeout=10) as s:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
                s.settimeout(60)
                _callmon.update(state="connected", error="")
                buf = b""
                # nur bei geänderter Adresse / Ausschalten neu verbinden
                while {k: v for k, v in _callmon_cfg().items() if k != "pause"} == {k: v for k, v in c.items() if k != "pause"}:
                    try:
                        chunk = s.recv(4096)
                    except socket.timeout:
                        continue
                    if not chunk:
                        break
                    buf += chunk
                    while b"\n" in buf:
                        line, buf = buf.split(b"\n", 1)
                        try:
                            _callmon_handle(line.decode("utf-8", "replace"))
                        except Exception:  # noqa: BLE001
                            pass
        except OSError as e:
            refused = isinstance(e, ConnectionRefusedError)
            _callmon.update(state="refused" if refused else "offline", error=str(e)[:120])
            time.sleep(60 if refused else 120)
            continue
        time.sleep(5)


def callmon_status():
    c = _callmon_cfg()
    return dict(c, state=_callmon["state"], last=_callmon["last"])


def callmon_set(data):
    cfg = _cfg()
    c = dict(cfg.get("callmon") or {})
    if "enabled" in data:
        c["enabled"] = bool(data["enabled"])
    if "pause" in data:
        c["pause"] = bool(data["pause"])
    if "host" in data:
        host = str(data["host"]).strip()
        if not re.match(r"^[A-Za-z0-9.-]{1,64}$", host):
            raise _err("Ungültige Adresse")
        c["host"] = host
    cfg["callmon"] = c
    _save(cfg)
    return callmon_status()


def callmon_test(_data=None):
    c = _callmon_cfg()
    push_notice(_call_notice("0170 1234567", "", c["pause"], test=True), ttl=25)
    return {"ok": True}


GET_ROUTES["/api/callmon"] = callmon_status
POST_ROUTES["/api/callmon"] = callmon_set
POST_ROUTES["/api/callmon/test"] = callmon_test


# ==========================================================================
# Einschalt-Timer (Wecker) und nächtlicher Neustart
# ==========================================================================
WAKE_DEFAULT = {"enabled": False, "time": "07:00", "days": [1, 2, 3, 4, 5], "channel": "", "nightly": False,
                "mode": "tv", "radio": "", "scene": "polarlicht", "gentle": True}


def wake_cfg():
    w = dict(WAKE_DEFAULT)
    w.update({k: v for k, v in (_cfg().get("wake") or {}).items() if k in WAKE_DEFAULT})
    return w


def wake_status():
    w = wake_cfg()
    w["next"] = _wake_next(w)
    w["channels"] = [c["name"] for c in all_channels()][:200]
    return w


def _wake_next(w, now=None):
    if not w["enabled"] or not w["days"]:
        return None
    now = now or datetime.now()
    hh, mm = (int(x) for x in w["time"].split(":"))
    for add in range(0, 8):
        d = datetime.fromtimestamp(now.timestamp() + add * 86400).replace(hour=hh, minute=mm, second=0, microsecond=0)
        if d.isoweekday() in w["days"] and d > now:
            return d.timestamp()
    return None


def wake_set(data):
    cfg = _cfg()
    w = wake_cfg()
    if "enabled" in data:
        w["enabled"] = bool(data["enabled"])
    if "nightly" in data:
        w["nightly"] = bool(data["nightly"])
    if "time" in data:
        if not re.match(r"^([01]\d|2[0-3]):[0-5]\d$", str(data["time"])):
            raise _err("Ungültige Uhrzeit")
        w["time"] = data["time"]
    if "days" in data:
        days = data["days"]
        if not isinstance(days, list) or not all(isinstance(d, int) and 1 <= d <= 7 for d in days):
            raise _err("Ungültige Tage")
        w["days"] = sorted(set(days))
    if "channel" in data:
        ch = str(data["channel"] or "")[:80]
        if ch and ch not in {c["name"] for c in all_channels()}:
            raise _err("Unbekannter Sender")
        w["channel"] = ch
    # 6.0: Wecker mit Radio oder Ambient-Szene, sanft lauter werdend
    if "mode" in data:
        if data["mode"] not in ("tv", "radio", "ambient"):
            raise _err("Ungültige Art")
        w["mode"] = data["mode"]
    if "radio" in data:
        w["radio"] = str(data["radio"] or "")[:80]
    if "scene" in data:
        if not re.fullmatch(r"[a-z0-9-]{1,40}", str(data["scene"])):
            raise _err("Ungültige Szene")
        w["scene"] = data["scene"]
    if "gentle" in data:
        w["gentle"] = bool(data["gentle"])
    cfg["wake"] = w
    _save(cfg)
    return wake_status()


def _wake_fire(w):
    touch_activity()
    try:
        _cec(["--to", "0", "--image-view-on"])
        pa = _phys_addr()
        if pa and pa != "f.f.f.f":
            _cec(["--to", "15", "--active-source", f"phys-addr={pa}"])
    except Exception:  # noqa: BLE001
        pass
    _set_tv_power("on")
    if w.get("mode") in ("radio", "ambient"):
        q = "mode=" + w["mode"] + "&scene=" + quote(w.get("scene") or "") + "&gentle=" + ("1" if w.get("gentle") else "0")
        if w["mode"] == "radio" and w.get("radio"):
            q += "&radio=" + quote(w["radio"])
        request_nav(LAUNCHER + "#/wakeup?" + q)
    elif w["channel"]:
        request_nav(LAUNCHER + "tv.html?name=" + quote(w["channel"]))
    else:
        request_nav(LAUNCHER)


def wake_loop():
    fired = None
    while True:
        time.sleep(20)
        try:
            w = wake_cfg()
            now = datetime.now()
            key = now.strftime("%Y-%m-%d %H:%M")
            if (w["enabled"] and now.isoweekday() in w["days"] and now.strftime("%H:%M") == w["time"]
                    and fired != key):
                fired = key
                _wake_fire(w)
            # Nachts um 4 Uhr neu starten (nur wenn niemand schaut und der Pi schon lange läuft)
            if (w["nightly"] and now.hour == 4 and now.minute < 30 and T["tv_power"]() != "on"
                    and time.time() - last_input() > 1800 and _uptime() > 20 * 3600):
                T["power"]("reboot")
                time.sleep(120)
        except Exception:  # noqa: BLE001
            pass


def _uptime():
    try:
        with open("/proc/uptime") as f:
            return float(f.read().split()[0])
    except (OSError, ValueError):
        return 0


GET_ROUTES["/api/wake"] = wake_status
POST_ROUTES["/api/wake"] = wake_set
_old_start8 = start_background


def start_background():  # noqa: F811
    _old_start8()
    threading.Thread(target=callmon_loop, daemon=True).start()
    threading.Thread(target=wake_loop, daemon=True).start()


# ==========================================================================
# Raspi-TV-App für ältere Android-Handys: Fernbedienung über Bluetooth
#   Die App verbindet sich per Bluetooth (RFCOMM, Kanal 22) und schickt pro Zeile
#   eine Anfrage als JSON: {"id": 1, "path": "/r/key", "data": {"key": "up"}}
#   Antwort: {"id": 1, "ok": true, "data": {...}} bzw. {"id": 1, "error": "…"}
#   Nur Handys, die während des Kopplungsfensters (3 Minuten, am Fernseher gestartet)
#   verbunden wurden, dürfen danach steuern.
# ==========================================================================
BT_REMOTE_CHANNEL = 22
_btr = {"window_until": 0, "clients": {}, "error": "", "listening": False}
_btr_connections = {}
_btr_lock = threading.Lock()


def _btr_allowed():
    return _read_json(_state("bt-remotes.json"), {})


def _btr_allow(mac, name=""):
    allowed = _btr_allowed()
    allowed[mac] = {"name": name or allowed.get(mac, {}).get("name") or mac, "added": time.time()}
    _write_json(_state("bt-remotes.json"), allowed)


def _bt_name(mac):
    try:
        _, out, _ = T["run"](["bluetoothctl", "info", mac], 2)
        m = re.search(r"^\s*(?:Alias|Name):\s*(.+)$", out, re.M)
        return m.group(1).strip() if m else ""
    except Exception:  # noqa: BLE001
        return ""


def btremote_window(_data=None):
    """Raspi-TV 3 Minuten lang sichtbar machen, damit das Handy ihn findet und koppeln darf."""
    T["bt_ready"]()
    T["run"](["bluetoothctl", "pairable", "on"], 10)
    T["run"](["bluetoothctl", "discoverable-timeout", "180"], 10)
    T["run"](["bluetoothctl", "discoverable", "on"], 10)
    _btr["window_until"] = time.time() + 180
    return btremote_status()


def btremote_status():
    left = max(0, int(_btr["window_until"] - time.time()))
    allowed = _btr_allowed()
    return {"listening": _btr["listening"], "error": _btr["error"], "window": left,
            "connected": [dict(mac=m, name=c) for m, c in _btr["clients"].items()],
            "phones": [dict(mac=m, name=v.get("name") or m) for m, v in allowed.items()],
            "name": _device_name(),
            "drops": [d for d in _btr.get("log", []) if d["at"] > time.time() - 86400 and d["reason"] != "vom Handy beendet"][-5:]}


def btremote_forget(data):
    mac = str(data.get("mac") or "")
    allowed = _btr_allowed()
    if mac in allowed:
        del allowed[mac]
        _write_json(_state("bt-remotes.json"), allowed)
        try:
            T["run"](["bluetoothctl", "remove", mac], 15)
        except Exception:  # noqa: BLE001
            pass
    return btremote_status()


def _btr_handle(conn, mac):
    import socket as so
    allowed = _btr_allowed()
    # Reconnecting must not wait for bluetoothctl before answering the phone.
    name = allowed.get(mac, {}).get("name") or mac
    conn.settimeout(120)
    if mac not in allowed:
        if time.time() < _btr["window_until"]:
            name = _bt_name(mac) or mac
            _btr_allow(mac, name)
        else:
            try:
                conn.settimeout(2)
                conn.sendall(json.dumps({"id": 0, "error": "pair", "message":
                         "Am Fernseher unter Einstellungen → Fernbedienung → Handy „Handy-App koppeln“ wählen."}).encode() + b"\n")
            finally:
                conn.close()
            return
    routes = T["REMOTE_ROUTES"]
    started = time.time()
    send_lock = threading.Lock()
    jobs = queue.Queue(maxsize=64)
    closed = threading.Event()
    state = {"hb": False, "reason": "getrennt"}

    def close_session(reason=None):
        if reason and not closed.is_set():
            state["reason"] = reason
        closed.set()
        try:
            conn.shutdown(so.SHUT_RDWR)
        except OSError:
            pass
        conn.close()

    with _btr_lock:
        old = _btr_connections.get(mac)
        _btr_connections[mac] = close_session
        _btr["clients"][mac] = name
    if old:
        old("durch neue Handy-Verbindung ersetzt")
    print("Bluetooth-Fernbedienung verbunden:", name, flush=True)

    def send(obj):
        data = json.dumps(obj, ensure_ascii=False).encode() + b"\n"
        with send_lock:
            if closed.is_set():
                raise OSError("Verbindung beendet")
            conn.sendall(data)

    def worker():
        # Befehle der Reihe nach ausführen (Tasten dürfen sich nicht überholen); langsame Befehle
        # (z. B. CEC) halten dabei die Herzschlag-Antworten nicht mehr auf.
        while not closed.is_set():
            try:
                req = jobs.get(timeout=0.5)
            except queue.Empty:
                continue
            if closed.is_set():
                return
            rid = req.get("id", 0) if isinstance(req, dict) else 0
            try:
                fn = routes.get(req.get("path")) if isinstance(req, dict) else None
                data = (req.get("data") or {}) if isinstance(req, dict) else None
                if not fn or not isinstance(data, dict):
                    raise _err("Unbekannte Anfrage", 404)
                touch_activity()
                out = {"id": rid, "ok": True, "data": fn(data)}
            except T["ApiError"] as e:
                out = {"id": rid, "error": str(e), "status": e.code}
            except Exception as e:  # noqa: BLE001
                out = {"id": rid, "error": f"Fehler: {e}", "status": 500}
            try:
                send(out)
            except OSError as e:
                close_session(f"Bluetooth-Senden fehlgeschlagen: {e}")
                return

    threading.Thread(target=worker, daemon=True).start()
    buf = b""
    # Ältere Apps melden sich nur alle 10 s (und nur im Vordergrund).
    try:
        while not closed.is_set():
            try:
                chunk = conn.recv(8192)
            except so.timeout:
                state["reason"] = "keine Antwort vom Handy (Zeitüberschreitung)"
                break
            if not chunk:
                if not closed.is_set():
                    state["reason"] = "vom Handy beendet"
                break
            buf += chunk
            if len(buf) > 262144:
                state["reason"] = "zu lange Anfrage"
                break
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                line = line.strip()
                if not line:
                    continue
                try:
                    req = json.loads(line)
                except ValueError:
                    send({"id": 0, "error": "Ungültige Anfrage", "status": 400})
                    continue
                if isinstance(req, dict) and req.get("path") == "/r/hb":
                    # Herzschlag der App (ab 1.11, alle 4 s): sofort beantworten
                    if not state["hb"]:
                        state["hb"] = True
                        conn.settimeout(30)
                    send({"id": req.get("id", -1), "ok": True, "data": {"t": int(time.time())}})
                    continue
                try:
                    jobs.put_nowait(req)
                except queue.Full:
                    send({"id": req.get("id", 0) if isinstance(req, dict) else 0, "error": "Raspi-TV ist beschäftigt", "status": 503})
    except OSError as e:
        if not closed.is_set():
            state["reason"] = f"Bluetooth-Fehler: {e.strerror or e}"
    finally:
        close_session()
        with _btr_lock:
            if _btr_connections.get(mac) is close_session:
                _btr_connections.pop(mac, None)
                _btr["clients"].pop(mac, None)
        _btr.setdefault("log", []).append({"at": int(time.time()), "name": name, "reason": state["reason"],
                                           "secs": int(time.time() - started)})
        del _btr["log"][:-20]
        print(f"Bluetooth-Fernbedienung getrennt: {name} ({state['reason']}, nach {int(time.time() - started)} s)", flush=True)


def btremote_loop():
    import socket as so
    import struct
    if not hasattr(so, "BTPROTO_RFCOMM"):
        _btr["error"] = "Python ohne Bluetooth-Unterstützung"
        return
    while True:
        srv = None
        try:
            T["bt_ready"]()
            srv = so.socket(so.AF_BLUETOOTH, so.SOCK_STREAM, so.BTPROTO_RFCOMM)
            try:
                # Verbindung nur nach Kopplung (BT_SECURITY = mittel)
                srv.setsockopt(274, 4, struct.pack("BB", 2, 0))
            except OSError:
                pass
            srv.bind(("00:00:00:00:00:00", BT_REMOTE_CHANNEL))
            srv.listen(2)
            _btr.update(listening=True, error="")
            while True:
                conn, addr = srv.accept()
                threading.Thread(target=_btr_handle, args=(conn, addr[0].upper()), daemon=True).start()
        except Exception as e:  # noqa: BLE001
            _btr.update(listening=False, error=str(e)[:160])
            try:
                if srv:
                    srv.close()
            except OSError:
                pass
            time.sleep(30)


GET_ROUTES["/api/btremote"] = btremote_status
POST_ROUTES["/api/btremote/window"] = btremote_window
POST_ROUTES["/api/btremote/forget"] = btremote_forget
_old_start9 = start_background


def start_background():  # noqa: F811
    _old_start9()
    threading.Thread(target=btremote_loop, daemon=True).start()


# ==========================================================================
# Videorekorder (siehe recorder.py)
# ==========================================================================
def _rec():
    import recorder
    if not recorder._H:
        recorder.configure(state_file=_state("recordings.json"),
                           channels=lambda: all_channels(include_hidden=True),
                           usb_roots=_usb_roots, run=T["run"], log=lambda *a: print(*a, flush=True))
    return recorder


def rec_status():
    r = _rec()
    pref = _cfg().get("rec_target", "auto")
    ts = [{"id": t["id"], "name": t["name"], "free": t["free"], "kind": t["kind"]} for t in r.targets()]
    try:
        auto = r.pick_target(pref)["id"]
    except r.RecError:
        auto = None
    return {"schedule": r.schedule(), "recordings": r.recordings(), "targets": ts, "pref": pref, "target": auto}


def rec_plan(data):
    r = _rec()
    try:
        r.plan(str(data["channel"])[:80], int(data["start"]), int(data["stop"]), str(data.get("title") or "")[:120],
               pref=_cfg().get("rec_target", "auto"))
    except (KeyError, TypeError, ValueError):
        raise _err("Ungültige Aufnahme")
    except r.RecError as e:
        raise _err(str(e))
    return rec_status()


def rec_now(data):
    """Sofort aufnehmen – bis zum Ende der laufenden Sendung (mind. 15, sonst 60 Minuten)."""
    r = _rec()
    ch = str(data.get("channel") or "")[:80]
    if ch not in {c["name"] for c in all_channels(include_hidden=True)}:
        raise _err("Sender nicht gefunden")
    now = int(time.time())
    p = (epg_now().get(ch) or {}).get("now")
    stop = int(p["stop"]) if p and p["stop"] - now > 15 * 60 else now + 60 * 60
    title = p["title"] if p else ch
    try:
        r.plan(ch, now, stop, title, source="now", pref=_cfg().get("rec_target", "auto"))
        r.tick()
    except r.RecError as e:
        raise _err(str(e))
    st = rec_status()
    rid = f"{ch}|{now}"
    it = next((i for i in st["schedule"] if i["id"] == rid), None)
    if it and it["status"] == "failed":
        raise _err(it.get("error") or "Aufnahme nicht möglich")
    st["title"], st["until"] = title, stop
    return st


def rec_cancel(data):
    r = _rec()
    try:
        r.cancel(str(data.get("id") or ""))
    except r.RecError as e:
        raise _err(str(e))
    return rec_status()


def rec_delete(data):
    r = _rec()
    try:
        r.delete(str(data.get("src") or ""), str(data.get("path") or ""))
    except r.RecError as e:
        raise _err(str(e))
    return rec_status()


def rec_target(data):
    pref = str(data.get("pref") or "auto")
    if pref != "auto" and pref not in {t["id"] for t in _rec().targets()}:
        raise _err("Unbekannter Speicherort")
    cfg = _cfg()
    cfg["rec_target"] = pref
    _save(cfg)
    return rec_status()


_source_root_base = _source_root


def _source_root(src):  # noqa: F811 – Aufnahmen auf der Speicherkarte als eigene Quelle „rec“
    if src == "rec":
        import recorder
        os.makedirs(recorder.SD_DIR, exist_ok=True)
        return os.path.realpath(recorder.SD_DIR)
    return _source_root_base(src)


GET_ROUTES["/api/rec"] = rec_status
POST_ROUTES["/api/rec/plan"] = rec_plan
POST_ROUTES["/api/rec/now"] = rec_now
POST_ROUTES["/api/rec/cancel"] = rec_cancel
POST_ROUTES["/api/rec/delete"] = rec_delete
POST_ROUTES["/api/rec/target"] = rec_target
_old_start10 = start_background


def start_background():  # noqa: F811
    _old_start10()
    threading.Thread(target=_rec().loop, daemon=True).start()


# ==========================================================================
# Kindersicherung: PIN, Kinder-Modus, Tageslimit und Schlafenszeit
# ==========================================================================
KIDS_DEFAULT_CHANNELS = ["KiKA", "Nickelodeon"]
_par = {"fails": 0, "locked_until": 0, "unlocks": {}, "minute": 0}
_par_lock = threading.Lock()


def _par_cfg():
    p = dict(_cfg().get("parental") or {})
    p.setdefault("lock_settings", True)
    p.setdefault("kids_mode", False)
    p.setdefault("limit_min", 0)
    p.setdefault("bedtime", "")
    p.setdefault("kids_channels", KIDS_DEFAULT_CHANNELS)
    return p


def _par_save(p):
    cfg = _cfg()
    cfg["parental"] = p
    _save(cfg)


def _pin_hash(pin, salt):
    return hashlib.sha256((salt + ":" + pin).encode()).hexdigest()


def _pin_ok(pin):
    p = _par_cfg()
    if not p.get("pin_hash"):
        return True
    pin = re.sub(r"\D", "", str(pin or ""))
    with _par_lock:
        if time.time() < _par["locked_until"]:
            raise _err("Zu viele falsche Versuche – bitte 5 Minuten warten.", 429)
        ok = hmac.compare_digest(_pin_hash(pin, p.get("pin_salt", "")), p["pin_hash"])
        if not ok:
            _par["fails"] += 1
            if _par["fails"] >= 5:
                _par.update(fails=0, locked_until=time.time() + 300)
        else:
            _par["fails"] = 0
    if not ok:
        time.sleep(0.6)
    return ok


def _usage_today():
    u = _read_json(_state("kids-usage.json"), {})
    return u if u.get("day") == time.strftime("%Y-%m-%d") else {"day": time.strftime("%Y-%m-%d"), "minutes": 0, "extra": 0}


def _kids_block():
    """Grund, warum gerade gesperrt ist (oder '')."""
    p = _par_cfg()
    if not p["kids_mode"]:
        return ""
    u = _usage_today()
    if p["limit_min"] and u["minutes"] >= p["limit_min"] + u.get("extra", 0):
        return "limit"
    bt = p.get("bedtime") or ""
    if re.match(r"^\d\d:\d\d$", bt):
        now = time.strftime("%H:%M")
        if now >= bt or now < "06:00":
            if time.time() > u.get("bed_ok_until", 0):
                return "bedtime"
    return ""


def parental_status():
    p = _par_cfg()
    u = _usage_today()
    return {"has_pin": bool(p.get("pin_hash")), "lock_settings": p["lock_settings"], "kids_mode": p["kids_mode"],
            "limit_min": p["limit_min"], "bedtime": p["bedtime"], "kids_channels": p["kids_channels"],
            "used_today": u["minutes"], "extra_today": u.get("extra", 0), "blocked": _kids_block()}


def _unlock_ok(data):
    """Gültiger PIN oder frisches Entsperr-Zeichen aus dem gleichen Gerät."""
    tok = str(data.get("unlock") or "")
    with _par_lock:
        until = _par["unlocks"].get(tok, 0)
    if tok and until > time.time():
        return True
    return _pin_ok(data.get("pin"))


def parental_verify(data):
    if not _pin_ok(data.get("pin")):
        raise _err("Falscher PIN", 403)
    tok = secrets.token_urlsafe(16)
    with _par_lock:
        now = time.time()
        _par["unlocks"] = {k: v for k, v in _par["unlocks"].items() if v > now}
        _par["unlocks"][tok] = now + 15 * 60
    return {"ok": True, "unlock": tok, "valid": 15 * 60}


def parental_set(data):
    p = _par_cfg()
    if p.get("pin_hash") and not _unlock_ok(data):
        raise _err("Falscher PIN", 403)
    if "new_pin" in data:
        pin = str(data.get("new_pin") or "")
        if pin == "":
            for k in ("pin_hash", "pin_salt"):
                p.pop(k, None)
            p["kids_mode"] = False
        else:
            if not re.match(r"^\d{4}$", pin):
                raise _err("Der PIN muss aus 4 Ziffern bestehen.")
            salt = secrets.token_hex(8)
            p.update(pin_salt=salt, pin_hash=_pin_hash(pin, salt))
    if "lock_settings" in data:
        p["lock_settings"] = bool(data["lock_settings"])
    if "limit_min" in data:
        if data["limit_min"] not in (0, 30, 45, 60, 90, 120, 180):
            raise _err("Ungültiges Limit")
        p["limit_min"] = data["limit_min"]
    if "bedtime" in data:
        bt = str(data["bedtime"] or "")
        if bt and not re.match(r"^([01]\d|2[0-3]):[0-5]\d$", bt):
            raise _err("Ungültige Uhrzeit")
        p["bedtime"] = bt
    if "kids_channels" in data:
        names = {c["name"] for c in all_channels(include_hidden=True)}
        lst = [n for n in data["kids_channels"] if isinstance(n, str) and n in names][:60] if isinstance(data["kids_channels"], list) else None
        if lst is None:
            raise _err("Ungültige Senderliste")
        p["kids_channels"] = lst
    if "kids_mode" in data:
        if data["kids_mode"] and not p.get("pin_hash"):
            raise _err("Bitte zuerst einen PIN festlegen.")
        p["kids_mode"] = bool(data["kids_mode"])
    _par_save(p)
    return parental_status()


def parental_kids_on(_data=None):
    """Kinder-Modus einschalten geht ohne PIN (ausschalten nur mit PIN)."""
    p = _par_cfg()
    if not p.get("pin_hash"):
        raise _err("Bitte zuerst einen PIN festlegen.")
    p["kids_mode"] = True
    _par_save(p)
    return parental_status()


def parental_extend(data):
    """Mit PIN: heute 30 Minuten länger bzw. Schlafenszeit für eine Stunde aufheben."""
    if not _unlock_ok(data):
        raise _err("Falscher PIN", 403)
    u = _usage_today()
    u["extra"] = u.get("extra", 0) + int(data.get("minutes") or 30)
    u["bed_ok_until"] = time.time() + 3600
    _write_json(_state("kids-usage.json"), u)
    return parental_status()


def parental_loop():
    """Zählt im Kinder-Modus die Fernsehzeit und schickt bei Ablauf zum Sperrbildschirm."""
    last_block = ""
    while True:
        time.sleep(60)
        try:
            p = _par_cfg()
            if not p["kids_mode"]:
                last_block = ""
                continue
            watching = T["tv_power"]() != "standby" and time.time() - last_input() < 45 * 60
            if watching:
                u = _usage_today()
                u["minutes"] = u.get("minutes", 0) + 1
                _write_json(_state("kids-usage.json"), u)
            block = _kids_block()
            if block and block != last_block:
                request_nav(LAUNCHER + "#/kidslock")
            last_block = block
        except Exception:  # noqa: BLE001
            pass


# Im Kinder-Modus liefert die Senderliste nur die Kindersender (gilt für Fernsehen und TV-Programm)
_all_channels_base = all_channels


def all_channels(include_hidden=False):  # noqa: F811
    lst = _all_channels_base(include_hidden)
    p = _par_cfg()
    if p["kids_mode"] and not include_hidden:
        allowed = set(p["kids_channels"])
        lst = [c for c in lst if c["name"] in allowed]
    return lst


GET_ROUTES["/api/channels"] = all_channels
GET_ROUTES["/api/parental"] = parental_status
POST_ROUTES["/api/parental/verify"] = parental_verify
POST_ROUTES["/api/parental/set"] = parental_set
POST_ROUTES["/api/parental/kids"] = parental_kids_on
POST_ROUTES["/api/parental/extend"] = parental_extend
_old_start11 = start_background


def start_background():  # noqa: F811
    _old_start11()
    threading.Thread(target=parental_loop, daemon=True).start()


def _status_with_kids():
    s = {"network": T["network_status"](), "tv": T["tv_power"](), "time": time.time(), "autooff": autooff_left()}
    s["kids"] = _par_cfg()["kids_mode"]
    s["kids_blocked"] = _kids_block()
    return s


GET_ROUTES["/api/status"] = _status_with_kids


# ==========================================================================
# Nachrichten (Schlagzeilen per RSS) für Startseite und Bildschirmschoner
# ==========================================================================
NEWS_SOURCES = {
    "tagesschau": ("tagesschau", "https://www.tagesschau.de/index~rss2.xml"),
    "zdf": ("ZDFheute", "https://www.zdf.de/rss/zdf/nachrichten"),
    "dw": ("Deutsche Welle", "https://rss.dw.com/rdf/rss-de-top"),
    "dw_en": ("DW News (English)", "https://rss.dw.com/rdf/rss-en-top"),
    "spiegel": ("DER SPIEGEL", "https://www.spiegel.de/schlagzeilen/index.rss"),
}
_news = {"at": 0, "src": None, "items": [], "error": ""}


def _strip_html(s):
    s = re.sub(r"<[^>]+>", " ", s or "")
    s = s.replace("&nbsp;", " ").replace("&amp;", "&").replace("&quot;", '"').replace("&#39;", "'")
    return re.sub(r"\s+", " ", s).strip()


def parse_rss(data):
    """RSS 2.0, RDF und Atom: [{title, desc, link, date}]"""
    root = ET.fromstring(data)
    out = []
    for el in root.iter():
        tag = el.tag.split("}")[-1]
        if tag not in ("item", "entry"):
            continue
        f = {c.tag.split("}")[-1]: c for c in el}
        title = _strip_html((f.get("title").text if f.get("title") is not None else "") or "")
        if not title:
            continue
        desc_el = f.get("description") if f.get("description") is not None else f.get("summary")
        link_el = f.get("link")
        link = ""
        if link_el is not None:
            link = (link_el.text or link_el.get("href") or "").strip()
        date = ""
        for k in ("pubDate", "date", "updated", "published"):
            if f.get(k) is not None and f[k].text:
                date = f[k].text.strip()
                break
        ts = 0
        try:
            from email.utils import parsedate_to_datetime
            ts = parsedate_to_datetime(date).timestamp()
        except Exception:  # noqa: BLE001
            try:
                ts = datetime.fromisoformat(date.replace("Z", "+00:00")).timestamp()
            except Exception:  # noqa: BLE001
                ts = 0
        out.append({"title": title[:200], "desc": _strip_html(desc_el.text if desc_el is not None else "")[:300],
                    "link": link if re.match(r"^https?://", link) else "", "time": ts})
    return out[:30]


def news(_query=None, _headers=None):
    src = _cfg().get("news_source") or ("dw_en" if _cfg().get("lang") == "en" else "tagesschau")
    if src not in NEWS_SOURCES:
        src = "tagesschau"
    if _news["src"] == src and time.time() - _news["at"] < 15 * 60 and _news["items"]:
        return {"source": NEWS_SOURCES[src][0], "id": src, "items": _news["items"]}
    try:
        items = parse_rss(_download(NEWS_SOURCES[src][1], limit=3_000_000, timeout=15))
        _news.update(at=time.time(), src=src, items=items, error="")
    except Exception as e:  # noqa: BLE001
        _news["error"] = str(e)[:120]
        if _news["src"] != src:
            _news["items"] = []
    return {"source": NEWS_SOURCES[src][0], "id": src, "items": _news["items"], "error": _news["error"],
            "sources": [{"id": k, "name": v[0]} for k, v in NEWS_SOURCES.items()]}


def news_set(data):
    src = str(data.get("source") or "")
    if src not in NEWS_SOURCES:
        raise _err("Unbekannte Quelle")
    cfg = _cfg()
    cfg["news_source"] = src
    _save(cfg)
    _news["at"] = 0
    return news()


GET_ROUTES["/api/news"] = news
POST_ROUTES["/api/news"] = news_set


# ==========================================================================
# Bildschirmschoner: Fotos von USB-Sticks
# ==========================================================================
def saver_photos():
    import random
    found = []
    for sid, _name, mnt in _usb_roots():
        for dirpath, dirnames, files in os.walk(mnt):
            depth = dirpath[len(mnt):].count(os.sep)
            dirnames[:] = [d for d in dirnames if not d.startswith(".") and depth < 4 and d != "System Volume Information"]
            for f in files:
                if _ftype(f) == "image":
                    found.append({"src": sid, "path": os.path.relpath(os.path.join(dirpath, f), mnt)})
            if len(found) > 3000:
                break
    random.shuffle(found)
    return {"photos": found[:150]}


GET_ROUTES["/api/saver/photos"] = saver_photos


# ==========================================================================
# Systemmonitor und Internet-Geschwindigkeitstest
# ==========================================================================
_cpu_prev = {"t": None}


def _cpu_percent():
    try:
        with open("/proc/stat") as f:
            vals = [int(x) for x in f.readline().split()[1:]]
    except (OSError, ValueError):
        return None
    idle, total = vals[3] + (vals[4] if len(vals) > 4 else 0), sum(vals)
    prev = _cpu_prev["t"]
    _cpu_prev["t"] = (idle, total)
    if not prev or total == prev[1]:
        return None
    return round(100 * (1 - (idle - prev[0]) / (total - prev[1])), 1)


def sysmon():
    out = {"cpu": _cpu_percent(), "cores": os.cpu_count() or 1, "load": os.getloadavg()[0] if hasattr(os, "getloadavg") else None}
    try:
        with open("/sys/class/thermal/thermal_zone0/temp") as f:
            out["temp"] = int(f.read().strip()) / 1000
    except (OSError, ValueError):
        out["temp"] = None
    try:
        mem = {}
        with open("/proc/meminfo") as f:
            for line in f:
                k, v = line.split(":", 1)
                mem[k] = int(v.split()[0]) * 1024
        out["mem_total"], out["mem_free"] = mem.get("MemTotal", 0), mem.get("MemAvailable", 0)
    except (OSError, ValueError):
        pass
    try:
        du = shutil.disk_usage("/")
        out["disk_total"], out["disk_free"] = du.total, du.free
    except OSError:
        pass
    # Raspberry Pi: Unterspannung / Drosselung (vcgencmd get_throttled)
    thr = None
    if shutil.which("vcgencmd"):
        code, o, _ = T["run"](["vcgencmd", "get_throttled"], 5)
        m = re.search(r"0x([0-9a-fA-F]+)", o or "")
        if code == 0 and m:
            v = int(m.group(1), 16)
            thr = {"undervoltage_now": bool(v & 0x1), "throttled_now": bool(v & 0x4 or v & 0x2),
                   "undervoltage_past": bool(v & 0x10000), "throttled_past": bool(v & 0x40000 or v & 0x20000)}
    out["throttle"] = thr
    try:
        with open("/proc/uptime") as f:
            out["uptime"] = float(f.read().split()[0])
    except (OSError, ValueError):
        pass
    return out


SPEED_DOWN = "https://speed.cloudflare.com/__down?bytes=50000000"
SPEED_UP = "https://speed.cloudflare.com/__up"
SPEED_PING = "https://speed.cloudflare.com/__down?bytes=0"
_speed = {"running": False, "phase": "", "down": None, "up": None, "ping": None, "at": 0, "error": ""}


def _speed_worker():
    import urllib.request as ur
    try:
        # Antwortzeit (kleinster von 5 Versuchen)
        _speed["phase"] = "ping"
        pings = []
        for _ in range(5):
            t0 = time.time()
            with ur.urlopen(ur.Request(SPEED_PING, headers={"User-Agent": "Raspi-TV"}), timeout=10) as r:
                r.read()
            pings.append((time.time() - t0) * 1000)
        _speed["ping"] = round(min(pings))
        # Herunterladen: höchstens 10 Sekunden
        _speed["phase"] = "down"
        t0, got = time.time(), 0
        with ur.urlopen(ur.Request(SPEED_DOWN, headers={"User-Agent": "Raspi-TV"}), timeout=20) as r:
            while time.time() - t0 < 10:
                chunk = r.read(256 * 1024)
                if not chunk:
                    break
                got += len(chunk)
                _speed["down"] = round(got * 8 / max(0.001, time.time() - t0) / 1e6, 1)
        # Hochladen: 8 MB (klappt das nicht, bleibt das Download-Ergebnis stehen)
        _speed["phase"] = "up"
        try:
            blob = os.urandom(8 * 1024 * 1024)
            t0 = time.time()
            req = ur.Request(SPEED_UP, data=blob, method="POST", headers={"User-Agent": "Raspi-TV", "Content-Type": "application/octet-stream"})
            with ur.urlopen(req, timeout=40) as r:
                r.read()
            _speed["up"] = round(len(blob) * 8 / max(0.001, time.time() - t0) / 1e6, 1)
        except Exception:  # noqa: BLE001
            _speed["up"] = None
        _speed.update(error="", at=time.time())
    except Exception as e:  # noqa: BLE001
        print("Geschwindigkeitstest:", e, flush=True)
        _speed.update(error="Test nicht möglich – ist Raspi-TV mit dem Internet verbunden?", at=time.time())
    finally:
        _speed.update(running=False, phase="")


def speedtest_start(_data=None):
    if not _speed["running"]:
        _speed.update(running=True, phase="ping", down=None, up=None, ping=None, error="")
        threading.Thread(target=_speed_worker, daemon=True).start()
    return dict(_speed)


GET_ROUTES["/api/sysmon"] = sysmon
GET_ROUTES["/api/speedtest"] = lambda: dict(_speed)
POST_ROUTES["/api/speedtest"] = speedtest_start


# Handy-Fernbedienung: Akzentfarbe des gewählten Designs mitschicken
_ACCENT_HEX = {"blue": ("#3d8bff", "#2563eb", "#1d4ed8"), "violet": ("#a78bfa", "#7c3aed", "#6d28d9"),
               "green": ("#34d399", "#047857", "#065f46"), "orange": ("#fb923c", "#c2410c", "#9a3412"),
               "red": ("#f87171", "#dc2626", "#b91c1c"), "pink": ("#f472b6", "#be185d", "#9d174d"),
               "teal": ("#22d3ee", "#0e7490", "#155e75"), "gold": ("#fbbf24", "#b45309", "#92400e")}
_THEME_ACCENT = {"midnight": "blue", "oled": "blue", "aurora": "teal", "sunset": "orange", "forest": "green",
                 "cinema": "red", "light": "blue", "auto": "blue"}
_remote_ping_base = _remote_ping


def _remote_ping(data):  # noqa: F811
    out = _remote_ping_base(data)
    cfg = _cfg()
    acc = cfg.get("accent") or "theme"
    if acc == "theme":
        acc = _THEME_ACCENT.get(cfg.get("theme") or "midnight", "blue")
    a, f1, f2 = _ACCENT_HEX.get(acc, _ACCENT_HEX["blue"])
    out["accent"] = {"a": a, "f1": f1, "f2": f2}
    return out


REMOTE_ROUTES_EXTRA["/r/ping"] = _remote_ping


# ==========================================================================
# Handy-App 1.3: „Jetzt läuft“, Senderliste, Umschalten, Aufnehmen, Schlaf-Timer
#   Alles läuft über REMOTE_ROUTES – also per WLAN und genauso per Bluetooth.
# ==========================================================================
_tvnow = {"name": None, "at": 0, "favs": []}
_sleep = {"until": 0}


def tv_now_report(data):
    """tv.html meldet den laufenden Sender (beim Umschalten und alle 30 s)."""
    name = data.get("name")
    _tvnow["name"] = str(name)[:80] if name else None
    _tvnow["at"] = time.time() if name else 0
    favs = data.get("favs")
    if isinstance(favs, list):
        _tvnow["favs"] = [str(f)[:80] for f in favs[:200]]
    return {"ok": True}


def _watching():
    return _tvnow["name"] if _tvnow["name"] and time.time() - _tvnow["at"] < 75 else None


def _sleep_left():
    left = _sleep["until"] - time.time()
    return int(left) if _sleep["until"] and left > 0 else None


def _slim(p):
    return {"title": p["title"], "start": p["start"], "stop": p["stop"]} if p else None


def remote_state(_data=None):
    name = _watching()
    rec = None
    try:
        rec = next((i for i in _rec().schedule() if i["status"] == "recording"), None)
    except Exception:  # noqa: BLE001 – ohne Rekorder trotzdem antworten
        pass
    out = {"tv": T["tv_power"](), "channel": None, "now": None, "next": None, "sleep_left": _sleep_left(),
           "recording": {"channel": rec["channel"], "title": rec["title"], "stop": rec["stop"]} if rec else None,
           "time": int(time.time())}
    if name:
        ch = next((c for c in all_channels() if c["name"] == name), None)
        e = epg_now().get(name) or {}
        out.update(channel={"name": name, "logo": (ch or {}).get("logo", ""),
                            "num": next((i + 1 for i, c in enumerate(all_channels()) if c["name"] == name), None)},
                   now=_slim(e.get("now")), next=_slim(e.get("next")))
    return out


def remote_channels(_data=None):
    epg = epg_now()
    favs = set(_tvnow["favs"])
    recs = set()
    try:
        recs = {i["channel"] for i in _rec().schedule() if i["status"] == "recording"}
    except Exception:  # noqa: BLE001
        pass
    lst = []
    for i, c in enumerate(all_channels()):
        e = epg.get(c["name"]) or {}
        lst.append({"num": i + 1, "name": c["name"], "logo": c.get("logo", ""), "fav": c["name"] in favs,
                    "rec": c["name"] in recs, "now": _slim(e.get("now")), "next": _slim(e.get("next"))})
    return {"channels": lst, "current": _watching(), "time": int(time.time())}


def remote_channel(data):
    name = str(data.get("name") or "")[:80]
    if name not in {c["name"] for c in all_channels()}:
        raise _err("Sender nicht gefunden")
    touch_activity()
    if T["tv_power"]() == "standby":
        try:
            cec_action({"action": "tv_on"})
        except Exception:  # noqa: BLE001
            pass
    request_nav(LAUNCHER + "tv.html?name=" + quote(name, safe=""))
    _tvnow.update(name=name, at=time.time())
    return {"ok": True}


def remote_record(data):
    """Läuft auf dem Sender schon eine Aufnahme → beenden, sonst sofort aufnehmen."""
    name = str(data.get("name") or _watching() or "")[:80]
    if not name:
        raise _err("Am Fernseher läuft gerade kein Sender")
    r = _rec()
    running = next((i for i in r.schedule() if i["status"] == "recording" and i["channel"] == name), None)
    if running:
        rec_cancel({"id": running["id"]})
        return {"ok": True, "recording": False, "title": running["title"]}
    st = rec_now({"channel": name})
    return {"ok": True, "recording": True, "title": st.get("title"), "until": st.get("until")}


def remote_sleep(data):
    try:
        minutes = max(0, min(240, int(data.get("minutes", 0))))
    except (TypeError, ValueError):
        raise _err("Ungültige Zeit")
    _sleep["until"] = time.time() + minutes * 60 if minutes else 0
    return {"ok": True, "sleep_left": _sleep_left()}


def sleep_loop():
    while True:
        time.sleep(10)
        try:
            if _sleep["until"] and time.time() >= _sleep["until"]:
                _sleep["until"] = 0
                T["tv_standby"]()
                _set_tv_power("standby")
                touch_activity()
        except Exception:  # noqa: BLE001 – Hintergrundschleife darf nie sterben
            pass


# Die letzten 2 Minuten des Schlaf-Timers zeigt der Fernseher wie die Abschalt-Warnung an
_autooff_left_base = autooff_left


def autooff_left():  # noqa: F811
    a, s = _autooff_left_base(), _sleep_left()
    if s is not None and s <= 120:
        return s if a is None else min(a, s)
    return a


_old_start12 = start_background


def start_background():  # noqa: F811
    _old_start12()
    threading.Thread(target=sleep_loop, daemon=True).start()


POST_ROUTES["/api/tv/now"] = tv_now_report
GET_ROUTES["/api/sleep"] = lambda: {"sleep_left": _sleep_left()}
POST_ROUTES["/api/sleep"] = remote_sleep
REMOTE_ROUTES_EXTRA["/r/state"] = remote_state
REMOTE_ROUTES_EXTRA["/r/channels"] = remote_channels
REMOTE_ROUTES_EXTRA["/r/channel"] = remote_channel
REMOTE_ROUTES_EXTRA["/r/record"] = remote_record
REMOTE_ROUTES_EXTRA["/r/sleep"] = remote_sleep
_status_sleep_base = _status_with_kids


def _status_with_kids():  # noqa: F811
    s = _status_sleep_base()
    s["sleep_left"] = _sleep_left()
    return s


GET_ROUTES["/api/status"] = _status_with_kids


# ==========================================================================
# Aussehen der Handy-App – wird am Fernseher eingestellt, per WLAN/Bluetooth aufs Handy
# übertragen und dort gespeichert (gilt also auch, wenn der Pi gerade nicht erreichbar ist).
# ==========================================================================
APP_TABS = ("channels", "touch", "keys", "search", "gamepad")
APP_LOOK_DEFAULT = {"theme": "tv", "accent": "tv", "layout": "classic", "hand": "right", "corners": "tv",
                    "nowbar": True, "tabs": {k: True for k in APP_TABS}}
APP_LOOK_CHECKS = {
    "theme": lambda v: v in ("tv", "midnight", "oled", "aurora", "sunset", "forest", "cinema", "light"),
    "accent": lambda v: v in ("tv", "blue", "violet", "teal", "green", "gold", "orange", "red", "pink"),
    "layout": lambda v: v in ("classic", "big", "swipe", "top"),
    "hand": lambda v: v in ("right", "left"),
    "corners": lambda v: v in ("tv", "round", "soft", "square"),
    "nowbar": lambda v: isinstance(v, bool),
    "tabs": lambda v: isinstance(v, dict) and all(k in APP_TABS and isinstance(x, bool) for k, x in v.items()),
}


def app_look():
    cfg = _cfg()
    raw = dict(APP_LOOK_DEFAULT)
    saved = cfg.get("app_look") or {}
    if isinstance(saved, dict):
        raw.update({k: v for k, v in saved.items() if k in APP_LOOK_CHECKS and APP_LOOK_CHECKS[k](v)})
    tabs = dict(APP_LOOK_DEFAULT["tabs"])
    tabs.update(raw.get("tabs") or {})
    theme = raw["theme"]
    if theme == "tv":
        theme = cfg.get("theme") or "midnight"
        if theme == "auto":
            theme = "light" if 7 <= time.localtime().tm_hour < 19 else "midnight"
    if theme not in ("midnight", "oled", "aurora", "sunset", "forest", "cinema", "light"):
        theme = "midnight"
    acc = raw["accent"]
    if acc == "tv":
        acc = cfg.get("accent") or "theme"
        if acc == "theme":
            acc = _THEME_ACCENT.get(cfg.get("theme") or "midnight", "blue")
    if raw["accent"] == "tv" and raw["theme"] != "tv":
        acc = _THEME_ACCENT.get(theme, "blue")      # eigenes Handy-Design bringt seine Farbe mit
    a, f1, f2 = _ACCENT_HEX.get(acc, _ACCENT_HEX["blue"])
    corners = raw["corners"] if raw["corners"] != "tv" else (cfg.get("corners") or "round")
    out = {"theme": theme, "accent": {"a": a, "f1": f1, "f2": f2}, "layout": raw["layout"], "hand": raw["hand"],
           "corners": corners, "nowbar": raw["nowbar"], "tabs": tabs}
    out["v"] = hashlib.sha1(json.dumps(out, sort_keys=True).encode()).hexdigest()[:10]
    return out


_remote_ping_look = _remote_ping


def _remote_ping(data):  # noqa: F811
    out = _remote_ping_look(data)
    out["look"] = app_look()
    out["accent"] = out["look"]["accent"]
    return out


REMOTE_ROUTES_EXTRA["/r/ping"] = _remote_ping
GET_ROUTES["/api/applook"] = lambda: {"look": app_look(), "saved": dict(APP_LOOK_DEFAULT, **(_cfg().get("app_look") or {}))}


# ==========================================================================
# Terminal (Einstellungen · System · Terminal und Apps → Terminal)
#   Echte Shell auf dem Pi im Fernseher. Die Sitzung läuft weiter, wenn man die Seite verlässt.
#   Angemeldet als Wartungsbenutzer (admin, sudo mit Passwort), damit nicht jeder mit der
#   Fernbedienung Root-Rechte hat.
# ==========================================================================
TERMINAL_USER = "admin"
TERM_APPS = ("shell", "spotify")


def _term():
    import terminal
    return terminal


def _user_env(user):
    import pwd
    pw = pwd.getpwnam(user)
    return pw, {"HOME": pw.pw_dir, "USER": user, "LOGNAME": user, "SHELL": pw.pw_shell or "/bin/bash",
                "TERM": "xterm-256color", "COLORTERM": "truecolor", "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8",
                "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
                "XDG_RUNTIME_DIR": f"/run/user/{pw.pw_uid}"}


def _shell_cmd():
    """Login-Shell des Wartungsbenutzers – ohne ihn (Entwicklungsrechner) die eigene Shell."""
    for user in (TERMINAL_USER, T["TV_USER"]):
        try:
            _, env = _user_env(user)
        except KeyError:
            continue
        if os.geteuid() == 0 and shutil.which("runuser"):
            return ["runuser", "-l", user], env, env["HOME"]
    env = {k: v for k, v in os.environ.items() if k not in ("DISPLAY", "WAYLAND_DISPLAY")}
    env.update(TERM="xterm-256color", COLORTERM="truecolor")
    return ["bash", "-l"], env, os.path.expanduser("~")


def _term_session(sid):
    s = _term().get(sid)
    if not s:
        raise _err("Sitzung nicht gefunden", 404)
    return s


def term_start(data):
    app = data.get("app", "shell")
    if app not in TERM_APPS:
        raise _err("Unbekannt")
    cols, rows = data.get("cols", 100), data.get("rows", 30)
    if app == "spotify":
        argv, env, cwd = _ncspot_cmd()
        s = _term().start("spotify", argv, env, cwd, cols, rows, "Spotify")
    else:
        argv, env, cwd = _shell_cmd()
        if data.get("restart"):
            _term().stop("shell")
            time.sleep(0.3)
        s = _term().start("shell", argv, env, cwd, cols, rows, "Terminal")
    touch_activity()
    return s.info()


def term_read(query, headers):
    if headers.get("X-Raspi-TV") != "1":
        raise _err("forbidden", 403)
    s = _term_session((query.get("id") or [""])[0])
    try:
        since = int((query.get("since") or ["0"])[0])
    except ValueError:
        since = 0
    out = s.read(since, 20)
    if s.id == "spotify":
        auth = _ncspot_auth(s)
        out["auth_url"] = auth["url"] if auth else None
        out["auth_step"] = auth["step"] if auth else 0
    return out


def term_write(data):
    s = _term_session(str(data.get("id") or ""))
    text = data.get("data")
    if not isinstance(text, str) or len(text) > 65536:
        raise _err("Ungültig")
    s.write(text)
    touch_activity()
    return {"ok": True}


def term_resize(data):
    _term_session(str(data.get("id") or "")).resize(data.get("cols"), data.get("rows"))
    return {"ok": True}


def term_stop(data):
    sid = str(data.get("id") or "")
    if sid in TERM_APPS:
        _term().stop(sid)
    return {"ok": True}


POST_ROUTES["/api/term/start"] = term_start
POST_ROUTES["/api/term/write"] = term_write
POST_ROUTES["/api/term/resize"] = term_resize
POST_ROUTES["/api/term/stop"] = term_stop
QUERY_ROUTES["/api/term/read"] = term_read
GET_ROUTES["/api/term"] = lambda: {"sessions": _term().all_info()}


# ==========================================================================
# Spotify als App auf dem Fernseher (ncspot)
#   Spotify gibt es für den Raspberry Pi nicht als offizielles Programm. ncspot ist ein
#   schlanker Spotify-Player (librespot, braucht Spotify Premium). Er läuft in einer
#   dauerhaften Terminal-Sitzung: Musik spielt weiter, auch auf der Startseite und in
#   anderen Apps. Steuerung mit der Fernbedienung (Pfeile, OK, Zurück, Pause, CH ±).
# ==========================================================================
# 1.5.0: Spotify hat Ende Oktober 2026 die Rückmeldeadresse von ncspot geändert (/ncspot_login) –
# ältere Versionen scheitern bei der zweiten Anmeldung mit „redirect_uri: Not matching configuration“.
NCSPOT_VERSION = "1.5.0"
NCSPOT_STAMP = "/usr/local/lib/raspi-tv-ncspot.version"
NCSPOT_URL = "https://github.com/hrkfdn/ncspot/releases/download/v{v}/ncspot-v{v}-linux-{arch}.tar.gz"
NCSPOT_BIN = "/usr/local/bin/ncspot"
NCSPOT_DEPS = ("libpulse0", "libssl3t64")

_ANSI = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b\][^\x07]*\x07|\x1b[()][A-Z0-9]")

NCSPOT_CONFIG = '''# Von Raspi-TV verwaltet – wird beim Start von Spotify überschrieben.
use_nerdfont = false
notify = false
gapless = true
volnorm = true
bitrate = 320
backend = "pulseaudio"
initial_screen = "library"
library_tabs = ["tracks", "albums", "artists", "playlists", "podcasts"]

[keybindings]
"Space" = "playpause"
"PageUp" = "previous"
"PageDown" = "next"
"g" = "focus library"
"i" = "focus queue"
"r" = "focus search"
"F5" = "focus search"
"q" = "noop"

[theme]
background = "#121212"
primary = "#f2f2f2"
secondary = "#a7a7a7"
title = "#1ed760"
playing = "#1ed760"
playing_selected = "#1ed760"
playing_bg = "#121212"
highlight = "#ffffff"
highlight_bg = "#2f6b45"
error = "#ffffff"
error_bg = "#c0392b"
statusbar = "#121212"
statusbar_progress = "#1ed760"
statusbar_bg = "#1ed760"
cmdline = "#ffffff"
cmdline_bg = "#181818"
search_match = "#1ed760"
'''


def _ncspot_bin():
    return shutil.which("ncspot") or (NCSPOT_BIN if os.access(NCSPOT_BIN, os.X_OK) else None)


def _ncspot_cmd():
    exe = _ncspot_bin()
    if not exe:
        raise _err("Spotify ist noch nicht installiert")
    try:
        pw, env = _user_env(T["TV_USER"])
        user = T["TV_USER"]
    except KeyError:
        pw, user = None, None
        env = {k: v for k, v in os.environ.items() if k not in ("DISPLAY", "WAYLAND_DISPLAY")}
        env.update(TERM="xterm-256color", COLORTERM="truecolor")
    home = env.get("HOME") or os.path.expanduser("~")
    cfgdir = os.path.join(home, ".config", "ncspot")
    try:
        os.makedirs(cfgdir, exist_ok=True)
        with open(os.path.join(cfgdir, "config.toml"), "w") as f:
            f.write(NCSPOT_CONFIG)
        if pw and os.geteuid() == 0:
            for d in (os.path.join(home, ".config"), cfgdir, os.path.join(cfgdir, "config.toml")):
                os.chown(d, pw.pw_uid, pw.pw_gid)
    except OSError:
        pass
    env["BROWSER"] = "/bin/true"     # Anmelde-Link nicht selbst öffnen – die Oberfläche zeigt ihn an
    if user and os.geteuid() == 0 and shutil.which("runuser"):
        return ["runuser", "-u", user, "--", "env"] + [f"{k}={v}" for k, v in env.items()] + [exe], env, home
    return [exe], env, home


def _listen_ports():
    """Lokale TCP-Ports im Zustand LISTEN (ohne sich zu verbinden – das würde die Anmeldung stören)."""
    ports = set()
    for f in ("/proc/net/tcp", "/proc/net/tcp6"):
        try:
            with open(f) as fh:
                next(fh, None)
                for line in fh:
                    parts = line.split()
                    if len(parts) > 3 and parts[3] == "0A":
                        ports.add(int(parts[1].rsplit(":", 1)[1], 16))
        except (OSError, ValueError):
            pass
    return ports


_AUTH_RE = re.compile(r"https://accounts\.spotify\.com/authorize\?[^\s\"'<>\x00-\x1f]+(?=\s)")


def _ncspot_auth(s):
    """Offene Spotify-Anmeldung: der letzte Anmelde-Link, dessen Rückmelde-Port ncspot gerade offen hat.
    ncspot fragt zweimal (Wiedergabe, danach Bibliothek/Playlists) – jeweils mit eigenem Port."""
    raw = bytes(s.buf)
    if b"accounts.spotify.com/authorize" not in raw:
        return None
    text = _ANSI.sub("", raw.decode("utf-8", "replace"))
    urls = []
    for m in _AUTH_RE.finditer(text):
        if m.group(0) not in urls:
            urls.append(m.group(0))
    if not urls:
        return None
    ports = _listen_ports()
    for i in range(len(urls) - 1, -1, -1):
        q = parse_qs(urlparse(urls[i]).query)
        try:
            port = urlparse((q.get("redirect_uri") or [""])[0]).port
        except ValueError:
            port = None
        if port and port in ports:
            return {"url": urls[i], "step": i + 1}
    return None


def _ncspot_sock_paths():
    paths = []
    try:
        import pwd
        uid = pwd.getpwnam(T["TV_USER"]).pw_uid
        home = pwd.getpwnam(T["TV_USER"]).pw_dir
    except KeyError:
        uid, home = os.getuid(), os.path.expanduser("~")
    for pat in (f"/run/user/{uid}/ncspot/*.sock", f"/run/user/{uid}/ncspot*.sock", f"/tmp/ncspot-{uid}/*.sock",
                f"{home}/.cache/ncspot/*.sock"):
        paths += glob.glob(pat)
    return paths


def _ncspot_ipc(cmd=None):
    """Status über die IPC-Schnittstelle von ncspot lesen (eine JSON-Zeile) und ggf. Befehl schicken."""
    import socket as _s
    for path in _ncspot_sock_paths():
        try:
            c = _s.socket(_s.AF_UNIX, _s.SOCK_STREAM)
            c.settimeout(1.0)
            c.connect(path)
            if cmd:
                c.sendall((cmd + "\n").encode())
            buf = b""
            while b"\n" not in buf and len(buf) < 65536:
                part = c.recv(8192)
                if not part:
                    break
                buf += part
            c.close()
            line = buf.split(b"\n", 1)[0]
            return json.loads(line) if line else {}
        except (OSError, ValueError):
            continue
    return None


def _ncspot_now():
    s = _term().get("spotify")
    if not s or not s.alive:
        return None
    st = _ncspot_ipc()
    if not st:
        return None
    mode = st.get("mode")
    playing = isinstance(mode, dict) and "Playing" in mode
    paused = isinstance(mode, dict) and "Paused" in mode
    p = st.get("playable") or {}
    artists = p.get("artists") or []
    cover = p.get("cover_url") or ""
    return {"playing": playing, "paused": paused, "title": str(p.get("title") or "")[:120],
            "artist": ", ".join(str(a) for a in artists)[:120] if isinstance(artists, list) else str(artists)[:120],
            "album": str(p.get("album") or "")[:120], "cover": cover if str(cover).startswith("https://") else "",
            "duration": int(p.get("duration") or 0), "position": 0, "at": int(time.time()), "app": True}


_spotify_now_base = spotify_now


def spotify_now():  # noqa: F811
    n = _ncspot_now()
    if n and (n["playing"] or n["paused"]):
        return n
    return _spotify_now_base()


def _ncspot_outdated():
    """Von Raspi-TV installiertes ncspot, aber nicht die aktuelle Version → neu laden."""
    if _ncspot_bin() != NCSPOT_BIN:
        return False
    try:
        with open(NCSPOT_STAMP) as f:
            return f.read().strip() != NCSPOT_VERSION
    except OSError:
        return True


def ncspot_status():
    job = dict(_job) if _job.get("id") == "ncspot" else None
    s = _term().get("spotify")
    _, arch, _ = T["run"](["dpkg", "--print-architecture"], 10)
    return {"installed": bool(_ncspot_bin()), "update": _ncspot_outdated(), "running": bool(s and s.alive), "job": job,
            "supported": (arch.strip() or "arm64") in ("arm64", "amd64"), "version": NCSPOT_VERSION}


def _ncspot_install_worker():
    try:
        with _apt_lock, open(NATIVE_LOG, "a") as log:
            log.write(f"\n=== {time.strftime('%Y-%m-%d %H:%M:%S')} install ncspot ===\n")
            _job.update(step="Wird vorbereitet", percent=5)
            # Offizielles Release von GitHub (64-Bit) – die Paketquellen haben oft eine ältere Version
            _, arch, _ = T["run"](["dpkg", "--print-architecture"], 10)
            arch = {"arm64": "arm64", "amd64": "x86_64"}.get(arch.strip() or "arm64")
            if not arch:
                raise RuntimeError("Spotify braucht ein 64-Bit-System (Raspberry Pi 3, 4 oder 5 mit 64-Bit-Image).")
            for i, dep in enumerate(NCSPOT_DEPS):
                _job.update(step="Wird vorbereitet", percent=10 + i * 4)
                _apt(["install", "--no-install-recommends", dep], log, 10 + i * 4, 12 + i * 4)
            os.makedirs("/var/cache/raspi-tv", exist_ok=True)
            tgz = "/var/cache/raspi-tv/ncspot.tar.gz"
            _job.update(step="Wird heruntergeladen", percent=45)
            p = subprocess.run(["curl", "-fsSL", "--retry", "3", "-o", tgz, NCSPOT_URL.format(v=NCSPOT_VERSION, arch=arch)],
                               stdout=log, stderr=subprocess.STDOUT, timeout=600)
            if p.returncode != 0:
                raise RuntimeError("Spotify konnte nicht geladen werden – Internetverbindung prüfen.")
            _job.update(step="Wird installiert", percent=80)
            tmp = tempfile.mkdtemp(prefix="ncspot-")
            p = subprocess.run(["tar", "xzf", tgz, "-C", tmp], stdout=log, stderr=subprocess.STDOUT, timeout=120)
            exe = next((os.path.join(d, f) for d, _, fs in os.walk(tmp) for f in fs if f == "ncspot"), None)
            if p.returncode != 0 or not exe:
                raise RuntimeError("Spotify-Paket ist beschädigt.")
            # laufendes Spotify beenden und die Datei austauschen (auch während sie benutzt wird)
            _term().stop("spotify")
            shutil.copy(exe, NCSPOT_BIN + ".new")
            os.chmod(NCSPOT_BIN + ".new", 0o755)
            os.replace(NCSPOT_BIN + ".new", NCSPOT_BIN)
            os.makedirs(os.path.dirname(NCSPOT_STAMP), exist_ok=True)
            with open(NCSPOT_STAMP, "w") as f:
                f.write(NCSPOT_VERSION + "\n")
            shutil.rmtree(tmp, ignore_errors=True)
            try:
                os.remove(tgz)
            except OSError:
                pass
            _, missing, _ = T["run"](["sh", "-c", f"ldd {NCSPOT_BIN} | grep 'not found' || true"], 20)
            if missing.strip():
                log.write("Fehlende Bibliotheken:\n" + missing)
                raise RuntimeError("Spotify fehlen Systembibliotheken: " + missing.strip().split()[0])
        _job.update(done=True, percent=100, step="Fertig")
    except Exception as e:  # noqa: BLE001
        _job["error"] = str(e)
    finally:
        _job["running"] = False


def ncspot_install(_data=None):
    if _ncspot_bin() and not _ncspot_outdated():
        return ncspot_status()
    if _job["running"]:
        raise _err("Es läuft schon eine Installation – bitte kurz warten.", 409)
    _job.update(running=True, id="ncspot", action="install", step="Wird vorbereitet", percent=0, error=None, done=False)
    threading.Thread(target=_ncspot_install_worker, daemon=True).start()
    return ncspot_status()


def ncspot_ctl(data):
    cmd = data.get("cmd")
    if cmd not in ("playpause", "next", "previous", "stop"):
        raise _err("Ungültig")
    if _ncspot_ipc(cmd) is None:
        s = _term().get("spotify")
        keys = {"playpause": " ", "next": "\x1b[6~", "previous": "\x1b[5~", "stop": "S"}
        if not s or not s.alive:
            raise _err("Spotify läuft nicht")
        s.write(keys[cmd])
    return {"ok": True}


def ncspot_quit(_data=None):
    _term().stop("spotify")
    return {"ok": True}


GET_ROUTES["/api/spotify/now"] = spotify_now
GET_ROUTES["/api/ncspot"] = ncspot_status
POST_ROUTES["/api/ncspot/install"] = ncspot_install
POST_ROUTES["/api/ncspot/ctl"] = ncspot_ctl
POST_ROUTES["/api/ncspot/quit"] = ncspot_quit


# ==========================================================================
# Spotify im eigenen Hintergrund-Tab (open.spotify.com)
#   Die Erweiterung meldet, was gerade läuft – für die Leiste auf der Startseite.
# ==========================================================================
_webnow = {"now": None, "at": 0}


def spotify_webnow(query, headers):
    if headers.get("X-Raspi-TV") != "1":
        raise _err("forbidden", 403)
    try:
        n = json.loads((query.get("d") or ["null"])[0])
    except ValueError:
        n = None
    if isinstance(n, dict) and n.get("title"):
        cover = str(n.get("cover") or "")
        _webnow.update(at=time.time(), now={
            "playing": bool(n.get("playing")), "paused": not n.get("playing"), "title": str(n["title"])[:120],
            "artist": str(n.get("artist") or "")[:120], "album": "", "duration": 0, "position": 0,
            "cover": cover if cover.startswith("https://") else "", "at": int(time.time()), "web": True})
    else:
        _webnow.update(at=time.time(), now=None)
    return {"ok": True}


_spotify_now_app = spotify_now


def spotify_now():  # noqa: F811
    if _webnow["now"] and time.time() - _webnow["at"] < 20:
        return _webnow["now"]
    return _spotify_now_app()


QUERY_ROUTES["/api/spotify/webnow"] = spotify_webnow
GET_ROUTES["/api/spotify/now"] = spotify_now


# ==========================================================================
# Handy-App: Raspberry Pi ausschalten / neu starten (WLAN und Bluetooth)
# ==========================================================================
def remote_system(data):
    action = data.get("action")
    if action not in ("shutdown", "reboot"):
        raise _err("Ungültig")
    push_notice({"kicker": "Handy-Fernbedienung",
                 "title": "Raspberry Pi startet neu" if action == "reboot" else "Raspberry Pi wird ausgeschaltet",
                 "sub": "Einen Moment …" if action == "reboot" else "Zum Einschalten kurz den Strom trennen"}, ttl=20)
    threading.Timer(2.5, T["power"], [action]).start()     # Hinweis noch kurz am Fernseher zeigen
    return {"ok": True}


REMOTE_ROUTES_EXTRA["/r/system"] = remote_system


# ==========================================================================
# Update-Pakete von Windows: Zeilenenden reparieren
#   Unter Windows bearbeitete Dateien haben oft CRLF-Zeilenenden. Shell-Skripte (z. B. der
#   Browser-Start) laufen damit unter Linux nicht – deshalb vor dem Installieren umwandeln.
# ==========================================================================
_TEXT_EXT = (".sh", ".py", ".js", ".cjs", ".mjs", ".html", ".css", ".json", ".service", ".txt", ".md", ".conf", ".toml")
_TEXT_NAMES = ("xinitrc", "xbindkeysrc", "bash_profile", "VERSION", "00-packages-nr")


def _unix_line_endings(root):
    n = 0
    for d, _, files in os.walk(root):
        for f in files:
            if not (f.endswith(_TEXT_EXT) or f in _TEXT_NAMES):
                continue
            p = os.path.join(d, f)
            try:
                with open(p, "rb") as fh:
                    data = fh.read()
                if b"\r" in data or data.startswith(b"\xef\xbb\xbf"):
                    with open(p, "wb") as fh:
                        fh.write(data.removeprefix(b"\xef\xbb\xbf").replace(b"\r\n", b"\n").replace(b"\r", b"\n"))
                    n += 1
            except OSError:
                pass
    return n


# ==========================================================================
# iPhone-Fernbedienung (HomeKit, Dienst raspi-tv-homekit)
#   Einstellungen → Fernbedienung → iPhone. HAP-python wird beim ersten Einschalten aus dem
#   Internet geladen (nach /var/lib/raspi-tv/pylib, das System bleibt unverändert).
# ==========================================================================
HK_PYLIB = "/var/lib/raspi-tv/pylib"
HK_INFO = "/run/raspi-tv/homekit.json"
HK_VERSION = "5.1.0"
HK_INPUTS = {1: "", 2: "tv.html", 3: "#/guide", 4: "#/radio", 5: "#/media"}


def _hk_installed():
    return os.path.isdir(os.path.join(HK_PYLIB, "pyhap")) and os.path.isdir(os.path.join(HK_PYLIB, "zeroconf"))


def _hk_running():
    code, out, _ = T["run"](["systemctl", "is-active", "raspi-tv-homekit"], 10)
    return out.strip() == "active"


def homekit_status():
    info = {}
    try:
        with open(HK_INFO) as f:
            info = json.load(f)
    except (OSError, ValueError):
        pass
    running = _hk_running()
    job = dict(_job) if _job.get("id") == "homekit" else None
    return {"enabled": bool(_cfg().get("homekit")), "installed": _hk_installed(), "running": running,
            "pin": info.get("pin") if running else None, "uri": info.get("uri") if running else None,
            "paired": bool(info.get("paired")) if running else False, "clients": info.get("clients", 0),
            "addresses": info.get("addresses", []), "job": job}


def _hk_service(on):
    T["run"](["systemctl", "enable" if on else "disable", "--now", "raspi-tv-homekit"], 60)


def _hk_install_worker():
    try:
        with _apt_lock, open(NATIVE_LOG, "a") as log:
            log.write(f"\n=== {time.strftime('%Y-%m-%d %H:%M:%S')} install HomeKit ===\n")
            _job.update(step="Wird vorbereitet", percent=5)
            code, _, _ = T["run"](["python3", "-m", "pip", "--version"], 30)
            if code != 0:
                _apt(["install", "--no-install-recommends", "python3-pip"], log, 5, 40)
            _job.update(step="Wird heruntergeladen", percent=45)
            os.makedirs(HK_PYLIB, exist_ok=True)
            p = subprocess.run(["python3", "-m", "pip", "install", "--disable-pip-version-check", "--no-cache-dir",
                                "--break-system-packages", "--upgrade", "--target", HK_PYLIB, f"HAP-python=={HK_VERSION}"],
                               stdout=log, stderr=subprocess.STDOUT, timeout=1200)
            if p.returncode != 0 or not _hk_installed():
                raise RuntimeError("HomeKit konnte nicht geladen werden – Internetverbindung prüfen.")
            _job.update(step="Wird gestartet", percent=90)
            if _cfg().get("homekit"):
                _hk_service(True)
        _job.update(done=True, percent=100, step="Fertig")
    except Exception as e:  # noqa: BLE001
        _job["error"] = str(e)
    finally:
        _job["running"] = False


def homekit_set(data):
    on = bool(data.get("on"))
    cfg = _cfg()
    cfg["homekit"] = on
    T["save_config"](cfg)
    if on and not _hk_installed():
        if _job["running"]:
            raise _err("Es läuft schon eine Installation – bitte kurz warten.", 409)
        _job.update(running=True, id="homekit", action="install", step="Wird vorbereitet", percent=0, error=None, done=False)
        threading.Thread(target=_hk_install_worker, daemon=True).start()
    else:
        _hk_service(on)
    return homekit_status()


def homekit_reset(_data=None):
    """Kopplung löschen: neuer Code, das iPhone muss neu hinzugefügt werden."""
    T["run"](["systemctl", "stop", "raspi-tv-homekit"], 30)
    for f in ("homekit.state", "homekit-code.json"):
        try:
            os.remove(os.path.join("/var/lib/raspi-tv", f))
        except OSError:
            pass
    try:
        os.remove(HK_INFO)
    except OSError:
        pass
    if _cfg().get("homekit") and _hk_installed():
        T["run"](["systemctl", "start", "raspi-tv-homekit"], 30)
    return homekit_status()


def hk_key(data):
    T["VINPUT"].key(str(data.get("key")))
    touch_activity()
    return {"ok": True}


def hk_power(data):
    touch_activity()
    if data.get("on"):
        try:
            cec_action({"action": "tv_on"})
        except Exception:  # noqa: BLE001
            pass
        _set_tv_power("on")
    else:
        T["tv_standby"]()
        _set_tv_power("standby")
    return {"ok": True}


def hk_input(data):
    try:
        ident = int(data.get("id"))
    except (TypeError, ValueError):
        raise _err("Ungültig")
    if ident not in HK_INPUTS:
        raise _err("Ungültig")
    touch_activity()
    request_nav(LAUNCHER + HK_INPUTS[ident])
    return {"ok": True}


GET_ROUTES["/api/homekit"] = homekit_status
POST_ROUTES["/api/homekit"] = homekit_set
POST_ROUTES["/api/homekit/reset"] = homekit_reset
POST_ROUTES["/api/hk/key"] = hk_key
POST_ROUTES["/api/hk/power"] = hk_power
POST_ROUTES["/api/hk/input"] = hk_input


# Benutzerprofile: nur persönliche Darstellung und Sender, keine Konten/Systemrechte.
PROFILE_KEYS = ("theme", "accent", "background", "wallpaper", "wallpaper_rotate", "motion", "corners", "home_layout",
                "home_sections", "ui_scale", "channel_order", "channel_hidden")
_profile_lock = threading.RLock()


def _profile_data(cfg):
    return json.loads(json.dumps({k: cfg[k] for k in PROFILE_KEYS if k in cfg}))


def _profile_init(cfg):
    if not cfg.get("profiles"):
        cfg["profiles"] = [{"id": "default", "name": "Standard", "settings": _profile_data(cfg)}]
        cfg["active_profile"] = "default"


def profiles_status():
    with _profile_lock:
        cfg = _cfg()
        _profile_init(cfg)
        return {"active": cfg["active_profile"],
                "profiles": [{"id": p["id"], "name": p["name"]} for p in cfg["profiles"]]}


def profiles_change(data):
    with _profile_lock:
        cfg = _cfg()
        _profile_init(cfg)
        profiles = cfg["profiles"]
        action = data.get("action")
        target = next((p for p in profiles if p["id"] == data.get("id")), None)
        if action in ("create", "rename"):
            name = str(data.get("name") or "").strip()
            if not name or len(name) > 24 or any(ord(c) < 32 for c in name):
                raise _err("Bitte einen Profilnamen mit 1 bis 24 Zeichen eingeben.")
            if any(p["name"].casefold() == name.casefold() and (action == "create" or p is not target) for p in profiles):
                raise _err("Dieser Profilname ist bereits vergeben.")
        if action == "create":
            if len(profiles) >= 8:
                raise _err("Es sind höchstens acht Profile möglich.")
            profiles.append({"id": secrets.token_hex(8), "name": name, "settings": _profile_data(cfg)})
        elif action == "rename" and target:
            target["name"] = name
        elif action == "switch" and target:
            current = next(p for p in profiles if p["id"] == cfg["active_profile"])
            current["settings"] = _profile_data(cfg)
            for key in PROFILE_KEYS:
                cfg.pop(key, None)
            cfg.update(target["settings"])
            cfg["active_profile"] = target["id"]
            _tvnow.update(name=None, at=0, favs=[])
        elif action == "delete" and target:
            if target["id"] == cfg["active_profile"]:
                raise _err("Bitte zuerst zu einem anderen Profil wechseln.")
            profiles.remove(target)
        else:
            raise _err("Ungültige Profilaktion.")
        _save(cfg)
        return profiles_status()


GET_ROUTES["/api/profiles"] = profiles_status
POST_ROUTES["/api/profiles"] = profiles_change


# Multimedia routes share the existing phone pairing and local API boundaries.
_media_lock = threading.RLock()
_media_module = None
_audio_meter = None
_mirror = None
_gamepad = None


def _load_media():
    global _media_module
    with _media_lock:
        if _media_module is None:
            import importlib.util
            spec = importlib.util.spec_from_file_location("raspitv_multimedia", os.path.join(os.path.dirname(__file__), "multimedia.py"))
            _media_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(_media_module)
        return _media_module


def audio_meter_status():
    global _audio_meter
    with _media_lock:
        if _audio_meter is None: _audio_meter = _load_media().AudioMeter(T)
    return _audio_meter.poll()


def mirror_request(data, viewer=False):
    global _mirror
    with _media_lock:
        if _mirror is None: _mirror = _load_media().Mirror(request_nav)
    try: return _mirror.request(data, viewer)
    except ValueError as e: raise _err(str(e))


def gamepad_request(data):
    global _gamepad
    with _media_lock:
        if _gamepad is None: _gamepad = _load_media().Gamepad()
    try: return _gamepad.request(data)
    except (ValueError, OSError) as e: raise _err(str(e), 503 if isinstance(e,OSError) else 400)


GET_ROUTES["/api/audio-meter"] = audio_meter_status
POST_ROUTES["/api/mirror"] = lambda d: mirror_request(d, True)
REMOTE_ROUTES_EXTRA["/r/mirror"] = mirror_request
REMOTE_ROUTES_EXTRA["/r/gamepad"] = gamepad_request


# A read-only state feed for optional round displays. No audio or volume changes.
_round_lock = threading.Lock()
_round_volume = {"at": 0, "volume": None, "muted": False, "target": "pi"}


def round_display_state():
    with _round_lock:
        cfg = _cfg()
        target = cfg.get("volume_target", "auto")
        if target == "auto": target = "soundbar" if _cec_cache.get("soundbar") else "pi"
        if target == "pi" and (time.monotonic()-_round_volume["at"] > 1 or _round_volume["target"] != target):
            _, out, _ = T["as_tv"](["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"], 2)
            match = re.search(r"Volume:\s*([0-9.]+)", out)
            _round_volume.update(at=time.monotonic(), target=target,
                volume=min(100,max(0,round(float(match.group(1))*100))) if match else None,
                muted="MUTED" in out)
        elif target != "pi":
            # CEC control without an audio-status reply does not reveal the TV's percentage.
            _round_volume.update(at=time.monotonic(),target=target,volume=None,muted=False)
        current = spotify_now()
        brightness = cfg.get("round_brightness", 100)
        return {"music": current, "volume": _round_volume["volume"], "muted": _round_volume["muted"],
                "target": target, "time": int(time.time()),
                "brightness": brightness if type(brightness) is int and 10 <= brightness <= 100 else 100,
                "palette": _round_palette(cfg), "intro": cfg.get("round_intro", True) is not False,
                "intro_seq": _round_intro["seq"], "version": _installed_version(),
                "motion": cfg.get("round_motion", "full"), "update": _round_update(cfg),
                "spi_hz": (cfg.get("round_speed") if cfg.get("round_speed") in (4, 8, 16, 32) else 4) * 1_000_000,
                "teensy_hz": (cfg.get("round_teensy_mhz") if cfg.get("round_teensy_mhz") in (15, 24, 30, 40, 60) else 30) * 1_000_000}


def _round_update(cfg):
    """Kurzfassung für die Update-Seite der runden Displays."""
    inst = _installed_version()
    latest = _online.get("latest")
    return {"installed": inst, "latest": latest,
            "newer": bool(latest and _ver_tuple(latest) > _ver_tuple(inst)),
            "checked": _online.get("checked") or 0, "error": bool(_online.get("error")),
            "auto": _update_auto(cfg), "online": bool(_update_url(cfg)),
            "running": bool(_swu.get("running")), "step": str(_swu.get("step") or "")[:40]}


# 6.0: Farben der runden Displays folgen dem Design (Hintergrundbild bzw. Akzentfarbe)
_ROUND_ACCENTS = {"blue": "#3d8bff", "violet": "#a78bfa", "teal": "#22d3ee", "green": "#34d399", "gold": "#fbbf24",
                  "orange": "#fb923c", "red": "#f87171", "pink": "#f472b6"}
_ROUND_THEMES = {"midnight": ("#0b0d12", "blue"), "oled": ("#000000", "blue"), "aurora": ("#060a13", "teal"),
                 "sunset": ("#120a0e", "orange"), "forest": ("#08100b", "green"), "cinema": ("#0c0909", "red"),
                 "light": ("#0b0d12", "blue"), "auto": ("#0b0d12", "blue")}
_round_walls = {"at": 0, "list": []}
_round_intro = {"seq": 0}


def _round_wallpapers():
    if time.monotonic() - _round_walls["at"] > 300 or not _round_walls["list"]:
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "launcher", "media", "wallpapers.json")
        _round_walls.update(at=time.monotonic(), list=_read_json(path, []) or [])
    return _round_walls["list"]


def _round_palette(cfg):
    if cfg.get("round_colors") == "classic":
        return {"accent": "#57dcc7", "bg": "#050b16", "source": "classic"}
    bg, theme_accent = _ROUND_THEMES.get(cfg.get("theme") or "midnight", _ROUND_THEMES["midnight"])
    accent = _ROUND_ACCENTS.get(cfg.get("accent") or "theme")
    if accent:
        return {"accent": accent, "bg": bg, "source": "accent"}
    background = cfg.get("background") or "wallpaper"
    walls = _round_wallpapers() if background == "wallpaper" else []
    if walls:
        if cfg.get("wallpaper_rotate"):
            day = int((time.time() - time.timezone) // 86400)
            wall = walls[day % len(walls)]
        else:
            wall = next((w for w in walls if w.get("id") == (cfg.get("wallpaper") or "aurora-nordlicht")), walls[0])
        if re.fullmatch(r"#[0-9a-fA-F]{6}", str(wall.get("accent", ""))):
            return {"accent": wall["accent"], "bg": bg, "source": "wallpaper"}
    return {"accent": _ROUND_ACCENTS[theme_accent], "bg": bg, "source": "theme"}


def round_intro_play(_data):
    _round_intro["seq"] += 1
    return {"ok": True}


GET_ROUTES["/api/round-display"] = round_display_state
POST_ROUTES["/api/round-display/intro"] = round_intro_play


# Protokoll der Hintergrund-Musik (Erweiterung → /var/log/raspi-tv/spotify-bg.log)
SPOTIFY_BG_LOG = "/var/log/raspi-tv/spotify-bg.log"


def spotify_bglog(query, headers):
    if headers.get("X-Raspi-TV") != "1":
        raise _err("forbidden", 403)
    try:
        e = json.loads((query.get("e") or ["{}"])[0])
    except ValueError:
        e = {}
    if not isinstance(e, dict):
        e = {}
    line = time.strftime("%Y-%m-%d %H:%M:%S ") + " ".join(
        f"{k}={str(v)[:120]}" for k, v in list(e.items())[:8]) + f" tv={T['tv_power']()}\n"
    try:
        os.makedirs(os.path.dirname(SPOTIFY_BG_LOG), exist_ok=True)
        if os.path.exists(SPOTIFY_BG_LOG) and os.path.getsize(SPOTIFY_BG_LOG) > 200_000:
            os.replace(SPOTIFY_BG_LOG, SPOTIFY_BG_LOG + ".1")
        with open(SPOTIFY_BG_LOG, "a") as f:
            f.write(line)
    except OSError:
        pass
    return {"ok": True}


QUERY_ROUTES["/api/spotify/bglog"] = spotify_bglog


# ==========================================================================
# Raspi-TV-Erweiterung im Browser überwachen
#   Die Erweiterung meldet sich alle 30 s mit ihrer Version. Läuft nach einem Update noch die
#   alte Version, zeigt der Status die Abweichung. Laufende Musik wird nicht neu gestartet.
#   Ohne Meldung weiß die Oberfläche, dass Hintergrund-Apps (Spotify) gerade nicht gehen.
# ==========================================================================
_ext = {"version": None, "at": 0, "restarted": 0}
EXT_MANIFEST = "/opt/raspi-tv/extension/manifest.json"


def _ext_disk_version():
    try:
        with open(EXT_MANIFEST) as f:
            return json.load(f).get("version")
    except (OSError, ValueError):
        return None


def ext_hello(query, headers):
    if headers.get("X-Raspi-TV") != "1":
        raise _err("forbidden", 403)
    _ext.update(version=str((query.get("v") or [""])[0])[:20] or None, at=time.time())
    return {"ok": True}


def ext_status():
    age = time.time() - _ext["at"] if _ext["at"] else None
    disk = _ext_disk_version()
    return {"version": _ext["version"], "disk_version": disk, "seen_ago": int(age) if age is not None else None,
            "ok": age is not None and age < 90 and (not disk or _ext["version"] == disk)}


QUERY_ROUTES["/api/ext/hello"] = ext_hello
GET_ROUTES["/api/ext"] = ext_status


# ==========================================================================
# Handy-App 1.6: Mini-Player (Spotify und Radio) – auch per Bluetooth
#   Zustand: Spotify meldet die Erweiterung (/api/spotify/webnow), Radio die Startseite.
#   Befehle holt die Erweiterung mit der Navigations-Abfrage ab (alle 0,7 s).
# ==========================================================================
_radio_now = {"now": None, "at": 0}
_web_media = {}
_web_media_lock = threading.Lock()


def media_webnow(query, headers):
    """Erweiterung: was in YouTube, Mediatheken, Netflix … gerade läuft."""
    if headers.get("X-Raspi-TV") != "1":
        raise _err("forbidden", 403)
    try:
        n = json.loads((query.get("d") or ["null"])[0])
    except ValueError:
        n = None
    if not isinstance(n, dict) or type(n.get("tab")) is not int or n["tab"] < 0:
        raise _err("Ungültige Medienmeldung")
    with _web_media_lock:
        cutoff = time.time() - 20
        for tab in list(_web_media):
            if _web_media[tab]["at"] < cutoff:
                del _web_media[tab]
        if n.get("title"):
            cover = str(n.get("cover") or "")
            _web_media[n["tab"]] = {"at": time.time(), "now": {
                "tab": n["tab"], "title": str(n["title"])[:120], "artist": str(n.get("artist") or "")[:80],
                "cover": cover if cover.startswith("https://") else "", "playing": bool(n.get("playing")),
                "site": str(n.get("site") or "")[:40]}}
            while len(_web_media) > 32:
                del _web_media[min(_web_media, key=lambda tab: _web_media[tab]["at"])]
        else:
            _web_media.pop(n["tab"], None)
    return {"ok": True}


QUERY_ROUTES["/api/media/webnow"] = media_webnow
_media_cmds = []
_media_cmd_lock = threading.Lock()


def radio_now_report(data):
    if data.get("name"):
        logo = str(data.get("logo") or "")
        _radio_now.update(at=time.time(), now={"title": str(data["name"])[:80],
                                               "artist": "Radio · " + (str(data.get("genre") or "")[:60] or "Live"),
                                               "cover": logo if logo.startswith(("https://", "http://", "/")) else "",
                                               "playing": data.get("state") in ("playing", "loading")})
    else:
        _radio_now.update(at=time.time(), now=None)
    return {"ok": True}


def _pi_volume():
    state = round_display_state()
    return {"level": state["volume"], "muted": state["muted"]} if state["target"] == "pi" else None


def remote_media(_data=None):
    """Was gerade läuft – zuerst, was tatsächlich spielt (Spotify, Video im Browser, Radio), sonst Pausiertes."""
    t = time.time()
    cands = []
    if _webnow["now"] and t - _webnow["at"] < 20:
        cands.append(("spotify", _webnow["now"]))
    with _web_media_lock:
        cands.extend(("web", report["now"]) for report in sorted(_web_media.values(), key=lambda r:r["at"], reverse=True)
                     if t - report["at"] < 20)
    if _radio_now["now"] and t - _radio_now["at"] < 600:
        cands.append(("radio", _radio_now["now"]))
    playing = [c for c in cands if c[1].get("playing")]
    src, now = (playing or cands or [(None, None)])[0]
    ext = ext_status()
    out = {"source": src, "volume": None, "target": _volume_target(), "ext_ok": ext["ok"]}
    if now and src == "web":
        out["site"] = now.get("site")
        out["tab"] = now["tab"]
    if now:
        cover = now.get("cover") or ""
        if cover.startswith("/"):
            cover = ""     # Senderlogos vom Pi kennt das Handy nicht über Bluetooth
        out.update(title=now.get("title"), artist=now.get("artist"), cover=cover, playing=bool(now.get("playing")))
    try:
        out["volume"] = _pi_volume()
    except Exception:  # noqa: BLE001
        pass
    return out


def remote_media_ctl(data):
    cmd = data.get("cmd")
    if cmd not in ("toggle", "next", "previous"):
        raise _err("Ungültig")
    st = remote_media()
    target = data.get("source") or st["source"] or "spotify"
    if target not in ("spotify", "radio", "web"):
        raise _err("Ungültig")
    if target == "web" and (st["source"] != "web" or "tab" not in st):
        raise _err("Das Video ist nicht mehr verfügbar.")
    with _media_cmd_lock:
        _media_cmds.append({"target": target, "cmd": cmd, "at": time.time(), "tab": st.get("tab")})
        del _media_cmds[:-5]
    touch_activity()
    return remote_media()


_nav_pending_media = nav_pending


def nav_pending(query, headers):  # noqa: F811
    out = _nav_pending_media(query, headers)
    now = time.time()
    with _media_cmd_lock:
        _media_cmds[:] = [c for c in _media_cmds if now - c["at"] < 10]
        if _media_cmds:
            c = _media_cmds.pop(0)
            out["media"] = {"target": c["target"], "cmd": c["cmd"]}
            if c["target"] == "web":
                out["media"]["tab"] = c["tab"]
    return out


QUERY_ROUTES["/api/nav/pending"] = nav_pending
POST_ROUTES["/api/radio/now"] = radio_now_report
REMOTE_ROUTES_EXTRA["/r/media"] = remote_media
REMOTE_ROUTES_EXTRA["/r/media/ctl"] = remote_media_ctl


# ==========================================================================
# „Teilen → Raspi-TV“ aus der Android-App: Link am Fernseher öffnen
# ==========================================================================
_URL_RE = re.compile(r"https?://[^\s<>\"']+")


def _open_target(text):
    """(Adresse, Beschreibung) für einen geteilten Text."""
    m = _URL_RE.search(text or "")
    if not m:
        q = (text or "").strip()[:100]
        if not q:
            raise _err("Nichts zum Öffnen")
        return SEARCH_TARGETS["youtube"](q), "YouTube-Suche"
    url = m.group(0).rstrip(".,;)!?")
    u = urlparse(url)
    host = (u.hostname or "").lower()
    if host in ("youtu.be",):
        vid = u.path.strip("/").split("/")[0]
        t = parse_qs(u.query).get("t", [""])[0]
        return f"https://www.youtube.com/watch?v={quote(vid)}" + (f"&t={quote(t)}" if t else ""), "YouTube"
    if host == "youtube.com" or host.endswith(".youtube.com"):
        if u.path.startswith("/shorts/"):
            return "https://www.youtube.com/watch?v=" + quote(u.path.split("/")[2]), "YouTube"
        return url.replace("://m.youtube.com", "://www.youtube.com"), "YouTube"
    if host == "open.spotify.com" or host == "spotify.link":
        return url, "Spotify"
    for name, part in (("Netflix", "netflix."), ("ARD Mediathek", "ardmediathek."), ("ZDF", "zdf."), ("ARTE", "arte."),
                       ("Twitch", "twitch."), ("Prime Video", "primevideo."), ("Disney+", "disneyplus.")):
        if part in host:
            return url, name
    return url, "Webseite"


def remote_open(data):
    url, what = _open_target(str(data.get("text") or data.get("url") or "")[:2000])
    touch_activity()
    if T["tv_power"]() == "standby":
        try:
            cec_action({"action": "tv_on"})
        except Exception:  # noqa: BLE001
            pass
    request_nav(url)
    return {"ok": True, "url": url, "what": what}


REMOTE_ROUTES_EXTRA["/r/open"] = remote_open


# ==========================================================================
# 6.3.1: Lautstärke-Schutz
#   Wird der Fernseher ausgeschaltet, verschwindet der HDMI-Tonausgang. PipeWire weicht dann auf
#   einen Ersatzausgang aus (oder setzt den HDMI-Ausgang beim Wiederkommen neu), der mit 100 %
#   startet. Ein solcher Sprung auf 100 %, den niemand ausgelöst hat, wird sofort auf den letzten
#   Wert zurückgesetzt; Anzeige (runde Displays, Handy-App) zeigt solange den gemerkten Wert.
# ==========================================================================
_vol_guard = {"saved": {}, "last": None, "user_at": 0.0, "dummy": False, "shown": None, "fixed": 0}


def _sink_now():
    _, info, _ = T["as_tv"](["wpctl", "inspect", "@DEFAULT_AUDIO_SINK@"], 5)
    name = re.search(r'node\.name = "([^"]*)"', info or "")
    desc = re.search(r'node\.description = "([^"]*)"', info or "")
    _, out, _ = T["as_tv"](["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"], 5)
    vol = re.search(r"Volume:\s*([0-9.]+)", out or "")
    return (name.group(1) if name else ""), (desc.group(1) if desc else ""), (float(vol.group(1)) if vol else None)


def _sink_is_dummy(name, desc):
    return not name or name.startswith("auto_null") or "dummy" in desc.lower()


def volume_guard_step(now=None):
    now = now or time.time()
    name, desc, vol = _sink_now()
    g = _vol_guard
    if vol is None:
        return
    if _sink_is_dummy(name, desc):
        g["dummy"] = True
        return
    saved = g["saved"].get(name)
    user = now - g["user_at"] < 15
    if (saved is not None and vol >= 0.99 and saved < 0.9 and not user):
        T["as_tv"](["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", f"{saved:.2f}"], 5)
        g["fixed"] += 1
        print(f"Lautstärke-Schutz: {name} sprang auf 100 % – zurück auf {round(saved * 100)} %", flush=True)
        vol = saved
    g["saved"][name] = vol
    g["last"], g["dummy"], g["shown"] = name, False, round(vol * 100)


def volume_guard_loop():
    while True:
        try:
            volume_guard_step()
        except Exception:  # noqa: BLE001
            pass
        time.sleep(2)


def _guard_mark_user():
    _vol_guard["user_at"] = time.time()


_old_volume_631 = volume


def volume(data):  # noqa: F811
    _guard_mark_user()
    r = _old_volume_631(data)
    _guard_mark_user()
    return r


POST_ROUTES["/api/volume"] = volume
_old_pi_volume_set_631 = _pi_volume_set


def _pi_volume_set(v):  # noqa: F811
    _guard_mark_user()
    _old_pi_volume_set_631(v)


_old_round_state_631 = round_display_state


def round_display_state():  # noqa: F811
    st = _old_round_state_631()
    # Ersatzausgang (Fernseher aus): letzten echten Wert zeigen statt 100 %
    if _vol_guard["dummy"] and _vol_guard["shown"] is not None and st.get("target") == "pi":
        st["volume"] = _vol_guard["shown"]
    return st


GET_ROUTES["/api/round-display"] = round_display_state
_old_start13 = start_background


def start_background():  # noqa: F811
    _old_start13()
    threading.Thread(target=volume_guard_loop, daemon=True).start()
REMOTE_ROUTES_EXTRA["/r/volume"] = volume


def _audio_set_marked(data):
    _guard_mark_user()
    return T["audio_set"](data)


POST_ROUTES["/api/audio"] = _audio_set_marked


# ==========================================================================
# 6.4: HDMI-Signal im Standby abschalten
#   Viele Fernseher (z. B. ältere Medion) nehmen den CEC-Aus-Befehl nicht an, gehen aber nach
#   einigen Minuten ohne Bildsignal selbst in Standby. Raspi-TV schaltet deshalb im Standby das
#   Bild (DPMS) ab. Jede Taste – Fernbedienung, Handy-App, iPhone – oder das Einschalten über
#   Raspi-TV bringt das Bild sofort zurück. Abschaltbar: Einstellungen · Energie.
# ==========================================================================
def _x(cmd):
    return T["as_tv"](["env", "DISPLAY=:0", f"XAUTHORITY=/home/{T['TV_USER']}/.Xauthority"] + cmd, 10)


_signal = {"off": False}


def hdmi_signal(on):
    _signal["off"] = not on
    if on:
        _x(["xset", "dpms", "force", "on"])
        _x(["xset", "-dpms"])            # keine automatische Bildabschaltung im Betrieb
    else:
        _x(["xset", "+dpms"])
        _x(["xset", "dpms", "0", "0", "0"])
        _x(["xset", "dpms", "force", "off"])


def _signal_off_wanted():
    return _cfg().get("standby_signal_off", True) is not False


def _install_signal_hooks():
    std0 = T["tv_standby"]

    def tv_standby_signal():
        r = std0()
        if _signal_off_wanted():
            # kurz warten, damit der CEC-Befehl (falls der Fernseher ihn doch kann) noch durchgeht
            threading.Timer(2, lambda: hdmi_signal(False)).start()
        return r

    T["tv_standby"] = tv_standby_signal


_old_set_tv_power_64 = _set_tv_power


def _set_tv_power(state):  # noqa: F811
    _old_set_tv_power_64(state)
    if state == "on":
        threading.Thread(target=hdmi_signal, args=(True,), daemon=True).start()


_old_cec_action_64 = cec_action


def cec_action(data):  # noqa: F811
    if data.get("action") == "tv_on":
        threading.Thread(target=hdmi_signal, args=(True,), daemon=True).start()
    elif data.get("action") == "tv_off" and _signal_off_wanted():
        try:
            r = _old_cec_action_64(data)
        except Exception:  # noqa: BLE001 – Fernseher ohne CEC-Aus: trotzdem Bild abschalten
            r = {"ok": True, "signal_off": True}
        _set_tv_power("standby")
        threading.Timer(2, lambda: hdmi_signal(False)).start()
        return r
    return _old_cec_action_64(data)


POST_ROUTES["/api/cec/action"] = cec_action
REMOTE_ROUTES_EXTRA["/r/cec"] = lambda d: cec_action(d) if d.get("action") in ("tv_on", "tv_off", "switch") else {"ok": False}
_old_start14 = start_background


def start_background():  # noqa: F811
    _install_signal_hooks()
    _old_start14()

def _activity_key(data=None):
    # Taste am Fernseher gedrückt, während das Bild aus ist: X schaltet das Bild selbst ein –
    # Zustand nachziehen. (Nur echte Tasten, nicht das Abfragen der Handy-App.)
    if _signal["off"]:
        _signal["off"] = False
        _set_tv_power("on")
    return touch_activity(data)


OPEN_POST_ROUTES["/api/activity"] = _activity_key


# ==========================================================================
# 6.4: Ein/Aus über HDMI-CEC für neue und ältere Fernseher
#   Mehrere Varianten nacheinander: direkt an den Fernseher, an alle Geräte (Broadcast), „Text View
#   On“ für ältere Geräte und „Active Source“ (manche Fernseher wachen nur damit auf). Fehlt der
#   Kernel-CEC-Anschluss (/dev/cec*), wird cec-client (libcec) versucht. Klappt Aus trotzdem nicht,
#   schaltet Raspi-TV das Bildsignal ab (siehe oben).
# ==========================================================================
def _cec_client(cmd):
    if not shutil.which("cec-client"):
        return False
    try:
        r = subprocess.run(["cec-client", "-s", "-d", "1"], input=cmd + "\n", capture_output=True, text=True, timeout=15)
        return r.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def _cec_try(variants):
    ok = False
    for args in variants:
        try:
            _cec(args, check=True)
            ok = True
        except Exception:  # noqa: BLE001
            continue
    return ok


def _cec_tv_on():
    if not _cec_dev():
        return _cec_client("on 0") and (_cec_client("as") or True)
    ok = _cec_try([["--to", "0", "--image-view-on"], ["--to", "0", "--text-view-on"]])
    try:
        pa = _phys_addr()
        if pa and pa != "f.f.f.f":
            _cec(["--to", "15", "--active-source", f"phys-addr={pa}"])
    except Exception:  # noqa: BLE001
        pass
    return ok


def _cec_tv_off():
    if not _cec_dev():
        return _cec_client("standby 0")
    return _cec_try([["--to", "0", "--standby"], ["--to", "15", "--standby"]])


_old_cec_action_64b = _old_cec_action_64


def _old_cec_action_64(data):  # noqa: F811 – Grundfunktion für den Bildsignal-Wrapper oben
    a = data.get("action")
    if a == "tv_on":
        if not _cec_tv_on():
            raise _err("Der Fernseher antwortet nicht. Ist HDMI-CEC am Fernseher eingeschaltet?")
        return {"ok": True}
    if a == "tv_off":
        ok = _cec_tv_off()
        _set_tv_power("standby")
        if not ok:
            raise _err("Der Fernseher nimmt den Aus-Befehl nicht an.")
        return {"ok": True}
    return _old_cec_action_64b(data)


def _install_cec_standby():
    def tv_standby_variants():
        try:
            _cec_tv_off()
        except Exception:  # noqa: BLE001
            pass
        return {"ok": True}
    T["tv_standby"] = tv_standby_variants


_old_start15 = start_background


def start_background():  # noqa: F811
    _install_cec_standby()      # zuerst: der Bildsignal-Haken (start14) baut darauf auf
    _old_start15()


# 7.0: Anschlussart der runden Displays (Teensy 4.1 per USB oder GPIO) für die Einstellungen
def round_hardware(_q=None, _h=None):
    st = _read_json("/var/lib/raspi-tv-round/teensy.json", {}) or {}
    if st.get("connected"):
        return {"mode": "teensy", "firmware": st.get("firmware", ""), "port": st.get("port", ""),
                "flashing": st.get("flashing", ""), "resets": st.get("resets", 0), "crash": st.get("crash", ""),
                "reset": st.get("reset", ""), "power": st.get("power")}
    scan = _read_json("/var/lib/raspi-tv-round/teensy-scan.json", {}) or {}
    return {"mode": "gpio" if os.path.exists("/var/lib/raspi-tv-round/enabled-separate-pins") else "none",
            "scan": {"halfkay": scan.get("halfkay", ""), "ports": scan.get("ports", []), "port": scan.get("port", ""),
                     "fresh": time.time() - scan.get("at", 0) < 30}}


GET_ROUTES["/api/round-displays/hardware"] = round_hardware


# ==========================================================================
# 7.0.2: Runde Displays zeigen alles, was gerade läuft – nicht nur Spotify Connect
#   Gleiche Quellen wie die Handy-App: Spotify (Connect/ncspot und Web-Player), Videos im Browser
#   (YouTube, Mediatheken …) und Radio. Vorher kam nur an, was die Startseite gerade meldete.
# ==========================================================================
_SITE_LABELS = {"youtube": "YOUTUBE", "netflix": "NETFLIX", "ard": "ARD", "zdf": "ZDF", "arte": "ARTE",
                "twitch": "TWITCH", "prime": "PRIME VIDEO", "disney": "DISNEY+", "spotify": "SPOTIFY"}


def _now_playing():
    t = time.time()
    cands = []
    sp = spotify_now()
    if sp.get("title") and (sp.get("playing") or sp.get("paused")):
        cands.append(("SPOTIFY", sp))
    if _webnow["now"] and t - _webnow["at"] < 20:
        cands.append(("SPOTIFY", _webnow["now"]))
    with _web_media_lock:
        for report in sorted(_web_media.values(), key=lambda r: r["at"], reverse=True):
            if t - report["at"] < 20:
                site = str(report["now"].get("site") or "").lower()
                label = next((v for k, v in _SITE_LABELS.items() if k in site), (site.upper()[:14] or "VIDEO"))
                cands.append((label, report["now"]))
    if _radio_now["now"] and t - _radio_now["at"] < 600:
        cands.append(("RADIO", _radio_now["now"]))
    playing = [c for c in cands if c[1].get("playing")]
    label, now = (playing or cands or [(None, None)])[0]
    if not now:
        return {"playing": False}
    cover = str(now.get("cover") or "")
    if cover.startswith("/"):
        cover = "http://127.0.0.1:8765" + cover     # Senderlogo vom Pi selbst
    return {"playing": bool(now.get("playing")), "paused": not now.get("playing"),
            "title": str(now.get("title") or "")[:120], "artist": str(now.get("artist") or "")[:120],
            "cover": cover, "source": label}


_old_round_state_702 = round_display_state


def round_display_state():  # noqa: F811
    st = _old_round_state_702()
    try:
        st["music"] = _now_playing()
    except Exception:  # noqa: BLE001
        pass
    try:
        st["tv"] = T["tv_power"]()      # 'standby' → Nachtmodus auf den runden Displays
    except Exception:  # noqa: BLE001
        pass
    return st


GET_ROUTES["/api/round-display"] = round_display_state


def round_teensy_flash(_data=None):
    """Einstellungen: Teensy-Firmware erneut einspielen (der Display-Dienst übernimmt das)."""
    os.makedirs("/var/lib/raspi-tv-round", exist_ok=True)
    with open("/var/lib/raspi-tv-round/teensy-force-flash", "w") as f:
        f.write(str(int(time.time())))
    T["run"](["systemctl", "restart", "raspi-tv-round.service"], 15)
    return {"ok": True}


POST_ROUTES["/api/round-displays/teensy-flash"] = round_teensy_flash


# ==========================================================================
# 7.1.4: Updates schneller erkennen
#   Statt alle 6 Stunden das ganze Paket zu laden, liest Raspi-TV alle 10 Minuten nur die kleine
#   Datei version.json neben dem Paket. Bei GitHub über die API – die liefert neue Versionen sofort
#   (raw.githubusercontent.com hält alte Dateien bis zu 5 Minuten im Zwischenspeicher).
#   Das Paket selbst wird erst beim Installieren geladen.
# ==========================================================================
_GH_RAW = re.compile(r"^https://raw\.githubusercontent\.com/([^/]+)/([^/]+)/([^/]+)/(.+)$")


def _gh_api(url):
    m = _GH_RAW.match(url)
    if not m:
        return None
    owner, repo, ref, path = m.groups()
    return f"https://api.github.com/repos/{owner}/{repo}/contents/{path}?ref={ref}"


def _fetch(url, limit, timeout, raw_api=False):
    headers = {"User-Agent": "Raspi-TV/1.0", "Cache-Control": "no-cache"}
    if raw_api:
        headers["Accept"] = "application/vnd.github.raw"
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise RuntimeError("Datei zu groß")
    return data


def _quick_latest(url):
    """Version aus version.json neben dem Paket (None, wenn es keine gibt)."""
    side = url.rsplit("/", 1)[0] + "/version.json"
    for candidate, api in ((_gh_api(side), True), (side, False)):
        if not candidate:
            continue
        try:
            info = json.loads(_fetch(candidate, 4096, 15, api))
            ver = str(info.get("version", "")).strip()
            if re.fullmatch(r"[0-9][0-9.]{0,18}", ver):
                return ver
        except Exception:  # noqa: BLE001
            continue
    return None


def _online_fetch():  # noqa: F811 – Paket laden (bei GitHub über die API, immer die neueste Fassung)
    url = _update_url(_cfg())
    if not url:
        raise RuntimeError("Keine Update-Adresse eingetragen.")
    api = _gh_api(url)
    try:
        data = _fetch(api, 80_000_000, 300, True) if api else _download(url, limit=80_000_000, timeout=180)
    except Exception:  # noqa: BLE001 – API nicht erreichbar/Limit: normaler Download
        data = _download(url, limit=80_000_000, timeout=180)
    os.makedirs(os.path.dirname(ONLINE_ZIP), exist_ok=True)
    with open(ONLINE_ZIP + ".tmp", "wb") as f:
        f.write(data)
    os.replace(ONLINE_ZIP + ".tmp", ONLINE_ZIP)
    with zipfile.ZipFile(ONLINE_ZIP) as zf:
        names = _zip_names(zf)
        root = _zip_root([n for _, n in names])
        if root is None:
            raise RuntimeError("Unter der Adresse liegt kein Raspi-TV-Update-Paket.")
        ver = next((zf.read(i).decode("utf-8", "replace").strip()[:20] for i, n in names if n == root + "VERSION"), None)
    if not ver:
        raise RuntimeError("Update-Paket ohne Versionsnummer.")
    _online["zip_version"] = ver
    return ver


def online_check(_data=None):  # noqa: F811
    if _online["busy"]:
        return online_status()
    _online["busy"] = True
    try:
        url = _update_url(_cfg())
        quick = _quick_latest(url) if url else None
        _online.update(latest=quick or _online_fetch(), error=None)
    except zipfile.BadZipFile:
        _online.update(latest=None, error="Unter der Adresse liegt keine Zip-Datei.")
    except Exception as e:  # noqa: BLE001
        _online.update(latest=None, error=str(e) if isinstance(e, RuntimeError) else "Update-Adresse nicht erreichbar.")
    finally:
        _online.update(busy=False, checked=time.time())
    return online_status()


def online_install(_data=None):  # noqa: F811
    if _swu["running"]:
        return online_status()
    st = online_check()
    if not st["latest"]:
        raise _err(st["error"] or "Kein Update gefunden.")
    if not st["newer"]:
        raise _err(f"Raspi-TV ist aktuell (Version {st['installed']}).")
    try:
        ver = _online_fetch()           # jetzt erst das Paket laden
    except Exception as e:  # noqa: BLE001
        raise _err(str(e) if isinstance(e, RuntimeError) else "Update-Paket konnte nicht geladen werden.")
    if _ver_tuple(ver) <= _ver_tuple(_installed_version()):
        raise _err("Das Update-Paket ist noch nicht verfügbar – bitte in ein paar Minuten noch einmal versuchen.")
    _swu.update(running=True, done=False, error=None, step="Wird vorbereitet", version=ver)
    threading.Thread(target=_swupdate_worker, args=(ONLINE_ZIP,), daemon=True).start()
    return online_status()


def online_loop():  # noqa: F811
    """Alle 10 Minuten nachsehen (kleine Datei), installiert auf Wunsch nachts zwischen 3 und 5 Uhr."""
    time.sleep(45)
    while True:
        try:
            cfg = _cfg()
            if _update_url(cfg) and time.time() - _online["checked"] > 600:
                online_check()
            h = datetime.now().hour
            if (_update_auto(cfg) and 3 <= h < 5 and _online["latest"] and not _swu["running"]
                    and _ver_tuple(_online["latest"]) > _ver_tuple(_installed_version())
                    and T["tv_power"]() != "on"):
                online_install()
        except Exception:  # noqa: BLE001
            pass
        time.sleep(60)


POST_ROUTES["/api/online-update/check"] = online_check
POST_ROUTES["/api/online-update/install"] = online_install


# ==========================================================================
# 7.1.6: Die Handy-App aktualisiert sich über Raspi-TV (auch nur per Bluetooth)
#   /r/app-info   → Version der mitgelieferten App (launcher/raspi-tv-remote.apk.json) und Prüfsummen
#   /r/app-chunk  → Stück der App bzw. der Oberfläche (remote.html) als Base64, höchstens 3 KB
#   Neue Oberfläche: die App übernimmt sie sofort; neue App: Android fragt einmal „Installieren?“
# ==========================================================================
_APP_FILES = {"apk": "raspi-tv-remote.apk", "ui": "remote.html"}
_app_cache = {}


def _app_file(what):
    name = _APP_FILES.get(str(what))
    if not name:
        raise _err("Unbekannte Datei", 404)
    full = os.path.join(T["ROOT"], name)
    mtime = os.path.getmtime(full)
    hit = _app_cache.get(name)
    if not hit or hit[0] != mtime:
        with open(full, "rb") as f:
            raw = f.read()
        hit = (mtime, raw, hashlib.sha256(raw).hexdigest())
        _app_cache[name] = hit
    return hit[1], hit[2]


def remote_app_info(_data=None):
    meta = _read_json(os.path.join(T["ROOT"], "raspi-tv-remote.apk.json"), {}) or {}
    out = {"code": int(meta.get("code") or 0), "name": str(meta.get("name") or "")}
    for what in _APP_FILES:
        try:
            raw, sha = _app_file(what)
            out[what] = {"size": len(raw), "sha256": sha}
        except OSError:
            pass
    return out


def remote_app_chunk(data):
    import base64
    raw, sha = _app_file(data.get("what"))
    try:
        off = max(0, int(data.get("off", 0)))
        # App 1.10+ advances by the actual decoded length. Small complete lines
        # leave room for heartbeats on slow RFCOMM links (1.11 watchdog: 13 s).
        size = min(3072, max(1, int(data.get("len", 3072))))
    except (TypeError, ValueError):
        raise _err("Ungültiger Bereich")
    return {"off": off, "total": len(raw), "sha256": sha, "b64": base64.b64encode(raw[off:off + size]).decode()}


REMOTE_ROUTES_EXTRA["/r/app-info"] = remote_app_info
REMOTE_ROUTES_EXTRA["/r/app-chunk"] = remote_app_chunk


# ==========================================================================
# 7.2.0: Uhren und VU-Meter auf den runden Displays, Nachtlautstärke, sanftes Ausblenden,
#        Rückmeldung bei Musikbefehlen, Schnellaktionen, Prüfung nach Updates
# ==========================================================================
_round_state_72 = round_display_state


def round_display_state():  # noqa: F811
    st = _round_state_72()
    cfg = _cfg()
    st["clock"] = cfg.get("round_clock") if cfg.get("round_clock") in (0, 1, 2, 3) else 0
    st["vu"] = cfg.get("round_vu") if cfg.get("round_vu") in (0, 1, 2) else 0
    return st


GET_ROUTES["/api/round-display"] = round_display_state


# ---- Nachtlautstärke: zwischen zwei Uhrzeiten wird der Ton des Pi auf einen Höchstwert begrenzt
def _night_cfg():
    n = _cfg().get("night_volume") or {}
    return {"on": bool(n.get("on")), "from": n.get("from", "22:00"), "to": n.get("to", "07:00"),
            "max": n.get("max", 30) if type(n.get("max", 30)) is int else 30}


def night_active(now=None, cfg=None):
    n = cfg or _night_cfg()
    if not n["on"]:
        return False
    t = time.localtime(now or time.time())
    cur = t.tm_hour * 60 + t.tm_min
    a, b = (int(x[:2]) * 60 + int(x[3:]) for x in (n["from"], n["to"]))
    return a <= cur < b if a < b else (cur >= a or cur < b) if a != b else False


def night_volume_step():
    n = _night_cfg()
    if not night_active(cfg=n) or _volume_target() != "pi" or _fade["active"]:
        return False
    vol = _pi_volume_get()
    if vol > n["max"]:
        _pi_volume_set(n["max"])
        return True
    return False


# ---- Schlaf-Timer: in der letzten Minute wird die Musik langsam leiser (danach wieder wie vorher)
_fade = {"active": False, "start": None}


def _fade_volume(left, start, span=60):
    """Lautstärke für „left“ Sekunden vor dem Ausschalten: von start sanft auf 10 % davon."""
    k = max(0.0, min(1.0, left / span))
    return max(1, round(start * (0.1 + 0.9 * k * k * (3 - 2 * k))))


def sleep_loop():  # noqa: F811 – ersetzt die 10-Sekunden-Schleife (wird beim Start über den Namen gestartet)
    tick = 0
    while True:
        time.sleep(1)
        tick += 1
        try:
            until = _sleep["until"]
            left = until - time.time() if until else None
            fade = _cfg().get("sleep_fade", True) is not False and _volume_target() == "pi"
            if left is not None and 0 < left <= 60 and fade:
                if not _fade["active"]:
                    _fade.update(active=True, start=_pi_volume_get())
                _pi_volume_set(_fade_volume(left, _fade["start"]))
            elif _fade["active"] and left is None:
                # Timer wurde abgebrochen: Lautstärke zurück
                _pi_volume_set(_fade["start"])
                _fade.update(active=False, start=None)
            if until and time.time() >= until:
                _sleep["until"] = 0
                T["tv_standby"]()
                _set_tv_power("standby")
                touch_activity()
                if _fade["active"]:
                    time.sleep(4)                    # erst nach dem Ausschalten wieder auf den alten Wert
                    _pi_volume_set(_fade["start"])
                    _fade.update(active=False, start=None)
            if tick % 5 == 0:
                night_volume_step()
        except Exception:  # noqa: BLE001 – Hintergrundschleife darf nie sterben
            pass


def night_status():
    n = _night_cfg()
    n["active"] = night_active(cfg=n)
    n["fade"] = _cfg().get("sleep_fade", True) is not False
    return n


GET_ROUTES["/api/night-volume"] = night_status


# ---- Rückmeldung bei Musikbefehlen: erst „ok“, wenn der Fernseher den Befehl wirklich abgeholt hat
_media_ctl_72 = remote_media_ctl
_nav_pending_72 = nav_pending
_nav_seen = {"at": 0.0}


def nav_pending(query, headers):  # noqa: F811
    _nav_seen["at"] = time.time()
    return _nav_pending_72(query, headers)


QUERY_ROUTES["/api/nav/pending"] = nav_pending


def _media_cmd_waiting(stamp):
    with _media_cmd_lock:
        return any(c["at"] == stamp for c in _media_cmds)


def remote_media_ctl(data):  # noqa: F811
    cmd = data.get("cmd")
    before = remote_media()
    if time.time() - _nav_seen["at"] > 20:
        raise _err("Der Browser am Fernseher antwortet nicht – läuft Raspi-TV gerade (kein Standby, keine andere App im Vollbild)?", 503)
    out = _media_ctl_72(data)
    with _media_cmd_lock:
        stamp = _media_cmds[-1]["at"] if _media_cmds else None
    end = time.time() + 2.5
    while stamp and _media_cmd_waiting(stamp) and time.time() < end:
        time.sleep(0.1)
    if stamp and _media_cmd_waiting(stamp):
        with _media_cmd_lock:
            _media_cmds[:] = [c for c in _media_cmds if c["at"] != stamp]
        raise _err("Der Fernseher hat den Befehl nicht abgeholt. Bitte noch einmal versuchen.", 503)
    src = out.get("source") or before.get("source")
    if cmd == "next" and src in ("spotify", "radio") and before.get("title"):
        # „Weiter“ gilt erst als ausgeführt, wenn wirklich ein anderer Titel läuft
        end = time.time() + 3.0
        while time.time() < end:
            now = remote_media()
            if now.get("title") != before.get("title") or now.get("artist") != before.get("artist"):
                return now
            time.sleep(0.2)
        raise _err("Spotify hat nicht weitergeschaltet – letzter Titel der Liste, Werbung oder kein Premium?" if src == "spotify"
                   else "Der Sender hat nicht gewechselt.", 409)
    return remote_media()


REMOTE_ROUTES_EXTRA["/r/media/ctl"] = remote_media_ctl
if "REMOTE_ROUTES" in T:
    T["REMOTE_ROUTES"]["/r/media/ctl"] = remote_media_ctl


# ---- Schnellaktionen („Musikabend“): mehrere Schritte auf einen Knopf im Schnellmenü
QUICK_STEPS = {
    "app": lambda v: isinstance(v, str) and re.fullmatch(r"[a-z0-9_-]{1,40}", v) is not None,
    "radio": lambda v: isinstance(v, str) and len(v) <= 80,
    "volume": lambda v: type(v) is int and 0 <= v <= 100,
    "saver": lambda v: isinstance(v, str) and re.fullmatch(r"[a-z0-9-]{0,48}", v) is not None,
    "sleep": lambda v: type(v) is int and v in (15, 30, 60, 90, 120),
    "wallpaper": lambda v: isinstance(v, str) and re.fullmatch(r"[a-z0-9-]{1,48}", v) is not None,
}


def quick_actions_valid(v):
    if not isinstance(v, list) or len(v) > 8:
        return False
    for a in v:
        if not isinstance(a, dict) or set(a) - {"name", "steps"}:
            return False
        name, steps = a.get("name"), a.get("steps")
        if not isinstance(name, str) or not 1 <= len(name.strip()) <= 24 or not isinstance(steps, list) or len(steps) > 6:
            return False
        for s in steps:
            if not isinstance(s, dict) or set(s) != {"type", "value"} or s["type"] not in QUICK_STEPS \
                    or not QUICK_STEPS[s["type"]](s["value"]):
                return False
    return True


def quick_volume(data):
    """Lautstärke direkt setzen (Schritt einer Schnellaktion) – nur für den Ton des Pi."""
    try:
        v = max(0, min(100, int(data.get("volume"))))
    except (TypeError, ValueError):
        raise _err("Ungültige Lautstärke")
    if _volume_target() != "pi":
        raise _err("Die Lautstärke regelt der Fernseher – sie lässt sich nicht fest einstellen.", 409)
    n = _night_cfg()
    if night_active(cfg=n):
        v = min(v, n["max"])
    _pi_volume_set(v)
    _vol_guard["user_at"] = time.time()
    return {"volume": v}


POST_ROUTES["/api/quick/volume"] = quick_volume


# ---- Prüfung nach Updates: läuft nach dem ersten Start einer neuen Version wirklich alles?
UPDATE_CHECK_FILE = "update-check.json"


def update_check_run(wait=150, sleep=time.sleep):
    ver = _installed_version()
    rec = _read_json(_state(UPDATE_CHECK_FILE), {}) or {}
    if rec.get("version") == ver:
        return rec
    sleep(wait)
    problems = []
    if time.time() - _nav_seen["at"] > 30:
        problems.append("Die Oberfläche am Fernseher meldet sich nicht (Browser nicht gestartet oder eingefroren).")
    else:
        ext = ext_status()
        if not ext["ok"]:
            problems.append("Die Browser-Steuerung (Raspi-TV-Erweiterung) antwortet nicht – Home-Taste, Handy-Befehle "
                            "und Bildschirmtastatur gehen dann nicht."
                            + (f" Geladen ist Version {ext['version']}, erwartet wird {ext['disk_version']}."
                               if ext.get("version") and ext.get("disk_version") and ext["version"] != ext["disk_version"] else ""))
    try:
        hw = round_hardware()
        bundled = T["read_file"]("/opt/raspi-tv/teensy/version").strip()
        if hw.get("mode") == "teensy" and hw.get("firmware") and bundled \
                and _ver_tuple(hw["firmware"]) < _ver_tuple(bundled):
            problems.append(f"Der Teensy hat noch Firmware {hw['firmware']} statt {bundled} – das Einspielen hat nicht geklappt.")
    except Exception:  # noqa: BLE001
        pass
    if not _btr["listening"] and _btr["error"]:
        problems.append("Der Bluetooth-Empfang für die Handy-App ist nicht bereit: " + _btr["error"])
    rec = {"version": ver, "previous": rec.get("version", ""), "at": int(time.time()),
           "problems": problems, "seen": not problems}
    _write_json(_state(UPDATE_CHECK_FILE), rec)
    print("Prüfung nach Update auf", ver + ":", "; ".join(problems) or "alles in Ordnung", flush=True)
    return rec


def update_check_status():
    rec = _read_json(_state(UPDATE_CHECK_FILE), {}) or {}
    return {"version": rec.get("version", ""), "previous": rec.get("previous", ""), "at": rec.get("at", 0),
            "problems": rec.get("problems", []), "seen": bool(rec.get("seen", True))}


def update_check_ack(_data=None):
    rec = _read_json(_state(UPDATE_CHECK_FILE), {}) or {}
    rec["seen"] = True
    _write_json(_state(UPDATE_CHECK_FILE), rec)
    return update_check_status()


GET_ROUTES["/api/update-check"] = update_check_status
POST_ROUTES["/api/update-check/ack"] = update_check_ack
_old_start16 = start_background


def start_background():  # noqa: F811
    _old_start16()

    def run():
        try:
            update_check_run()
        except Exception as e:  # noqa: BLE001
            print("Prüfung nach Update:", e, flush=True)
    threading.Thread(target=run, daemon=True).start()
