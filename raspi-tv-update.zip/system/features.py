#!/usr/bin/env python3
"""Raspi-TV OS – Zusatzfunktionen des Systemdienstes.

  * Programmführer (EPG) aus frei verfügbaren XMLTV-Daten
  * Erinnerungen an Sendungen
  * Senderverwaltung (Reihenfolge, ausblenden, eigene M3U-Liste)
  * Eigene Medien von USB-Sticks und Netzwerkfreigaben (SMB) mit Vorschaubildern
  * Bildeinstellungen (Auflösung, Oberflächengröße)

Wird von tvctl.py geladen; tvctl übergibt mit bind() seine Hilfsfunktionen.
"""
import calendar
import glob
import gzip
import hashlib
import hmac
import secrets
import json
import queue
import mimetypes
import os
import re
import shutil
import socket
import tempfile
import threading
import time
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime
from urllib.parse import parse_qs, quote, urlparse

T = {}  # Namensraum von tvctl (live, damit Tests Werte austauschen können)


def bind(ns):
    global T
    T = ns


def _err(msg, code=400):
    return T["ApiError"](msg, code)


def _state(*parts):
    return os.path.join(T["STATE_DIR"], *parts)


def _cfg():
    return T["load_config"]()


def _save(cfg):
    T["save_config"](cfg)


def _write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, ensure_ascii=False)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def _read_json(path, default):
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def _download(url, limit=80_000_000, timeout=60):
    req = urllib.request.Request(url, headers={"User-Agent": "Raspi-TV/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise _err("Datei zu groß")
    return data


# ==========================================================================
# Die eigentlichen Funktionen liegen nach Bereichen getrennt in features.d/ (Sender, Medien,
# Updates, Bluetooth, runde Displays …). Sie werden hier der Reihe nach (Dateiname) in diesen
# Namensraum geladen – genau so, als stünden sie in dieser Datei. Fehlermeldungen nennen die Teildatei.
# ==========================================================================
def _load_parts():
    folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), "features.d")
    for name in sorted(os.listdir(folder)):
        if name.endswith(".py") and name[:1].isdigit():
            path = os.path.join(folder, name)
            with open(path, encoding="utf-8") as f:
                exec(compile(f.read(), path, "exec"), globals())


_load_parts()
