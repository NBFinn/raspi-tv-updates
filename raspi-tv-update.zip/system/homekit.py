#!/usr/bin/env python3
"""Raspi-TV OS – iPhone-Fernbedienung über HomeKit.

Meldet den Pi im Netz als HomeKit-Fernseher „Raspi-TV“. Nach dem Hinzufügen in der Home-App
erscheint er in der Apple-TV-Fernbedienung im Kontrollzentrum des iPhones:
Wischen/Pfeile, Auswählen, Zurück, Play/Pause, Info, Lautstärke (Tasten am iPhone),
Ein/Aus und Eingänge (Startseite, Live-TV, TV-Programm, Radio).

Läuft als eigener Dienst (raspi-tv-homekit.service) und schickt alles an tvctl (Port 8765).
Die Bibliothek HAP-python wird bei Bedarf nach /var/lib/raspi-tv/pylib geladen.
"""
import json
import logging
import os
import random
import signal
import socket
import sys
import threading
import urllib.request

STATE_DIR = os.environ.get("RASPI_TV_STATE", "/var/lib/raspi-tv")
sys.path.insert(0, os.path.join(STATE_DIR, "pylib"))

from pyhap.accessory import Accessory  # noqa: E402
from pyhap.accessory_driver import AccessoryDriver  # noqa: E402
from pyhap.const import CATEGORY_TELEVISION  # noqa: E402

API = os.environ.get("RASPI_TV_API", "http://127.0.0.1:8765")
PERSIST = os.path.join(STATE_DIR, "homekit.state")
CODEFILE = os.path.join(STATE_DIR, "homekit-code.json")
INFO = os.environ.get("RASPI_TV_HK_INFO", "/run/raspi-tv/homekit.json")
PORT = 51826

logging.basicConfig(level=logging.WARNING, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("raspi-tv-homekit")

# HomeKit-Fernbedienungstasten → Tasten von Raspi-TV
REMOTE_KEYS = {0: "left", 1: "right", 2: "chup", 3: "chdown", 4: "up", 5: "down", 6: "left", 7: "right",
               8: "ok", 9: "back", 10: "home", 11: "playpause", 15: "info"}
INPUTS = [  # (Kennung, Name, HomeKit-Eingangstyp)
    (1, "Startseite", 1), (2, "Live-TV", 2), (3, "TV-Programm", 2), (4, "Radio", 10), (5, "Eigene Medien", 9)]


def api(path, data=None):
    req = urllib.request.Request(API + path, data=json.dumps(data or {}).encode() if data is not None else None,
                                 headers={"X-Raspi-TV": "1", "Content-Type": "application/json", "Host": "127.0.0.1:8765"})
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return json.loads(r.read() or b"{}")
    except Exception as e:  # noqa: BLE001
        log.warning("API %s: %s", path, e)
        return None


def _pin_ok(pin):
    d = pin.replace("-", "")
    bad = {"00000000", "11111111", "22222222", "33333333", "44444444", "55555555", "66666666", "77777777",
           "88888888", "99999999", "12345678", "87654321"}
    return len(d) == 8 and d not in bad


def load_code():
    """Kopplungscode und Setup-ID bleiben gleich, bis die Kopplung zurückgesetzt wird."""
    try:
        with open(CODEFILE) as f:
            c = json.load(f)
        if _pin_ok(c["pin"]) and len(c["setup_id"]) == 4:
            return c
    except (OSError, ValueError, KeyError):
        pass
    while True:
        d = "%08d" % random.randrange(10 ** 8)
        pin = f"{d[:3]}-{d[3:5]}-{d[5:]}"
        if _pin_ok(pin):
            break
    c = {"pin": pin, "setup_id": "".join(random.choice("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789") for _ in range(4))}
    os.makedirs(STATE_DIR, exist_ok=True)
    with open(CODEFILE, "w") as f:
        json.dump(c, f)
    return c


def setup_uri(pin, setup_id, category=CATEGORY_TELEVISION):
    """X-HM://-Adresse für den QR-Code der Home-App (wie HAP-python, aber ohne Zusatzpaket)."""
    payload = 0
    payload = (payload << 4)                       # Version 0, reservierte Bits
    payload = (payload << 8) | (category & 0xFF)
    payload = (payload << 4) | 2                   # Kopplung über IP
    payload = (payload << 27) | (int(pin.replace("-", "")) & 0x7FFFFFF)
    digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    out = ""
    while payload:
        payload, r = divmod(payload, 36)
        out = digits[r] + out
    return "X-HM://" + out.rjust(9, "0") + setup_id


def local_addresses():
    addrs = []
    try:
        import subprocess
        out = subprocess.run(["hostname", "-I"], capture_output=True, text=True, timeout=5).stdout
        addrs = [a for a in out.split() if "." in a and not a.startswith("127.")]
    except Exception:  # noqa: BLE001
        pass
    if not addrs:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("10.255.255.255", 1))
            addrs = [s.getsockname()[0]]
        except OSError:
            addrs = ["127.0.0.1"]
        finally:
            s.close()
    return addrs


class RaspiTV(Accessory):
    category = CATEGORY_TELEVISION

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.set_info_service(manufacturer="Raspi-TV OS", model="Raspberry Pi", serial_number="RASPITV-1",
                              firmware_revision=_version())
        tv = self.add_preload_service("Television", ["ConfiguredName", "Active", "ActiveIdentifier",
                                                     "RemoteKey", "SleepDiscoveryMode", "PowerModeSelection"])
        self.set_primary_service(tv)
        self.tv_active = tv.configure_char("Active", value=1, setter_callback=self._set_active)
        self.tv_input = tv.configure_char("ActiveIdentifier", value=1, setter_callback=self._set_input)
        tv.configure_char("ConfiguredName", value="Raspi-TV")
        tv.configure_char("SleepDiscoveryMode", value=1)
        tv.configure_char("RemoteKey", setter_callback=self._remote_key)
        tv.configure_char("PowerModeSelection", setter_callback=lambda v: api("/api/hk/input", {"id": 0}))
        for ident, name, kind in INPUTS:
            src = self.add_preload_service("InputSource", ["Name", "ConfiguredName", "InputSourceType", "IsConfigured",
                                                          "CurrentVisibilityState", "Identifier"], unique_id=name)
            src.configure_char("Name", value=name)
            src.configure_char("ConfiguredName", value=name)
            src.configure_char("InputSourceType", value=kind)
            src.configure_char("IsConfigured", value=1)
            src.configure_char("CurrentVisibilityState", value=0)
            src.configure_char("Identifier", value=ident)
            tv.add_linked_service(src)
        sp = self.add_preload_service("TelevisionSpeaker", ["Mute", "Active", "VolumeControlType", "VolumeSelector"])
        sp.configure_char("Active", value=1)
        sp.configure_char("VolumeControlType", value=1)
        sp.configure_char("Mute", value=False, setter_callback=lambda v: api("/api/volume", {"action": "mute"}))
        sp.configure_char("VolumeSelector", setter_callback=self._volume)
        tv.add_linked_service(sp)

    def _remote_key(self, value):
        key = REMOTE_KEYS.get(int(value))
        if key:
            threading.Thread(target=api, args=("/api/hk/key", {"key": key}), daemon=True).start()

    def _volume(self, value):
        threading.Thread(target=api, args=("/api/volume", {"action": "up" if int(value) == 0 else "down"}),
                         daemon=True).start()

    def _set_active(self, value):
        threading.Thread(target=api, args=("/api/hk/power", {"on": bool(value)}), daemon=True).start()

    def _set_input(self, value):
        threading.Thread(target=api, args=("/api/hk/input", {"id": int(value)}), daemon=True).start()

    @Accessory.run_at_interval(5)
    async def run(self):
        """Ein/Aus-Zustand vom Pi übernehmen und Kopplungsstatus für die Einstellungen schreiben."""
        # neue IP-Adresse (z. B. WLAN gewechselt) → Dienst neu starten, damit das iPhone ihn wiederfindet
        now_addrs = await self.driver.loop.run_in_executor(None, local_addresses)
        if sorted(now_addrs) != sorted(_CODE.get("addrs", now_addrs)):
            log.warning("Adressen geändert (%s → %s) – Neustart", _CODE.get("addrs"), now_addrs)
            os._exit(3)
        st = await self.driver.loop.run_in_executor(None, api, "/api/status")
        if st:
            on = 0 if st.get("tv") == "standby" else 1
            if self.tv_active.value != on:
                self.tv_active.set_value(on)
        write_info(self.driver)


_CODE = {}


def write_info(driver):
    try:
        os.makedirs(os.path.dirname(INFO), exist_ok=True)
        tmp = INFO + ".tmp"
        with open(tmp, "w") as f:
            json.dump({"pin": _CODE["pin"], "uri": setup_uri(_CODE["pin"], _CODE["setup_id"]),
                       "paired": driver.state.paired, "clients": len(driver.state.paired_clients),
                       "addresses": local_addresses(), "pid": os.getpid()}, f)
        os.replace(tmp, INFO)
    except OSError:
        pass


def _version():
    try:
        with open("/opt/raspi-tv/VERSION") as f:
            return f.read().strip().split("-")[0] or "1.0"
    except OSError:
        return "1.0"


def main():
    _CODE.update(load_code())
    addrs = local_addresses()
    _CODE["addrs"] = addrs
    from zeroconf import InterfaceChoice
    driver = AccessoryDriver(port=PORT, persist_file=PERSIST, pincode=_CODE["pin"].encode(),
                             listen_address="0.0.0.0", advertised_address=addrs, interface_choice=InterfaceChoice.All)
    driver.state.setup_id = _CODE["setup_id"]
    driver.add_accessory(accessory=RaspiTV(driver, "Raspi-TV"))
    write_info(driver)
    signal.signal(signal.SIGTERM, driver.signal_handler)
    driver.start()


if __name__ == "__main__":
    main()
