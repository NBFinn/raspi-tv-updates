#!/bin/bash -e
# Raspi-TV: Programmdateien installieren.
# Wird beim Bauen des Images UND beim Software-Update per USB-Stick benutzt.
#
#   install-files.sh <Quellordner (Projekt)> <Zielwurzel, z. B. / oder $ROOTFS_DIR>
F="${1:?Quellordner fehlt}"
R="${2:?Zielwurzel fehlt}"
D="$R/opt/raspi-tv"

install -d "$D/launcher" "$D/extension" "$D/user" "$D/recovery-assets"
# Eigene Kopien: Terminal bleibt bei ausgefallenem Launcher nutzbar.
install -m 644 "$F/system/terminal.py" "$D/recovery-assets/terminal.py"
install -m 644 "$F/system/maintenance.py" "$D/maintenance.py"
install -m 644 "$F/system/display-diagnostics.py" "$D/display-diagnostics.py"
install -m 644 "$F/system/display_settings.py" "$D/display_settings.py"
install -m 644 "$F/system/maintenance.js" "$D/recovery-assets/maintenance.js"
install -m 644 "$F/launcher/qrcode.js" "$D/recovery-assets/qrcode.js"
for asset in xterm.js xterm.css xterm-addon-fit.js xterm.LICENSE.txt; do
    install -m 644 "$F/launcher/$asset" "$D/recovery-assets/$asset"
done
# Oberfläche & Erweiterung komplett ersetzen (alte Dateien entfernen)
find "$D/launcher" "$D/extension" -maxdepth 1 -type f -delete 2>/dev/null || true
# nur Dateien (keine Ordner wie _metadata, die der Browser selbst anlegt)
find "$F/launcher" -maxdepth 1 -type f -exec install -m 644 -t "$D/launcher/" {} +
find "$F/extension" -maxdepth 1 -type f -exec install -m 644 -t "$D/extension/" {} +
# 6.0: Schriften und Medienbibliothek (4K-Hintergründe, Ambient-Videos) – Unterordner komplett ersetzen
# (Kleine Updates ohne diese Ordner lassen die vorhandenen Medien unverändert.)
for sub in fonts media; do
	if [ -d "$F/launcher/$sub" ]; then
		rm -rf "$D/launcher/$sub"
		cp -R "$F/launcher/$sub" "$D/launcher/$sub"
		chmod -R u=rwX,go=rX "$D/launcher/$sub"
	fi
done
# Chromium persistiert den DNR-Regelcache im Erweiterungsordner.
# Nur der Cache ist fuer tv schreibbar; Programmdateien bleiben root-eigen.
if [ -L "$D/extension/_metadata" ]; then echo "Ungueltiger Erweiterungscache" >&2; exit 1; fi
install -d -m 755 "$D/extension/_metadata"
TV_IDS="$(awk -F: '$1 == "tv" { print $3 ":" $4; exit }' "$R/etc/passwd" 2>/dev/null || true)"
if [[ "$TV_IDS" =~ ^[0-9]+:[0-9]+$ ]]; then
    chown --no-dereference "$TV_IDS" "$D/extension/_metadata"
fi
install -m 644 "$F/system/multimedia.py" "$D/multimedia.py"
install -m 644 "$F/system/features.py" "$D/features.py"
install -m 644 "$F/system/dlna.py" "$D/dlna.py"
install -m 644 "$F/system/timeshift.py" "$D/timeshift.py"
install -m 644 "$F/system/recorder.py" "$D/recorder.py"
install -m 644 "$F/system/terminal.py" "$D/terminal.py"
install -m 644 "$F/system/homekit.py" "$D/homekit.py"
install -m 644 "$F/system/recovery.html" "$D/recovery.html"
for s in fan-setup.py enable-fan.sh round-displays.py powerfail.py enable-round-displays.sh browser-guard.py open-recovery.sh recovery.py tvctl.py cec-remote.py start-browser.sh display-watch.sh wlan-setup.sh install-files.sh apply-update.sh spotify-event.sh volume.sh update-guard.sh; do
	[ -f "$F/system/$s" ] && install -m 755 "$F/system/$s" "$D/$s"
done
for u in xinitrc xbindkeysrc bash_profile; do
	install -m 644 "$F/user/$u" "$D/user/$u"
done
[ -f "$F/VERSION" ] && install -m 644 "$F/VERSION" "$D/VERSION"
# 7.0: Firmware für den Teensy 4.1 (runde Displays per USB) und udev-Regel zum Starten des Dienstes
if [ -f "$F/teensy/raspi-tv-displays.hex" ]; then
	install -d "$D/teensy"
	install -m 644 "$F/teensy/raspi-tv-displays.hex" "$D/teensy/raspi-tv-displays.hex"
	grep -o 'FW_VERSION "[0-9.]*"' "$F/teensy/raspi-tv-displays/raspi-tv-displays.ino" | grep -o '[0-9.]*' >"$D/teensy/version" || true
fi
install -d "$R/etc/udev/rules.d"
cat >"$R/etc/udev/rules.d/70-raspi-tv-displays.rules" <<'RULES'
# Raspi-TV: Teensy 4.1 mit der Display-Firmware -> /dev/raspi-tv-displays, Display-Dienst starten
SUBSYSTEM=="tty", ATTRS{idVendor}=="16c0", ATTRS{idProduct}!="0478", SYMLINK+="raspi-tv-displays", TAG+="systemd", ENV{SYSTEMD_WANTS}+="raspi-tv-round.service"
# Teensy im Programmiermodus (Knopf gedrückt / neuer Teensy): Firmware automatisch einspielen
SUBSYSTEM=="hidraw", ATTRS{idVendor}=="16c0", ATTRS{idProduct}=="0478", TAG+="systemd", ENV{SYSTEMD_WANTS}+="raspi-tv-teensy-flash.service"
RULES

for svc in "$F"/system/*.service; do
	install -m 644 "$svc" "$R/etc/systemd/system/"
done

for d in etc/chromium/policies/managed etc/chromium-browser/policies/managed; do
	install -d "$R/$d"
	install -m 644 "$F/system/chromium-policy.json" "$R/$d/raspi-tv.json"
done

# Grafik: Xorg soll den HDMI-Anzeigechip (vc4) nehmen, nicht den reinen
# 3D-Rechenchip (v3d). Ohne das bleibt das Bild auf Pi 4/5 schwarz ("no screens found").
install -d "$R/etc/X11/xorg.conf.d"
cat >"$R/etc/X11/xorg.conf.d/99-raspi-tv.conf" <<'EOXORG'
Section "OutputClass"
	Identifier "Raspi-TV HDMI"
	MatchDriver "vc4"
	Driver "modesetting"
	Option "PrimaryGPU" "true"
EndSection
EOXORG

# Ausweich-Konfigurationen, falls die erste nicht klappt (werden beim Start der Reihe nach probiert)
install -d "$R/etc/X11/raspi-tv"
for c in card1 card0 card2; do
	printf 'Section "Device"\n\tIdentifier "Raspi-TV %s"\n\tDriver "modesetting"\n\tOption "kmsdev" "/dev/dri/%s"\nEndSection\n' "$c" "$c" \
		>"$R/etc/X11/raspi-tv/$c.conf"
done
printf 'Section "Device"\n\tIdentifier "Raspi-TV Framebuffer"\n\tDriver "fbdev"\n\tOption "fbdev" "/dev/fb0"\nEndSection\n' \
	>"$R/etc/X11/raspi-tv/fbdev.conf"

# Bootlogo aktualisieren (falls vorhanden)
if [ -d "$F/branding/plymouth" ]; then
	install -d "$R/usr/share/plymouth/themes/raspitv"
	install -m 644 "$F"/branding/plymouth/* "$R/usr/share/plymouth/themes/raspitv/"
fi

# Schneller herunterfahren: Dienste bekommen höchstens 8 s statt 90 s zum Beenden,
# die TV-Anmeldung (Browser) und die Benutzersitzung 5 s.
install -d "$R/etc/systemd/system.conf.d" "$R/etc/systemd/user.conf.d" \
	"$R/etc/systemd/system/getty@tty1.service.d" "$R/etc/systemd/system/user@.service.d"
printf '[Manager]\nDefaultTimeoutStopSec=8s\n' >"$R/etc/systemd/system.conf.d/raspi-tv-fast-stop.conf"
printf '[Manager]\nDefaultTimeoutStopSec=5s\n' >"$R/etc/systemd/user.conf.d/raspi-tv-fast-stop.conf"
printf '[Service]\nTimeoutStopSec=5s\n' >"$R/etc/systemd/system/getty@tty1.service.d/raspi-tv-fast-stop.conf"
printf '[Service]\nTimeoutStopSec=5s\n' >"$R/etc/systemd/system/user@.service.d/raspi-tv-fast-stop.conf"

# Unter Windows bearbeitete Dateien: CRLF-Zeilenenden entfernen (sonst startet z. B. der Browser nicht)
find "$D" -maxdepth 2 -type f \( -name '*.sh' -o -name '*.py' -o -name '*.js' -o -name '*.html' -o -name '*.css' \
	-o -name '*.json' -o -name xinitrc -o -name xbindkeysrc -o -name bash_profile -o -name VERSION \) \
	-exec sed -i 's/\r$//' {} + 2>/dev/null || true
sed -i 's/\r$//' "$R"/etc/systemd/system/raspi-tv*.service 2>/dev/null || true

# Versionsinfo
VER="$(cat "$F/VERSION" 2>/dev/null || echo "${RASPI_TV_VERSION:-1.0}")"
cat >"$R/etc/raspi-tv-release" <<EOF
NAME="Raspi-TV OS"
VERSION="$VER"
BUILD_DATE="$(date +%Y-%m-%d)"
EOF
