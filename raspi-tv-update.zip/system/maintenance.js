/* Offline maintenance UI. All operations use the authenticated recovery service. */
(function(){
'use strict';
const panel=document.createElement('section');
panel.id='maintenanceTools';
panel.innerHTML='<h2>Wartungswerkzeuge</h2><div id="maintenanceTabs" class="row"></div><div id="maintenanceView"></div>';
document.querySelector('#admin').insertBefore(panel,document.querySelector('#admin').lastElementChild);
const style=document.createElement('style');
style.textContent='.maintenance-note{color:#b9c4dc}.maintenance-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px}.maintenance-item{border:1px solid #45567c;border-radius:12px;padding:14px;margin:12px 0;overflow-wrap:anywhere}.maintenance-item svg{max-width:100%;height:auto}.maintenance-good{color:#8ee3b5}.maintenance-bad{color:#ff9ca8}#maintenanceView select{font:inherit;max-width:100%;padding:12px;background:#0b1020;color:#edf2ff;border:1px solid #617ba6;border-radius:9px}#maintenanceView input[type=checkbox]{width:24px;height:24px;margin-right:12px}#maintenanceView label{padding:10px;border-bottom:1px solid #303c59;overflow-wrap:anywhere}#maintenanceView pre{max-height:450px}#calibration{position:fixed;inset:0;z-index:2147483647;background:#000;color:white;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:4vh}#calibration[hidden]{display:none}#calibration svg{width:100%;flex:1;min-height:0}#calibration p{background:#10131a;padding:10px;color:white;margin:8px}#calibration button{font:inherit;background:#3679f5;color:white;padding:14px;border-radius:10px}';
document.head.appendChild(style);
const tabs=[['qr','QR-Fehlerhilfe'],['safe','Startmodus'],['network','Netzwerk'],['cec','Fernbedienung'],['av','Bild und Ton'],['storage','Speicher'],['timeline','Fehlerverlauf'],['help','Offline-Hilfe'],['support','Support auf USB']];
let selectedTab=null,cecTimer=null,learnedCode=null,displayToken=null;
const view=$('maintenanceView');
const showError=error=>notice(error.message||String(error),true);
const bytes=value=>(Number(value)/1048576).toFixed(1)+' MiB';
function element(tag,text,cls){const node=document.createElement(tag);if(text!==undefined)node.textContent=text;if(cls)node.className=cls;return node;}
function button(text,fn,parent=view){const node=element('button',text);node.onclick=()=>Promise.resolve().then(fn).catch(showError);parent.appendChild(node);return node;}
function message(text){view.appendChild(element('p',text,'maintenance-note'));}
function pre(data,parent=view){const node=element('pre',typeof data==='string'?data:JSON.stringify(data,null,2));parent.appendChild(node);return node;}
async function job(path,name){
 await post(path);return waitTask(name);
}
async function waitTask(name){
 const deadline=Date.now()+180000;
 while(Date.now()<deadline){
  const state=await api('/maintenance/status'),task=state.tasks[name];
  if(task&&!task.running){if(task.error)throw Error(task.error);return task.result;}
  await new Promise(resolve=>setTimeout(resolve,500));
 }
 throw Error('Die Prüfung dauert länger. Bitte später erneut öffnen.');
}
let roundResult=null,roundPolling=false;
function showRoundResult(result){
 roundResult=result;
 $('roundReport').textContent=result.report;
 $('roundStatus').textContent='Diagnose abgeschlossen ('+result.created+'). Lade den Bericht herunter und schicke ihn im Chat. Alternativ kannst du ihn im Support-Paket auf USB speichern.';
 $('roundDownload').disabled=false;$('roundUsb').disabled=false;
}
async function runRoundDiagnosis(start){
 if(roundPolling)return;
 roundPolling=true;roundResult=null;$('roundDiagnose').disabled=true;$('roundDownload').disabled=true;$('roundUsb').disabled=true;
 $('roundStatus').textContent='Display-Anschlüsse werden geprüft … Das kann etwa eine Minute dauern.';
 $('roundReport').textContent='Prüfung läuft …';
 try{
  if(start)await post('/maintenance/round-displays');
  showRoundResult(await waitTask('round-displays'));
 }catch(error){$('roundStatus').textContent='Diagnose fehlgeschlagen: '+error.message;$('roundReport').textContent=error.message;$('roundDetails').open=true;}
 finally{roundPolling=false;$('roundDiagnose').disabled=false;}
}
$('roundDiagnose').onclick=()=>runRoundDiagnosis(true);
$('roundDownload').onclick=()=>{
 if(!roundResult)return;
 const link=element('a');link.href=URL.createObjectURL(new Blob(['\ufeff',roundResult.report],{type:'text/plain;charset=utf-8'}));
 link.download='raspi-tv-display-diagnose.txt';link.click();setTimeout(()=>URL.revokeObjectURL(link.href),1000);
};
$('roundUsb').onclick=()=>open('support').then(()=>panel.scrollIntoView({block:'start'})).catch(showError);
async function open(name){
 if(cecTimer){clearInterval(cecTimer);cecTimer=null;}
 selectedTab=name;view.replaceChildren();
 for(const node of $('maintenanceTabs').children)node.setAttribute('aria-pressed',node.dataset.tab===name?'true':'false');
 await renderers[name]();
}
for(const[name,title]of tabs){const node=button(title,()=>open(name),$('maintenanceTabs'));node.dataset.tab=name;}
const renderers={
 async qr(){
  message('Erstelle einen bereinigten Fehlerbericht. Auf dem Handy ist weiterhin der Admin-Code erforderlich; der QR-Code enthält ihn nicht.');
  button('QR-Code und Fehlerbericht erstellen',async()=>{
   const result=await post('/maintenance/report');
   const old=$('qrResult');if(old)old.remove();
   const box=element('div',undefined,'maintenance-item');box.id='qrResult';
   if(result.url){
    const qr=qrcode(0,'M');qr.addData(result.url);qr.make();
    const image=document.createElement('div');image.innerHTML=qr.createSvgTag({cellSize:5,margin:3});box.appendChild(image);
    const link=element('a',result.url);link.href=result.url;box.appendChild(link);
   }else box.appendChild(element('p','Noch keine Netzadresse erkannt. Der Bericht ist unten direkt lesbar.'));
   pre(result.report,box);view.appendChild(box);
  });
 },
 async safe(){
  const state=await api('/maintenance/status');
  message(state.safe.active?'Abgesicherter Start aktiv: Browser-Erweiterungen werden nicht geladen.':'Normaler Start. Nach drei kurzen Browserabstürzen innerhalb von fünf Minuten wird der abgesicherte Start automatisch aktiviert.');
  button('Abgesicherten Start aktivieren',async()=>{await post('/maintenance/safe',{enabled:true});await open('safe');});
  button('Zum normalen Start zurückkehren',async()=>{await post('/maintenance/safe',{enabled:false});await open('safe');});
  button('Browser jetzt neu starten',async()=>{if(confirm('Browser jetzt neu starten? Laufende Wiedergabe und offene Seiten werden beendet.')){await post('/maintenance/restart-browser');notice('Browser wird neu gestartet.');}});
 },
 async network(){
  message('WLAN, IP-Adresse, Namensauflösung und Internetzugang getrennt prüfen.');
  const output=element('div');view.appendChild(output);
  const start=button('Netzwerktest starten',async()=>{
   start.disabled=true;output.textContent='Netzwerk wird geprüft …';
   try{const result=await job('/maintenance/network','network');output.replaceChildren();
    for(const check of result.checks){const box=element('div',undefined,'maintenance-item');box.appendChild(element('strong',check.name+': '+(check.ok===true?'OK':check.ok===false?'Problem':'Hinweis'),check.ok===true?'maintenance-good':check.ok===false?'maintenance-bad':''));box.appendChild(element('p',check.detail));output.appendChild(box);}
   }finally{start.disabled=false;}
  });
 },
 async cec(){
  learnedCode=null;
  message('Drücke zuerst „Taste lernen“, danach genau die gewünschte Taste auf der TV-Fernbedienung. Anschließend kannst du ihre Funktion wählen.');
  const status=element('p','Noch keine Taste ausgewählt.');view.appendChild(status);
  const state=await api('/maintenance/cec'),select=document.createElement('select');select.id='cecAction';select.setAttribute('aria-label','Neue Tastenfunktion');
  for(const[action,title]of Object.entries(state.actions)){const option=element('option',title);option.value=action;select.appendChild(option);}
  const original=element('option','Standardbelegung wiederherstellen');original.value='default';select.appendChild(original);view.appendChild(select);
  button('Taste lernen',async()=>{
   const before=await api('/maintenance/cec'),stamp=before.last?before.last.at:null,started=performance.now();learnedCode=null;status.textContent='Jetzt die gewünschte Fernbedienungstaste drücken …';
   if(cecTimer)clearInterval(cecTimer);
   cecTimer=setInterval(async()=>{
    try{const current=await api('/maintenance/cec');
     if(current.last&&current.last.at!==stamp){learnedCode=current.last.code;status.textContent='Erkannt: '+current.last.name+' (Code '+learnedCode+'). Jetzt die Funktion wählen und speichern.';clearInterval(cecTimer);cecTimer=null;select.focus();}
     else if(performance.now()-started>30000){clearInterval(cecTimer);cecTimer=null;status.textContent='Keine Taste erkannt. Ist HDMI-CEC am Fernseher eingeschaltet?';}
    }catch(error){clearInterval(cecTimer);cecTimer=null;showError(error);}
   },600);
  });
  button('Belegung speichern',async()=>{if(!learnedCode)throw Error('Bitte zuerst eine Taste lernen.');await post('/maintenance/cec',{code:learnedCode,action:select.value});notice('Tastenbelegung gespeichert und sofort wirksam.');});
  pre(state.mapping);
 },
 async av(){
  message('Bildränder und Geometrie mit einem Testbild prüfen. Wähle am TV bei abgeschnittenen Rändern „Original“, „Just Scan“ oder „Bildschirmanpassung“.');
  button('Testbild bildschirmfüllend anzeigen',()=>{previousOverflow=document.body.style.overflow;document.body.style.overflow='hidden';calibration.hidden=false;$('calibrationClose').focus();if(calibration.requestFullscreen)calibration.requestFullscreen().catch(()=>{});});
  const displays=await api('/maintenance/display');
  const modes=document.createElement('select');modes.id='displayMode';modes.setAttribute('aria-label','Bildschirmauflösung');
  for(const output of displays.outputs)for(const mode of output.modes){const option=element('option',output.output+' · '+mode.mode+' @ '+mode.rate+' Hz');option.value=JSON.stringify({...mode,output:output.output});modes.appendChild(option);}
  if(!modes.options.length)message('Grafiksitzung nicht erreichbar. Das Testbild und die Offline-Hilfe bleiben verfügbar.');
  else{
   view.appendChild(modes);const status=element('p','Eine neue Auflösung wird nach 20 Sekunden automatisch zurückgesetzt, solange du sie nicht bestätigst.');view.appendChild(status);
   const keep=button('Bild ist sichtbar – Auflösung behalten',async()=>{await post('/maintenance/display-confirm',{id:displayToken});displayToken=null;keep.disabled=true;status.textContent='Auflösung dauerhaft gespeichert.';});keep.disabled=true;
   button('Auflösung für 20 Sekunden testen',async()=>{const result=await post('/maintenance/display-test',JSON.parse(modes.value));displayToken=result.id;keep.disabled=false;keep.focus();status.textContent='Ist das Bild sichtbar? Bitte innerhalb von 20 Sekunden bestätigen.';setTimeout(()=>{if(displayToken===result.id){displayToken=null;keep.disabled=true;status.textContent='Test abgelaufen. Die bisherige Auflösung wurde wiederhergestellt.';}},20500);});
  }
  view.appendChild(element('h3','Audioausgang und Testton'));
  const audio=await api('/maintenance/audio'),outputs=document.createElement('select');outputs.id='audioOutput';outputs.setAttribute('aria-label','Audioausgang');
  for(const item of audio.outputs){const option=element('option',item.name);option.value=item.id;outputs.appendChild(option);}
  if(audio.outputs.length){view.appendChild(outputs);button('Audioausgang übernehmen',async()=>{await post('/maintenance/audio',{id:Number(outputs.value)});notice('Audioausgang gespeichert.');});}
  else message('Der Audio-Dienst ist gerade nicht erreichbar. Prüfe HDMI/Audio mit der Offline-Hilfe.');
  button('Leisen Testton abspielen',async()=>{await post('/maintenance/audio-test');notice('Testton läuft für zwei Sekunden auf dem aktuellen Ausgang.');});
  button('Testton stoppen',()=>post('/maintenance/audio-stop'));
 },
 async storage(){
  message('Es werden nur Downloads und ausgewählte Cache-Verzeichnisse angeboten. Anmeldungen, Browserprofileinstellungen und persönliche Konfiguration bleiben erhalten.');
  const resultBox=element('div');view.appendChild(resultBox);
  button('Speicher und große Dateien prüfen',async()=>{
   resultBox.textContent='Dateien werden erfasst …';const result=await job('/maintenance/storage-scan','storage');resultBox.replaceChildren();
   resultBox.appendChild(element('p','Frei: '+bytes(result.free)+' von '+bytes(result.total)));
   for(const group of result.groups)resultBox.appendChild(element('p',group.path+': '+bytes(group.bytes)));
   for(const item of result.files){
    const label=document.createElement('label'),check=document.createElement('input');check.type='checkbox';check.dataset.id=item.id;check.dataset.category=item.category;check.dataset.bytes=item.bytes;
    label.appendChild(check);label.appendChild(document.createTextNode((item.category==='cache'?'Cache':'Download')+' · '+item.name+' · '+bytes(item.bytes)));resultBox.appendChild(label);
   }
   button('Angezeigte Cache-Dateien auswählen',()=>{for(const check of resultBox.querySelectorAll('input[type=checkbox]'))check.checked=check.dataset.category==='cache';},resultBox);
   button('Ausgewählte Dateien löschen',async()=>{
    const checks=[...resultBox.querySelectorAll('input:checked')];if(!checks.length)throw Error('Bitte Dateien auswählen.');
    const size=checks.reduce((sum,check)=>sum+Number(check.dataset.bytes),0);
    if(!confirm(checks.length+' ausgewählte Dateien ('+bytes(size)+') dauerhaft löschen?'))return;
    const removed=await post('/maintenance/storage-delete',{ids:checks.map(check=>check.dataset.id)});
    notice(bytes(removed.deleted)+' freigegeben.'+(removed.errors.length?' '+removed.errors.join(' '):''));
    await open('storage');
   },resultBox);
  });
 },
 async timeline(){
  const filter=document.createElement('select');filter.setAttribute('aria-label','Ereignistyp');
  for(const value of ['Alle','error','configuration','update-start','update-success','update-error','safe-mode','cleanup','support']){const option=element('option',value==='Alle'?'Alle Ereignisse':value);option.value=value;filter.appendChild(option);}view.appendChild(filter);
  const container=element('div');view.appendChild(container);
  const render=async()=>{const result=await api('/maintenance/timeline');container.replaceChildren();
   for(const item of result.events.filter(item=>filter.value==='Alle'||item.kind===filter.value)){
    const box=element('div',undefined,'maintenance-item');box.appendChild(element('strong',new Date(item.at*1000).toLocaleString('de-DE')+' · '+item.kind+' · '+item.version));
    box.appendChild(element('p',item.message,item.kind.includes('error')?'maintenance-bad':''));container.appendChild(box);
   }
   if(!container.children.length)container.appendChild(element('p','Noch keine passenden Ereignisse.'));
  };filter.onchange=()=>render().catch(showError);button('Verlauf aktualisieren',render);await render();
 },
 async help(){
  message('Diese bebilderten Anleitungen sind vollständig auf dem Pi gespeichert und funktionieren ohne Internet.');
  const guides=[
   ['Kein Bild','tv',['Den richtigen HDMI-Eingang am TV wählen.','Bild und Ton → Testbild öffnen; sind alle vier Ränder sichtbar?','Auflösung nur mit Rückfalltest ändern. Bei schwarzem Bild 20 Sekunden warten.']],
   ['Kein Internet','network',['WLAN am Pi oder Ethernet-Kabel prüfen.','Netzwerktest starten: zuerst IP, danach DNS und Internet ansehen.','Fehlt nur DNS, den Router neu verbinden. Die Offline-Hilfe bleibt erreichbar.']],
   ['Update schlägt fehl','usb',['Die ZIP oben auf den Stick kopieren und nicht entpacken.','USB-Stick suchen, Paket auswählen und Update-Probelauf starten.','Bei Platzmangel unter Speicher gezielt Cache aufräumen; Fehlerverlauf und Update-Protokoll ansehen.']],
   ['Fernbedienung reagiert nicht','tv',['HDMI-CEC am Fernseher einschalten; manche Hersteller nennen es Anynet+, Simplink oder Bravia Sync.','Unter Fernbedienung eine Taste lernen und ihre Funktion zuordnen.','Für die PIN-Eingabe die Zifferntastatur auf dieser Seite benutzen.']],
   ['Kein Ton','audio',['TV oder Soundbar entstummen und Lautstärke prüfen.','Unter Bild und Ton den gewünschten Audioausgang übernehmen.','Den leisen Testton abspielen und HDMI-Kabel beziehungsweise Bluetooth-Verbindung prüfen.']],
   ['Wiederholte Abstürze','tv',['Unter Startmodus den abgesicherten Start aktivieren.','Den Browser neu starten; Erweiterungen bleiben dabei deaktiviert.','Fehlerverlauf prüfen. Nach der Reparatur wieder zum normalen Start zurückkehren.']],
   ['Speicher voll','usb',['Speicher prüfen und die größten Dateien ansehen.','Nur nicht mehr benötigte Downloads oder Cache auswählen.','Löschen bestätigen; danach den Update-Probelauf erneut starten.']],
   ['Hilfe am Handy oder per USB','network',['QR-Fehlerhilfe erstellen und den Code mit dem Handy scannen.','Am Handy mit dem vierstelligen Admin-Code anmelden.','Ohne Netzwerk ein bereinigtes Support-Paket auf USB exportieren.']]
  ];
  for(const[title,type,steps]of guides){const details=document.createElement('details');details.className='maintenance-item';details.appendChild(element('summary',title));const figure=document.createElement('figure');figure.innerHTML=diagram(type);details.appendChild(figure);const list=document.createElement('ol');for(const step of steps)list.appendChild(element('li',step));details.appendChild(list);view.appendChild(details);}
 },
 async support(){
  message('Enthält bereinigte Diagnose, Fehlerverlauf und Versionsinfos. Passwörter, Admin-Code, Browserprofile und Terminalausgaben werden nicht mitgenommen.');
  button('Support-Paket herunterladen',async()=>{
   const response=await fetch('/maintenance/support.zip',{headers:{'X-Admin-Key':key}});if(!response.ok)throw Error((await response.json()).error||'Download fehlgeschlagen.');
   const link=element('a');link.href=URL.createObjectURL(await response.blob());link.download='raspi-tv-support.zip';link.click();setTimeout(()=>URL.revokeObjectURL(link.href),1000);
  });
  const select=document.createElement('select');select.id='supportUsb';select.setAttribute('aria-label','USB-Ziel');view.appendChild(select);
  const list=async()=>{const result=await api('/maintenance/usb');select.replaceChildren();for(const drive of result.drives){const option=element('option',drive.name);option.value=drive.id;select.appendChild(option);}if(!result.drives.length)notice('Kein USB-Stick erkannt. Bitte einstecken und erneut suchen.');};
  button('USB-Ziele suchen',list);
  button('Support-Paket auf USB speichern',async()=>{if(!select.value)throw Error('Bitte zuerst einen USB-Stick auswählen.');const result=await post('/maintenance/support-export',{id:select.value});notice('Auf '+result.device+' gespeichert: '+result.name);});
  await list();
 }
};
function diagram(type){
 const right=type==='network'?'Router / Handy':type==='usb'?'USB-Stick':type==='audio'?'TV / Soundbar':'Fernseher';
 const cable=type==='network'?'WLAN / Ethernet':type==='usb'?'USB':type==='audio'?'HDMI / Audio':'HDMI';
 return '<svg viewBox="0 0 600 180" role="img" aria-label="Verbindung vom Pi zu '+right+'"><rect x="20" y="35" width="150" height="100" rx="14" fill="#1e7658" stroke="#9be4c7" stroke-width="3"/><text x="95" y="94" text-anchor="middle" fill="white" font-size="25">Raspberry Pi</text><path d="M170 85H400" stroke="#8cc9ff" stroke-width="9"/><path d="M380 70L400 85L380 100" fill="none" stroke="#8cc9ff" stroke-width="5"/><text x="285" y="58" text-anchor="middle" fill="#cfe8ff" font-size="19">'+cable+'</text><rect x="405" y="25" width="175" height="120" rx="12" fill="#263d64" stroke="#9bc8ff" stroke-width="3"/><text x="493" y="92" text-anchor="middle" fill="white" font-size="20">'+right+'</text></svg>';
}
let previousOverflow='';
const calibration=document.createElement('div');calibration.id='calibration';calibration.hidden=true;
calibration.innerHTML='<svg viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid meet" role="img" aria-label="Testbild mit vier sichtbaren Randmarkierungen"><defs><pattern id="checker" width="80" height="80" patternUnits="userSpaceOnUse"><rect width="80" height="80" fill="#222"/><rect width="40" height="40" fill="#ddd"/><rect x="40" y="40" width="40" height="40" fill="#ddd"/></pattern></defs><rect width="1600" height="900" fill="url(#checker)"/><rect x="8" y="8" width="1584" height="884" fill="none" stroke="#ff5252" stroke-width="16"/><rect x="60" y="60" width="1480" height="780" fill="#101723" stroke="#5cf5a4" stroke-width="5"/><circle cx="800" cy="450" r="280" fill="none" stroke="#fff" stroke-width="6"/><path d="M800 60V840M60 450H1540" stroke="#aaa" stroke-width="3"/><text x="800" y="420" text-anchor="middle" fill="white" font-size="48">Alle vier roten Ränder sichtbar?</text><text x="800" y="490" text-anchor="middle" fill="white" font-size="38">Der Kreis soll rund sein.</text></svg><p>Bei abgeschnittenen Rändern am Fernseher „Original / Just Scan / Bildschirmanpassung“ wählen.</p><button id="calibrationClose">Testbild schließen</button>';
const frame=document.createElement('div');frame.style.cssText='position:absolute;inset:0;border:8px solid #ff5252;pointer-events:none';calibration.appendChild(frame);
const calibrationStyle=document.createElement('style');calibrationStyle.textContent='#calibration{display:block;padding:0}#calibration svg{position:absolute;inset:0;width:100%;height:100%}#calibration p{position:absolute;bottom:12vh;left:5%;width:90%;text-align:center}#calibration button{position:absolute;bottom:3vh;left:50%;transform:translateX(-50%)}';document.head.appendChild(calibrationStyle);
document.body.appendChild(calibration);
$('calibrationClose').onclick=()=>{calibration.hidden=true;document.body.style.overflow=previousOverflow;if(document.fullscreenElement)document.exitFullscreen().catch(()=>{});};
window.addEventListener('keydown',event=>{if(calibration.hidden)return;if(['Escape','Enter','Backspace'].includes(event.key)){$('calibrationClose').click();event.preventDefault();event.stopImmediatePropagation();}else if(event.key.startsWith('Arrow')||event.key==='Tab'){event.preventDefault();event.stopImmediatePropagation();$('calibrationClose').focus();}},true);
$('preflight').onclick=async()=>{
 if(!uploaded)return;const digest=uploaded.sha256;const start=$('preflight');start.disabled=true;$('preflightResult').textContent='ZIP, Speicher und Installation im geschützten Testverzeichnis werden geprüft …';
 try{const result=await job('/maintenance/preflight','preflight');if(!uploaded||uploaded.sha256!==digest||result.sha256!==digest)throw Error('Das Update wurde zwischenzeitlich gewechselt. Bitte erneut prüfen.');
  preflightReady=result.ok;$('preflightResult').textContent=result.steps.join('\n')+'\nBenötigt: '+bytes(result.needed)+' · Frei: '+bytes(result.free);$('install').disabled=!preflightReady;notice('Update-Probelauf bestanden. Installation kann gestartet werden.');
 }catch(error){preflightReady=false;$('install').disabled=true;$('preflightResult').textContent=error.message;showError(error);}finally{start.disabled=!uploaded;}
};
window.RaspiMaintenance={
 onSelected(){preflightReady=false;$('preflight').disabled=false;$('preflightResult').textContent='Update ausgewählt. Bitte zuerst den Update-Probelauf starten.';},
 async onLogin(){
  try{
   const status=await api('/maintenance/status');
   const displayTask=status.tasks&&status.tasks['round-displays'];
   if(displayTask){
    if(displayTask.running)runRoundDiagnosis(false);
    else if(displayTask.result)showRoundResult(displayTask.result);
    else if(displayTask.error){$('roundStatus').textContent='Diagnose fehlgeschlagen: '+displayTask.error;$('roundReport').textContent=displayTask.error;}
   }
   $('launcher').href=location.protocol+'//'+location.hostname+':8765/'+(status.safe.active?'?safe=1':'');
   const match=location.hash.match(/^#report=([0-9a-f]{24})$/);
   if(match){selectedTab='qr';view.replaceChildren();view.appendChild(element('h3','Fehlerbericht vom Pi'));pre(await api('/maintenance/report?id='+match[1]));panel.scrollIntoView({block:'start'});}
  }catch(error){showError(error);}
 }
};
button('Wartungswerkzeuge öffnen',()=>{panel.scrollIntoView({block:'start'});$('maintenanceTabs').querySelector('button').focus();},document.querySelector('#admin > section:first-child')).classList.add('secondary');
window.addEventListener('hashchange',()=>{if(connected)window.RaspiMaintenance.onLogin();});
if(uploaded)window.RaspiMaintenance.onSelected();
if(connected&&!$('admin').hidden)window.RaspiMaintenance.onLogin();
})();
