"""Independent, authenticated maintenance tools for Raspi-TV."""
import ast
import hashlib
import io
import ipaddress
import json
import math
import os
import platform
from pathlib import Path
import re
import secrets
import shutil
import socket
import stat
import struct
import subprocess
import tempfile
import threading
import time
import wave
import zipfile

ACTIONS = {'up': 'Hoch', 'down': 'Runter', 'left': 'Links', 'right': 'Rechts',
           'ok': 'OK', 'back': 'Zurueck', 'home': 'Home', 'mouse': 'Mausmodus',
           'pageup': 'Kanal hoch', 'pagedown': 'Kanal runter', 'playpause': 'Play/Pause',
           'volumeup': 'Lauter', 'volumedown': 'Leiser', 'mute': 'Stumm'}
PRIVATE = re.compile(r'password|passwd|secret|token|cookie|authorization|api.?key|admin.?key|(^|_)psk($|_)|(^|_)auth($|_)|(^|_)pin($|_)', re.I)


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.raspitv-', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as output:
            json.dump(value, output, ensure_ascii=False)
            output.flush()
            os.fsync(output.fileno())
        os.chmod(temporary, 0o644)
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


class Maintenance:
    def __init__(self, root, state, diagnostics, usb_roots, inspect_update, job, system_root=Path('/')):
        self.root, self.state, self.system_root = Path(root), Path(state), Path(system_root)
        self.diagnostics, self.usb_roots, self.inspect_update, self.job = diagnostics, usb_roots, inspect_update, job
        self.config = self.system_root/'var/lib/raspi-tv'
        self.home = self.system_root/'home/tv'
        self.lock, self.event_lock, self.preflight_lock = threading.RLock(), threading.Lock(), threading.Lock()
        self.tasks, self.files, self.drives = {}, {}, {}
        self.preflight_result = None
        self.display_pending = None
        self.sound_process = None
        self.spawn = subprocess.Popen
        self.connector = socket.create_connection
        self.state.mkdir(parents=True, exist_ok=True)

    def run(self, args, timeout=10, check=True):
        result = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        if check and result.returncode:
            raise ValueError((result.stderr or result.stdout or 'Programm fehlgeschlagen: '+args[0])[-3000:])
        return result

    def tv_args(self, args):
        uid = self.run(['id', '-u', 'tv']).stdout.strip()
        if not uid.isdigit():
            raise ValueError('TV-Benutzer fehlt.')
        return ['runuser', '-u', 'tv', '--', 'env', 'XDG_RUNTIME_DIR=/run/user/'+uid,
                'DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/'+uid+'/bus',
                'DISPLAY=:0', 'XAUTHORITY='+str(self.home/'.Xauthority')] + args

    def _secrets(self):
        found = []
        try:
            code = (self.state/'admin.key').read_text().strip()
            if code:
                found.append(code)
        except OSError:
            pass
        def walk(value):
            if isinstance(value, dict):
                for name, item in value.items():
                    if PRIVATE.search(name) and isinstance(item, (str, int)) and len(str(item)) >= 4:
                        found.append(str(item))
                    else:
                        walk(item)
            elif isinstance(value, list):
                for item in value:
                    walk(item)
        try:
            walk(json.loads((self.config/'config.json').read_text(encoding='utf-8')))
        except (OSError, ValueError):
            pass
        return found

    def redact(self, value):
        known = self._secrets()
        def clean(item):
            if isinstance(item, dict):
                return {str(key): '[ENTFERNT]' if PRIVATE.search(str(key)) else clean(data)
                        for key, data in item.items()}
            if isinstance(item, (list, tuple)):
                return [clean(data) for data in item]
            if not isinstance(item, str):
                return item
            text = '\n'.join('[Zeile mit Zugangsdaten entfernt]' if re.search(r'(?i)\b(?:password|passwd|authorization|cookie|secret|token|psk|pin|admin[-_ ]?code|api[-_ ]?key)\b', line) else line for line in item.split('\n'))
            for secret in sorted(known, key=len, reverse=True):
                text = re.sub(r'(?<![A-Za-z0-9])'+re.escape(secret)+r'(?![A-Za-z0-9])', '[ENTFERNT]', text)
            text = re.sub(r'(?i)((?:password|passwd|token|secret|authorization|cookie|api[_-]?key|admin[_ -]?(?:code|key)|pin)\s*[:=]\s*)(?:"[^"]*"|\'[^\']*\'|[^\s,;]+)', r'\1[ENTFERNT]', text)
            text = re.sub(r'([?&][^=\s&]+)=([^&\s]+)', r'\1=[ENTFERNT]', text)
            text = re.sub(r'(?i)(https?://)[^/\s:@]+:[^@\s]+@', r'\1[ENTFERNT]@', text)
            return text
        return clean(value)

    def event(self, kind, message, at=None):
        record = self.redact({'at': time.time() if at is None else at, 'kind': kind, 'message': str(message)[:3000],
                              'version': self.version()})
        with self.event_lock:
            path = self.state/'events.jsonl'
            previous = path.read_text(encoding='utf-8', errors='replace') if path.exists() else ''
            if len(previous) > 300000:
                previous = '\n'.join(previous.splitlines()[-300:])+'\n'
            path.write_text((previous.rstrip('\n')+'\n' if previous else '')+json.dumps(record, ensure_ascii=False)+'\n', encoding='utf-8')

    def version(self):
        try:
            return (self.root/'VERSION').read_text().strip()
        except OSError:
            return 'unbekannt'

    def timeline(self):
        observed = self.state/'observed.json'
        old = {}
        try:
            old = json.loads(observed.read_text())
        except (OSError, ValueError):
            pass
        current = {}
        for name, path in [('Systemeinstellungen', self.config/'config.json'),
                           ('Fernbedienung', self.config/'cec-mapping.json'),
                           ('Anzeige', self.config/'display-mode'), ('Softwareversion', self.root/'VERSION')]:
            if path.is_file():
                stamp = hashlib.sha256(path.read_bytes()).hexdigest()
                current[name] = stamp
                if name in old and old[name] != stamp:
                    self.event('configuration', name+' geaendert.', at=path.stat().st_mtime)
        try:
            atomic_json(observed, current)
        except OSError:
            pass
        rows = []
        try:
            with self.event_lock:
                lines = (self.state/'events.jsonl').read_text(encoding='utf-8', errors='replace').splitlines()
        except OSError:
            lines = []
        for line in lines:
            try:
                row = json.loads(line)
                if isinstance(row, dict) and isinstance(row.get('at'), (int, float)) and math.isfinite(row['at']) and all(isinstance(row.get(key), str) for key in ('kind', 'message', 'version')):
                    rows.append(row)
            except ValueError:
                continue
        return {'events': self.redact(sorted(rows, key=lambda row: row['at'], reverse=True)[:100])}

    def task(self, name, fn):
        with self.lock:
            if self.tasks.get(name, {}).get('running'):
                return {'task': name}
            self.tasks[name] = {'running': True, 'result': None, 'error': None}
        def worker():
            try:
                result = fn()
                with self.lock:
                    self.tasks[name] = {'running': False, 'result': result, 'error': None}
            except Exception as error:
                with self.lock:
                    self.tasks[name] = {'running': False, 'result': None, 'error': self.redact(str(error))}
        threading.Thread(target=worker, daemon=True).start()
        return {'task': name}

    def ensure_shared_config(self):
        created = not self.config.exists()
        self.config.mkdir(parents=True, exist_ok=True)
        if created:
            self.config.chmod(0o755)

    def safe_status(self):
        guard = self.home/'.local/state/raspi-tv/browser-guard.json'
        try:
            data = json.loads(guard.read_text())
        except (OSError, ValueError):
            data = {}
        forced = (self.config/'safe-mode').exists()
        return {'active': forced or bool(data.get('safe')), 'crashes': len(data.get('failures', []))}

    def safe_set(self, enabled):
        self.ensure_shared_config()
        flag = self.config/'safe-mode'
        if enabled:
            flag.write_text('1\n')
        else:
            flag.unlink(missing_ok=True)
            (self.home/'.local/state/raspi-tv/browser-guard.json').unlink(missing_ok=True)
        self.event('safe-mode', 'Abgesicherter Start '+('aktiviert' if enabled else 'beendet'))
        return self.safe_status()

    def frontend_failure(self, message):
        self.event('error', message)
        rows = self.timeline()['events']
        recent = [row for row in rows if row['kind'] == 'error' and 0 <= time.time()-row['at'] < 300]
        if len(recent) >= 3 and not self.safe_status()['active']:
            self.safe_set(True)

    def restart_browser(self):
        self.run(['pkill', '-u', 'tv', '-TERM', '-o', '-f', '--', '--user-data-dir=.*raspi-tv-browser'], check=False)
        return {'ok': True}

    def network(self):
        rows = []
        try:
            value = json.loads(self.run(['ip', '-j', 'address']).stdout)
            addresses = [item['local'] for interface in value for item in interface.get('addr_info', [])
                         if item.get('family') == 'inet' and item.get('scope') == 'global']
            rows.append({'name': 'IP-Adresse', 'ok': bool(addresses), 'detail': ', '.join(addresses) or 'Keine IP-Adresse'})
        except Exception as error:
            rows.append({'name': 'IP-Adresse', 'ok': False, 'detail': str(error)})
        try:
            devices = self.run(['iw', 'dev']).stdout
            interface = re.search(r'Interface\s+([A-Za-z0-9_.-]+)', devices)
            if interface:
                link = self.run(['iw', 'dev', interface.group(1), 'link']).stdout
                connected = 'Connected to' in link
                rows.append({'name': 'WLAN', 'ok': connected, 'detail': link.strip()[:800]})
            else:
                rows.append({'name': 'WLAN', 'ok': None, 'detail': 'Kein WLAN-Interface; Ethernet kann weiterhin funktionieren.'})
        except Exception as error:
            rows.append({'name': 'WLAN', 'ok': None, 'detail': str(error)})
        try:
            self.run(['getent', 'ahostsv4', 'www.raspberrypi.com'], timeout=4)
            rows.append({'name': 'DNS', 'ok': True, 'detail': 'Namensaufloesung funktioniert.'})
        except Exception as error:
            rows.append({'name': 'DNS', 'ok': False, 'detail': str(error)})
        try:
            with self.connector(('1.1.1.1', 443), timeout=3):
                pass
            rows.append({'name': 'Internet', 'ok': True, 'detail': 'Externe TCP-Verbindung erreichbar.'})
        except OSError as error:
            rows.append({'name': 'Internet', 'ok': False, 'detail': str(error)})
        self.event('diagnostic', 'Netzwerktest: '+', '.join(row['name']+'='+str(row['ok']) for row in rows))
        return {'checks': rows}

    def cec_state(self):
        try:
            last = json.loads((self.system_root/'run/raspi-tv/cec-last-key.json').read_text())
        except (OSError, ValueError):
            last = None
        try:
            mapping = json.loads((self.config/'cec-mapping.json').read_text())
        except (OSError, ValueError):
            mapping = {}
        return {'last': last, 'mapping': mapping, 'actions': ACTIONS}

    def cec_save(self, data):
        code = int(data.get('code', 0))
        action = data.get('action')
        if not 1 <= code <= 767 or action not in set(ACTIONS) | {'default'}:
            raise ValueError('Ungueltige Taste oder Aktion.')
        mapping = self.cec_state()['mapping']
        if action == 'default':
            mapping.pop(str(code), None)
        else:
            mapping[str(code)] = action
        if len(mapping) > 64:
            raise ValueError('Maximal 64 eigene Tastenbelegungen.')
        self.ensure_shared_config()
        atomic_json(self.config/'cec-mapping.json', mapping)
        self.event('configuration', 'Fernbedienung: Taste '+str(code)+' -> '+action)
        return self.cec_state()

    def display_info(self):
        result = self.run(self.tv_args(['xrandr', '--query']), check=False)
        outputs, current = [], None
        for line in result.stdout.splitlines():
            connected = re.match(r'^(\S+) connected', line)
            if connected:
                current = {'output': connected.group(1), 'modes': [], 'current': None}
                outputs.append(current)
            elif re.match(r'^\S', line):
                current = None
            elif current:
                match = re.match(r'^\s+(\d+x\d+i?)\s+(.*)', line)
                if match:
                    for rate, flags in re.findall(r'(\d+(?:\.\d+)?)([*+ ]*)', match.group(2)):
                        mode = {'mode': match.group(1), 'rate': rate}
                        current['modes'].append(mode)
                        if '*' in flags:
                            current['current'] = mode
        return {'available': result.returncode == 0, 'outputs': outputs, 'pending': self.display_pending}

    def display_test(self, data):
        info = self.display_info()
        output = next((item for item in info['outputs'] if item['output'] == data.get('output')), None)
        choice = {'mode': data.get('mode'), 'rate': data.get('rate')}
        if not output or choice not in output['modes'] or not output['current']:
            raise ValueError('Bitte eine erkannte Aufloesung auswaehlen.')
        with self.lock:
            if self.display_pending:
                raise ValueError('Bitte den laufenden Bildtest zuerst bestaetigen oder abwarten.')
            self.run(self.tv_args(['xrandr', '--output', output['output'], '--mode', choice['mode'], '--rate', choice['rate']]))
            token = secrets.token_hex(12)
            self.display_pending = {'id': token, 'output': output['output'], 'mode': choice['mode'],
                                    'rate': choice['rate'], 'until': time.time()+20}
            previous = output['current']
        def revert():
            with self.lock:
                if self.display_pending and self.display_pending['id'] == token:
                    try:
                        self.run(self.tv_args(['xrandr', '--output', output['output'], '--mode', previous['mode'], '--rate', previous['rate']]))
                        self.event('configuration', 'Bildtest automatisch zurueckgesetzt.')
                    finally:
                        self.display_pending = None
        timer = threading.Timer(20, revert); timer.daemon = True; timer.start()
        return dict(self.display_pending)

    def display_confirm(self, token):
        with self.lock:
            value = self.display_pending
            if not value or value['id'] != token or time.time() > value['until']:
                raise ValueError('Bildtest abgelaufen.')
            self.ensure_shared_config()
            (self.config/'display-mode').write_text(value['output']+' '+value['mode']+' '+value['rate']+'\n')
            (self.config/'display-mode').chmod(0o644)
            self.display_pending = None
        self.event('configuration', 'Anzeige bestaetigt: '+value['mode']+' @ '+value['rate'])
        return {'ok': True}

    def audio_info(self):
        result = self.run(self.tv_args(['pw-dump']), check=False)
        if result.returncode:
            return {'available': False, 'outputs': []}
        objects = json.loads(result.stdout)
        outputs = []
        for item in objects:
            props = (item.get('info') or {}).get('props') or {}
            if item.get('type') == 'PipeWire:Interface:Node' and props.get('media.class') == 'Audio/Sink':
                outputs.append({'id': item['id'], 'name': props.get('node.description') or props.get('node.name')})
        return {'available': True, 'outputs': outputs}

    def audio_set(self, identifier):
        identifier = int(identifier)
        if identifier not in [item['id'] for item in self.audio_info()['outputs']]:
            raise ValueError('Unbekannter Audioausgang.')
        self.run(self.tv_args(['wpctl', 'set-default', str(identifier)]))
        self.event('configuration', 'Audioausgang geaendert: '+str(identifier))
        return {'ok': True}

    def audio_stop(self):
        with self.lock:
            if self.sound_process and self.sound_process.poll() is None:
                self.sound_process.terminate()
            self.sound_process = None
        return {'ok': True}

    def audio_test(self):
        audio = self.audio_info()
        if not audio['available'] or not audio['outputs']:
            raise ValueError('Der Audio-Dienst ist nicht erreichbar.')
        self.audio_stop()
        folder = tempfile.TemporaryDirectory(prefix='raspi-tv-tone-')
        os.chmod(folder.name, 0o755)
        path = Path(folder.name)/'test.wav'
        with wave.open(str(path), 'wb') as output:
            output.setparams((2, 2, 48000, 0, 'NONE', 'not compressed'))
            samples = bytearray()
            for frame in range(96000):
                value = int(2600*math.sin(2*math.pi*440*frame/48000))
                samples.extend(struct.pack('<hh', value, value))
            output.writeframes(samples)
        os.chmod(path, 0o644)
        try:
            process = self.spawn(self.tv_args(['pw-play', str(path)]), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            with self.lock:
                self.sound_process = process
        except Exception:
            folder.cleanup()
            raise
        def finish():
            try:
                process.wait(timeout=6)
            except subprocess.TimeoutExpired:
                process.kill(); process.wait()
            finally:
                folder.cleanup()
        threading.Thread(target=finish, daemon=True).start()
        return {'ok': True, 'seconds': 2}

    def storage_roots(self):
        return [('download', self.home/'Downloads'), ('cache', self.system_root/'var/cache/raspi-tv'),
                ('cache', self.home/'.cache/chromium'), ('cache', self.home/'.cache/chromium-browser'),
                ('cache', self.home/'.config/raspi-tv-browser/Default/Cache'),
                ('cache', self.home/'.config/raspi-tv-browser/Default/Code Cache')]

    @staticmethod
    def _no_links(path):
        return not any(part.is_symlink() for part in [path]+list(path.parents))

    def storage_scan(self):
        candidates, groups = {}, []
        for category, root in self.storage_roots():
            if not root.is_dir() or not self._no_links(root):
                continue
            size, count = 0, 0
            for directory, folders, files in os.walk(root, followlinks=False):
                folders[:] = [name for name in folders if not (Path(directory)/name).is_symlink()]
                for name in files:
                    path = Path(directory)/name
                    if path.is_symlink() or not path.is_file():
                        continue
                    try:
                        info = path.stat()
                    except OSError:
                        continue
                    relative = path.relative_to(root)
                    identifier = hashlib.sha256((str(path)+str(info.st_size)+str(info.st_mtime_ns)).encode()).hexdigest()[:24]
                    candidates[identifier] = {'id': identifier, 'root': root, 'relative': relative, 'size': info.st_size,
                                              'mtime': info.st_mtime_ns, 'inode': info.st_ino, 'category': category}
                    size += info.st_size; count += 1
                    if count >= 5000:
                        break
                if count >= 5000:
                    break
            groups.append({'path': str(root), 'bytes': size, 'files': count})
        with self.lock:
            self.files = candidates
        usage = shutil.disk_usage(self.state)
        largest = sorted(candidates.values(), key=lambda item: item['size'], reverse=True)[:100]
        return {'total': usage.total, 'free': usage.free, 'groups': groups,
                'files': [{'id': item['id'], 'name': str(item['relative']), 'category': item['category'], 'bytes': item['size']}
                          for item in largest]}

    def _delete_candidate(self, item):
        root, relative = item['root'], item['relative']
        if not self._no_links(root):
            raise ValueError('Verknuepfungen werden nicht geloescht.')
        if os.name == 'posix':
            fd = os.open(root.anchor, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try:
                for name in root.parts[1:] + relative.parts[:-1]:
                    newer = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                    os.close(fd); fd = newer
                info = os.stat(relative.name, dir_fd=fd, follow_symlinks=False)
                if not stat.S_ISREG(info.st_mode) or (info.st_ino, info.st_size, info.st_mtime_ns) != (item['inode'], item['size'], item['mtime']):
                    raise ValueError('Datei wurde veraendert; bitte erneut suchen.')
                os.unlink(relative.name, dir_fd=fd)
            finally:
                os.close(fd)
        else:
            path = root/relative
            if not self._no_links(path) or not path.resolve().is_relative_to(root.resolve()):
                raise ValueError('Ungueltiger Speicherpfad.')
            info = path.stat()
            if (info.st_ino, info.st_size, info.st_mtime_ns) != (item['inode'], item['size'], item['mtime']):
                raise ValueError('Datei wurde veraendert.')
            path.unlink()

    def storage_delete(self, identifiers):
        if not isinstance(identifiers, list) or not 0 < len(identifiers) <= 100 or len(set(identifiers)) != len(identifiers):
            raise ValueError('Bitte 1 bis 100 angezeigte Dateien auswaehlen.')
        with self.lock:
            if any(identifier not in self.files for identifier in identifiers):
                raise ValueError('Dateiliste nicht mehr aktuell.')
            items = [self.files[identifier] for identifier in identifiers]
            deleted, errors = 0, []
            for identifier, item in zip(identifiers, items):
                try:
                    self._delete_candidate(item)
                    deleted += item['size']
                    self.files.pop(identifier, None)
                except (OSError, ValueError) as error:
                    errors.append(str(error))
        self.event('cleanup', str(deleted)+' Bytes ausgewaehlter Cache-/Download-Dateien geloescht.')
        return {'deleted': deleted, 'errors': errors}

    def _capacity(self, archive):
        with zipfile.ZipFile(archive) as package:
            expanded = sum(item.file_size for item in package.infolist())
        installed = sum(path.stat().st_size for path in self.root.rglob('*') if path.is_file() and not path.is_symlink())
        needed = expanded*2 + installed + 128*1024*1024
        free = shutil.disk_usage(self.state).free
        if free < needed:
            raise ValueError('Nicht genug Speicher: benoetigt '+str(needed//1048576)+' MiB, frei '+str(free//1048576)+' MiB.')
        return needed, free

    def _sandbox_install(self, source, target, workspace):
        command = ['systemd-run', '--wait', '--pipe', '--collect', '--quiet',
                   '--unit=raspi-tv-preflight-'+secrets.token_hex(8),
                   '--property=ProtectSystem=strict', '--property=ProtectHome=yes',
                   '--property=PrivateDevices=yes', '--property=PrivateNetwork=yes',
                   # systemd-run forwards "none" as an address-family name; the
                   # manager rejects it with EINVAL. Block socket I/O directly.
                   '--property=SystemCallFilter=~@network-io',
                   '--property=SystemCallErrorNumber=EPERM',
                   '--property=NoNewPrivileges=yes', '--property=CapabilityBoundingSet=',
                   '--property=ProtectKernelTunables=yes', '--property=ProtectControlGroups=yes',
                   '--property=RestrictSUIDSGID=yes', '--property=RuntimeMaxSec=60',
                   '--property=ReadWritePaths='+str(workspace),
                   '/bin/bash', str(source/'system/install-files.sh'), str(source), str(target)]
        return self.run(command, timeout=75).stdout[-16000:]

    def preflight(self):
        with self.preflight_lock:
            archive = self.state/'update.zip'
            payload = archive.read_bytes()
            if len(payload) > 300*1024*1024:
                raise ValueError('Update ist zu gross.')
            prefix, version = self.inspect_update(io.BytesIO(payload))
            needed, free = self._capacity(io.BytesIO(payload))
            digest = hashlib.sha256(payload).hexdigest()
            if self.preflight_result and self.preflight_result['sha256'] == digest:
                return dict(self.preflight_result, free=free)
            with tempfile.TemporaryDirectory(prefix='dry-run-', dir=str(self.state)) as folder:
                workspace = Path(folder)
                unpacked, target = workspace/'source', workspace/'rootfs'
                unpacked.mkdir()
                with zipfile.ZipFile(io.BytesIO(payload)) as package:
                    package.extractall(unpacked)
                source = unpacked/prefix
                steps = ['ZIP und freier Speicher geprueft']
                for path in source.rglob('*.py'):
                    ast.parse(path.read_text(encoding='utf-8-sig'), filename=str(path))
                steps.append('Python-Dateien syntaktisch geprueft')
                for path in list(source.rglob('*.sh')) + [source/'user/xinitrc', source/'user/bash_profile']:
                    if not path.is_file():
                        raise ValueError('Startdatei fehlt: '+str(path.relative_to(source)))
                    content = path.read_bytes()
                    if b'\r' in content or content.startswith(b'\xef\xbb\xbf'):
                        raise ValueError('Linux-Zeilenenden fehlen: '+str(path.relative_to(source)))
                    self.run(['/bin/bash', '--noprofile', '--norc', '-n', str(path)])
                steps.append('Shell-Dateien und Linux-Zeilenenden geprueft')
                (target/'etc/systemd/system').mkdir(parents=True)
                output = self._sandbox_install(source, target, workspace)
                for name in ['opt/raspi-tv/launcher/index.html', 'opt/raspi-tv/VERSION', 'opt/raspi-tv/start-browser.sh',
                             'etc/systemd/system/raspi-tv-ctl.service']:
                    if not (target/name).is_file():
                        raise ValueError('Probelauf hat eine benoetigte Datei nicht installiert: '+name)
                steps.append('Installation im geschuetzten Testverzeichnis erfolgreich')
                result = {'ok': True, 'version': version, 'sha256': digest, 'needed': needed,
                          'free': free, 'steps': steps, 'output': self.redact(output)}
            self.preflight_result = result
            self.event('update-test', 'Probelauf fuer Version '+version+' bestanden.')
            return result

    def system_info(self):
        usage = shutil.disk_usage(self.state)
        return {'os': platform.system(), 'kernel': platform.release(),
                'architecture': platform.machine(), 'python': platform.python_version(),
                'disk_total': usage.total, 'disk_free': usage.free}

    def report(self):
        identifier = secrets.token_hex(12)
        report = self.redact({'at': time.time(), 'version': self.version(), 'diagnostics': self.diagnostics(),
                              'timeline': self.timeline()['events'], 'safe_mode': self.safe_status(), 'system': self.system_info()})
        folder = self.state/'reports'
        folder.mkdir(exist_ok=True)
        atomic_json(folder/(identifier+'.json'), report)
        old = sorted(folder.glob('*.json'), key=lambda item: item.stat().st_mtime, reverse=True)
        for path in old[20:]:
            path.unlink()
        addresses = self.run(['hostname', '-I'], check=False).stdout.split()
        address = next((item for item in addresses if self._lan_ip(item)), None)
        host = '['+address+']' if address and ':' in address else address
        url = 'http://'+host+':8767/#report='+identifier if host else None
        return {'id': identifier, 'url': url, 'report': report}

    @staticmethod
    def _lan_ip(value):
        try:
            address = ipaddress.ip_address(value)
            return not (address.is_loopback or address.is_link_local or address.is_unspecified)
        except ValueError:
            return False

    def support_zip(self):
        report = self.redact({'version': self.version(), 'diagnostics': self.diagnostics(),
                              'timeline': self.timeline()['events'], 'safe_mode': self.safe_status(), 'system': self.system_info()})
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as archive:
            archive.writestr('diagnose.json', json.dumps(report, ensure_ascii=False, indent=2))
            archive.writestr('raspi-tv-display-test.json', json.dumps(self.round_test_status(), ensure_ascii=False, indent=2))
            with self.lock:
                display = self.tasks.get('round-displays', {}).get('result')
            if display and isinstance(display.get('report'), str):
                archive.writestr('raspi-tv-display-diagnose.txt', self.redact(display['report']))
            archive.writestr('HINWEIS.txt', 'Raspi-TV Support-Paket. Zugangsdaten, Browserprofile und Terminalausgaben werden nicht exportiert.\n')
        return buffer.getvalue()

    def usb_targets(self):
        roots, errors = self.usb_roots()
        drives = {}
        for root, label in roots:
            root = Path(root).resolve()
            identifier = hashlib.sha256(str(root).encode()).hexdigest()[:24]
            drives[identifier] = (root, label)
        self.drives = drives
        return {'drives': [{'id': key, 'name': value[1]} for key, value in drives.items()], 'errors': errors}

    def support_export(self, identifier):
        self.usb_targets()
        if identifier not in self.drives:
            raise ValueError('Bitte einen erkannten USB-Stick auswaehlen.')
        root, label = self.drives[identifier]
        options = self.run(['findmnt', '-n', '-o', 'OPTIONS', '--target', str(root)]).stdout.strip().split(',')
        read_only = 'ro' in options
        data = self.support_zip()
        if shutil.disk_usage(root).free < len(data)+5*1024*1024:
            raise ValueError('Nicht genug Speicher auf dem USB-Stick.')
        name = 'raspi-tv-support-'+time.strftime('%Y%m%d-%H%M%S')+'-'+secrets.token_hex(3)+'.zip'
        try:
            if read_only:
                self.run(['mount', '-o', 'remount,rw', str(root)])
            flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0)
            fd = os.open(root/name, flags, 0o600)
            if hasattr(os, 'fchmod'):
                os.fchmod(fd, 0o644)
            with os.fdopen(fd, 'wb') as output:
                output.write(data); output.flush(); os.fsync(output.fileno())
        finally:
            if read_only:
                self.run(['mount', '-o', 'remount,ro', str(root)])
        self.event('support', 'Bereinigtes Support-Paket auf USB exportiert.')
        return {'name': name, 'device': label}

    def round_display_diagnostics(self):
        import importlib.util
        spec = importlib.util.spec_from_file_location('raspitv_display_diagnostics', self.root/'display-diagnostics.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        def command(args, timeout=5, **kwargs):
            return self.run(args, timeout=timeout, check=False)
        report = self.redact(module.collect(self.system_root, run=command))
        return {'report': report, 'created': time.strftime('%Y-%m-%d %H:%M:%S')}

    def round_test_file(self, name):
        path = self.system_root/'run/raspi-tv-round'/name
        try:
            with path.open(encoding='utf-8') as stream:
                data = json.loads(stream.read(4096))
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def round_test_status(self):
        request = self.round_test_file('test-request.json')
        if not request:
            return {'phase': 'idle', 'active': False, 'remaining': 0}
        number = request.get('display', 2)
        now = time.monotonic()
        status = self.round_test_file('test-status.json')
        if status.get('id') == request.get('id') and status.get('display', 2) == number:
            phase = status.get('phase')
            if phase in ('finished', 'error'):
                return {'phase': phase, 'active': False, 'remaining': 0, 'display': number, 'error': self.redact(status.get('error'))}
            until = status.get('until', 0)
            if phase == 'running' and isinstance(until, (int, float)) and math.isfinite(until) and now < until + 10:
                return {'phase': 'stopping' if request.get('cancel') or now >= until else 'running',
                        'active': True, 'remaining': max(0, math.ceil(until-now)), 'display': number}
        expires = request.get('expires', 0)
        if isinstance(expires, (int, float)) and math.isfinite(expires) and now <= expires:
            return {'phase': 'pending', 'active': True, 'remaining': 0, 'display': number}
        return {'phase': 'error', 'active': False, 'remaining': 0, 'display': number,
                'error': 'Keine aktuelle Bestätigung vom Display-Dienst. Bitte erneut versuchen oder eine Diagnose starten.'}

    def round_test(self, cancel=False, number=2):
        with self.lock:
            folder = self.system_root/'run/raspi-tv-round'
            current = self.round_test_status()
            if cancel:
                if current['active']:
                    request = self.round_test_file('test-request.json')
                    request['cancel'] = True
                    atomic_json(folder/'test-request.json', request)
                return self.round_test_status()
            if current['active']:
                return current
            if not (self.system_root/'var/lib/raspi-tv-round/enabled-separate-pins').is_file():
                raise ValueError('Die runden Displays sind noch nicht aktiviert.')
            result = self.run(['systemctl', 'is-active', 'raspi-tv-round.service'], check=False)
            if result.returncode or result.stdout.strip() != 'active' or not folder.is_dir():
                raise ValueError('Der Display-Dienst läuft nicht. Bitte zuerst die Display-Diagnose starten.')
            atomic_json(folder/'test-request.json', {'id': secrets.token_hex(12), 'expires': time.monotonic()+10, 'cancel': False, 'display': number})
            return self.round_test_status()

    def get(self, path, query):
        if path == '/maintenance/round-display-test':
            return self.round_test_status()
        if path == '/maintenance/status':
            with self.lock:
                tasks = json.loads(json.dumps(self.tasks))
            return {'safe': self.safe_status(), 'tasks': tasks}
        if path == '/maintenance/timeline':
            return self.timeline()
        if path == '/maintenance/cec':
            return self.cec_state()
        if path == '/maintenance/display':
            return self.display_info()
        if path == '/maintenance/audio':
            return self.audio_info()
        if path == '/maintenance/usb':
            return self.usb_targets()
        if path == '/maintenance/support.zip':
            return self.support_zip()
        if path == '/maintenance/report':
            identifier = query.get('id', [''])[0]
            if not re.fullmatch(r'[0-9a-f]{24}', identifier):
                raise ValueError('Ungueltiger Bericht.')
            return self.redact(json.loads((self.state/'reports'/(identifier+'.json')).read_text(encoding='utf-8')))
        raise ValueError('Unbekannte Wartungsfunktion.')

    def post(self, path, data):
        if self.job().get('running') and path not in ('/maintenance/network', '/maintenance/report', '/maintenance/support-export'):
            raise ValueError('Bitte die laufende Installation abwarten.')
        if path == '/maintenance/network':
            return self.task('network', self.network)
        if path == '/maintenance/round-display-test':
            action = data.get('action')
            if action not in ('start', 'stop') or set(data) - ({'action', 'display'} if action == 'start' else {'action'}):
                raise ValueError('Ungültiger Display-Test.')
            number = data.get('display', 2)
            if type(number) is not int or number not in (1, 2):
                raise ValueError('Bitte Display 1 oder Display 2 auswählen.')
            return self.round_test(cancel=action == 'stop', number=number)
        if path == '/maintenance/round-displays':
            return self.task('round-displays', self.round_display_diagnostics)
        if path == '/maintenance/preflight':
            return self.task('preflight', self.preflight)
        if path == '/maintenance/storage-scan':
            return self.task('storage', self.storage_scan)
        if path == '/maintenance/storage-delete':
            return self.storage_delete(data.get('ids'))
        if path == '/maintenance/safe':
            if not isinstance(data.get('enabled'), bool):
                raise ValueError('Ungueltiger Startmodus.')
            return self.safe_set(data['enabled'])
        if path == '/maintenance/restart-browser':
            return self.restart_browser()
        if path == '/maintenance/cec':
            return self.cec_save(data)
        if path == '/maintenance/display-test':
            return self.display_test(data)
        if path == '/maintenance/display-confirm':
            return self.display_confirm(data.get('id'))
        if path == '/maintenance/audio':
            return self.audio_set(data.get('id'))
        if path == '/maintenance/audio-test':
            return self.audio_test()
        if path == '/maintenance/audio-stop':
            return self.audio_stop()
        if path == '/maintenance/report':
            return self.report()
        if path == '/maintenance/support-export':
            return self.support_export(data.get('id'))
        raise ValueError('Unbekannte Wartungsfunktion.')
