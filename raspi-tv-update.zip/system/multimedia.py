"""Audio metering, LAN WebRTC signalling and a fail-safe virtual gamepad."""
import array
import math
import os
import secrets
import shutil
import subprocess
import sys
import threading
import time

BANDS = (63, 100, 160, 250, 400, 630, 1000, 1600, 2500, 3200)


def spectrum(pcm, rate=8000):
    samples = array.array('h')
    samples.frombytes(pcm[:len(pcm)//2*2])
    if sys.byteorder != 'little': samples.byteswap()
    n = len(samples)
    if n < 2: return {'level': 0, 'bands': [0]*len(BANDS)}
    values = [v/32768 for v in samples]
    rms = math.sqrt(sum(v*v for v in values)/n)
    window = [v*(.5-.5*math.cos(2*math.pi*i/(n-1))) for i,v in enumerate(values)]
    result = []
    for hz in BANDS:
        coeff = 2*math.cos(2*math.pi*hz/rate)
        s1 = s2 = 0.
        for value in window:
            s = value + coeff*s1 - s2
            s2, s1 = s1, s
        magnitude = math.sqrt(max(0, s1*s1+s2*s2-coeff*s1*s2))*4/n
        result.append(round(min(1, math.sqrt(magnitude)*2), 4))
    return {'level': round(min(1,rms*3),4), 'bands': result}


class AudioMeter:
    def __init__(self, namespace):
        self.ns = namespace
        self.lock = threading.Lock()
        self.process = None
        self.last_request = 0
        self.started = False
        self.sample_at = 0
        self.data = {'level':0, 'bands':[0]*len(BANDS)}
        self.error = ''
        self.retry_at = 0

    def poll(self):
        with self.lock:
            self.last_request = time.monotonic()
            if not self.started and time.monotonic() >= self.retry_at:
                self.started = True
                threading.Thread(target=self.run,daemon=True).start()
            data = dict(self.data)
            data.update(available=bool(self.process and self.process.poll() is None),
                        fresh=time.monotonic()-self.sample_at < 1, error=self.error)
            return data

    def run(self):
        try:
            if not shutil.which('parec'):
                raise RuntimeError('Audio-Monitor fehlt. Bitte das vollständige Update installieren.')
            import pwd
            user = self.ns.get('TV_USER','tv')
            uid = pwd.getpwnam(user).pw_uid
            argv = ['runuser','-u',user,'--','env',f'XDG_RUNTIME_DIR=/run/user/{uid}',
                    f'PULSE_SERVER=unix:/run/user/{uid}/pulse/native','parec',
                    '--device=@DEFAULT_MONITOR@','--format=s16le','--rate=8000','--channels=1','--latency-msec=80']
            proc = subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
            with self.lock:
                self.process = proc
                self.error = ''
            def watchdog():
                while proc.poll() is None:
                    time.sleep(.5)
                    if time.monotonic()-self.last_request > 4:
                        try: proc.terminate()
                        except ProcessLookupError: pass
                        return
            threading.Thread(target=watchdog,daemon=True).start()
            while True:
                raw = proc.stdout.read(512)
                if not raw: break
                data = spectrum(raw)
                with self.lock:
                    self.data = data
                    self.sample_at = time.monotonic()
            if time.monotonic()-self.last_request <= 4:
                raise RuntimeError('Kein Zugriff auf den Audio-Ausgang. PipeWire/PulseAudio prüfen.')
        except Exception as error:
            with self.lock: self.error = str(error)
        finally:
            proc = self.process
            if proc:
                if proc.poll() is None: proc.terminate()
                try: proc.wait(timeout=2)
                except subprocess.TimeoutExpired: proc.kill();proc.wait(timeout=2)
                if proc.stdout: proc.stdout.close()
            with self.lock:
                self.process = None
                self.started = False
                self.retry_at = time.monotonic()+3
                self.data = {'level':0,'bands':[0]*len(BANDS)}


class Mirror:
    def __init__(self, navigate, clock=time.monotonic):
        self.lock = threading.Lock()
        self.navigate = navigate
        self.clock = clock
        self.session = None

    def request(self, data, viewer=False):
        action = data.get('action','poll')
        now = self.clock()
        with self.lock:
            s = self.session
            if s and (now-s['pc_at'] > 25 or now-s['tv_at'] > 90): self.session=s=None
            if action == 'create':
                if viewer: raise ValueError('Nur der PC darf eine Übertragung starten.')
                if s: raise ValueError('Es läuft bereits eine Bildschirmübertragung. Zuerst beenden.')
                identifier = secrets.token_urlsafe(24)
                self.session = {'id':identifier,'offer':None,'answer':None,'pc_at':now,'tv_at':now}
                self.navigate('http://127.0.0.1:8765/mirror.html#'+identifier)
                return {'id':identifier}
            if not s or not secrets.compare_digest(str(data.get('id','')).encode(),s['id'].encode()):
                return {'ended':True}
            s['tv_at' if viewer else 'pc_at'] = now
            if action == 'stop':
                self.session = None
                return {'ended':True}
            if action in ('offer','answer'):
                if (action == 'offer' and viewer) or (action == 'answer' and not viewer):
                    raise ValueError('Ungültige Signalisierungsrichtung.')
                value = data.get('sdp')
                if not isinstance(value,str) or not value.startswith('v=0') or len(value)>24000:
                    raise ValueError('Ungültige WebRTC-Beschreibung.')
                if s[action] is not None and s[action] != value:
                    raise ValueError('Diese Verbindung wurde bereits ausgehandelt.')
                s[action] = value
            elif action != 'poll': raise ValueError('Unbekannter Bildschirm-Befehl.')
            return {'ended':False,'offer':s['offer'] if viewer else None,'answer':s['answer'] if not viewer else None}


BUTTON_NAMES = {'a':'BTN_SOUTH','b':'BTN_EAST','x':'BTN_WEST','y':'BTN_NORTH',
                'l':'BTN_TL','r':'BTN_TR','select':'BTN_SELECT','start':'BTN_START'}
DIRECTIONS = {'up','down','left','right'}


class Gamepad:
    def __init__(self, factory=None, clock=time.monotonic):
        self.factory = factory
        self.clock = clock
        self.lock = threading.Lock()
        self.device = None
        self.owner = None
        self.last = 0
        self.seq = -1
        self.pressed = set()
        self.axes = [0,0]
        self.thread_started = False
        self.sequences = {}

    def ensure(self):
        if self.device: return
        if self.factory:
            self.device, self.codes = self.factory()
        else:
            try:
                from evdev import UInput, AbsInfo, ecodes as e
            except ImportError: raise ValueError('Gamepad-Eingabe ist auf diesem System nicht verfügbar.')
            buttons = [getattr(e,name) for name in BUTTON_NAMES.values()]
            self.device = UInput({e.EV_KEY:buttons,e.EV_ABS:[(e.ABS_X,AbsInfo(0,-32767,32767,0,3000,0)),
                (e.ABS_Y,AbsInfo(0,-32767,32767,0,3000,0)),(e.ABS_HAT0X,AbsInfo(0,-1,1,0,0,0)),
                (e.ABS_HAT0Y,AbsInfo(0,-1,1,0,0,0))]},name='Raspi-TV Handy Gamepad',vendor=0x1209,product=0x5254)
            self.codes = e
        self.pressed=set()
        self.axes=[0,0]
        if not self.thread_started:
            self.thread_started = True
            threading.Thread(target=self.watchdog,daemon=True).start()

    def emit(self, buttons, axes):
        e = self.codes
        for key in (self.pressed | buttons) - DIRECTIONS:
            if (key in buttons) != (key in self.pressed):
                self.device.write(e.EV_KEY,getattr(e,BUTTON_NAMES[key]),int(key in buttons))
        x = int('right' in buttons)-int('left' in buttons)
        y = int('down' in buttons)-int('up' in buttons)
        self.device.write(e.EV_ABS,e.ABS_HAT0X,x)
        self.device.write(e.EV_ABS,e.ABS_HAT0Y,y)
        for code,value in zip((e.ABS_X,e.ABS_Y),axes): self.device.write(e.EV_ABS,code,round(value*32767))
        self.device.syn()
        self.pressed, self.axes = set(buttons),list(axes)

    def request(self,data):
        client = data.get('client')
        buttons,axes,seq = data.get('buttons',[]),data.get('axes',[0,0]),data.get('seq',0)
        if not isinstance(client,str) or not 8<=len(client)<=80: raise ValueError('Ungültige Controller-ID.')
        if not isinstance(seq,int) or isinstance(seq,bool) or seq<0: raise ValueError('Ungültige Controller-Sequenz.')
        if not isinstance(buttons,list) or len(buttons)>12 or any(not isinstance(k,str) or k not in set(BUTTON_NAMES)|DIRECTIONS for k in buttons):
            raise ValueError('Ungültige Controller-Tasten.')
        if not isinstance(axes,list) or len(axes)!=2 or any(isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) or not -1<=x<=1 for x in axes):
            raise ValueError('Ungültige Controller-Achsen.')
        with self.lock:
            self.release_expired()
            if self.owner and self.owner!=client: raise ValueError('Ein anderes Handy steuert diesen Controller.')
            self.ensure()
            if seq <= self.sequences.get(client,(-1,0))[0]: return {'ok':True,'ignored':True}
            if len(self.sequences)>128:
                self.sequences={k:v for k,v in self.sequences.items() if self.clock()-v[1]<30}
                if len(self.sequences)>128: raise ValueError('Zu viele Controller-Sitzungen.')
            self.sequences[client]=(seq,self.clock())
            self.owner,self.last,self.seq=client,self.clock(),seq
            self.emit(set(buttons),axes)
            if not buttons and axes==[0,0]: self.owner=None
            return {'ok':True}

    def release_expired(self):
        if self.owner and self.clock()-self.last>1:
            self.emit(set(),[0,0]);self.owner=None

    def watchdog(self):
        while True:
            time.sleep(.2)
            try:
                with self.lock:self.release_expired()
            except OSError:
                with self.lock:
                    self.owner=None;self.device=None;self.thread_started=False
                return
