#!/bin/bash
# Bestehende Kiosk-Sitzung verwenden; ein neuer Browser laedt ebenfalls die Systemerweiterung.
BROWSER="$(command -v chromium-browser || command -v chromium)"
EXTENSION_ARGS=(--load-extension=/opt/raspi-tv/extension)
if [ "$(python3 /opt/raspi-tv/browser-guard.py mode 2>/dev/null)" = safe ]; then
  EXTENSION_ARGS=(--disable-extensions)
fi
exec "$BROWSER" --user-data-dir="$HOME/.config/raspi-tv-browser" \
  --kiosk --start-fullscreen --no-first-run --no-default-browser-check \
  "${EXTENSION_ARGS[@]}" "http://127.0.0.1:8767/local"
