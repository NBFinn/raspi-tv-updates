#!/usr/bin/env python3
"""Raspi-TV: Notfall-Abschaltung bei Stromausfall.

Ein Raspberry Pi verliert bei einem Stromausfall sofort die Spannung – herunterfahren kann er nur, wenn
eine kleine Notstromversorgung (USV-Aufsatz, Akku- oder Kondensator-Modul) ihn noch ein paar Sekunden
versorgt und per GPIO-Pin meldet „Netzstrom weg“. Dieser Dienst prüft den Pin alle 10 ms; meldet er
länger als die Entprellzeit „Strom weg“, schreibt er sofort alles auf die Karte (sync) und fährt den Pi
herunter. Läuft der Pi nach 20 s noch, wird hart (aber mit sauber eingehängter Karte) abgeschaltet.

Seit 7.8.1 geht es auch ganz ohne Kabel (nur Pi 5): Hängt der Pi an einem Akku-Modul, sinkt seine
Eingangsspannung, sobald nur noch der Akku liefert. Der Pi 5 misst diese Spannung selbst (EXT5V_V).
Einmal mit Netzteil und einmal nur mit Akku einmessen – die Schwelle liegt dann in der Mitte. Ausgelöst
wird erst, wenn die Spannung eine halbe Sekunde lang darunter bleibt (kurze Einbrüche bei Last zählen nicht).

Einstellungen (config.json → "powerfail"):
  {"on": true, "source": "gpio"|"voltage", "pin": 6, "lost": "low"|"high", "pull": "up"|"down"|"none",
   "v_mains": 5.15, "v_batt": 4.95}
"""
import glob
import json
import os
import re
import shutil
import statistics
import subprocess
import sys
import time

CONFIG = "/var/lib/raspi-tv/config.json"
STATUS = "/run/raspi-tv-powerfail.json"
EVENT = "/var/lib/raspi-tv/powerfail-event.json"
POLL = 0.01
DEBOUNCE = 0.05                      # 50 ms – kurze Störungen auf der Leitung lösen nichts aus
HARD_AFTER = 20
PAUSE = "/run/raspi-tv-powerfail-pause"   # beim Einmessen „nur Akku“: so lange nicht abschalten
V_POLL = 0.1
V_HOLD = 0.5                         # Spannung muss 0,5 s unter der Schwelle bleiben
V_ARM = 10                           # erst scharf nach 10 s über der Schwelle
MIN_GAP = 0.08                       # Netzteil und Akku müssen sich mindestens so deutlich unterscheiden


def cfg():
    try:
        with open(CONFIG) as f:
            p = json.load(f).get("powerfail") or {}
    except (OSError, ValueError):
        p = {}
    pin = p.get("pin", 6)
    vm, vb = p.get("v_mains"), p.get("v_batt")
    thr = None
    if isinstance(vm, (int, float)) and isinstance(vb, (int, float)) and vm - vb >= MIN_GAP:
        thr = round((vm + vb) / 2, 3)
    return {"on": p.get("on") is True, "pin": pin if type(pin) is int and 2 <= pin <= 27 else 6,
            "source": "voltage" if p.get("source") == "voltage" else "gpio", "fast": p.get("fast") is not False,
            "lost": "high" if p.get("lost") == "high" else "low",
            "pull": p.get("pull") if p.get("pull") in ("up", "down", "none") else "up", "threshold": thr}


def read_volt():
    """Eingangsspannung des Pi 5 (EXT5V_V). None bei älteren Pis oder Fehler."""
    try:
        out = subprocess.run(["vcgencmd", "pmic_read_adc", "EXT5V_V"], capture_output=True, text=True, timeout=2).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    m = re.search(r"=\s*([\d.]+)\s*V", out)
    return float(m.group(1)) if m else None


def paused():
    try:
        return time.time() - os.path.getmtime(PAUSE) < 60
    except OSError:
        return False


def write_status(**kw):
    kw["at"] = time.time()
    try:
        with open(STATUS + ".tmp", "w") as f:
            json.dump(kw, f)
        os.replace(STATUS + ".tmp", STATUS)
    except OSError:
        pass


class Pin:
    """Liest einen GPIO-Eingang über libgpiod (Python-Anbindung Version 1 oder 2)."""

    def __init__(self, pin, pull):
        import gpiod
        self.g = gpiod
        self.pin = pin
        chip = self.header_chip()
        if hasattr(gpiod, "request_lines"):                       # Version 2
            from gpiod.line import Bias, Direction
            bias = {"up": Bias.PULL_UP, "down": Bias.PULL_DOWN, "none": Bias.DISABLED}[pull]
            self.req = gpiod.request_lines(chip, consumer="raspi-tv-powerfail",
                                           config={pin: gpiod.LineSettings(direction=Direction.INPUT, bias=bias)})
            from gpiod.line import Value
            self.read = lambda: self.req.get_value(pin) == Value.ACTIVE
            self.close = self.req.release
        else:                                                     # Version 1
            c = gpiod.Chip(chip)
            line = c.get_line(pin)
            flags = {"up": getattr(gpiod, "LINE_REQ_FLAG_BIAS_PULL_UP", 0), "down": getattr(gpiod, "LINE_REQ_FLAG_BIAS_PULL_DOWN", 0),
                     "none": getattr(gpiod, "LINE_REQ_FLAG_BIAS_DISABLE", 0)}[pull]
            line.request(consumer="raspi-tv-powerfail", type=gpiod.LINE_REQ_DIR_IN, flags=flags)
            self.read = lambda: line.get_value() == 1
            self.close = line.release

    def header_chip(self):
        """Der GPIO-Baustein der Stiftleiste (Pi 5: pinctrl-rp1, ältere: pinctrl-bcm2711/bcm2835)."""
        best = None
        for dev in sorted(glob.glob("/dev/gpiochip*")):
            try:
                if hasattr(self.g, "request_lines"):
                    with self.g.Chip(dev) as c:
                        label = c.get_info().label
                else:
                    label = self.g.Chip(dev).label()
            except Exception:  # noqa: BLE001
                continue
            if label == "pinctrl-rp1" or label.startswith(("pinctrl-bcm2711", "pinctrl-bcm2835", "pinctrl-bcm2712")):
                if label == "pinctrl-rp1" or best is None:
                    best = dev
        return best or "/dev/gpiochip0"


def sysrq(keys, pause=0.3):
    for c in keys:
        try:
            with open("/proc/sysrq-trigger", "w") as f:
                f.write(c)
        except OSError:
            pass
        time.sleep(pause)


def usb_off():
    """7.8.3: Alle USB-Anschlüsse sofort stromlos schalten (spart Strom aus dem Akku-Modul, angeschlossene
    Geräte gehen sofort aus). Pi 5: die vier Anschlüsse hängen gemeinsam an Hub 2 und 4 (je nach System
    auch 3 und 5) – erst wenn alle aus sind, fällt die 5 V weg. Pi 4: Hub 1-1 und 2. uhubctl ohne Ortsangabe nimmt alle schaltbaren Hubs."""
    if not shutil.which("uhubctl"):
        return []
    try:
        return [subprocess.Popen(["uhubctl", "-a", "0", "-N"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)]
    except OSError:
        return []


def shutdown(fast=True):
    """Sofort alles auf die Karte schreiben und herunterfahren.
    fast (Standard seit 7.8.2): für schwache Akku-Module, die den Pi nur ein, zwei Sekunden halten –
    Browser anhalten (spart Strom), alles schreiben, Karte schreibgeschützt einhängen, sofort aus.
    Dauert unter einer Sekunde. Sonst: normales Herunterfahren (5–15 s, braucht eine gute USV)."""
    usb = usb_off()
    try:
        subprocess.run(["pkill", "-STOP", "-f", "raspi-tv-browser"], timeout=1)
    except (OSError, subprocess.SubprocessError):
        pass
    os.sync()
    for p in usb:                         # USB-Abschaltung höchstens kurz abwarten
        try:
            p.wait(timeout=0.4)
        except (OSError, subprocess.SubprocessError):
            pass
    try:
        with open(EVENT, "w") as f:
            json.dump({"at": int(time.time())}, f)
            f.flush()
            os.fsync(f.fileno())
    except OSError:
        pass
    os.sync()
    if fast:
        print("Stromausfall gemeldet – Raspi-TV schaltet sofort aus", flush=True)
        sysrq("su", 0.25)
        sysrq("o", 1)
    print("Stromausfall gemeldet – Raspi-TV fährt herunter", flush=True)
    subprocess.Popen(["systemctl", "poweroff", "--no-block"])
    time.sleep(HARD_AFTER)
    # immer noch an: Karte schreibgeschützt einhängen und hart ausschalten
    print("Herunterfahren dauert zu lange – schalte sofort aus", flush=True)
    sysrq("suo")


def watch_voltage(c):
    """Spannungs-Modus: läuft 5 s, dann werden die Einstellungen neu gelesen."""
    thr = c["threshold"]
    global V_ARMED
    hist, next_status = VS["hist"], 0
    end = time.monotonic() + 5
    while time.monotonic() < end:
        v = read_volt()
        now = time.monotonic()
        if v is None:
            write_status(on=True, source="voltage", error="Spannung lässt sich nicht messen (nur Raspberry Pi 5)")
            time.sleep(10)
            return
        hist[:] = (hist + [v])[-5:]
        med = statistics.median(hist)
        if thr is None:
            if now >= next_status:
                write_status(on=True, source="voltage", volt=round(med, 3), need_learn=True)
                next_status = now + 0.5
            time.sleep(V_POLL)
            continue
        low = med < thr
        if not low:
            VS["low_since"] = None
            if VS["ok_since"] is None:
                VS["ok_since"] = now
            if not V_ARMED and now - VS["ok_since"] >= V_ARM:
                V_ARMED = True
        else:
            VS["ok_since"] = None
            if VS["low_since"] is None:
                VS["low_since"] = now
            if V_ARMED and not paused() and now - VS["low_since"] >= V_HOLD:
                write_status(on=True, source="voltage", volt=round(med, 3), power=False, shutting_down=True)
                shutdown(c["fast"])
                sys.exit(0)
        if now >= next_status:
            write_status(on=True, source="voltage", volt=round(med, 3), threshold=thr, power=not low,
                         armed=V_ARMED, paused=paused())
            next_status = now + 0.5
        time.sleep(V_POLL)


V_ARMED = False
VS = {"hist": [], "low_since": None, "ok_since": None}   # bleibt über die 5-s-Runden erhalten


def main():
    global V_ARMED
    pin = None
    current = None
    armed = False
    while True:
        c = cfg()
        if c["on"] and c["source"] == "voltage":
            if pin:
                pin.close()
                pin = None
                current = None
            watch_voltage(c)
            continue
        V_ARMED = False
        if not c["on"]:
            if pin:
                pin.close()
                pin = None
            write_status(on=False)
            armed = False
            time.sleep(5)
            continue
        if pin is None or current != (c["pin"], c["pull"]):
            if pin:
                pin.close()
            try:
                pin = Pin(c["pin"], c["pull"])
                current = (c["pin"], c["pull"])
                armed = False
            except Exception as e:  # noqa: BLE001
                write_status(on=True, error=f"GPIO {c['pin']} lässt sich nicht lesen: {e}")
                pin = None
                time.sleep(10)
                continue
        lost_since = None
        # Erst scharf, wenn der Pin 3 s lang „Strom da“ gemeldet hat – ein falsch eingestellter oder offener
        # Pin kann so nie eine Schleife aus Hochfahren und sofortigem Herunterfahren auslösen.
        ok_since = None
        next_cfg = time.monotonic() + 5
        next_status = 0
        while time.monotonic() < next_cfg:
            high = pin.read()
            lost = high if c["lost"] == "high" else not high
            now = time.monotonic()
            if not armed:
                ok_since = None if lost else (ok_since or now)
                if ok_since and now - ok_since >= 3:
                    armed = True
            if lost:
                lost_since = lost_since or now
                if armed and now - lost_since >= DEBOUNCE:
                    write_status(on=True, pin=c["pin"], power=False, shutting_down=True)
                    shutdown(c["fast"])
                    return
            else:
                lost_since = None
            if now >= next_status:
                write_status(on=True, source="gpio", pin=c["pin"], power=not lost, level="high" if high else "low", armed=armed)
                next_status = now + 1
            time.sleep(POLL)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
