#!/usr/bin/env python3
"""Raspi-TV: Notfall-Abschaltung bei Stromausfall.

Ein Raspberry Pi verliert bei einem Stromausfall sofort die Spannung – herunterfahren kann er nur, wenn
eine kleine Notstromversorgung (USV-Aufsatz, Akku- oder Kondensator-Modul) ihn noch ein paar Sekunden
versorgt und per GPIO-Pin meldet „Netzstrom weg“. Dieser Dienst prüft den Pin alle 10 ms; meldet er
länger als die Entprellzeit „Strom weg“, schreibt er sofort alles auf die Karte (sync) und fährt den Pi
herunter. Läuft der Pi nach 20 s noch, wird hart (aber mit sauber eingehängter Karte) abgeschaltet.

Einstellungen (config.json → "powerfail"): {"on": true, "pin": 6, "lost": "low"|"high", "pull": "up"|"down"|"none"}
"""
import glob
import json
import os
import subprocess
import sys
import time

CONFIG = "/var/lib/raspi-tv/config.json"
STATUS = "/run/raspi-tv-powerfail.json"
EVENT = "/var/lib/raspi-tv/powerfail-event.json"
POLL = 0.01
DEBOUNCE = 0.05                      # 50 ms – kurze Störungen auf der Leitung lösen nichts aus
HARD_AFTER = 20


def cfg():
    try:
        with open(CONFIG) as f:
            p = json.load(f).get("powerfail") or {}
    except (OSError, ValueError):
        p = {}
    pin = p.get("pin", 6)
    return {"on": p.get("on") is True, "pin": pin if type(pin) is int and 2 <= pin <= 27 else 6,
            "lost": "high" if p.get("lost") == "high" else "low",
            "pull": p.get("pull") if p.get("pull") in ("up", "down", "none") else "up"}


def write_status(**kw):
    kw["at"] = time.time()
    try:
        with open(STATUS + ".tmp", "w") as f:
            json.dump(kw, f)
        os.replace(STATUS + ".tmp", STATUS)
    except OSError:
        pass


class Pin:
    """Liest einen GPIO-Eingang über libgpiod (Python-Anbindung Version 1 oder 2)."""

    def __init__(self, pin, pull):
        import gpiod
        self.g = gpiod
        self.pin = pin
        chip = self.header_chip()
        if hasattr(gpiod, "request_lines"):                       # Version 2
            from gpiod.line import Bias, Direction
            bias = {"up": Bias.PULL_UP, "down": Bias.PULL_DOWN, "none": Bias.DISABLED}[pull]
            self.req = gpiod.request_lines(chip, consumer="raspi-tv-powerfail",
                                           config={pin: gpiod.LineSettings(direction=Direction.INPUT, bias=bias)})
            from gpiod.line import Value
            self.read = lambda: self.req.get_value(pin) == Value.ACTIVE
            self.close = self.req.release
        else:                                                     # Version 1
            c = gpiod.Chip(chip)
            line = c.get_line(pin)
            flags = {"up": getattr(gpiod, "LINE_REQ_FLAG_BIAS_PULL_UP", 0), "down": getattr(gpiod, "LINE_REQ_FLAG_BIAS_PULL_DOWN", 0),
                     "none": getattr(gpiod, "LINE_REQ_FLAG_BIAS_DISABLE", 0)}[pull]
            line.request(consumer="raspi-tv-powerfail", type=gpiod.LINE_REQ_DIR_IN, flags=flags)
            self.read = lambda: line.get_value() == 1
            self.close = line.release

    def header_chip(self):
        """Der GPIO-Baustein der Stiftleiste (Pi 5: pinctrl-rp1, ältere: pinctrl-bcm2711/bcm2835)."""
        best = None
        for dev in sorted(glob.glob("/dev/gpiochip*")):
            try:
                if hasattr(self.g, "request_lines"):
                    with self.g.Chip(dev) as c:
                        label = c.get_info().label
                else:
                    label = self.g.Chip(dev).label()
            except Exception:  # noqa: BLE001
                continue
            if label == "pinctrl-rp1" or label.startswith(("pinctrl-bcm2711", "pinctrl-bcm2835", "pinctrl-bcm2712")):
                if label == "pinctrl-rp1" or best is None:
                    best = dev
        return best or "/dev/gpiochip0"


def shutdown():
    """Sofort alles auf die Karte schreiben und herunterfahren."""
    os.sync()
    try:
        with open(EVENT, "w") as f:
            json.dump({"at": int(time.time())}, f)
            f.flush()
            os.fsync(f.fileno())
    except OSError:
        pass
    os.sync()
    print("Stromausfall gemeldet – Raspi-TV fährt herunter", flush=True)
    subprocess.Popen(["systemctl", "poweroff", "--no-block"])
    time.sleep(HARD_AFTER)
    # immer noch an: Karte schreibgeschützt einhängen und hart ausschalten
    print("Herunterfahren dauert zu lange – schalte sofort aus", flush=True)
    for c in "suo":
        try:
            with open("/proc/sysrq-trigger", "w") as f:
                f.write(c)
        except OSError:
            pass
        time.sleep(0.3)


def main():
    pin = None
    current = None
    armed = False
    while True:
        c = cfg()
        if not c["on"]:
            if pin:
                pin.close()
                pin = None
            write_status(on=False)
            armed = False
            time.sleep(5)
            continue
        if pin is None or current != (c["pin"], c["pull"]):
            if pin:
                pin.close()
            try:
                pin = Pin(c["pin"], c["pull"])
                current = (c["pin"], c["pull"])
                armed = False
            except Exception as e:  # noqa: BLE001
                write_status(on=True, error=f"GPIO {c['pin']} lässt sich nicht lesen: {e}")
                pin = None
                time.sleep(10)
                continue
        lost_since = None
        # Erst scharf, wenn der Pin 3 s lang „Strom da“ gemeldet hat – ein falsch eingestellter oder offener
        # Pin kann so nie eine Schleife aus Hochfahren und sofortigem Herunterfahren auslösen.
        ok_since = None
        next_cfg = time.monotonic() + 5
        next_status = 0
        while time.monotonic() < next_cfg:
            high = pin.read()
            lost = high if c["lost"] == "high" else not high
            now = time.monotonic()
            if not armed:
                ok_since = None if lost else (ok_since or now)
                if ok_since and now - ok_since >= 3:
                    armed = True
            if lost:
                lost_since = lost_since or now
                if armed and now - lost_since >= DEBOUNCE:
                    write_status(on=True, pin=c["pin"], power=False, shutting_down=True)
                    shutdown()
                    return
            else:
                lost_since = None
            if now >= next_status:
                write_status(on=True, pin=c["pin"], power=not lost, level="high" if high else "low", armed=armed)
                next_status = now + 1
            time.sleep(POLL)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
