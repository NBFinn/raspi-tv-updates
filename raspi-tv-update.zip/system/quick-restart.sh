#!/bin/bash
# Raspi-TV 7.5: nach einem Update ohne Neustart des Pi die Raspi-TV-Dienste und den Browser neu starten,
# danach wie nach einem Neustart prüfen, ob alles läuft (sonst zurück zur vorherigen Version).
#
#   quick-restart.sh <Sicherung>
SNAP="$1"
LOG=/var/log/raspi-tv-swupdate.log
echo "$(date '+%F %T') Schnelles Update: Dienste werden neu gestartet" >>"$LOG"
systemctl daemon-reload
# der Systemdienst zuerst (Oberfläche und Handy-App sprechen mit ihm), dann alle übrigen laufenden Dienste
systemctl restart raspi-tv-ctl
for svc in $(systemctl list-units 'raspi-tv-*' --type=service --state=active --plain --no-legend 2>/dev/null | awk '{print $1}'); do
	case "$svc" in
		raspi-tv-ctl.service|raspi-tv-update-check.service|raspi-tv-reboot-wake.service|raspi-tv-teensy-flash.service|raspi-tv-restart.service) ;;
		*) systemctl restart "$svc" || true ;;
	esac
done
# neu aktivierte Dienste starten (z. B. Teensy-Suche, Notfall-Abschaltung)
for svc in raspi-tv-teensy-watch raspi-tv-powerfail; do
	systemctl is-enabled --quiet "$svc" 2>/dev/null && systemctl start "$svc" 2>/dev/null || true
done
# Browser neu starten (lädt Oberfläche und Erweiterung frisch; start-browser.sh startet ihn sofort wieder)
pkill -u tv -f raspi-tv-browser || true
[ -n "$SNAP" ] && exec /bin/bash /opt/raspi-tv/update-guard.sh "$SNAP"
