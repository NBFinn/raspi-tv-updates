#!/usr/bin/env python3
"""Raspi-TV OS – Videorekorder.

Nimmt Live-Sender mit ffmpeg auf (ohne Umwandeln, „-c copy“) und speichert sie als
fragmentiertes MP4 – das lässt sich schon während der Aufnahme abspielen und bleibt
auch bei Stromausfall bis zur letzten Sekunde lesbar.

  * Aufnahmen planen (aus dem TV-Programm), mit 2 Minuten Vorlauf und 5 Minuten Nachlauf
  * Sofortaufnahme (bis zum Ende der laufenden Sendung bzw. 60 Minuten)
  * Speicherort: USB-Stick (Ordner „Raspi-TV Aufnahmen“) oder Speicherkarte
  * Neben jeder Aufnahme liegt eine kleine .json-Datei mit Titel, Sender und Zeit

Wird von features.py benutzt; die Schnittstelle steht unten (configure/plan/list/…).
"""
import json
import os
import re
import shutil
import signal
import subprocess
import threading
import time

PRE, POST = 120, 300               # Vor- und Nachlauf in Sekunden
MIN_FREE = 2 * 1024 ** 3           # so viel muss frei bleiben
USB_FOLDER = "Raspi-TV Aufnahmen"
SD_DIR = "/var/lib/raspi-tv/recordings"

_H = {}                            # Helfer aus features.py (configure)
_lock = threading.RLock()
_procs = {}                        # id -> Popen


def configure(**helpers):
    """state_file, channels() -> [{name,url}], usb_roots() -> [(id,name,mount)], run(cmd,timeout), log(...)"""
    _H.update(helpers)


def _log(*a):
    (_H.get("log") or print)(*a)


class RecError(Exception):
    pass


# ---------------------------------------------------------------- Plan (JSON-Datei)
def _load():
    try:
        with open(_H["state_file"]) as f:
            return json.load(f)
    except (OSError, ValueError, KeyError):
        return []


def _save(items):
    path = _H["state_file"]
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(items[-300:], f, ensure_ascii=False)
    os.replace(tmp, path)


def _safe(s):
    s = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', " ", s or "").strip()
    return re.sub(r"\s+", " ", s)[:80] or "Aufnahme"


# ---------------------------------------------------------------- Speicherort
def targets():
    """Mögliche Speicherorte: [{id, name, path, free, kind}]"""
    out = []
    for sid, name, mnt in (_H.get("usb_roots") or (lambda: []))():
        try:
            free = shutil.disk_usage(mnt).free
        except OSError:
            continue
        out.append({"id": sid, "name": name, "mount": mnt, "path": os.path.join(mnt, USB_FOLDER), "free": free, "kind": "usb"})
    try:
        os.makedirs(SD_DIR, exist_ok=True)
        out.append({"id": "sd", "name": "Speicherkarte", "mount": None, "path": SD_DIR,
                    "free": shutil.disk_usage(SD_DIR).free, "kind": "sd"})
    except OSError:
        pass
    return out


def pick_target(pref="auto"):
    ts = targets()
    if pref and pref != "auto":
        t = next((x for x in ts if x["id"] == pref), None)
        if t:
            return t
    usb = [x for x in ts if x["kind"] == "usb" and x["free"] > MIN_FREE]
    if usb:
        return max(usb, key=lambda x: x["free"])
    sd = next((x for x in ts if x["kind"] == "sd"), None)
    if not sd:
        raise RecError("Kein Speicherplatz für Aufnahmen gefunden.")
    return sd


def _writable(t):
    """USB-Sticks sind normalerweise schreibgeschützt eingehängt – zum Aufnehmen kurz freigeben."""
    if t["kind"] != "usb":
        return True
    code, _, _ = _H["run"](["mount", "-o", "remount,rw", t["mount"]], 20)
    return code == 0


def _readonly_again(mount):
    if not mount:
        return
    with _lock:
        busy = any(it.get("mount") == mount and it["status"] == "recording" for it in _load())
    if not busy:
        _H["run"](["sync"], 30)
        _H["run"](["mount", "-o", "remount,ro", mount], 20)


# ---------------------------------------------------------------- Planen
def plan(channel, start, stop, title="", source="plan", pref="auto"):
    if stop <= start:
        raise RecError("Ungültige Zeit")
    if stop < time.time():
        raise RecError("Die Sendung ist schon vorbei.")
    rid = f"{channel}|{int(start)}"
    with _lock:
        items = [i for i in _load() if i["id"] != rid or i["status"] not in ("planned",)]
        if any(i["id"] == rid and i["status"] == "recording" for i in items):
            raise RecError("Diese Sendung wird schon aufgenommen.")
        items.append({"id": rid, "channel": channel, "title": title or channel, "start": int(start), "stop": int(stop),
                      "status": "planned", "source": source, "pref": pref, "created": time.time()})
        _save(items)
    return rid


def cancel(rid):
    with _lock:
        items = _load()
        it = next((i for i in items if i["id"] == rid), None)
        if not it:
            raise RecError("Aufnahme nicht gefunden")
        if it["status"] == "recording":
            _stop_proc(rid)
            it["status"] = "done"
            it["stop"] = int(time.time())
        else:                                    # geplant oder fehlgeschlagen: aus der Liste nehmen
            items.remove(it)
        _save(items)
    return True


def _stop_proc(rid):
    p = _procs.pop(rid, None)
    if p and p.poll() is None:
        try:
            p.send_signal(signal.SIGINT)        # ffmpeg schließt die Datei sauber ab
            p.wait(10)
        except Exception:  # noqa: BLE001
            p.kill()


# ---------------------------------------------------------------- Aufnehmen
def _start(it):
    chans = {c["name"]: c for c in _H["channels"]()}
    ch = chans.get(it["channel"])
    if not ch or not re.match(r"^https?://", ch.get("url") or ""):
        raise RecError("Sender nicht gefunden")
    t = pick_target(it.get("pref") or "auto")
    if t["free"] < MIN_FREE:
        raise RecError("Zu wenig Speicherplatz frei")
    if not _writable(t):
        raise RecError("Auf den USB-Stick kann nicht geschrieben werden")
    os.makedirs(t["path"], exist_ok=True)
    stamp = time.strftime("%Y-%m-%d %H-%M", time.localtime(it["start"]))
    name = f"{stamp} {_safe(it['title'])} ({_safe(it['channel'])})"
    final = os.path.join(t["path"], name + ".mp4")
    n = 2
    while os.path.exists(final):
        final = os.path.join(t["path"], f"{name} {n}.mp4")
        n += 1
    duration = max(30, int(it["stop"] + (POST if it.get("source") == "plan" else 0) - time.time()))
    cmd = ["ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-y",
           "-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_delay_max", "10",
           "-user_agent", "Mozilla/5.0 (X11; Linux aarch64) Raspi-TV",
           "-i", ch["url"], "-map", "0:v:0?", "-map", "0:a:0?", "-c", "copy", "-bsf:a", "aac_adtstoasc",
           "-t", str(duration), "-movflags", "+frag_keyframe+empty_moov+default_base_moof", "-f", "mp4", final]
    meta = {"title": it["title"], "channel": it["channel"], "start": it["start"], "stop": it["stop"], "recorded": time.time()}
    with open(final[:-4] + ".json", "w") as f:
        json.dump(meta, f, ensure_ascii=False)
    log = open(final[:-4] + ".log", "w")
    p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=log, start_new_session=True)
    _procs[it["id"]] = p
    it.update(status="recording", file=final, mount=t["mount"], target=t["id"], began=time.time())
    _log("Aufnahme gestartet:", it["title"], "->", final)
    threading.Thread(target=_watch, args=(it["id"], p, final, t["mount"], log), daemon=True).start()


def _watch(rid, p, final, mount, log):
    p.wait()
    log.close()
    ok = os.path.exists(final) and os.path.getsize(final) > 256 * 1024
    with _lock:
        items = _load()
        it = next((i for i in items if i["id"] == rid), None)
        if it and it["status"] == "recording":
            it["status"] = "done" if ok else "failed"
            if not ok:
                try:
                    with open(final[:-4] + ".log") as f:
                        it["error"] = (f.read().strip().splitlines() or ["Sender lieferte kein Bild"])[-1][:160]
                except OSError:
                    it["error"] = "Aufnahme fehlgeschlagen"
            _save(items)
        _procs.pop(rid, None)
    if ok:
        try:
            os.remove(final[:-4] + ".log")
        except OSError:
            pass
    else:
        for ext in (".mp4", ".json"):
            try:
                os.remove(final[:-4] + ext)
            except OSError:
                pass
    _log("Aufnahme beendet:", final, "ok" if ok else "fehlgeschlagen")
    _readonly_again(mount)


def tick():
    """Alle paar Sekunden aufrufen: fällige Aufnahmen starten, verwaiste aufräumen."""
    now = time.time()
    with _lock:
        items = _load()
        changed = False
        for it in items:
            if it["status"] == "planned" and it["start"] - (PRE if it.get("source") == "plan" else 0) <= now:
                if now > it["stop"] + POST:
                    it.update(status="failed", error="Raspi-TV war zu der Zeit aus")
                else:
                    try:
                        _start(it)
                    except RecError as e:
                        it.update(status="failed", error=str(e))
                    except Exception as e:  # noqa: BLE001
                        it.update(status="failed", error=f"Aufnahme nicht möglich ({e})")
                changed = True
            elif it["status"] == "recording" and it["id"] not in _procs:
                # Raspi-TV wurde während der Aufnahme neu gestartet
                it["status"] = "done" if it.get("file") and os.path.exists(it["file"]) else "failed"
                changed = True
        # Erledigte Einträge nach 30 Tagen aus der Liste nehmen (die Dateien bleiben)
        keep = [i for i in items if i["status"] in ("planned", "recording") or now - i.get("stop", now) < 30 * 86400]
        if changed or len(keep) != len(items):
            _save(keep)


def loop():
    while True:
        try:
            tick()
        except Exception as e:  # noqa: BLE001
            _log("Rekorder:", e)
        time.sleep(10)


# ---------------------------------------------------------------- Liste & Löschen
def recordings():
    """Fertige Aufnahmen auf allen Speicherorten (neueste zuerst)."""
    out = []
    active = {i.get("file") for i in _load() if i["status"] == "recording"}
    for t in targets():
        try:
            names = os.listdir(t["path"])
        except OSError:
            continue
        for n in names:
            if not n.endswith(".mp4"):
                continue
            full = os.path.join(t["path"], n)
            try:
                st = os.stat(full)
            except OSError:
                continue
            meta = {}
            try:
                with open(full[:-4] + ".json") as f:
                    meta = json.load(f)
            except (OSError, ValueError):
                pass
            src = "rec" if t["kind"] == "sd" else t["id"]
            rel = n if t["kind"] == "sd" else USB_FOLDER + "/" + n
            out.append({"file": n, "src": src, "path": rel, "where": t["name"], "size": st.st_size,
                        "title": meta.get("title") or n[:-4], "channel": meta.get("channel", ""),
                        "start": meta.get("start") or int(st.st_mtime), "stop": meta.get("stop"),
                        "recording": full in active})
    out.sort(key=lambda r: -r["start"])
    return out


def delete(src, rel):
    for t in targets():
        tsrc = "rec" if t["kind"] == "sd" else t["id"]
        if tsrc != src:
            continue
        name = os.path.basename(rel or "")
        full = os.path.realpath(os.path.join(t["path"], name))
        if not full.startswith(os.path.realpath(t["path"]) + os.sep) or not name.endswith(".mp4"):
            raise RecError("Ungültige Datei")
        if any(i.get("file") == full and i["status"] == "recording" for i in _load()):
            raise RecError("Läuft gerade – erst die Aufnahme beenden.")
        if not _writable(t):
            raise RecError("Auf den USB-Stick kann nicht geschrieben werden")
        try:
            for ext in (".mp4", ".json", ".log"):
                try:
                    os.remove(full[:-4] + ext)
                except FileNotFoundError:
                    pass
        finally:
            _readonly_again(t["mount"])
        return True
    raise RecError("Speicherort nicht gefunden")


def schedule():
    with _lock:
        items = _load()
    return sorted([i for i in items if i["status"] in ("planned", "recording", "failed")],
                  key=lambda i: (i["status"] != "recording", i["status"] == "failed", i["start"]))
