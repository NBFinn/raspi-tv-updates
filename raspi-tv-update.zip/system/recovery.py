#!/usr/bin/env python3
"""Independent Raspi-TV recovery server. Only Python's standard library is required."""
import hashlib
import importlib.util
import re
import hmac
import json
import os
import secrets
import shutil
import stat
import subprocess
import threading
import tempfile
import time
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path, PurePosixPath
from urllib.parse import parse_qs, urlsplit

ROOT = Path('/opt/raspi-tv')
STATE = Path('/var/lib/raspi-tv-recovery')
LOCK = threading.Lock()
JOB = {'running': False, 'step': 'Bereit', 'error': None}
KEY = ''
AUTH_LOCK = threading.Lock()
AUTH_FAILURES = {}
MAX_UPLOAD = 300 * 1024 * 1024
REQUIRED = ('VERSION', 'system/apply-update.sh', 'system/install-files.sh', 'system/tvctl.py', 'launcher/index.html')


def valid_admin_code(code):
    return len(code) == 4 and all('0' <= digit <= '9' for digit in code)


def load_admin_code():
    STATE.mkdir(mode=0o700, parents=True, exist_ok=True)
    keyfile = STATE/'admin.key'
    try:
        code = keyfile.read_text(encoding='utf-8').strip()
    except (FileNotFoundError, UnicodeError):
        code = ''
    if valid_admin_code(code):
        keyfile.chmod(0o600)
        return code
    # Replace old long keys once; preserve a valid PIN across restarts.
    code = f'{secrets.randbelow(10000):04d}'
    fd, temporary = tempfile.mkstemp(prefix='.admin-', dir=str(STATE))
    try:
        with os.fdopen(fd, 'w', encoding='ascii') as output:
            output.write(code)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, keyfile)
    finally:
        Path(temporary).unlink(missing_ok=True)
    return code


def inspect_update(path):
    with zipfile.ZipFile(path) as z:
        entries = z.infolist()
        names = [e.filename for e in entries]
        if len(names) != len(set(names)) or len(names) > 5000:
            raise ValueError('Doppelte oder zu viele ZIP-Einträge.')
        roots = [n[:-len('VERSION')] for n in names if n == 'VERSION' or n.endswith('/VERSION')]
        roots = [r for r in roots if all(r + n in names for n in REQUIRED)]
        if len(roots) != 1:
            raise ValueError('Kein vollständiges Raspi-TV-Update.')
        prefix = roots[0]
        if sum(e.file_size for e in entries) > 300_000_000:
            raise ValueError('Entpacktes Update ist zu groß.')
        for e in entries:
            n = e.filename
            if '\\' in n or n.startswith('/') or '..' in PurePosixPath(n).parts or ':' in n or not n.startswith(prefix):
                raise ValueError('Unsicherer Pfad im Update.')
            if stat.S_ISLNK(e.external_attr >> 16):
                raise ValueError('Verknüpfungen sind im Update nicht erlaubt.')
        if z.getinfo(prefix + 'VERSION').file_size > 128:
            raise ValueError('Versionsdatei ist zu groß.')
        # Reject aliases before extraction: ./a, a//b and a/b must not address the same file.
        canonical = set()
        files = set()
        for e in entries:
            name = e.filename.rstrip('/') if e.is_dir() else e.filename
            clean = PurePosixPath(name).as_posix()
            if clean != name or clean in canonical:
                raise ValueError('Mehrdeutiger Pfad im Update.')
            if e.flag_bits & 1:
                raise ValueError('Verschlüsselte Updates werden nicht unterstützt.')
            if e.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
                raise ValueError('Nicht unterstützte ZIP-Kompression.')
            canonical.add(clean)
            if not e.is_dir(): files.add(clean)
        for name in canonical:
            if any(str(parent) in files for parent in PurePosixPath(name).parents):
                raise ValueError('Eine Datei blockiert einen Update-Ordner.')
        if z.testzip() is not None:
            raise ValueError('Beschädigtes Update: ZIP-Prüfsumme stimmt nicht.')
        version = z.read(prefix + 'VERSION').decode('utf-8').strip()
        if not version or len(version) > 30 or any(ord(c) < 32 for c in version):
            raise ValueError('Ungültige Versionsnummer.')
        return prefix, version


def tail(path):
    try:
        with open(path, 'rb') as f:
            f.seek(0, 2)
            f.seek(max(0, f.tell() - 32000))
            return f.read().decode('utf-8', 'replace')
    except OSError:
        return 'Noch kein Protokoll vorhanden.'


def command(args):
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=5)
        return (p.stdout + p.stderr)[-24000:]
    except (OSError, subprocess.TimeoutExpired) as e:
        return str(e)


def diagnostics():
    missing = []
    try:
        from html.parser import HTMLParser
        class Scripts(HTMLParser):
            def handle_starttag(self, tag, attrs):
                src = dict(attrs).get('src', '')
                if tag == 'script' and src and '://' not in src and not (ROOT/'launcher'/src).is_file():
                    missing.append(src)
        Scripts().feed((ROOT/'launcher/index.html').read_text(encoding='utf-8'))
    except OSError as e:
        missing.append(str(e))
    return {'version': tail(ROOT/'VERSION').strip(), 'missing_scripts': missing,
            'frontend': tail(STATE/'frontend.log'), 'installation': tail('/var/log/raspi-tv-swupdate.log'),
            'service': command(['journalctl', '-u', 'raspi-tv-ctl', '-n', '60', '--no-pager']),
            'browser': tail('/var/log/raspi-tv/browser.log'), 'job': dict(JOB)}


def install_worker():
    log_started = False
    try:
        archive = STATE/'update.zip'
        prefix, version = inspect_update(archive)
        JOB.update(step='Update-Probelauf und Speicherpruefung')
        maintenance().preflight()
        maintenance_event('update-start', 'Installation von Version '+version)
        work = STATE/'unpacked'
        if work.exists():
            shutil.rmtree(work)
        work.mkdir()
        JOB.update(step='Update wird entpackt')
        with zipfile.ZipFile(archive) as z:
            z.extractall(work)
        source = work/prefix
        # Same recovery snapshot format as the existing updater, before changing program files.
        snapshots = Path('/var/lib/raspi-tv-rollback')
        snapshots.mkdir(parents=True, exist_ok=True)
        snapshot = snapshots/('raspi-tv-recovery-' + time.strftime('%Y%m%d-%H%M%S') + '.tar.gz')
        paths = ['opt/raspi-tv', 'etc/raspi-tv-release', 'home/tv/.xbindkeysrc', 'home/tv/.xinitrc']
        paths = [p for p in paths if Path('/' + p).exists()]
        JOB.update(step='Bisherige Programmdateien werden gesichert')
        subprocess.run(['tar', '-czf', str(snapshot), '-C', '/'] + paths, check=True, timeout=180)
        JOB.update(step='Version ' + version + ' wird installiert')
        with open('/var/log/raspi-tv-swupdate.log', 'w') as log:
            log_started = True
            subprocess.run(['bash', str(source/'system/apply-update.sh'), str(source)], stdout=log,
                           stderr=subprocess.STDOUT, check=True, timeout=1200)
        maintenance_event('update-success', 'Version '+version+' installiert.')
        JOB.update(step='Installation beendet. Neustart wird ausgeführt.')
    except Exception as e:
        maintenance_event('update-error', str(e))
        JOB.update(error=str(e) + ('\n' + tail('/var/log/raspi-tv-swupdate.log') if log_started else ''), step='Installation fehlgeschlagen – Protokoll prüfen')
    finally:
        JOB['running'] = False


MEDIA_ROOT = Path('/media/raspi-tv')
USB_LOCK = threading.Lock()
USB_CANDIDATES = {}
TERMINAL_BACKEND = None


def local_console(handler):
    host = urlsplit('http://' + handler.headers.get('Host', '')).hostname
    return handler.client_address[0] == '127.0.0.1' and host in ('127.0.0.1', 'localhost')


def terminal_backend():
    global TERMINAL_BACKEND
    if TERMINAL_BACKEND is None:
        spec = importlib.util.spec_from_file_location('recovery_terminal', ROOT/'recovery-assets/terminal.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        TERMINAL_BACKEND = module
    return TERMINAL_BACKEND


def terminal_session():
    session = terminal_backend().get('recovery-admin')
    if session is None:
        raise ValueError('Bitte zuerst das Terminal oeffnen.')
    return session


def _mountpoints(device):
    points = device.get('mountpoints') or [device.get('mountpoint')]
    if isinstance(points, str):
        points = [points]
    return [point for point in points if point]


def _system_disk(device):
    return any(point in ('/', '/boot', '/boot/firmware') for point in _mountpoints(device)) or any(
        _system_disk(child) for child in device.get('children') or [])


def usb_roots():
    result = subprocess.run(['lsblk', '-J', '-p', '-o', 'NAME,TYPE,FSTYPE,LABEL,MOUNTPOINTS,TRAN,RM'],
                            capture_output=True, text=True, check=True, timeout=10)
    roots, errors = [], []
    def walk(devices, parent_usb=False):
        for device in devices:
            if _system_disk(device):
                continue
            removable = parent_usb or device.get('tran') == 'usb' or device.get('rm') in (True, 1, '1')
            filesystem = device.get('fstype')
            if removable and filesystem in ('vfat', 'exfat', 'ntfs', 'ntfs3', 'ext4', 'ext3', 'ext2', 'fuseblk'):
                name = device.get('name', '')
                if not re.fullmatch(r'/dev/[A-Za-z0-9_-]+', name):
                    continue
                mounts = _mountpoints(device)
                label = device.get('label') or Path(name).name
                try:
                    if mounts:
                        target = Path(mounts[0])
                    else:
                        target = MEDIA_ROOT/('usb-' + Path(name).name)
                        target.mkdir(parents=True, exist_ok=True)
                        subprocess.run(['mount', '-o', 'ro,nosuid,nodev,noexec', '--', name, str(target)],
                                       capture_output=True, text=True, check=True, timeout=15)
                    if target.is_dir():
                        roots.append((target.resolve(), label))
                except (OSError, subprocess.SubprocessError) as error:
                    errors.append(label + ': ' + str(error))
            walk(device.get('children') or [], removable)
    walk(json.loads(result.stdout).get('blockdevices', []))
    return roots, errors


def _usb_id(path):
    info = path.stat()
    return hashlib.sha256((str(path) + ':' + str(info.st_size) + ':' + str(info.st_mtime_ns)).encode()).hexdigest()[:24]


def scan_usb_updates():
    with USB_LOCK:
        roots, errors = usb_roots()
        candidates, seen = {}, set()
        for root, label in roots:
            try:
                paths = sorted((path for path in root.iterdir() if path.suffix.lower() == '.zip'),
                               key=lambda path: path.name)[:64]
                for path in paths:
                    try:
                        resolved = path.resolve()
                        if not resolved.is_relative_to(root) or resolved in seen or not resolved.is_file():
                            continue
                        seen.add(resolved)
                        if resolved.stat().st_size > MAX_UPLOAD:
                            continue
                        _, version = inspect_update(resolved)
                        identifier = _usb_id(resolved)
                        candidates[identifier] = {'path': resolved, 'root': root, 'id': identifier,
                                                  'name': path.name, 'device': label, 'version': version}
                    except (OSError, ValueError, zipfile.BadZipFile):
                        continue
            except OSError as error:
                errors.append(label + ': ' + str(error))
        USB_CANDIDATES.clear()
        USB_CANDIDATES.update(candidates)
        return {'updates': [{key: item[key] for key in ('id', 'name', 'device', 'version')}
                            for item in candidates.values()], 'errors': errors}


def select_usb_update(identifier):
    # Caller holds the same update lock used by uploads and installation.
    with USB_LOCK:
        item = USB_CANDIDATES.get(identifier)
        if item is None:
            raise ValueError('Update nicht gefunden. Bitte den USB-Stick erneut suchen.')
        path = item['path'].resolve()
        if not path.is_relative_to(item['root']) or _usb_id(path) != identifier:
            raise ValueError('Die USB-Datei wurde veraendert. Bitte erneut suchen.')
        temporary = STATE/'usb-update.tmp'
        try:
            count = 0
            with path.open('rb') as source, temporary.open('wb') as output:
                while True:
                    chunk = source.read(1024 * 1024)
                    if not chunk:
                        break
                    count += len(chunk)
                    if count > MAX_UPLOAD:
                        raise ValueError('Update ist zu gross.')
                    output.write(chunk)
            _, version = inspect_update(temporary)
            digest = hashlib.sha256(temporary.read_bytes()).hexdigest()
            os.replace(temporary, STATE/'update.zip')
            maintenance_event('update-selected', 'USB-Update '+version+' ausgewaehlt.')
            return {'version': version, 'sha256': digest}
        finally:
            temporary.unlink(missing_ok=True)


def read_json(handler):
    size = int(handler.headers.get('Content-Length', '0'))
    if not 0 <= size <= 16384:
        raise ValueError('Anfrage ist zu gross.')
    data = json.loads(handler.rfile.read(size)) if size else {}
    if not isinstance(data, dict):
        raise ValueError('Ungueltige Anfrage.')
    return data


MAINTENANCE = None

def maintenance():
    global MAINTENANCE
    if MAINTENANCE is None or MAINTENANCE.root != ROOT or MAINTENANCE.state != STATE:
        spec = importlib.util.spec_from_file_location('raspitv_maintenance', ROOT/'maintenance.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        MAINTENANCE = module.Maintenance(ROOT, STATE, diagnostics, usb_roots, inspect_update, lambda: dict(JOB))
    return MAINTENANCE

def maintenance_event(kind, message):
    try:
        maintenance().event(kind, message)
        if kind == 'service-start':
            maintenance().timeline()
    except (OSError, ImportError, ValueError):
        pass


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_): pass

    def reply(self, code, body, content_type='application/json; charset=utf-8', cors=False):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode()
        if isinstance(body, str): body = body.encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        if code == 429: self.send_header('Retry-After', '60')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        if cors: self.send_header('Access-Control-Allow-Origin', 'http://127.0.0.1:8765')
        try:
            self.end_headers()
            self.wfile.write(body)
        except ConnectionError:
            # Navigating away cancels outstanding terminal long-polls.
            return

    def authorized(self):
        origin = self.headers.get('Origin')
        if origin and origin != 'http://' + self.headers.get('Host', ''):
            self.reply(403, {'error': 'Fremder Ursprung.'}); return False
        candidate = self.headers.get('X-Admin-Key', '')
        if not candidate:
            self.reply(401, {'error': 'Bitte mit dem vierstelligen Admin-Code anmelden.'})
            return False
        peer = self.client_address[0]
        now = time.monotonic()
        with AUTH_LOCK:
            # At most five wrong codes per minute and client, including concurrent requests.
            for address, attempts in list(AUTH_FAILURES.items()):
                recent = [at for at in attempts if now - at < 60]
                if recent:
                    AUTH_FAILURES[address] = recent
                else:
                    del AUTH_FAILURES[address]
            if len(AUTH_FAILURES.get(peer, [])) >= 5:
                status, error = 429, 'Zu viele falsche Codes. Bitte in einer Minute erneut versuchen.'
            elif not valid_admin_code(candidate) or not hmac.compare_digest(candidate.encode(), KEY.encode()):
                AUTH_FAILURES.setdefault(peer, []).append(now)
                status, error = 401, 'Admin-Code fehlt oder ist falsch.'
            else:
                AUTH_FAILURES.pop(peer, None)
                return True
        self.reply(status, {'error': error})
        return False

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == '/favicon.ico':
            return self.reply(204, b'', 'image/x-icon')
        if path == '/local':
            if not local_console(self):
                return self.reply(403, {'error': 'Nur direkt am Pi verfuegbar.'})
            return self.reply(200, (ROOT/'recovery.html').read_bytes(), 'text/html; charset=utf-8')
        if path.startswith('/maintenance/'):
            if not self.authorized(): return
            try:
                result = maintenance().get(path, parse_qs(urlsplit(self.path).query))
                return self.reply(200, result, 'application/zip' if isinstance(result, bytes) else 'application/json; charset=utf-8')
            except (ValueError, TypeError, OSError, ImportError, subprocess.SubprocessError) as error:
                return self.reply(400, {'error': str(error)})
        assets = {'/assets/maintenance.js': ('maintenance.js', 'application/javascript'),
                  '/assets/qrcode.js': ('qrcode.js', 'application/javascript'),
                  '/assets/xterm.js': ('xterm.js', 'application/javascript'),
                  '/assets/xterm-addon-fit.js': ('xterm-addon-fit.js', 'application/javascript'),
                  '/assets/xterm.css': ('xterm.css', 'text/css')}
        if path in assets:
            name, content_type = assets[path]
            try:
                return self.reply(200, (ROOT/'recovery-assets'/name).read_bytes(), content_type)
            except OSError:
                return self.reply(404, {'error': 'Terminal-Datei fehlt.'})
        if self.path in ('/', '/admin'):
            return self.reply(200, (ROOT/'recovery.html').read_bytes(), 'text/html; charset=utf-8')
        if not self.authorized(): return
        if path == '/terminal/read':
            try:
                query = parse_qs(urlsplit(self.path).query)
                since = max(0, int(query.get('since', ['0'])[0]))
                wait = max(0, min(10, float(query.get('wait', ['0'])[0])))
                return self.reply(200, terminal_session().read(since, wait))
            except (ValueError, OSError, ImportError) as error:
                return self.reply(400, {'error': str(error)})
        if self.path == '/status': return self.reply(200, dict(JOB))
        if self.path == '/diagnostics': return self.reply(200, diagnostics())
        return self.reply(404, {'error': 'Unbekannte Adresse.'})

    def do_POST(self):
        path = urlsplit(self.path).path
        if path.startswith('/maintenance/'):
            if not self.authorized(): return
            try:
                return self.reply(200, maintenance().post(path, read_json(self)))
            except (ValueError, TypeError, OSError, ImportError, subprocess.SubprocessError) as error:
                return self.reply(400, {'error': str(error)})
        if path in ('/usb/scan', '/usb/select', '/terminal/start', '/terminal/write', '/terminal/resize', '/terminal/stop'):
            if not self.authorized():
                return
            try:
                data = read_json(self)
                if path == '/usb/scan':
                    return self.reply(200, scan_usb_updates())
                if path == '/usb/select':
                    with LOCK:
                        if JOB['running']:
                            return self.reply(409, {'error': 'Eine Installation laeuft bereits.'})
                        result = select_usb_update(str(data.get('id', '')))
                    return self.reply(200, result)
                backend = terminal_backend()
                if path == '/terminal/start':
                    environment = dict(os.environ, TERM='xterm-256color', HISTFILE='/dev/null')
                    session = backend.start('recovery-admin', ['/bin/bash', '--noprofile', '--norc', '-i'],
                                            environment, cwd='/', cols=int(data.get('cols', 100)),
                                            rows=int(data.get('rows', 24)), title='Notfall-Terminal')
                    return self.reply(200, session.info())
                if path == '/terminal/stop':
                    backend.stop('recovery-admin')
                    return self.reply(200, {'ok': True})
                session = terminal_session()
                if path == '/terminal/write':
                    text = data.get('data', '')
                    if not isinstance(text, str) or len(text) > 8192:
                        raise ValueError('Terminaleingabe ist zu gross.')
                    session.write(text)
                else:
                    session.resize(int(data.get('cols', 100)), int(data.get('rows', 24)))
                return self.reply(200, {'ok': True})
            except (ValueError, TypeError, OSError, ImportError, subprocess.SubprocessError) as error:
                return self.reply(400, {'error': str(error)})
        if self.path == '/report':
            if self.client_address[0] != '127.0.0.1' or self.headers.get('Origin') != 'http://127.0.0.1:8765':
                return self.reply(403, {'error': 'forbidden'})
            try:
                size = int(self.headers.get('Content-Length', '0'))
                if not 0 < size <= 8192: raise ValueError('Bericht zu groß.')
                report = json.loads(self.rfile.read(size))
                record = {'at': time.strftime('%Y-%m-%d %H:%M:%S'), 'message': str(report.get('message', ''))[:4000],
                          'file': str(report.get('file', ''))[:300], 'line': report.get('line')}
                with LOCK:
                    log = STATE/'frontend.log'
                    if log.exists() and log.stat().st_size > 128000:
                        log.write_text(tail(log), encoding='utf-8')
                    with log.open('a', encoding='utf-8') as f: f.write(json.dumps(record, ensure_ascii=False) + '\n')
                try:
                    maintenance().frontend_failure(record['message'])
                except (OSError, ImportError, ValueError):
                    pass
                return self.reply(200, {'ok': True}, cors=True)
            except (ValueError, AttributeError): return self.reply(400, {'error': 'Ungültiger Bericht.'}, cors=True)
        if not self.authorized(): return
        if self.path == '/install':
            with LOCK:
                if JOB['running']: return self.reply(409, {'error': 'Eine Installation läuft bereits.'})
                try: _, version = inspect_update(STATE/'update.zip')
                except Exception as e: return self.reply(400, {'error': str(e)})
                JOB.update(running=True, error=None, step='Update ' + version + ' wird vorbereitet')
                threading.Thread(target=install_worker, daemon=True).start()
            return self.reply(202, dict(JOB))
        if self.path != '/upload': return self.reply(404, {'error': 'Unbekannte Adresse.'})
        if not LOCK.acquire(blocking=False): return self.reply(409, {'error': 'Bitte erneut versuchen.'})
        temp = STATE/'upload.tmp'
        try:
            if JOB['running']: return self.reply(409, {'error': 'Installation läuft.'})
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 < size <= MAX_UPLOAD: raise ValueError('ZIP muss zwischen 1 Byte und 300 MB groß sein.')
            self.connection.settimeout(90)
            with temp.open('wb') as f:
                remaining = size
                while remaining:
                    chunk = self.rfile.read(min(65536, remaining))
                    if not chunk: raise ValueError('Upload abgebrochen.')
                    f.write(chunk); remaining -= len(chunk)
            _, version = inspect_update(temp)
            digest = hashlib.sha256(temp.read_bytes()).hexdigest()
            os.replace(temp, STATE/'update.zip')
            maintenance_event('update-selected', 'Update '+version+' hochgeladen.')
            return self.reply(200, {'version': version, 'sha256': digest})
        except Exception as e:
            return self.reply(400, {'error': str(e)})
        finally:
            temp.unlink(missing_ok=True)
            LOCK.release()


def main():
    global KEY
    KEY = load_admin_code()
    maintenance_event('service-start', 'Notfalldienst gestartet.')
    ThreadingHTTPServer(('0.0.0.0', 8767), Handler).serve_forever()


if __name__ == '__main__': main()
