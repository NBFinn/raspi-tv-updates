"""Optional dual GC9A01 displays: album/clock and a real volume ring (240x240).
No GPIO libraries are imported until the hardware service is explicitly started.
Register values follow the GC9A01A data sheet and the Waveshare 1.28-inch module example.
https://files.waveshare.com/wiki/common/GC9A01A.pdf
"""
import array
import datetime
import io
import functools
import json
import math
import os
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
from pathlib import Path
from urllib.parse import urlsplit
from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFont, ImageOps

SIZE=240
# Confirmed horizontal mirroring on the user's GC9A01 modules: toggle MADCTL MX.
MADCTL=0x48
SPI_SPEED=4_000_000
# 6.3: wählbar unter Einstellungen · Runde Displays (kurze Kabel schaffen meist 16–32 MHz)
SPEEDS=(4_000_000,8_000_000,16_000_000,32_000_000)
# Independent wiring: (SPI bus, chip select, DC GPIO, reset GPIO).
DISPLAY_PINS=((0,0,25,27),(1,0,24,23))
TEST_SPEED=500_000
TEST_SECONDS=30
TEST_DIRECTORY=Path('/run/raspi-tv-round')


@functools.lru_cache(maxsize=16)
def font(size):
    for path in ('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','C:/Windows/Fonts/arial.ttf'):
        try:return ImageFont.truetype(path,size)
        except OSError:pass
    return ImageFont.load_default()


def center(draw,text,y,size,fill):
    f=font(size);box=draw.textbbox((0,0),text,font=f)
    draw.text(((SIZE-(box[2]-box[0]))/2,y),text,font=f,fill=fill)


def _rgb(value):
    value=str(value).lstrip('#');return tuple(int(value[i:i+2],16) for i in (0,2,4))


def _mix(a,b,amount):
    return tuple(round(x+(y-x)*amount) for x,y in zip(a,b))


def make_palette(accent='#57dcc7',base='#050b16'):
    """6.0: alle Farben der Displays aus einer Akzentfarbe (Design, Hintergrundbild oder Albumcover)."""
    try:a=_rgb(accent)
    except (ValueError,IndexError):a=_rgb('#57dcc7')
    try:b=_rgb(base)
    except (ValueError,IndexError):b=_rgb('#050b16')
    if sum(a)<300:a=_mix(a,(255,255,255),.35)          # zu dunkle Akzente auf dem schwarzen Glas aufhellen
    bg=_mix(_mix(b,(4,7,13),.5),a,.06)
    return {'accent':a,'bg':bg,'track':_mix(bg,a,.2),'line':_mix(bg,a,.42),'tick':_mix((150,165,185),a,.45),
            'label':_mix((200,212,226),a,.22),'muted':_mix((142,157,178),a,.18),'hand':_mix((255,255,255),a,.2),
            'light':_mix(a,(255,255,255),.45),'text':(239,249,255),'warn':(255,184,92),'bad':(242,134,149)}


PAL=make_palette()


def blend_palette(current,target,amount):
    return {k:_mix(current[k],target[k],amount) for k in target}


def gradient_arc(draw,box,start,end,width,first,second,step=3):
    """Ring mit Farbverlauf (PIL kennt keine Verläufe auf Bögen)."""
    if end<=start:return
    span=end-start;angle=start
    while angle<end:
        stop=min(end,angle+step);t=(angle-start)/span if span else 1
        draw.arc(box,angle,stop+.6,fill=_mix(first,second,t),width=width);angle=stop


def volume_frame(value,muted=False,target='pi'):
    P=PAL;image=Image.new('RGB',(SIZE,SIZE),P['bg']);d=ImageDraw.Draw(image)
    d.arc((16,16,224,224),135,405,fill=P['track'],width=16)
    if isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value):
        value=min(100,max(0,round(value)))
        if value and not muted:
            if value<85:gradient_arc(d,(16,16,224,224),135,135+value*2.7,16,P['accent'],P['light'])
            else:d.arc((16,16,224,224),135,135+value*2.7,fill=P['warn'],width=16)
        label=str(value)
    else:label='--'
    center(d,'LAUTSTÄRKE',56,18,P['label'])
    center(d,'STUMM' if muted else label,91,34 if muted else 60,P['bad'] if muted else P['text'])
    center(d,'Pi' if target=='pi' else 'TV / Soundbar',169,15,P['muted'])
    center(d,'kein Rückmeldewert' if label=='--' and not muted else '%' if not muted else 'Ton aus',190,12,P['muted'])
    return image


def album_frame(music,cover=None,now=None,phase=None,enter=1.0):
    """phase: Animationszeit in Sekunden (None = Standbild); enter: 0…1 beim Hereinkommen der Seite."""
    now=now or datetime.datetime.now()
    P=PAL;image=Image.new('RGB',(SIZE,SIZE),P['bg']);d=ImageDraw.Draw(image)
    if music and music.get('title') and (music.get('playing') or music.get('paused')):
        if cover:
            picture=ImageOps.fit(cover.convert('RGB'),(216,216));mask=Image.new('L',(216,216));ImageDraw.Draw(mask).ellipse((0,0,215,215),fill=255)
            image.paste(picture,(12,12),mask)
        else:
            d.ellipse((18,18,222,222),fill=P['track'],outline=P['line'],width=2)
            center(d,'♪',46,65,P['accent'])
        overlay=Image.new('RGBA',(240,240));o=ImageDraw.Draw(overlay);o.rectangle((20,153,220,211),fill=(0,0,0,200))
        image=Image.alpha_composite(image.convert('RGBA'),overlay).convert('RGB');d=ImageDraw.Draw(image)
        title=str(music.get('title',''))
        artist=str(music.get('artist',''))
        center(d,title[:21]+('…' if len(title)>21 else ''),157,14,'white')
        center(d,artist[:25],181,11,P['label'])
        playing=music.get('playing') and not (music.get('paused') and not music.get('playing'))
        if phase is not None and playing:
            # kleiner Equalizer neben dem Schriftzug
            for i in range(5):
                h=2+9*(.5+.5*math.sin(phase*(5.1+i*1.7)+i*1.3))*(.6+.4*math.sin(phase*2.3+i))
                x=84+i*5;d.rectangle((x,222-h,x+2,222),fill=P['accent'])
            d.text((112,212),str(music.get('source') or 'SPOTIFY')[:14],font=font(9),fill=P['accent'])
        else:center(d,'PAUSE' if music.get('paused') and not music.get('playing') else str(music.get('source') or 'SPOTIFY')[:14],211,9,P['accent'])
    else:
        d.ellipse((13,13,227,227),outline=P['line'],width=2)
        for i in range(12):
            angle=2*math.pi*i/12-math.pi/2
            d.line((120+91*math.cos(angle),120+91*math.sin(angle),120+100*math.cos(angle),120+100*math.sin(angle)),fill=P['tick'],width=2)
        sec=now.second+(now.microsecond/1e6 if phase is not None else 0)
        k=_ease(enter) if phase is not None else 1
        for angle,length,width,color in ((2*math.pi*(now.hour%12+now.minute/60)/12,51,5,P['hand']),(2*math.pi*(now.minute+sec/60)/60 if phase is not None else 2*math.pi*now.minute/60,76,3,P['hand']),(2*math.pi*sec/60,84,2 if phase is not None else 1,P['accent'])):
            angle=angle*k-math.pi/2;d.line((120,120,120+length*math.cos(angle),120+length*math.sin(angle)),fill=color,width=width)
        d.ellipse((116,116,124,124),fill=P['accent']);center(d,now.strftime('%d.%m.'),165,14,P['label'])
    return image


try:
    import numpy as _np
except ImportError:  # ohne numpy: langsamer, aber gleiches Ergebnis
    _np=None


def rgb565(image):
    rgb=image.convert('RGB')
    if _np is not None:
        a=_np.asarray(rgb,dtype=_np.uint16)
        return (((a[...,0]>>3)<<11)|((a[...,1]>>2)<<5)|(a[...,2]>>3)).astype('>u2').tobytes()
    data=rgb.get_flattened_data() if hasattr(rgb,'get_flattened_data') else rgb.getdata()
    pixels=array.array('H',(((r>>3)<<11)|((g>>2)<<5)|(b>>3) for r,g,b in data))
    if sys.byteorder=='little':pixels.byteswap()
    return pixels.tobytes()


# Controller register initialization data, not a frame or a remotely executed program.
INIT=[(0xef,[]),(0xeb,[0x14]),(0xfe,[]),(0xef,[]),(0xeb,[0x14]),(0x84,[0x40]),
 (0x85,[0xff]),(0x86,[0xff]),(0x87,[0xff]),(0x88,[0x0a]),(0x89,[0x21]),(0x8a,[0]),
 (0x8b,[0x80]),(0x8c,[1]),(0x8d,[1]),(0x8e,[0xff]),(0x8f,[0xff]),(0xb6,[0,0]),
 (0x36,[MADCTL]),(0x3a,[0x05]),(0x90,[8,8,8,8]),(0xbd,[6]),(0xbc,[0]),(0xff,[0x60,1,4]),
 (0xc3,[0x13]),(0xc4,[0x13]),(0xc9,[0x22]),(0xbe,[0x11]),(0xe1,[0x10,0x0e]),(0xdf,[0x21,0x0c,2]),
 (0xf0,[0x45,9,8,8,0x26,0x2a]),(0xf1,[0x43,0x70,0x72,0x36,0x37,0x6f]),
 (0xf2,[0x45,9,8,8,0x26,0x2a]),(0xf3,[0x43,0x70,0x72,0x36,0x37,0x6f]),(0xed,[0x1b,0x0b]),
 (0xae,[0x77]),(0xcd,[0x63]),(0x70,[7,7,4,0x0e,0x0f,9,7,8,3]),(0xe8,[0x34]),
 (0x62,[0x18,0x0d,0x71,0xed,0x70,0x70,0x18,0x0f,0x71,0xef,0x70,0x70]),
 (0x63,[0x18,0x11,0x71,0xf1,0x70,0x70,0x18,0x13,0x71,0xf3,0x70,0x70]),
 (0x64,[0x28,0x29,0xf1,1,0xf1,0,7]),(0x66,[0x3c,0,0xcd,0x67,0x45,0x45,0x10,0,0,0]),
 (0x67,[0,0x3c,0,0,0,1,0x54,0x10,0x32,0x98]),(0x74,[0x10,0x85,0x80,0,0,0x4e,0]),
 (0x98,[0x3e,7]),(0x21,[])]


class GC9A01:
    def __init__(self,spi,dc,reset=None):
        self.spi,self.dc,self.reset,self.last=spi,dc,reset,None
        self.lock=threading.RLock()   # Anzeige-Thread und Display-Test teilen sich den Bus
    def command(self,code,data=()):
        self.dc.off();self.spi.writebytes([code])
        if data:self.dc.on();self.spi.writebytes(list(data))
    def initialize(self):
        self.last=None;self.last_image=None
        for code,data in INIT:self.command(code,data)
        self.command(0x11);time.sleep(.15);self.command(0x29);time.sleep(.05)
    def set_speed(self,speed):
        with self.lock:
            if self.spi.max_speed_hz!=speed:self.spi.max_speed_hz=speed;self.last=None
    def reinitialize(self,speed):
      with self.lock:
        self.spi.max_speed_hz=speed
        if self.reset is not None:
            try:self.reset.off();time.sleep(.05)
            finally:self.reset.on()
            time.sleep(.15)
        self.initialize()
    BAND=16
    FULL_EVERY=20   # Sekunden: komplettes Bild zur Sicherheit neu senden (heilt Übertragungsfehler)
    def show(self,image,full=False):
        with self.lock:return self._show(image,full)
    def _show(self,image,full=False):
        """6.0: nur geänderte Bereiche senden. Bei 4 MHz dauert ein volles Bild ~0,23 s.
        6.3: Änderungen werden in Streifen zu je BAND Zeilen zerlegt, jeder mit eigenem Ausschnitt –
        ein wachsender Ring und eine Zahl in der Mitte kosten so nur einen Bruchteil eines Vollbilds."""
        image=image.convert('RGB');raw=image.tobytes()
        if raw==self.last:return
        boxes=[(0,0,SIZE,SIZE)]
        previous=getattr(self,'last_image',None);now=time.monotonic()
        if not full and previous is not None and self.last is not None and now-getattr(self,'full_at',0)<self.FULL_EVERY:
            diff=ImageChops.difference(previous,image)
            whole=diff.getbbox()
            if whole is None:boxes=[]
            else:
                boxes=[]
                for top in range(whole[1],whole[3],self.BAND):
                    band=diff.crop((0,top,SIZE,min(whole[3],top+self.BAND))).getbbox()
                    if band:boxes.append((band[0],top+band[1],band[2],top+band[3]))
                # Viele kleine Streifen, die zusammen fast alles abdecken: lieber ein Ausschnitt
                if sum((b[2]-b[0])*(b[3]-b[1]) for b in boxes)>.8*(whole[2]-whole[0])*(whole[3]-whole[1]):boxes=[whole]
        for box in boxes:
            x0,y0,x1,y1=box;x1-=1;y1-=1
            self.command(0x2a,[x0>>8,x0&255,x1>>8,x1&255]);self.command(0x2b,[y0>>8,y0&255,y1>>8,y1&255]);self.command(0x2c)
            self.dc.on();self.spi.writebytes2(rgb565(image if box==(0,0,SIZE,SIZE) else image.crop(box)))
        if boxes==[(0,0,SIZE,SIZE)]:self.full_at=now
        self.last=raw;self.last_image=image


# Kernel-driven chip-select GPIOs of the SPI buses used above.
CS_GPIO={(0,0):8,(1,0):18}


def cs_idle_low(gpio,run=None):
    """True if an idle chip select reads LOW, i.e. the kernel drives it with inverted polarity.
    Seen on a Pi 5 (kernel 6.18): SPI0 CS GPIO8 idled low while SPI1 CS GPIO18 idled high,
    so display 1 was deselected exactly while frames were sent."""
    try:
        result=(run or subprocess.run)(['pinctrl','get',str(gpio)],capture_output=True,text=True,timeout=3)
    except (OSError,subprocess.SubprocessError):return False
    return bool(re.search(r'^\s*\d+:\s*op\b[^|]*\|\s*lo\b',result.stdout or '',re.M))


def open_displays(spidev,output,probe=cs_idle_low):
    devices=[];pins=[];buses=[]
    try:
        for bus,cs,dc_pin,reset_pin in DISPLAY_PINS:
            dc=output(dc_pin,initial_value=True);pins.append(dc)
            reset=output(reset_pin,initial_value=True);pins.append(reset)
            spi=spidev.SpiDev();buses.append(spi)
            spi.open(bus,cs);spi.mode=0;spi.max_speed_hz=SPI_SPEED
            reset.off();time.sleep(.05);reset.on();time.sleep(.15)
            lcd=GC9A01(spi,dc,reset);lcd.initialize();devices.append(lcd)
            gpio=CS_GPIO.get((bus,cs))
            if gpio is not None and probe(gpio):
                # Leave CS untouched (it stays LOW = selected) and initialize again so the controller sees it.
                spi.no_cs=True
                lcd.reinitialize(SPI_SPEED)
                print(f'Runde Displays: CS GPIO{gpio} war im Ruhezustand LOW (verkehrt gepolt). '
                      'Display bleibt jetzt dauerhaft ausgewaehlt.',flush=True)
        return devices,pins
    except Exception:
        for spi in buses:spi.close()
        for pin in pins:pin.close()
        raise


def test_frame(number):
    image=Image.new('RGB',(SIZE,SIZE),'#122438');draw=ImageDraw.Draw(image)
    draw.ellipse((12,12,228,228),outline='#58dec7',width=4)
    center(draw,'DISPLAY',37,18,'white');center(draw,str(number),58,66,'white')
    center(draw,'UHR / COVER' if number==1 else 'LAUTSTAERKE',138,16,'#90dcd0')
    draw.text((34,107),'L',font=font(20),fill='white')
    draw.text((193,107),'R',font=font(20),fill='white')
    for x,color in ((66,'red'),(106,'lime'),(146,'blue')):
        draw.rectangle((x,171,x+28,194),fill=color)
    center(draw,'ABC 123',201,12,'white')
    return image


def read_test_file(path):
    try:
        with path.open(encoding='utf-8') as stream:value=json.loads(stream.read(4096))
        return value if isinstance(value,dict) else {}
    except (OSError,ValueError):return {}


def write_test_status(folder,value):
    folder.mkdir(mode=0o700,parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix='.status-',dir=folder)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as stream:json.dump(value,stream)
        os.replace(name,folder/'test-status.json')
    finally:
        Path(name).unlink(missing_ok=True)


class RoundDisplayTest:
    """Run the bounded test inside the sole GPIO owner; never restart playback."""
    def __init__(self,devices,folder=TEST_DIRECTORY,clock=time.monotonic):
        self.devices,self.folder,self.clock=devices,Path(folder),clock
        self.active=None;self.until=0;self.speed=SPI_SPEED;self.device=None
        previous=read_test_file(self.folder/'test-status.json')
        self.handled=previous.get('id')
        self.number=previous.get('display',2)
        if previous.get('phase')=='running':
            self.status('error','Display-Dienst wurde neu gestartet. Der Test wurde beendet.',self.handled)

    def status(self,phase,error=None,identifier=None):
        write_test_status(self.folder,{'id':identifier or self.active,'phase':phase,
                                      'until':self.until,'error':error,'speed':TEST_SPEED,'display':self.number})

    def finish(self,normal,error=None):
        identifier=self.active
        try:
            self.device.reinitialize(self.speed)
            self.device.show(normal[self.number-1])
        except Exception as restore_error:
            error=(str(error)+'; ' if error else '')+'Normale Anzeige konnte nicht wiederhergestellt werden: '+str(restore_error)
        finally:
            self.active=None;self.until=0
        self.status('error' if error else 'finished',str(error) if error else None,identifier)

    def tick(self,normal):
        request=read_test_file(self.folder/'test-request.json');now=self.clock()
        if self.active:
            if now>=self.until or (request.get('id')==self.active and request.get('cancel')):
                self.finish(normal);return False
            return self.number
        identifier=request.get('id');expires=request.get('expires')
        number=request.get('display',2)
        if (not isinstance(identifier,str) or len(identifier)!=24 or any(c not in '0123456789abcdef' for c in identifier)
                or identifier==self.handled
                or type(number) is not int or number not in (1,2)
                or not isinstance(expires,(int,float)) or not math.isfinite(expires) or not now<=expires<=now+10):
            return False
        self.number=number
        if request.get('cancel'):
            self.handled=identifier;self.status('finished',identifier=identifier);return False
        self.device=self.devices[number-1]
        self.handled=identifier;self.active=identifier;self.speed=self.device.spi.max_speed_hz
        try:
            self.device.reinitialize(TEST_SPEED)
            self.device.show(test_frame(number))
            self.until=self.clock()+TEST_SECONDS
            self.status('running')
        except Exception as error:
            self.finish(normal,'Testbild konnte nicht gesendet werden: '+str(error));return False
        return number

    def close(self):
        if self.active:
            identifier=self.active;self.active=None
            try:self.device.spi.max_speed_hz=self.speed
            finally:self.status('error','Display-Dienst wurde beendet. Test abgebrochen.',identifier)


PAGE_SECONDS=10
FRONTEND_LOG=Path('/var/lib/raspi-tv-recovery/frontend.log')


class SystemInfo:
    """Read-only system values for the rotating pages. Slow commands are cached."""
    def __init__(self,root=Path('/'),run=None,clock=time.monotonic,wall=time.time):
        self.root,self.run,self.clock,self.wall=Path(root),run or subprocess.run,clock,wall
        self.cpu_prev=None;self.cached={};self.cached_at=-1e9

    def text(self,path,limit=65536):
        try:
            with (self.root/path).open(encoding='utf-8',errors='replace') as stream:return stream.read(limit)
        except OSError:return ''

    def command(self,args):
        try:return self.run(args,capture_output=True,text=True,timeout=3).stdout or ''
        except (OSError,subprocess.SubprocessError):return ''

    def cpu(self):
        fields=self.text('proc/stat',4096).split('\n',1)[0].split()
        if len(fields)<5 or fields[0]!='cpu':return None
        values=[int(v) for v in fields[1:] if v.isdigit()]
        idle=values[3]+(values[4] if len(values)>4 else 0);total=sum(values)
        previous,self.cpu_prev=self.cpu_prev,(idle,total)
        if not previous or total<=previous[1]:return None
        return round(100*(1-(idle-previous[0])/(total-previous[1])))

    def slow(self):
        if self.clock()-self.cached_at<15:return self.cached
        ssid=self.command(['iwgetid','-r']).strip()
        if not ssid:
            for line in self.command(['nmcli','-t','-f','active,ssid','dev','wifi']).splitlines():
                if line.startswith('yes:'):ssid=line[4:].replace('\\:',':');break
        failed=[line.split()[0] for line in self.command(['systemctl','--failed','--no-legend','--plain','raspi-tv*']).splitlines() if line.strip()]
        errors=['Dienst ausgefallen: '+name.removesuffix('.service') for name in failed]
        lines=self.text(FRONTEND_LOG.relative_to('/'),200000).strip().splitlines()
        if lines:
            try:
                record=json.loads(lines[-1])
                age=self.wall()-time.mktime(time.strptime(record.get('at',''),'%Y-%m-%d %H:%M:%S'))
                if 0<=age<=86400 and record.get('message'):errors.append('Oberflaeche: '+str(record['message']))
            except (ValueError,TypeError,OverflowError):pass
        self.cached={'ssid':ssid,'errors':errors}
        self.cached_at=self.clock()
        return self.cached

    def snapshot(self):
        info=dict(self.slow())
        info['cpu']=self.cpu()
        raw=self.text('sys/class/thermal/thermal_zone0/temp',64).strip()
        info['temp']=round(int(raw)/1000) if raw.lstrip('-').isdigit() else None
        mem={}
        for line in self.text('proc/meminfo',8192).splitlines():
            key,_,value=line.partition(':')
            if value.split() and value.split()[0].isdigit():mem[key]=int(value.split()[0])
        info['ram']=round(100*(1-mem['MemAvailable']/mem['MemTotal'])) if mem.get('MemTotal') and 'MemAvailable' in mem else None
        info['signal']=None;info['wlan']=False
        for line in self.text('proc/net/wireless',4096).splitlines()[2:]:
            parts=line.replace('.',' ').split()
            if len(parts)>2 and parts[0].endswith(':') and parts[2].isdigit():
                info['wlan']=True;info['signal']=min(100,round(int(parts[2])*100/70));break
        return info


def ring(draw,value,color):
    draw.arc((16,16,224,224),135,405,fill=PAL['track'],width=14)
    if isinstance(value,(int,float)) and value>0:
        if color==PAL['accent']:gradient_arc(draw,(16,16,224,224),135,135+min(100,value)*2.7,14,PAL['accent'],PAL['light'])
        else:draw.arc((16,16,224,224),135,135+min(100,value)*2.7,fill=color,width=14)


def wlan_frame(info):
    P=PAL;image=Image.new('RGB',(SIZE,SIZE),P['bg']);d=ImageDraw.Draw(image)
    signal=info.get('signal')
    real=info.get('signal_real',signal)
    ring(d,signal,P['accent'] if (real or 0)>=40 else P['warn'])
    center(d,'WLAN',52,18,P['label'])
    if info.get('wlan'):
        center(d,f'{signal} %' if signal is not None else '--',80,46,P['text'])
        ssid=info.get('ssid') or 'verbunden'
        center(d,ssid[:18]+('…' if len(ssid)>18 else ''),144,16,P['muted'])
        center(d,'Signal',172,12,P['muted'])
    else:
        center(d,'Kein WLAN',96,26,P['bad'])
        center(d,'evtl. per Kabel online',140,13,P['muted'])
    return image


def system_frame(info):
    P=PAL;image=Image.new('RGB',(SIZE,SIZE),P['bg']);d=ImageDraw.Draw(image)
    cpu=info.get('cpu')
    ring(d,cpu,P['accent'] if (info.get('cpu_real',cpu) or 0)<80 else P['warn'])
    center(d,'CPU',52,18,P['label'])
    center(d,f'{cpu} %' if cpu is not None else '--',78,46,P['text'])
    temp=info.get('temp');ram=info.get('ram')
    center(d,f'Temperatur {temp} °C' if temp is not None else 'Temperatur --',142,15,P['warn'] if (temp or 0)>=70 else P['muted'])
    center(d,f'Speicher {ram} %' if ram is not None else 'Speicher --',166,15,P['muted'])
    return image


def wrap(text,width,lines):
    words=str(text).split();out=[];line=''
    for word in words:
        candidate=(line+' '+word).strip()
        if len(candidate)<=width:line=candidate
        else:
            if line:out.append(line)
            line=word[:width]
        if len(out)==lines:break
    if line and len(out)<lines:out.append(line)
    if len(out)==lines and ' '.join(out)!=' '.join(words):out[-1]=out[-1][:width-1]+'…'
    return out


def status_frame(errors,enter=1.0):
    P=PAL;image=Image.new('RGB',(SIZE,SIZE),P['bg']);d=ImageDraw.Draw(image)
    if not errors:
        d.ellipse((13,13,227,227),outline=P['line'],width=4)
        center(d,'STATUS',62,18,P['label'])
        pts=[(97,116),(114,133),(146,96)];k=max(0.0,min(1.0,enter));seg1=min(1,k*2.2);seg2=max(0,min(1,k*2.2-1))
        if seg1>0:d.line((pts[0],(pts[0][0]+(pts[1][0]-pts[0][0])*seg1,pts[0][1]+(pts[1][1]-pts[0][1])*seg1)),fill=P['accent'],width=8,joint='curve')
        if seg2>0:d.line((pts[1],(pts[1][0]+(pts[2][0]-pts[1][0])*seg2,pts[1][1]+(pts[2][1]-pts[1][1])*seg2)),fill=P['accent'],width=8,joint='curve')
        center(d,'Keine Fehler',156,17,P['hand'])
        return image
    d.ellipse((13,13,227,227),outline=P['bad'],width=4)
    center(d,'FEHLER' if len(errors)==1 else f'{len(errors)} FEHLER',48,18,P['bad'])
    for i,line in enumerate(wrap(errors[0],20,5)):center(d,line,82+i*22,15,P['text'])
    return image


def update_frame(update,enter=1.0,phase=None,now=None):
    """6.1: Seite „Updates“ auf Display 2 – installierte Version, neue Version, Installation läuft."""
    P=PAL;image=Image.new('RGB',(SIZE,SIZE),P['bg']);d=ImageDraw.Draw(image)
    u=update or {};now=now or time.time();k=_ease(enter)
    center(d,'UPDATES',50,18,P['label'])
    installed=str(u.get('installed') or '?')[:12]
    if u.get('running'):
        step=str(u.get('step') or '')
        m=re.search(r'(\d+)/(\d+)',step)
        if m and int(m.group(2)):
            # Fortschritt (z. B. Systemupdates 12/80) als wachsender Ring mit wanderndem Glanzpunkt
            frac=min(1,int(m.group(1))/int(m.group(2)))
            d.arc((16,16,224,224),135,405,fill=P['track'],width=12)
            gradient_arc(d,(16,16,224,224),135,135+270*frac,12,P['accent'],P['light'])
            glint=135+270*frac*(((phase or 0)*.6)%1)
            if frac>0:d.arc((16,16,224,224),glint,min(135+270*frac,glint+8),fill=(255,255,255),width=12)
            center(d,f'{round(frac*100)} %',84,30,P['text'])
            center(d,'Systemupdates' if step.startswith('Systemupdates') else 'Installation',120,15,P['label'])
            center(d,f'{m.group(1)} von {m.group(2)} Paketen',150,12,P['muted'])
            center(d,'Nicht ausschalten',172,12,P['warn'])
            return image
        d.arc((16,16,224,224),0,360,fill=P['track'],width=12)
        start=((phase or 0)*200)%360;gradient_arc(d,(16,16,224,224),start,start+110,12,P['bg'],P['accent'],step=6)
        center(d,'Wird',84,22,P['text']);center(d,'installiert …',110,22,P['text'])
        center(d,step[:22]+('…' if len(step)>22 else ''),150,12,P['muted'])
        center(d,'Nicht ausschalten',172,12,P['warn'])
        return image
    if u.get('newer'):
        gradient_arc(d,(16,16,224,224),135,135+270*k,12,P['accent'],P['light'])
        pulse=.75+.25*math.sin((phase or 0)*3) if phase is not None else 1
        center(d,'NEU',76,15,_mix(P['bg'],P['warn'],pulse))
        center(d,str(u.get('latest'))[:12],94,34,P['text'])
        center(d,'installiert: '+installed,140,13,P['muted'])
        center(d,'kommt heute Nacht' if u.get('auto') else 'In den Einstellungen',162,13,P['label'])
        if not u.get('auto'):center(d,'installieren',178,13,P['label'])
        return image
    d.arc((16,16,224,224),135,405,fill=P['track'],width=12)
    gradient_arc(d,(16,16,224,224),135,135+270*k,12,P['accent'],P['light'])
    center(d,installed,82,34,P['text'])
    if not u.get('online'):
        center(d,'Online-Update aus',132,14,P['muted']);return image
    if u.get('error'):
        center(d,'Server nicht',128,14,P['warn']);center(d,'erreichbar',146,14,P['warn'])
    else:
        pts=[(104,140),(115,151),(136,128)];seg1=min(1,k*2.2);seg2=max(0,min(1,k*2.2-1))
        if seg1>0:d.line((pts[0],(pts[0][0]+(pts[1][0]-pts[0][0])*seg1,pts[0][1]+(pts[1][1]-pts[0][1])*seg1)),fill=P['accent'],width=5,joint='curve')
        if seg2>0:d.line((pts[1],(pts[1][0]+(pts[2][0]-pts[1][0])*seg2,pts[1][1]+(pts[2][1]-pts[1][1])*seg2)),fill=P['accent'],width=5,joint='curve')
        center(d,'Aktuell',160,15,P['hand'])
    checked=u.get('checked') or 0
    if checked:
        mins=max(0,int((now-checked)//60))
        ago='gerade eben' if mins<2 else f'vor {mins} Min.' if mins<90 else f'vor {mins//60} Std.'
        center(d,'geprüft '+ago,184,11,P['muted'])
    return image


class Rotation:
    """Cycles pages every few seconds; hold() shows one page again for a full period."""
    def __init__(self,count,seconds=PAGE_SECONDS,clock=time.monotonic):
        self.count,self.seconds,self.clock=count,seconds,clock;self.start=clock()
    def page(self):return int((self.clock()-self.start)//self.seconds)%self.count
    def hold(self,index):self.start=self.clock()-index*self.seconds


class Pages:
    """Display 1: clock/cover, WLAN, system. Display 2: volume, status, updates (the admin code is never shown).
    A changed volume or mute state jumps display 2 back to the volume page."""
    def __init__(self,clock=time.monotonic):
        self.first=Rotation(3,clock=clock);self.second=Rotation(3,clock=clock);self.volume_key=None;self.update_key=None
    def select(self,state,fresh):
        key=(state.get('volume'),state.get('muted'),state.get('target')) if fresh else None
        if key is not None:
            if self.volume_key is not None and key!=self.volume_key:self.second.hold(0)
            self.volume_key=key
        update=(state.get('update') or {}) if fresh else {}
        ukey=(update.get('newer'),update.get('latest'),update.get('running'))
        if update.get('running'):self.second.hold(2)               # Installation läuft: Seite bleibt stehen
        elif self.update_key is not None and ukey!=self.update_key and update.get('newer'):self.second.hold(2)
        if fresh:self.update_key=ukey
        return self.first.page(),self.second.page()
    def frames(self,state,fresh,cover,info):
        first,second=self.select(state,fresh)
        one=(album_frame(state.get('music') if fresh else None,cover) if first==0
             else wlan_frame(info) if first==1 else system_frame(info))
        two=(volume_frame(state.get('volume') if fresh else None,state.get('muted') if fresh else False,state.get('target','pi')) if second==0
             else status_frame(info.get('errors') or []) if second==1 else update_frame(state.get('update') if fresh else None))
        return [one,two]


class DisplayWorker:
    """Jedes Display bekommt seinen eigenen Sende-Thread (eigener SPI-Bus): ein volles Bild auf
    Display 1 bremst Display 2 nicht mehr aus. Veraltete Bilder werden übersprungen."""
    def __init__(self,device):
        self.device=device;self.cond=threading.Condition();self.image=None;self.stop=False;self.error=''
        self.thread=threading.Thread(target=self.run,daemon=True);self.thread.start()
    def post(self,image):
        with self.cond:self.image=image;self.cond.notify()
    def idle(self):
        with self.cond:return self.image is None
    def run(self):
        while True:
            with self.cond:
                while self.image is None and not self.stop:self.cond.wait()
                if self.stop:return
                image,self.image=self.image,None
            try:
                self.device.show(image);self.error=''
            except OSError as error:
                if str(error)!=self.error:print('Runde Displays: '+str(error),flush=True)
                self.error=str(error)
    def close(self):
        with self.cond:self.stop=True;self.cond.notify()
        self.thread.join(2)


class Animator:
    """6.0: weicher Seitenwechsel (Wischen wie ein Uhrzeiger) und Einblend-Zeit für die neue Seite.
    Es werden nur geänderte Bereiche übertragen, deshalb bleibt das auch bei 4 MHz flüssig."""
    WIPE=.45
    def __init__(self,clock=time.monotonic):
        self.clock=clock;self.page=None;self.since=0.0;self.last=None;self.prev=None;self.wipe=True
    def enter(self,now):
        return min(1.0,max(0.0,(now-self.since-.08)/.75))
    def frame(self,page,render,motion=True):
        now=self.clock()
        if page!=self.page:
            self.prev=self.last if (motion and self.wipe and self.last is not None) else None
            self.page=page;self.since=now
        t=now-self.since
        image=render(self.enter(now) if motion else 1.0)
        if self.prev is not None and t<self.WIPE:
            p=_ease(t/self.WIPE);a=-90+360*p
            mask=Image.new('L',(SIZE,SIZE));ImageDraw.Draw(mask).pieslice((-60,-60,300,300),-90,a,fill=255)
            out=Image.composite(image,self.prev,mask)
        else:
            out=image;self.prev=None
        self.last=out
        return out
    def busy(self):
        return self.prev is not None or self.clock()-self.since<1.0


def _scaled(info,key,k):
    value=info.get(key)
    return dict(info,**{key:round(value*k),key+'_real':value}) if isinstance(value,(int,float)) and not isinstance(value,bool) else info


def dim(image,brightness):
    """The modules have no backlight pin, so brightness scales the picture itself (10-100 %)."""
    if not isinstance(brightness,int) or isinstance(brightness,bool) or brightness>=100:return image
    return ImageEnhance.Brightness(image).enhance(max(10,brightness)/100)


# ======================================================================
# 6.0: Startbildschirm (Logo zeichnet sich, Ring lädt) und Wartebild
# ======================================================================
BRAND=((139,92,246),(61,123,255),(34,211,238))


def _brand(t):
    t=min(1,max(0,t))
    return _mix(BRAND[0],BRAND[1],t*2) if t<.5 else _mix(BRAND[1],BRAND[2],(t-.5)*2)


def _ease(t):t=min(1,max(0,t));return 1-(1-t)**3


def _back(t):
    t=min(1,max(0,t));c=1.9;return 1+(c+1)*(t-1)**3+c*(t-1)**2


@functools.lru_cache(maxsize=4)
def _squircle(cx,cy,r,n=4,count=360):
    """Punkte des abgerundeten Logo-Bildschirms (Superellipse), oben mittig beginnend, im Uhrzeigersinn."""
    pts=[]
    for i in range(count+1):
        a=-math.pi/2+2*math.pi*i/count;c,s=math.cos(a),math.sin(a)
        pts.append((cx+r*math.copysign(abs(c)**(2/n),c),cy+r*math.copysign(abs(s)**(2/n),s)))
    return tuple(pts)


@functools.lru_cache(maxsize=4)
def _logo_fill(cx,cy,r):
    """Farbverlauf Violett → Blau → Türkis, als Squircle ausgeschnitten (RGBA)."""
    size=int(r*2)+4;grad=Image.new('RGB',(size,size));px=grad.load()
    for y in range(size):
        for x in range(size):px[x,y]=_brand((x+y)/(2*size))
    mask=Image.new('L',(size,size));ImageDraw.Draw(mask).polygon([(x-cx+size/2,y-cy+size/2) for x,y in _squircle(cx,cy,r)],fill=255)
    out=grad.convert('RGBA');out.putalpha(mask);return out


def font_bold(size):
    for path in ('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf','C:/Windows/Fonts/arialbd.ttf'):
        try:return ImageFont.truetype(path,size)
        except OSError:pass
    return font(size)


def logo_frame(t,bg=(5,8,14)):
    """Display 1: Rahmen zeichnet sich, füllt sich, Play-Symbol ploppt, Sendewelle, Schriftzug."""
    image=Image.new('RGB',(SIZE,SIZE),bg);d=ImageDraw.Draw(image)
    cx,cy,r=120,100,58;pts=_squircle(cx,cy,r)
    # weiches Leuchten hinter dem Logo
    glow=_ease((t-.2)/1.2)
    if glow>0:
        for k in range(6,0,-1):
            rad=r+k*9;d.ellipse((cx-rad,cy-rad,cx+rad,cy+rad),fill=_mix(bg,BRAND[1],.05*glow*(7-k)/6))
    draw=_ease(t/.9)
    if draw>0:
        n=max(2,int(len(pts)*draw))
        for i in range(1,n):d.line((pts[i-1],pts[i]),fill=_brand((pts[i][0]-cx+pts[i][1]-cy+2*r)/(4*r)),width=5)
    fill=_ease((t-.85)/.45)
    if fill>0:
        logo=_logo_fill(cx,cy,r);size=logo.width
        cut=int(size*(1-fill));part=logo.crop((0,cut,size,size))
        image.paste(part,(int(cx-size/2),int(cy-size/2)+cut),part)
    pop=_back((t-1.1)/.5) if t>1.1 else 0
    if pop>0:
        k=pop;tri=[(cx+5+x*k,cy+2+y*k) for x,y in ((-14,-23),(-14,23),(25,0))]
        d.polygon(tri,fill='white');d.line(tri+[tri[0]],fill='white',width=max(1,int(5*k)),joint='curve')
    for start,rad in ((1.5,12),(1.65,22)):
        a=_ease((t-start)/.3)
        if a>0:
            wx,wy=cx+16,cy-14
            d.arc((wx-rad,wy-rad,wx+rad,wy+rad),-60,-18,fill=_mix(BRAND[1],(255,255,255),.85*a),width=5)
    word='Raspi TV';f=font_bold(30)
    total=d.textlength(word,font=f);x=(SIZE-total)/2
    for i,ch in enumerate(word):
        a=_ease((t-1.75-i*.07)/.35)
        w=d.textlength(ch,font=f)
        if a>0 and ch!=' ':
            col=_brand(.4+.6*(i-6)) if i>=6 else (255,255,255)
            d.text((x,181+8*(1-a)),ch,font=f,fill=_mix(bg,col,a))
        x+=w
    return image


def ring_frame(t,version='',bg=(5,8,14)):
    """Display 2: Ring füllt sich mit dem Markenverlauf, in der Mitte Name und Version, dann „Bereit“."""
    image=Image.new('RGB',(SIZE,SIZE),bg);d=ImageDraw.Draw(image)
    track=_ease(t/.4)
    d.arc((16,16,224,224),135,135+270*track,fill=_mix(bg,(40,52,78),1),width=16)
    sweep=_ease((t-.35)/1.6)
    if sweep>0:
        end=135+270*sweep;angle=135
        while angle<end:
            stop=min(end,angle+3);d.arc((16,16,224,224),angle,stop+.6,fill=_brand((angle-135)/270),width=16);angle=stop
        # leuchtender Punkt an der Spitze
        a=math.radians(end);px,py=120+104*math.cos(a),120+104*math.sin(a)
        d.ellipse((px-9,py-9,px+9,py+9),fill=_mix(_brand(sweep),(255,255,255),.55))
    a=_ease((t-.5)/.5)
    if a>0:
        center(d,'RASPI-TV',62,16,_mix(bg,(170,190,212),a))
        center(d,str(int(100*sweep))+' %' if t<2.2 else '',96,40,_mix(bg,(239,249,255),a))
    if t>=2.2:
        b=_ease((t-2.2)/.4)
        center(d,'Bereit',92,38,_mix(bg,(239,249,255),b))
    if version:center(d,'Version '+str(version)[:12],170,13,_mix(bg,(133,155,181),a))
    return image


INTRO_SECONDS=3.2


def wait_frames(t,pal=None):
    """Solange Raspi-TV noch startet: Logo mit pulsierendem Leuchten und kreisender Ladebogen."""
    P=pal or PAL
    one=logo_frame(9,P['bg'])
    d=ImageDraw.Draw(one);center(d,'startet …',214,12,_mix(P['bg'],P['muted'],.6+.4*math.sin(t*3)))
    two=Image.new('RGB',(SIZE,SIZE),P['bg']);e=ImageDraw.Draw(two)
    e.arc((16,16,224,224),0,360,fill=P['track'],width=10)
    start=(t*240)%360;gradient_arc(e,(16,16,224,224),start,start+90,10,P['bg'],P['accent'],step=6)
    center(e,'Einen',92,18,P['label']);center(e,'Moment …',116,18,P['label'])
    return [one,two]


def play_intro(devices,running,version='',bg=(5,8,14),seconds=INTRO_SECONDS,clock=time.monotonic):
    """Beide Displays gleichzeitig (eigene SPI-Busse) – jedes zeichnet so viele Bilder, wie es schafft."""
    def run(device,make):
        start=clock()
        try:
            while running.is_set():
                t=clock()-start
                device.show(make(min(t,seconds)))
                if t>=seconds:break
        except OSError as error:print('Runde Displays: Startbild '+str(error),flush=True)
    makers=[lambda t:logo_frame(t,bg),lambda t:ring_frame(t,version,bg)]
    threads=[threading.Thread(target=run,args=(device,makers[i]),daemon=True) for i,device in enumerate(devices[:2])]
    for th in threads:th.start()
    for th in threads:th.join(seconds+20)


def cover_accent(image):
    """Kräftigste Farbe eines Albumcovers – die Displays nehmen sie als Akzent, solange Musik läuft."""
    small=image.convert('RGB').resize((24,24));best=[]
    for r,g,b in (small.get_flattened_data() if hasattr(small,'get_flattened_data') else small.getdata()):
        hi,lo=max(r,g,b),min(r,g,b)
        best.append(((hi-lo)*hi,(r,g,b)))
    best.sort(reverse=True);top=[c for _,c in best[:max(1,len(best)//8)]]
    if best[0][0]<1500:return None          # graues Cover: Design-Farbe behalten
    avg=tuple(sum(c[i] for c in top)//len(top) for i in range(3))
    return '#%02x%02x%02x'%avg


# ======================================================================
# 7.0: Teensy 4.1 per USB – der Teensy zeichnet beide Displays selbst (eigene Firmware,
# teensy/raspi-tv-displays), der Pi schickt nur noch Zustand, Albumcover und Befehle.
# ======================================================================
TEENSY_LINK=Path('/dev/raspi-tv-displays')
TEENSY_HEX=Path(__file__).resolve().parent/'teensy'/'raspi-tv-displays.hex'
TEENSY_STATUS=Path('/var/lib/raspi-tv-round/teensy.json')


def teensy_status(connected,port='',firmware='',path=None,flashing=''):
    path=path or TEENSY_STATUS
    try:
        path.parent.mkdir(parents=True,exist_ok=True)
        tmp=path.with_suffix('.tmp')
        tmp.write_text(json.dumps({'connected':connected,'port':port,'firmware':firmware,'flashing':flashing,'at':int(time.time())}))
        os.replace(tmp,path)
    except OSError:pass


def teensy_port(root=Path('/')):
    """Teensy (USB 16c0:0483) suchen: zuerst der udev-Link, sonst über sysfs."""
    link=root/TEENSY_LINK.relative_to('/')
    if link.exists():return str(link)
    for tty in sorted((root/'sys/class/tty').glob('ttyACM*')):
        dev=(tty/'device').resolve()
        for parent in (dev,dev.parent,dev.parent.parent):
            try:
                vid=(parent/'idVendor').read_text().strip();pid=(parent/'idProduct').read_text().strip()
            except OSError:continue
            if vid=='16c0' and pid in ('0483','0489','048a','048b','048c','04d0','04d1','04d2','04d3','04d4'):
                return str(root/'dev'/tty.name)
    return None


def fetch_cover(url):
    """Cover/Logo laden: Spotify, Videoseiten, Senderlogos (https) und Logos vom Pi selbst; höchstens 512 KB,
    nur gängige Bildformate."""
    parsed=urlsplit(url or '')
    local=parsed.scheme=='http' and parsed.hostname=='127.0.0.1' and parsed.port==8765
    if not (parsed.scheme=='https' or local):return None
    with urllib.request.urlopen(url,timeout=3) as response:raw=response.read(524289)
    if len(raw)>524288:return None
    candidate=Image.open(io.BytesIO(raw),formats=['JPEG','PNG','WEBP','GIF'])
    if candidate.width*candidate.height>4_000_000:return None
    candidate.load()
    return candidate.convert('RGB')


class TeensyLink:
    """Zeilenprotokoll über USB-Seriell (ohne pyserial): S key=value…, C <Bytes>+Cover, F/R Testbild, I Intro."""
    def __init__(self,port,opener=os.open):
        import termios,tty
        self.fd=opener(port,os.O_RDWR|os.O_NOCTTY|os.O_NONBLOCK)
        try:
            tty.setraw(self.fd)
            attrs=termios.tcgetattr(self.fd);attrs[4]=attrs[5]=termios.B115200
            termios.tcsetattr(self.fd,termios.TCSANOW,attrs)
        except (termios.error,OSError):pass
        self.buffer=b'';self.version=None;self.port=port
    def write(self,data):
        if self.fd is None:raise OSError('Teensy-Verbindung geschlossen')
        view=memoryview(data)
        deadline=time.monotonic()+3
        while view:
            try:n=os.write(self.fd,view);view=view[n:]
            except BlockingIOError:
                if time.monotonic()>deadline:raise OSError('Teensy antwortet nicht (Puffer voll)')
                time.sleep(.002)
    def line(self,text):self.write(text.encode('utf-8','replace')+b'\n')
    def read_lines(self):
        if self.fd is None:return []
        try:
            while True:
                chunk=os.read(self.fd,4096)
                if not chunk:break
                self.buffer+=chunk
        except BlockingIOError:pass
        lines=[]
        while b'\n' in self.buffer:
            raw,self.buffer=self.buffer.split(b'\n',1);text=raw.decode('utf-8','replace').strip()
            if text.startswith('HELLO raspi-tv-displays'):
                self.version=text.split()[2] if len(text.split())>2 else '0'
            if text:lines.append(text)
        return lines
    def close(self):
        if self.fd is None:return
        try:os.close(self.fd)
        except OSError:pass
        self.fd=None


def rgb565_le(image):
    """240×240-Bild als RGB565 in der Byte-Reihenfolge des Teensy (Little Endian)."""
    rgb=image.convert('RGB').resize((SIZE,SIZE))
    if _np is not None:
        a=_np.asarray(rgb,dtype=_np.uint16)
        return (((a[...,0]>>3)<<11)|((a[...,1]>>2)<<5)|(a[...,2]>>3)).astype('<u2').tobytes()
    return b''.join((((r>>3)<<11)|((g>>2)<<5)|(b>>3)).to_bytes(2,'little') for r,g,b in rgb.getdata())


def cover_square(image):
    w,h=image.size;side=min(w,h)
    return image.crop(((w-side)//2,(h-side)//2,(w-side)//2+side,(h-side)//2+side)).resize((SIZE,SIZE),Image.LANCZOS)


def _clean(value,limit=90):
    return str(value if value is not None else '').replace('\t',' ').replace('\n',' ').replace('\r',' ')[:limit]


def teensy_state_line(state,info,accent,fresh,now=None):
    """Zustand für die Firmware als eine Zeile „S key=value<TAB>…“."""
    now=now if now is not None else time.time()
    offset=datetime.datetime.now().astimezone().utcoffset()
    local=int(now+(offset.total_seconds() if offset else 0))
    music=(state.get('music') or {}) if fresh else {}
    palette=state.get('palette') or {}
    update=state.get('update') or {}
    errors=info.get('errors') or []
    def num(v):return str(int(v)) if isinstance(v,(int,float)) and not isinstance(v,bool) else '-1'
    checked=update.get('checked') or 0
    pairs=[('t',str(local)),('v',num(state.get('volume') if fresh else None)),('m','1' if state.get('muted') else '0'),
           ('tg',_clean(state.get('target','pi'),10)),('pl','1' if music.get('playing') else '0'),
           ('pa','1' if music.get('paused') else '0'),('ti',_clean(music.get('title'))),('ar',_clean(music.get('artist'))),
           ('so',_clean(music.get('source') or 'SPOTIFY',14)),
           ('ac',_clean(accent or palette.get('accent','#6d5dfc'),8)),('bg',_clean(palette.get('bg','#0b0d12'),8)),
           ('br',num(state.get('brightness',100))),('mo','0' if state.get('motion')=='off' else '1'),
           ('cpu',num(info.get('cpu'))),('tmp',num(info.get('temp'))),('ram',num(info.get('ram'))),
           ('sig',num(info.get('signal'))),('wl','1' if info.get('wlan') else '0'),('ss',_clean(info.get('ssid'),38)),
           ('ne',str(len(errors))),('e1',_clean(errors[0] if errors else '',94)),
           ('ui',_clean(update.get('installed'),14)),('ul',_clean(update.get('latest'),14)),
           ('un','1' if update.get('newer') else '0'),('ur','1' if update.get('running') else '0'),
           ('us',_clean(update.get('step'),46)),('ue','1' if update.get('error') else '0'),
           ('uo','1' if update.get('online') else '0'),('ua','0' if update.get('auto') is False else '1'),
           ('uc',str(int((now-checked)//60)) if checked else '-1'),('ver',_clean(state.get('version'),14))]
    return 'S '+'\t'.join(f'{k}={v}' for k,v in pairs)


def _ver(text):
    try:return tuple(int(x) for x in str(text).split('.')[:3])
    except ValueError:return (0,)


TEENSY_FLASH_LOG=Path('/var/lib/raspi-tv-round/teensy-flash.json')


def teensy_flash_allowed(target,path=None,now=None):
    """Höchstens 2 Versuche pro Firmware-Version und Stunde – verhindert eine Endlosschleife,
    falls das Einspielen scheitert (dann hilft einmal der Knopf am Teensy)."""
    path=path or TEENSY_FLASH_LOG;now=now or time.time()
    log=read_test_file(path) if path.exists() else {}
    if log.get('target')==target and now-log.get('at',0)<3600 and log.get('attempts',0)>=2:return False
    attempts=log.get('attempts',0)+1 if log.get('target')==target and now-log.get('at',0)<3600 else 1
    try:
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps({'target':target,'attempts':attempts,'at':int(now) if attempts==1 else log.get('at',int(now))}))
    except OSError:pass
    return True


def teensy_bootloader(link):
    """Teensy ohne Knopf in den Programmiermodus schicken: Befehl „B“ an die Firmware, zusätzlich der
    134-Baud-Trick des Teensy-USB-Stacks (klappt auch mit fremder Firmware mit USB-Seriell)."""
    try:link.line('B');time.sleep(.3)
    except OSError:pass
    try:
        import termios
        attrs=termios.tcgetattr(link.fd);attrs[4]=attrs[5]=termios.B134
        termios.tcsetattr(link.fd,termios.TCSANOW,attrs)
    except Exception:pass
    link.close()


def teensy_flash(link,hex_path=TEENSY_HEX,run=subprocess.run,target=''):
    """Neue Firmware automatisch einspielen – ohne Abstecken und ohne Knopf."""
    if not hex_path.exists() or not shutil.which('teensy_loader_cli'):
        print('Runde Displays: Teensy-Firmware kann nicht eingespielt werden (teensy_loader_cli fehlt).',flush=True)
        return False
    if not teensy_flash_allowed(target):
        print('Runde Displays: Firmware-Update wurde schon zweimal versucht – bitte einmal den Knopf am Teensy drücken.',flush=True)
        return False
    print(f'Runde Displays: Teensy-Firmware {link.version or "?"} -> {target or "?"} wird eingespielt …',flush=True)
    teensy_status(True,link.port,link.version or '',flashing=target)
    teensy_bootloader(link)
    # Der Programmiermodus startet per udev auch raspi-tv-teensy-flash.service; „start“ wartet auf dieselbe
    # Einheit, so spielt immer nur ein Programm die Firmware ein.
    if shutil.which('systemctl'):
        result=run(['systemctl','start','raspi-tv-teensy-flash.service'],capture_output=True,text=True,timeout=150)
    else:
        result=run(['teensy_loader_cli','--mcu=TEENSY41','-w','-v',str(hex_path)],capture_output=True,text=True,timeout=120)
    print('Runde Displays: Firmware-Update '+('fertig' if result.returncode==0 else 'fehlgeschlagen: '+(result.stdout+result.stderr).strip()[-300:]),flush=True)
    return result.returncode==0


class TeensyDevice:
    """Stellvertreter für den Display-Test (RoundDisplayTest): Testbild wird als Rohbild gesendet."""
    class _Spi:max_speed_hz=SPI_SPEED
    def __init__(self,link,number):self.link,self.number,self.spi=link,number,self._Spi()
    def reinitialize(self,speed):pass
    def set_speed(self,speed):pass
    def show(self,image):
        if image is None:self.link.line(f'R {self.number}');return
        data=rgb565_le(image);self.link.line(f'F {self.number} {len(data)}');self.link.write(data)


def teensy_main(port,running,clock=time.monotonic):
    link=TeensyLink(port);system=SystemInfo();state={};cover=None;cover_url='';cover_color=None;sent_cover=None
    info=system.snapshot();info_at=clock();last_send=0.0;intro_seq=None;hello_at=clock();flashed=False;sent_hz=None
    display_test=RoundDisplayTest([TeensyDevice(link,1),TeensyDevice(link,2)])
    link.line('?')
    print(f'Runde Displays: Teensy 4.1 an {port}',flush=True)
    try:
        while running.is_set():
            for text in link.read_lines():
                if text.startswith('HELLO'):
                    print('Runde Displays: '+text,flush=True);teensy_status(True,port,link.version or '')
            bundled=(TEENSY_HEX.parent/'version').read_text().strip() if (TEENSY_HEX.parent/'version').exists() else ''
            if (not flashed and link.version and bundled and _ver(link.version)<_ver(bundled)) or (
                    not flashed and link.version is None and clock()-hello_at>8 and bundled):
                flashed=True
                if teensy_flash(link,target=bundled):
                    raise SystemExit(3)   # Dienst startet neu und verbindet sich mit der neuen Firmware
                if link.fd is None or not os.path.exists(port):raise SystemExit(3)
                print('Runde Displays: weiter mit der vorhandenen Firmware.',flush=True)
            try:
                with urllib.request.urlopen('http://127.0.0.1:8765/api/round-display',timeout=4) as response:
                    state=json.loads(response.read(16384))
            except Exception:pass
            url=(state.get('music') or {}).get('cover','')
            if url!=cover_url:
                cover_url=url;cover=None;cover_color=None
                try:
                    candidate=fetch_cover(url) if url else None
                    if candidate is not None:cover=cover_square(candidate);cover_color=cover_accent(candidate)
                except Exception as error:print('Runde Displays: Cover '+str(error),flush=True)
            if clock()-info_at>=2:info=system.snapshot();info_at=clock()
            fresh=time.time()-state.get('time',0)<6
            music=state.get('music') or {}
            palette=state.get('palette') or {}
            accent=cover_color if (cover_color and palette.get('source')!='classic' and music.get('playing')) else palette.get('accent')
            if cover is not None and sent_cover!=cover_url:
                data=rgb565_le(cover);link.line(f'C {len(data)}');link.write(data);sent_cover=cover_url
            line=teensy_state_line(state,info,accent,fresh)
            if cover is None:line+='\tcv=0'
            if clock()-last_send>=.5:link.line(line);last_send=clock()
            hz=state.get('teensy_hz')
            if isinstance(hz,int) and hz!=sent_hz and link.version:
                link.line(f'P {hz}');sent_hz=hz
            if 'intro_seq' in state and state['intro_seq']!=intro_seq:
                if intro_seq is not None:link.line('I')
                intro_seq=state['intro_seq']
            display_test.tick([None,None])
            time.sleep(.1)
    except OSError as error:
        print('Runde Displays: Teensy getrennt ('+str(error)+')',flush=True)
    finally:
        teensy_status(False,port,link.version or '')
        display_test.close()
        link.close()


def main(test=False):
    running=threading.Event();running.set()
    def stop(*_):
        running.clear()
        if test:raise KeyboardInterrupt
    signal.signal(signal.SIGTERM,stop)
    signal.signal(signal.SIGINT,stop)
    port=teensy_port()
    if port and not test:
        return teensy_main(port,running)
    import spidev
    from gpiozero import DigitalOutputDevice
    devices=[];pins=[];display_test=None
    try:
        devices,pins=open_displays(spidev,DigitalOutputDevice)
        if test:
            for number,device in enumerate(devices,1):
                device.show(test_frame(number))
            print('Testbilder gesendet: 1 = SPI0 / Uhr, 2 = SPI1 / Lautstaerke.',flush=True)
            print('L muss links stehen, R rechts. Farbfelder: Rot, Gruen, Blau.',flush=True)
            print('Ob die Displays etwas anzeigen, kann SPI ohne Rueckkanal nicht erkennen.',flush=True)
            input('Bitte ein Foto machen. Danach Eingabetaste zum Beenden: ')
            return
        display_test=RoundDisplayTest(devices)
        state={'music':{},'volume':None,'muted':False,'target':'pi'};cover=None;cover_url='';cover_color=None
        def poll():
            nonlocal state,cover,cover_url,cover_color
            last_error=''
            while running.is_set():
                try:
                    with urllib.request.urlopen('http://127.0.0.1:8765/api/round-display',timeout=4) as response:
                        state=json.loads(response.read(16384))
                    url=(state.get('music') or {}).get('cover','')
                    if url!=cover_url:
                        cover_url=url;cover=None;cover_color=None
                        candidate=fetch_cover(url) if url else None
                        if candidate is not None:
                            cover=candidate
                            try:cover_color=cover_accent(candidate)
                            except Exception:cover_color=None
                    if last_error:
                        print('Runde Displays: Datenverbindung wiederhergestellt.',flush=True)
                        last_error=''
                except Exception as error:
                    message=str(error)
                    if message!=last_error:print('Runde Displays: '+message,flush=True)
                    last_error=message
                time.sleep(.5)
        threading.Thread(target=poll,daemon=True).start()
        # 6.0: Startbildschirm, bis Raspi-TV antwortet (höchstens kurz warten, damit die Version bekannt ist)
        intro_seq=None;started=time.monotonic()
        for _ in range(6):
            if 'time' in state or not running.is_set():break
            time.sleep(.25)
        if state.get('intro',True):play_intro(devices,running,state.get('version',''))
        intro_seq=state.get('intro_seq')
        global PAL
        pages=Pages();system=SystemInfo();info=system.snapshot();info_at=time.monotonic();brightness=100
        animators=[Animator(),Animator()];shown_volume=None
        workers=[DisplayWorker(device) for device in devices];speed=SPI_SPEED
        teensy_check=time.monotonic()
        while running.is_set():
            if time.monotonic()-teensy_check>5:
                teensy_check=time.monotonic()
                if teensy_port():   # Teensy eingesteckt: Dienst neu starten und auf USB umschalten
                    print('Runde Displays: Teensy gefunden – wechsle auf USB.',flush=True);raise SystemExit(3)
            if 'intro_seq' in state and state['intro_seq']!=intro_seq:
                if intro_seq is not None:play_intro(devices,running,state.get('version',''))
                intro_seq=state['intro_seq']
            palette=state.get('palette') or {}
            music=state.get('music') or {}
            accent=cover_color if (cover_color and palette.get('source')!='classic' and music.get('playing')) else palette.get('accent','#57dcc7')
            PAL=blend_palette(PAL,make_palette(accent,palette.get('bg','#050b16')),.35)
            if 'time' not in state and time.monotonic()-started<90:
                normal=[dim(frame,brightness) for frame in wait_frames(time.monotonic())]
                for number,device in enumerate(devices,1):device.show(normal[number-1])
                time.sleep(.05);continue
            fresh=time.time()-state.get('time',0)<6
            if time.monotonic()-info_at>=2:info=system.snapshot();info_at=time.monotonic()
            if isinstance(state.get('brightness'),int):brightness=state['brightness']
            motion=state.get('motion','full')!='off'
            first,second=pages.select(state,fresh)
            music_now=state.get('music') if fresh else None
            target=state.get('volume') if fresh else None
            if isinstance(target,(int,float)) and not isinstance(target,bool):
                shown_volume=target if (shown_volume is None or not motion) else shown_volume+(target-shown_volume)*.35
                if abs(shown_volume-target)<.5:shown_volume=target
            else:shown_volume=None
            phase=time.monotonic() if motion else None
            def one(k):
                if first==0:return album_frame(music_now,cover,phase=phase,enter=k)
                return wlan_frame(_scaled(info,'signal',_ease(k))) if first==1 else system_frame(_scaled(info,'cpu',_ease(k)))
            def two(k):
                if second==0:
                    v=shown_volume*_ease(k) if shown_volume is not None else None
                    return volume_frame(v,state.get('muted') if fresh else False,state.get('target','pi'))
                if second==1:return status_frame(info.get('errors') or [],k)
                return update_frame(state.get('update') if fresh else None,k,phase)
            wanted=state.get('spi_hz') if state.get('spi_hz') in SPEEDS else SPI_SPEED
            if wanted!=speed and not display_test.active:
                for device in devices:device.set_speed(wanted)
                speed=wanted;print(f'Runde Displays: Übertragung {speed//1_000_000} MHz',flush=True)
            normal=[dim(animators[0].frame(first,one,motion),brightness),dim(animators[1].frame(second,two,motion),brightness)]
            testing=display_test.tick(normal)
            for number,worker in enumerate(workers,1):
                if number!=testing:worker.post(normal[number-1])
            installing=bool((state.get('update') or {}).get('running')) and second==2
            lively=motion and (any(a.busy() for a in animators) or first==0 or shown_volume!=target or installing)
            time.sleep(.04 if lively else .25)
    finally:
        for worker in locals().get('workers') or []:
            try:worker.close()
            except Exception:pass
        if display_test is not None:
            try:display_test.close()
            except OSError:pass
        for device in devices:
            try:device.show(Image.new('RGB',(240,240)));device.command(0x28)
            except OSError:pass
            device.spi.close()
        for pin in pins:pin.close()

if __name__=='__main__':main(test='--test' in sys.argv[1:])
