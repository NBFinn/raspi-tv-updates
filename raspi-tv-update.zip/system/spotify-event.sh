#!/bin/sh
# Raspi-TV: librespot meldet hier, was über Spotify Connect läuft.
# Wird als TV-Benutzer aufgerufen; schreibt den Stand für die Oberfläche.
exec python3 - <<'PYEOF'
import json, os, time
d = os.path.expanduser("~/.cache/raspi-tv")
os.makedirs(d, exist_ok=True)
f = os.path.join(d, "spotify.json")
try:
    cur = json.load(open(f))
except Exception:
    cur = {}
ev = os.environ.get("PLAYER_EVENT", "")
e = os.environ.get
if ev == "track_changed":
    covers = [c for c in (e("COVERS") or "").split("\n") if c]
    cur.update(title=e("NAME", ""), artist=", ".join(a for a in (e("ARTISTS") or "").split("\n") if a),
               album=e("ALBUM", ""), cover=covers[0] if covers else "", duration=int(e("DURATION_MS") or 0))
elif ev in ("playing", "started"):
    cur.update(state="playing", position=int(e("POSITION_MS") or 0))
elif ev == "paused":
    cur.update(state="paused", position=int(e("POSITION_MS") or 0))
elif ev in ("stopped", "session_disconnected", "unavailable"):
    cur.update(state="stopped")
else:
    raise SystemExit(0)
cur["at"] = time.time()
tmp = f + ".tmp"
json.dump(cur, open(tmp, "w"))
os.replace(tmp, f)
PYEOF
