#!/usr/bin/env bash
# Startet Chromium im Kiosk-Modus und startet ihn neu, wenn er beendet wird.
# Home/F12 wechselt per Erweiterung zum Launcher; nur Shift+F12 startet Chromium neu.

PROFILE="$HOME/.config/raspi-tv-browser"
HOME_URL="http://127.0.0.1:8765/"
RECOVERY_URL="http://127.0.0.1:8767/local"
BROWSER="$(command -v chromium-browser || command -v chromium)"

# ChromeOS-User-Agent: Netflix & Co. liefern damit den Player statt "Browser nicht unterstützt"
MAJOR="$("$BROWSER" --version 2>/dev/null | grep -oE '[0-9]+' | head -1)"
MAJOR="${MAJOR:-130}"
UA="Mozilla/5.0 (X11; CrOS aarch64 15633.69.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${MAJOR}.0.0.0 Safari/537.36"

# Zuerst die normale TV-Oberflaeche starten; nur bei Ausfall zur Admin-Anmeldung.
for _ in $(seq 1 40); do
  curl -fs --connect-timeout 1 --max-time 2 "$HOME_URL" >/dev/null && break
  sleep 0.5
done

stopping() { [ "$(systemctl is-system-running 2>/dev/null)" = stopping ]; }
BPID=""
stop_browser() {
  trap - TERM HUP INT
  [ -z "$BPID" ] || kill "$BPID" 2>/dev/null || true
  exit 0
}
trap stop_browser TERM HUP INT
LOG=/var/log/raspi-tv/browser.log
[ -w "$(dirname "$LOG")" ] || LOG="$HOME/raspi-tv-browser.log"
while ! stopping; do
  START_URL="$HOME_URL"
  if ! curl -fs --connect-timeout 1 --max-time 2 "$HOME_URL" >/dev/null; then
    START_URL="$RECOVERY_URL"
  fi
  # "Chromium wurde nicht korrekt beendet"-Hinweis unterdrücken
  PREFS="$PROFILE/Default/Preferences"
  if [[ -f "$PREFS" ]]; then
    sed -i 's/"exited_cleanly":false/"exited_cleanly":true/; s/"exit_type":"[^"]*"/"exit_type":"Normal"/' "$PREFS"
  fi

  EXTENSION_ARGS=(--load-extension=/opt/raspi-tv/extension)
  if [ "$(python3 /opt/raspi-tv/browser-guard.py mode 2>/dev/null)" = safe ]; then
    EXTENSION_ARGS=(--disable-extensions)
    START_URL="$RECOVERY_URL"
  fi
  if [ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt 2000000 ]; then mv -f -- "$LOG" "$LOG.1"; fi
  BROWSER_STARTED=$(date +%s)
  "$BROWSER" \
    --user-data-dir="$PROFILE" \
    --kiosk --start-fullscreen \
    --noerrdialogs --disable-infobars --disable-session-crashed-bubble \
    --no-first-run --no-default-browser-check \
    --autoplay-policy=no-user-gesture-required \
    --disable-renderer-backgrounding --disable-background-timer-throttling \
    --check-for-update-interval=31536000 \
    --lang=de \
    --password-store=basic \
    "${EXTENSION_ARGS[@]}" \
    --user-agent="$UA" \
    "$START_URL" >>"$LOG" 2>&1 &
  BPID=$!
  wait "$BPID"
  BROWSER_EXIT=$?
  BPID=""
  stopping && break
  if [[ "$BROWSER_EXIT" != 0 && "$BROWSER_EXIT" != 130 && "$BROWSER_EXIT" != 143 ]]; then
    curl -fs --max-time 2 -H 'Origin: http://127.0.0.1:8765' -H 'Content-Type: text/plain' \
      --data "{\"message\":\"Browser beendet mit Exitcode $BROWSER_EXIT\"}" \
      http://127.0.0.1:8767/report >/dev/null 2>&1 || true
  fi
  python3 /opt/raspi-tv/browser-guard.py exit --seconds "$(( $(date +%s) - BROWSER_STARTED ))" --code "$BROWSER_EXIT" 2>/dev/null || true
  sleep 1
done
