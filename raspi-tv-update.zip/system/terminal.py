"""Raspi-TV OS – Terminal-Sitzungen (Pseudo-Terminals) für die Oberfläche.

Die Sitzungen laufen auf dem Pi weiter, auch wenn die Seite verlassen wird (z. B. Spotify spielt
weiter, wenn man zur Startseite geht). Die Seite holt die Ausgabe per Long-Poll und schickt
Tastendrücke zurück. Ausgabe wird als Bytes gepuffert (letzte 512 KB), damit ein neu geöffnetes
Fenster den aktuellen Bildschirm wieder aufbauen kann.
"""
import base64
import fcntl
import os
import signal
import struct
import subprocess
import termios
import threading
import time

KEEP = 512 * 1024
_sessions = {}
_lock = threading.Lock()


class Session:
    def __init__(self, sid, argv, env, cwd, cols, rows, title):
        self.id, self.title, self.argv = sid, title, argv
        self.cond = threading.Condition()
        self.buf = bytearray()
        self.base = 0          # Position des ersten Bytes in buf (gesamt geschriebene Bytes - len(buf))
        self.alive = True
        self.code = None
        self.started = time.time()
        self.listeners = []    # Rückrufe für jede Ausgabe (z. B. Anmelde-Link erkennen)
        master, slave = os.openpty()
        _winsize(slave, cols, rows)

        def child_setup():
            os.setsid()
            fcntl.ioctl(0, termios.TIOCSCTTY, 0)

        self.proc = subprocess.Popen(argv, stdin=slave, stdout=slave, stderr=slave, env=env, cwd=cwd,
                                     preexec_fn=child_setup, close_fds=True)
        os.close(slave)
        self.fd = master
        threading.Thread(target=self._reader, daemon=True).start()

    @property
    def seq(self):
        return self.base + len(self.buf)

    def _reader(self):
        while True:
            try:
                data = os.read(self.fd, 65536)
            except OSError:
                data = b""
            if not data:
                break
            with self.cond:
                self.buf += data
                if len(self.buf) > KEEP:
                    cut = len(self.buf) - KEEP
                    del self.buf[:cut]
                    self.base += cut
                self.cond.notify_all()
            for fn in list(self.listeners):
                try:
                    fn(self, data)
                except Exception:  # noqa: BLE001
                    pass
        try:
            self.code = self.proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.code = None
        with self.cond:
            self.alive = False
            self.cond.notify_all()
        try:
            os.close(self.fd)
        except OSError:
            pass

    def read(self, since, wait):
        """Ausgabe ab Position since; wartet bis zu wait Sekunden auf Neues."""
        end = time.time() + wait
        with self.cond:
            while self.alive and since >= self.seq and time.time() < end:
                self.cond.wait(max(0.05, end - time.time()))
            reset = since < self.base or since > self.seq
            start = self.base if reset else since
            chunk = bytes(self.buf[start - self.base:])
            return {"id": self.id, "data": base64.b64encode(chunk).decode(), "seq": self.seq, "reset": reset,
                    "alive": self.alive, "code": self.code}

    def write(self, text):
        if not self.alive:
            return
        data = text.encode("utf-8", "replace") if isinstance(text, str) else bytes(text)
        while data:
            n = os.write(self.fd, data)
            data = data[n:]

    def resize(self, cols, rows):
        if self.alive:
            _winsize(self.fd, cols, rows)
            try:
                os.killpg(os.getpgid(self.proc.pid), signal.SIGWINCH)
            except OSError:
                pass

    def kill(self):
        if not self.alive:
            return
        try:
            os.killpg(os.getpgid(self.proc.pid), signal.SIGHUP)
        except OSError:
            pass
        for _ in range(20):
            if self.proc.poll() is not None:
                return
            time.sleep(0.1)
        try:
            os.killpg(os.getpgid(self.proc.pid), signal.SIGKILL)
        except OSError:
            pass

    def info(self):
        return {"id": self.id, "title": self.title, "alive": self.alive, "seq": self.seq, "started": int(self.started)}


def _winsize(fd, cols, rows):
    cols = max(20, min(400, int(cols or 80)))
    rows = max(5, min(200, int(rows or 24)))
    fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))


def get(sid):
    return _sessions.get(sid)


def start(sid, argv, env, cwd="/", cols=80, rows=24, title=""):
    """Laufende Sitzung zurückgeben oder neu starten."""
    with _lock:
        s = _sessions.get(sid)
        if s and s.alive:
            s.resize(cols, rows)
            return s
        s = Session(sid, argv, env, cwd, cols, rows, title)
        _sessions[sid] = s
        return s


def stop(sid):
    s = _sessions.get(sid)
    if s:
        s.kill()


def all_info():
    return [s.info() for s in _sessions.values()]
