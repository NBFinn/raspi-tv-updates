#!/usr/bin/env python3
"""Raspi-TV OS – Live-TV anhalten (Timeshift).

Drückt man beim Fernsehen auf Pause, nimmt der Pi den laufenden HLS-Sender ab
genau dieser Stelle auf die Speicherkarte auf. Beim Weiterschauen spielt der
Fernseher die Aufnahme ab, während im Hintergrund weiter aufgenommen wird –
man schaut also „zeitversetzt“ und kann vor- und zurückspulen.

Ablauf
  * Hauptliste lesen, passende Qualität wählen (höchstens 720p, spart Platz)
  * gibt es eine getrennte Tonspur, wird sie mit aufgenommen
  * neue Segmente laufend herunterladen und eine lokale EVENT-Playlist schreiben
  * Grenzen: 2 Stunden oder weniger als 1 GB freier Speicher

Wird von features.py benutzt (start/stop/status/serve).
"""
import os
import re
import shutil
import threading
import time
import urllib.request
from urllib.parse import urljoin, urlparse

UA = "Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36 Raspi-TV"
MAX_SECONDS = 2 * 3600
MIN_FREE = 1024 ** 3
MAX_HEIGHT = 720
IDLE_STOP = 120   # Sekunden ohne Abfrage -> Aufnahme beenden
NAME_RE = re.compile(r"^[a-z0-9_.-]{1,64}$")
CTYPES = {".m3u8": "application/vnd.apple.mpegurl", ".ts": "video/mp2t", ".aac": "audio/aac",
          ".m4s": "video/iso.segment", ".mp4": "video/mp4", ".m4a": "audio/mp4", ".key": "application/octet-stream",
          ".vtt": "text/vtt"}


class TimeshiftError(Exception):
    pass


def _fetch(url, limit=60_000_000, timeout=20, headers=None):
    h = {"User-Agent": UA}
    h.update(headers or {})
    req = urllib.request.Request(url, headers=h)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read(limit + 1)
        final = r.geturl()
    if len(data) > limit:
        raise TimeshiftError("Segment zu groß")
    return data, final


def _attrs(s):
    """Attributliste einer HLS-Zeile (KEY=VALUE,KEY="VALUE") -> dict"""
    out = {}
    for m in re.finditer(r'([A-Z0-9-]+)=("[^"]*"|[^,]*)', s):
        v = m.group(2)
        out[m.group(1)] = v[1:-1] if v.startswith('"') else v
    return out


def parse_master(text, base):
    """-> (variants, audio) ; variants: [{url, bw, height, attrs}], audio: {group: [{url, attrs}]}"""
    lines = [ln.strip() for ln in text.splitlines()]
    variants, audio = [], {}
    for i, ln in enumerate(lines):
        if ln.startswith("#EXT-X-STREAM-INF:"):
            a = _attrs(ln.split(":", 1)[1])
            uri = next((x for x in lines[i + 1:] if x and not x.startswith("#")), None)
            if not uri:
                continue
            res = a.get("RESOLUTION", "")
            h = int(res.split("x")[1]) if "x" in res and res.split("x")[1].isdigit() else 0
            variants.append({"url": urljoin(base, uri), "bw": int(a.get("BANDWIDTH", "0") or 0), "height": h, "attrs": a})
        elif ln.startswith("#EXT-X-MEDIA:"):
            a = _attrs(ln.split(":", 1)[1])
            if a.get("TYPE") == "AUDIO" and a.get("URI"):
                audio.setdefault(a.get("GROUP-ID", ""), []).append({"url": urljoin(base, a["URI"]), "attrs": a})
    return variants, audio


def pick_variant(variants):
    # Nur Varianten mit Bild (Audio-only-Varianten haben oft keine Auflösung und sehr wenig Bandbreite)
    video = [v for v in variants if v["height"]] or variants
    fit = [v for v in video if not v["height"] or v["height"] <= MAX_HEIGHT]
    if fit:
        return max(fit, key=lambda v: (v["height"], v["bw"]))
    return min(video, key=lambda v: (v["height"], v["bw"]))


def pick_audio(renditions, lang="de"):
    for r in renditions:
        if r["attrs"].get("LANGUAGE", "").lower().startswith(lang) and r["attrs"].get("DEFAULT") == "YES":
            return r
    for r in renditions:
        if r["attrs"].get("LANGUAGE", "").lower().startswith(lang):
            return r
    for r in renditions:
        if r["attrs"].get("DEFAULT") == "YES":
            return r
    return renditions[0] if renditions else None


def parse_media(text, base):
    """Medien-Playlist -> dict(target, seq, segments=[{seq, dur, url, disc, key, map}], ended)"""
    target, seq, ended = 6.0, 0, False
    segs, dur, disc = [], None, False
    key, cur_map = None, None
    n = None
    for ln in text.splitlines():
        ln = ln.strip()
        if not ln:
            continue
        if ln.startswith("#EXT-X-TARGETDURATION:"):
            target = float(ln.split(":", 1)[1] or 6)
        elif ln.startswith("#EXT-X-MEDIA-SEQUENCE:"):
            seq = int(ln.split(":", 1)[1] or 0)
        elif ln.startswith("#EXTINF:"):
            dur = float(ln.split(":", 1)[1].split(",")[0] or 0)
        elif ln.startswith("#EXT-X-DISCONTINUITY") and not ln.startswith("#EXT-X-DISCONTINUITY-SEQUENCE"):
            disc = True
        elif ln.startswith("#EXT-X-KEY:"):
            a = _attrs(ln.split(":", 1)[1])
            key = None if a.get("METHOD", "NONE") == "NONE" else dict(a, URI=urljoin(base, a.get("URI", "")))
            if key and key.get("METHOD") != "AES-128":
                raise TimeshiftError("Sender ist verschlüsselt (DRM)")
        elif ln.startswith("#EXT-X-MAP:"):
            a = _attrs(ln.split(":", 1)[1])
            if "BYTERANGE" in a:
                raise TimeshiftError("Format wird nicht unterstützt")
            cur_map = urljoin(base, a.get("URI", ""))
        elif ln.startswith("#EXT-X-BYTERANGE"):
            raise TimeshiftError("Format wird nicht unterstützt")
        elif ln.startswith("#EXT-X-ENDLIST"):
            ended = True
        elif not ln.startswith("#"):
            n = seq + len(segs)
            segs.append({"seq": n, "dur": dur if dur is not None else target, "url": urljoin(base, ln),
                         "disc": disc, "key": key, "map": cur_map})
            dur, disc = None, False
    return {"target": target, "seq": seq, "segments": segs, "ended": ended}


def _ext(url, default):
    e = os.path.splitext(urlparse(url).path)[1].lower()
    return e if e in (".ts", ".aac", ".m4s", ".mp4", ".m4a", ".mp3", ".ac3", ".ec3") else default


class Track:
    """Eine Medien-Playlist (Bild oder Ton), die laufend gespiegelt wird."""

    def __init__(self, rec, name, url):
        self.rec, self.name, self.url = rec, name, url
        self.final_url = url
        self.lines = []           # lokale Playlist-Einträge
        self.next_seq = None
        self.seconds = 0.0
        self.count = 0
        self.target = 6.0
        self.maps = {}            # Original-URL -> lokaler Name
        self.keys = {}
        self.last_map = None
        self.last_key = None

    def poll(self):
        data, self.final_url = _fetch(self.url, limit=4_000_000)
        pl = parse_media(data.decode("utf-8", "replace"), self.final_url)
        self.target = pl["target"]
        return pl

    def _local_map(self, url):
        if url not in self.maps:
            name = f"{self.name}-init{len(self.maps)}{_ext(url, '.mp4')}"
            data, _ = _fetch(url)
            self.rec.write(name, data)
            self.maps[url] = name
        return self.maps[url]

    def _local_key(self, key):
        url = key["URI"]
        if url not in self.keys:
            name = f"{self.name}-key{len(self.keys)}.key"
            data, _ = _fetch(url, limit=4096)
            self.rec.write(name, data)
            self.keys[url] = name
        return self.keys[url]

    def add(self, seg):
        default = ".m4s" if seg["map"] else ".ts"
        name = f"{self.name}-{seg['seq']}{_ext(seg['url'], default)}"
        data, _ = _fetch(seg["url"])
        self.rec.write(name, data)
        if seg["disc"] and self.lines:
            self.lines.append("#EXT-X-DISCONTINUITY")
        if seg["map"] and seg["map"] != self.last_map:
            self.lines.append(f'#EXT-X-MAP:URI="{self._local_map(seg["map"])}"')
            self.last_map = seg["map"]
        k = seg["key"]
        kid = (k or {}).get("URI"), (k or {}).get("IV")
        if kid != self.last_key:
            if k:
                iv = f',IV={k["IV"]}' if k.get("IV") else ""
                self.lines.append(f'#EXT-X-KEY:METHOD=AES-128,URI="{self._local_key(k)}"{iv}')
            elif self.last_key and self.last_key[0]:
                self.lines.append("#EXT-X-KEY:METHOD=NONE")
            self.last_key = kid
        self.lines.append(f"#EXTINF:{seg['dur']:.3f},")
        self.lines.append(name)
        self.seconds += seg["dur"]
        self.count += 1
        self.next_seq = seg["seq"] + 1

    def playlist(self):
        target = max(1, int(self.target + 0.999))
        head = ["#EXTM3U", "#EXT-X-VERSION:6", f"#EXT-X-TARGETDURATION:{target}",
                "#EXT-X-PLAYLIST-TYPE:EVENT", "#EXT-X-MEDIA-SEQUENCE:0"]
        return "\n".join(head + self.lines) + "\n"


class Recorder:
    def __init__(self, url, folder, behind=0.0, log=print):
        self.url, self.folder, self.behind, self.log = url, folder, max(0.0, float(behind or 0)), log
        self.stop_ev = threading.Event()
        self.started = time.time()
        self.error = ""
        self.full = ""
        self.tracks = []
        self.ready = False
        self.touched = time.time()   # letzte Abfrage vom Fernseher
        self.thread = threading.Thread(target=self._run, daemon=True)

    # ---- Dateien
    def write(self, name, data):
        tmp = os.path.join(self.folder, "." + name + ".tmp")
        with open(tmp, "wb") as f:
            f.write(data)
        os.replace(tmp, os.path.join(self.folder, name))

    def _write_text(self, name, text):
        self.write(name, text.encode())

    # ---- Ablauf
    def start(self):
        os.makedirs(self.folder, exist_ok=True)
        self.thread.start()

    def stop(self):
        self.stop_ev.set()

    def _open(self):
        data, final = _fetch(self.url, limit=4_000_000)
        text = data.decode("utf-8", "replace")
        if "#EXTM3U" not in text[:200]:
            raise TimeshiftError("Sender liefert kein HLS")
        if "#EXT-X-STREAM-INF" in text:
            variants, audio = parse_master(text, final)
            if not variants:
                raise TimeshiftError("Keine Qualitätsstufe gefunden")
            v = pick_variant(variants)
            self.tracks.append(Track(self, "v", v["url"]))
            a_attrs = ""
            group = v["attrs"].get("AUDIO")
            if group and audio.get(group):
                r = pick_audio(audio[group])
                if r:
                    self.tracks.append(Track(self, "a", r["url"]))
                    a_attrs = ',AUDIO="aud"'
            inf = [f'BANDWIDTH={v["bw"] or 2000000}']
            for k in ("CODECS", "RESOLUTION", "FRAME-RATE"):
                if v["attrs"].get(k):
                    val = v["attrs"][k]
                    inf.append(f'{k}="{val}"' if k == "CODECS" else f"{k}={val}")
            master = ["#EXTM3U", "#EXT-X-VERSION:6"]
            if a_attrs:
                master.append('#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="aud",NAME="Ton",DEFAULT=YES,AUTOSELECT=YES,URI="a.m3u8"')
            master += ["#EXT-X-STREAM-INF:" + ",".join(inf) + a_attrs, "v.m3u8"]
            self._write_text("index.m3u8", "\n".join(master) + "\n")
        else:
            self.tracks.append(Track(self, "v", self.url))
            self._write_text("index.m3u8", "#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=2000000\nv.m3u8\n")

    def _first_seq(self, pls):
        """Gemeinsamer Startpunkt aller Spuren: so weit zurück, wie der Fernseher hinter „live“ war."""
        starts = []
        for pl in pls:
            segs = pl["segments"]
            if not segs:
                return None
            acc, idx = 0.0, len(segs) - 1
            while idx > 0 and acc + segs[idx]["dur"] <= self.behind:
                acc += segs[idx]["dur"]
                idx -= 1
            starts.append(segs[idx]["seq"])
        # alle Spuren müssen diesen Abschnitt noch haben
        lo = max(pl["segments"][0]["seq"] for pl in pls)
        return max(lo, min(starts))

    def _limits(self):
        if self.tracks and self.tracks[0].seconds >= MAX_SECONDS:
            return "Zwischenspeicher voll (2 Stunden)"
        try:
            if shutil.disk_usage(self.folder).free < MIN_FREE:
                return "Speicherkarte fast voll"
        except OSError:
            pass
        return ""

    def _run(self):
        try:
            self._open()
            errors = 0
            while not self.stop_ev.is_set():
                try:
                    pls = [t.poll() for t in self.tracks]
                    errors = 0
                except Exception as e:  # noqa: BLE001
                    errors += 1
                    if errors >= 8:
                        raise TimeshiftError(f"Sender nicht erreichbar ({e})")
                    self.stop_ev.wait(3)
                    continue
                if self.tracks[0].next_seq is None:
                    first = self._first_seq(pls)
                    if first is None:
                        self.stop_ev.wait(2)
                        continue
                    for t in self.tracks:
                        t.next_seq = first
                for t, pl in zip(self.tracks, pls):
                    for seg in pl["segments"]:
                        if self.stop_ev.is_set():
                            break
                        if seg["seq"] < t.next_seq:
                            continue
                        if seg["seq"] > t.next_seq and t.count:
                            # Lücke (zu langsam geladen): sauber weitermachen
                            t.lines.append("#EXT-X-DISCONTINUITY")
                        t.add(seg)
                    self._write_text(t.name + ".m3u8", t.playlist())
                self.ready = all(t.count for t in self.tracks)
                self.full = self._limits()
                if time.time() - self.touched > IDLE_STOP:
                    # Fernseher schaut nicht mehr zu (z. B. per Home-Taste verlassen): aufräumen
                    self.error = "beendet"
                    shutil.rmtree(self.folder, ignore_errors=True)
                    break
                if self.full or any(pl["ended"] for pl in pls):
                    break
                self.stop_ev.wait(max(1.0, min(self.tracks[0].target / 2, 4)))
        except Exception as e:  # noqa: BLE001
            self.error = str(e) if isinstance(e, TimeshiftError) else f"Aufnahme nicht möglich ({e})"
            self.log("Timeshift:", self.error)

    def status(self):
        v = self.tracks[0] if self.tracks else None
        return {"active": True, "ready": self.ready, "seconds": round(v.seconds, 1) if v else 0,
                "since": self.started, "error": self.error, "full": self.full,
                "recording": self.thread.is_alive(), "playlist": "/timeshift/index.m3u8"}


# --------------------------------------------------------------------------
# Schnittstelle für features.py
# --------------------------------------------------------------------------
FOLDER = "/var/cache/raspi-tv/timeshift"
_lock = threading.Lock()
_rec = None


def _clear():
    shutil.rmtree(FOLDER, ignore_errors=True)


def start(url, behind=0, log=print):
    global _rec
    if not isinstance(url, str) or not re.match(r"^https?://", url):
        raise TimeshiftError("Dieser Sender kann nicht angehalten werden")
    with _lock:
        if _rec:
            _rec.stop()
            _rec.thread.join(5)
        _clear()
        _rec = Recorder(url, FOLDER, behind, log)
        _rec.start()
        return _rec.status()


def stop():
    global _rec
    with _lock:
        if _rec:
            _rec.stop()
            _rec.thread.join(5)
            _rec = None
        _clear()
    return {"active": False}


def status():
    r = _rec
    if not r:
        return {"active": False}
    r.touched = time.time()
    return r.status()


def serve(handler, path, send_file):
    name = path[len("/timeshift/"):]
    if not NAME_RE.match(name) or name.startswith("."):
        return handler._json(404, {"error": "unbekannt"})
    full = os.path.join(FOLDER, name)
    if _rec:
        _rec.touched = time.time()
    if not _rec or not os.path.isfile(full):
        return handler._json(404, {"error": "nicht vorhanden"})
    ext = os.path.splitext(name)[1]
    return send_file(handler, full, CTYPES.get(ext, "application/octet-stream"))
