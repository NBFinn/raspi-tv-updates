#!/usr/bin/env python3
"""Raspi-TV OS – Systemdienst.

Liefert die TV-Oberfläche aus (http://127.0.0.1:8765/) und stellt eine kleine
API für die Einstellungen bereit: WLAN, Bluetooth, Ton, Apps, System.

Zusätzlich (Port 8766, im Heimnetz): Handy-Fernbedienung. Sie ist nur mit dem
Kopplungscode nutzbar, der auf dem Fernseher als QR-Code angezeigt wird.

Läuft als root, lauscht aber nur auf localhost. Schutz gegen fremde Webseiten,
die im selben Browser geöffnet sind:
  * Host-Header muss 127.0.0.1:8765/localhost:8765 sein (gegen DNS-Rebinding)
  * Schreibende Aufrufe brauchen JSON + Header "X-Raspi-TV: 1" + eigenen Origin
    (fremde Seiten können das nur mit CORS-Preflight, den wir nie erlauben)
"""
import hashlib
import hmac
import json
import os
import pwd
import re
import secrets
import shutil
import socket
import subprocess
import threading
import time
import urllib.request
from http.server import BaseHTTPRequestHandler, SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs

import features
from display_settings import DisplaySettings

try:
    import evdev
    from evdev import UInput, ecodes as E
except ImportError:  # nur zum Testen ohne evdev
    evdev = None

HOST, PORT = "127.0.0.1", 8765
BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(BASE, "launcher")
STATE_DIR = "/var/lib/raspi-tv"
CONFIG_FILE = os.path.join(STATE_DIR, "config.json")
UPDATE_LOG = "/var/log/raspi-tv-update.log"
TV_USER = "tv"
BROWSER_PROFILE = f"/home/{TV_USER}/.config/raspi-tv-browser"
REMOTE_PORT = 8766
TOKEN_FILE = os.path.join(STATE_DIR, "remote-token")
CHANNEL_OVERRIDES = os.path.join(STATE_DIR, "channel-urls.json")
TV_POWER_FILE = "/run/raspi-tv/tv-power"
CHANNEL_SOURCES = [
    "https://raw.githubusercontent.com/jnk22/kodinerds-iptv/master/iptv/clean/clean_tv_main.m3u",
    "https://raw.githubusercontent.com/jnk22/kodinerds-iptv/master/iptv/clean/clean_tv_regional.m3u",
    "https://raw.githubusercontent.com/jnk22/kodinerds-iptv/master/iptv/clean/clean_tv_extra.m3u",
    "https://raw.githubusercontent.com/jnk22/kodinerds-iptv/master/iptv/clean/clean_tv_shop.m3u",
]

ALLOWED_HOSTS = {f"127.0.0.1:{PORT}", f"localhost:{PORT}"}
ALLOWED_ORIGINS = {f"http://{h}" for h in ALLOWED_HOSTS}
MAC_RE = re.compile(r"^[0-9A-F]{2}(:[0-9A-F]{2}){5}$")


# --------------------------------------------------------------------------
# Hilfsfunktionen
# --------------------------------------------------------------------------
class ApiError(Exception):
    def __init__(self, message, code=400):
        super().__init__(message)
        self.code = code


def run(cmd, timeout=30):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return 124, "", "Zeitüberschreitung"
    except FileNotFoundError:
        return 127, "", f"Programm fehlt: {cmd[0]}"


def as_tv(cmd, timeout=15):
    """Befehl im Kontext des TV-Benutzers ausführen (für dessen PipeWire-Ton)."""
    try:
        uid = pwd.getpwnam(TV_USER).pw_uid
    except KeyError:
        return 1, "", "TV-Benutzer fehlt"
    return run(["runuser", "-u", TV_USER, "--", "env", f"XDG_RUNTIME_DIR=/run/user/{uid}"] + cmd,
               timeout=timeout)


def nm_split(line):
    """Terse-Ausgabe von nmcli zerlegen (':' ist mit '\\' maskiert)."""
    parts = re.split(r"(?<!\\):", line)
    return [p.replace("\\:", ":").replace("\\\\", "\\") for p in parts]


def read_file(path, default=""):
    try:
        with open(path) as f:
            return f.read().strip()
    except OSError:
        return default


def local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("192.0.2.1", 80))  # nur Routenermittlung, sendet nichts
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return None


# --------------------------------------------------------------------------
# Konfiguration (ausgeblendete Apps)
# --------------------------------------------------------------------------
def load_config():
    try:
        with open(CONFIG_FILE) as f:
            cfg = json.load(f)
    except (OSError, ValueError):
        cfg = {}
    cfg.setdefault("hidden", [])
    cfg.setdefault("startup", "tv")
    cfg.setdefault("ui_scale", 100)
    cfg.setdefault("setup_done", False)
    cfg.setdefault("auto_off_hours", 4)
    cfg.setdefault("screensaver_min", 10)
    return cfg


def save_config(cfg):
    os.makedirs(STATE_DIR, exist_ok=True)
    tmp = CONFIG_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(cfg, f, indent=2)
    os.replace(tmp, CONFIG_FILE)


# --------------------------------------------------------------------------
# Netzwerk / WLAN
# --------------------------------------------------------------------------
def network_status():
    wifi = {"device": None, "state": "unavailable", "ssid": None, "signal": None}
    ethernet = False
    _, out, _ = run(["nmcli", "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device"], 10)
    for line in out.splitlines():
        f = nm_split(line)
        if len(f) < 4:
            continue
        dev, typ, state, _conn = f[:4]
        if typ == "wifi" and wifi["device"] is None:
            wifi["device"], wifi["state"] = dev, state
        elif typ == "ethernet" and state == "connected":
            ethernet = True
    if wifi["state"] == "connected":
        _, out, _ = run(["nmcli", "-t", "-f", "ACTIVE,SSID,SIGNAL", "device", "wifi"], 10)
        for line in out.splitlines():
            f = nm_split(line)
            if len(f) >= 3 and f[0] == "yes":
                wifi["ssid"] = f[1]
                wifi["signal"] = int(f[2]) if f[2].isdigit() else None
                break
    ip = local_ip()
    return {"online": bool(ip), "ip": ip, "ethernet": ethernet, "wifi": wifi}


def wifi_scan():
    run(["rfkill", "unblock", "wifi"], 5)
    _, out, err = run(["nmcli", "-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY",
                       "device", "wifi", "list", "--rescan", "yes"], 30)
    nets = {}
    for line in out.splitlines():
        f = nm_split(line)
        if len(f) < 4 or not f[1]:
            continue
        in_use, ssid, signal, security = f[0] == "*", f[1], f[2], f[3]
        sig = int(signal) if signal.isdigit() else 0
        cur = nets.get(ssid)
        if cur is None or sig > cur["signal"] or in_use:
            nets[ssid] = {
                "ssid": ssid,
                "signal": sig,
                "secure": security not in ("", "--"),
                "connected": in_use or (cur["connected"] if cur else False),
            }
    known = set(saved_wifi_names())
    result = sorted(nets.values(), key=lambda n: (not n["connected"], -n["signal"]))
    for n in result:
        n["saved"] = n["ssid"] in known
    return result


def saved_wifi_names():
    _, out, _ = run(["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show"], 10)
    names = []
    for line in out.splitlines():
        f = nm_split(line)
        if len(f) >= 2 and f[1] in ("802-11-wireless", "wifi"):
            names.append(f[0])
    return names


def wifi_connect(ssid, password):
    if not ssid or len(ssid) > 64:
        raise ApiError("Ungültiger WLAN-Name")
    run(["rfkill", "unblock", "wifi"], 5)
    if not password and ssid in saved_wifi_names():
        # bekanntes Netz: gespeichertes Profil benutzen
        code, out, err = run(["nmcli", "connection", "up", "id", ssid], 60)
        if code == 0:
            return {"ok": True}
        raise ApiError("Verbindung fehlgeschlagen – ist das Netzwerk in Reichweite?")
    cmd = ["nmcli", "device", "wifi", "connect", ssid]
    if password:
        cmd += ["password", password]
    code, out, err = run(cmd, 60)
    if code == 0:
        return {"ok": True}
    # kaputtes Profil nicht liegen lassen
    run(["nmcli", "connection", "delete", "id", ssid], 10)
    msg = (err or out).strip()
    if "Secrets were required" in msg or "802-1x" in msg or "psk" in msg.lower():
        raise ApiError("Verbindung fehlgeschlagen – stimmt das Passwort?")
    if "No network with SSID" in msg:
        raise ApiError("Netzwerk nicht gefunden – bitte neu suchen.")
    raise ApiError("Verbindung fehlgeschlagen: " + msg.replace("Error: ", "")[:160])


def wifi_forget(ssid):
    removed = 0
    for name in saved_wifi_names():
        if name == ssid:
            run(["nmcli", "connection", "delete", "id", name], 10)
            removed += 1
    return {"ok": True, "removed": removed}


# --------------------------------------------------------------------------
# Bluetooth
# --------------------------------------------------------------------------
_bt_scan = {"running": False, "until": 0}
_bt_lock = threading.Lock()


def bt_ready():
    run(["rfkill", "unblock", "bluetooth"], 5)
    run(["bluetoothctl", "power", "on"], 10)


def bt_info(mac):
    _, out, _ = run(["bluetoothctl", "info", mac], 10)
    info = {"mac": mac, "name": None, "paired": False, "connected": False, "icon": ""}
    for line in out.splitlines():
        line = line.strip()
        if line.startswith("Name:"):
            info["name"] = line[5:].strip()
        elif line.startswith("Alias:") and not info["name"]:
            info["name"] = line[6:].strip()
        elif line.startswith("Paired:"):
            info["paired"] = line.endswith("yes")
        elif line.startswith("Connected:"):
            info["connected"] = line.endswith("yes")
        elif line.startswith("Icon:"):
            info["icon"] = line[5:].strip()
    return info


def bt_devices():
    _, out, _ = run(["bluetoothctl", "devices"], 10)
    devices = []
    for line in out.splitlines()[:40]:
        m = re.match(r"Device ([0-9A-F:]{17}) (.*)", line.strip())
        if not m:
            continue
        mac, name = m.group(1), m.group(2)
        info = bt_info(mac)
        info["name"] = info["name"] or name
        # Geräte ohne echten Namen (nur Adresse) ausblenden
        if re.fullmatch(r"[0-9A-F]{2}([-:][0-9A-F]{2}){5}", info["name"] or ""):
            if not info["paired"]:
                continue
        devices.append(info)
    devices.sort(key=lambda d: (not d["connected"], not d["paired"], (d["name"] or "").lower()))
    return {"scanning": _bt_scan["running"], "devices": devices}


def bt_start_scan(seconds=15):
    with _bt_lock:
        if _bt_scan["running"]:
            return
        _bt_scan["running"] = True
        _bt_scan["until"] = time.time() + seconds

    def worker():
        try:
            bt_ready()
            run(["bluetoothctl", "--timeout", str(seconds), "scan", "on"], seconds + 10)
        finally:
            _bt_scan["running"] = False

    threading.Thread(target=worker, daemon=True).start()


def bt_action(action, mac):
    if not MAC_RE.match(mac or ""):
        raise ApiError("Ungültiges Gerät")
    bt_ready()
    if action == "pair":
        run(["bluetoothctl", "--timeout", "25", "pair", mac], 35)
        if not bt_info(mac)["paired"]:
            raise ApiError("Koppeln fehlgeschlagen – ist das Gerät im Kopplungsmodus?")
        run(["bluetoothctl", "trust", mac], 10)
        run(["bluetoothctl", "--timeout", "15", "connect", mac], 25)
    elif action == "connect":
        run(["bluetoothctl", "--timeout", "15", "connect", mac], 25)
        if not bt_info(mac)["connected"]:
            raise ApiError("Verbinden fehlgeschlagen – ist das Gerät eingeschaltet?")
    elif action == "disconnect":
        run(["bluetoothctl", "disconnect", mac], 15)
    elif action == "remove":
        run(["bluetoothctl", "remove", mac], 15)
    else:
        raise ApiError("Unbekannte Aktion", 404)
    return {"ok": True, "device": bt_info(mac)}


# --------------------------------------------------------------------------
# Ton (PipeWire des TV-Benutzers)
# --------------------------------------------------------------------------
def audio_status():
    code, out, err = as_tv(["pw-dump"], 15)
    if code != 0:
        return {"available": False, "outputs": [], "volume": None, "muted": False}
    try:
        objs = json.loads(out)
    except ValueError:
        objs = []
    default_name = None
    for o in objs:
        if o.get("type") == "PipeWire:Interface:Metadata" and \
                o.get("props", {}).get("metadata.name") == "default":
            for entry in o.get("metadata", []):
                if entry.get("key") == "default.audio.sink":
                    val = entry.get("value")
                    if isinstance(val, str):
                        try:
                            val = json.loads(val)
                        except ValueError:
                            val = {"name": val}
                    default_name = (val or {}).get("name")
    outputs = []
    for o in objs:
        props = (o.get("info") or {}).get("props") or {}
        if o.get("type") == "PipeWire:Interface:Node" and props.get("media.class") == "Audio/Sink":
            name = props.get("node.name", "")
            outputs.append({
                "id": o.get("id"),
                "name": props.get("node.description") or props.get("node.nick") or name,
                "bluetooth": name.startswith("bluez"),
                "default": name == default_name,
            })
    volume, muted = None, False
    code, out, _ = as_tv(["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"], 10)
    m = re.search(r"Volume:\s*([0-9.]+)", out)
    if m:
        volume = round(float(m.group(1)) * 100)
        muted = "MUTED" in out
    return {"available": True, "outputs": outputs, "volume": volume, "muted": muted}


def audio_set(data):
    if "output" in data:
        try:
            out_id = int(data["output"])
        except (TypeError, ValueError):
            raise ApiError("Ungültiger Ausgang")
        as_tv(["wpctl", "set-default", str(out_id)])
    if "volume" in data:
        try:
            vol = max(0, min(100, int(data["volume"])))
        except (TypeError, ValueError):
            raise ApiError("Ungültige Lautstärke")
        as_tv(["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "0"])
        as_tv(["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", f"{vol / 100:.2f}"])
    return audio_status()


# --------------------------------------------------------------------------
# System
# --------------------------------------------------------------------------
def system_info():
    mem = {}
    for line in read_file("/proc/meminfo").splitlines():
        k, _, v = line.partition(":")
        mem[k] = int(v.split()[0]) if v.split() else 0
    disk = shutil.disk_usage("/")
    temp = read_file("/sys/class/thermal/thermal_zone0/temp")
    uptime = float(read_file("/proc/uptime", "0").split()[0])
    release = {}
    for line in read_file("/etc/raspi-tv-release").splitlines():
        k, _, v = line.partition("=")
        release[k] = v.strip('"')
    return {
        "version": release.get("VERSION", "dev"),
        "build": release.get("BUILD_DATE", ""),
        "model": read_file("/proc/device-tree/model").replace("\x00", "") or "unbekannt",
        "hostname": socket.gethostname(),
        "ip": local_ip(),
        "temp": round(int(temp) / 1000, 1) if temp.isdigit() else None,
        "uptime": int(uptime),
        "mem_total": mem.get("MemTotal", 0) * 1024,
        "mem_free": mem.get("MemAvailable", 0) * 1024,
        "disk_total": disk.total,
        "disk_free": disk.free,
    }


_update = {"running": False, "rc": None, "started": None, "finished": None}


def update_start():
    if _update["running"]:
        return update_status()
    _update.update(running=True, rc=None, started=time.time(), finished=None)

    def worker():
        env = dict(os.environ, DEBIAN_FRONTEND="noninteractive")
        rc = 1
        try:
            with open(UPDATE_LOG, "w") as log:
                for cmd in (["apt-get", "update"],
                            ["apt-get", "-y", "-o", "Dpkg::Options::=--force-confold",
                             "full-upgrade"],
                            ["apt-get", "-y", "autoremove"]):
                    log.write(f"\n$ {' '.join(cmd)}\n")
                    log.flush()
                    rc = subprocess.call(cmd, stdout=log, stderr=subprocess.STDOUT, env=env)
                    if rc != 0:
                        break
        finally:
            _update.update(running=False, rc=rc, finished=time.time())

    threading.Thread(target=worker, daemon=True).start()
    return update_status()


def update_status():
    tail = read_file(UPDATE_LOG).splitlines()[-6:]
    return dict(_update, log=tail, reboot_required=os.path.exists("/var/run/reboot-required"))


def reset_browser():
    run(["pkill", "-u", TV_USER, "-f", "raspi-tv-browser"], 10)
    time.sleep(2)
    shutil.rmtree(BROWSER_PROFILE, ignore_errors=True)
    return {"ok": True}


def power(action):
    cmd = {"shutdown": ["systemctl", "poweroff"], "reboot": ["systemctl", "reboot"]}[action]
    threading.Timer(1.0, lambda: subprocess.Popen(cmd)).start()
    return {"ok": True}


# --------------------------------------------------------------------------
# Fernseher (HDMI-CEC)
# --------------------------------------------------------------------------
def tv_power():
    """'on', 'standby' oder 'unknown' – geschrieben vom CEC-Dienst."""
    return read_file(TV_POWER_FILE, "unknown") or "unknown"


def tv_standby():
    import glob
    for dev in sorted(glob.glob("/dev/cec*")):
        run(["cec-ctl", "-d", dev, "--to", "0", "--standby"], 10)
    return {"ok": True}


# --------------------------------------------------------------------------
# Senderliste (aktualisiert Stream-Adressen automatisch)
# --------------------------------------------------------------------------
def channels_merged():
    try:
        with open(os.path.join(ROOT, "channels.json")) as f:
            channels = json.load(f)
    except (OSError, ValueError):
        return []
    try:
        with open(CHANNEL_OVERRIDES) as f:
            overrides = json.load(f)
    except (OSError, ValueError):
        overrides = {}
    region = load_config().get("region")
    for ch in channels:
        # Regionalprogramm in der Version fürs eigene Bundesland (z. B. NDR Hamburg statt Niedersachsen)
        var = (ch.pop("variants", None) or {}).get(region)
        if var:
            ch["source"], ch["url"] = var["source"], var["url"]
        url = overrides.get(ch.get("source") or ch["name"])
        if url:
            ch["url"] = url
        ch.pop("source", None)
    return channels


def parse_m3u(text):
    entries, name = {}, None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("#EXTINF"):
            m = re.search(r'tvg-name="([^"]+)"', line)
            name = [line.rsplit(",", 1)[-1].strip()] + ([m.group(1)] if m else [])
        elif line and not line.startswith("#") and name:
            if re.match(r"^https?://\S+\.m3u8(\?\S*)?$", line):
                for n in name:
                    entries.setdefault(n.casefold(), line)
            name = None
    return entries


def update_channels_once():
    try:
        with open(os.path.join(ROOT, "channels.json")) as f:
            data = json.load(f)
        wanted = {ch.get("source") or ch["name"] for ch in data}
        wanted |= {v["source"] for ch in data for v in (ch.get("variants") or {}).values()}
    except (OSError, ValueError):
        return
    found = {}
    for src in CHANNEL_SOURCES:
        try:
            req = urllib.request.Request(src, headers={"User-Agent": "Raspi-TV"})
            with urllib.request.urlopen(req, timeout=20) as r:
                found.update(parse_m3u(r.read(2_000_000).decode("utf-8", "replace")))
        except Exception:  # noqa: BLE001 – offline o. Ä.: alte Liste behalten
            continue
    overrides = {k: found[k.casefold()] for k in wanted if k.casefold() in found}
    if overrides:
        os.makedirs(STATE_DIR, exist_ok=True)
        tmp = CHANNEL_OVERRIDES + ".tmp"
        with open(tmp, "w") as f:
            json.dump(overrides, f, indent=1)
        os.replace(tmp, CHANNEL_OVERRIDES)


def channel_updater():
    time.sleep(60)  # erst nach dem Start, wenn das Netz da ist
    while True:
        update_channels_once()
        time.sleep(12 * 3600)


# --------------------------------------------------------------------------
# Handy-Fernbedienung
# --------------------------------------------------------------------------
def remote_token():
    tok = read_file(TOKEN_FILE)
    if len(tok) < 16:
        tok = remote_reset()["token"]
    return tok


def remote_reset():
    os.makedirs(STATE_DIR, exist_ok=True)
    tok = secrets.token_urlsafe(18)
    fd = os.open(TOKEN_FILE + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(tok)
    os.replace(TOKEN_FILE + ".tmp", TOKEN_FILE)
    ip = local_ip()
    return {"ok": True, "token": tok, "url": remote_url(tok), "pin": remote_pin()["pin"],
            "address": f"http://{ip}:{REMOTE_PORT}" if ip else None}


def remote_url(tok=None):
    ip = local_ip()
    if not ip:
        return None
    return f"http://{ip}:{REMOTE_PORT}/#{tok or remote_token()}"


def remote_info():
    ip = local_ip()
    return {"url": remote_url(), "hostname": socket.gethostname(), "pin": remote_pin()["pin"],
            "address": f"http://{ip}:{REMOTE_PORT}" if ip else None}


# Kurzer Zahlencode zum Koppeln ohne QR-Code (z. B. Adresse in Safari eintippen)
_PIN = {"pin": None, "until": 0, "fails": 0, "locked_until": 0}
_PIN_LOCK = threading.Lock()


def remote_pin():
    with _PIN_LOCK:
        if not _PIN["pin"] or time.time() > _PIN["until"]:
            _PIN.update(pin=f"{secrets.randbelow(1000000):06d}", until=time.time() + 15 * 60, fails=0)
        return dict(_PIN)


def remote_pair(data):
    """Code vom Fernseher -> Kopplungsschlüssel. Nach 8 Fehlversuchen 10 Minuten gesperrt."""
    pin = re.sub(r"\D", "", str(data.get("pin") or ""))
    with _PIN_LOCK:
        now = time.time()
        if now < _PIN["locked_until"]:
            raise ApiError("Zu viele Versuche – bitte in ein paar Minuten nochmal.", 429)
        ok = _PIN["pin"] and now <= _PIN["until"] and hmac.compare_digest(pin, _PIN["pin"])
        if ok:
            # Consume while still holding the lock; concurrent requests cannot reuse the PIN.
            _PIN.update(pin=None, fails=0)
        if not ok:
            _PIN["fails"] += 1
            if _PIN["fails"] >= 8:
                _PIN.update(locked_until=now + 600, fails=0, pin=None)
    if not ok:
        time.sleep(1)
        raise ApiError("Code stimmt nicht. Er steht am Fernseher unter Einstellungen → Fernbedienung → Handy.", 403)
    return {"token": remote_token()}


class VirtualInput:
    """Virtuelle Tastatur + Maus (wie die TV-Fernbedienung)."""
    # F8 erreicht die Erweiterung; KEY_HOMEPAGE wird von Chromium selbst verarbeitet.
    KEYS = {
        "up": "KEY_UP", "down": "KEY_DOWN", "left": "KEY_LEFT", "right": "KEY_RIGHT",
        "ok": "KEY_ENTER", "back": "KEY_BACK", "home": "KEY_F8", "esc": "KEY_ESC",
        "chup": "KEY_PAGEUP", "chdown": "KEY_PAGEDOWN", "playpause": "KEY_SPACE",
        "backspace": "KEY_BACKSPACE", "enter": "KEY_ENTER", "tab": "KEY_TAB",
        "reload": "KEY_F5", "fullscreen": "KEY_F", "guide": "KEY_G", "info": "KEY_I", "record": "KEY_R",
        **{str(i): f"KEY_{i}" for i in range(10)},
    }

    def __init__(self):
        self.lock = threading.Lock()
        self.dev = None

    def _ui(self):
        if self.dev is None:
            if evdev is None:
                raise ApiError("Eingabe nicht verfügbar", 503)
            keys = [getattr(E, k) for k in self.KEYS.values()]
            self.dev = UInput({E.EV_KEY: keys + [E.BTN_LEFT, E.BTN_RIGHT],
                               E.EV_REL: [E.REL_X, E.REL_Y, E.REL_WHEEL]},
                              name="raspi-tv-handy")
            time.sleep(0.3)  # X erkennt das neue Gerät
        return self.dev

    def key(self, name):
        code = self.KEYS.get(name)
        if not code:
            raise ApiError("Unbekannte Taste")
        with self.lock:
            ui = self._ui()
            c = getattr(E, code)
            ui.write(E.EV_KEY, c, 1); ui.syn()
            ui.write(E.EV_KEY, c, 0); ui.syn()

    def move(self, dx, dy):
        dx = max(-400, min(400, int(dx)))
        dy = max(-400, min(400, int(dy)))
        with self.lock:
            ui = self._ui()
            ui.write(E.EV_REL, E.REL_X, dx)
            ui.write(E.EV_REL, E.REL_Y, dy)
            ui.syn()

    def click(self, button):
        b = E.BTN_RIGHT if button == "right" else E.BTN_LEFT
        with self.lock:
            ui = self._ui()
            ui.write(E.EV_KEY, b, 1); ui.syn()
            ui.write(E.EV_KEY, b, 0); ui.syn()

    def scroll(self, dy):
        with self.lock:
            ui = self._ui()
            ui.write(E.EV_REL, E.REL_WHEEL, max(-10, min(10, int(dy))))
            ui.syn()


VINPUT = VirtualInput()


def type_text(text):
    if not isinstance(text, str) or not text or len(text) > 500:
        raise ApiError("Ungültiger Text")
    text = "".join(ch for ch in text if ch.isprintable())
    code, _, err = as_tv(["env", "DISPLAY=:0", f"XAUTHORITY=/home/{TV_USER}/.Xauthority",
                          "xdotool", "type", "--delay", "25", "--", text], 60)
    if code != 0:
        raise ApiError("Texteingabe fehlgeschlagen: " + err.strip()[:120], 500)
    return {"ok": True}


REMOTE_ROUTES = {
    "/r/key": lambda d: (VINPUT.key(str(d.get("key"))), {"ok": True})[1],
    "/r/move": lambda d: (VINPUT.move(d.get("dx", 0), d.get("dy", 0)), {"ok": True})[1],
    "/r/click": lambda d: (VINPUT.click(d.get("button", "left")), {"ok": True})[1],
    "/r/scroll": lambda d: (VINPUT.scroll(d.get("dy", 0)), {"ok": True})[1],
    "/r/text": lambda d: type_text(d.get("text")),
    "/r/ping": lambda d: {"ok": True, "name": socket.gethostname(), "tv": tv_power()},
}


class RemoteHandler(BaseHTTPRequestHandler):
    """Heimnetz-Server für die Handy-Fernbedienung.

    Eine einzige, kleine Seite (komprimiert, mit ETag), damit sie auch über schwaches
    WLAN sofort da ist. Jede Anfrage bekommt eine eigene Verbindung (HTTP/1.0) – das ist
    mit Safari am zuverlässigsten.
    """
    timeout = 30          # hängende Verbindungen nicht ewig offen halten
    _cache = {}           # Dateiname -> (mtime, roh, gzip, etag)

    def log_message(self, *_):
        pass

    def _send(self, code, body, ctype, extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "SAMEORIGIN")
        self.send_header("Content-Security-Policy", "frame-ancestors 'self'")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, code, data):
        self._send(code, json.dumps(data).encode(), "application/json; charset=utf-8")

    def _file(self, name):
        import gzip
        full = os.path.join(ROOT, name)
        mtime = os.path.getmtime(full)
        hit = self._cache.get(name)
        if not hit or hit[0] != mtime:
            with open(full, "rb") as f:
                raw = f.read()
            hit = (mtime, raw, gzip.compress(raw, 9), '"%s"' % hashlib.sha1(raw).hexdigest()[:16])
            self._cache[name] = hit
        return hit

    def _static(self, name, ctype):
        try:
            _, raw, gz, etag = self._file(name)
        except OSError:
            return self._json(404, {"error": "fehlt"})
        if self.headers.get("If-None-Match") == etag:
            self.send_response(304)
            self.send_header("ETag", etag)
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            return None
        extra = {"ETag": etag, "Vary": "Accept-Encoding"}
        body = raw
        if "gzip" in (self.headers.get("Accept-Encoding") or "") and ctype.startswith(("text/", "application/json", "application/manifest")):
            body, extra["Content-Encoding"] = gz, "gzip"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "SAMEORIGIN")
        self.send_header("Content-Security-Policy", "frame-ancestors 'self'")
        for k, v in extra.items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)
        return None

    def _manifest(self, query):
        try:
            with open(os.path.join(ROOT, "remote-manifest.json")) as f:
                m = json.load(f)
        except (OSError, ValueError):
            m = {"name": "Raspi-TV", "display": "standalone"}
        key = (query.get("k") or [""])[0]
        # Mit gültigem Schlüssel startet das Symbol auf dem Startbildschirm schon gekoppelt
        if key and hmac.compare_digest(key.encode(), remote_token().encode()):
            m["start_url"] = "/#" + key
        m["icons"] = [{"src": "/icon.png", "sizes": "512x512", "type": "image/png"}]
        self._send(200, json.dumps(m, ensure_ascii=False).encode(), "application/manifest+json")

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        path, _, qs = self.path.partition("?")
        if path in ("/", "/index.html"):
            return self._static("remote.html", "text/html; charset=utf-8")
        if path == "/manifest.json":
            return self._manifest(parse_qs(qs))
        if path in ("/icon.png", "/apple-touch-icon.png", "/apple-touch-icon-precomposed.png", "/favicon.ico"):
            return self._static("remote-icon.png", "image/png")
        if path in ("/app.apk", "/raspi-tv-remote.apk"):     # App für ältere Android-Handys (Bluetooth)
            return self._static("raspi-tv-remote.apk", "application/vnd.android.package-archive")
        if path == "/i18n.js":          # ältere, noch offene Fernbedienungs-Seiten
            return self._static("i18n.js", "text/javascript; charset=utf-8")
        return self._json(404, {"error": "unbekannt"})

    def _body(self):
        if not (self.headers.get("Content-Type") or "").startswith("application/json"):
            raise ApiError("Ungültige Anfrage")
        length = int(self.headers.get("Content-Length") or 0)
        if not 0 <= length <= (32768 if getattr(self, "path", "") == "/r/mirror" else 8192):
            raise ApiError("Anfrage ist zu groß oder hat eine ungültige Länge.", 413)
        data = json.loads(self.rfile.read(length) or b"{}")
        if not isinstance(data, dict):
            raise ApiError("Ungültige Anfrage")
        return data

    def do_POST(self):
        path = self.path.split("?")[0]
        try:
            if path == "/r/pair":
                return self._json(200, remote_pair(self._body()))
            fn = REMOTE_ROUTES.get(path)
            if not fn:
                return self._json(404, {"error": "unbekannt"})
            token = self.headers.get("X-Token", "")
            if not hmac.compare_digest(token.encode(), remote_token().encode()):
                time.sleep(0.5)  # Raten bremsen
                return self._json(401, {"error": "Nicht gekoppelt – QR-Code auf dem Fernseher scannen."})
            data = self._body()
            features.touch_activity()
            return self._json(200, fn(data))
        except ApiError as e:
            return self._json(e.code, {"error": str(e)})
        except (ValueError, TypeError):
            return self._json(400, {"error": "Ungültige Anfrage"})
        except Exception as e:  # noqa: BLE001
            return self._json(500, {"error": f"Interner Fehler: {e}"})

    def do_OPTIONS(self):
        self.send_response(403)
        self.send_header("Content-Length", "0")
        self.end_headers()


# --------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------
GET_ROUTES = {
    "/api/status": lambda: {"network": network_status(), "tv": tv_power(), "time": time.time(),
                            "autooff": features.autooff_left()},
    "/api/channels": channels_merged,
    "/api/remote": remote_info,
    "/api/wifi/scan": lambda: {"networks": wifi_scan()},
    "/api/bluetooth": bt_devices,
    "/api/audio": audio_status,
    "/api/system": system_info,
    "/api/update": update_status,
    "/api/config": load_config,
}


REGIONS = {"BW", "BY", "BE", "BB", "HB", "HH", "HE", "MV", "NI", "NW", "RP", "SL", "SN", "ST", "SH", "TH"}


def post_config(data):
    """Einstellungen ändern. Nur übergebene Felder werden geändert."""
    cfg = load_config()
    if "hidden" in data:
        hidden = data["hidden"]
        if not isinstance(hidden, list) or not all(isinstance(h, str) and len(h) < 40 for h in hidden):
            raise ApiError("Ungültige Einstellungen")
        cfg["hidden"] = hidden[:50]
    checks = {
        "startup": lambda v: v in ("tv", "home"),
        "setup_done": lambda v: isinstance(v, bool),
        "adblock": lambda v: isinstance(v, bool),
        "lang": lambda v: v in ("de", "en"),
        "intro": lambda v: isinstance(v, bool),
        "theme": lambda v: v in ("midnight", "oled", "aurora", "sunset", "forest", "cinema", "light", "auto"),
        "accent": lambda v: v in ("theme", "blue", "violet", "teal", "green", "gold", "orange", "red", "pink"),
        "background": lambda v: v in ("glow", "animated", "plain", "wallpaper"),
        "wallpaper": lambda v: isinstance(v, str) and re.fullmatch(r"[a-z0-9-]{0,48}", v) is not None,
        "wallpaper_rotate": lambda v: isinstance(v, bool),
        "motion": lambda v: v in ("full", "reduced", "off"),
        "corners": lambda v: v in ("round", "soft", "square"),
        "home_layout": lambda v: v in ("classic", "compact", "cinema", "sidebar", "minimal"),
        "home_sections": lambda v: isinstance(v, dict) and len(v) <= 10 and all(
            k in ("continue", "now", "apps", "weather", "search", "news") and isinstance(x, bool) for k, x in v.items()),
        "app_look": lambda v: isinstance(v, dict) and len(v) <= 10 and all(k in features.APP_LOOK_CHECKS and features.APP_LOOK_CHECKS[k](x) for k, x in v.items()),
        "saver_style": lambda v: v in ("classic", "analog", "photos", "dark", "aurora", "stars", "lava", "spectrum", "video") or (
            isinstance(v, str) and re.fullmatch(r"video-[a-z0-9-]{1,40}", v) is not None),
        "saver_news": lambda v: isinstance(v, bool),
        "region": lambda v: v in REGIONS,
        "auto_off_hours": lambda v: v in (0, 2, 4, 6, 8),
        "standby_signal_off": lambda v: isinstance(v, bool),
        "screensaver_min": lambda v: v in (0, 5, 10, 20, 30),
        "round_brightness": lambda v: type(v) is int and v in range(10, 101, 10),
        "round_colors": lambda v: v in ("design", "classic"),
        "round_intro": lambda v: isinstance(v, bool),
        "round_motion": lambda v: v in ("full", "off"),
        "system_updates": lambda v: isinstance(v, bool),
        "round_speed": lambda v: type(v) is int and v in (4, 8, 16, 32),
        "round_teensy_mhz": lambda v: type(v) is int and v in (15, 24, 30, 40, 60),
    }
    for key, ok in checks.items():
        if key in data:
            if not ok(data[key]):
                raise ApiError("Ungültige Einstellungen")
            cfg[key] = data[key]
    save_config(cfg)
    return cfg


DISPLAY_SETTINGS = DisplaySettings(ApiError)

POST_ROUTES = {
    "/api/round-displays": DISPLAY_SETTINGS.request,
    "/api/wifi/connect": lambda d: wifi_connect(d.get("ssid", ""), d.get("password", "")),
    "/api/wifi/forget": lambda d: wifi_forget(d.get("ssid", "")),
    "/api/bluetooth/scan": lambda d: (bt_start_scan(), bt_devices())[1],
    "/api/bluetooth/pair": lambda d: bt_action("pair", d.get("mac")),
    "/api/bluetooth/connect": lambda d: bt_action("connect", d.get("mac")),
    "/api/bluetooth/disconnect": lambda d: bt_action("disconnect", d.get("mac")),
    "/api/bluetooth/remove": lambda d: bt_action("remove", d.get("mac")),
    "/api/audio": audio_set,
    "/api/config": post_config,
    "/api/update": lambda d: update_start(),
    "/api/reset-browser": lambda d: reset_browser(),
    "/api/remote/reset": lambda d: remote_reset(),
    "/api/tv/standby": lambda d: tv_standby(),
    "/api/shutdown": lambda d: power("shutdown"),
    "/api/reboot": lambda d: power("reboot"),
}


GET_ROUTES.update(features.GET_ROUTES)
POST_ROUTES.update(features.POST_ROUTES)


# ---------------------------------------------------------------- schnelle statische Dateien (6.0)
# Vorher: jede Datei mit "no-store" → bei jeder Rückkehr zur Startseite alles neu laden und neu
# übersetzen. Jetzt: Dateien mit Versionskennung (?v=…) dürfen dauerhaft im Browser bleiben
# (inkl. übersetztem JavaScript), HTML wird nur kurz nachgefragt (304), Text wird komprimiert,
# Videos unterstützen Teilabrufe (Spulen/Schleifen).
import gzip as _gzip
import mimetypes as _mt

_STATIC_TYPES = {".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
                 ".html": "text/html; charset=utf-8", ".json": "application/json; charset=utf-8",
                 ".svg": "image/svg+xml", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
                 ".webp": "image/webp", ".avif": "image/avif", ".woff2": "font/woff2", ".mp4": "video/mp4",
                 ".webm": "video/webm", ".ico": "image/x-icon", ".txt": "text/plain; charset=utf-8",
                 ".apk": "application/vnd.android.package-archive", ".wasm": "application/wasm"}
_GZIP_EXT = (".js", ".css", ".html", ".json", ".svg", ".txt")
_gz_cache = {}
_ASSET_RE = re.compile(r'((?:src|href)=")((?!https?:|data:|//|#)[^"?#]+\.(?:js|css|svg|png|webp|woff2))(")')


def _fingerprint(path):
    try:
        st = os.stat(path)
    except OSError:
        return None
    return f"{st.st_mtime_ns:x}{st.st_size:x}"[-12:]


def _versioned_html(path, data):
    """Lokale Skripte/Stile in HTML mit ?v=<Fingerabdruck> versehen – ändert sich eine Datei
    (Update), ändert sich die Adresse, und der Browser lädt genau diese Datei neu."""
    base = os.path.dirname(path)

    def repl(m):
        fp = _fingerprint(os.path.join(base, m.group(2).lstrip("/")) if not m.group(2).startswith("/")
                          else os.path.join(ROOT, m.group(2).lstrip("/")))
        return m.group(1) + m.group(2) + (f"?v={fp}" if fp else "") + m.group(3)
    return _ASSET_RE.sub(repl, data.decode("utf-8")).encode("utf-8")


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=ROOT, **kw)

    def log_message(self, *_):
        pass

    def end_headers(self):
        if not getattr(self, "_cache_hdr", False):
            self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        super().end_headers()

    def _static(self, path, query):
        """Datei aus dem Launcher-Ordner ausliefern (None = nicht zuständig)."""
        if path == "/":
            path = "/index.html"
        ext = os.path.splitext(path)[1].lower()
        if ext not in _STATIC_TYPES or ".." in path:
            return None
        full = os.path.realpath(os.path.join(ROOT, path.lstrip("/")))
        if not full.startswith(os.path.realpath(ROOT) + os.sep) or not os.path.isfile(full):
            return None
        st = os.stat(full)
        etag = f'W/"{st.st_mtime_ns:x}-{st.st_size:x}"'
        self._cache_hdr = True
        cache = "public, max-age=31536000, immutable" if "v" in query and ext != ".html" else "no-cache"
        if self.headers.get("If-None-Match") == etag:
            self.send_response(304)
            self.send_header("ETag", etag)
            self.send_header("Cache-Control", cache)
            self.end_headers()
            return True
        ctype = _STATIC_TYPES[ext]
        if ext in (".mp4", ".webm"):
            return self._ranged(full, st.st_size, ctype, etag, cache)
        key = (full, st.st_mtime_ns, st.st_size)
        hit = _gz_cache.get(full)
        if hit and hit[0] == key:
            raw, gz = hit[1], hit[2]
        else:
            with open(full, "rb") as f:
                raw = f.read()
            if ext == ".html":
                raw = _versioned_html(full, raw)
            gz = _gzip.compress(raw, 6) if ext in _GZIP_EXT and len(raw) > 1024 else None
            if len(raw) < 4_000_000:
                _gz_cache[full] = (key, raw, gz)
        use_gz = gz is not None and "gzip" in (self.headers.get("Accept-Encoding") or "")
        body = gz if use_gz else raw
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("ETag", etag)
        self.send_header("Cache-Control", cache)
        if use_gz:
            self.send_header("Content-Encoding", "gzip")
        if ext in _GZIP_EXT:
            self.send_header("Vary", "Accept-Encoding")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)
        return True

    def _ranged(self, full, size, ctype, etag, cache):
        start, end = 0, size - 1
        rng = self.headers.get("Range") or ""
        m = re.match(r"bytes=(\d*)-(\d*)$", rng.strip())
        partial = bool(m and (m.group(1) or m.group(2)))
        if partial:
            if m.group(1):
                start = int(m.group(1))
                end = min(int(m.group(2)) if m.group(2) else size - 1, size - 1)
            else:
                start = max(0, size - int(m.group(2)))
            if start > end or start >= size:
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{size}")
                self.end_headers()
                return True
        self.send_response(206 if partial else 200)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1))
        if partial:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.send_header("ETag", etag)
        self.send_header("Cache-Control", cache)
        self.end_headers()
        if self.command == "HEAD":
            return True
        with open(full, "rb") as f:
            f.seek(start)
            left = end - start + 1
            try:
                while left > 0:
                    chunk = f.read(min(262144, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
            except (BrokenPipeError, ConnectionResetError):
                pass
        return True

    def _json(self, code, data):
        body = json.dumps(data).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _host_ok(self):
        return self.headers.get("Host") in ALLOWED_HOSTS

    def do_GET(self):
        if not self._host_ok():
            return self._json(403, {"error": "forbidden"})
        path, _, qs = self.path.partition("?")
        query = parse_qs(qs)
        if path in features.FILE_ROUTES:
            return features.serve_media(self, path, query)
        if features.serve_prefix(self, path):
            return None
        if path in features.QUERY_ROUTES:
            try:
                return self._json(200, features.QUERY_ROUTES[path](query, self.headers))
            except ApiError as e:
                return self._json(e.code, {"error": str(e)})
            except Exception as e:  # noqa: BLE001
                return self._json(500, {"error": f"Interner Fehler: {e}"})
        if path.startswith("/api/"):
            fn = GET_ROUTES.get(path)
            if not fn:
                return self._json(404, {"error": "unbekannt"})
            try:
                return self._json(200, fn())
            except ApiError as e:
                return self._json(e.code, {"error": str(e)})
            except Exception as e:  # noqa: BLE001
                return self._json(500, {"error": f"Interner Fehler: {e}"})
        try:
            if self._static(path, query):
                return None
        except (BrokenPipeError, ConnectionResetError):
            return None
        return super().do_GET()

    def do_HEAD(self):
        if not self._host_ok():
            return self._json(403, {"error": "forbidden"})
        path, _, qs = self.path.partition("?")
        if self._static(path, parse_qs(qs)):
            return None
        return super().do_HEAD()

    def do_POST(self):
        if self.path in features.OPEN_POST_ROUTES and self._host_ok():
            return self._json(200, features.OPEN_POST_ROUTES[self.path]({}))
        origin = self.headers.get("Origin")
        if (not self._host_ok() or self.headers.get("X-Raspi-TV") != "1"
                or (origin and origin not in ALLOWED_ORIGINS)
                or not (self.headers.get("Content-Type") or "").startswith("application/json")):
            return self._json(403, {"error": "forbidden"})
        fn = POST_ROUTES.get(self.path)
        if not fn:
            return self._json(404, {"error": "unbekannt"})
        try:
            length = int(self.headers.get("Content-Length") or 0)
            if not 0 <= length <= 65536:
                raise ApiError("Anfrage ist zu groß oder hat eine ungültige Länge.", 413)
            data = json.loads(self.rfile.read(length) or b"{}")
            if not isinstance(data, dict):
                raise ApiError("Ungültige Anfrage")
            return self._json(200, fn(data))
        except ApiError as e:
            return self._json(e.code, {"error": str(e)})
        except ValueError:
            return self._json(400, {"error": "Ungültige Anfrage"})
        except Exception as e:  # noqa: BLE001
            return self._json(500, {"error": f"Interner Fehler: {e}"})

    def do_OPTIONS(self):  # CORS-Preflight immer ablehnen
        self.send_response(403)
        self.end_headers()


features.bind(globals())
REMOTE_ROUTES.update(features.REMOTE_ROUTES_EXTRA)

if __name__ == "__main__":
    ThreadingHTTPServer.daemon_threads = True
    threading.Thread(target=channel_updater, daemon=True).start()
    features.start_background()
    try:
        remote = ThreadingHTTPServer(("0.0.0.0", REMOTE_PORT), RemoteHandler)
        threading.Thread(target=remote.serve_forever, daemon=True).start()
    except OSError as e:
        print("Handy-Fernbedienung nicht verfügbar:", e, flush=True)
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
