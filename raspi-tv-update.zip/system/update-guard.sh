#!/bin/bash
# Raspi-TV: Prüfung nach einem Update.
#
#   update-guard.sh --boot     beim Start (Dienst raspi-tv-update-check): Liegt eine frische
#                              Update-Markierung vor und antwortet Raspi-TV nicht innerhalb von
#                              ca. 4 Minuten, wird die vorherige Version zurückgespielt und neu gestartet.
#   update-guard.sh <Sicherung> dasselbe ohne Neustart dazwischen (ältere Versionen)
DIR=/var/lib/raspi-tv-rollback
LOG=/var/log/raspi-tv-swupdate.log
if [ "$1" = "--boot" ]; then
	[ -f "$DIR/pending" ] || exit 0
	SNAP="$(cat "$DIR/pending")"
	rm -f "$DIR/pending"      # nur einmal versuchen – keine Neustart-Schleife
	REBOOT=1
else
	SNAP="$1"; REBOOT=0
fi
[ -f "$SNAP" ] || exit 0
sleep 20
for _ in $(seq 1 30); do
	if curl -sf -m 5 http://127.0.0.1:8765/api/status >/dev/null; then
		echo "$(date '+%F %T') Update-Prüfung: neue Version läuft" >>"$LOG"
		exit 0
	fi
	sleep 7
done
echo "$(date '+%F %T') Neue Version antwortet nicht – Rückkehr zu $(basename "$SNAP")" >>"$LOG"
tar -xzf "$SNAP" -C / && systemctl daemon-reload
touch "$DIR/rolled-back"
if [ "$REBOOT" = 1 ]; then
	systemctl reboot
else
	pkill -u tv -f raspi-tv-browser
	systemctl restart raspi-tv-cec
	systemctl restart raspi-tv-ctl
fi
