#!/bin/sh
# Raspi-TV: Lautstärke-Tasten (Tastatur/Air-Maus) -> Fernseher, Soundbar oder Pi
case "$1" in up|down|mute) ;; *) exit 1 ;; esac
exec curl -s -m 5 -X POST -H 'X-Raspi-TV: 1' -H 'Content-Type: application/json' \
	-d "{\"action\":\"$1\"}" http://127.0.0.1:8765/api/volume >/dev/null
