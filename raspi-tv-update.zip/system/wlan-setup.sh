#!/bin/bash
# Raspi-TV: richtet WLAN aus /boot/firmware/raspi-tv-wlan.txt ein.
# Läuft bei jedem Start; tut nichts, solange kein WLAN-Name eingetragen ist.
# Danach wird das Passwort aus der Datei gelöscht.

F=/boot/firmware/raspi-tv-wlan.txt
[ -f "$F" ] || exit 0

val() {
	grep -m1 "^$1=" "$F" | cut -d= -f2- | tr -d '\r' | sed -e 's/^ *"\{0,1\}//' -e 's/"\{0,1\} *$//'
}
SSID="$(val WLAN_NAME)"
PSK="$(val WLAN_PASSWORT)"
COUNTRY="$(val LAND)"; COUNTRY="${COUNTRY:-DE}"

[ -n "$SSID" ] || exit 0

echo "Richte WLAN \"$SSID\" ein (Land $COUNTRY)"
raspi-config nonint do_wifi_country "$COUNTRY" || true
rfkill unblock wifi || true

# Warten, bis NetworkManager bereit ist
for _ in $(seq 1 30); do nmcli general status >/dev/null 2>&1 && break; sleep 1; done

nmcli connection delete raspi-tv-wlan >/dev/null 2>&1 || true
nmcli connection add type wifi ifname wlan0 con-name raspi-tv-wlan ssid "$SSID" \
	connection.autoconnect yes >/dev/null
if [ -n "$PSK" ]; then
	nmcli connection modify raspi-tv-wlan wifi-sec.key-mgmt wpa-psk wifi-sec.psk "$PSK"
fi
nmcli connection up raspi-tv-wlan || echo "Verbindung noch nicht möglich – wird automatisch erneut versucht."

# Passwort nicht auf der Karte liegen lassen
cat >"$F" <<EOF
# Raspi-TV – WLAN einrichten
#
# WLAN "$SSID" wurde eingerichtet. Um ein anderes WLAN zu verwenden,
# hier wieder Name und Passwort eintragen und den Raspberry Pi neu starten.

WLAN_NAME=
WLAN_PASSWORT=
LAND=$COUNTRY
EOF
sync
