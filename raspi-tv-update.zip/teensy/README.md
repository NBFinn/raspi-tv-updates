# Runde Displays am Teensy 4.1

Ab Raspi-TV 7.0 können die beiden runden GC9A01-Displays an einem **Teensy 4.1** hängen statt an den
GPIO-Pins des Raspberry Pi. Der Teensy zeichnet alle Seiten und Animationen selbst (über DMA, bis ca.
30 Bilder pro Sekunde je Display). Der Pi schickt per USB nur noch Uhrzeit, Musik und Albumcover,
Lautstärke, WLAN/CPU, Update-Status und Farben.

## Verdrahtung

| Display-Pin | Display 1 (Uhr/Cover, WLAN, System) | Display 2 (Lautstärke, Status, Updates) |
|---|---|---|
| VCC | 3.3V | 3.3V |
| GND | GND | GND |
| SCL / SCK | 13 | 27 |
| SDA / MOSI | 11 | 26 |
| CS | 10 | 0 |
| DC | 9 | 2 |
| RST / RES | 8 | 3 |
| BL / BLK (nur falls vorhanden) | 6 | 7 |

Displays ohne BL-Pin brauchen keinen Anschluss dafür – die Helligkeit wird per Software geregelt.

Teensy per USB-Kabel (mit Datenleitungen) an den Raspberry Pi anschließen. Die Displays bekommen ihren
Strom vom 3.3V-Pin des Teensy. Kurze Kabel (unter 15 cm) erlauben hohe Übertragungsraten.

## Firmware einspielen

Raspi-TV spielt die Firmware selbst ein:

* **Neuer Teensy:** anschließen und **einmal den weißen Knopf** auf dem Teensy drücken. Der Pi erkennt den
  Programmiermodus und spielt `raspi-tv-displays.hex` ein (Dienst `raspi-tv-teensy-flash`).
* **Updates:** Bringt ein Raspi-TV-Update eine neuere Firmware mit, schickt der Pi den Teensy selbst in den
  Programmiermodus und spielt sie ein – ohne Knopfdruck.

Raspi-TV braucht dafür kein Zusatzprogramm (eigener HalfKay-Flasher in `round-displays.py`).
Manuell: `sudo python3 /opt/raspi-tv/round-displays.py --flash-teensy`
und dann den Knopf drücken. Oder mit der Arduino IDE + Teensyduino (Board „Teensy 4.1“, USB Type „Serial“) den Ordner
`raspi-tv-displays` öffnen und hochladen – keine zusätzliche Bibliothek nötig (der Display-Treiber
GC9A01A_t3n von KurtE, MIT-Lizenz, liegt im Sketch unter `src/`).

## Selbst bauen

```
sudo apt install gcc-arm-none-eabi libnewlib-arm-none-eabi libstdc++-arm-none-eabi-newlib
cd teensy && make          # lädt beim ersten Mal die Teensy-Bibliotheken von GitHub
```

Vorschau am PC ohne Hardware: `host/preview.cpp` (Bilderfolge) und `host/emulator.cpp` (spricht das
USB-Protokoll über ein Pseudo-Terminal). Schriften neu erzeugen: `python3 tools/make-teensy-fonts.py`.

## Protokoll (Pi → Teensy, Zeilen über USB-Seriell)

`S key=value<TAB>…` Zustand · `C <Bytes>` + Albumcover 240×240 RGB565 · `F <1|2> <Bytes>` + Testbild ·
`R <1|2>` Testbild beenden · `I` Startanimation · `P <Hz>` SPI-Takt · `B` Bootloader · `?` Version.
Der Teensy meldet sich mit `HELLO raspi-tv-displays <Version>`.
