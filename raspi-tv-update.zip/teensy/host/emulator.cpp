// Teensy-Emulator am PC: spricht das USB-Protokoll über ein Pseudo-Terminal und rendert beide Displays.
//   emulator <fd> <ausgabeordner> <sekunden>   (schreibt alle 0,25 s ein PPM-Bild beider Displays)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include "ui.h"
#include "proto.h"

static int fd;
static uint16_t fb[2][240 * 240], prevb[2][240 * 240], cover[240 * 240];
static State st;
static uint32_t introAt = 1, rawUntil[2];
static uint32_t ms() {
  static timespec t0;
  timespec t;
  clock_gettime(CLOCK_MONOTONIC, &t);
  if (!t0.tv_sec) t0 = t;
  return (uint32_t)((t.tv_sec - t0.tv_sec) * 1000 + (t.tv_nsec - t0.tv_nsec) / 1000000) + 1;
}
static void out(const char *s) { if (write(fd, s, strlen(s)) < 0) {} if (write(fd, "\n", 1) < 0) {} }
static void hello() { out("HELLO raspi-tv-displays 1.0.0 spi=30000000"); }
static uint8_t *target(int w, size_t) { return w < 0 ? (uint8_t *)cover : (uint8_t *)fb[w]; }
static void done(int w) { if (w < 0) st.hasCover = true; else rawUntil[w] = ms() + 15000; fprintf(stderr, "Bild %d empfangen\n", w); }
static void release(int d) { rawUntil[d] = 0; }
static void intro() { introAt = ms(); fprintf(stderr, "Intro\n"); }
static void speed(uint32_t) {}
static void boot() { fprintf(stderr, "Bootloader angefordert\n"); exit(0); }

int main(int argc, char **argv) {
  fd = atoi(argv[1]);
  const char *dir = argv[2];
  uint32_t end = atoi(argv[3]) * 1000;
  fcntl(fd, F_SETFL, O_NONBLOCK);
  Proto proto;
  proto.st = &st;
  proto.now = ms;
  proto.hooks = ProtoHooks{out, target, done, release, intro, speed, boot, hello};
  Screen sc[2];
  Rotation rot[2];
  PageRules rules;
  Canvas cv[2];
  for (int d = 0; d < 2; d++) { sc[d].which = d; sc[d].prev = prevb[d]; cv[d].bind(fb[d]); }
  Pal pal = makePal(st.accent, st.bg);
  strcpy(st.fw, "1.0.4");
  if (argc > 4) { strcpy(st.fwFrom, argv[4]); st.fwNoticeAt = INTRO_MS + 200; }
  hello();
  uint32_t lastShot = 0;
  int n = 0;
  uint8_t buf[65536];
  while (ms() < end) {
    ssize_t k = read(fd, buf, sizeof buf);
    if (k > 0) proto.feed(buf, (size_t)k);
    uint32_t now = ms();
    rules.apply(st, rot, now);
    pal = blendPal(pal, makePal(st.accent, st.bg), .06f);
    for (int d = 0; d < 2; d++) {
      if (rawUntil[d] && (int32_t)(now - rawUntil[d]) < 0) continue;
      if (proto.receiving(d)) continue;
      sc[d].frame(cv[d], st, pal, rot[d], now, introAt, cover, 0);
    }
    if (now - lastShot >= 250) {
      lastShot = now;
      char path[256];
      snprintf(path, sizeof path, "%s/e%04d.ppm", dir, n++);
      FILE *f = fopen(path, "wb");
      fprintf(f, "P6 480 240 255\n");
      for (int y = 0; y < 240; y++)
        for (int d = 0; d < 2; d++)
          for (int x = 0; x < 240; x++) {
            Col c = from565(fb[d][y * 240 + x]);
            unsigned char px[3] = {(unsigned char)c.r, (unsigned char)c.g, (unsigned char)c.b};
            fwrite(px, 1, 3, f);
          }
      fclose(f);
    }
    usleep(16000);
  }
  return 0;
}
