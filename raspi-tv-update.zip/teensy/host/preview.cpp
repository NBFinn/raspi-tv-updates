// Vorschau am PC: rendert Bilderfolgen beider Displays als PPM (für Tests und GIF-Vorschau).
//   g++ -O2 -I../raspi-tv-displays preview.cpp ../raspi-tv-displays/gfx.cpp ../raspi-tv-displays/ui.cpp -o preview
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "ui.h"

static uint16_t fb[2][240 * 240], prevb[2][240 * 240], cover[240 * 240];

static void save(const char *dir, int n) {
  char path[256];
  snprintf(path, sizeof path, "%s/f%04d.ppm", dir, n);
  FILE *f = fopen(path, "wb");
  fprintf(f, "P6 480 240 255\n");
  for (int y = 0; y < 240; y++)
    for (int d = 0; d < 2; d++)
      for (int x = 0; x < 240; x++) {
        Col c = from565(fb[d][y * 240 + x]);
        unsigned char px[3] = {(unsigned char)c.r, (unsigned char)c.g, (unsigned char)c.b};
        fwrite(px, 1, 3, f);
      }
  fclose(f);
}

int main(int argc, char **argv) {
  const char *dir = argc > 1 ? argv[1] : ".";
  const char *scenario = argc > 2 ? argv[2] : "all";
  for (int i = 0; i < 240 * 240; i++) {   // Testcover: Verlauf
    int x = i % 240, y = i / 240;
    cover[i] = to565(rgb(200 - y / 2, 60 + x / 3, 120 + y / 3));
  }
  State s;
  s.ever = true; s.epoch = (1794522000LL + 22 * 3600 + 14 * 60 + 5) * 1000; s.epochAt = 0;
  s.volume = 40; strcpy(s.version, "7.0.0");
  s.info.cpu = 34; s.info.temp = 52; s.info.ram = 41; s.info.signal = 78; s.info.wlan = true; strcpy(s.info.ssid, "FRITZ!Box 7590");
  strcpy(s.upd.installed, "7.0.0"); s.upd.online = true; s.upd.checkedMin = 120;
  Pal p = makePal(hexcol(0x6d5dfc), hexcol(0x0b0d12));
  Screen sc[2];
  Rotation rot[2];
  Canvas cv[2];
  for (int d = 0; d < 2; d++) { sc[d].which = d; sc[d].prev = prevb[d]; cv[d].bind(fb[d]); }
  int n = 0;
  uint32_t introAt = strcmp(scenario, "intro") == 0 || strcmp(scenario, "all") == 0 ? 1 : 0;
  uint32_t end = strcmp(scenario, "intro") == 0 ? 3600 : 34000;
  for (uint32_t now = 1; now < end; now += 40) {
    s.lastMs = now;
    if (now > 3500) { s.volume = now < 6000 ? 40 : 72; }
    if (now > 12000 && now < 22000) { s.playing = true; strcpy(s.title, "Nachts am Meer"); strcpy(s.artist, "Raspi-TV Band"); s.hasCover = true; }
    else s.playing = false;
    if (now > 24000) { s.upd.newer = true; strcpy(s.upd.latest, "7.1.0"); }
    if (now > 29000) { s.upd.running = true; snprintf(s.upd.step, sizeof s.upd.step, "Systemupdates %d/80", (int)((now - 29000) / 60)); }
    for (int d = 0; d < 2; d++) sc[d].frame(cv[d], s, p, rot[d], now, introAt, cover, 0);
    if (now % 80 == 1 || strcmp(scenario, "intro") == 0) save(dir, n++);
    // Rotation: Seiten schneller durchschalten für die Vorschau
    if (now == 3501) { rot[0].hold(0, now); rot[1].hold(0, now); }
    if (now == 8001) { rot[0].hold(1, now); rot[1].hold(1, now); }
    if (now == 10001) { rot[0].hold(2, now); }
    if (now == 12001) { rot[0].hold(0, now); }
    if (now == 24001) { rot[1].hold(2, now); }
  }
  printf("%d Bilder\n", n);
  return 0;
}
