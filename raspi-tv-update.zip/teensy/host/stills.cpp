// Einzelbilder der neuen Seiten (Uhren, Titelwechsel, Pause, VU-Meter) als PPM – zum Ansehen am PC.
//   g++ -O2 -I../raspi-tv-displays stills.cpp ../raspi-tv-displays/gfx.cpp ../raspi-tv-displays/ui.cpp -o stills
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "ui.h"

static uint16_t fb[2][240 * 240], prevb[2][240 * 240], cover[240 * 240];
static const char *dir = ".";

static void save(const char *name) {
  char path[256];
  snprintf(path, sizeof path, "%s/%s.ppm", dir, name);
  FILE *f = fopen(path, "wb");
  fprintf(f, "P6 480 240 255\n");
  for (int y = 0; y < 240; y++)
    for (int d = 0; d < 2; d++)
      for (int x = 0; x < 240; x++) {
        float dx = x - 119.5f, dy = y - 119.5f;
        Col c = dx * dx + dy * dy > 120 * 120 ? rgb(30, 30, 34) : from565(fb[d][y * 240 + x]);   // rund maskieren
        unsigned char px[3] = {(unsigned char)c.r, (unsigned char)c.g, (unsigned char)c.b};
        fwrite(px, 1, 3, f);
      }
  fclose(f);
}

struct Rig {
  State s;
  Pal p;
  Screen sc[2];
  Rotation rot[2];
  Canvas cv[2];
  Rig() {
    s.ever = true; s.epoch = (1794522000LL + 22 * 3600 + 9 * 60 + 37) * 1000; s.epochAt = 0;
    s.volume = 40; strcpy(s.version, "7.2.0"); s.info.cpu = 34; s.info.signal = 78; s.info.wlan = true;
    strcpy(s.upd.installed, "7.2.0"); s.upd.online = true;
    p = makePal(hexcol(0x6d5dfc), hexcol(0x0b0d12));
    for (int d = 0; d < 2; d++) { sc[d].which = d; sc[d].prev = prevb[d]; cv[d].bind(fb[d]); }
  }
  // von from bis to in 40-ms-Schritten rendern
  void run(uint32_t from, uint32_t to, void (*each)(Rig &, uint32_t) = nullptr) {
    for (uint32_t now = from; now <= to; now += 40) {
      s.lastMs = now;
      if (each) each(*this, now);
      for (int d = 0; d < 2; d++) sc[d].frame(cv[d], s, p, rot[d], now, 0, cover, 0);
    }
  }
};

static void music(Rig &r) {
  r.s.playing = true; r.s.hasCover = true;
  strcpy(r.s.title, "Nachts am Meer (Live in Hamburg 2024)"); strcpy(r.s.artist, "Raspi-TV Band"); strcpy(r.s.source, "SPOTIFY");
}

int main(int argc, char **argv) {
  if (argc > 1) dir = argv[1];
  for (int i = 0; i < 240 * 240; i++) {
    int x = i % 240, y = i / 240;
    cover[i] = to565(rgb(220 - y / 2, 90 + x / 3, 60 + y / 2));
  }
  for (int style = 0; style < 4; style++) {
    Rig r; r.s.clockStyle = style;
    r.run(1, 3001);
    char n[32]; snprintf(n, sizeof n, "uhr%d", style); save(n);
  }
  { Rig r; music(r); r.s.trackAt = 2001; r.run(1, 2401); save("titel_a"); r.run(2441, 3401); save("titel_b"); r.run(3441, 6001); save("titel_c");
    r.run(6041, 9801); save("spielt");
    r.rot[0].hold(0, 9801); r.s.playing = false; r.s.paused = true; r.run(9841, 10201); save("pause_a"); r.run(10241, 13001); save("pause_b"); }
  { Rig r; music(r); r.s.vuMode = 2; r.s.trackAt = 0;
    r.run(1, 4001, [](Rig &q, uint32_t now) { q.s.vu[0] = 58 + 20 * sinf(now / 300.f); q.s.vu[1] = 80 + 18 * sinf(now / 210.f); q.s.vuAt = now; });
    save("vu"); }
  { Rig r; r.s.wx.valid = true; r.s.wx.temp = 14; r.s.wx.code = 61; r.s.wx.rain = 80; r.s.wx.hi = 16; r.s.wx.lo = 9; strcpy(r.s.wx.city, "Berlin");
    r.s.sleepLeft = 1500; r.s.sleepTotal = 1800; r.s.sleepAt = 1; strcpy(r.s.wake, "06:30");
    r.rot[0].hold(4, 1); r.run(1, 41); r.rot[0].hold(4, 41); r.rot[1].hold(5, 41); r.run(81, 3001); save("wetter_timer");
    r.s.wx.code = 2; r.s.wx.rain = 10; r.s.sleepLeft = 42; r.s.sleepAt = 3001; r.run(3041, 6001); save("heiter_timer60"); }
  { Rig r; r.s.wx.valid = true; r.s.wx.temp = -2; r.s.wx.code = 73; r.s.wx.rain = 60; r.s.wx.hi = 1; r.s.wx.lo = -5; r.s.wx.day = false; strcpy(r.s.wx.city, "Garmisch-Partenkirchen");
    strcpy(r.s.notice.title, "Aufnahme gestartet"); strcpy(r.s.notice.text, "Tatort: Nachtschatten \xC2\xB7 Das Erste"); r.s.notice.kind = 'r'; r.s.notice.at = 1001;
    r.rot[0].hold(4, 1); r.run(1, 41); r.rot[0].hold(4, 41); r.run(81, 3001); save("schnee_hinweis");
    r.s.wx.code = 95; r.s.wx.day = true; strcpy(r.s.notice.title, "Unterspannung"); strcpy(r.s.notice.text, "Netzteil oder Kabel des Pi ist zu schwach"); r.s.notice.kind = 'w'; r.s.notice.at = 3001;
    r.run(3041, 5001); save("warnung"); r.s.notice.at = 0; r.s.wx.code = 0; r.run(5041, 7001); save("klar_nacht"); }
  { Rig r; strcpy(r.s.tvName, "Das Erste HD"); strcpy(r.s.tvTitle, "Tatort: Nachtschatten"); int64_t l = r.s.epoch / 1000; r.s.tvStart = l - 2400; r.s.tvStop = l + 3000;
    r.s.upd.running = true; strcpy(r.s.upd.step, "Download 12/21"); r.run(1, 3001); save("tv_download"); }
  { Rig r; music(r); r.s.trackAt = 0; r.s.posMs = 95000; r.s.durMs = 214000; r.s.posAt = 1; r.s.pages[1] = 0x02; r.run(1, 3001); save("fortschritt"); }
  { Rig r; strcpy(r.s.cdName, "Urlaub Mallorca"); r.s.cdDays = 23; r.s.pages[0] = 32;
    r.run(1, 3001); save("countdown");
    r.s.cdDays = 0; strcpy(r.s.cdName, "Silvester"); r.run(3041, 6001); save("countdown_heute");
    r.s.saver = true; r.s.saverAt = 6001; r.run(6041, 12001); save("saver"); }
  return 0;
}
