// Einzelbilder der neuen Seiten (Uhren, Titelwechsel, Pause, VU-Meter) als PPM – zum Ansehen am PC.
//   g++ -O2 -I../raspi-tv-displays stills.cpp ../raspi-tv-displays/gfx.cpp ../raspi-tv-displays/ui.cpp -o stills
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "ui.h"

static uint16_t fb[2][240 * 240], prevb[2][240 * 240], cover[240 * 240];
static const char *dir = ".";

static void save(const char *name) {
  char path[256];
  snprintf(path, sizeof path, "%s/%s.ppm", dir, name);
  FILE *f = fopen(path, "wb");
  fprintf(f, "P6 480 240 255\n");
  for (int y = 0; y < 240; y++)
    for (int d = 0; d < 2; d++)
      for (int x = 0; x < 240; x++) {
        float dx = x - 119.5f, dy = y - 119.5f;
        Col c = dx * dx + dy * dy > 120 * 120 ? rgb(30, 30, 34) : from565(fb[d][y * 240 + x]);   // rund maskieren
        unsigned char px[3] = {(unsigned char)c.r, (unsigned char)c.g, (unsigned char)c.b};
        fwrite(px, 1, 3, f);
      }
  fclose(f);
}

struct Rig {
  State s;
  Pal p;
  Screen sc[2];
  Rotation rot[2];
  Canvas cv[2];
  Rig() {
    s.ever = true; s.epoch = (1794522000LL + 22 * 3600 + 9 * 60 + 37) * 1000; s.epochAt = 0;
    s.volume = 40; strcpy(s.version, "7.2.0"); s.info.cpu = 34; s.info.signal = 78; s.info.wlan = true;
    strcpy(s.upd.installed, "7.2.0"); s.upd.online = true;
    p = makePal(hexcol(0x6d5dfc), hexcol(0x0b0d12));
    for (int d = 0; d < 2; d++) { sc[d].which = d; sc[d].prev = prevb[d]; cv[d].bind(fb[d]); }
  }
  // von from bis to in 40-ms-Schritten rendern
  void run(uint32_t from, uint32_t to, void (*each)(Rig &, uint32_t) = nullptr) {
    for (uint32_t now = from; now <= to; now += 40) {
      s.lastMs = now;
      if (each) each(*this, now);
      for (int d = 0; d < 2; d++) sc[d].frame(cv[d], s, p, rot[d], now, 0, cover, 0);
    }
  }
};

static void music(Rig &r) {
  r.s.playing = true; r.s.hasCover = true;
  strcpy(r.s.title, "Nachts am Meer (Live in Hamburg 2024)"); strcpy(r.s.artist, "Raspi-TV Band"); strcpy(r.s.source, "SPOTIFY");
}

int main(int argc, char **argv) {
  if (argc > 1) dir = argv[1];
  for (int i = 0; i < 240 * 240; i++) {
    int x = i % 240, y = i / 240;
    cover[i] = to565(rgb(220 - y / 2, 90 + x / 3, 60 + y / 2));
  }
  for (int style = 0; style < 4; style++) {
    Rig r; r.s.clockStyle = style;
    r.run(1, 3001);
    char n[32]; snprintf(n, sizeof n, "uhr%d", style); save(n);
  }
  { Rig r; music(r); r.s.trackAt = 2001; r.run(1, 2401); save("titel_a"); r.run(2441, 3401); save("titel_b"); r.run(3441, 6001); save("titel_c");
    r.run(6041, 9801); save("spielt");
    r.rot[0].hold(0, 9801); r.s.playing = false; r.s.paused = true; r.run(9841, 10201); save("pause_a"); r.run(10241, 13001); save("pause_b"); }
  { Rig r; music(r); r.s.vuMode = 2; r.s.trackAt = 0;
    r.run(1, 4001, [](Rig &q, uint32_t now) { q.s.vu[0] = 58 + 20 * sinf(now / 300.f); q.s.vu[1] = 80 + 18 * sinf(now / 210.f); q.s.vuAt = now; });
    save("vu"); }
  return 0;
}
