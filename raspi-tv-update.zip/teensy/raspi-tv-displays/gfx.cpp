#include "gfx.h"
#include <string.h>

#ifdef ARDUINO
#include <avr/pgmspace.h>
#endif

void Canvas::clear(Col c) {
  uint16_t v = to565(c);
  for (int i = 0; i < W * H; i++) px[i] = v;
}

void Canvas::blend(int x, int y, Col c, float a) {
  if (x < clipX0 || x >= clipX1 || (unsigned)y >= (unsigned)H || a <= 0.003f) return;
  uint16_t *p = &px[y * W + x];
  if (a >= 0.997f) {
    *p = to565(c);
    return;
  }
  *p = to565(mix(from565(*p), c, a));
}

static inline void bbox(float x0, float y0, float x1, float y1, int &ax, int &ay, int &bx, int &by) {
  ax = (int)floorf(x0); ay = (int)floorf(y0); bx = (int)ceilf(x1); by = (int)ceilf(y1);
  if (ax < 0) ax = 0;
  if (ay < 0) ay = 0;
  if (bx > W - 1) bx = W - 1;
  if (by > H - 1) by = H - 1;
}

void Canvas::disc(float cx, float cy, float r, Col c, float alpha) {
  int ax, ay, bx, by;
  bbox(cx - r - 1, cy - r - 1, cx + r + 1, cy + r + 1, ax, ay, bx, by);
  for (int y = ay; y <= by; y++)
    for (int x = ax; x <= bx; x++) {
      float d = sqrtf((x + .5f - cx) * (x + .5f - cx) + (y + .5f - cy) * (y + .5f - cy));
      blend(x, y, c, alpha * clamp01(r - d + .5f));
    }
}

void Canvas::glow(float cx, float cy, float r, Col c, float alpha) {
  int ax, ay, bx, by;
  bbox(cx - r, cy - r, cx + r, cy + r, ax, ay, bx, by);
  for (int y = ay; y <= by; y++)
    for (int x = ax; x <= bx; x++) {
      float d = sqrtf((x + .5f - cx) * (x + .5f - cx) + (y + .5f - cy) * (y + .5f - cy)) / r;
      if (d < 1) {
        float k = 1 - d;
        blend(x, y, c, alpha * k * k);
      }
    }
}

static inline float wrap360(float a) {
  a = fmodf(a, 360.f);
  return a < 0 ? a + 360 : a;
}

void Canvas::arc(float cx, float cy, float r, float width, float a0, float a1, Grad g, float alpha, bool caps) {
  if (a1 <= a0 || alpha <= 0) return;
  float span = a1 - a0;
  bool full = span >= 359.9f;
  float rin = r - width, rmid = r - width / 2, hw = width / 2;
  int ax, ay, bx, by;
  bbox(cx - r - 1, cy - r - 1, cx + r + 1, cy + r + 1, ax, ay, bx, by);
  float s0 = a0 * (float)M_PI / 180, s1 = a1 * (float)M_PI / 180;
  float e0x = cx + rmid * cosf(s0), e0y = cy + rmid * sinf(s0);
  float e1x = cx + rmid * cosf(s1), e1y = cy + rmid * sinf(s1);
  for (int y = ay; y <= by; y++) {
    float dy = y + .5f - cy;
    for (int x = ax; x <= bx; x++) {
      float dx = x + .5f - cx;
      float d = sqrtf(dx * dx + dy * dy);
      if (d < rin - 1.5f || d > r + 1.5f) continue;
      float cover = clamp01(r - d + .5f) * clamp01(d - rin + .5f);
      float ang = fastAtan2(dy, dx) * 180 / (float)M_PI;
      float rel = wrap360(ang - a0);
      float t;
      if (full) {
        t = rel / 360;
      } else if (rel <= span) {
        // weiche Kante an den Enden (ohne Kappen)
        float edge = fminf(rel, span - rel) * (float)M_PI / 180 * d;
        if (!caps) cover *= clamp01(edge + .5f);
        t = rel / span;
      } else {
        if (!caps) continue;
        // runde Kappen an beiden Enden
        float d0 = sqrtf((x + .5f - e0x) * (x + .5f - e0x) + (y + .5f - e0y) * (y + .5f - e0y));
        float d1 = sqrtf((x + .5f - e1x) * (x + .5f - e1x) + (y + .5f - e1y) * (y + .5f - e1y));
        float dd = fminf(d0, d1);
        cover = clamp01(hw - dd + .5f);
        t = d0 < d1 ? 0 : 1;
      }
      if (cover > 0) blend(x, y, g.at(t), alpha * cover);
    }
  }
}

void Canvas::line(float x0, float y0, float x1, float y1, float width, Col c, float alpha) {
  float hw = width / 2;
  int ax, ay, bx, by;
  bbox(fminf(x0, x1) - hw - 1, fminf(y0, y1) - hw - 1, fmaxf(x0, x1) + hw + 1, fmaxf(y0, y1) + hw + 1, ax, ay, bx, by);
  float vx = x1 - x0, vy = y1 - y0, len2 = vx * vx + vy * vy;
  for (int y = ay; y <= by; y++)
    for (int x = ax; x <= bx; x++) {
      float px_ = x + .5f - x0, py_ = y + .5f - y0;
      float t = len2 > 0 ? clamp01((px_ * vx + py_ * vy) / len2) : 0;
      float dx = px_ - vx * t, dy = py_ - vy * t;
      float d = sqrtf(dx * dx + dy * dy);
      blend(x, y, c, alpha * clamp01(hw - d + .5f));
    }
}

void Canvas::triangle(float x0, float y0, float x1, float y1, float x2, float y2, Col c, float alpha) {
  int ax, ay, bx, by;
  bbox(fminf(x0, fminf(x1, x2)) - 1, fminf(y0, fminf(y1, y2)) - 1, fmaxf(x0, fmaxf(x1, x2)) + 1,
       fmaxf(y0, fmaxf(y1, y2)) + 1, ax, ay, bx, by);
  float area = (x1 - x0) * (y2 - y0) - (y1 - y0) * (x2 - x0);
  float sgn = area < 0 ? -1 : 1;
  float ex[3] = {x0, x1, x2}, ey[3] = {y0, y1, y2};
  for (int y = ay; y <= by; y++)
    for (int x = ax; x <= bx; x++) {
      float m = 1e9f;
      for (int i = 0; i < 3; i++) {
        float axp = ex[i], ayp = ey[i], bxp = ex[(i + 1) % 3], byp = ey[(i + 1) % 3];
        float ux = bxp - axp, uy = byp - ayp, l = sqrtf(ux * ux + uy * uy);
        float dist = sgn * ((x + .5f - axp) * uy - (y + .5f - ayp) * ux) / (l > 0 ? l : 1);
        m = fminf(m, -dist);
      }
      blend(x, y, c, alpha * clamp01(m + .5f));
    }
}

uint32_t utf8next(const char *&s) {
  uint8_t c = (uint8_t)*s;
  if (!c) return 0;
  s++;
  if (c < 0x80) return c;
  int n = (c >= 0xF0) ? 3 : (c >= 0xE0) ? 2 : 1;
  uint32_t v = c & (0x3F >> n);
  while (n-- && (*s & 0xC0) == 0x80) v = (v << 6) | (*s++ & 0x3F);
  return v;
}

static const Glyph *findGlyph(const Font &f, uint32_t code) {
  int lo = 0, hi = f.count - 1;
  while (lo <= hi) {
    int mid = (lo + hi) / 2;
    if (f.glyphs[mid].code == code) return &f.glyphs[mid];
    if (f.glyphs[mid].code < code) lo = mid + 1;
    else hi = mid - 1;
  }
  return code == '?' ? nullptr : findGlyph(f, '?');
}

float Canvas::textWidth(const Font &f, const char *s) {
  float w = 0;
  while (*s) {
    const Glyph *g = findGlyph(f, utf8next(s));
    if (g) w += g->adv / 4.f;
  }
  return w;
}

float Canvas::text(const Font &f, const char *s, float x, float y, Col c, int align, float alpha) {
  float w = textWidth(f, s);
  if (align == 1) x -= w / 2;
  else if (align == 2) x -= w;
  float fx = x;
  int iy = (int)roundf(y);
  while (*s) {
    const Glyph *g = findGlyph(f, utf8next(s));
    if (!g) continue;
    int ix = (int)roundf(fx);
    const uint8_t *bits = f.bits + g->offset;
    for (int j = 0; j < g->h; j++)
      for (int i = 0; i < g->w; i++) {
        int k = j * g->w + i;
        uint8_t b = bits[k >> 1];
        uint8_t v = (k & 1) ? (b & 15) : (b >> 4);
        if (v) blend(ix + g->x + i, iy + g->y + j, c, alpha * v / 15.f);
      }
    fx += g->adv / 4.f;
  }
  return w;
}

void Canvas::textFit(const Font &f, const char *s, float x, float y, Col c, float maxW, float alpha) {
  if (textWidth(f, s) <= maxW) {
    text(f, s, x, y, c, 1, alpha);
    return;
  }
  char buf[96];
  size_t n = strlen(s);
  if (n > sizeof(buf) - 4) n = sizeof(buf) - 4;
  memcpy(buf, s, n);
  buf[n] = 0;
  while (n > 0) {
    // auf ganzes UTF-8-Zeichen zurückgehen
    do n--; while (n > 0 && (buf[n] & 0xC0) == 0x80);
    memcpy(buf + n, "\xE2\x80\xA6", 4);
    if (textWidth(f, buf) <= maxW) break;
  }
  text(f, buf, x, y, c, 1, alpha);
}

void Canvas::image(const uint16_t *src, float cx, float cy, float r, float alpha) {
  int ax, ay, bx, by;
  bbox(cx - r - 1, cy - r - 1, cx + r + 1, cy + r + 1, ax, ay, bx, by);
  float scale = 240.f / (2 * r);
  for (int y = ay; y <= by; y++)
    for (int x = ax; x <= bx; x++) {
      float dx = x + .5f - cx, dy = y + .5f - cy;
      float cover = clamp01(r - sqrtf(dx * dx + dy * dy) + .5f);
      if (cover <= 0) continue;
      int sx = (int)((dx + r) * scale), sy = (int)((dy + r) * scale);
      if (sx < 0 || sy < 0 || sx >= 240 || sy >= 240) continue;
      blend(x, y, from565(src[sy * 240 + sx]), alpha * cover);
    }
}

void Canvas::vignette(Col edge, float strength) {
  for (int y = 0; y < H; y++)
    for (int x = 0; x < W; x++) {
      float dx = (x - 119.5f) / 120, dy = (y - 119.5f) / 120;
      float d = dx * dx + dy * dy;
      if (d > .55f) blend(x, y, edge, strength * clamp01((d - .55f) / .45f));
    }
}

void Canvas::dim(float level) {
  if (level >= 0.999f) return;
  uint32_t k = (uint32_t)(level * 256);
  for (int i = 0; i < W * H; i++) {
    uint32_t v = px[i];
    uint32_t r = ((v >> 11) & 31) * k >> 8, g = ((v >> 5) & 63) * k >> 8, b = (v & 31) * k >> 8;
    px[i] = (uint16_t)((r << 11) | (g << 5) | b);
  }
}
