// Raspi-TV Displays – kleine kantengeglättete Grafik für 240×240-RGB565-Puffer.
// Alle Formen werden pro Pixel über Abstandsfelder gezeichnet (weiche Kanten, Verläufe).
#pragma once
#include <stdint.h>
#include <math.h>
#if defined(__IMXRT1062__)
#include <avr/pgmspace.h>   // Teensy: Schriften im Flash statt im RAM
#endif
#ifndef PROGMEM
#define PROGMEM
#endif
#include "fonts.h"

static const int W = 240, H = 240;

struct Col {
  float r, g, b;
};

static inline Col rgb(int r, int g, int b) { return Col{(float)r, (float)g, (float)b}; }
static inline Col hexcol(uint32_t v) { return rgb((v >> 16) & 255, (v >> 8) & 255, v & 255); }
static inline Col mix(Col a, Col b, float t) {
  return Col{a.r + (b.r - a.r) * t, a.g + (b.g - a.g) * t, a.b + (b.b - a.b) * t};
}
static inline float clamp01(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
static inline float easeOut(float t) { t = clamp01(t); return 1 - (1 - t) * (1 - t) * (1 - t); }
static inline float easeInOut(float t) { t = clamp01(t); return t < .5f ? 4 * t * t * t : 1 - powf(-2 * t + 2, 3) / 2; }
static inline float easeBack(float t) {
  t = clamp01(t);
  const float c = 1.9f;
  return 1 + (c + 1) * powf(t - 1, 3) + c * powf(t - 1, 2);
}
// schnelle atan2-Näherung (Fehler < 0,3°), deutlich schneller als atan2f auf dem Teensy
static inline float fastAtan2(float y, float x) {
  float ax = fabsf(x), ay = fabsf(y);
  float mx = ax > ay ? ax : ay, mn = ax > ay ? ay : ax;
  if (mx == 0) return 0;
  float a = mn / mx, s2 = a * a;
  float r = ((-0.0464964749f * s2 + 0.15931422f) * s2 - 0.327622764f) * s2 * a + a;
  if (ay > ax) r = 1.57079637f - r;
  if (x < 0) r = 3.14159274f - r;
  if (y < 0) r = -r;
  return r;
}
static inline uint16_t to565(Col c) {
  int r = (int)(c.r + .5f), g = (int)(c.g + .5f), b = (int)(c.b + .5f);
  r = r < 0 ? 0 : r > 255 ? 255 : r;
  g = g < 0 ? 0 : g > 255 ? 255 : g;
  b = b < 0 ? 0 : b > 255 ? 255 : b;
  return (uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3));
}
static inline Col from565(uint16_t v) {
  return Col{(float)(((v >> 11) & 31) * 255 / 31), (float)(((v >> 5) & 63) * 255 / 63), (float)((v & 31) * 255 / 31)};
}

// Farbverlauf entlang eines Rings (t = 0…1)
struct Grad {
  Col a, b;
  bool single;
  Col at(float t) const { return single ? a : mix(a, b, clamp01(t)); }
};
static inline Grad solid(Col c) { return Grad{c, c, true}; }
static inline Grad grad(Col a, Col b) { return Grad{a, b, false}; }

class Canvas {
 public:
  uint16_t *px = nullptr;
  int clipX0 = 0, clipX1 = W;   // waagerechter Ausschnitt (Lauftext)
  void bind(uint16_t *buffer) { px = buffer; }
  void clear(Col c);
  void blend(int x, int y, Col c, float a);
  // gefüllter Kreis mit weicher Kante
  void disc(float cx, float cy, float r, Col c, float alpha = 1);
  // weicher Lichthof (Leuchten)
  void glow(float cx, float cy, float r, Col c, float alpha);
  // Ringbogen: Winkel in Grad, 0 = 3 Uhr, im Uhrzeigersinn (wie PIL); runde Enden optional
  void arc(float cx, float cy, float r, float width, float a0, float a1, Grad g, float alpha = 1, bool caps = true);
  // Linie mit runden Enden
  void line(float x0, float y0, float x1, float y1, float width, Col c, float alpha = 1);
  void triangle(float x0, float y0, float x1, float y1, float x2, float y2, Col c, float alpha = 1);
  // Text: align 0 = links, 1 = Mitte, 2 = rechts; y = Grundlinie
  float text(const Font &f, const char *s, float x, float y, Col c, int align = 1, float alpha = 1);
  float textWidth(const Font &f, const char *s);
  // Text auf maxW kürzen (mit „…“)
  void textFit(const Font &f, const char *s, float x, float y, Col c, float maxW, float alpha = 1);
  // RGB565-Bild (240×240) in einen Kreis einsetzen
  void image(const uint16_t *src, float cx, float cy, float r, float alpha = 1);
  void vignette(Col edge, float strength);
  // ganzes Bild abdunkeln (Displays ohne Beleuchtungs-Pin)
  void dim(float level);
};

uint32_t utf8next(const char *&s);
