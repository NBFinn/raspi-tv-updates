#include "proto.h"
#include <stdlib.h>
#include <string.h>

static uint32_t hexval(const char *v) { return (uint32_t)strtoul(v[0] == '#' ? v + 1 : v, nullptr, 16); }
static int clampi(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }
static void copyText(char *dst, size_t n, const char *v) {
  strncpy(dst, v, n - 1);
  dst[n - 1] = 0;
}

void Proto::apply(const char *k, const char *v) {
  State &s = *st;
  if (!strcmp(k, "tm")) hasMs = true;
  int i = atoi(v);
  if (!strcmp(k, "tm")) s.syncClock(atoll(v), now());                    // Millisekunden (ab 7.1.3)
  else if (!strcmp(k, "t")) { if (!hasMs) s.syncClock(atoll(v) * 1000, now()); }   // ältere Pi-Version
  else if (!strcmp(k, "v")) { if (s.volume >= 0 && s.volume != i) s.volAt = now() | 1; s.volume = i; }
  else if (!strcmp(k, "m")) { if (s.muted != (i != 0)) s.volAt = now() | 1; s.muted = i; }
  else if (!strcmp(k, "tg")) copyText(s.target, sizeof s.target, v);
  else if (!strcmp(k, "pl")) s.playing = i;
  else if (!strcmp(k, "pa")) s.paused = i;
  else if (!strcmp(k, "ti")) {
    if (v[0] && strncmp(s.title, v, sizeof s.title - 1) != 0) s.trackAt = now() | 1;   // neuer Titel → kurz groß zeigen
    copyText(s.title, sizeof s.title, v);
  }
  else if (!strcmp(k, "cs")) s.clockStyle = clampi(i, 0, 3);
  else if (!strcmp(k, "wx")) {      // Wetter: Temperatur|Code|Regen %|Max|Min|Tag
    int f[6] = {0, 0, -1, 0, 0, 1}, n = 0;
    const char *p = v;
    while (*p && n < 6) {
      f[n++] = atoi(p);
      const char *bar = strchr(p, '|');
      if (!bar) break;
      p = bar + 1;
    }
    s.wx.valid = n >= 2;
    s.wx.temp = f[0]; s.wx.code = f[1]; s.wx.rain = f[2]; s.wx.hi = f[3]; s.wx.lo = f[4]; s.wx.day = f[5] != 0;
  }
  else if (!strcmp(k, "wc")) copyText(s.wx.city, sizeof s.wx.city, v);
  else if (!strcmp(k, "po")) { s.posMs = atoll(v); s.posAt = now(); }
  else if (!strcmp(k, "du")) s.durMs = atoll(v);
  else if (!strcmp(k, "tvn")) copyText(s.tvName, sizeof s.tvName, v);
  else if (!strcmp(k, "tvt")) copyText(s.tvTitle, sizeof s.tvTitle, v);
  else if (!strcmp(k, "tva")) s.tvStart = atoll(v);
  else if (!strcmp(k, "tvz")) s.tvStop = atoll(v);
  else if (!strcmp(k, "sl")) { s.sleepLeft = i; s.sleepAt = now(); }
  else if (!strcmp(k, "st")) s.sleepTotal = i;
  else if (!strcmp(k, "wk")) copyText(s.wake, sizeof s.wake, v);
  else if (!strcmp(k, "p1")) s.pages[0] = i;
  else if (!strcmp(k, "p2")) s.pages[1] = i;
  else if (!strcmp(k, "pd")) s.pageSec = clampi(i, 4, 120);
  else if (!strcmp(k, "vu")) s.vuMode = clampi(i, 0, 2);
  else if (!strcmp(k, "ar")) copyText(s.artist, sizeof s.artist, v);
  else if (!strcmp(k, "cv")) s.hasCover = i;
  else if (!strcmp(k, "so")) copyText(s.source, sizeof s.source, v);
  else if (!strcmp(k, "ac")) s.accent = hexcol(hexval(v));
  else if (!strcmp(k, "bg")) s.bg = hexcol(hexval(v));
  else if (!strcmp(k, "br")) s.brightness = clampi(i, 5, 100);
  else if (!strcmp(k, "mo")) s.motion = i;
  else if (!strcmp(k, "cpu")) s.info.cpu = i;
  else if (!strcmp(k, "tmp")) s.info.temp = i;
  else if (!strcmp(k, "ram")) s.info.ram = i;
  else if (!strcmp(k, "sig")) s.info.signal = i;
  else if (!strcmp(k, "wl")) s.info.wlan = i;
  else if (!strcmp(k, "ss")) copyText(s.info.ssid, sizeof s.info.ssid, v);
  else if (!strcmp(k, "ne")) s.info.nerr = clampi(i, 0, 9);
  else if (!strcmp(k, "e1")) copyText(s.info.errors[0], sizeof s.info.errors[0], v);
  else if (!strcmp(k, "ui")) copyText(s.upd.installed, sizeof s.upd.installed, v);
  else if (!strcmp(k, "ul")) copyText(s.upd.latest, sizeof s.upd.latest, v);
  else if (!strcmp(k, "un")) s.upd.newer = i;
  else if (!strcmp(k, "ur")) s.upd.running = i;
  else if (!strcmp(k, "us")) copyText(s.upd.step, sizeof s.upd.step, v);
  else if (!strcmp(k, "ue")) s.upd.error = i;
  else if (!strcmp(k, "uo")) s.upd.online = i;
  else if (!strcmp(k, "ua")) s.upd.autoInst = i;
  else if (!strcmp(k, "uc")) s.upd.checkedMin = i;
  else if (!strcmp(k, "ver")) copyText(s.version, sizeof s.version, v);
  else if (!strcmp(k, "tvs")) s.tvStandby = i;
}

void Proto::handle(char *s) {
  if (s[0] == 'S' && s[1] == ' ') {
    char *p = s + 2;
    while (*p) {
      char *tab = strchr(p, '\t');
      if (tab) *tab = 0;
      char *eq = strchr(p, '=');
      if (eq) {
        *eq = 0;
        apply(p, eq + 1);
      }
      if (!tab) break;
      p = tab + 1;
    }
    st->ever = true;
    st->lastMs = now();
    if (st->mode == 1) hooks.intro();   // Pi ist nach dem Neustart wieder da → Startanimation
    st->mode = 0;
    hooks.reply("OK");
  } else if ((s[0] == 'C' || s[0] == 'F') && s[1] == ' ') {
    int which = -1;
    const char *num = s + 2;
    if (s[0] == 'F') {
      which = atoi(s + 2) - 1;
      num = strchr(s + 2, ' ');
      if (!num || (which != 0 && which != 1)) { hooks.reply("ERR Testbild"); return; }
      num++;
    }
    size_t n = strtoul(num, nullptr, 10);
    uint8_t *dst = n == 240u * 240u * 2u ? hooks.binTarget(which, n) : nullptr;
    if (!dst) { hooks.reply("ERR Bild muss 240x240 RGB565 sein"); return; }
    binDst = dst;
    binLeft = n;
    binFor = which;
  } else if (s[0] == 'R' && s[1] == ' ') {
    int d = atoi(s + 2) - 1;
    if (d == 0 || d == 1) hooks.release(d);
    hooks.reply("OK");
  } else if (s[0] == 'I') {
    hooks.intro();
    hooks.reply("OK");
  } else if (s[0] == 'P' && s[1] == ' ') {
    hooks.speed(strtoul(s + 2, nullptr, 10));
    hooks.hello();
  } else if (s[0] == 'B') {
    hooks.reply("OK Bootloader");
    hooks.bootloader();
  } else if (s[0] == 'O' && s[1] == ' ') {
    st->mode = strncmp(s + 2, "reboot", 6) == 0 ? 1 : 2;
    st->modeAt = now();
    hooks.reply("OK");
  } else if (s[0] == 'N' && s[1] == ' ') {
    // Hinweis: N <Art>\t<Titel>\t<Text>
    Notice &n = st->notice;
    n.kind = s[2] ? s[2] : 'i';
    char *a = strchr(s + 2, '\t'), *b = a ? strchr(a + 1, '\t') : nullptr;
    if (b) *b = 0;
    copyText(n.title, sizeof n.title, a ? a + 1 : "");
    copyText(n.text, sizeof n.text, b ? b + 1 : "");
    n.at = now() | 1;
    hooks.reply("OK");
  } else if (s[0] == 'V' && s[1] == ' ') {
    // Tonpegel links/rechts (0…100), kommt ~20×/s und wird nicht bestätigt
    char *e = nullptr;
    long l = strtol(s + 2, &e, 10), r = e ? strtol(e, nullptr, 10) : l;
    st->vu[0] = (float)clampi((int)l, 0, 100);
    st->vu[1] = (float)clampi((int)r, 0, 100);
    st->vuAt = now() | 1;
  } else if (s[0] == '?') {
    hooks.hello();
  }
}

void Proto::feed(const uint8_t *data, size_t n) {
  while (n) {
    if (binLeft) {
      size_t k = n < binLeft ? n : binLeft;
      memcpy(binDst, data, k);
      binDst += k;
      binLeft -= k;
      data += k;
      n -= k;
      if (!binLeft) {
        hooks.binDone(binFor);
        hooks.reply("OK");
      }
      continue;
    }
    char c = (char)*data++;
    n--;
    if (c == '\n') {
      line[lineLen] = 0;
      if (lineLen && line[lineLen - 1] == '\r') line[lineLen - 1] = 0;
      handle(line);
      lineLen = 0;
    } else if (lineLen < sizeof line - 1) line[lineLen++] = c;
  }
}
