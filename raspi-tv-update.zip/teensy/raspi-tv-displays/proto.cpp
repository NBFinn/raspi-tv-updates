#include "proto.h"
#include <stdlib.h>
#include <string.h>

static uint32_t hexval(const char *v) { return (uint32_t)strtoul(v[0] == '#' ? v + 1 : v, nullptr, 16); }
static int clampi(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }
static void copyText(char *dst, size_t n, const char *v) {
  strncpy(dst, v, n - 1);
  dst[n - 1] = 0;
}

void Proto::apply(const char *k, const char *v) {
  State &s = *st;
  int i = atoi(v);
  if (!strcmp(k, "t")) { s.epoch = atoll(v); s.epochAt = now(); }
  else if (!strcmp(k, "v")) s.volume = i;
  else if (!strcmp(k, "m")) s.muted = i;
  else if (!strcmp(k, "tg")) copyText(s.target, sizeof s.target, v);
  else if (!strcmp(k, "pl")) s.playing = i;
  else if (!strcmp(k, "pa")) s.paused = i;
  else if (!strcmp(k, "ti")) copyText(s.title, sizeof s.title, v);
  else if (!strcmp(k, "ar")) copyText(s.artist, sizeof s.artist, v);
  else if (!strcmp(k, "cv")) s.hasCover = i;
  else if (!strcmp(k, "ac")) s.accent = hexcol(hexval(v));
  else if (!strcmp(k, "bg")) s.bg = hexcol(hexval(v));
  else if (!strcmp(k, "br")) s.brightness = clampi(i, 5, 100);
  else if (!strcmp(k, "mo")) s.motion = i;
  else if (!strcmp(k, "cpu")) s.info.cpu = i;
  else if (!strcmp(k, "tmp")) s.info.temp = i;
  else if (!strcmp(k, "ram")) s.info.ram = i;
  else if (!strcmp(k, "sig")) s.info.signal = i;
  else if (!strcmp(k, "wl")) s.info.wlan = i;
  else if (!strcmp(k, "ss")) copyText(s.info.ssid, sizeof s.info.ssid, v);
  else if (!strcmp(k, "ne")) s.info.nerr = clampi(i, 0, 9);
  else if (!strcmp(k, "e1")) copyText(s.info.errors[0], sizeof s.info.errors[0], v);
  else if (!strcmp(k, "ui")) copyText(s.upd.installed, sizeof s.upd.installed, v);
  else if (!strcmp(k, "ul")) copyText(s.upd.latest, sizeof s.upd.latest, v);
  else if (!strcmp(k, "un")) s.upd.newer = i;
  else if (!strcmp(k, "ur")) s.upd.running = i;
  else if (!strcmp(k, "us")) copyText(s.upd.step, sizeof s.upd.step, v);
  else if (!strcmp(k, "ue")) s.upd.error = i;
  else if (!strcmp(k, "uo")) s.upd.online = i;
  else if (!strcmp(k, "ua")) s.upd.autoInst = i;
  else if (!strcmp(k, "uc")) s.upd.checkedMin = i;
  else if (!strcmp(k, "ver")) copyText(s.version, sizeof s.version, v);
}

void Proto::handle(char *s) {
  if (s[0] == 'S' && s[1] == ' ') {
    char *p = s + 2;
    while (*p) {
      char *tab = strchr(p, '\t');
      if (tab) *tab = 0;
      char *eq = strchr(p, '=');
      if (eq) {
        *eq = 0;
        apply(p, eq + 1);
      }
      if (!tab) break;
      p = tab + 1;
    }
    st->ever = true;
    st->lastMs = now();
    hooks.reply("OK");
  } else if ((s[0] == 'C' || s[0] == 'F') && s[1] == ' ') {
    int which = -1;
    const char *num = s + 2;
    if (s[0] == 'F') {
      which = atoi(s + 2) - 1;
      num = strchr(s + 2, ' ');
      if (!num || (which != 0 && which != 1)) { hooks.reply("ERR Testbild"); return; }
      num++;
    }
    size_t n = strtoul(num, nullptr, 10);
    uint8_t *dst = n == 240u * 240u * 2u ? hooks.binTarget(which, n) : nullptr;
    if (!dst) { hooks.reply("ERR Bild muss 240x240 RGB565 sein"); return; }
    binDst = dst;
    binLeft = n;
    binFor = which;
  } else if (s[0] == 'R' && s[1] == ' ') {
    int d = atoi(s + 2) - 1;
    if (d == 0 || d == 1) hooks.release(d);
    hooks.reply("OK");
  } else if (s[0] == 'I') {
    hooks.intro();
    hooks.reply("OK");
  } else if (s[0] == 'P' && s[1] == ' ') {
    hooks.speed(strtoul(s + 2, nullptr, 10));
    hooks.hello();
  } else if (s[0] == 'B') {
    hooks.reply("OK Bootloader");
    hooks.bootloader();
  } else if (s[0] == '?') {
    hooks.hello();
  }
}

void Proto::feed(const uint8_t *data, size_t n) {
  while (n) {
    if (binLeft) {
      size_t k = n < binLeft ? n : binLeft;
      memcpy(binDst, data, k);
      binDst += k;
      binLeft -= k;
      data += k;
      n -= k;
      if (!binLeft) {
        hooks.binDone(binFor);
        hooks.reply("OK");
      }
      continue;
    }
    char c = (char)*data++;
    n--;
    if (c == '\n') {
      line[lineLen] = 0;
      if (lineLen && line[lineLen - 1] == '\r') line[lineLen - 1] = 0;
      handle(line);
      lineLen = 0;
    } else if (lineLen < sizeof line - 1) line[lineLen++] = c;
  }
}
