// Raspi-TV Displays – Zeilenprotokoll vom Pi (ohne Hardware, auch am PC testbar)
//   S key=value<TAB>key=value…   Zustand (siehe applyKey)
//   C <Bytes>\n + Daten           Albumcover 240×240 RGB565 (Little Endian)
//   F <Display> <Bytes>\n + Daten Testbild für Display 1/2 (15 s oder bis R)
//   R <Display>                   Testbild beenden
//   I                             Startanimation zeigen
//   P <Hz>                        SPI-Takt der Displays
//   B                             in den Bootloader (Firmware-Update)
//   V <links> <rechts>            Tonpegel 0…100 für die VU-Meter (ohne Antwort)
//   O reboot|off                  Neustart- bzw. Ausschalt-Animation (Pi fährt herunter)
//   ?                             Version melden
#pragma once
#include <stddef.h>
#include <stdint.h>
#include "ui.h"

struct ProtoHooks {
  void (*reply)(const char *text);
  uint8_t *(*binTarget)(int which, size_t bytes);   // which: -1 = Cover, 0/1 = Testbild
  void (*binDone)(int which);
  void (*release)(int display);
  void (*intro)();
  void (*speed)(uint32_t hz);
  void (*bootloader)();
  void (*hello)();
};

class Proto {
 public:
  State *st = nullptr;
  ProtoHooks hooks{};
  uint32_t (*now)() = nullptr;
  void feed(const uint8_t *data, size_t n);
  bool receiving(int which) const { return binLeft && binFor == which; }

 private:
  char line[1024];
  size_t lineLen = 0;
  uint8_t *binDst = nullptr;
  size_t binLeft = 0;
  int binFor = -1;
  bool hasMs = false;
  void handle(char *s);
  void apply(const char *k, const char *v);
};
