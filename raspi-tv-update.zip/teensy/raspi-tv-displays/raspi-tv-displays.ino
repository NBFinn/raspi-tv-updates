// Raspi-TV Displays – Firmware für Teensy 4.1
//
// Steuert die beiden runden GC9A01-Displays (240×240) mit eigener Grafik und Animationen
// (bis ~30 Bilder/s pro Display über DMA). Der Raspberry Pi schickt nur noch den Zustand
// (Uhrzeit, Musik, Lautstärke, WLAN, Updates, Farben) per USB; gezeichnet wird hier.
//
// Verdrahtung (siehe teensy/README.md):
//   Display 1 (Uhr/Cover, WLAN, System):     SCL→13  SDA→11  CS→10  DC→9  RST→8  (BL→6, falls vorhanden)
//   Display 2 (Lautstärke, Status, Updates): SCL→27  SDA→26  CS→0   DC→2  RST→3  (BL→7, falls vorhanden)
//   VCC→3.3V, GND→GND (beide Displays)
//
// Bauen: Arduino IDE + Teensyduino (Board „Teensy 4.1“, USB Type „Serial“) – keine weitere Bibliothek nötig,
// der Display-Treiber GC9A01A_t3n liegt unter src/. Oder `make` im Ordner teensy/ (siehe Makefile). Der Raspberry Pi spielt die Firmware selbst ein.

#include <Arduino.h>
#include <SPI.h>
#include "src/GC9A01A_t3n/GC9A01A_t3n.h"   // mitgeliefert (KurtE, MIT)
#include "gfx.h"
#include "ui.h"
#include "proto.h"

#define FW_VERSION "1.0.3"

static const uint8_t PIN_BL[2] = {6, 7};
GC9A01A_t3n tft[2] = {GC9A01A_t3n(10, 9, 8, 11, 13), GC9A01A_t3n(0, 2, 3, 26, 27)};

DMAMEM static uint16_t fb[2][W * H] __attribute__((aligned(32)));
DMAMEM static uint16_t cover[W * H] __attribute__((aligned(32)));
static uint16_t prevb[2][W * H];

static Canvas canvas[2];
static Screen screen[2];
static Rotation rot[2];
static PageRules rules;
static State st;
static Pal pal;
static Proto proto;
static uint32_t introAt = 1;            // Startanimation beim Einschalten
static uint32_t spiHz = 30000000;
static uint32_t rawUntil[2] = {0, 0};   // Testbild vom Pi steht

static void startDisplay(int d) {
  tft[d].begin(spiHz);
  tft[d].setRotation(0);
  tft[d].setFrameBuffer(fb[d]);
  tft[d].useFrameBuffer(true);
}

static uint32_t resetCause = 0;
static void hello() {
  Serial.print("HELLO raspi-tv-displays " FW_VERSION " spi=");
  Serial.print(spiHz);
  Serial.print(" up=");
  Serial.print(millis());
  Serial.print(" reset=0x");
  Serial.println(resetCause, HEX);
  // Absturzbericht einmal an den Pi schicken, sobald er zuhört (landet im Systemprotokoll)
  static bool crashSent = false;
  if (!crashSent && Serial.dtr() && CrashReport) {
    crashSent = true;
    Serial.print("CRASH ");
    Serial.println(CrashReport);
  }
}

static void reply(const char *t) { Serial.println(t); }
static uint8_t *binTarget(int which, size_t) {
  if (which < 0) return (uint8_t *)cover;
  tft[which].waitUpdateAsyncComplete();
  return (uint8_t *)fb[which];
}
static void binDone(int which) {
  if (which < 0) { st.hasCover = true; return; }
  rawUntil[which] = millis() + 15000;
  tft[which].updateScreenAsync();
}
static void release(int d) { rawUntil[d] = 0; }
static void intro() { introAt = millis() | 1; }
static void speed(uint32_t hz) {
  hz = constrain(hz, 4000000u, 80000000u);
  if (hz == spiHz) return;
  spiHz = hz;
  for (int d = 0; d < 2; d++) {
    tft[d].waitUpdateAsyncComplete();
    startDisplay(d);
  }
}
static void bootloader() {
  Serial.flush();
  delay(50);
  _reboot_Teensyduino_();
}
static uint32_t nowMs() { return millis(); }

void setup() {
  for (int d = 0; d < 2; d++) {
    pinMode(PIN_BL[d], OUTPUT);
    analogWriteFrequency(PIN_BL[d], 20000);
    analogWrite(PIN_BL[d], 255);
    startDisplay(d);
    canvas[d].bind(fb[d]);
    screen[d].which = d;
    screen[d].prev = prevb[d];
  }
  pal = makePal(st.accent, st.bg);
  proto.st = &st;
  proto.now = nowMs;
  proto.hooks = ProtoHooks{reply, binTarget, binDone, release, intro, speed, bootloader, hello};
  resetCause = SRC_SRSR;          // Grund des letzten Neustarts (Strom, Watchdog, Absturz …)
  SRC_SRSR = resetCause;          // Bits löschen (write-1-to-clear)
  Serial.begin(115200);
  rot[0].start = rot[1].start = millis();
  hello();
}

void loop() {
  static uint8_t buf[4096];
  int n = Serial.available();
  while (n > 0) {
    int k = Serial.readBytes((char *)buf, n < (int)sizeof buf ? n : (int)sizeof buf);
    proto.feed(buf, k);
    n = Serial.available();
  }
  uint32_t now = millis();
  rules.apply(st, rot, now);
  pal = blendPal(pal, makePal(st.accent, st.bg), .06f);
  // Helligkeit per Software: funktioniert auch bei Displays ohne BL-Pin (BL bleibt dann voll an)
  float level = st.brightness / 100.f;
  for (int d = 0; d < 2; d++) {
    if (rawUntil[d] && (int32_t)(now - rawUntil[d]) < 0) continue;
    rawUntil[d] = 0;
    if (proto.receiving(d)) continue;
    if (tft[d].asyncUpdateActive()) continue;   // DMA sendet noch das letzte Bild
    screen[d].frame(canvas[d], st, pal, rot[d], now, introAt, cover, 0, level);
    tft[d].updateScreenAsync();
  }
  if (introAt && now - introAt > INTRO_MS + 1000) introAt = 0;
  static uint32_t helloAt = 0;
  if (!st.ever && now - helloAt > 2000) {   // bis der Pi Daten schickt, regelmäßig melden
    helloAt = now;
    hello();
  }
}
