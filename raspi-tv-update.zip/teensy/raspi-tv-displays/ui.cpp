#include "ui.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static const Col WHITE = rgb(255, 255, 255);
static const Col BRAND_A = rgb(139, 92, 246), BRAND_B = rgb(61, 123, 255), BRAND_C = rgb(34, 211, 238);
static const float PI_F = 3.14159265f;

static Col brand(float t) {
  t = clamp01(t);
  return t < .5f ? mix(BRAND_A, BRAND_B, t * 2) : mix(BRAND_B, BRAND_C, (t - .5f) * 2);
}

Pal makePal(Col a, Col base) {
  if (a.r + a.g + a.b < 300) a = mix(a, WHITE, .35f);   // dunkle Akzente aufhellen
  Col bg = mix(mix(base, rgb(4, 7, 13), .5f), a, .06f);
  Pal p;
  p.accent = a;
  p.bg = bg;
  p.track = mix(bg, a, .2f);
  p.line = mix(bg, a, .42f);
  p.tick = mix(rgb(150, 165, 185), a, .45f);
  p.label = mix(rgb(200, 212, 226), a, .22f);
  p.muted = mix(rgb(142, 157, 178), a, .18f);
  p.hand = mix(WHITE, a, .2f);
  p.light = mix(a, WHITE, .45f);
  p.text = rgb(239, 249, 255);
  p.warn = rgb(255, 184, 92);
  p.bad = rgb(242, 134, 149);
  return p;
}

Pal blendPal(const Pal &a, const Pal &b, float t) {
  Pal r;
  const Col *x = &a.accent, *y = &b.accent;
  Col *z = &r.accent;
  for (int i = 0; i < 12; i++) z[i] = mix(x[i], y[i], t);
  return r;
}

// ---------------------------------------------------------------- Hilfen
static void label(Canvas &c, const char *s, float y, Col col, float a = 1) { c.text(F_LABEL, s, 120, y, col, 1, a); }

static void ringTrack(Canvas &c, const Pal &p) { c.arc(120, 120, 112, 16, 135, 405, solid(p.track), 1, true); }

// Fortschrittsring mit Verlauf und leuchtender Spitze
static void ringValue(Canvas &c, const Pal &p, float v, bool warn, float t) {
  if (v <= 0.2f) return;
  float end = 135 + 270 * clamp01(v / 100);
  Grad g = warn ? solid(p.warn) : grad(p.accent, p.light);
  c.arc(120, 120, 112, 16, 135, end, g, 1, true);
  float a = end * PI_F / 180, tx = 120 + 104 * cosf(a), ty = 120 + 104 * sinf(a);
  c.glow(tx, ty, 18, warn ? p.warn : p.light, .35f + .15f * sinf(t * 3));
  c.disc(tx, ty, 4.2f, WHITE, .85f);
}

// langsam wandernder Lichtschein im Hintergrund (lebendiges Glas)
static void ambience(Canvas &c, const Pal &p, float t, bool motion) {
  if (!motion) return;
  float x = 120 + 46 * sinf(t * .23f), y = 120 + 40 * cosf(t * .31f);
  c.glow(x, y, 150, p.accent, .10f);
  float x2 = 120 + 60 * cosf(t * .17f + 2), y2 = 120 + 55 * sinf(t * .21f + 1);
  c.glow(x2, y2, 120, p.light, .05f);
}

static void fmtInt(char *b, int v, const char *suffix) {
  if (v < 0) snprintf(b, 16, "--");
  else snprintf(b, 16, "%d%s", v, suffix);
}

// ---------------------------------------------------------------- Display 1
static void drawClock(Canvas &c, const State &s, const Pal &p, uint32_t now, float k, bool motion) {
  int64_t sec = s.epoch + (s.ever ? (int64_t)((now - s.epochAt) / 1000) : 0);
  float frac = s.ever ? ((now - s.epochAt) % 1000) / 1000.f : 0;
  if (!motion) frac = 0;
  int hh = (int)((sec / 3600) % 24), mm = (int)((sec / 60) % 60);
  float ss = (float)(sec % 60) + frac;
  float t = now / 1000.f;
  ambience(c, p, t, motion);
  // Minutenstriche: leuchten kurz nach, wenn der Sekundenzeiger vorbeikommt
  for (int i = 0; i < 60; i++) {
    float a = (i / 60.f) * 2 * PI_F - PI_F / 2;
    float behind = fmodf(ss - i + 60, 60);
    float lit = motion ? clamp01(1 - behind / 6) : 0;
    bool big = i % 5 == 0;
    float r0 = big ? 96 : 101, r1 = 108;
    Col col = mix(big ? p.tick : p.track, p.light, lit);
    c.line(120 + r0 * cosf(a), 120 + r0 * sinf(a), 120 + r1 * cosf(a), 120 + r1 * sinf(a), big ? 3 : 1.6f, col);
  }
  float ke = easeBack(k);
  float ah = ((hh % 12) + mm / 60.f) / 12 * 2 * PI_F * ke - PI_F / 2;
  float am = (mm + ss / 60) / 60 * 2 * PI_F * ke - PI_F / 2;
  float as = ss / 60 * 2 * PI_F * ke - PI_F / 2;
  c.line(120, 120, 120 + 52 * cosf(ah), 120 + 52 * sinf(ah), 7, p.hand);
  c.line(120, 120, 120 + 80 * cosf(am), 120 + 80 * sinf(am), 4, p.hand);
  c.line(120 - 16 * cosf(as), 120 - 16 * sinf(as), 120 + 90 * cosf(as), 120 + 90 * sinf(as), 2, p.accent);
  c.glow(120 + 90 * cosf(as), 120 + 90 * sinf(as), 12, p.accent, .5f);
  c.disc(120, 120, 6, p.accent);
  c.disc(120, 120, 2.5f, p.bg);
  char d[24];
  int64_t days = sec / 86400;
  // Datum aus Tagen seit 1970 (Gregorianisch)
  int64_t z = days + 719468, era = (z >= 0 ? z : z - 146096) / 146097;
  unsigned doe = (unsigned)(z - era * 146097), yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
  unsigned doy = doe - (365 * yoe + yoe / 4 - yoe / 100), mp = (5 * doy + 2) / 153;
  unsigned dd = doy - (153 * mp + 2) / 5 + 1, mo = mp < 10 ? mp + 3 : mp - 9;
  snprintf(d, sizeof d, "%02u.%02u.", dd, mo);
  c.text(F_TEXT, d, 120, 172, p.label, 1, k);
}

static void drawAlbum(Canvas &c, const State &s, const Pal &p, uint32_t now, float k, const uint16_t *cover,
                      float angle, bool motion) {
  float t = now / 1000.f;
  if (cover) {
    c.image(cover, 120, 120, 120, 1);
  } else {
    c.disc(120, 120, 102, p.track);
    c.text(F_BIG, "\xE2\x99\xAA", 120, 130, p.accent);   // Note (Ersatzzeichen „?“, wenn nicht in der Schrift)
  }
  // Infoleiste unten
  for (int y = 150; y < 240; y++) {
    float a = clamp01((y - 150) / 30.f) * .82f;
    for (int x = 0; x < 240; x++) c.blend(x, y, rgb(3, 6, 12), a);
  }
  c.textFit(F_MID, s.title[0] ? s.title : s.source, 120, 184, p.text, 176, k);
  c.textFit(F_TEXT, s.artist, 120, 204, p.label, 150, k);
  bool playing = s.playing && !(s.paused && !s.playing);
  // Equalizer-Balken rund um das Cover
  if (playing && motion) {
    for (int i = 0; i < 48; i++) {
      float a = i / 48.f * 2 * PI_F;
      float h = 3 + 7 * (.5f + .5f * sinf(t * (4.7f + (i % 7) * .9f) + i * 1.3f)) * (.6f + .4f * sinf(t * 2.1f + i));
      c.line(120 + (116 - h) * cosf(a), 120 + (116 - h) * sinf(a), 120 + 117 * cosf(a), 120 + 117 * sinf(a), 2.6f,
             mix(p.accent, p.light, (float)i / 48), .9f);
    }
  }
  c.text(F_SMALL, playing ? s.source : "PAUSE", 120, 224, p.accent, 1, k);
  (void)angle;
}

static void drawWlan(Canvas &c, const State &s, const Pal &p, uint32_t now, float k, float shownSig, bool motion) {
  float t = now / 1000.f;
  ambience(c, p, t, motion);
  ringTrack(c, p);
  if (s.info.wlan) {
    ringValue(c, p, shownSig * easeOut(k), s.info.signal >= 0 && s.info.signal < 40, t);
    // WLAN-Wellen, die nacheinander aufleuchten
    for (int i = 0; i < 3; i++) {
      float ph = motion ? clamp01(.5f + .5f * sinf(t * 2.4f - i * .9f)) : 1;
      c.arc(120, 74, 12 + i * 10, 4, 225, 315, solid(mix(p.track, p.accent, .35f + .65f * ph)), k, true);
    }
    c.disc(120, 72, 3.5f, p.accent, k);
    char b[16];
    fmtInt(b, s.info.signal < 0 ? -1 : (int)roundf(shownSig * easeOut(k)), " %");
    c.text(F_BIG, b, 120, 128, p.text, 1, k);
    c.textFit(F_TEXT, s.info.ssid[0] ? s.info.ssid : "verbunden", 120, 158, p.muted, 150, k);
    c.text(F_SMALL, "WLAN-Signal", 120, 180, p.muted, 1, k);
  } else {
    c.text(F_LABEL, "WLAN", 120, 70, p.label, 1, k);
    c.text(F_MID, "Kein WLAN", 120, 122, p.bad, 1, k);
    c.text(F_SMALL, "evtl. per Kabel online", 120, 150, p.muted, 1, k);
  }
}

static void drawSystem(Canvas &c, const State &s, const Pal &p, uint32_t now, float k, float shownCpu, bool motion) {
  float t = now / 1000.f;
  ambience(c, p, t, motion);
  ringTrack(c, p);
  ringValue(c, p, shownCpu * easeOut(k), s.info.cpu >= 80, t);
  label(c, "CPU", 66, p.label, k);
  char b[40];
  fmtInt(b, s.info.cpu < 0 ? -1 : (int)roundf(shownCpu * easeOut(k)), " %");
  c.text(F_BIG, b, 120, 118, p.text, 1, k);
  if (s.info.temp >= 0) snprintf(b, sizeof b, "Temperatur %d \xC2\xB0" "C", s.info.temp);
  else snprintf(b, sizeof b, "Temperatur --");
  c.text(F_TEXT, b, 120, 150, s.info.temp >= 70 ? p.warn : p.muted, 1, k);
  if (s.info.ram >= 0) snprintf(b, sizeof b, "Speicher %d %%", s.info.ram);
  else snprintf(b, sizeof b, "Speicher --");
  c.text(F_TEXT, b, 120, 172, p.muted, 1, k);
}

// ---------------------------------------------------------------- Display 2
static void drawVolume(Canvas &c, const State &s, const Pal &p, uint32_t now, float k, float shownVol, bool fresh,
                       bool motion) {
  float t = now / 1000.f;
  ambience(c, p, t, motion);
  ringTrack(c, p);
  bool known = fresh && s.volume >= 0;
  if (known && !s.muted) ringValue(c, p, shownVol * easeOut(k), shownVol >= 85, t);
  label(c, "LAUTST\xC3\x84RKE", 62, p.label, k);
  char b[16];
  if (s.muted && fresh) c.text(F_BIG, "STUMM", 120, 128, p.bad, 1, k);
  else {
    fmtInt(b, known ? (int)roundf(shownVol * easeOut(k)) : -1, "");
    c.text(F_NUM, b, 120, 142, p.text, 1, k);
  }
  const char *tgt = strcmp(s.target, "pi") == 0 ? "Pi" : "TV / Soundbar";
  c.text(F_TEXT, tgt, 120, 176, p.muted, 1, k);
  c.text(F_SMALL, s.muted && fresh ? "Ton aus" : known ? "%" : "kein R\xC3\xBC" "ckmeldewert", 120, 196, p.muted, 1, k);
}

static void checkMark(Canvas &c, Col col, float k, float cx, float cy, float sc, float width) {
  float x0 = cx - 23 * sc, y0 = cy + 1 * sc, x1 = cx - 6 * sc, y1 = cy + 18 * sc, x2 = cx + 26 * sc, y2 = cy - 19 * sc;
  float a = clamp01(k * 2.2f), b = clamp01(k * 2.2f - 1);
  if (a > 0) c.line(x0, y0, x0 + (x1 - x0) * a, y0 + (y1 - y0) * a, width, col);
  if (b > 0) c.line(x1, y1, x1 + (x2 - x1) * b, y1 + (y2 - y1) * b, width, col);
}

static void wrapLines(Canvas &c, const char *s, float y0, Col col, float k) {
  // einfacher Zeilenumbruch nach Wörtern (max. 5 Zeilen à ~170 px)
  char line[96] = "", word[64];
  int lines = 0;
  const char *p = s;
  while (*p && lines < 5) {
    int n = 0;
    while (*p == ' ') p++;
    while (*p && *p != ' ' && n < 62) word[n++] = *p++;
    word[n] = 0;
    char test[200];
    snprintf(test, sizeof test, "%s%s%s", line, line[0] ? " " : "", word);
    if (c.textWidth(F_TEXT, test) > 170 && line[0]) {
      c.text(F_TEXT, line, 120, y0 + lines * 22, col, 1, k);
      lines++;
      snprintf(line, sizeof line, "%s", word);
    } else {
      strncpy(line, test, sizeof line - 1);
      line[sizeof line - 1] = 0;
    }
  }
  if (line[0] && lines < 5) c.text(F_TEXT, line, 120, y0 + lines * 22, col, 1, k);
}

static void drawStatus(Canvas &c, const State &s, const Pal &p, uint32_t now, float k, bool motion) {
  float t = now / 1000.f;
  ambience(c, p, t, motion);
  if (!s.info.nerr) {
    c.arc(120, 120, 112, 4, 0, 360, solid(p.line), 1, false);
    if (motion) {   // umlaufender Lichtpunkt
      float a = fmodf(t * 60, 360);
      c.arc(120, 120, 113, 6, a, a + 50, grad(p.bg, p.light), .9f, false);
    }
    label(c, "STATUS", 66, p.label, k);
    c.glow(120, 112, 46, p.accent, .25f * k);
    checkMark(c, p.accent, k, 120, 110, 1, 9);
    c.text(F_LABEL, "Keine Fehler", 120, 164, p.hand, 1, k);
    return;
  }
  float pulse = motion ? .7f + .3f * sinf(t * 4) : 1;
  c.arc(120, 120, 112, 4, 0, 360, solid(p.bad), pulse, false);
  char b[24];
  if (s.info.nerr == 1) snprintf(b, sizeof b, "FEHLER");
  else snprintf(b, sizeof b, "%d FEHLER", s.info.nerr);
  label(c, b, 56, p.bad, k);
  wrapLines(c, s.info.errors[0], 90, p.text, k);
}

static void drawUpdate(Canvas &c, const State &s, const Pal &p, uint32_t now, float k, float shownProg, bool motion) {
  float t = now / 1000.f;
  ambience(c, p, t, motion);
  const Upd &u = s.upd;
  label(c, "UPDATES", 56, p.label, k);
  if (u.running) {
    int a = 0, b = 0;
    const char *sl = strchr(u.step, '/');
    if (sl) {
      const char *q = sl;
      while (q > u.step && q[-1] >= '0' && q[-1] <= '9') q--;
      a = atoi(q);
      b = atoi(sl + 1);
    }
    if (b > 0) {
      ringTrack(c, p);
      ringValue(c, p, shownProg, false, t);
      char pc[16];
      snprintf(pc, sizeof pc, "%d %%", (int)roundf(shownProg));
      c.text(F_BIG, pc, 120, 116, p.text, 1, k);
      c.text(F_TEXT, strncmp(u.step, "Systemupdates", 13) == 0 ? "Systemupdates" : "Installation", 120, 142, p.label, 1, k);
      char line[40];
      snprintf(line, sizeof line, "%d von %d Paketen", a, b);
      c.text(F_SMALL, line, 120, 164, p.muted, 1, k);
    } else {
      c.arc(120, 120, 112, 12, 0, 360, solid(p.track), 1, false);
      float st = fmodf(t * 220, 360);
      c.arc(120, 120, 112, 12, st, st + 120, grad(p.track, p.accent), 1, true);
      c.text(F_MID, "Wird", 120, 104, p.text, 1, k);
      c.text(F_MID, "installiert \xE2\x80\xA6", 120, 130, p.text, 1, k);
      c.textFit(F_SMALL, u.step, 120, 156, p.muted, 160, k);
    }
    c.text(F_SMALL, "Nicht ausschalten", 120, 182, p.warn, 1, k);
    return;
  }
  ringTrack(c, p);
  if (u.newer) {
    ringValue(c, p, 100 * easeOut(k), false, t);
    float pulse = motion ? .7f + .3f * sinf(t * 3) : 1;
    c.text(F_LABEL, "NEU", 120, 84, mix(p.bg, p.warn, pulse), 1, k);
    c.text(F_BIG, u.latest, 120, 124, p.text, 1, k);
    char line[40];
    snprintf(line, sizeof line, "installiert: %s", u.installed);
    c.text(F_SMALL, line, 120, 148, p.muted, 1, k);
    c.text(F_SMALL, u.autoInst ? "kommt heute Nacht" : "in den Einstellungen installieren", 120, 168, p.label, 1, k);
    return;
  }
  ringValue(c, p, 100 * easeOut(k), false, t);
  c.text(F_BIG, u.installed[0] ? u.installed : "?", 120, 112, p.text, 1, k);
  if (!u.online) {
    c.text(F_TEXT, "Online-Update aus", 120, 146, p.muted, 1, k);
  } else if (u.error) {
    c.text(F_TEXT, "Server nicht", 120, 142, p.warn, 1, k);
    c.text(F_TEXT, "erreichbar", 120, 160, p.warn, 1, k);
  } else {
    checkMark(c, p.accent, k, 120, 138, .55f, 5);
    c.text(F_TEXT, "Aktuell", 120, 170, p.hand, 1, k);
  }
  if (u.checkedMin >= 0) {
    char line[40];
    if (u.checkedMin < 2) snprintf(line, sizeof line, "gepr\xC3\xBC" "ft gerade eben");
    else if (u.checkedMin < 90) snprintf(line, sizeof line, "gepr\xC3\xBC" "ft vor %d Min.", u.checkedMin);
    else snprintf(line, sizeof line, "gepr\xC3\xBC" "ft vor %d Std.", u.checkedMin / 60);
    c.text(F_SMALL, line, 120, 192, p.muted, 1, k);
  }
}

// ---------------------------------------------------------------- Start und Warten
static float sq(float v) { return v * v; }

// Superellipse (Logo-Bildschirm), Wert < 0 innen, ≈ Abstand in Pixeln
static float squircle(float x, float y, float cx, float cy, float r) {
  float u = fabsf(x - cx) / r, v = fabsf(y - cy) / r;
  return (powf(u * u * u * u + v * v * v * v, .25f) - 1) * r;
}

void drawIntroLogo(Canvas &c, float t, Col bg) {
  c.clear(bg);
  const float cx = 120, cy = 100, r = 58;
  float glow = easeOut((t - .2f) / 1.2f);
  if (glow > 0) c.glow(cx, cy, r + 60, BRAND_B, .32f * glow);
  // Rahmen zeichnet sich (im Uhrzeigersinn ab oben)
  float draw = easeOut(t / .9f);
  float fill = easeOut((t - .85f) / .45f);
  float cut = cy + r - fill * 2 * r;   // Füllung steigt von unten
  for (int y = (int)(cy - r - 4); y <= (int)(cy + r + 4); y++)
    for (int x = (int)(cx - r - 4); x <= (int)(cx + r + 4); x++) {
      float px = x + .5f, py = y + .5f;
      float d = squircle(px, py, cx, cy, r);
      Col col = brand(((px - cx) + (py - cy) + 2 * r) / (4 * r));
      if (fill > 0 && py >= cut) c.blend(x, y, col, clamp01(.5f - d) * clamp01(py - cut + .5f));
      if (draw > 0) {
        float ang = fastAtan2(py - cy, px - cx) + PI_F / 2;
        if (ang < 0) ang += 2 * PI_F;
        float shown = draw * 2 * PI_F;
        if (ang <= shown) c.blend(x, y, col, clamp01(2.6f - fabsf(d)));
      }
    }
  float pop = t > 1.1f ? easeBack((t - 1.1f) / .5f) : 0;
  if (pop > 0) {
    float k = pop;
    c.triangle(cx + 5 - 14 * k, cy + 2 - 23 * k, cx + 5 - 14 * k, cy + 2 + 23 * k, cx + 5 + 25 * k, cy + 2, WHITE);
  }
  for (int i = 0; i < 2; i++) {
    float a = easeOut((t - 1.5f - i * .15f) / .3f);
    if (a > 0) c.arc(cx + 16, cy - 14, 12 + i * 10 + 2.5f, 5, -60, -18, solid(mix(BRAND_B, WHITE, .85f)), a, true);
  }
  // Schriftzug „Raspi TV“ Buchstabe für Buchstabe
  const char *word = "Raspi TV";
  float total = c.textWidth(F_WORD, word), x = 120 - total / 2;
  char ch[2] = {0, 0};
  for (int i = 0; word[i]; i++) {
    ch[0] = word[i];
    float w = c.textWidth(F_WORD, ch);
    float a = easeOut((t - 1.75f - i * .07f) / .35f);
    if (a > 0 && word[i] != ' ') {
      Col col = i >= 6 ? brand(.4f + .6f * (i - 6)) : WHITE;
      c.text(F_WORD, ch, x, 208 + 8 * (1 - a), col, 0, a);
    }
    x += w;
  }
}

void drawIntroRing(Canvas &c, float t, const char *version, Col bg) {
  c.clear(bg);
  float track = easeOut(t / .4f);
  c.arc(120, 120, 112, 16, 135, 135 + 270 * track, solid(rgb(40, 52, 78)), 1, true);
  float sweep = easeInOut((t - .35f) / 1.6f);
  if (sweep > 0) {
    float end = 135 + 270 * sweep;
    c.arc(120, 120, 112, 16, 135, end, grad(BRAND_A, BRAND_C), 1, true);
    float a = end * PI_F / 180;
    c.glow(120 + 104 * cosf(a), 120 + 104 * sinf(a), 24, mix(brand(sweep), WHITE, .3f), .55f);
    c.disc(120 + 104 * cosf(a), 120 + 104 * sinf(a), 5, WHITE, .9f);
  }
  float a = easeOut((t - .5f) / .5f);
  if (a > 0) c.text(F_LABEL, "RASPI-TV", 120, 70, rgb(170, 190, 212), 1, a);
  if (t < 2.2f) {
    char b[8];
    snprintf(b, sizeof b, "%d", (int)(100 * sweep));
    if (a > 0) c.text(F_NUM, b, 120, 140, rgb(239, 249, 255), 1, a);
  } else {
    float b = easeOut((t - 2.2f) / .4f);
    c.glow(120, 112, 60, BRAND_C, .25f * b);
    c.text(F_BIG, "Bereit", 120, 130, rgb(239, 249, 255), 1, b);
  }
  if (version && version[0] && a > 0) {
    char v[32];
    snprintf(v, sizeof v, "Version %s", version);
    c.text(F_SMALL, v, 120, 178, rgb(133, 155, 181), 1, a);
  }
}

void drawWait(Canvas &c, const Pal &p, float t, int which) {
  if (which == 0) {
    drawIntroLogo(c, 9, p.bg);
    c.text(F_SMALL, "startet \xE2\x80\xA6", 120, 228, p.muted, 1, .6f + .4f * sinf(t * 3));
    return;
  }
  c.clear(p.bg);
  c.arc(120, 120, 112, 10, 0, 360, solid(p.track), 1, false);
  float st = fmodf(t * 240, 360);
  c.arc(120, 120, 112, 10, st, st + 100, grad(p.bg, p.accent), 1, true);
  c.text(F_MID, "Einen", 120, 112, p.label, 1);
  c.text(F_MID, "Moment \xE2\x80\xA6", 120, 138, p.label, 1);
}


// ---------------------------------------------------------------- Neustart, Ausschalten, Standby
static void drawLogoAt(Canvas &c, float cx, float cy, float r, float alpha) {
  for (int y = (int)(cy - r - 2); y <= (int)(cy + r + 2); y++)
    for (int x = (int)(cx - r - 2); x <= (int)(cx + r + 2); x++) {
      float px = x + .5f, py = y + .5f;
      float u = fabsf(px - cx) / r, v = fabsf(py - cy) / r;
      float d = (powf(u * u * u * u + v * v * v * v, .25f) - 1) * r;
      if (d < 1) c.blend(x, y, brand(((px - cx) + (py - cy) + 2 * r) / (4 * r)), alpha * clamp01(.5f - d));
    }
  float k = r / 58;
  c.triangle(cx + 5 * k - 14 * k, cy + 2 * k - 23 * k, cx + 5 * k - 14 * k, cy + 2 * k + 23 * k, cx + 5 * k + 25 * k,
             cy + 2 * k, WHITE, alpha);
}

void drawRestart(Canvas &c, const Pal &p, float t, int which) {
  c.clear(p.bg);
  if (which == 0) {
    c.glow(120, 110, 110, BRAND_B, .25f + .1f * sinf(t * 2));
    drawLogoAt(c, 120, 110, 44, 1);
    // kreisender Pfeil um das Logo
    float a = fmodf(t * 200, 360);
    c.arc(120, 110, 84, 6, a, a + 260, grad(mix(p.bg, BRAND_A, .3f), BRAND_C), 1, true);
    float e = (a + 260) * PI_F / 180, hx = 120 + 81 * cosf(e), hy = 110 + 81 * sinf(e);
    float tx = -sinf(e), ty = cosf(e);   // Laufrichtung
    c.triangle(hx + tx * 12, hy + ty * 12, hx - ty * 8, hy + tx * 8, hx + ty * 8, hy - tx * 8, BRAND_C);
    c.text(F_LABEL, "Neustart", 120, 222, p.label, 1, .7f + .3f * sinf(t * 3));
    return;
  }
  c.arc(120, 120, 112, 10, 0, 360, solid(p.track), 1, false);
  for (int i = 0; i < 3; i++) {
    float st = fmodf(t * (160 + i * 50) + i * 120, 360);
    c.arc(120, 120, 112 - i * 16, 6, st, st + 70, grad(p.bg, i == 1 ? BRAND_B : i == 2 ? BRAND_C : BRAND_A), 1, true);
  }
  c.text(F_MID, "Raspi-TV", 120, 112, p.text, 1);
  c.text(F_TEXT, "startet neu \xE2\x80\xA6", 120, 138, p.label, 1);
  c.text(F_SMALL, "gleich wieder da", 120, 162, p.muted, 1);
}

void drawGoodbye(Canvas &c, const Pal &p, float t, int which) {
  c.clear(rgb(0, 0, 0));
  float out = clamp01((t - 2.4f) / 1.2f);   // nach 2,4 s ausblenden
  float a = 1 - out;
  if (a <= 0) return;
  if (which == 0) {
    float k = 1 - .35f * easeInOut(t / 3.6f);
    c.glow(120, 104, 100 * k, BRAND_B, .3f * a);
    drawLogoAt(c, 120, 104, 52 * k, a);
    c.text(F_WORD, "Bis bald", 120, 210, mix(rgb(0, 0, 0), WHITE, a), 1);
    return;
  }
  float drain = 1 - easeInOut(t / 2.4f);
  if (drain > 0) c.arc(120, 120, 112, 14, 135, 135 + 270 * drain, grad(BRAND_A, BRAND_C), a, true);
  c.text(F_MID, "Gute Nacht", 120, 118, mix(rgb(0, 0, 0), p.text, a), 1);
  c.text(F_SMALL, "Raspi-TV f\xC3\xA4hrt herunter", 120, 144, mix(rgb(0, 0, 0), p.muted, a), 1);
}

void drawStandby(Canvas &c, const Pal &p, float t) {
  c.clear(rgb(2, 3, 6));
  // Mondsichel mit sanft funkelnden Sternen
  c.glow(120, 100, 70, p.accent, .12f);
  c.disc(120, 100, 34, mix(p.light, WHITE, .5f));
  c.disc(136, 90, 30, rgb(2, 3, 6));
  const float sx[6] = {62, 172, 84, 160, 190, 52}, sy[6] = {70, 60, 140, 150, 112, 120};
  for (int i = 0; i < 6; i++) c.disc(sx[i], sy[i], 1.8f, WHITE, .3f + .7f * (.5f + .5f * sinf(t * 1.5f + i * 1.7f)));
  c.text(F_LABEL, "Standby", 120, 176, p.label, 1);
  c.text(F_SMALL, "Taste dr\xC3\xBC" "cken zum Einschalten", 120, 198, p.muted, 1);
}

// ---------------------------------------------------------------- Seiten und Übergänge
// Übergänge: 0 = Wischen wie ein Uhrzeiger, 1 = Iris (Kreis wächst aus der Mitte), 2 = Schieben
static void transition(Canvas &c, const uint16_t *prev, int kind, float k) {
  const float soft = 10;
  for (int y = 0; y < H; y++)
    for (int x = 0; x < W; x++) {
      float dx = x + .5f - 120, dy = y + .5f - 120, keep;   // keep = Anteil altes Bild
      if (kind == 0) {
        float ang = fastAtan2(dy, dx) * 180 / PI_F + 90;
        if (ang < 0) ang += 360;
        keep = clamp01((ang - k * (360 + soft)) / soft + 1);
      } else if (kind == 1) {
        float d = sqrtf(dx * dx + dy * dy);
        keep = clamp01((d - k * (175 + soft)) / soft + 1);
      } else {
        int sx = x + (int)(k * 240);
        if (x >= (1 - k) * 240) continue;   // neues Bild rechts
        keep = 1;
        c.px[y * W + x] = prev[y * W + (sx < 240 ? sx : 239)];
        continue;
      }
      if (keep >= 1) c.px[y * W + x] = prev[y * W + x];
      else if (keep > 0) c.blend(x, y, from565(prev[y * W + x]), keep);
    }
}

void Screen::frame(Canvas &c, const State &s, const Pal &p, Rotation &rot, uint32_t now, uint32_t introAt,
                   const uint16_t *cover, float coverAngle, float level) {
  bool fresh = s.ever && now - s.lastMs < STALE_MS;
  bool motion = s.motion;
  int want;
  if (s.mode == 1) want = -4;                                  // Neustart
  else if (s.mode == 2) want = -5;                             // Ausschalten
  else if (introAt && now - introAt < INTRO_MS) want = -2;
  else if (!s.ever && now < 90000) want = -3;
  else if (s.tvStandby && fresh && which == 1) want = -6;      // Fernseher aus: Standby-Bild
  else want = rot.page(now);
  if (want != page) {
    if (motion && page != -100 && prev) {
      memcpy(prev, c.px, sizeof(uint16_t) * W * H);
      transOn = true;
      transAt = now;
      transKind = (transKind + 1) % 3;
      if (page == -2 || want == -2) transKind = 1;
    }
    page = want;
    pageAt = now;
  }
  float k = motion ? clamp01((now - pageAt - 120) / 750.f) : 1;
  // weich nachgeführte Werte
  float target[4] = {(float)(s.volume < 0 ? 0 : s.volume), (float)(s.info.cpu < 0 ? 0 : s.info.cpu),
                     (float)(s.info.signal < 0 ? 0 : s.info.signal), 0};
  {
    const char *sl = strchr(s.upd.step, '/');
    if (s.upd.running && sl) {
      const char *q = sl;
      while (q > s.upd.step && q[-1] >= '0' && q[-1] <= '9') q--;
      int a = atoi(q), b = atoi(sl + 1);
      if (b > 0) target[3] = 100.f * a / b;
    }
  }
  for (int i = 0; i < 4; i++) {
    if (shown[i] < 0 || !motion) shown[i] = target[i];
    else shown[i] += (target[i] - shown[i]) * .18f;
  }
  if (page == -2) {
    float t = (now - introAt) / 1000.f;
    if (which == 0) drawIntroLogo(c, t, p.bg);
    else drawIntroRing(c, t, s.version, p.bg);
  } else if (page == -3) {
    drawWait(c, p, now / 1000.f, which);
  } else if (page == -4) {
    drawRestart(c, p, (now - s.modeAt) / 1000.f, which);
  } else if (page == -5) {
    drawGoodbye(c, p, (now - s.modeAt) / 1000.f, which);
  } else if (page == -6) {
    drawStandby(c, p, now / 1000.f);
  } else {
    c.clear(p.bg);
    if (which == 0) {
      bool music = fresh && (s.playing || s.paused) && s.title[0];
      if (page == 0) {
        if (music) drawAlbum(c, s, p, now, k, s.hasCover ? cover : nullptr, coverAngle, motion);
        else drawClock(c, s, p, now, k, motion);
      } else if (page == 1) drawWlan(c, s, p, now, k, shown[2], motion);
      else drawSystem(c, s, p, now, k, shown[1], motion);
    } else {
      if (page == 0) drawVolume(c, s, p, now, k, shown[0], fresh, motion);
      else if (page == 1) drawStatus(c, s, p, now, k, motion);
      else drawUpdate(c, s, p, now, k, shown[3], motion);
    }
  }
  if (s.tvStandby && fresh && page >= 0) level *= .35f;   // Nachtmodus bei ausgeschaltetem Fernseher
  c.dim(level);   // Helligkeit per Software (vor dem Übergang: das alte Bild ist schon abgedunkelt)
  if (transOn) {
    float tk = (now - transAt) / 520.f;
    if (tk >= 1) transOn = false;
    else transition(c, prev, transKind, easeInOut(tk));
  }
}

void PageRules::apply(const State &s, Rotation *rot, uint32_t now) {
  if (!(s.ever && now - s.lastMs < STALE_MS)) return;
  int volKey = s.volume * 4 + (s.muted ? 1 : 0) + (s.target[0] == 'p' ? 2 : 0);
  if (lastVol != -9999 && volKey != lastVol) rot[1].hold(0, now);
  lastVol = volKey;
  int updKey = (s.upd.newer ? 1 : 0) + (s.upd.running ? 2 : 0);
  if (s.upd.running) rot[1].hold(2, now);
  else if (lastUpd >= 0 && updKey != lastUpd && s.upd.newer) rot[1].hold(2, now);
  lastUpd = updKey;
}
