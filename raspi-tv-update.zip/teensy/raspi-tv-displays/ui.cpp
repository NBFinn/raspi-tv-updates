#include "ui.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static const Col WHITE = rgb(255, 255, 255);
static const Col BRAND_A = rgb(139, 92, 246), BRAND_B = rgb(61, 123, 255), BRAND_C = rgb(34, 211, 238);
static const float PI_F = 3.14159265f;
static const uint32_t NOTICE_MS = 7000;      // Hinweise vom Pi

static Col brand(float t) {
  t = clamp01(t);
  return t < .5f ? mix(BRAND_A, BRAND_B, t * 2) : mix(BRAND_B, BRAND_C, (t - .5f) * 2);
}

Pal makePal(Col a, Col base) {
  if (a.r + a.g + a.b < 300) a = mix(a, WHITE, .35f);   // dunkle Akzente aufhellen
  Col bg = mix(mix(base, rgb(4, 7, 13), .5f), a, .06f);
  Pal p;
  p.accent = a;
  p.bg = bg;
  p.track = mix(bg, a, .2f);
  p.line = mix(bg, a, .42f);
  p.tick = mix(rgb(150, 165, 185), a, .45f);
  p.label = mix(rgb(200, 212, 226), a, .22f);
  p.muted = mix(rgb(142, 157, 178), a, .18f);
  p.hand = mix(WHITE, a, .2f);
  p.light = mix(a, WHITE, .45f);
  p.text = rgb(239, 249, 255);
  p.warn = rgb(255, 184, 92);
  p.bad = rgb(242, 134, 149);
  return p;
}

Pal blendPal(const Pal &a, const Pal &b, float t) {
  Pal r;
  const Col *x = &a.accent, *y = &b.accent;
  Col *z = &r.accent;
  for (int i = 0; i < 12; i++) z[i] = mix(x[i], y[i], t);
  return r;
}

// ---------------------------------------------------------------- Hilfen
static void label(Canvas &c, const char *s, float y, Col col, float a = 1) { c.text(F_LABEL, s, 120, y, col, 1, a); }

static void ringTrack(Canvas &c, const Pal &p) { c.arc(120, 120, 112, 16, 135, 405, solid(p.track), 1, true); }

// Fortschrittsring mit Verlauf und leuchtender Spitze
static void ringValue(Canvas &c, const Pal &p, float v, bool warn, float t) {
  if (v <= 0.2f) return;
  float end = 135 + 270 * clamp01(v / 100);
  Grad g = warn ? solid(p.warn) : grad(p.accent, p.light);
  c.arc(120, 120, 112, 16, 135, end, g, 1, true);
  float a = end * PI_F / 180, tx = 120 + 104 * cosf(a), ty = 120 + 104 * sinf(a);
  c.glow(tx, ty, 18, warn ? p.warn : p.light, .35f + .15f * sinf(t * 3));
  c.disc(tx, ty, 4.2f, WHITE, .85f);
}

// langsam wandernder Lichtschein im Hintergrund (lebendiges Glas)
static void ambience(Canvas &c, const Pal &p, float t, bool motion) {
  if (!motion) return;
  float x = 120 + 46 * sinf(t * .23f), y = 120 + 40 * cosf(t * .31f);
  c.glow(x, y, 150, p.accent, .10f);
  float x2 = 120 + 60 * cosf(t * .17f + 2), y2 = 120 + 55 * sinf(t * .21f + 1);
  c.glow(x2, y2, 120, p.light, .05f);
}

static void fmtInt(char *b, int v, const char *suffix) {
  if (v < 0) snprintf(b, 16, "--");
  else snprintf(b, 16, "%d%s", v, suffix);
}

// Lauftext: passt der Text nicht, läuft er nach kurzer Pause endlos durch (sonst mittig)
static void marquee(Canvas &c, const Font &f, const char *s, float y, Col col, float maxW, float t, float alpha = 1) {
  float w = c.textWidth(f, s);
  if (w <= maxW) {
    c.text(f, s, 120, y, col, 1, alpha);
    return;
  }
  float period = w + 46;
  float off = fmodf((t > 1.4f ? t - 1.4f : 0) * 36, period);
  c.clipX0 = (int)(120 - maxW / 2);
  c.clipX1 = (int)(120 + maxW / 2);
  float x = 120 - maxW / 2 - off;
  c.text(f, s, x, y, col, 0, alpha);
  c.text(f, s, x + period, y, col, 0, alpha);
  c.clipX0 = 0;
  c.clipX1 = W;
}

// ---------------------------------------------------------------- Display 1
struct ClockTime {
  int hh, mm, sec;
  float ss;          // Sekunden mit Bruchteil
  char date[12];     // „13.11.“
  char hm[8];        // „22:14“
};

static ClockTime clockTime(const State &s, uint32_t now, bool motion) {
  ClockTime ct;
  int64_t ms = s.nowMs(now);
  int64_t sec = ms / 1000;
  float frac = motion ? (ms % 1000) / 1000.f : 0;
  ct.hh = (int)((sec / 3600) % 24);
  ct.mm = (int)((sec / 60) % 60);
  ct.sec = (int)(sec % 60);
  ct.ss = ct.sec + frac;
  // Datum aus Tagen seit 1970 (Gregorianisch)
  int64_t days = sec / 86400;
  int64_t z = days + 719468, era = (z >= 0 ? z : z - 146096) / 146097;
  unsigned doe = (unsigned)(z - era * 146097), yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
  unsigned doy = doe - (365 * yoe + yoe / 4 - yoe / 100), mp = (5 * doy + 2) / 153;
  unsigned dd = doy - (153 * mp + 2) / 5 + 1, mo = mp < 10 ? mp + 3 : mp - 9;
  snprintf(ct.date, sizeof ct.date, "%02u.%02u.", dd, mo);
  snprintf(ct.hm, sizeof ct.hm, "%02d:%02d", ct.hh, ct.mm);
  return ct;
}

// 0: analoges Zifferblatt
static void clockAnalog(Canvas &c, const ClockTime &ct, const Pal &p, float t, float k, bool motion) {
  ambience(c, p, t, motion);
  // Minutenstriche: leuchten kurz nach, wenn der Sekundenzeiger vorbeikommt
  for (int i = 0; i < 60; i++) {
    float a = (i / 60.f) * 2 * PI_F - PI_F / 2;
    float behind = fmodf(ct.ss - i + 60, 60);
    float lit = motion ? clamp01(1 - behind / 6) : 0;
    bool big = i % 5 == 0;
    float r0 = big ? 96 : 101, r1 = 108;
    Col col = mix(big ? p.tick : p.track, p.light, lit);
    c.line(120 + r0 * cosf(a), 120 + r0 * sinf(a), 120 + r1 * cosf(a), 120 + r1 * sinf(a), big ? 3 : 1.6f, col);
  }
  float ke = easeBack(k);
  float ah = ((ct.hh % 12) + ct.mm / 60.f) / 12 * 2 * PI_F * ke - PI_F / 2;
  float am = (ct.mm + ct.ss / 60) / 60 * 2 * PI_F * ke - PI_F / 2;
  float as = ct.ss / 60 * 2 * PI_F * ke - PI_F / 2;
  c.line(120, 120, 120 + 52 * cosf(ah), 120 + 52 * sinf(ah), 7, p.hand);
  c.line(120, 120, 120 + 80 * cosf(am), 120 + 80 * sinf(am), 4, p.hand);
  c.line(120 - 16 * cosf(as), 120 - 16 * sinf(as), 120 + 90 * cosf(as), 120 + 90 * sinf(as), 2, p.accent);
  c.glow(120 + 90 * cosf(as), 120 + 90 * sinf(as), 12, p.accent, .5f);
  c.disc(120, 120, 6, p.accent);
  c.disc(120, 120, 2.5f, p.bg);
  c.text(F_TEXT, ct.date, 120, 172, p.label, 1, k);
}

// 1: Radar – der Suchstrahl ist der Sekundenzeiger, Stunde und Minute sind Echos, die er aufleuchten lässt
static void clockRadar(Canvas &c, const ClockTime &ct, const Pal &p, float t, float k, bool motion) {
  (void)t;
  for (int i = 1; i <= 3; i++) c.arc(120, 120, 36 * i - 1, 1.4f, 0, 360, solid(p.track), 1, false);
  c.line(120, 14, 120, 226, 1, p.track, .8f);
  c.line(14, 120, 226, 120, 1, p.track, .8f);
  for (int i = 0; i < 12; i++) {
    float a = i / 12.f * 2 * PI_F;
    c.line(120 + 110 * cosf(a), 120 + 110 * sinf(a), 120 + 116 * cosf(a), 120 + 116 * sinf(a), 2, p.tick);
  }
  float beam = ct.ss * 6 - 90;                       // Grad, 0 = 3 Uhr
  if (motion) c.arc(120, 120, 54, 108, beam - 80, beam, grad(p.bg, p.accent), .8f * k, false);
  float br = beam * PI_F / 180;
  c.line(120, 120, 120 + 108 * cosf(br), 120 + 108 * sinf(br), 2, p.light, k);
  struct Echo { float deg, r; int value; } echo[2] = {
      {((ct.hh % 12) + ct.mm / 60.f) * 30 - 90, 56, ct.hh}, {(ct.mm + ct.ss / 60) * 6 - 90, 90, ct.mm}};
  for (int i = 0; i < 2; i++) {
    float behind = fmodf(beam - echo[i].deg + 720, 360) / 360;      // 0 = gerade überstrichen
    float lit = motion ? .35f + .65f * (1 - behind) * (1 - behind) : 1;
    float a = echo[i].deg * PI_F / 180, x = 120 + echo[i].r * cosf(a), y = 120 + echo[i].r * sinf(a);
    c.glow(x, y, 22, p.accent, .55f * lit * k);
    c.disc(x, y, i ? 5 : 7, mix(p.accent, WHITE, .5f * lit), k);
    char b[8];
    snprintf(b, sizeof b, "%02d", echo[i].value);
    float lx = 120 + (echo[i].r - 22) * cosf(a), ly = 120 + (echo[i].r - 22) * sinf(a);
    c.text(F_SMALL, b, lx, ly + 5, mix(p.muted, p.text, lit), 1, k);
  }
  c.disc(120, 120, 4, p.light);
  char line[24];
  snprintf(line, sizeof line, "%s    %s", ct.hm, ct.date);
  c.text(F_SMALL, line, 120, ct.mm >= 20 && ct.mm < 40 ? 38 : 212, p.label, 1, k);   // nicht unter dem Minuten-Echo
}

// Sieben-Segment-Ziffer (x,y = links oben), aus = schwach sichtbar wie bei einer alten Anzeige
static void sevenSeg(Canvas &c, int digit, float x, float y, float w, float h, float th, Col on, Col off, float alpha) {
  static const uint8_t MAP[10] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F};   // gfedcba
  uint8_t m = digit >= 0 && digit <= 9 ? MAP[digit] : 0;
  float g = th * .75f, x0 = x + g, x1 = x + w - g, ym = y + h / 2, y1 = y + h;
  float seg[7][4] = {{x0, y, x1, y}, {x + w, y + g, x + w, ym - g}, {x + w, ym + g, x + w, y1 - g}, {x0, y1, x1, y1},
                     {x, ym + g, x, y1 - g}, {x, y + g, x, ym - g}, {x0, ym, x1, ym}};
  for (int i = 0; i < 7; i++) {
    bool lit = m & (1 << i);
    c.line(seg[i][0], seg[i][1], seg[i][2], seg[i][3], th, lit ? on : off, lit ? alpha : alpha * .5f);
  }
}

// 2: Retro-Ziffern
static void clockRetro(Canvas &c, const ClockTime &ct, const Pal &p, float t, float k, bool motion) {
  (void)t;
  for (int i = 0; i < 60; i++) {                     // Sekundenkranz
    float a = i / 60.f * 2 * PI_F - PI_F / 2;
    bool lit = i <= ct.sec;
    float fresh = motion && i == ct.sec ? 1 - (ct.ss - ct.sec) : 0;
    c.disc(120 + 109 * cosf(a), 120 + 109 * sinf(a), i % 5 == 0 ? 3.2f : 2.1f, lit ? mix(p.accent, WHITE, fresh * .7f) : p.track);
  }
  const float w = 31, h = 60, th = 6.5f, gap = 10, colon = 18;
  float total = 4 * w + 2 * gap + colon + 2 * gap, x = 120 - total / 2, y = 88;
  Col off = mix(p.bg, p.accent, .13f);
  c.glow(120, 118, 96, p.accent, .16f * k);
  int d[4] = {ct.hh / 10, ct.hh % 10, ct.mm / 10, ct.mm % 10};
  for (int i = 0; i < 4; i++) {
    sevenSeg(c, d[i], x, y, w, h, th, p.light, off, k);
    x += w + gap;
    if (i == 1) {
      float blink = motion ? (ct.ss - ct.sec < .5f ? 1 : .25f) : 1;
      c.disc(x + colon / 2 - gap / 2, y + h * .3f, 4, p.light, blink * k);
      c.disc(x + colon / 2 - gap / 2, y + h * .7f, 4, p.light, blink * k);
      x += colon + gap;
    }
  }
  c.text(F_TEXT, ct.date, 120, 184, p.label, 1, k);
}

// 3: kreisende Punkte – Sekunde, Minute und Stunde ziehen auf drei Bahnen ihre Lichtspur
static void clockDots(Canvas &c, const ClockTime &ct, const Pal &p, float t, float k, bool motion) {
  ambience(c, p, t, motion);
  struct Orbit { float r, deg, size, tail; Col col; } o[3] = {
      {110, ct.ss * 6 - 90, 4.5f, 70, p.light},
      {94, (ct.mm + ct.ss / 60) * 6 - 90, 6, 100, p.accent},
      {78, ((ct.hh % 12) + ct.mm / 60.f) * 30 - 90, 7.5f, 130, mix(p.accent, WHITE, .25f)}};
  for (int i = 0; i < 3; i++) {
    c.arc(120, 120, o[i].r, 1.6f, 0, 360, solid(p.track), 1, false);
    c.arc(120, 120, o[i].r, o[i].size * .9f, o[i].deg - o[i].tail * k, o[i].deg, grad(p.bg, o[i].col), .9f, true);
    float a = o[i].deg * PI_F / 180, x = 120 + o[i].r * cosf(a), y = 120 + o[i].r * sinf(a);
    c.glow(x, y, o[i].size * 3.2f, o[i].col, .5f);
    c.disc(x, y, o[i].size, mix(o[i].col, WHITE, .35f));
  }
  c.text(F_CLOCK, ct.hm, 120, 136, p.text, 1, k);
  c.text(F_TEXT, ct.date, 120, 162, p.label, 1, k);
}

static void drawClock(Canvas &c, const State &s, const Pal &p, uint32_t now, float k, bool motion) {
  ClockTime ct = clockTime(s, now, motion);
  float t = now / 1000.f;
  if (s.clockStyle == 1) clockRadar(c, ct, p, t, k, motion);
  else if (s.clockStyle == 2) clockRetro(c, ct, p, t, k, motion);
  else if (s.clockStyle == 3) clockDots(c, ct, p, t, k, motion);
  else clockAnalog(c, ct, p, t, k, motion);
}

// energy: 1 = läuft, 0 = Pause (Balken und Cover beruhigen sich); level: Tonpegel 0…1;
// intro: Sekunden seit dem Titelwechsel (< 0 = kein Wechsel)
static void drawAlbum(Canvas &c, const State &s, const Pal &p, uint32_t now, float k, const uint16_t *cover,
                      bool motion, float energy, float level, float intro) {
  int64_t pos = s.songPos(now);
  float t = now / 1000.f;
  bool in = intro >= 0 && motion;
  float zoom = in ? .5f + .5f * easeBack(intro / .9f) : 1;
  if (cover) {
    c.image(cover, 120, 120, 120 * zoom, in ? easeOut(intro / .5f) : 1);
  } else {
    c.disc(120, 120, 102 * zoom, p.track);
    c.text(F_BIG, "\xE2\x99\xAA", 120, 130, p.accent);   // Note (Ersatzzeichen „?“, wenn nicht in der Schrift)
  }
  float calm = 1 - energy;
  if (calm > .01f) c.disc(120, 120, 121, rgb(3, 6, 12), .5f * calm);   // Pause: Cover tritt zurück
  // Infoleiste unten
  for (int y = 150; y < 240; y++) {
    float a = clamp01((y - 150) / 30.f) * .82f;
    for (int x = 0; x < 240; x++) c.blend(x, y, rgb(3, 6, 12), a);
  }
  float ta = in ? easeOut((intro - .5f) / .6f) : k;
  marquee(c, F_MID, s.title[0] ? s.title : s.source, 184, p.text, 172, in ? intro : t, ta);
  c.textFit(F_TEXT, s.artist, 120, 204, p.label, 150, ta);
  // Equalizer-Balken rund um das Cover: folgen dem Tonpegel und kommen bei Pause langsam zur Ruhe
  if (motion) {
    float amp = energy * (.35f + 1.1f * level);
    for (int i = 0; i < 48; i++) {
      float a = i / 48.f * 2 * PI_F;
      float wave = (.5f + .5f * sinf(t * (4.7f + (i % 7) * .9f) + i * 1.3f)) * (.6f + .4f * sinf(t * 2.1f + i));
      float h = 1.5f + 2 * energy + 8.5f * wave * amp;
      c.line(120 + (116 - h) * cosf(a), 120 + (116 - h) * sinf(a), 120 + 117 * cosf(a), 120 + 117 * sinf(a), 2.6f,
             mix(p.accent, p.light, (float)i / 48), .35f + .55f * energy);
    }
  }
  if (in && intro < 1.6f) {            // Lichtring läuft einmal ums Cover
    float e = easeInOut(intro / 1.4f) * 360 - 90;
    c.arc(120, 120, 114, 5, e - 120, e, grad(p.bg, WHITE), .85f * (1 - intro / 1.6f), true);
  }
  if (calm > .02f) {                   // Pause-Zeichen atmet sanft
    float breath = motion ? .78f + .22f * sinf(t * 1.6f) : 1;
    c.glow(120, 104, 54, p.accent, .3f * calm * breath);
    c.line(109, 86, 109, 122, 9, WHITE, .9f * calm * breath);
    c.line(131, 86, 131, 122, 9, WHITE, .9f * calm * breath);
  }
  char foot[40];
  if (pos >= 0) {                      // Fortschritt: dünner Ring ganz außen und Restzeit
    float done = (float)pos / (float)s.durMs;
    c.arc(120, 120, 118.6f, 2.6f, -90, 270, solid(rgb(3, 6, 12)), .55f, false);
    if (done > .004f) c.arc(120, 120, 118.6f, 2.6f, -90, -90 + 360 * done, solid(WHITE), .92f, true);
    int left = (int)((s.durMs - pos) / 1000);
    snprintf(foot, sizeof foot, "%s  -%d:%02d", energy > .5f ? s.source : "PAUSE", left / 60, left % 60);
  } else snprintf(foot, sizeof foot, "%s", energy > .5f ? s.source : "PAUSE");
  c.text(F_SMALL, foot, 120, 224, p.accent, 1, k);
}

// Fernsehen: Sender, laufende Sendung und wie lange sie noch geht
static void drawTv(Canvas &c, const State &s, const Pal &p, uint32_t now, float k, bool motion) {
  float t = now / 1000.f;
  ambience(c, p, t, motion);
  ringTrack(c, p);
  int64_t local = s.nowMs(now) / 1000;
  bool timed = s.tvStop > s.tvStart && local >= s.tvStart - 60;
  if (timed) {
    float done = clamp01((float)(local - s.tvStart) / (float)(s.tvStop - s.tvStart));
    ringValue(c, p, 100 * done * easeOut(k), false, t);
  }
  // kleines Fernseher-Zeichen
  c.line(107, 52, 133, 52, 2.4f, p.accent, k);
  c.line(133, 52, 133, 69, 2.4f, p.accent, k);
  c.line(133, 69, 107, 69, 2.4f, p.accent, k);
  c.line(107, 69, 107, 52, 2.4f, p.accent, k);
  c.line(113, 75, 127, 75, 2.4f, p.accent, k);
  c.textFit(F_LABEL, s.tvName, 120, 96, p.label, 150, k);
  marquee(c, F_MID, s.tvTitle[0] ? s.tvTitle : "Live-TV", 130, p.text, 172, (now % 600000) / 1000.f, k);
  if (timed) {
    char b[40];
    int left = (int)((s.tvStop - local + 59) / 60);
    if (left < 0) left = 0;
    if (left >= 90) snprintf(b, sizeof b, "noch %d Std. %d Min.", left / 60, left % 60);
    else snprintf(b, sizeof b, "noch %d Min.", left);
    c.text(F_TEXT, b, 120, 158, p.muted, 1, k);
    snprintf(b, sizeof b, "bis %02d:%02d", (int)((s.tvStop / 3600) % 24), (int)((s.tvStop / 60) % 60));
    c.text(F_SMALL, b, 120, 180, p.muted, 1, k);
  }
}

// ---- Wetter
static void wxCloud(Canvas &c, float x, float y, float sc, Col col, float a) {
  c.disc(x - 15 * sc, y + 6 * sc, 12 * sc, col, a);
  c.disc(x + 1 * sc, y - 4 * sc, 17 * sc, col, a);
  c.disc(x + 18 * sc, y + 5 * sc, 13 * sc, col, a);
  c.line(x - 15 * sc, y + 12 * sc, x + 18 * sc, y + 12 * sc, 12 * sc, col, a);
}

static void wxSun(Canvas &c, float x, float y, float r, float t, bool motion, float a) {
  const Col sun = rgb(255, 196, 64);
  c.glow(x, y, r * 2.4f, sun, .35f * a);
  for (int i = 0; i < 8; i++) {
    float an = i / 8.f * 2 * PI_F + (motion ? t * .25f : 0);
    c.line(x + (r + 6) * cosf(an), y + (r + 6) * sinf(an), x + (r + 13) * cosf(an), y + (r + 13) * sinf(an), 3.4f, sun, a);
  }
  c.disc(x, y, r, sun, a);
}

static void wxMoon(Canvas &c, float x, float y, float r, Col bg, float a) {
  c.glow(x, y, r * 2.2f, rgb(200, 214, 255), .25f * a);
  c.disc(x, y, r, rgb(226, 232, 255), a);
  c.disc(x + r * .45f, y - r * .3f, r * .86f, bg, a);
}

// Art: 0 klar, 1 heiter, 2 bewölkt, 3 Regen, 4 Schnee, 5 Gewitter, 6 Nebel (aus dem WMO-Wettercode)
static int wxKind(int code) {
  if (code == 0) return 0;
  if (code == 1 || code == 2) return 1;
  if (code == 3) return 2;
  if (code == 45 || code == 48) return 6;
  if ((code >= 71 && code <= 77) || code == 85 || code == 86) return 4;
  if (code >= 95) return 5;
  if (code >= 51) return 3;
  return 2;
}

static void drawWeather(Canvas &c, const State &s, const Pal &p, uint32_t now, float k, bool motion) {
  float t = now / 1000.f;
  const Weather &w = s.wx;
  ambience(c, p, t, motion);
  ringTrack(c, p);
  if (w.rain >= 0) ringValue(c, p, w.rain * easeOut(k), false, t);       // Ring = Regenwahrscheinlichkeit
  int kind = wxKind(w.code);
  const float x = 120, y = 82;
  const Col cloud = rgb(214, 224, 238), dark = rgb(150, 162, 182);
  float bob = motion ? 2 * sinf(t * .9f) : 0;
  if (kind == 0) {
    if (w.day) wxSun(c, x, y, 17, t, motion, k); else wxMoon(c, x, y, 20, p.bg, k);
  } else if (kind == 1) {
    if (w.day) wxSun(c, x + 14, y - 10, 13, t, motion, k); else wxMoon(c, x + 14, y - 10, 15, p.bg, k);
    wxCloud(c, x - 6 + bob, y + 6, .95f, cloud, k);
  } else if (kind == 6) {
    for (int i = 0; i < 4; i++) {
      float sh = motion ? 5 * sinf(t * .8f + i * 1.4f) : 0;
      c.line(x - 28 + sh, y - 15 + i * 11, x + 28 + sh, y - 15 + i * 11, 4.5f, cloud, k * (.9f - i * .15f));
    }
  } else {
    wxCloud(c, x + bob, y - 6, 1, kind == 2 ? cloud : dark, k);
    if (kind == 3 || kind == 5)
      for (int i = 0; i < 4; i++) {            // fallende Tropfen
        float f = motion ? fmodf(t * 1.3f + i * .27f, 1) : .4f;
        float dx = x - 20 + i * 13, dy = y + 12 + f * 16;
        c.line(dx, dy, dx - 3, dy + 7, 2.6f, rgb(96, 170, 255), k * (1 - f * .7f));
      }
    if (kind == 4)
      for (int i = 0; i < 5; i++) {
        float f = motion ? fmodf(t * .5f + i * .21f, 1) : .4f;
        c.disc(x - 22 + i * 11 + 3 * sinf(t * 2 + i), y + 13 + f * 17, 2.4f, WHITE, k * (1 - f * .6f));
      }
    if (kind == 5) {
      float flash = motion ? (fmodf(t, 2.6f) < .18f ? 1 : .75f) : 1;
      c.triangle(x + 4, y + 6, x - 8, y + 24, x + 2, y + 22, rgb(255, 214, 80), k * flash);
      c.triangle(x + 2, y + 20, x - 4, y + 38, x + 12, y + 16, rgb(255, 214, 80), k * flash);
    }
  }
  char b[48];
  snprintf(b, sizeof b, "%d\xC2\xB0", w.temp);
  c.text(F_BIG, b, 124, 152, p.text, 1, k);
  if (w.rain >= 0) snprintf(b, sizeof b, "Regen %d %%", w.rain);
  else snprintf(b, sizeof b, "Wetter");
  c.text(F_TEXT, b, 120, 176, w.rain >= 60 ? rgb(120, 180, 255) : p.muted, 1, k);
  snprintf(b, sizeof b, "%d\xC2\xB0 / %d\xC2\xB0", w.hi, w.lo);
  c.text(F_SMALL, b, 120, 195, p.muted, 1, k);
  c.textFit(F_SMALL, w.city, 120, 212, p.label, 110, k);
}

static void drawWlan(Canvas &c, const State &s, const Pal &p, uint32_t now, float k, float shownSig, bool motion) {
  float t = now / 1000.f;
  ambience(c, p, t, motion);
  ringTrack(c, p);
  if (s.info.wlan) {
    ringValue(c, p, shownSig * easeOut(k), s.info.signal >= 0 && s.info.signal < 40, t);
    // WLAN-Wellen, die nacheinander aufleuchten
    for (int i = 0; i < 3; i++) {
      float ph = motion ? clamp01(.5f + .5f * sinf(t * 2.4f - i * .9f)) : 1;
      c.arc(120, 74, 12 + i * 10, 4, 225, 315, solid(mix(p.track, p.accent, .35f + .65f * ph)), k, true);
    }
    c.disc(120, 72, 3.5f, p.accent, k);
    char b[16];
    fmtInt(b, s.info.signal < 0 ? -1 : (int)roundf(shownSig * easeOut(k)), " %");
    c.text(F_BIG, b, 120, 128, p.text, 1, k);
    c.textFit(F_TEXT, s.info.ssid[0] ? s.info.ssid : "verbunden", 120, 158, p.muted, 150, k);
    c.text(F_SMALL, "WLAN-Signal", 120, 180, p.muted, 1, k);
  } else {
    c.text(F_LABEL, "WLAN", 120, 70, p.label, 1, k);
    c.text(F_MID, "Kein WLAN", 120, 122, p.bad, 1, k);
    c.text(F_SMALL, "evtl. per Kabel online", 120, 150, p.muted, 1, k);
  }
}

static void drawSystem(Canvas &c, const State &s, const Pal &p, uint32_t now, float k, float shownCpu, bool motion) {
  float t = now / 1000.f;
  ambience(c, p, t, motion);
  ringTrack(c, p);
  ringValue(c, p, shownCpu * easeOut(k), s.info.cpu >= 80, t);
  label(c, "CPU", 66, p.label, k);
  char b[40];
  fmtInt(b, s.info.cpu < 0 ? -1 : (int)roundf(shownCpu * easeOut(k)), " %");
  c.text(F_BIG, b, 120, 118, p.text, 1, k);
  if (s.info.temp >= 0) snprintf(b, sizeof b, "Temperatur %d \xC2\xB0" "C", s.info.temp);
  else snprintf(b, sizeof b, "Temperatur --");
  c.text(F_TEXT, b, 120, 150, s.info.temp >= 70 ? p.warn : p.muted, 1, k);
  if (s.info.ram >= 0) snprintf(b, sizeof b, "Speicher %d %%", s.info.ram);
  else snprintf(b, sizeof b, "Speicher --");
  c.text(F_TEXT, b, 120, 172, p.muted, 1, k);
}

// ---------------------------------------------------------------- Display 2
static void drawVolume(Canvas &c, const State &s, const Pal &p, uint32_t now, float k, float shownVol, bool fresh,
                       bool motion) {
  float t = now / 1000.f;
  ambience(c, p, t, motion);
  ringTrack(c, p);
  bool known = fresh && s.volume >= 0;
  if (known && !s.muted) ringValue(c, p, shownVol * easeOut(k), shownVol >= 85, t);
  label(c, "LAUTST\xC3\x84RKE", 62, p.label, k);
  char b[16];
  if (s.muted && fresh) c.text(F_BIG, "STUMM", 120, 128, p.bad, 1, k);
  else {
    fmtInt(b, known ? (int)roundf(shownVol * easeOut(k)) : -1, "");
    c.text(F_NUM, b, 120, 142, p.text, 1, k);
  }
  const char *tgt = strcmp(s.target, "pi") == 0 ? "Pi" : "TV / Soundbar";
  c.text(F_TEXT, tgt, 120, 176, p.muted, 1, k);
  c.text(F_SMALL, s.muted && fresh ? "Ton aus" : known ? "%" : "kein R\xC3\xBC" "ckmeldewert", 120, 196, p.muted, 1, k);
}

static void checkMark(Canvas &c, Col col, float k, float cx, float cy, float sc, float width);

// Schlaf-Timer: der Ring läuft ab
static void drawSleep(Canvas &c, const State &s, const Pal &p, uint32_t now, float k, bool motion) {
  float t = now / 1000.f;
  ambience(c, p, t, motion);
  int left = s.sleepNow(now);
  int total = s.sleepTotal > 0 ? s.sleepTotal : (left > 0 ? left : 1);
  ringTrack(c, p);
  ringValue(c, p, 100.f * left / total * easeOut(k), left <= 60, t);
  wxMoon(c, 120, 62, 13, p.bg, k);
  c.text(F_SMALL, "SCHLAF-TIMER", 120, 96, p.label, 1, k);
  char b[24];
  if (left >= 3600) snprintf(b, sizeof b, "%d:%02d:%02d", left / 3600, (left / 60) % 60, left % 60);
  else snprintf(b, sizeof b, "%d:%02d", left / 60, left % 60);
  c.text(left >= 3600 ? F_BIG : F_CLOCK, b, 120, 146, left <= 60 ? p.warn : p.text, 1, k);
  c.text(F_SMALL, left <= 60 ? "Musik wird leiser" : "bis zum Ausschalten", 120, 168, p.muted, 1, k);
  if (s.wake[0]) {
    snprintf(b, sizeof b, "Wecker %s", s.wake);
    c.text(F_SMALL, b, 120, 190, p.accent, 1, k);
  }
}

static void wrapLines(Canvas &c, const char *s, float y0, Col col, float k);

// Kurzer Hinweis (Aufnahme, Update fertig, Warnung …)
static void drawNotice(Canvas &c, const State &s, const Pal &p, uint32_t now, float tt, bool motion) {
  const Notice &n = s.notice;
  float t = now / 1000.f, k = easeOut(tt / .5f);
  Col col = n.kind == 'w' ? p.warn : n.kind == 'r' ? rgb(240, 70, 70) : p.accent;
  float pulse = motion ? .75f + .25f * sinf(t * 4) : 1;
  c.glow(120, 120, 150, col, .12f * k);
  c.arc(120, 120, 113, 5, 0, 360, solid(col), (n.kind == 'w' || n.kind == 'r' ? pulse : 1) * k, false);
  const float ix = 120, iy = 64;
  if (n.kind == 'k') checkMark(c, col, clamp01(tt / .6f), ix, iy, .6f, 6);
  else if (n.kind == 'r') { c.glow(ix, iy, 30, col, .5f * pulse); c.disc(ix, iy, 11, col, k); }
  else if (n.kind == 'w') {
    c.triangle(ix, iy - 20, ix - 21, iy + 15, ix + 21, iy + 15, col, k);
    c.line(ix, iy - 8, ix, iy + 3, 3.6f, p.bg, k);
    c.disc(ix, iy + 9.5f, 2.4f, p.bg, k);
  } else {
    c.arc(ix, iy, 16, 3.4f, 0, 360, solid(col), k, false);
    c.line(ix, iy - 2, ix, iy + 8, 3.6f, col, k);
    c.disc(ix, iy - 8.5f, 2.3f, col, k);
  }
  marquee(c, F_MID, n.title, 116, p.text, 176, tt, k);
  wrapLines(c, n.text, 142, p.label, k);
}

static void checkMark(Canvas &c, Col col, float k, float cx, float cy, float sc, float width) {
  float x0 = cx - 23 * sc, y0 = cy + 1 * sc, x1 = cx - 6 * sc, y1 = cy + 18 * sc, x2 = cx + 26 * sc, y2 = cy - 19 * sc;
  float a = clamp01(k * 2.2f), b = clamp01(k * 2.2f - 1);
  if (a > 0) c.line(x0, y0, x0 + (x1 - x0) * a, y0 + (y1 - y0) * a, width, col);
  if (b > 0) c.line(x1, y1, x1 + (x2 - x1) * b, y1 + (y2 - y1) * b, width, col);
}

static void wrapLines(Canvas &c, const char *s, float y0, Col col, float k) {
  // einfacher Zeilenumbruch nach Wörtern (max. 5 Zeilen à ~170 px)
  char line[96] = "", word[64];
  int lines = 0;
  const char *p = s;
  while (*p && lines < 5) {
    int n = 0;
    while (*p == ' ') p++;
    while (*p && *p != ' ' && n < 62) word[n++] = *p++;
    word[n] = 0;
    char test[200];
    snprintf(test, sizeof test, "%s%s%s", line, line[0] ? " " : "", word);
    if (c.textWidth(F_TEXT, test) > 170 && line[0]) {
      c.text(F_TEXT, line, 120, y0 + lines * 22, col, 1, k);
      lines++;
      snprintf(line, sizeof line, "%s", word);
    } else {
      strncpy(line, test, sizeof line - 1);
      line[sizeof line - 1] = 0;
    }
  }
  if (line[0] && lines < 5) c.text(F_TEXT, line, 120, y0 + lines * 22, col, 1, k);
}

static void drawStatus(Canvas &c, const State &s, const Pal &p, uint32_t now, float k, bool motion) {
  float t = now / 1000.f;
  ambience(c, p, t, motion);
  if (!s.info.nerr) {
    c.arc(120, 120, 112, 4, 0, 360, solid(p.line), 1, false);
    if (motion) {   // umlaufender Lichtpunkt
      float a = fmodf(t * 60, 360);
      c.arc(120, 120, 113, 6, a, a + 50, grad(p.bg, p.light), .9f, false);
    }
    label(c, "STATUS", 66, p.label, k);
    c.glow(120, 112, 46, p.accent, .25f * k);
    checkMark(c, p.accent, k, 120, 110, 1, 9);
    c.text(F_LABEL, "Keine Fehler", 120, 164, p.hand, 1, k);
    return;
  }
  float pulse = motion ? .7f + .3f * sinf(t * 4) : 1;
  c.arc(120, 120, 112, 4, 0, 360, solid(p.bad), pulse, false);
  char b[24];
  if (s.info.nerr == 1) snprintf(b, sizeof b, "FEHLER");
  else snprintf(b, sizeof b, "%d FEHLER", s.info.nerr);
  label(c, b, 56, p.bad, k);
  wrapLines(c, s.info.errors[0], 90, p.text, k);
}

static void teensyLine(Canvas &c, const State &s, const Pal &p, float k) {
  if (!s.fw[0]) return;
  char line[40];
  snprintf(line, sizeof line, "Teensy-Firmware %s", s.fw);
  c.text(F_SMALL, line, 120, 210, p.muted, 1, k * .9f);
}

static void drawUpdate(Canvas &c, const State &s, const Pal &p, uint32_t now, float k, float shownProg, bool motion) {
  float t = now / 1000.f;
  ambience(c, p, t, motion);
  const Upd &u = s.upd;
  label(c, "UPDATES", 54, p.label, k);
  if (u.running) {
    int a = 0, b = 0;
    const char *sl = strchr(u.step, '/');
    if (sl) {
      const char *q = sl;
      while (q > u.step && q[-1] >= '0' && q[-1] <= '9') q--;
      a = atoi(q);
      b = atoi(sl + 1);
    }
    if (b > 0) {
      ringTrack(c, p);
      ringValue(c, p, shownProg, false, t);
      char pc[16];
      snprintf(pc, sizeof pc, "%d %%", (int)roundf(shownProg));
      c.text(F_BIG, pc, 120, 116, p.text, 1, k);
      bool dl = strncmp(u.step, "Download", 8) == 0;
      c.text(F_TEXT, dl ? "wird geladen" : strncmp(u.step, "Systemupdates", 13) == 0 ? "Systemupdates" : "Installation", 120, 142, p.label, 1, k);
      char line[40];
      if (dl) snprintf(line, sizeof line, "%d,%d von %d,%d MB", a / 10, a % 10, b / 10, b % 10);
      else snprintf(line, sizeof line, "%d von %d Paketen", a, b);
      c.text(F_SMALL, line, 120, 164, p.muted, 1, k);
    } else {
      c.arc(120, 120, 112, 12, 0, 360, solid(p.track), 1, false);
      float st = fmodf(t * 220, 360);
      c.arc(120, 120, 112, 12, st, st + 120, grad(p.track, p.accent), 1, true);
      c.text(F_MID, "Wird", 120, 104, p.text, 1, k);
      c.text(F_MID, "installiert \xE2\x80\xA6", 120, 130, p.text, 1, k);
      c.textFit(F_SMALL, u.step, 120, 156, p.muted, 160, k);
    }
    c.text(F_SMALL, "Nicht ausschalten", 120, 182, p.warn, 1, k);
    return;
  }
  ringTrack(c, p);
  if (u.newer) {
    ringValue(c, p, 100 * easeOut(k), false, t);
    float pulse = motion ? .7f + .3f * sinf(t * 3) : 1;
    c.text(F_LABEL, "NEU", 120, 84, mix(p.bg, p.warn, pulse), 1, k);
    c.text(F_BIG, u.latest, 120, 124, p.text, 1, k);
    char line[40];
    snprintf(line, sizeof line, "installiert: %s", u.installed);
    c.text(F_SMALL, line, 120, 148, p.muted, 1, k);
    c.text(F_SMALL, u.autoInst ? "kommt heute Nacht" : "in den Einstellungen installieren", 120, 168, p.label, 1, k);
    teensyLine(c, s, p, k);
    return;
  }
  ringValue(c, p, 100 * easeOut(k), false, t);
  c.text(F_SMALL, "Raspi-TV", 120, 76, p.muted, 1, k);
  c.text(F_BIG, u.installed[0] ? u.installed : "?", 120, 112, p.text, 1, k);
  if (!u.online) {
    c.text(F_TEXT, "Online-Update aus", 120, 146, p.muted, 1, k);
  } else if (u.error) {
    c.text(F_TEXT, "Server nicht", 120, 142, p.warn, 1, k);
    c.text(F_TEXT, "erreichbar", 120, 160, p.warn, 1, k);
  } else {
    checkMark(c, p.accent, k, 120, 138, .55f, 5);
    c.text(F_TEXT, "Aktuell", 120, 170, p.hand, 1, k);
  }
  if (u.checkedMin >= 0) {
    char line[40];
    if (u.checkedMin < 2) snprintf(line, sizeof line, "gepr\xC3\xBC" "ft gerade eben");
    else if (u.checkedMin < 90) snprintf(line, sizeof line, "gepr\xC3\xBC" "ft vor %d Min.", u.checkedMin);
    else snprintf(line, sizeof line, "gepr\xC3\xBC" "ft vor %d Std.", u.checkedMin / 60);
    c.text(F_SMALL, line, 120, 190, p.muted, 1, k);
  }
  teensyLine(c, s, p, k);
}

// Titelwechsel auf Display 2: „Jetzt läuft“ mit Lauftext
static void drawTrack(Canvas &c, const State &s, const Pal &p, uint32_t now, float tt, bool motion) {
  float t = now / 1000.f, k = easeOut(tt / .6f);
  ambience(c, p, t, motion);
  c.arc(120, 120, 112, 6, 0, 360, solid(p.track), 1, false);
  float left = 1 - clamp01(tt * 1000 / TRACK_MS);
  c.arc(120, 120, 112, 6, -90, -90 + 360 * left, grad(p.accent, p.light), 1, true);
  for (int i = 0; i < 5; i++) {        // kleine tanzende Balken
    float h = motion ? 6 + 14 * (.5f + .5f * sinf(t * (5 + i * 1.3f) + i * 2.1f)) : 12;
    c.line(96 + i * 12, 78, 96 + i * 12, 78 - h * k, 5, mix(p.accent, p.light, i / 4.f));
  }
  c.text(F_SMALL, "JETZT L\xC3\x84UFT", 120, 100, p.label, 1, k);
  marquee(c, F_MID, s.title, 132, p.text, 178, tt, k);
  c.textFit(F_TEXT, s.artist, 120, 158, p.label, 160, k);
  c.text(F_SMALL, s.source, 120, 184, p.accent, 1, k);
}

// Analoges VU-Meter wie an einer alten Stereoanlage. v = Zeigerstellung 0…1, peak = gehaltene Spitze
static void drawVu(Canvas &c, const Pal &p, float v, float peak, int which, float k) {
  const Col face = mix(rgb(238, 226, 192), p.accent, .05f), ink = rgb(38, 32, 26), red = rgb(196, 44, 38);
  const float px = 120, py = 196, R = 114, A0 = 226, A1 = 314;
  c.clear(face);
  c.glow(120, 60, 150, WHITE, .35f);                            // Licht von oben
  c.vignette(rgb(96, 78, 52), .55f);
  // Skala: schwarz bis 0 dB, rot darüber
  static const float POS[10] = {0, .2f, .33f, .44f, .56f, .68f, .76f, .84f, .92f, 1};
  static const char *const LAB[10] = {"20", "10", "7", "5", "3", "1", "0", "1", "2", "3"};
  float zero = A0 + (A1 - A0) * POS[6];
  c.arc(px, py, R, 2.4f, A0, zero, solid(ink), 1, false);
  c.arc(px, py, R - 3, 8, zero, A1, solid(red), 1, false);
  for (int i = 0; i < 10; i++) {
    float a = (A0 + (A1 - A0) * POS[i]) * PI_F / 180, ca = cosf(a), sa = sinf(a);
    Col col = i > 6 ? red : ink;
    c.line(px + (R - 1) * ca, py + (R - 1) * sa, px + (R + 11) * ca, py + (R + 11) * sa, 2.4f, col);
    c.text(F_SMALL, LAB[i], px + (R + 22) * ca, py + (R + 22) * sa + 5, col, 1);
  }
  for (int i = 0; i < 9; i++) {         // Zwischenstriche
    float a = (A0 + (A1 - A0) * (POS[i] + POS[i + 1]) / 2) * PI_F / 180;
    c.line(px + R * cosf(a), py + R * sinf(a), px + (R + 6) * cosf(a), py + (R + 6) * sinf(a), 1.4f, i >= 6 ? red : ink);
  }
  c.text(F_MID, "VU", 120, 146, ink, 1, k);
  c.text(F_SMALL, which == 0 ? "LINKS" : "RECHTS", 120, 166, mix(ink, face, .3f), 1, k);
  // Spitzenlampe
  bool hot = peak > .86f;
  if (hot) c.glow(176, 156, 20, red, .7f);
  c.disc(176, 156, 5.5f, hot ? rgb(255, 70, 50) : mix(face, red, .45f));
  c.disc(176, 156, 5.5f, ink, .12f);
  // Zeiger mit Schatten
  float a = (A0 + (A1 - A0) * clamp01(v)) * PI_F / 180, ca = cosf(a), sa = sinf(a);
  c.line(px + 4 + 30 * ca, py + 5 + 30 * sa, px + 4 + 108 * ca, py + 5 + 108 * sa, 3, rgb(60, 48, 30), .22f);
  c.line(px + 24 * ca, py + 24 * sa, px + 110 * ca, py + 110 * sa, 2.4f, ink);
  // Abdeckung unten mit Achse
  for (int y = 182; y < 240; y++)
    for (int x = 0; x < 240; x++) c.blend(x, y, rgb(24, 22, 22), clamp01((y - 181.5f)));
  c.disc(px, py + 6, 15, rgb(58, 54, 52));
  c.disc(px, py + 6, 9, rgb(160, 150, 136));
  c.disc(px, py + 6, 3.5f, rgb(30, 28, 28));
}

// ---------------------------------------------------------------- Start und Warten
static float sq(float v) { return v * v; }

// Superellipse (Logo-Bildschirm), Wert < 0 innen, ≈ Abstand in Pixeln
static float squircle(float x, float y, float cx, float cy, float r) {
  float u = fabsf(x - cx) / r, v = fabsf(y - cy) / r;
  return (powf(u * u * u * u + v * v * v * v, .25f) - 1) * r;
}

void drawIntroLogo(Canvas &c, float t, Col bg) {
  c.clear(bg);
  const float cx = 120, cy = 100, r = 58;
  float glow = easeOut((t - .2f) / 1.2f);
  if (glow > 0) c.glow(cx, cy, r + 60, BRAND_B, .32f * glow);
  // Rahmen zeichnet sich (im Uhrzeigersinn ab oben)
  float draw = easeOut(t / .9f);
  float fill = easeOut((t - .85f) / .45f);
  float cut = cy + r - fill * 2 * r;   // Füllung steigt von unten
  for (int y = (int)(cy - r - 4); y <= (int)(cy + r + 4); y++)
    for (int x = (int)(cx - r - 4); x <= (int)(cx + r + 4); x++) {
      float px = x + .5f, py = y + .5f;
      float d = squircle(px, py, cx, cy, r);
      Col col = brand(((px - cx) + (py - cy) + 2 * r) / (4 * r));
      if (fill > 0 && py >= cut) c.blend(x, y, col, clamp01(.5f - d) * clamp01(py - cut + .5f));
      if (draw > 0) {
        float ang = fastAtan2(py - cy, px - cx) + PI_F / 2;
        if (ang < 0) ang += 2 * PI_F;
        float shown = draw * 2 * PI_F;
        if (ang <= shown) c.blend(x, y, col, clamp01(2.6f - fabsf(d)));
      }
    }
  float pop = t > 1.1f ? easeBack((t - 1.1f) / .5f) : 0;
  if (pop > 0) {
    float k = pop;
    c.triangle(cx + 5 - 14 * k, cy + 2 - 23 * k, cx + 5 - 14 * k, cy + 2 + 23 * k, cx + 5 + 25 * k, cy + 2, WHITE);
  }
  for (int i = 0; i < 2; i++) {
    float a = easeOut((t - 1.5f - i * .15f) / .3f);
    if (a > 0) c.arc(cx + 16, cy - 14, 12 + i * 10 + 2.5f, 5, -60, -18, solid(mix(BRAND_B, WHITE, .85f)), a, true);
  }
  // Schriftzug „Raspi TV“ Buchstabe für Buchstabe
  const char *word = "Raspi TV";
  float total = c.textWidth(F_WORD, word), x = 120 - total / 2;
  char ch[2] = {0, 0};
  for (int i = 0; word[i]; i++) {
    ch[0] = word[i];
    float w = c.textWidth(F_WORD, ch);
    float a = easeOut((t - 1.75f - i * .07f) / .35f);
    if (a > 0 && word[i] != ' ') {
      Col col = i >= 6 ? brand(.4f + .6f * (i - 6)) : WHITE;
      c.text(F_WORD, ch, x, 208 + 8 * (1 - a), col, 0, a);
    }
    x += w;
  }
}

void drawIntroRing(Canvas &c, float t, const char *version, Col bg) {
  c.clear(bg);
  float track = easeOut(t / .4f);
  c.arc(120, 120, 112, 16, 135, 135 + 270 * track, solid(rgb(40, 52, 78)), 1, true);
  float sweep = easeInOut((t - .35f) / 1.6f);
  if (sweep > 0) {
    float end = 135 + 270 * sweep;
    c.arc(120, 120, 112, 16, 135, end, grad(BRAND_A, BRAND_C), 1, true);
    float a = end * PI_F / 180;
    c.glow(120 + 104 * cosf(a), 120 + 104 * sinf(a), 24, mix(brand(sweep), WHITE, .3f), .55f);
    c.disc(120 + 104 * cosf(a), 120 + 104 * sinf(a), 5, WHITE, .9f);
  }
  float a = easeOut((t - .5f) / .5f);
  if (a > 0) c.text(F_LABEL, "RASPI-TV", 120, 70, rgb(170, 190, 212), 1, a);
  if (t < 2.2f) {
    char b[8];
    snprintf(b, sizeof b, "%d", (int)(100 * sweep));
    if (a > 0) c.text(F_NUM, b, 120, 140, rgb(239, 249, 255), 1, a);
  } else {
    float b = easeOut((t - 2.2f) / .4f);
    c.glow(120, 112, 60, BRAND_C, .25f * b);
    c.text(F_BIG, "Bereit", 120, 130, rgb(239, 249, 255), 1, b);
  }
  if (version && version[0] && a > 0) {
    char v[32];
    snprintf(v, sizeof v, "Version %s", version);
    c.text(F_SMALL, v, 120, 178, rgb(133, 155, 181), 1, a);
  }
}

void drawWait(Canvas &c, const Pal &p, float t, int which) {
  if (which == 0) {
    drawIntroLogo(c, 9, p.bg);
    c.text(F_SMALL, "startet \xE2\x80\xA6", 120, 228, p.muted, 1, .6f + .4f * sinf(t * 3));
    return;
  }
  c.clear(p.bg);
  c.arc(120, 120, 112, 10, 0, 360, solid(p.track), 1, false);
  float st = fmodf(t * 240, 360);
  c.arc(120, 120, 112, 10, st, st + 100, grad(p.bg, p.accent), 1, true);
  c.text(F_MID, "Einen", 120, 112, p.label, 1);
  c.text(F_MID, "Moment \xE2\x80\xA6", 120, 138, p.label, 1);
}


// ---------------------------------------------------------------- Neustart, Ausschalten, Standby
static void drawLogoAt(Canvas &c, float cx, float cy, float r, float alpha) {
  for (int y = (int)(cy - r - 2); y <= (int)(cy + r + 2); y++)
    for (int x = (int)(cx - r - 2); x <= (int)(cx + r + 2); x++) {
      float px = x + .5f, py = y + .5f;
      float u = fabsf(px - cx) / r, v = fabsf(py - cy) / r;
      float d = (powf(u * u * u * u + v * v * v * v, .25f) - 1) * r;
      if (d < 1) c.blend(x, y, brand(((px - cx) + (py - cy) + 2 * r) / (4 * r)), alpha * clamp01(.5f - d));
    }
  float k = r / 58;
  c.triangle(cx + 5 * k - 14 * k, cy + 2 * k - 23 * k, cx + 5 * k - 14 * k, cy + 2 * k + 23 * k, cx + 5 * k + 25 * k,
             cy + 2 * k, WHITE, alpha);
}

void drawRestart(Canvas &c, const Pal &p, float t, int which) {
  c.clear(p.bg);
  if (which == 0) {
    c.glow(120, 110, 110, BRAND_B, .25f + .1f * sinf(t * 2));
    drawLogoAt(c, 120, 110, 44, 1);
    // kreisender Pfeil um das Logo
    float a = fmodf(t * 200, 360);
    c.arc(120, 110, 84, 6, a, a + 260, grad(mix(p.bg, BRAND_A, .3f), BRAND_C), 1, true);
    float e = (a + 260) * PI_F / 180, hx = 120 + 81 * cosf(e), hy = 110 + 81 * sinf(e);
    float tx = -sinf(e), ty = cosf(e);   // Laufrichtung
    c.triangle(hx + tx * 12, hy + ty * 12, hx - ty * 8, hy + tx * 8, hx + ty * 8, hy - tx * 8, BRAND_C);
    c.text(F_LABEL, "Neustart", 120, 222, p.label, 1, .7f + .3f * sinf(t * 3));
    return;
  }
  c.arc(120, 120, 112, 10, 0, 360, solid(p.track), 1, false);
  for (int i = 0; i < 3; i++) {
    float st = fmodf(t * (160 + i * 50) + i * 120, 360);
    c.arc(120, 120, 112 - i * 16, 6, st, st + 70, grad(p.bg, i == 1 ? BRAND_B : i == 2 ? BRAND_C : BRAND_A), 1, true);
  }
  c.text(F_MID, "Raspi-TV", 120, 112, p.text, 1);
  c.text(F_TEXT, "startet neu \xE2\x80\xA6", 120, 138, p.label, 1);
  c.text(F_SMALL, "gleich wieder da", 120, 162, p.muted, 1);
}

void drawGoodbye(Canvas &c, const Pal &p, float t, int which, int hour) {
  c.clear(rgb(0, 0, 0));
  float out = clamp01((t - 2.4f) / 1.2f);   // nach 2,4 s ausblenden
  float a = 1 - out;
  if (a <= 0) return;
  if (which == 0) {
    float k = 1 - .35f * easeInOut(t / 3.6f);
    c.glow(120, 104, 100 * k, BRAND_B, .3f * a);
    drawLogoAt(c, 120, 104, 52 * k, a);
    c.text(F_WORD, "Bis bald", 120, 210, mix(rgb(0, 0, 0), WHITE, a), 1);
    return;
  }
  float drain = 1 - easeInOut(t / 2.4f);
  if (drain > 0) c.arc(120, 120, 112, 14, 135, 135 + 270 * drain, grad(BRAND_A, BRAND_C), a, true);
  // Gruß passend zur Uhrzeit (hour < 0 = Uhrzeit unbekannt)
  const char *bye = hour < 0 ? "Bis bald" : hour >= 22 || hour < 5 ? "Gute Nacht" : hour < 11 ? "Sch\xC3\xB6nen Tag"
                    : hour < 17 ? "Bis sp\xC3\xA4ter" : "Sch\xC3\xB6nen Abend";
  c.text(F_MID, bye, 120, 118, mix(rgb(0, 0, 0), p.text, a), 1);
  c.text(F_SMALL, "Raspi-TV f\xC3\xA4hrt herunter", 120, 144, mix(rgb(0, 0, 0), p.muted, a), 1);
}

void drawStandby(Canvas &c, const Pal &p, float t, const char *wake) {
  c.clear(rgb(2, 3, 6));
  // Mondsichel mit sanft funkelnden Sternen
  c.glow(120, 100, 70, p.accent, .12f);
  c.disc(120, 100, 34, mix(p.light, WHITE, .5f));
  c.disc(136, 90, 30, rgb(2, 3, 6));
  const float sx[6] = {62, 172, 84, 160, 190, 52}, sy[6] = {70, 60, 140, 150, 112, 120};
  for (int i = 0; i < 6; i++) c.disc(sx[i], sy[i], 1.8f, WHITE, .3f + .7f * (.5f + .5f * sinf(t * 1.5f + i * 1.7f)));
  c.text(F_LABEL, "Standby", 120, 176, p.label, 1);
  if (wake && wake[0]) {
    char b[24];
    snprintf(b, sizeof b, "Wecker %s", wake);
    c.text(F_TEXT, b, 120, 200, p.accent, 1);
  } else c.text(F_SMALL, "Taste dr\xC3\xBC" "cken zum Einschalten", 120, 198, p.muted, 1);
}


static const uint32_t FW_NOTICE_MS = 7000;

void drawFwUpdated(Canvas &c, const Pal &p, float t, int which, const char *from, const char *to) {
  c.clear(p.bg);
  float k = easeOut(t / .8f);
  if (which == 0) {
    c.glow(120, 104, 90, p.accent, .3f * k);
    c.arc(120, 104, 60, 6, -90, -90 + 360 * easeInOut(t / 1.2f), grad(BRAND_A, BRAND_C), 1, true);
    checkMark(c, p.accent, clamp01((t - .8f) / .6f), 120, 102, 1, 8);
    c.text(F_LABEL, "Teensy aktualisiert", 120, 196, p.text, 1, k);
    return;
  }
  ringTrack(c, p);
  ringValue(c, p, 100 * easeOut(t / 1.4f), false, t);
  c.text(F_LABEL, "FIRMWARE", 120, 66, p.label, 1, k);
  c.text(F_TEXT, from[0] ? from : "?", 120, 98, p.muted, 1, k);
  c.line(120, 106, 120, 124, 3, p.accent, k);                       // Pfeil nach unten
  c.triangle(111, 120, 129, 120, 120, 131, p.accent, k);
  c.text(F_BIG, to, 120, 160, p.text, 1, k);
}

// ---------------------------------------------------------------- Seiten und Übergänge
// Übergänge: 0 = Wischen wie ein Uhrzeiger, 1 = Iris (Kreis wächst aus der Mitte), 2 = Schieben
static void transition(Canvas &c, const uint16_t *prev, int kind, float k) {
  const float soft = 10;
  for (int y = 0; y < H; y++)
    for (int x = 0; x < W; x++) {
      float dx = x + .5f - 120, dy = y + .5f - 120, keep;   // keep = Anteil altes Bild
      if (kind == 0) {
        float ang = fastAtan2(dy, dx) * 180 / PI_F + 90;
        if (ang < 0) ang += 360;
        keep = clamp01((ang - k * (360 + soft)) / soft + 1);
      } else if (kind == 1) {
        float d = sqrtf(dx * dx + dy * dy);
        keep = clamp01((d - k * (175 + soft)) / soft + 1);
      } else {
        int sx = x + (int)(k * 240);
        if (x >= (1 - k) * 240) continue;   // neues Bild rechts
        keep = 1;
        c.px[y * W + x] = prev[y * W + (sx < 240 ? sx : 239)];
        continue;
      }
      if (keep >= 1) c.px[y * W + x] = prev[y * W + x];
      else if (keep > 0) c.blend(x, y, from565(prev[y * W + x]), keep);
    }
}

void Screen::frame(Canvas &c, const State &s, const Pal &p, Rotation &rot, uint32_t now, uint32_t introAt,
                   const uint16_t *cover, float coverAngle, float level) {
  bool fresh = s.ever && now - s.lastMs < STALE_MS;
  bool motion = s.motion;
  int want;
  if (s.mode == 1) want = -4;                                  // Neustart
  else if (s.mode == 2) want = -5;                             // Ausschalten
  else if (introAt && now - introAt < INTRO_MS) want = -2;
  else if (!s.ever && now < 90000) want = -3;
  else if (s.fwNoticeAt && now >= s.fwNoticeAt && now - s.fwNoticeAt < FW_NOTICE_MS) want = -7;   // Teensy aktualisiert
  else if (s.tvStandby && fresh && which == 1) want = -6;      // Fernseher aus: Standby-Bild
  else {
    bool music = s.music(now), vu = s.vuLive(now) && music;
    bool track = music && s.trackAt && now - s.trackAt < TRACK_MS && s.playing;
    bool volNow = which == 1 && s.volAt && now - s.volAt < 4000;
    // Seitenliste: was eingeschaltet ist und gerade etwas zu zeigen hat
    uint8_t list[8];
    int n = 0, mask = s.pages[which], sl = s.sleepNow(now);
    if (which == 0) {
      if (mask & 1) list[n++] = 0;
      if ((mask & 16) && s.wx.valid) list[n++] = 4;            // Wetter
      if (mask & 2) list[n++] = 1;
      if (mask & 4) list[n++] = 2;
    } else {
      if (mask & 1) list[n++] = 0;
      if (mask & 2) list[n++] = 1;
      if (mask & 4) list[n++] = 2;
      if (sl > 0) list[n++] = 5;                               // Schlaf-Timer läuft
    }
    if (vu && s.vuMode == 1) list[n++] = 3;                    // VU-Meter als zusätzliche Seite
    if (!n) list[n++] = 0;
    rot.set(list, n, (uint32_t)s.pageSec * 1000, now);
    bool notice = s.notice.at && now - s.notice.at < NOTICE_MS && (which == 1 || s.notice.kind == 'w');
    if (notice) want = -9;                                     // kurzer Hinweis
    else if (which == 1 && s.upd.running) want = 2;            // Installation hat Vorrang
    else if (which == 1 && sl > 0 && sl <= 60) want = 5;       // letzte Minute des Schlaf-Timers
    else if (volNow) want = 0;                                 // Lautstärke gerade geändert
    else if (track) want = which == 0 ? 0 : -8;                // Titelwechsel: Cover groß / „Jetzt läuft“
    else if (vu && s.vuMode == 2) want = 3;                    // VU-Meter immer bei Musik
    else want = rot.page(now);
  }
  if (want != page) {
    if (motion && page != -100 && prev) {
      memcpy(prev, c.px, sizeof(uint16_t) * W * H);
      transOn = true;
      transAt = now;
      transKind = (transKind + 1) % 3;
      if (page == -2 || want == -2) transKind = 1;
    }
    page = want;
    pageAt = now;
  }
  float k = motion ? clamp01((now - pageAt - 120) / 750.f) : 1;
  // weich nachgeführte Werte
  float target[4] = {(float)(s.volume < 0 ? 0 : s.volume), (float)(s.info.cpu < 0 ? 0 : s.info.cpu),
                     (float)(s.info.signal < 0 ? 0 : s.info.signal), 0};
  {
    const char *sl = strchr(s.upd.step, '/');
    if (s.upd.running && sl) {
      const char *q = sl;
      while (q > s.upd.step && q[-1] >= '0' && q[-1] <= '9') q--;
      int a = atoi(q), b = atoi(sl + 1);
      if (b > 0) target[3] = 100.f * a / b;
    }
  }
  for (int i = 0; i < 4; i++) {
    if (shown[i] < 0 || !motion) shown[i] = target[i];
    else shown[i] += (target[i] - shown[i]) * .18f;
  }
  // Zeit seit dem letzten Bild: Pause-Beruhigung und Zeigerträgheit unabhängig von der Bildrate
  float dt = lastFrame ? (now - lastFrame) / 1000.f : .04f;
  if (dt > .25f) dt = .25f;
  lastFrame = now;
  bool vuOk = s.vuLive(now);
  float eTarget = s.playing ? 1 : 0;
  energy = motion ? energy + (eTarget - energy) * (1 - expf(-dt / (eTarget > energy ? .35f : .9f))) : eTarget;
  float lv = vuOk ? (s.vu[0] + s.vu[1]) / 200.f : .55f;
  level += (lv - level) * (1 - expf(-dt / .12f));
  float nt = vuOk ? s.vu[which] / 100.f : 0;
  needle += (nt - needle) * (1 - expf(-dt / (nt > needle ? .09f : .22f)));     // schnell hoch, träge zurück
  if (needle > peak) peak = needle; else peak -= dt * .35f;
  if (page == -2) {
    float t = (now - introAt) / 1000.f;
    if (which == 0) drawIntroLogo(c, t, p.bg);
    else drawIntroRing(c, t, s.version, p.bg);
  } else if (page == -3) {
    drawWait(c, p, now / 1000.f, which);
  } else if (page == -4) {
    drawRestart(c, p, (now - s.modeAt) / 1000.f, which);
  } else if (page == -5) {
    drawGoodbye(c, p, (now - s.modeAt) / 1000.f, which, s.ever ? (int)((s.nowMs(now) / 3600000) % 24) : -1);
  } else if (page == -6) {
    drawStandby(c, p, now / 1000.f, s.wake);
  } else if (page == -7) {
    drawFwUpdated(c, p, (now - s.fwNoticeAt) / 1000.f, which, s.fwFrom, s.fw);
  } else if (page == -8) {
    c.clear(p.bg);
    drawTrack(c, s, p, now, (now - s.trackAt) / 1000.f, motion);
  } else if (page == -9) {
    c.clear(p.bg);
    drawNotice(c, s, p, now, (now - s.notice.at) / 1000.f, motion);
  } else if (page == 3) {
    drawVu(c, p, needle, peak, which, k);
  } else {
    c.clear(p.bg);
    if (which == 0) {
      bool music = s.music(now);
      if (page == 0) {
        float intro = s.trackAt && now - s.trackAt < TRACK_MS && s.playing ? (now - s.trackAt) / 1000.f : -1;
        if (music) drawAlbum(c, s, p, now, k, s.hasCover ? cover : nullptr, motion, energy, level, intro);
        else if (fresh && s.tvName[0]) drawTv(c, s, p, now, k, motion);
        else drawClock(c, s, p, now, k, motion);
      } else if (page == 4) drawWeather(c, s, p, now, k, motion);
      else if (page == 1) drawWlan(c, s, p, now, k, shown[2], motion);
      else drawSystem(c, s, p, now, k, shown[1], motion);
    } else {
      if (page == 0) drawVolume(c, s, p, now, k, shown[0], fresh, motion);
      else if (page == 5) drawSleep(c, s, p, now, k, motion);
      else if (page == 1) drawStatus(c, s, p, now, k, motion);
      else drawUpdate(c, s, p, now, k, shown[3], motion);
    }
  }
  if (s.tvStandby && fresh && page >= 0) level *= .35f;   // Nachtmodus bei ausgeschaltetem Fernseher
  c.dim(level);   // Helligkeit per Software (vor dem Übergang: das alte Bild ist schon abgedunkelt)
  if (transOn) {
    float tk = (now - transAt) / 520.f;
    if (tk >= 1) transOn = false;
    else transition(c, prev, transKind, easeInOut(tk));
  }
}

void PageRules::apply(const State &s, Rotation *rot, uint32_t now) {
  if (!(s.ever && now - s.lastMs < STALE_MS)) return;
  int volKey = s.volume * 4 + (s.muted ? 1 : 0) + (s.target[0] == 'p' ? 2 : 0);
  if (lastVol != -9999 && volKey != lastVol) rot[1].hold(0, now);
  lastVol = volKey;
  int updKey = (s.upd.newer ? 1 : 0) + (s.upd.running ? 2 : 0);
  if (s.upd.running) rot[1].hold(2, now);
  else if (lastUpd >= 0 && updKey != lastUpd && s.upd.newer) rot[1].hold(2, now);
  lastUpd = updKey;
}

// Uhr mit dem Pi abgleichen: kleine Abweichungen werden sanft nachgezogen (keine Sprünge, nie
// rückwärts sichtbar), nur grobe Abweichungen (> 2 s, z. B. nach dem Start) werden direkt gesetzt.
void State::syncClock(int64_t piMs, uint32_t now) {
  int64_t mine = nowMs(now);
  int64_t diff = piMs - mine;
  if (epoch == 0 || diff > 2000 || diff < -2000) {
    epoch = piMs;
    epochAt = now;
    return;
  }
  // höchstens 4 ms pro Abgleich (2× pro Sekunde) – unsichtbar für den Sekundenzeiger
  int64_t step = diff / 8;
  if (step > 4) step = 4;
  if (step < -4) step = -4;
  epoch = mine + step;
  epochAt = now;
}
