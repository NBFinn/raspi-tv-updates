// Raspi-TV Displays – Seiten, Animationen und Zustand (ohne Hardware, auch am PC testbar).
#pragma once
#include "gfx.h"

static const uint32_t PAGE_MS = 10000;     // Seitenwechsel alle 10 s
static const uint32_t INTRO_MS = 3400;     // Startanimation
static const uint32_t STALE_MS = 6000;     // ohne Daten vom Pi: Anzeige „--“
static const uint32_t TRACK_MS = 6500;     // Anzeige beim Titelwechsel
static const uint32_t VU_STALE_MS = 2000;  // ohne Pegel vom Pi: keine VU-Meter

struct Info {
  int cpu = -1, temp = -1, ram = -1, signal = -1;
  bool wlan = false;
  char ssid[40] = "";
  char errors[3][96] = {"", "", ""};
  int nerr = 0;
};

struct Upd {
  char installed[16] = "", latest[16] = "", step[48] = "";
  bool newer = false, running = false, error = false, online = false, autoInst = true;
  int checkedMin = -1;
};

struct State {
  bool ever = false;              // schon einmal Daten bekommen?
  uint32_t lastMs = 0;            // Zeitpunkt der letzten Daten
  int64_t epoch = 0;              // Ortszeit in Millisekunden (vom Pi) zum Zeitpunkt epochAt
  uint32_t epochAt = 0;
  // Ortszeit in ms – läuft mit der Teensy-Uhr weiter, nie rückwärts
  int64_t nowMs(uint32_t now) const { return epoch + (int64_t)(uint32_t)(now - epochAt); }
  void syncClock(int64_t piMs, uint32_t now);
  char title[96] = "", artist[96] = "", source[16] = "SPOTIFY";
  bool playing = false, paused = false, hasCover = false;
  int volume = -1;
  bool muted = false;
  char target[12] = "pi";
  Col accent = hexcol(0x6d5dfc), bg = hexcol(0x0b0d12);
  int brightness = 100;
  bool motion = true;
  Info info;
  Upd upd;
  char version[16] = "";
  bool tvStandby = false;         // Fernseher aus → Nachtmodus
  int mode = 0;                   // 0 normal, 1 Neustart, 2 Ausschalten
  char fw[16] = "";               // eigene Firmware-Version (Teensy)
  char fwFrom[16] = "";           // vorherige Version, wenn gerade aktualisiert
  uint32_t fwNoticeAt = 0;        // Hinweis „Teensy aktualisiert“ ab diesem Zeitpunkt
  uint32_t modeAt = 0;
  int clockStyle = 0;             // 0 analog, 1 Radar, 2 Retro-Ziffern, 3 kreisende Punkte
  int vuMode = 0;                 // 0 aus, 1 als eigene Seite, 2 immer bei Musik
  float vu[2] = {0, 0};           // Tonpegel links/rechts 0…100 (vom Pi, ~20×/s)
  uint32_t vuAt = 0;              // letzter Pegel
  uint32_t trackAt = 0;           // Titel hat gewechselt (0 = nie)
  uint32_t volAt = 0;             // Lautstärke wurde geändert
  bool music(uint32_t now) const { return ever && now - lastMs < STALE_MS && (playing || paused) && title[0]; }
  bool vuLive(uint32_t now) const { return vuMode && playing && vuAt && now - vuAt < VU_STALE_MS; }
};

struct Pal {
  Col accent, bg, track, line, tick, label, muted, hand, light, text, warn, bad;
};
Pal makePal(Col accent, Col base);
Pal blendPal(const Pal &a, const Pal &b, float t);

struct Rotation {
  uint32_t start = 0;
  int count = 3;
  int page(uint32_t now) const { return (int)(((now - start) / PAGE_MS) % count); }
  void hold(int i, uint32_t now) { start = now - i * PAGE_MS; }
};

class Screen {
 public:
  int which = 0;                  // 0 = Display 1 (Uhr/Cover, WLAN, System), 1 = Display 2 (Lautstärke, Status, Updates)
  uint16_t *prev = nullptr;       // letztes Bild (für Übergänge)
  int page = -100;
  uint32_t pageAt = 0, transAt = 0;
  int transKind = 0;
  bool transOn = false;
  float shown[4] = {-1, -1, -1, -1};   // weich nachgeführte Werte (Lautstärke, CPU, Signal, Fortschritt)
  float energy = 1;               // 1 = Musik läuft, 0 = pausiert (Animationen beruhigen sich)
  float needle = 0, peak = 0;     // VU-Zeiger mit Trägheit, Spitzenwert
  float level = 0;                // geglätteter Tonpegel 0…1 (für Balken ums Cover)
  uint32_t lastFrame = 0;
  void frame(Canvas &c, const State &s, const Pal &p, Rotation &rot, uint32_t now, uint32_t introAt,
             const uint16_t *cover, float coverAngle, float level = 1);
};

void drawIntroLogo(Canvas &c, float t, Col bg);
void drawIntroRing(Canvas &c, float t, const char *version, Col bg);
void drawWait(Canvas &c, const Pal &p, float t, int which);
void drawRestart(Canvas &c, const Pal &p, float t, int which);
void drawGoodbye(Canvas &c, const Pal &p, float t, int which);
void drawStandby(Canvas &c, const Pal &p, float t);
void drawFwUpdated(Canvas &c, const Pal &p, float t, int which, const char *from, const char *to);

// Regeln für Display 2: geänderte Lautstärke → Lautstärke-Seite, neues Update/Installation → Update-Seite
struct PageRules {
  int lastVol = -9999, lastUpd = -1;
  void apply(const State &s, Rotation *rot, uint32_t now);
};
