#!/bin/bash
# Ersatz fuer start.sh auf dem vorhandenen Raspi-TV-Notfall-Stick.
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo 'Bitte mit sudo bash /mnt/start.sh starten.'; exit 1; }
SOURCE="$(cd "$(dirname "$0")" && pwd)"
if [ -f "$SOURCE/../system/recovery.py" ]; then
  SOURCE="$(cd "$SOURCE/../system" && pwd)"
  ASSET_SOURCE="$SOURCE/../launcher"
elif [ -f "$SOURCE/system/recovery.py" ]; then
  SOURCE="$SOURCE/system"
  ASSET_SOURCE="$SOURCE/../launcher"
else
  ASSET_SOURCE="$SOURCE/recovery-assets"
fi
for file in recovery.py recovery.html raspi-tv-recovery.service maintenance.py maintenance.js display-diagnostics.py terminal.py; do
  [ -s "$SOURCE/$file" ] || { echo "Auf dem Stick fehlt: $file"; exit 1; }
done
for file in xterm.js xterm.css xterm-addon-fit.js xterm.LICENSE.txt qrcode.js; do
  [ -s "$ASSET_SOURCE/$file" ] || { echo "Auf dem Stick fehlt die Terminal-/QR-Datei: $file"; exit 1; }
done
python3 -c 'import ast,sys; ast.parse(open(sys.argv[1],encoding="utf-8-sig").read())' "$SOURCE/recovery.py"

echo 'Pruefe den Portkonflikt zwischen DLNA und Notfall-Admin ...'
CHANGED="$(python3 - /opt/raspi-tv/dlna.py <<'PY'
import ast
import os
from pathlib import Path
import shutil
import socket
import sys
import tempfile
import time

path = Path(sys.argv[1])
if not path.exists():
    print('0')
    sys.exit(0)
source = path.read_text(encoding='utf-8-sig')
tree = ast.parse(source)
assignments = [n for n in tree.body if isinstance(n, ast.Assign)
               and any(isinstance(t, ast.Name) and t.id == 'PORT' for t in n.targets)]
if len(assignments) != 1 or not isinstance(assignments[0].value, ast.Constant):
    sys.exit('DLNA-Port konnte nicht sicher erkannt werden. Datei wurde nicht veraendert.')
node = assignments[0]
if node.value.value == 8768:
    print('1')  # Auch nach einem zuvor unterbrochenen Lauf neu starten.
    sys.exit(0)
if node.value.value != 8767:
    print('0')
    sys.exit(0)
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
    try:
        probe.bind(('0.0.0.0', 8768))
    except OSError:
        sys.exit('Port 8768 ist ebenfalls belegt. Keine DLNA-Datei wurde veraendert.')
lines = source.splitlines(keepends=True)
if node.lineno != node.end_lineno:
    sys.exit('Unbekanntes DLNA-Dateiformat. Datei wurde nicht veraendert.')
line = lines[node.lineno - 1].encode('utf-8')
value = node.value
lines[node.lineno - 1] = (line[:value.col_offset] + b'8768' + line[value.end_col_offset:]).decode('utf-8')
updated = ''.join(lines)
ast.parse(updated)
backup = path.with_name(path.name + '.vor-port-reparatur-' + str(time.time_ns()))
shutil.copy2(path, backup)
fd, temporary = tempfile.mkstemp(prefix='.dlna-reparatur-', dir=str(path.parent))
try:
    with os.fdopen(fd, 'w', encoding='utf-8', newline='') as output:
        output.write(updated)
        output.flush()
        os.fsync(output.fileno())
    shutil.copymode(path, temporary)
    os.replace(temporary, path)
finally:
    if os.path.exists(temporary):
        os.unlink(temporary)
print('Sicherung: ' + str(backup), file=sys.stderr)
print('1')
PY
)"

install -d /opt/raspi-tv /opt/raspi-tv/recovery-assets
install -m 644 "$SOURCE/maintenance.py" /opt/raspi-tv/maintenance.py
install -m 644 "$SOURCE/display-diagnostics.py" /opt/raspi-tv/display-diagnostics.py
install -m 644 "$SOURCE/terminal.py" /opt/raspi-tv/recovery-assets/terminal.py
install -m 644 "$SOURCE/maintenance.js" /opt/raspi-tv/recovery-assets/maintenance.js
for file in xterm.js xterm.css xterm-addon-fit.js xterm.LICENSE.txt qrcode.js; do
  install -m 644 "$ASSET_SOURCE/$file" "/opt/raspi-tv/recovery-assets/$file"
done
install -m 755 "$SOURCE/recovery.py" /opt/raspi-tv/recovery.py
install -m 644 "$SOURCE/recovery.html" /opt/raspi-tv/recovery.html
install -m 644 "$SOURCE/raspi-tv-recovery.service" /etc/systemd/system/raspi-tv-recovery.service
systemctl daemon-reload
systemctl stop raspi-tv-recovery.service
if [ "$CHANGED" = 1 ]; then
  echo 'DLNA verwendet jetzt Port 8768. Starte den Steuerdienst neu ...'
  systemctl try-restart raspi-tv-ctl.service
fi
systemctl reset-failed raspi-tv-recovery.service || true
systemctl enable raspi-tv-recovery.service
systemctl restart raspi-tv-recovery.service

# Erfolg erst melden, wenn die HTTP-Seite wirklich antwortet.
if ! python3 - <<'PY'
import time
import urllib.request
for attempt in range(30):
    try:
        with urllib.request.urlopen('http://127.0.0.1:8767/', timeout=1) as response:
            if response.status == 200 and b'Raspi-TV Notfall-Admin' in response.read():
                break
    except Exception:
        pass
    time.sleep(0.3)
else:
    raise SystemExit(1)
PY
then
  echo 'Die Notfallseite antwortet noch nicht. Fehlerdetails:'
  journalctl -u raspi-tv-recovery.service -n 15 --no-pager || true
  ss -ltnp 'sport = :8767' || true
  exit 1
fi
if ! systemctl is-active --quiet raspi-tv-recovery.service; then
  journalctl -u raspi-tv-recovery.service -n 15 --no-pager || true
  exit 1
fi

echo
echo 'NOTFALL-ADMIN IST BEREIT.'
echo 'Am Handy oder PC im selben Netzwerk oeffnen:'
for IP in $(hostname -I); do
  case "$IP" in *:*) ;; *) echo "  http://$IP:8767/" ;; esac
done
echo
echo 'Admin-Code zum Anmelden:'
cat /var/lib/raspi-tv-recovery/admin.key
echo
echo
echo 'Der DLNA-Port und die Notfall-Dateien wurden geprueft und bei Bedarf angepasst.'
echo 'Deine Einstellungen bleiben erhalten. Ein Neustart ist nicht notwendig.'
