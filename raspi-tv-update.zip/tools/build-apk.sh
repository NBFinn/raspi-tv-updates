#!/bin/bash
# Baut die Raspi-TV-App für ältere Android-Handys (Fernbedienung über Bluetooth).
#   bash tools/build-apk.sh   ->  launcher/raspi-tv-remote.apk
# Braucht (Ubuntu/Debian): android-sdk-platform-23 aapt dalvik-exchange zipalign apksigner openjdk
# Die Oberfläche ist dieselbe Datei wie bei der WLAN-Fernbedienung (launcher/remote.html).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
A="$ROOT/android"
SDK=/usr/lib/android-sdk
JAR="$SDK/platforms/android-23/android.jar"
BT="$(ls -d "$SDK"/build-tools/* | sort -V | tail -1)"
DX="$BT/dx"; [ -x "$DX" ] || DX=dalvik-exchange
W="$(mktemp -d)"
trap 'rm -rf "$W"' EXIT

mkdir -p "$W/gen" "$W/classes" "$W/assets"
cp "$ROOT/launcher/remote.html" "$W/assets/remote.html"

aapt package -f -m -M "$A/AndroidManifest.xml" -S "$A/res" -A "$W/assets" -I "$JAR" -J "$W/gen" -F "$W/app.unsigned.apk"
javac -nowarn -Xlint:-options -source 8 -target 8 -encoding UTF-8 -bootclasspath "$JAR" -d "$W/classes" \
  $(find "$A/src" "$W/gen" -name '*.java')
"$DX" --dex --output="$W/classes.dex" "$W/classes"
( cd "$W" && aapt add app.unsigned.apk classes.dex >/dev/null )
zipalign -f 4 "$W/app.unsigned.apk" "$W/app.aligned.apk"

KS="$A/raspitv.keystore"
if [ ! -f "$KS" ]; then
  keytool -genkeypair -keystore "$KS" -storepass raspitv -keypass raspitv -alias raspitv \
    -keyalg RSA -keysize 2048 -validity 20000 -dname "CN=Raspi-TV" >/dev/null 2>&1
fi
apksigner sign --ks "$KS" --ks-pass pass:raspitv --key-pass pass:raspitv --ks-key-alias raspitv \
  --min-sdk-version 19 --out "$ROOT/launcher/raspi-tv-remote.apk" "$W/app.aligned.apk"
rm -f "$ROOT/launcher/raspi-tv-remote.apk.idsig"
echo "Fertig: launcher/raspi-tv-remote.apk ($(du -k "$ROOT/launcher/raspi-tv-remote.apk" | cut -f1) KB)"
