#!/bin/bash
# Read-only GPIO/SPI diagnosis; writes only a report next to this script.
set -eu
if [ "$(id -u)" != 0 ]; then exec sudo bash "$0" "$@"; fi
python3 - "$(cd -- "$(dirname -- "$0")" && pwd)" <<'PY'
import ast
import datetime
import hashlib
import importlib.metadata
import os
from pathlib import Path
import re
import struct
import subprocess
import sys


def read(path,limit=16000):
    try:
        with path.open('rb') as stream:return stream.read(limit).decode('utf-8','replace').replace('\0',' ').strip()
    except OSError as error:return 'Nicht lesbar: '+str(error)


def dt_property(path):
    try:
        data=path.read_bytes()[:1024]
        if not data:return '(leer)'
        if all(32<=byte<=126 or byte==0 for byte in data) and any(byte for byte in data):
            return data.decode('ascii').replace('\0',' ').strip()
        if len(data)%4==0:return 'Zellen: '+' '.join(str(v[0]) for v in struct.iter_unpack('>I',data))
        return data.hex()
    except OSError as error:return 'Nicht lesbar: '+str(error)


def boot_config(root):
    output=[];seen=set();boot=(root/'boot').resolve()
    def visit(path):
        path=path.resolve()
        if not path.is_relative_to(boot) or path in seen or len(seen)>=12:return
        seen.add(path)
        if not path.is_file():return
        output.append(str(path))
        for line in read(path,64000).splitlines():
            line=line.split('#',1)[0].strip()
            if re.match(r'^(\[|dtoverlay\s*=|dtparam\s*=|gpio\s*=|enable_uart\s*=|include\s+)',line):
                output.append(line)
            if line.startswith('include '):visit(path.parent/line[8:].strip())
    visit(root/'boot/firmware/config.txt');visit(root/'boot/config.txt')
    return '\n'.join(output) or 'Keine Boot-Konfiguration gefunden.'


def collect(root=Path('/'),run=None):
    run=run or subprocess.run
    parts=['Raspi-TV Display-Diagnose',datetime.datetime.now().isoformat(timespec='seconds'),
           'Nur gelesen: keine GPIO-Anforderung, keine Pin-/Dienst-/Boot-Aenderung.',
           'Erwartet Display 2: SPI1.0, SCL=GPIO21, SDA=GPIO20, CS=GPIO18, DC=GPIO24, RST=GPIO23.',
           '\nModell: '+read(root/'proc/device-tree/model'),
           'Systemversion: '+read(root/'opt/raspi-tv/VERSION')]
    def command(args):
        parts.append('\n$ '+' '.join(args))
        try:
            result=run(args,capture_output=True,text=True,errors='replace',timeout=5)
            parts.extend(['Exit: '+str(result.returncode),(result.stdout or '')[-16000:],(result.stderr or '')[-4000:]])
        except (OSError,subprocess.TimeoutExpired) as error:parts.append(str(error))
    command(['uname','-r'])
    parts.append('\n--- Display-Dienst ---')
    marker=root/'var/lib/raspi-tv-round/enabled-separate-pins'
    parts.append('Getrennte Belegung freigeschaltet: '+str(marker.is_file()))
    command(['systemctl','show','raspi-tv-round.service','--no-pager',
             '--property=ActiveState,SubState,ExecMainStatus,ExecMainCode'])
    driver=root/'opt/raspi-tv/round-displays.py'
    try:
        data=driver.read_bytes();parts.append('Treiber SHA256: '+hashlib.sha256(data).hexdigest())
        for node in ast.parse(data.decode('utf-8-sig')).body:
            if isinstance(node,ast.Assign):
                for target in node.targets:
                    if isinstance(target,ast.Name) and target.id in ('DISPLAY_PINS','MADCTL','SPI_SPEED'):
                        parts.append(target.id+' = '+repr(ast.literal_eval(node.value)))
    except (OSError,SyntaxError,ValueError) as error:parts.append('Treiber nicht lesbar: '+str(error))
    for package in ('gpiozero','lgpio','spidev','Pillow'):
        try:version=importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:version='keine Paket-Metadaten'
        parts.append(package+': '+version)
    parts.append('\n--- SPI-Geraete ---')
    nodes=sorted((root/'dev').glob('spidev*'))
    parts.extend(str(path) for path in nodes)
    if not nodes:parts.append('KEINE spidev-Geraete gefunden.')
    parts.append('SPI1.0 vorhanden: '+str((root/'dev/spidev1.0').exists()))
    tree=root/'proc/device-tree'
    for number in (0,1):
        name='spi'+str(number)
        alias=tree/'aliases'/name
        location=read(alias)
        parts.append('\n'+name+' Device-Tree-Alias: '+location)
        if location.startswith('/'):
            node=tree/location.lstrip('/')
            for field in ('status','compatible','cs-gpios','pinctrl-0','pinctrl-names'):
                if (node/field).exists():parts.append(field+': '+dt_property(node/field))
        dev=root/'sys/class/spi_master'/name/'device'
        parts.append('Controller: '+str(dev.resolve()))
        parts.append('Controller-Treiber: '+str((dev/'driver').resolve()))
        for cs in (0,1):
            device=root/'sys/bus/spi/devices'/f'{name}.{cs}'
            if device.exists():
                parts.append(str(device)+': '+str(device.resolve()))
                parts.append('Treiber: '+str((device/'driver').resolve()))
                parts.append('modalias: '+read(device/'modalias'))
    parts.append('\n--- Aktuelle GPIO-Funktionen (Pi 5) ---')
    for pin in (18,20,21,23,24):command(['pinctrl','get',str(pin)])
    parts.append('\n--- Boot-Konfiguration: nur Hardware-Einstellungen ---')
    parts.append(boot_config(root))
    command(['dtoverlay','-l'])
    parts.append('Hinweis: dtoverlay -l alleine zeigt nicht alle beim Booten geladenen Overlays.')
    parts.append('\n--- Letzte Display-Dienstmeldungen ---')
    command(['journalctl','-b','-u','raspi-tv-round.service','-n','45','--no-pager'])
    result='\n'.join(parts)+'\n'
    result=re.sub(r'(?im)^.*(?:password|passwd|secret|token|cookie|authorization|admin.?code|admin.?key|psk).*$','[Zugangsdaten entfernt]',result)
    return re.sub(r'([?&][^=\s&]+)=([^&\s]+)',r'\1=[ENTFERNT]',result)


def main(folder):
    print('Pruefe SPI1, GPIO-Funktionen und den Display-Dienst. Bitte kurz warten ...',flush=True)
    report=collect()
    name='display-diagnose-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'.txt'
    for directory in (Path(folder),Path('/tmp')):
        try:
            target=directory/name
            fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
            with os.fdopen(fd,'w',encoding='utf-8') as output:output.write(report)
            print('\nFERTIG. Bitte diese Datei im Chat schicken:\n'+str(target))
            print('Die Diagnose hat keine Pins oder Einstellungen veraendert.')
            return
        except OSError as error:print('Hier nicht speicherbar: '+str(error))
    raise SystemExit('Bericht konnte nicht gespeichert werden.')


if __name__=='__main__':main(sys.argv[1])
PY
