"""Isolated real HTTP fixture used by the settings browser test."""
import importlib.util
import json
from pathlib import Path
import threading
import time
import types

path = Path(__file__).with_name('test-display-settings.py')
spec = importlib.util.spec_from_file_location('settings_fixture', path)
suite = importlib.util.module_from_spec(spec); spec.loader.exec_module(suite)
fixture = suite.SettingsTest(); fixture.setUp()
suite.tv.ROOT = str(suite.ROOT/'launcher')
original = fixture.app.run
def hardware(args, **kwargs):
    if args[0] == 'uname': time.sleep(.3)
    return original(args, **kwargs)
fixture.app.run = hardware
folder=fixture.enable_displays()
devices=[types.SimpleNamespace(spi=types.SimpleNamespace(max_speed_hz=4_000_000),
                               reinitialize=lambda speed:None,show=lambda image:None) for _ in range(2)]
test=suite.driver.RoundDisplayTest(devices,folder)
normal=[suite.driver.album_frame({}),suite.driver.volume_frame(45)]
stopping=threading.Event()
def display_loop():
    while not stopping.wait(.05):test.tick(normal)
display_thread=threading.Thread(target=display_loop,daemon=True);display_thread.start()
try:
    print(json.dumps({'url':fixture.url, 'stick':str(fixture.stick)}), flush=True)
    threading.Event().wait()
finally:
    stopping.set();display_thread.join(2);test.close()
    fixture.tearDown()
