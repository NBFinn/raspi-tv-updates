#!/usr/bin/env python3
"""Raspi-TV 6.0: Ambient-Szenen für Bildschirmschoner und Musikansicht.

Rendert weiche, langsam treibende Licht-Szenen prozedural (numpy) und kodiert sie als nahtlose
Schleife (alle Bewegungen sind periodisch mit der Schleifenlänge). Feines Filmkorn verhindert
Farbstufen (Banding) auf großen Verläufen.

    python3 tools/make-ambient.py [szene …]   ->  launcher/media/ambient/*.mp4 + ambient.json
"""
import json
import math
import os
import subprocess
import sys

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "launcher", "media", "ambient")
W, H = 960, 540          # Renderauflösung, Ausgabe 1920×1080
FPS = 24
SECS = 60


def hexrgb(h):
    h = h.lstrip("#")
    return np.array([int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)], np.float32)


# (id, Name, Stil, Grundfarbe, Lichtfarben, Akzent)
SCENES = [
    ("polarlicht", "Polarlicht", "aurora", "#030a14", ["#19e3b1", "#5b4bff", "#0fb5a0", "#7cf5d0"], "#19e3b1"),
    ("ozean", "Ozean", "wellen", "#020a14", ["#0b4f8a", "#22d3ee", "#0e6aa8", "#7dd3fc"], "#22d3ee"),
    ("glut", "Glut", "blobs", "#0c0306", ["#d9364f", "#ff7a3d", "#8f1d33", "#ffb36b"], "#ff7a3d"),
    ("lavendel", "Lavendel", "blobs", "#08050f", ["#6d28d9", "#ec4899", "#a78bfa", "#3b1d8f"], "#a78bfa"),
    ("mitternacht", "Mitternacht", "sterne", "#020308", ["#1e2a78", "#3d5afe", "#90caf9", "#0a1030"], "#3d5afe"),
    ("nordwald", "Nordwald", "aurora", "#020b07", ["#22c55e", "#a3e635", "#0f766e", "#34d399"], "#34d399"),
    ("sonnenuntergang", "Sonnenuntergang", "wellen", "#0d0510", ["#f97316", "#db2777", "#facc15", "#7c3aed"], "#f97316"),
    ("tiefsee", "Tiefsee", "sterne", "#01060a", ["#0e7490", "#14b8a6", "#155e75", "#5eead4"], "#14b8a6"),
]

yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
xn, yn = xx / W, yy / H


def blob(cx, cy, r, sx=1.0):
    d = ((xn - cx) * (W / H) / sx) ** 2 + (yn - cy) ** 2
    return np.exp(-d / (2 * r * r))


def frame(style, t, cols, rng_stars):
    """t in [0,1): Phase der Schleife."""
    a = 2 * math.pi * t
    img = np.zeros((H, W, 3), np.float32)
    if style == "blobs":
        for i, c in enumerate(cols):
            fx, fy = (1, 2, 1, 3)[i], (2, 1, 3, 1)[i]
            cx = 0.5 + 0.32 * math.sin(fx * a + i * 1.7)
            cy = 0.5 + 0.28 * math.cos(fy * a + i * 2.3)
            r = 0.16 + 0.04 * math.sin(a + i)
            img += blob(cx, cy, r)[..., None] * c * 0.6
    elif style == "aurora":
        for i, c in enumerate(cols):
            ph = i * 1.9
            off = (0.10 * np.sin(2 * math.pi * (xn * (1.2 + 0.3 * i)) + a * (1 + i % 2) + ph)
                   + 0.05 * np.sin(2 * math.pi * xn * 3.1 - a * 2 + ph))
            centre = 0.30 + 0.09 * i + off
            band = np.exp(-((yn - centre) ** 2) / (2 * (0.05 + 0.02 * i) ** 2))
            # Vorhang: nach unten auslaufender Schleier
            veil = np.clip(1 - (yn - centre) * 2.2, 0, 1) * (yn > centre) * 0.35
            shimmer = 0.75 + 0.25 * np.sin(2 * math.pi * xn * 9 + a * 3 + ph)
            img += ((band + veil * band ** 0.2) * shimmer)[..., None] * c * 0.8
    elif style == "wellen":
        for i, c in enumerate(cols):
            ph = i * 1.3
            y0 = 0.35 + 0.14 * i + 0.04 * math.sin(a + ph)
            wave = y0 + 0.05 * np.sin(2 * math.pi * xn * (1 + i * 0.5) + a * (i % 3 + 1) + ph)
            d = yn - wave
            layer = np.where(d > 0, np.exp(-d * 3.0), np.exp(-(d ** 2) / 0.0012))
            img += layer[..., None] * c * (0.55 - 0.06 * i)
    elif style == "sterne":
        for i, c in enumerate(cols[:3]):
            cx = 0.5 + 0.3 * math.sin(a + i * 2.1)
            cy = 0.55 + 0.2 * math.cos(a * (1 + i % 2) + i)
            img += blob(cx, cy, 0.24, 1.4)[..., None] * c * 0.32
        sx, sy, sp, ss = rng_stars
        tw = 0.5 + 0.5 * np.sin(a * sp + ss * 6.28)
        star = np.zeros((H, W), np.float32)
        np.add.at(star, (sy, sx), tw)
        # weiches Leuchten der Sterne: kleine Unschärfe per Box-Filter
        k = star.copy()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            k += 0.35 * np.roll(np.roll(star, dx, 1), dy, 0)
        img += k[..., None] * (cols[3] * 0.5 + 0.9)
    # Vignette
    v = 1 - 0.55 * (((xn - 0.5) * 1.2) ** 2 + ((yn - 0.5) * 1.4) ** 2)
    return img * v[..., None]


def render(scene):
    sid, name, style, base, cols, accent = scene
    cols = [hexrgb(c) for c in cols]
    base = hexrgb(base)
    rng = np.random.default_rng(abs(hash(sid)) % 2 ** 32)
    n = 420
    stars = (rng.integers(0, W, n), rng.integers(0, H, n), rng.integers(1, 5, n).astype(np.float32),
             rng.random(n).astype(np.float32))
    path = os.path.join(OUT, sid + ".mp4")
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24",
           "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
           "-vf", "scale=1920:1080:flags=lanczos,noise=alls=2:allf=t,format=yuv420p",
           "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-maxrate", "2000k", "-bufsize", "4000k", "-tune", "film", "-g", "96",
           "-movflags", "+faststart", "-an", path]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    total = FPS * SECS
    for f in range(total):
        img = base + frame(style, f / total, cols, stars)
        img = 1 - np.exp(-img * 1.6)            # weiches Abrollen statt hartem Clipping
        p.stdin.write((np.clip(img, 0, 1) * 255 + 0.5).astype(np.uint8).tobytes())
    p.stdin.close()
    p.wait()
    print(sid, os.path.getsize(path) // 1024, "KB", flush=True)
    return {"id": sid, "name": name, "file": f"media/ambient/{sid}.mp4", "accent": accent, "seconds": SECS}


def main():
    os.makedirs(OUT, exist_ok=True)
    want = set(sys.argv[1:])
    meta = []
    for s in SCENES:
        path = os.path.join(OUT, s[0] + ".mp4")
        if not want or s[0] in want:
            meta.append(render(s))
        elif os.path.exists(path):
            meta.append({"id": s[0], "name": s[1], "file": f"media/ambient/{s[0]}.mp4", "accent": s[5], "seconds": SECS})
    with open(os.path.join(OUT, "..", "ambient.json"), "w") as f:
        json.dump(meta, f, ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
