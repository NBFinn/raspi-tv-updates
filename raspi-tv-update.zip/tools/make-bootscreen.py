"""Erzeugt die Bilder für die Raspi-TV-Startanimation (Plymouth).

    python3 tools/make-bootscreen.py   ->  branding/plymouth/*.png

Alle Bilder sind für 1080p gezeichnet; das Plymouth-Skript skaliert sie passend.
"""
import math
import os
from PIL import Image, ImageDraw, ImageFilter, ImageFont

OUT = os.path.join(os.path.dirname(__file__), "..", "branding", "plymouth")
SS = 4                                   # Supersampling für glatte Kanten
C1, C2 = (139, 92, 246), (34, 211, 238)   # Verlauf wie im Logo (6.0: Violett → Cyan)
K = 1.5                                  # Logo-Größe (1 = 296 px breit bei 1080p)
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"


def gradient(size, c1=C1, c2=C2):
    w, h = size
    g = Image.new("RGBA", size)
    px = g.load()
    for y in range(h):
        for x in range(w):
            t = (x / w + y / h) / 2
            px[x, y] = tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3)) + (255,)
    return g


def masked(mask, size):
    g = gradient(size)
    g.putalpha(mask)
    return g


def save(img, name, scale=1):
    if scale != 1:
        img = img.resize((max(1, round(img.width * scale)), max(1, round(img.height * scale))), Image.LANCZOS)
    img.save(os.path.join(OUT, name))
    print(name, img.size)


# Fernseher-Rahmen (ohne Play-Dreieck) – Maße wie im Logo (64×48) ×4, mit Rand für die Feder-Animation
U = 4 * SS
W, H = 64 * U + 40 * SS, 48 * U + 40 * SS
ox, oy = 20 * SS, 20 * SS
m = Image.new("L", (W, H), 0)
d = ImageDraw.Draw(m)
d.rounded_rectangle([ox + 3 * U, oy + 3 * U, ox + 61 * U, oy + 39 * U], radius=8 * U, outline=255, width=5 * U)
d.rounded_rectangle([ox + 22 * U, oy + 42 * U, ox + 42 * U, oy + 46 * U], radius=2 * U, fill=255)
save(masked(m, (W, H)), "tvframe.png", K / SS)

# Play-Dreieck (eigenes Bild, „ploppt“ nach dem Rahmen herein)
P = 22 * U
m = Image.new("L", (P, P), 0)
ImageDraw.Draw(m).polygon([(P * 0.22, P * 0.12), (P * 0.88, P * 0.5), (P * 0.22, P * 0.88)], fill=255)
save(masked(m, (P, P)), "play.png", K / SS)

# Schriftzug: „Raspi“ hell, „TV“ im Blau-Verlauf
font = ImageFont.truetype(FONT, 64 * SS)
a, b = "Raspi", "TV"
wa = font.getbbox(a)[2]
wb = font.getbbox(b)[2]
gap = 6 * SS
Hw = 84 * SS
word = Image.new("RGBA", (wa + gap + wb + 8 * SS, Hw), (0, 0, 0, 0))
ImageDraw.Draw(word).text((0, 2 * SS), a, font=font, fill=(243, 244, 247, 255))
mtv = Image.new("L", (wb + 8 * SS, Hw), 0)
ImageDraw.Draw(mtv).text((0, 2 * SS), b, font=font, fill=255)
word.alpha_composite(masked(mtv, mtv.size), (wa + gap, 0))
save(word, "word.png", K / SS)

# Weiches Leuchten hinter dem Logo
G = 900
glow = Image.new("RGBA", (G, G), (0, 0, 0, 0))
px = glow.load()
for y in range(G):
    for x in range(G):
        r = math.hypot(x - G / 2, y - G / 2) / (G / 2)
        if r < 1:
            a_ = (1 - r) ** 2.2
            px[x, y] = (61, 139, 255, int(150 * a_))
save(glow, "glow.png")

# Ring für die Druckwelle
R = 420 * SS
m = Image.new("L", (R, R), 0)
ImageDraw.Draw(m).ellipse([6 * SS, 6 * SS, R - 6 * SS, R - 6 * SS], outline=255, width=4 * SS)
m = m.filter(ImageFilter.GaussianBlur(1.2 * SS))
ring = Image.new("RGBA", (R, R), (150, 195, 255, 0))
ring.putalpha(m)
save(ring, "ring.png", K / SS)

# Lichtfunke
S_ = 28
spark = Image.new("RGBA", (S_, S_), (0, 0, 0, 0))
px = spark.load()
for y in range(S_):
    for x in range(S_):
        r = math.hypot(x - S_ / 2 + .5, y - S_ / 2 + .5) / (S_ / 2)
        if r < 1:
            px[x, y] = (200, 225, 255, int(255 * (1 - r) ** 1.6))
save(spark, "spark.png")

# Lichtstreifen, der über das Logo wischt
BW, BH = 140, 420
beam = Image.new("RGBA", (BW, BH), (0, 0, 0, 0))
px = beam.load()
for y in range(BH):
    for x in range(BW):
        t = abs(x - BW / 2) / (BW / 2)
        v = abs(y - BH / 2) / (BH / 2)
        px[x, y] = (255, 255, 255, int(110 * max(0, 1 - t) ** 2 * max(0, 1 - v ** 4)))
save(beam.rotate(-18, expand=True, resample=Image.BICUBIC), "beam.png", K)

# Fortschrittsbalken (1 Pixel, wird im Skript gestreckt)
save(Image.new("RGBA", (1, 1), (61, 139, 255, 255)), "bar.png")
save(Image.new("RGBA", (1, 1), (255, 255, 255, 40)), "bar-bg.png")

# Symbol der Handy-Fernbedienung (Startbildschirm des Handys) -> launcher/remote-icon.png
N = 512 * 2
ic = Image.new("RGBA", (N, N), (11, 13, 18, 255))
bg = Image.new("L", (N, N), 0)
ImageDraw.Draw(bg).ellipse([-N * .2, -N * .45, N * 1.2, N * .75], fill=70)
bg = bg.filter(ImageFilter.GaussianBlur(N * .12))
ic.paste(Image.new("RGBA", (N, N), (61, 139, 255, 255)), (0, 0), bg)
u = N / 100
m = Image.new("L", (N, N), 0)
d = ImageDraw.Draw(m)
d.rounded_rectangle([20 * u, 24 * u, 80 * u, 64 * u], radius=9 * u, outline=255, width=int(5.5 * u))
d.polygon([(43 * u, 35 * u), (59 * u, 44 * u), (43 * u, 53 * u)], fill=255)
d.rounded_rectangle([38 * u, 70 * u, 62 * u, 75 * u], radius=2.5 * u, fill=255)
ic.alpha_composite(masked(m, (N, N)))
# 6.0: Symbol kommt jetzt aus branding/logo/mark.svg (tools/render-logo.py)
# save(ic.convert("RGB"), os.path.join("..", "..", "launcher", "remote-icon.png"), 0.5)
