"""Raspi-TV 6.0: erzeugt die 4K-Hintergrundbibliothek (prozedural, ohne fremde Bildrechte).

    python3 tools/make-media.py            -> launcher/media/wallpapers/*.jpg (3840×2160)
                                              launcher/media/thumbs/*.jpg      (480×270)
                                             launcher/media/hd/*.jpg          (1920×1080)
                                              launcher/media/wallpapers.json

Jedes Bild ist aus Rauschen, Verläufen und weichen Formen gerechnet. Ein fester Startwert pro Bild
sorgt dafür, dass bei jedem Lauf dieselben Bilder entstehen.
"""
import json
import os
import sys

import numpy as np
from PIL import Image, ImageFilter

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT = os.path.join(ROOT, "launcher", "media")
W, H = 3840, 2160

PALETTES = {
    "nordlicht": ["#05070f", "#0b1b3a", "#11c5a7", "#6d5dfc", "#c3f7e8"],
    "ozean":     ["#020a14", "#06243f", "#0e6aa8", "#22d3ee", "#d6f6ff"],
    "glut":      ["#0d0507", "#3a0d1c", "#d9364f", "#ff9f43", "#ffe3b8"],
    "violett":   ["#07040f", "#1d0f3d", "#7c3aed", "#ec4899", "#f5d0fe"],
    "wald":      ["#030805", "#0d2a1a", "#2f9e66", "#c6e86b", "#f1fbe0"],
    "mitternacht": ["#020308", "#0a1030", "#3d5afe", "#90caf9", "#ffffff"],
    "sand":      ["#0c0806", "#33210f", "#c08a3e", "#f2c879", "#fff3dc"],
}


def hexrgb(h):
    h = h.lstrip("#")
    return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], dtype=np.float32) / 255


def ramp(t, pal):
    """t (0..1) → Farbe entlang der Palette."""
    cols = np.stack([hexrgb(c) for c in pal])
    t = np.clip(t, 0, 1) * (len(cols) - 1)
    i = np.minimum(t.astype(np.int32), len(cols) - 2)
    f = (t - i)[..., None]
    return cols[i] * (1 - f) + cols[i + 1] * f


def smooth_noise(rng, cells, w=W // 4, h=H // 4):
    small = rng.random((cells[1], cells[0])).astype(np.float32)
    img = Image.fromarray((small * 255).astype(np.uint8)).resize((w, h), Image.BICUBIC)
    return np.asarray(img, dtype=np.float32) / 255


def fbm(rng, w=W // 4, h=H // 4, octaves=5):
    out = np.zeros((h, w), np.float32)
    amp, tot = 1.0, 0.0
    for o in range(octaves):
        c = 3 * 2 ** o
        out += amp * smooth_noise(rng, (c * 16 // 9 + 1, c + 1), w, h)
        tot += amp
        amp *= 0.5
    return out / tot


def grid(w=W // 4, h=H // 4):
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    return x / w, y / h


def style_aurora(rng, pal):
    x, y = grid()
    n = fbm(rng)
    img = ramp(0.12 + 0.25 * y, pal[:2])
    for k in range(3):
        phase = rng.random() * 6.28
        center = 0.30 + 0.12 * k + 0.08 * np.sin(x * (2.5 + k) * 3.14 + phase) + 0.10 * (n - 0.5)
        band = np.exp(-((y - center) / (0.05 + 0.03 * k)) ** 2)
        curtain = band * (0.72 + 0.28 * np.sin(x * 22 + n * 5 + phase) ** 2)
        img = img + curtain[..., None] * ramp(np.full_like(x, 0.55 + 0.15 * k), pal) * (0.75 - 0.15 * k)
    stars = (rng.random(x.shape) > 0.9975) * (1 - y) * 0.9
    return img + stars[..., None]


def style_nebula(rng, pal):
    x, y = grid()
    n = fbm(rng, octaves=6)
    m = fbm(rng, octaves=4)
    t = np.clip((n - 0.25) * 1.8, 0, 1) ** 1.6
    img = ramp(t * 0.95, pal) * (0.35 + 0.9 * m[..., None])
    vign = 1 - 0.55 * ((x - 0.5) ** 2 + (y - 0.5) ** 2) * 2.2
    stars = (rng.random(x.shape) > 0.996) * rng.random(x.shape)
    return img * vign[..., None] + stars[..., None] * 0.9


def style_waves(rng, pal):
    x, y = grid()
    img = ramp(0.05 + 0.5 * (1 - y) ** 2, [pal[0], pal[1], pal[2]])
    layers = 6
    for i in range(layers):
        base = 0.45 + i * 0.09
        ridge = base + 0.05 * np.sin(x * (2 + i) * 3.14 + rng.random() * 6) + 0.025 * np.sin(x * (7 + i) * 3.14 + rng.random() * 6)
        mask = (y > ridge).astype(np.float32)
        col = ramp(np.full_like(x, 0.15 + 0.7 * (1 - i / layers)), pal)
        shade = (0.55 + 0.45 * (1 - (y - ridge).clip(0, 1) * 3))
        img = img * (1 - mask[..., None]) + (col * shade[..., None] * (0.35 + 0.1 * i)) * mask[..., None]
    sun = np.exp(-(((x - 0.7) * 1.78) ** 2 + (y - 0.36) ** 2) / 0.004)
    return img + sun[..., None] * hexrgb(pal[4]) * 0.9


def style_bokeh(rng, pal):
    x, y = grid()
    img = ramp(0.08 + 0.3 * y, pal[:3]) * 0.6
    canvas = Image.new("RGB", (W // 4, H // 4))
    layer = np.zeros((H // 4, W // 4, 3), np.float32)
    for _ in range(70):
        cx, cy, r = rng.random(), rng.random(), 0.01 + rng.random() ** 2 * 0.08
        col = ramp(np.array(0.4 + 0.6 * rng.random()), pal)
        d = ((x - cx) * 1.78) ** 2 + (y - cy) ** 2
        disk = np.clip(1 - (np.sqrt(d) - r) * 160, 0, 1) * (0.12 + 0.35 * rng.random())
        layer += disk[..., None] * col
    blurred = Image.fromarray((np.clip(layer, 0, 1) * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(3))
    del canvas
    return img + np.asarray(blurred, np.float32) / 255


def style_mesh(rng, pal):
    x, y = grid()
    img = np.zeros(x.shape + (3,), np.float32)
    wsum = np.zeros(x.shape, np.float32) + 1e-4
    for i in range(6):
        cx, cy = rng.random(), rng.random()
        w = 1 / (((x - cx) * 1.78) ** 2 + (y - cy) ** 2 + 0.02) ** 1.6
        img += w[..., None] * ramp(np.array(0.1 + 0.7 * rng.random()), pal)
        wsum += w
    img /= wsum[..., None]
    n = fbm(rng, octaves=3)
    vign = 1 - 0.6 * ((x - 0.5) ** 2 + (y - 0.5) ** 2) * 2
    return img * (0.75 + 0.3 * n[..., None]) * 0.62 * vign[..., None]


STYLES = {"aurora": ("Polarlicht", style_aurora), "nebel": ("Nebel", style_nebula), "wellen": ("Hügel", style_waves),
          "bokeh": ("Lichter", style_bokeh), "verlauf": ("Farbfluss", style_mesh)}


def finish(img, rng):
    """Hochskalieren auf 4K, leicht weichzeichnen, feines Filmkorn (gegen Farbstufen)."""
    img = np.clip(img, 0, 1)
    im = Image.fromarray((img * 255).astype(np.uint8)).resize((W, H), Image.BICUBIC).filter(ImageFilter.GaussianBlur(1.2))
    a = np.asarray(im, np.float32)
    grain = rng.normal(0, 3.2, (H, W, 1)).astype(np.float32)
    return Image.fromarray(np.clip(a + grain, 0, 255).astype(np.uint8))


def main():
    os.makedirs(os.path.join(OUT, "wallpapers"), exist_ok=True)
    os.makedirs(os.path.join(OUT, "thumbs"), exist_ok=True)
    os.makedirs(os.path.join(OUT, "hd"), exist_ok=True)
    only = sys.argv[1:]
    items = []
    seed = 600
    for sid, (sname, fn) in STYLES.items():
        for pid, pal in PALETTES.items():
            seed += 1
            name = f"{sid}-{pid}"
            items.append({"id": name, "name": f"{sname} · {pid.capitalize()}", "file": f"media/wallpapers/{name}.jpg",
                          "hd": f"media/hd/{name}.jpg", "thumb": f"media/thumbs/{name}.jpg", "accent": pal[3]})
            if only and name not in only:
                continue
            rng = np.random.default_rng(seed)
            im = finish(fn(rng, pal), rng)
            im.save(os.path.join(OUT, "wallpapers", name + ".jpg"), quality=92, optimize=True, progressive=True)
            im.resize((1920, 1080), Image.LANCZOS).save(os.path.join(OUT, "hd", name + ".jpg"), quality=90, progressive=True)
            im.resize((480, 270), Image.LANCZOS).save(os.path.join(OUT, "thumbs", name + ".jpg"), quality=82)
            print(name, os.path.getsize(os.path.join(OUT, "wallpapers", name + ".jpg")) // 1024, "KB", flush=True)
    with open(os.path.join(OUT, "wallpapers.json"), "w") as f:
        json.dump(items, f, ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
