#!/usr/bin/env python3
"""Raspi-TV: Kantengeglättete 4-Bit-Schriften (Plus Jakarta Sans) für die Teensy-Firmware erzeugen.

    python3 tools/make-teensy-fonts.py  ->  teensy/raspi-tv-displays/fonts.h

Braucht: pip install fonttools brotli pillow
"""
import io
import os

from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "launcher", "fonts", "plus-jakarta-sans-latin-wght-normal.woff2")
OUT = os.path.join(ROOT, "teensy", "raspi-tv-displays", "fonts.h")
TEXT = "".join(chr(c) for c in range(32, 127)) + "ÄÖÜäöüß°…·–"
DIGITS = " 0123456789%:-.?"
# (Name, Pixelgröße, Strichstärke, Zeichensatz)
FONTS = [("F_SMALL", 12, 600, TEXT), ("F_TEXT", 15, 600, TEXT), ("F_LABEL", 17, 700, TEXT),
         ("F_MID", 22, 650, TEXT), ("F_BIG", 36, 650, TEXT), ("F_WORD", 30, 800, TEXT),
         ("F_NUM", 62, 300, DIGITS), ("F_CLOCK", 46, 250, DIGITS)]


def ttf(weight):
    font = TTFont(SRC)
    font.flavor = None
    inst = instantiateVariableFont(font, {"wght": weight})
    buf = io.BytesIO()
    inst.save(buf)
    buf.seek(0)
    return buf


def main():
    out = ["// Automatisch erzeugt von tools/make-teensy-fonts.py – nicht von Hand ändern.",
           "// Schrift: Plus Jakarta Sans (SIL Open Font License, siehe launcher/fonts).",
           "#pragma once", "#include <stdint.h>",
           "struct Glyph { uint32_t code; uint32_t offset; uint8_t w, h; int8_t x, y; uint8_t adv; };  // adv in Viertelpixeln",
           "struct Font { const Glyph *glyphs; uint16_t count; const uint8_t *bits; uint8_t ascent, height; };", ""]
    total = 0
    for name, size, weight, chars in FONTS:
        f = ImageFont.truetype(ttf(weight), size)
        ascent, descent = f.getmetrics()
        glyphs, bits = [], bytearray()
        for ch in sorted(set(chars), key=ord):
            box = f.getbbox(ch, anchor="ls")
            adv = round(f.getlength(ch) * 4)   # Viertelpixel
            w, h = max(0, box[2] - box[0]), max(0, box[3] - box[1])
            offset = len(bits)
            if w and h:
                im = Image.new("L", (w, h))
                ImageDraw.Draw(im).text((-box[0], -box[1]), ch, font=f, fill=255, anchor="ls")
                px = list(im.tobytes())
                if len(px) % 2:
                    px.append(0)
                for i in range(0, len(px), 2):
                    bits.append((px[i] >> 4) << 4 | (px[i + 1] >> 4))
            glyphs.append((ord(ch), offset, w, h, box[0], box[1], adv))
        total += len(bits)
        out.append(f"static const uint8_t {name}_bits[] PROGMEM = {{")
        for i in range(0, len(bits), 32):
            out.append("  " + ",".join(str(b) for b in bits[i:i + 32]) + ",")
        out.append("};")
        out.append(f"static const Glyph {name}_glyphs[] PROGMEM = {{")
        for g in glyphs:
            out.append("  {%d,%d,%d,%d,%d,%d,%d}," % g)
        out.append("};")
        out.append(f"static const Font {name} = {{{name}_glyphs, {len(glyphs)}, {name}_bits, {ascent}, {ascent + descent}}};\n")
    with open(OUT, "w") as fh:
        fh.write("\n".join(out))
    print(f"{OUT}: {total // 1024} KB Glyphen")


if __name__ == "__main__":
    main()
