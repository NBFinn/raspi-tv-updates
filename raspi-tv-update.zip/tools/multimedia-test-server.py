"""Isolated real signalling/proxy fixture; never injects input or captures sound."""
import importlib.util
import json
import threading
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
media=load('fixture_media',ROOT/'system/multimedia.py')
helper=load('fixture_helper',ROOT/'windows-screen/screen_helper.py')
nav={'url':None}
mirror=media.Mirror(lambda url:nav.update(url=url))
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*_):pass
 def reply(self,code,data,kind='application/json'):
  if not isinstance(data,bytes):data=json.dumps(data).encode()
  self.send_response(code);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
 def do_GET(self):
  if self.path=='/nav':return self.reply(200,nav)
  if self.path.startswith('/mirror.html'):return self.reply(200,(ROOT/'launcher/mirror.html').read_bytes(),'text/html; charset=utf-8')
  return self.reply(404,{})
 def do_POST(self):
  data=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))))
  try:
   if self.path=='/r/pair':
    if data.get('pin')!='123456':return self.reply(403,{'error':'Falscher Code'})
    return self.reply(200,{'token':'fixture-paired'})
   if self.path=='/r/mirror':
    if self.headers.get('X-Token')!='fixture-paired':return self.reply(401,{'error':'Nicht gekoppelt'})
    return self.reply(200,mirror.request(data))
   if self.path=='/api/mirror':
    if self.headers.get('X-Raspi-TV')!='1':return self.reply(403,{})
    return self.reply(200,mirror.request(data,True))
   return self.reply(404,{})
  except ValueError as e:return self.reply(400,{'error':str(e)})
pi=ThreadingHTTPServer(('127.0.0.1',0),Handler)
threading.Thread(target=pi.serve_forever,daemon=True).start()
server=helper.Server(('127.0.0.1',0),helper.Relay(pi.server_port))
print(json.dumps({'pi':pi.server_port,'helper':server.server_port}),flush=True)
server.serve_forever()
