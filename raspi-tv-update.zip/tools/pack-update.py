#!/usr/bin/env python3
"""Raspi-TV: Update-Paket unter Linux/macOS bauen (wie Update-Paket.bat unter Windows).

    python3 tools/pack-update.py [Ziel.zip]               ->  fertig/raspi-tv-update.zip
    python3 tools/pack-update.py --ohne-medien [Ziel.zip]  ->  kleines Update ohne Medien/Schriften
                                                              (vorhandene bleiben auf dem Pi erhalten)
    python3 tools/pack-update.py --online [Ziel.zip]       ->  wie --ohne-medien, für die öffentliche
                                                              Update-Adresse: ohne App-Signaturschlüssel,
                                                              Image-Bauskript und Windows-Dateien

Linux-Textdateien (Shell, Dienste, Startdateien) bekommen LF ohne BOM; Bilder und Videos
werden unkomprimiert abgelegt (sie sind schon komprimiert, so geht das Entpacken schneller).
"""
import os
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SKIP_TOP = {"fertig", "pi-gen", "artifacts", ".git"}
SKIP_DIR = {"_metadata", "__pycache__"}
STORED = (".jpg", ".jpeg", ".png", ".mp4", ".woff2", ".apk", ".gz", ".zip", ".gif")
LINUX_TEXT_EXT = (".sh", ".service", ".rules", ".conf")
LINUX_TEXT_NAMES = {"user/xinitrc", "user/xbindkeysrc", "user/bash_profile"}


def main():
    args = [a for a in sys.argv[1:] if a not in ("--ohne-medien", "--online")]
    online = "--online" in sys.argv[1:]
    lite = online or "--ohne-medien" in sys.argv[1:]
    dst = args[0] if args else os.path.join(ROOT, "fertig", "raspi-tv-update.zip")
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    tmp = dst + ".tmp"
    n = norm = 0
    with zipfile.ZipFile(tmp, "w") as z:
        for top in sorted(os.listdir(ROOT)):
            if top in SKIP_TOP:
                continue
            path = os.path.join(ROOT, top)
            files = [path] if os.path.isfile(path) else [
                os.path.join(d, f) for d, ds, fs in os.walk(path) for f in fs
                if not (SKIP_DIR & set(os.path.relpath(d, ROOT).split(os.sep)))]
            for full in sorted(files):
                name = os.path.relpath(full, ROOT).replace(os.sep, "/")
                if lite and name.startswith(("launcher/media/", "launcher/fonts/")):
                    continue
                if online and (name.startswith(("android/", "windows-screen/")) or name.endswith((".bat", ".ps1", ".keystore"))
                               or name == "build.sh"):
                    continue
                with open(full, "rb") as f:
                    data = f.read()
                body = data[3:] if data.startswith(b"\xef\xbb\xbf") else data
                if name.endswith(LINUX_TEXT_EXT) or name in LINUX_TEXT_NAMES or \
                        os.path.basename(name) == "00-packages-nr" or body.startswith(b"#!"):
                    data = body.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
                    norm += 1
                comp = zipfile.ZIP_STORED if name.lower().endswith(STORED) else zipfile.ZIP_DEFLATED
                info = zipfile.ZipInfo(name, date_time=(2026, 11, 12, 12, 0, 0))
                info.external_attr = (0o755 if data.startswith(b"#!") else 0o644) << 16
                z.writestr(info, data, compress_type=comp, compresslevel=9 if comp == zipfile.ZIP_DEFLATED else None)
                n += 1
    os.replace(tmp, dst)
    print(f"{n} Dateien gepackt; {norm} Linux-Textdateien mit LF ohne BOM -> {dst} "
          f"({os.path.getsize(dst) / 1e6:.1f} MB)")


if __name__ == "__main__":
    main()
