import base64
import importlib.util
import json
import shutil
from pathlib import Path
import sys
import tempfile
import threading
import time
import types
import zipfile
from http.server import ThreadingHTTPServer

root=Path(sys.argv[1])
spec=importlib.util.spec_from_file_location('browser_recovery',root/'system/recovery.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
temporary=tempfile.TemporaryDirectory()
r.STATE=Path(temporary.name)/'state';r.STATE.mkdir()
stick=Path(temporary.name)/'usb';stick.mkdir()
shutil.copyfile(root/'fertig/raspi-tv-update.zip',stick/'raspi-tv-update-5.6.0.zip')
program=Path(temporary.name)/'program'
(program/'recovery-assets').mkdir(parents=True)
shutil.copyfile(root/'system/recovery.html',program/'recovery.html')
shutil.copyfile(root/'VERSION',program/'VERSION')
assets=root/'launcher' if (root/'launcher/xterm.js').exists() else root/'system/recovery-assets'
for name in ['xterm.js','xterm.css','xterm-addon-fit.js','qrcode.js']:
 shutil.copyfile(assets/name,program/'recovery-assets'/name)
shutil.copyfile(root/'system/maintenance.js',program/'recovery-assets/maintenance.js')
shutil.copyfile(root/'system/maintenance.py',program/'maintenance.py')
shutil.copyfile(root/'system/display-diagnostics.py',program/'display-diagnostics.py')
r.ROOT=program;r.KEY='0042'
(r.STATE/'admin.key').write_text('0042')
r.command=lambda args:'Steuerdienst ausgefallen (Test). Der Notfall-Admin arbeitet unabhaengig.'
r.usb_roots=lambda:([(stick,'TEST-USB')],[])
class Shell:
 def __init__(self):self.alive=True;self.output=b'root@raspi-tv:/# ';self.condition=threading.Condition()
 def info(self):return {'id':'recovery-admin','alive':self.alive}
 def write(self,data):
  with self.condition:self.output+=data.encode();self.output+=b'root@raspi-tv:/# ';self.condition.notify_all()
 def resize(self,cols,rows):pass
 def read(self,since,wait):
  with self.condition:
   if since>=len(self.output) and self.alive:self.condition.wait(min(wait,1))
   return {'data':base64.b64encode(self.output[since:]).decode(),'seq':len(self.output),'reset':False,'alive':self.alive,'code':0 if not self.alive else None}
shell=Shell()
def stop(sid):
 with shell.condition:shell.alive=False;shell.condition.notify_all()
r.terminal_backend=lambda:types.SimpleNamespace(start=lambda *args,**kwargs:shell,get=lambda sid:shell,stop=stop)
def install():
 r.JOB.update(running=False,step='Test: Installation ausgeloest.',error=None)
r.install_worker=install

app=r.maintenance()
fake_system=Path(temporary.name)/'system'
(fake_system/'proc/device-tree').mkdir(parents=True)
(fake_system/'proc/device-tree/model').write_bytes(b'Raspberry Pi 5 Model B\0')
app.system_root=fake_system;app.config=fake_system/'var/lib/raspi-tv';app.home=fake_system/'home/tv'
app.config.mkdir(parents=True)
(app.config/'config.json').write_text('{"password":"DO_NOT_EXPORT"}')
(app.home/'Downloads').mkdir(parents=True)
(app.home/'Downloads/old-video.bin').write_bytes(b'x'*1000)
(app.home/'.config').mkdir()
(app.home/'.config/private-canary').write_text('KEEP')
cache=fake_system/'var/cache/raspi-tv';cache.mkdir(parents=True)
(cache/'thumbnail.tmp').write_bytes(b'x'*2000)
class Connection:
 def __enter__(self):return self
 def __exit__(self,*args):pass
app.connector=lambda *args,**kwargs:Connection()
class Sound:
 def poll(self):return 0
 def wait(self,timeout=None):return 0
 def terminate(self):pass
 def kill(self):pass
app.spawn=lambda *args,**kwargs:Sound()
def hardware(args,timeout=10,check=True):
 output=''
 if args[:3]==['id','-u','tv']:output='1000'
 elif args[:2]==['hostname','-I']:output='192.168.1.20'
 elif args[:3]==['ip','-j','address']:output='[{"addr_info":[{"family":"inet","scope":"global","local":"192.168.1.20"}]}]'
 elif args[:2]==['iw','dev']:output='Interface wlan0' if len(args)==2 else 'Connected to test-router'
 elif args[0]=='findmnt':output='ro,nosuid,nodev,noexec'
 elif 'xrandr' in args and '--query' in args:output='HDMI-1 connected primary 1920x1080+0+0\n   1920x1080 60.00*+ 50.00\n   1280x720 60.00\n'
 elif 'pw-dump' in args:output='[{"id":42,"type":"PipeWire:Interface:Node","info":{"props":{"media.class":"Audio/Sink","node.description":"HDMI TV"}}}]'
 elif args[0]=='/bin/bash':
  import subprocess
  bash=r'C:\Program Files\Git\bin\bash.exe' if sys.platform=='win32' else '/bin/bash'
  result=subprocess.run([bash]+args[1:],capture_output=True,text=True,timeout=20)
  if result.returncode:raise ValueError(result.stderr)
 return types.SimpleNamespace(returncode=0,stdout=output,stderr='')
app.run=hardware
def sandbox_install(source,target,workspace):
 import subprocess
 assert target.resolve().is_relative_to(workspace.resolve())
 assert workspace.resolve().is_relative_to(r.STATE.resolve())
 bash=r'C:\Program Files\Git\bin\bash.exe' if sys.platform=='win32' else '/bin/bash'
 result=subprocess.run([bash,str(source/'system/install-files.sh').replace('\\','/'),str(source).replace('\\','/'),str(target).replace('\\','/')],capture_output=True,text=True,timeout=60)
 if result.returncode:raise ValueError(result.stderr)
 return result.stdout
app._sandbox_install=sandbox_install

class BrowserHandler(r.Handler):
 def do_POST(self):
  if self.path=='/fixture/cec-key':
   if not self.authorized():return
   data=r.read_json(self)
   path=fake_system/'run/raspi-tv/cec-last-key.json';path.parent.mkdir(parents=True,exist_ok=True)
   path.write_text(json.dumps({'at':time.monotonic(),'code':int(data['code']),'name':'KEY_RED'}))
   return self.reply(200,{'ok':True})
  return super().do_POST()
 def do_GET(self):
  if self.path=='/broken-launcher':
   watch=(root/'launcher/bootwatch.js').read_text(encoding='utf-8').replace(':8767',':'+str(self.server.server_port))
   return self.reply(200,'<html><body><script>'+watch+'</script><script>throw new Error("Launcher start failed test")</script></body></html>','text/html; charset=utf-8')
  return super().do_GET()
http=ThreadingHTTPServer(('127.0.0.1',0),BrowserHandler)
print(json.dumps({'port':http.server_port}),flush=True)
http.serve_forever()
