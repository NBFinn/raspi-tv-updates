"""Refresh only the bundled UI of an existing APK; sign the result afterwards.
For changes to Java/resources use build-apk.sh instead.
"""
import re
import struct
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
u16 = lambda data, pos: struct.unpack_from('<H', data, pos)[0]
u32 = lambda data, pos: struct.unpack_from('<I', data, pos)[0]


def patch_manifest(data, version_code, version_name):
    data = bytearray(data)
    strings = []
    locations = []
    pos = u16(data, 2)
    while pos < len(data):
        kind, header, size = struct.unpack_from('<HHI', data, pos)
        if not size or pos + size > len(data):
            raise ValueError('Invalid binary manifest chunk')
        if kind == 1:  # Android string pool
            count, flags, start = u32(data, pos + 8), u32(data, pos + 16), u32(data, pos + 20)
            if flags & 0x100:
                raise ValueError('UTF-8 manifests require a full SDK build')
            for i in range(count):
                at = pos + start + u32(data, pos + header + 4 * i)
                length = u16(data, at)
                if length & 0x8000:
                    raise ValueError('Unexpected long manifest string')
                raw = bytes(data[at + 2:at + 2 + length * 2])
                strings.append(raw.decode('utf-16le'))
                locations.append((at + 2, length * 2))
        elif kind == 0x102:  # start element, ResXMLTree_attrExt
            ext = pos + header
            if strings[u32(data, ext + 4)] == 'manifest':
                first = ext + u16(data, ext + 8)
                stride, count = u16(data, ext + 10), u16(data, ext + 12)
                found = set()
                for i in range(count):
                    at = first + i * stride
                    name = strings[u32(data, at + 4)]
                    if name == 'versionCode':
                        assert data[at + 15] == 0x10
                        struct.pack_into('<I', data, at + 16, version_code)
                        found.add(name)
                    elif name == 'versionName':
                        assert data[at + 15] == 3
                        start, length = locations[u32(data, at + 16)]
                        value = version_name.encode('utf-16le')
                        if len(value) != length:
                            raise ValueError('Version string length changed; use build-apk.sh')
                        data[start:start + length] = value
                        found.add(name)
                if found != {'versionCode', 'versionName'}:
                    raise ValueError('Manifest version attributes missing')
        pos += size
    return bytes(data)


def write_aligned(out, entry, data):
    entry.extra = b''
    if entry.compress_type == zipfile.ZIP_STORED:
        offset = out.fp.tell() + 30 + len(entry.filename.encode('utf-8'))
        padding = (-offset) % 4
        if padding:
            entry.extra = struct.pack('<HH', 0xffff, padding) + bytes(padding)
    out.writestr(entry, data)


def main():
    if sys.argv[1] == '--align':
        # Safe after jarsigner (v1 signatures cover contents, not ZIP offsets).
        # Do not use this on an APK signed with v2/v3; use SDK zipalign before apksigner.
        src_path, dst_path = Path(sys.argv[2]), Path(sys.argv[3])
        if src_path.resolve() == dst_path.resolve():
            raise ValueError('Use a separate output file')
        with zipfile.ZipFile(src_path) as src, zipfile.ZipFile(dst_path, 'w') as out:
            for entry in src.infolist():
                write_aligned(out, entry, src.read(entry))
        print(f'Aligned v1-signed APK: {dst_path}')
        return
    dst = Path(sys.argv[1])
    manifest = (ROOT / 'android/AndroidManifest.xml').read_text(encoding='utf-8')
    code = int(re.search(r'versionCode="(\d+)"', manifest)[1])
    name = re.search(r'versionName="([^"]+)"', manifest)[1]
    with zipfile.ZipFile(ROOT / 'launcher/raspi-tv-remote.apk') as src, zipfile.ZipFile(dst, 'w') as out:
        for entry in src.infolist():
            if entry.filename.upper().startswith('META-INF/'):
                continue  # signatures must be regenerated with the existing project key
            data = src.read(entry)
            if entry.filename == 'assets/remote.html':
                data = (ROOT / 'launcher/remote.html').read_bytes()
            elif entry.filename == 'AndroidManifest.xml':
                data = patch_manifest(data, code, name)
            write_aligned(out, entry, data)
    print(f'Prepared UI update {name} ({code}): {dst}')


if __name__ == '__main__':
    main()
