import os
from playwright.sync_api import sync_playwright
R = os.path.abspath(os.path.join(os.path.dirname(__file__), "..")); L = R + "/branding/logo"
with sync_playwright() as p:
    b = p.chromium.launch()
    def mark(size, out, pad=0, bg=None):
        pg = b.new_page(viewport={"width": size, "height": size}, device_scale_factor=1)
        bgcss = f"background:{bg};" if bg else "background:transparent;"
        svg = open(L + "/mark.svg").read().replace("<svg ", f'<svg width="{size-2*pad}" height="{size-2*pad}" style="margin:{pad}px;display:block" ', 1)
        pg.set_content(f'<html><body style="margin:0;{bgcss}">{svg}</body></html>')   # eingebettet: file://-Bilder lädt set_content nicht
        pg.wait_for_timeout(200); pg.screenshot(path=out, omit_background=not bg); pg.close()
    mark(512, R + "/launcher/remote-icon.png")
    mark(192, R + "/android/res/drawable/icon.png")
    mark(512, L + "/mark-512.png")
    mark(132, L + "/mark-132.png")
    pg = b.new_page(device_scale_factor=1); pg.goto(f"file://{L}/logo.html"); pg.wait_for_timeout(500)
    pg.locator("#word").screenshot(path=R + "/branding/plymouth/word.png", omit_background=True)
    pg.locator("#lockup").screenshot(path=L + "/lockup.png")
    pg.close(); b.close()
