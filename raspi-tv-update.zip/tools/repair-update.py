"""Narrow recovery fix for the systemd-run preflight EINVAL; no update bypass."""
import ast
import datetime
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
import urllib.request

OLD='--property=RestrictAddressFamilies=none'
FILTER='--property=SystemCallFilter=~@network-io'
ERRNO='--property=SystemCallErrorNumber=EPERM'


def repair(path):
    path=Path(path).resolve(strict=True)
    source=path.read_text(encoding='utf-8-sig')
    tree=ast.parse(source)
    cls=next((n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Maintenance'),None)
    fn=next((n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_sandbox_install'),None) if cls else None
    if fn is None:raise ValueError('Unbekannte Wartungsdatei. Keine Aenderung.')
    constants=[n for n in ast.walk(fn) if isinstance(n,ast.Constant) and isinstance(n.value,str)]
    values=[n.value for n in constants]
    if OLD not in values and FILTER in values and ERRNO in values:return None
    targets=[n for n in constants if n.value==OLD]
    if len(targets)!=1 or targets[0].lineno!=targets[0].end_lineno:
        raise ValueError('Die bekannte Fehlerstelle wurde nicht eindeutig gefunden. Keine Aenderung.')
    node=targets[0];lines=source.encode('utf-8').splitlines(keepends=True)
    line=lines[node.lineno-1]
    lines[node.lineno-1]=line[:node.col_offset]+(repr(FILTER)+', '+repr(ERRNO)).encode('utf-8')+line[node.end_col_offset:]
    updated=b''.join(lines)
    ast.parse(updated.decode('utf-8'))
    backup=path.with_name(path.name+'.vor-update-reparatur-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
    shutil.copy2(path,backup)
    fd,name=tempfile.mkstemp(prefix='.update-reparatur-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as output:output.write(updated);output.flush();os.fsync(output.fileno())
        os.chmod(name,path.stat().st_mode & 0o777)
        os.replace(name,path)
    finally:Path(name).unlink(missing_ok=True)
    return backup


def main():
    if os.geteuid()!=0:raise SystemExit('Bitte mit sudo starten.')
    # Check the replacement against the actual manager before touching installed files.
    command=['systemd-run','--wait','--pipe','--collect','--quiet',FILTER,ERRNO,'/bin/true']
    result=subprocess.run(command,capture_output=True,text=True,timeout=20)
    if result.returncode:raise SystemExit('Der Linux-Test scheitert; keine Aenderung:\n'+result.stderr)
    backup=repair('/opt/raspi-tv/maintenance.py')
    print('Sicherung: '+str(backup) if backup else 'Die Korrektur ist bereits vorhanden.',flush=True)
    subprocess.run(['systemctl','restart','raspi-tv-recovery.service'],check=True,timeout=20)
    for attempt in range(30):
        try:
            with urllib.request.urlopen('http://127.0.0.1:8767/',timeout=1) as response:
                if response.status==200 and b'Raspi-TV Notfall-Admin' in response.read(200000):break
        except OSError:pass
        time.sleep(.3)
    else:raise SystemExit('Korrektur gespeichert, aber die Notfallseite antwortet nicht. Bitte diese Meldung fotografieren.')
    print('\nNOTFALLSEITE IST BEREIT. Bitte im Browser neu laden.\n')
    key=Path('/var/lib/raspi-tv-recovery/admin.key')
    if key.is_file():print('Dein vorhandener Admin-Code: '+key.read_text().strip())
    print('\nJetzt raspi-tv-update.zip (Version 5.8.3) waehlen und den Probelauf erneut starten.')
    print('Die Update-Pruefung bleibt aktiv. Es wurde kein Update ungeprueft installiert.')
    print('Der separate Startfehler der TV-Oberflaeche ist damit noch nicht diagnostiziert.')


if __name__=='__main__':
    try:main()
    except (OSError,ValueError,subprocess.SubprocessError) as error:
        raise SystemExit('Reparatur nicht abgeschlossen: '+str(error))
