#!/bin/bash
# Im Display-Reparaturpaket heisst diese Datei start.sh.
set -euo pipefail
if [ "$(id -u)" != 0 ]; then exec sudo bash "$0" "$@"; fi
folder="$(cd -- "$(dirname -- "$0")" && pwd)"
source_file="$folder/round-displays.py"
target=/opt/raspi-tv/round-displays.py
[ -f "$source_file" ] && [ -f "$target" ] || { echo 'Display-Treiber fehlt. Bitte das gesamte Paket entpacken.'; exit 1; }
[ -f /var/lib/raspi-tv-round/enabled-separate-pins ] || {
    echo 'Die getrennte Display-Belegung ab 5.8.1 ist noch nicht freigeschaltet.'
    echo 'Bitte zuerst die Verkabelung und Aktivierung laut Runde-Displays.md pruefen.'
    exit 1
}
python3 -c 'import ast,sys,spidev,gpiozero,PIL; ast.parse(open(sys.argv[1],encoding="utf-8").read())' "$source_file"
backup="$(mktemp /opt/raspi-tv/round-displays.py.vor-display-reparatur.XXXXXXXX)"
cp -p -- "$target" "$backup"
echo "Sicherung: $backup"
was_active=0
if systemctl is-active --quiet raspi-tv-round.service; then was_active=1; fi
success=0
installed=0
cleanup() {
    result=$?
    trap - EXIT
    if [ "$success" != 1 ] && [ "$installed" = 1 ]; then
        cp -p -- "$backup" "$target" || true
        echo 'Der Test wurde nicht abgeschlossen. Vorheriger Treiber wiederhergestellt.'
    fi
    if [ "$was_active" = 1 ]; then
        if ! systemctl restart raspi-tv-round.service; then
            echo 'Der Display-Dienst konnte nicht neu gestartet werden.'
            result=1
        fi
    fi
    exit "$result"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
systemctl stop raspi-tv-round.service
installed=1
install -m 755 "$source_file" "$target"
echo 'Spiegelkorrektur und langsamere SPI-Uebertragung werden getestet.'
python3 "$target" --test
success=1
echo 'Treiberkorrektur gespeichert. Die normale Anzeige wird wieder gestartet, wenn sie vorher lief.'
echo 'Bleibt Display 1 hell: den Pi vor jeder Kabelpruefung vom Strom trennen.'
echo 'Display 1: VCC=1 GND=6 SCL=23 SDA=19 DC=22 CS=24 RST=13 (physische Pi-Pins).'
