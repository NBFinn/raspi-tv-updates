#!/bin/bash
# Im Rettungspaket heisst diese Datei start.sh.
set -eu
if [ "$(id -u)" != 0 ]; then exec sudo bash "$0" "$@"; fi
folder="$(cd -- "$(dirname -- "$0")" && pwd)"
[ -f "$folder/repair-update.py" ] || { echo 'Bitte das gesamte Reparaturpaket entpacken, nicht nur start.sh.'; exit 1; }
exec python3 "$folder/repair-update.py"
