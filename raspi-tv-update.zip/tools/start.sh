#!/bin/bash
# Raspi-TV: Admin-Code direkt an der Konsole anzeigen, Startfehler einsammeln.
set -eu
if [ "$(id -u)" != 0 ]; then
    exec sudo bash "$0" "$@"
fi
command -v python3 >/dev/null || { echo 'Python 3 fehlt auf diesem Pi.'; exit 1; }
python3 - "$(cd -- "$(dirname -- "$0")" && pwd)" <<'PY'
import datetime
import json
import os
from pathlib import Path
import re
import subprocess
import sys


def read_tail(path, limit=40000):
    try:
        with path.open('rb') as stream:
            stream.seek(0, 2)
            stream.seek(max(0, stream.tell()-limit))
            return stream.read(limit).decode('utf-8', 'replace')
    except OSError as error:
        return 'Nicht lesbar: '+str(error)


def secrets_on_pi(root):
    values=[]
    try:
        code=(root/'var/lib/raspi-tv-recovery/admin.key').read_text().strip()
    except OSError:
        code=''
    if code:values.append(code)
    def walk(value):
        if isinstance(value,dict):
            for key,item in value.items():
                if re.search(r'password|passwd|token|secret|cookie|authorization|key|pin|psk',key,re.I) and isinstance(item,(str,int)):
                    if len(str(item))>=4:values.append(str(item))
                else:walk(item)
        elif isinstance(value,list):
            for item in value:walk(item)
    try:walk(json.loads((root/'var/lib/raspi-tv/config.json').read_text()))
    except (OSError,ValueError):pass
    return code,values


def redact(text,values):
    for value in sorted(set(values),key=len,reverse=True):
        text=text.replace(value,'[ENTFERNT]')
    text=re.sub(r'(?im)^.*(?:password|passwd|token|secret|cookie|authorization|admin.?code|admin.?key|psk|api.?key).*$','[Zugangsdaten entfernt]',text)
    text=re.sub(r'([?&][^=\s&]+)=([^&\s]+)',r'\1=[ENTFERNT]',text)
    return re.sub(r'(?i)(https?://)[^/\s:@]+:[^@\s]+@',r'\1[ENTFERNT]@',text)


def collect(root,values,run=None):
    run=run or subprocess.run
    parts=['Raspi-TV Startdiagnose',datetime.datetime.now().isoformat(timespec='seconds')]
    for name in ('opt/raspi-tv/VERSION','var/lib/raspi-tv-recovery/frontend.log','var/log/raspi-tv/x.log','var/log/raspi-tv-swupdate.log'):
        parts.extend(['\n--- '+name+' ---',read_tail(root/name)])
    commands=[['systemctl','--no-pager','--full','status','raspi-tv-ctl.service','raspi-tv-recovery.service','getty@tty1.service'],
              ['journalctl','-b','-u','raspi-tv-ctl.service','-u','raspi-tv-recovery.service','-u','getty@tty1.service','-n','100','--no-pager']]
    for command in commands:
        parts.append('\n--- '+' '.join(command)+' ---')
        try:
            result=run(command,capture_output=True,text=True,errors='replace',timeout=12)
            parts.extend([(result.stdout or '')[-80000:],(result.stderr or '')[-10000:]])
        except (OSError,subprocess.TimeoutExpired) as error:parts.append(str(error))
    return redact('\n'.join(parts)+'\n',values)


def main(folder):
    root=Path('/')
    code,values=secrets_on_pi(root)
    print('\n========== RASPI-TV NOTFALLHILFE ==========\n')
    if re.fullmatch(r'[0-9]{4}',code):
        print('DEIN ADMIN-CODE:  '+code+'\n')
        print('Diesen Code auf der bereits geoeffneten Notfallseite eingeben.')
    elif code:
        print('Gespeicherter aelterer Admin-Schluessel: '+code)
        print('Falls die Seite nur vier Ziffern erlaubt, ist der Dienststand zu pruefen.')
    else:
        print('Kein Admin-Code gefunden. Der Code wurde nicht veraendert.')
        print('Die Startdiagnose hilft bei der Suche nach dem fehlenden Notfalldienst.')
    print('\nSammle die letzten Startfehler ...')
    report=collect(root,values)
    filename='raspi-tv-startfehler-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'.txt'
    for directory in (Path(folder),Path('/tmp')):
        path=directory/filename
        try:
            fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
            with os.fdopen(fd,'w',encoding='utf-8') as output:output.write(report)
            print('\nFehlerbericht gespeichert: '+str(path))
            print('Den Fehlerbericht kannst du fuer die Fehlersuche weitergeben.')
            break
        except OSError as error:print('Bericht hier nicht speicherbar: '+str(error))
    else:print('Fehlerbericht konnte nicht gespeichert werden.')
    print('\nDer Admin-Code wurde nur hier angezeigt, nicht in den Bericht geschrieben.')
    print('Zur TV-/Notfallseite zurueck: Strg + Alt + F1.')
    print('Es wurden keine Dienste, Einstellungen oder Updates veraendert.\n')


if __name__=='__main__':main(sys.argv[1])
PY
