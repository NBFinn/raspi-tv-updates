"""7.8: Bluetooth-Tonausgleich, Pflege, Heimnetz-Schutz, Logos."""
import importlib.util
import json
import tempfile
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('features', ROOT / 'system/features.py')
f = importlib.util.module_from_spec(spec)
spec.loader.exec_module(f)

CARDS = """Card #52
	Name: alsa_card.platform-hdmi
	Ports:
		hdmi-output-0: HDMI (type: HDMI, priority: 5900, latency offset: 0 usec, availability unknown)
Card #77
	Name: bluez_card.AA_BB_CC_DD_EE_01
	Driver: module-bluez5-device.c
	Properties:
		device.description = "Sony WH-1000XM5"
	Profiles:
		a2dp-sink: High Fidelity Playback (A2DP Sink) (sinks: 1, sources: 0, priority: 16, available: yes)
	Active Profile: a2dp-sink
	Ports:
		headphone-output: Headphone (type: Headphones, priority: 0, latency offset: 150000 usec, available)
			Part of profile(s): a2dp-sink
		headphone-input: Headphone (type: Headphones, priority: 0, latency offset: 0 usec, availability unknown)
"""


class T78(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.cfg = {}
        self.cmds = []
        f.bind({'load_config': lambda: self.cfg, 'save_config': lambda c: self.cfg.update(c),
                'as_tv': self.as_tv, 'run': self.fake_run, 'tv_power': lambda: 'standby', 'TV_USER': 'tv',
                'ApiError': Exception, 'STATE_DIR': self.tmp.name})
        f._state = lambda n: str(Path(self.tmp.name) / n)

    def tearDown(self):
        self.tmp.cleanup()

    def as_tv(self, cmd, timeout=15):
        self.cmds.append(cmd)
        if 'cards' in cmd:
            return 0, CARDS, ''
        if 'sink-inputs' in cmd:
            return 0, '', ''
        return 0, '', ''

    def fake_run(self, cmd, timeout=15):
        self.cmds.append(cmd)
        if cmd[0] == 'pgrep':
            return 0, '1234\n', ''
        if cmd[0] == 'ps':
            return 0, ' 50000\n', ''
        return 0, '', ''

    def test_bt_cards_and_apply(self):
        c = f._bt_cards()
        self.assertEqual(c, [{'mac': 'AA:BB:CC:DD:EE:01', 'name': 'Sony WH-1000XM5', 'card': 'bluez_card.AA_BB_CC_DD_EE_01',
                              'ports': {'headphone-output': 150}}])
        f.bt_delay_set({'mac': 'aa:bb:cc:dd:ee:01', 'ms': 200})
        self.assertIn(['pactl', 'set-port-latency-offset', 'bluez_card.AA_BB_CC_DD_EE_01', 'headphone-output', '200000'], self.cmds)
        self.assertEqual(self.cfg['bt_delay'], {'AA:BB:CC:DD:EE:01': 200})
        self.assertTrue(f.bt_delay_valid({'AA:BB:CC:DD:EE:01': 200}))
        self.assertFalse(f.bt_delay_valid({'x': 1}))
        self.assertEqual(f.bt_delay_status()['devices'][0]['ms'], 200)

    def test_fstab(self):
        self.assertIn('defaults,noatime,commit=60', f._fstab_root_opts('PARTUUID=1-02 / ext4 defaults 0 1\n'))
        self.assertIn('defaults,noatime,commit=60', f._fstab_root_opts('PARTUUID=1-02 / ext4 defaults,relatime 0 1\n'))
        self.assertIsNone(f._fstab_root_opts('PARTUUID=1-02 / ext4 defaults,noatime,commit=30 0 1\n'))
        self.assertIsNone(f._fstab_root_opts('PARTUUID=1-02 / btrfs defaults 0 1\n'))

    def test_night_refresh(self):
        at3 = time.mktime((2026, 11, 18, 3, 30, 0, 0, 0, -1))
        at9 = time.mktime((2026, 11, 18, 9, 0, 0, 0, 0, -1))
        self.assertTrue(f.night_refresh_due(at3))
        self.assertFalse(f.night_refresh_due(at9))
        f.night_refresh()
        self.assertFalse(f.night_refresh_due(at3 + 60))       # heute schon
        self.assertIn(['pkill', '-u', 'tv', '-f', 'raspi-tv-browser'], self.cmds)
        self.cfg['night_refresh'] = False
        self.assertFalse(f.night_refresh_due(at3 + 86400))

    def test_guard_rules(self):
        r = f.lan_guard_rules(['192.168.178.0/24', '203.0.113.0/24'], ['2001:db8:1:2::/64'])
        self.assertIn('192.168.0.0/16', r)
        self.assertNotIn('192.168.178.0/24', r)          # in 192.168/16 enthalten → zusammengefasst
        self.assertIn('203.0.113.0/24', r)
        self.assertIn('2001:db8:1:2::/64', r)
        self.assertIn('ct state new counter drop', r)

    def test_logo_only_known(self):
        f.all_channels = lambda include_hidden=False: [{'name': 'A', 'logo': 'https://x.example/a.png', 'url': 'u'}]
        f._logo['at'] = 0
        self.assertTrue(f._logo_allowed('https://x.example/a.png'))
        self.assertFalse(f._logo_allowed('http://192.168.1.1/admin'))
        f._download = lambda url, limit, timeout: b'\x89PNG\r\n\x1a\n' + b'0' * 20
        p, ct = f.logo_file('https://x.example/a.png')
        self.assertTrue(p.endswith('.png') and ct == 'image/png')
        f._download = lambda url, limit, timeout: b'<svg></svg>'
        self.assertIsNone(f.logo_file('https://x.example/b.svg'))


if __name__ == '__main__':
    unittest.main()
