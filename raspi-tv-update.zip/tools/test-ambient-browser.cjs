const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {chromium}=require('playwright');
const root=path.resolve(__dirname,'..'),read=n=>fs.readFileSync(path.join(root,n),'utf8');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.BROWSER_EXECUTABLE,args:['--autoplay-policy=no-user-gesture-required']});
 try{
 const page=await browser.newPage({viewport:{width:1280,height:720}}),errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 const wav=Buffer.alloc(44+8000*2*60);wav.write('RIFF');wav.writeUInt32LE(wav.length-8,4);wav.write('WAVEfmt ',8);wav.writeUInt32LE(16,16);wav.writeUInt16LE(1,20);wav.writeUInt16LE(1,22);wav.writeUInt32LE(8000,24);wav.writeUInt32LE(16000,28);wav.writeUInt16LE(2,32);wav.writeUInt16LE(16,34);wav.write('data',36);wav.writeUInt32LE(wav.length-44,40);
 let meterRequests=0;
 await page.route('http://127.0.0.1:8765/**',route=>{if(new URL(route.request().url()).pathname==='/api/audio-meter'){meterRequests++;return route.fulfill({json:{available:true,fresh:true,level:.5,bands:[.1,.2,.4,.8,.9,.6,.4,.2,.1,.05]}});}return route.fulfill({contentType:'text/html; charset=utf-8',body:`<meta charset="utf-8"><style>${read('launcher/style.css')}</style><div id="modals"></div><audio id="music" loop src="data:audio/wav;base64,${wav.toString('base64')}"></audio><script>${read('launcher/app.js')}</script><script>${read('launcher/extras.js')}</script><script>${read('launcher/extras7.js')}</script><script>const I18N={lang:'de'}; const Radio={current:{name:'Test-Radio'},audio:document.querySelector('audio')}; const SpotifyNow={cur:null,control(action){window.controls.push(action);}};window.controls=[];state.config={motion:'full',screensaver_min:0};window.chrome={runtime:{sendMessage(m,cb){window.messages.push(m);if(cb)cb({});},onMessage:{addListener(){}}}};window.messages=[];</script><script>${read('extension/keys.js')}</script><script>${read('launcher/ambient.js')}</script><script>${read('launcher/multimedia.js')}</script><script>Saver.init();</script>`});});
 await page.goto('http://127.0.0.1:8765/');
 await page.locator('audio').evaluate(a=>a.play());
 await page.waitForFunction(()=>document.querySelector('audio').currentTime>.1);
 const source=await page.locator('audio').getAttribute('src');
 for(const style of ['aurora','stars','lava','spectrum']){
  const at=await page.locator('audio').evaluate(a=>a.currentTime);
  await page.evaluate(s=>{state.config.saver_style=s;Saver.show();},style);
  await page.locator('.ambient-'+style).waitFor();
  assert.equal(await page.locator('audio').evaluate(a=>a.paused),false);
  await page.waitForFunction(at=>document.querySelector('audio').currentTime>at,at);
  assert.equal(await page.locator('video').count(),0);
  if(style==='spectrum'){await page.waitForFunction(()=>document.querySelector('.spectrum-canvas').width===innerWidth);assert(meterRequests>0);}

  await page.keyboard.press('F8');
  await page.waitForFunction(()=>Saver.el===null);
  assert.equal(await page.locator('audio').evaluate(a=>a.paused),false);
  assert.equal(await page.locator('audio').getAttribute('src'),source);
  await page.waitForTimeout(450);
 }
 await page.evaluate(()=>Saver.showAmbient('aurora'));
 await page.keyboard.press('ArrowRight');
 assert(await page.locator('.ambient-stars').isVisible());
 assert.equal(await page.locator('audio').evaluate(a=>a.paused),false);
 await page.keyboard.press('ArrowLeft');
 assert(await page.locator('.ambient-aurora').isVisible());
 await page.keyboard.press('Space');
 await page.waitForFunction(()=>document.querySelector('audio').paused);
 assert(await page.locator('.ambient').isVisible());
 await page.keyboard.press('Space');
 await page.waitForFunction(()=>!document.querySelector('audio').paused);
 await page.evaluate(()=>{SpotifyNow.cur={web:true,playing:true,title:'Nachts am Meer',artist:'Ambient Test',cover:''};});
 await page.waitForFunction(()=>document.querySelector('#ambient-title').textContent==='Nachts am Meer');
 await page.keyboard.press('MediaPlayPause');
 assert.deepEqual(await page.evaluate(()=>window.controls),['toggle']);
 await page.emulateMedia({reducedMotion:'reduce'});
 assert.equal(await page.locator('.ambient-scene i').first().evaluate(el=>getComputedStyle(el).animationName),'none');
 await page.emulateMedia({reducedMotion:'no-preference'});
 fs.mkdirSync(path.join(root,'artifacts'),{recursive:true});
 await page.waitForTimeout(1000);
 await page.screenshot({path:path.join(root,'artifacts/ambient-57.png')});
 await page.keyboard.press('Escape');
 await page.waitForFunction(()=>Saver.el===null);
 assert.equal(await page.locator('audio').evaluate(a=>a.paused),false);
 assert(!(await page.evaluate(()=>window.messages)).some(m=>m.type==='raspi-tv-home'),'Home must dismiss the saver without navigating/reloading');
 assert.deepEqual(errors,[]);
 console.log('Ambient browser checks passed: 3 animated scenes + live spectrum, real uninterrupted audio, source/time continuity, Home/exit, radio and Spotify controls, metadata and reduced motion.');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
