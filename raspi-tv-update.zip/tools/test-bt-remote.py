"""Exercise the real line protocol over local sockets; no Bluetooth hardware needed."""
import base64
import importlib.util
import json
from pathlib import Path
import socket
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('bt_features', ROOT / 'system/features.py')
f = importlib.util.module_from_spec(spec)
spec.loader.exec_module(f)


class ApiError(Exception):
    def __init__(self, message, code=400):
        super().__init__(message)
        self.code = code


class BluetoothTests(unittest.TestCase):
    MAC = '01:02:03:04:05:06'

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.routes = {'/r/echo': lambda data: data, '/r/app-chunk': f.remote_app_chunk}
        f.bind({'STATE_DIR': self.temp.name, 'ROOT': str(ROOT / 'launcher'),
                'REMOTE_ROUTES': self.routes, 'ApiError': ApiError})
        f._btr.update(window_until=0, clients={}, log=[])
        f._btr_allow(self.MAC, 'Testhandy')
        self.peers = []
        self.threads = []
        self.name = patch.object(f, '_bt_name', return_value='Testhandy').start()
        patch.object(f, 'touch_activity').start()
        self.addCleanup(patch.stopall)
        self.addCleanup(self.close_all)

    def close_all(self):
        for peer in self.peers:
            try:
                peer.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            peer.close()
        for thread in self.threads:
            thread.join(2)

    def connect(self, mac=None):
        server, client = socket.socketpair()
        client.settimeout(1)
        thread = threading.Thread(target=f._btr_handle, args=(server, mac or self.MAC), daemon=True)
        self.peers.append(client)
        self.threads.append(thread)
        thread.start()
        return client

    def send(self, peer, path, data=None, rid=1):
        peer.sendall(json.dumps({'id': rid, 'path': path, 'data': data or {}}).encode() + b'\n')

    def read(self, peer):
        # Byte-by-byte deliberately avoids buffering a subsequent line away from the test.
        data = b''
        while not data.endswith(b'\n'):
            chunk = peer.recv(1)
            if not chunk:
                raise EOFError(data)
            data += chunk
        return json.loads(data)

    def test_known_phone_does_not_wait_for_name_lookup(self):
        entered, release = threading.Event(), threading.Event()
        def slow_name(_mac):
            entered.set()
            release.wait(2)
            return 'Testhandy'
        self.name.side_effect = slow_name
        try:
            peer = self.connect()
            self.send(peer, '/r/hb', rid=-1)
            self.assertEqual(self.read(peer)['id'], -1)
            self.assertFalse(entered.is_set(), 'The paired name is already stored')
        finally:
            release.set()

    def test_heartbeat_overtakes_slow_command_and_commands_stay_ordered(self):
        entered, release = threading.Event(), threading.Event()
        seen = []
        def slow(data):
            seen.append(data['key'])
            entered.set()
            release.wait(2)
            return {'ok': True}
        self.routes['/r/key'] = slow
        try:
            peer = self.connect()
            self.send(peer, '/r/key', {'key': 'up'}, 1)
            self.assertTrue(entered.wait(1))
            self.send(peer, '/r/key', {'key': 'down'}, 2)
            self.send(peer, '/r/hb', rid=-1)
            self.assertEqual(self.read(peer)['id'], -1)
            release.set()
            self.assertEqual([self.read(peer)['id'], self.read(peer)['id']], [1, 2])
            self.assertEqual(seen, ['up', 'down'])
        finally:
            release.set()

    def test_new_session_replaces_old_without_losing_connected_status(self):
        first = self.connect()
        self.send(first, '/r/hb', rid=-1)
        self.read(first)
        second = self.connect()
        self.send(second, '/r/hb', rid=-1)
        self.read(second)
        self.assertEqual(first.recv(1), b'', 'Only the newest connection may remain active')
        self.threads[0].join(1)
        self.assertEqual(f._btr['clients'][self.MAC], 'Testhandy')
        self.send(second, '/r/echo', {'value': 42})
        self.assertEqual(self.read(second)['data'], {'value': 42})

    def test_disconnected_session_drops_queued_commands(self):
        entered, release = threading.Event(), threading.Event()
        executed = []
        def slow(_data):
            entered.set()
            release.wait(2)
            return {}
        self.routes.update({'/r/slow': slow, '/r/action': lambda d: executed.append(d)})
        try:
            peer = self.connect()
            self.send(peer, '/r/slow')
            self.assertTrue(entered.wait(1))
            self.send(peer, '/r/action', {'key': 'next'}, 2)
            self.send(peer, '/r/hb', rid=-1)
            self.read(peer)  # Queue has been received before closing.
            peer.shutdown(socket.SHUT_RDWR)
            self.threads[0].join(1)
            release.set()
            time.sleep(.1)
            self.assertEqual(executed, [])
        finally:
            release.set()

    def test_unpaired_phone_cannot_control(self):
        peer = self.connect('AA:BB:CC:DD:EE:FF')
        self.assertEqual(self.read(peer)['error'], 'pair')

    def test_ui_update_on_slow_link_has_bounded_frames_and_exact_hash(self):
        # At 1 KiB/s a complete line must arrive before the 1.11 app's 13 s
        # watchdog; leave room for heartbeats and commands between chunks.
        payload = bytearray()
        while True:
            part = f.remote_app_chunk({'what': 'ui', 'off': len(payload), 'len': 24000})
            wire = json.dumps({'id': 800001, 'ok': True, 'data': part}).encode() + b'\n'
            self.assertLess(len(wire) / 1024, 6, 'An update frame must not starve the heartbeat')
            self.assertEqual(part['off'], len(payload))
            payload.extend(base64.b64decode(part['b64']))
            if len(payload) >= part['total']:
                break
        expected = (ROOT / 'launcher/remote.html').read_bytes()
        self.assertEqual(payload, expected)
        self.assertEqual(f.hashlib.sha256(payload).hexdigest(), part['sha256'])


if __name__ == '__main__':
    unittest.main()
