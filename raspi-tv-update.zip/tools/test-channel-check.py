"""7.7.1: Sender prüfen und ohne Signal ausblenden."""
import http.server
import importlib.util
import json
import tempfile
import threading
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('features', ROOT / 'system/features.py')
f = importlib.util.module_from_spec(spec)
spec.loader.exec_module(f)

PAGES = {
    '/ok/master.m3u8': (200, '#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1\nlow/index.m3u8\n'),
    '/ok/low/index.m3u8': (200, '#EXTM3U\n#EXT-X-TARGETDURATION:6\n#EXTINF:6,\nseg1.ts\n#EXTINF:6,\nseg2.ts\n'),
    '/ok/low/seg2.ts': (200, 'x' * 100),
    '/geo/master.m3u8': (200, '#EXTM3U\n#EXTINF:6,\nseg.ts\n'),
    '/geo/seg.ts': (403, ''),
    '/empty/master.m3u8': (200, '#EXTM3U\n#EXT-X-TARGETDURATION:6\n'),
}


class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        code, body = PAGES.get(self.path, (404, ''))
        self.send_response(code)
        self.end_headers()
        self.wfile.write(body.encode())

    def log_message(self, *a):
        pass


class ChannelCheckTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), H)
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        cls.base = f'http://127.0.0.1:{cls.srv.server_port}'

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.cfg = {}
        chans = [{'name': n, 'group': 'X', 'url': self.base + p} for n, p in
                 (('Gut', '/ok/master.m3u8'), ('Ausland', '/geo/master.m3u8'), ('Leer', '/empty/master.m3u8'), ('Weg', '/weg.m3u8'))]
        (Path(self.tmp.name) / 'channels.json').write_text(json.dumps(chans))
        f.bind({'load_config': lambda: self.cfg, 'save_config': lambda c: None, 'ROOT': self.tmp.name,
                'CHANNEL_OVERRIDES': self.tmp.name + '/none.json', 'STATE_DIR': self.tmp.name})
        f._state = lambda n: str(Path(self.tmp.name) / n)
        f._ck['data'] = None
        f._ck_online = lambda: True

    def tearDown(self):
        self.tmp.cleanup()

    def test_probe(self):
        self.assertEqual(f.channel_probe(self.base + '/ok/master.m3u8'), (True, ''))
        self.assertFalse(f.channel_probe(self.base + '/geo/master.m3u8')[0])
        self.assertIn('Ausland', f.channel_probe(self.base + '/geo/master.m3u8')[1])
        self.assertEqual(f.channel_probe(self.base + '/empty/master.m3u8'), (False, 'Sendet gerade nicht'))
        self.assertFalse(f.channel_probe(self.base + '/weg.m3u8')[0])

    def test_hide_after_two_failures_and_return(self):
        names = lambda: [c['name'] for c in f.all_channels()]
        self.assertTrue(f._ck_run())
        self.assertEqual(len(names()), 4)                       # einmal nichts: noch nicht ausblenden
        self.assertTrue(f._ck_run(only_dead=True))
        self.assertEqual(names(), ['Gut'])
        all_ = {c['name']: c for c in f.all_channels(True)}
        self.assertTrue(all_['Ausland']['dead'])
        self.assertTrue(all_['Weg']['why'])
        self.assertEqual(f.channel_check_status()['dead'], 3)
        self.cfg['channel_hide_dead'] = False
        self.assertEqual(len(names()), 4)
        self.cfg.pop('channel_hide_dead')
        PAGES['/empty/master.m3u8'] = (200, '#EXTM3U\n#EXTINF:6,\n../ok/low/seg2.ts\n')
        try:
            f._ck_run(only_dead=True)
            self.assertEqual(names(), ['Gut', 'Leer'])
        finally:
            PAGES['/empty/master.m3u8'] = (200, '#EXTM3U\n#EXT-X-TARGETDURATION:6\n')
        self.assertTrue(Path(self.tmp.name, 'channel-health.json').exists())

    def test_offline_keeps_list(self):
        f._ck_online = lambda: False
        self.assertFalse(f._ck_run())
        self.assertEqual(len(f.all_channels()), 4)
        self.assertTrue(f.channel_check_status()['offline'])

    def test_no_signal_report(self):
        r = f.channel_no_signal({'url': self.base + '/geo/master.m3u8'})
        self.assertTrue(r['dead'])
        self.assertNotIn('Ausland', [c['name'] for c in f.all_channels()])
        self.assertFalse(f.channel_no_signal({'url': self.base + '/ok/master.m3u8'})['dead'])
        self.assertFalse(f.channel_no_signal({'url': 'http://fremd.example/x.m3u8'})['dead'])   # nur eigene Sender


if __name__ == '__main__':
    unittest.main()
