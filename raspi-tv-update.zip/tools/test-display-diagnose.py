import io
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

source=(Path(__file__).resolve().parents[1]/'system/display-diagnostics.py').read_text(encoding='utf-8')
diagnose=types.ModuleType('display_diagnose')
exec(compile(source,'display-diagnose.sh','exec'),diagnose.__dict__)


class DisplayDiagnoseTests(unittest.TestCase):
    def test_reads_actual_configuration_without_loading_driver_or_changing_files(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            files={
                'proc/device-tree/model':b'Raspberry Pi 5 Model B\0',
                'proc/device-tree/aliases/spi1':b'/axi/spi@54000\0',
                'proc/device-tree/axi/spi@54000/status':b'okay\0',
                'proc/device-tree/axi/spi@54000/cs-gpios':b'\0\0\0\x01\0\0\0\x12\0\0\0\x01',
                'dev/spidev0.0':b'', 'dev/spidev1.0':b'',
                'opt/raspi-tv/VERSION':b'5.8.4',
                'opt/raspi-tv/round-displays.py':b'DISPLAY_PINS=((0,0,25,27),(1,0,24,23))\nSPI_SPEED=4000000\nraise RuntimeError("must not execute")\n',
                'var/lib/raspi-tv-round/enabled-separate-pins':b'',
                'boot/firmware/config.txt':b'[all]\ndtoverlay=spi1-1cs\ninclude display.txt\n',
                'boot/firmware/display.txt':b'gpio=18=ip\n',
            }
            for name,data in files.items():
                path=root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
            calls=[]
            def run(args,**kwargs):
                calls.append(args)
                return types.SimpleNamespace(returncode=0,stdout='current GPIO state\n',stderr='')
            report=diagnose.collect(root,run)
            for expected in ('Raspberry Pi 5','Erwartet Display 1: SPI0.0','SPI0.0 vorhanden: True','SPI1.0 vorhanden: True','gpio=18=ip','cs-gpios: Zellen: 1 18 1','SPI_SPEED = 4000000'):
                self.assertIn(expected,report)
            self.assertEqual({tuple(call) for call in calls if call[0]=='pinctrl'},
                             {('pinctrl','get',str(pin)) for pin in (8,10,11,25,27,18,20,21,23,24)})
            self.assertTrue(all(call[0] in ('uname','systemctl','pinctrl','dtoverlay','journalctl') for call in calls))
            self.assertFalse(any('set' in call or 'restart' in call or 'stop' in call for call in calls))
            self.assertEqual({p.relative_to(root).as_posix():p.read_bytes() for p in root.rglob('*') if p.is_file()},files)

    def test_missing_interfaces_and_commands_still_produce_report(self):
        with tempfile.TemporaryDirectory() as folder:
            def missing(*args,**kwargs):raise FileNotFoundError('command unavailable')
            report=diagnose.collect(Path(folder),missing)
            self.assertIn('KEINE spidev-Geraete',report)
            self.assertIn('SPI1.0 vorhanden: False',report)
            self.assertIn('command unavailable',report)

    def test_assessment_flags_spi0_pin_not_in_spi_mode(self):
        roles={8:'output',10:'SPI0_MOSI',11:'input',25:'output',27:'output',
               18:'output',20:'SPI1_MOSI',21:'SPI1_SCLK',23:'output',24:'output'}
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'dev').mkdir()
            (root/'dev/spidev0.0').write_bytes(b'');(root/'dev/spidev1.0').write_bytes(b'')
            def run(args,**kwargs):
                out=''
                if args[0]=='pinctrl':
                    pin=int(args[2])
                    # Real Pi 5 report: SPI0 CS idles low, SPI1 CS idles high.
                    mode={8:'op dl pu | lo',18:'op dh pd | hi'}.get(pin,'a0 pd | lo')
                    out=f'{pin}: {mode} // GPIO{pin} = {roles[pin]}\n'
                return types.SimpleNamespace(returncode=0,stdout=out,stderr='')
            report=diagnose.collect(root,run)
        summary=report.split('--- Kurzbewertung ---',1)[1]
        self.assertIn('Display 1: KONFIGURATIONSPROBLEM - SCL GPIO11 ist input statt SPI0_SCLK',summary)
        self.assertIn('Display 2: Alle Pins richtig eingestellt',summary)
        self.assertIn('Display 1: CS GPIO8 ruht auf LOW',summary)
        self.assertNotIn('Display 2: CS',summary)
        self.assertLess(report.index('Kurzbewertung'),report.index('Modell:'))

    def test_pin_function_reads_short_pinctrl_format(self):
        self.assertEqual(diagnose.pin_function('25: op dh pd | hi'),'output')
        self.assertIsNone(diagnose.pin_function(''))

    def test_does_not_follow_config_include_outside_boot(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'boot/firmware').mkdir(parents=True)
            (root/'boot/firmware/config.txt').write_text('include ../../private.txt\n')
            (root/'private.txt').write_text('gpio=SECRET\n')
            self.assertNotIn('SECRET',diagnose.boot_config(root))


if __name__=='__main__':unittest.main()
