const {spawn}=require('node:child_process');
const fs=require('node:fs/promises'),path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require('playwright');
const root=path.resolve(__dirname,'..');
(async()=>{
 const server=spawn('python',['-u',path.join(root,'tools/recovery-browser-server.py'),root],{windowsHide:true,stdio:['ignore','pipe','pipe']});
 let browser;
 try{
  const info=await new Promise((resolve,reject)=>{
   let output='';const timer=setTimeout(()=>reject(Error('Server timeout')),15000);
   server.stdout.on('data',data=>{output+=data;if(output.includes('\n')){clearTimeout(timer);resolve(JSON.parse(output.split('\n')[0]));}});
   server.stderr.on('data',data=>process.stderr.write(data));
   server.once('exit',code=>{clearTimeout(timer);reject(Error('Server exit '+code));});
  });
  browser=await chromium.launch({headless:true,executablePath:process.env.BROWSER_EXECUTABLE||'C:/Program Files/Google/Chrome/Application/chrome.exe'});
  const page=await browser.newPage({viewport:{width:390,height:844}}),errors=[];
  page.on('pageerror',error=>errors.push(error.message));
  await page.goto('http://127.0.0.1:'+info.port+'/');
  assert.equal(await page.locator('#roundDisplays').isVisible(),false);
  await page.locator('#key').fill('0042');await page.locator('#connect').click();
  await page.locator('#roundDisplays').waitFor({state:'visible'});
  assert(await page.locator('#roundDownload').isDisabled());
  await page.locator('#roundDiagnose').click();
  await page.waitForFunction(()=>!document.querySelector('#roundDownload').disabled);
  assert((await page.locator('#roundStatus').textContent()).includes('Diagnose abgeschlossen'));
  const downloadEvent=page.waitForEvent('download');await page.locator('#roundDownload').click();
  const download=await downloadEvent;
  assert.equal(download.suggestedFilename(),'raspi-tv-display-diagnose.txt');
  const report=await fs.readFile(await download.path(),'utf8');
  assert(report.includes('Raspberry Pi 5'));
  assert(report.includes('SPI1.0 vorhanden: False'));
  assert(!report.includes('0042'));assert(!report.includes('DO_NOT_EXPORT'));
  await page.reload();await page.locator('#key').fill('0042');await page.locator('#connect').click();
  await page.waitForFunction(()=>!document.querySelector('#roundDownload').disabled);
  await page.locator('#roundUsb').click();
  await page.getByRole('button',{name:'Support-Paket auf USB speichern',exact:true}).waitFor();
  await page.getByRole('button',{name:'Support-Paket auf USB speichern',exact:true}).click();
  await page.waitForFunction(()=>document.querySelector('#notice').textContent.includes('gespeichert:'));
  await page.route('**/maintenance/round-displays',route=>route.fulfill({status:500,json:{error:'Test: Diagnose nicht verfügbar'}}));
  await page.locator('#roundDiagnose').click();
  await page.waitForFunction(()=>document.querySelector('#roundStatus').textContent.includes('Diagnose nicht verfügbar'));
  assert(await page.locator('#roundDiagnose').isEnabled());assert(await page.locator('#roundDownload').isDisabled());
  await page.unroute('**/maintenance/round-displays');
  await page.locator('#roundDiagnose').click();
  await page.waitForFunction(()=>!document.querySelector('#roundDownload').disabled);
  await page.locator('#roundDisplays').screenshot({path:path.join(root,'artifacts/display-diagnose-admin.png')});
  const sizes=await page.evaluate(()=>{
   const section=document.querySelector('#roundDisplays'),parent=section.parentNode,next=section.nextSibling;
   const before=document.documentElement.scrollWidth;section.remove();const without=document.documentElement.scrollWidth;parent.insertBefore(section,next);
   return {before,without,rects:[section,...section.querySelectorAll('button,pre')].map(el=>({id:el.id,width:el.getBoundingClientRect().width,right:el.getBoundingClientRect().right+scrollX})),viewport:innerWidth};
  });
  assert(sizes.before<=sizes.without,'New display section adds horizontal overflow: '+JSON.stringify(sizes));
  assert(sizes.rects.every(rect=>rect.width<=sizes.viewport&&rect.right<=sizes.viewport),JSON.stringify(sizes));
  await page.locator('#roundDisplays').screenshot({path:path.join(root,'artifacts/display-diagnose-admin.png')});
  assert.deepEqual(errors,[]);
  console.log('Display diagnosis UI passed: authenticated task, mobile layout, report download, restored result, USB export, error and retry.');
 }finally{if(browser)await browser.close();server.kill();}
})().catch(error=>{console.error(error);process.exitCode=1;});
