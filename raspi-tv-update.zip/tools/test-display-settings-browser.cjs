// Full launcher, real local settings HTTP bridge and recovery/collector task.
const {spawn}=require('node:child_process');
const fs=require('node:fs/promises'),path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require('playwright');
const root=path.resolve(__dirname,'..');
(async()=>{
 const server=spawn('python',['-u',path.join(root,'tools/display-settings-browser-server.py')],{windowsHide:true,stdio:['ignore','pipe','pipe']});
 let browser;
 try{
  const info=await new Promise((resolve,reject)=>{
   let output='';const timer=setTimeout(()=>reject(Error('Server timeout')),15000);
   server.stdout.on('data',data=>{output+=data;if(output.includes('\n')){clearTimeout(timer);resolve(JSON.parse(output.split('\n')[0]));}});
   server.stderr.on('data',data=>process.stderr.write(data));
   server.once('exit',code=>{clearTimeout(timer);reject(Error('Server exit '+code));});
  });
  browser=await chromium.launch({headless:true,executablePath:process.env.BROWSER_EXECUTABLE||'C:/Program Files/Google/Chrome/Application/chrome.exe'});
  const page=await browser.newPage({viewport:{width:1280,height:720}}),errors=[],requests=[];
  page.on('pageerror',error=>errors.push(error.message));
  page.on('request',r=>{if(r.url().endsWith('/api/round-displays'))requests.push(r);});
  await page.route(info.url+'/api/**',route=>{
   const n=new URL(route.request().url()).pathname;
   if(n==='/api/round-displays')return route.continue();
   const data={
    '/api/config':{hidden:[],setup_done:true,startup:'home',intro:false,ui_scale:100,lang:'de',screensaver_min:0,motion:'off'},
    '/api/status':{network:{online:true,ethernet:true},tv:'on'},'/api/channels':[],
    '/api/epg/now':{},'/api/parental':{has_pin:false,kids_mode:false},
    '/api/store':{installed:[],hidden:[],custom:[],native:{}},'/api/native':{running:false},
    '/api/news':{items:[]},'/api/spotify/now':{},'/api/bluetooth':{devices:[]},
    '/api/audio':{outputs:[],volume:45},'/api/system':{version:'5.8.6'}
   };
   return route.fulfill({json:data[n]||{}});
  });
  await page.goto(info.url+'/#/settings');
  await page.getByRole('button',{name:/Runde Displays/}).click();
  await page.waitForFunction(()=>document.querySelector('#rd-start')?.disabled===false);
  assert.equal(new URL(page.url()).hash,'#/settings/round-displays');
  assert(await page.locator('#rd-download').isDisabled());
  // Navigate from the back button using the same arrow/OK events as CEC.
  await page.evaluate(()=>Nav.focus(document.querySelector('[data-key=round-back]')));
  await page.keyboard.press('ArrowDown');
  // Brightness sits first: reachable with the remote and saved through the normal config API.
  assert(await page.locator('#rd-bright-down').evaluate(el=>el.classList.contains('focused')));
  assert.equal(await page.locator('#rd-bright-value').textContent(),'100 %');
  assert(await page.locator('#rd-bright-up').isDisabled());
  const saved=page.waitForRequest(r=>r.url().endsWith('/api/config')&&r.method()==='POST');
  await page.keyboard.press('Enter');
  assert.deepEqual(JSON.parse((await saved).postData()),{round_brightness:90});
  await page.waitForFunction(()=>document.querySelector('#rd-bright-value').textContent==='90 %');
  assert(await page.locator('#rd-bright-up').isEnabled());
  await page.evaluate(()=>Nav.focus(document.querySelector('#rd-test-start-1')));
  await page.keyboard.press('Enter');
  await page.waitForFunction(()=>document.querySelector('#rd-test-status').textContent.includes('Testbild für Display 1 gesendet'));
  assert(await page.locator('#rd-test-start-1').isDisabled());
  assert(await page.locator('#rd-test-start-2').isDisabled());
  await page.locator('#rd-test-stop').click();
  await page.waitForFunction(()=>document.querySelector('#rd-test-status').textContent.startsWith('Test beendet'));
  assert((await page.locator('#rd-test-status').textContent()).includes('Uhr oder Albumcover'));
  await page.locator('#rd-test-start-2').click();
  await page.waitForFunction(()=>document.querySelector('#rd-test-status').textContent.includes('Testbild für Display 2 gesendet'));
  await page.locator('#rd-test-stop').click();
  await page.waitForFunction(()=>document.querySelector('#rd-test-status').textContent.startsWith('Test beendet'));
  assert((await page.locator('#rd-test-status').textContent()).includes('Lautstärkering'));
  await page.locator('#rd-test-start-1').click();
  await page.waitForFunction(()=>document.querySelector('#rd-test-status').textContent.includes('Testbild für Display 1 gesendet'));
  await page.reload();
  await page.waitForFunction(()=>document.querySelector('#rd-test-status')?.textContent.includes('Testbild für Display 1 gesendet'));
  await page.getByRole('button',{name:'Zurück zu Einstellungen',exact:true}).click();
  // Real 30-second driver timeout, with no settings page polling to stop it.
  await page.waitForTimeout(31000);
  await page.getByRole('button',{name:/Runde Displays/}).click();
  await page.waitForFunction(()=>document.querySelector('#rd-test-status')?.textContent.startsWith('Test beendet'));
  assert(await page.locator('#rd-test-start-1').isEnabled());
  assert(await page.locator('#rd-test-start-2').isEnabled());
  assert(await page.locator('#rd-test-stop').isDisabled());
  assert((await page.locator('#rd-test-status').textContent()).includes('Display 1'));
  await page.locator('#rd-start').click();
  await page.waitForFunction(()=>document.querySelector('#rd-download')?.disabled===false);
  assert((await page.locator('#rd-status').textContent()).includes('Diagnose abgeschlossen'));
  await page.locator('#rd-show').click();
  assert((await page.locator('#rd-report').textContent()).includes('Raspberry Pi 5'));
  const downloadEvent=page.waitForEvent('download');await page.locator('#rd-download').click();
  const download=await downloadEvent;
  assert.equal(download.suggestedFilename(),'raspi-tv-display-diagnose.txt');
  const report=await fs.readFile(await download.path(),'utf8');
  assert(report.includes('SPI1.0 vorhanden: False'));
  assert(report.includes('SPI0.0 vorhanden: False'));
  assert(report.includes('pinctrl get 27'));
  assert(!report.includes('0042'));assert(!report.includes('PRIVATE_SECRET'));
  await page.locator('#rd-show').click();
  await page.locator('#rd-usb').click();
  await page.getByRole('button',{name:'Auf RASPITV speichern',exact:true}).click();
  await page.waitForFunction(()=>document.querySelector('#rd-export-status').textContent.startsWith('Gespeichert auf'));
  assert((await fs.readdir(info.stick)).some(name=>name.startsWith('raspi-tv-support-')&&name.endsWith('.zip')));
  // Leave while a new diagnosis runs; returning restores its result.
  await page.locator('#rd-start').click();
  await page.getByRole('button',{name:'Zurück zu Einstellungen',exact:true}).click();
  await page.waitForTimeout(200);const count=requests.length;
  await page.waitForTimeout(1300);assert.equal(requests.length,count,'No polling after leaving the settings page');
  await page.getByRole('button',{name:/Runde Displays/}).click();
  await page.waitForFunction(()=>document.querySelector('#rd-download')?.disabled===false);
  await page.reload();
  await page.waitForFunction(()=>document.querySelector('#rd-download')?.disabled===false);
  // Errors must be readable and retryable without navigating to recovery.
  await page.route(info.url+'/api/round-displays',route=>route.fulfill({status:503,json:{error:'Test: Dienst nicht erreichbar'}}));
  await page.locator('#rd-start').click();
  await page.waitForFunction(()=>document.querySelector('#rd-status').textContent.includes('Dienst nicht erreichbar'));
  assert(await page.locator('#rd-start').isEnabled());assert(await page.locator('#rd-download').isDisabled());
  await page.unroute(info.url+'/api/round-displays');
  await page.locator('#rd-start').click();
  await page.waitForFunction(()=>document.querySelector('#rd-download')?.disabled===false);
  await page.route(info.url+'/api/round-displays',route=>route.request().postDataJSON().action==='usb'
    ?route.fulfill({json:{drives:[],errors:[]}}):route.continue());
  await page.locator('#rd-usb').click();
  await page.waitForFunction(()=>document.querySelector('#rd-export-status').textContent.includes('Kein USB-Stick erkannt'));
  assert(await page.locator('#rd-usb').isEnabled());
  await page.unroute(info.url+'/api/round-displays');
  for(const size of [{width:1280,height:720},{width:1920,height:1080}]){
   await page.setViewportSize(size);
   const boxes=await page.locator('.round-actions button').evaluateAll(els=>els.map(el=>{const r=el.getBoundingClientRect();return {left:r.left,right:r.right,width:r.width,bottom:r.bottom};}));
   assert(boxes.every(b=>b.left>=0&&b.right<=size.width&&b.bottom<=size.height),JSON.stringify(boxes));
  }
  await page.setViewportSize({width:1280,height:720});
  await page.evaluate(()=>document.querySelector('#view').scrollTop=0);
  await page.screenshot({path:path.join(root,'artifacts/display-settings-5.8.8.png')});
  assert(requests.every(r=>!r.headers()['x-admin-key']),'Admin key never sent by browser');
  assert.equal(await page.locator('#key').count(),0,'No recovery login form');
  assert.deepEqual([...new Set(requests.filter(r=>r.postDataJSON().action==='test-start').map(r=>r.postDataJSON().display))].sort(),[1,2]);
  assert.deepEqual(errors,[]);
  console.log('Display settings passed: explicit Display 1/2 selection, correct result labels, start/stop, reload and automatic 30-second restore with page closed, both-pin diagnosis, remote arrows/OK, download, USB export, errors/retry and TV layout.');
 }finally{if(browser)await browser.close();server.kill();}
})().catch(error=>{console.error(error);process.exitCode=1;});
