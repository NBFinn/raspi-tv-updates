"""Real TV HTTP -> authenticated recovery -> collector/USB export integration."""
import json
import importlib.util
import os
from pathlib import Path
import shutil
import sys
import tempfile
import threading
import time
import types
import unittest
import urllib.error
import urllib.request
import zipfile
from http.server import ThreadingHTTPServer

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'system'))
if os.name == 'nt':
    sys.modules.setdefault('pwd', types.ModuleType('pwd'))
import tvctl as tv
import recovery as recovery
from maintenance import Maintenance
from display_settings import DisplaySettings
spec=importlib.util.spec_from_file_location('settings_test_driver',ROOT/'system/round-displays.py')
driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)


class SettingsTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        base = Path(self.tmp.name)
        recovery.ROOT = base/'program'; recovery.ROOT.mkdir()
        (recovery.ROOT/'VERSION').write_text('5.8.6')
        shutil.copyfile(ROOT/'system/display-diagnostics.py', recovery.ROOT/'display-diagnostics.py')
        recovery.STATE = base/'state'; recovery.STATE.mkdir()
        recovery.KEY = '0042'; (recovery.STATE/'admin.key').write_text(recovery.KEY)
        recovery.AUTH_FAILURES.clear(); recovery.JOB.update(running=False, error=None, step='Bereit')
        self.stick = base/'stick'; self.stick.mkdir()
        self.app = Maintenance(recovery.ROOT, recovery.STATE, lambda: {},
                               lambda: ([(self.stick, 'RASPITV')], []), recovery.inspect_update,
                               lambda: dict(recovery.JOB), base/'system')
        model = self.app.system_root/'proc/device-tree/model'; model.parent.mkdir(parents=True)
        model.write_text('Raspberry Pi 5')
        self.app.config.mkdir(parents=True); (self.app.config/'config.json').write_text('{"password":"PRIVATE_SECRET"}')
        self.calls = []
        def hardware(args, **kwargs):
            self.calls.append(args)
            return types.SimpleNamespace(returncode=0, stdout='rw' if args[0]=='findmnt' else 'state 0042 PRIVATE_SECRET', stderr='')
        self.app.run = hardware; recovery.MAINTENANCE = self.app
        self.recovery_http = ThreadingHTTPServer(('127.0.0.1', 0), recovery.Handler)
        self.bridge = DisplaySettings(tv.ApiError, recovery.STATE/'admin.key', self.recovery_http.server_port)
        tv.POST_ROUTES['/api/round-displays'] = self.bridge.request
        self.http = ThreadingHTTPServer(('127.0.0.1', 0), tv.Handler)
        self.url = 'http://127.0.0.1:' + str(self.http.server_port)
        tv.ALLOWED_HOSTS = {self.url.removeprefix('http://')}; tv.ALLOWED_ORIGINS = {self.url}
        self.threads = []
        for server in (self.http, self.recovery_http):
            thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start(); self.threads.append(thread)

    def tearDown(self):
        for server in (self.http, self.recovery_http): server.shutdown(); server.server_close()
        for thread in self.threads: thread.join(2)
        self.tmp.cleanup()

    def request(self, data, headers=None):
        full = {'Content-Type':'application/json', 'X-Raspi-TV':'1', 'Origin':self.url}
        if headers: full.update(headers)
        request = urllib.request.Request(self.url+'/api/round-displays', json.dumps(data).encode(), headers=full)
        try:
            with urllib.request.urlopen(request, timeout=5) as response:
                return response.status, json.loads(response.read())
        except urllib.error.HTTPError as error:
            with error: return error.code, json.loads(error.read())

    def diagnose(self):
        self.assertEqual(self.request({'action':'start'})[0], 200)
        deadline = time.monotonic()+5
        while time.monotonic()<deadline:
            code, result = self.request({'action':'status'})
            if not result['running']: return result
            time.sleep(.02)
        self.fail('Diagnosis never completed')

    def enable_displays(self):
        marker=self.app.system_root/'var/lib/raspi-tv-round/enabled-separate-pins'
        marker.parent.mkdir(parents=True);marker.touch()
        folder=self.app.system_root/'run/raspi-tv-round';folder.mkdir(parents=True)
        original=self.app.run
        def hardware(args,**kwargs):
            result=original(args,**kwargs)
            if args==['systemctl','is-active','raspi-tv-round.service']:result.stdout='active'
            return result
        self.app.run=hardware
        return folder

    def test_test_button_requires_enabled_service_and_waits_for_ack(self):
        self.assertEqual(self.request({'action':'test-start'})[0],400)
        folder=self.enable_displays()
        code,status=self.request({'action':'test-start'})
        self.assertEqual(code,200);self.assertEqual(status['phase'],'pending')
        self.assertEqual(self.request({'action':'status'})[1]['test']['phase'],'pending')
        pending=json.loads((folder/'test-request.json').read_text())
        self.request({'action':'test-start'})
        self.assertEqual(json.loads((folder/'test-request.json').read_text())['id'],pending['id'])
        self.assertFalse((folder/'test-status.json').exists(),'HTTP cannot claim a test image was sent')
        pending['expires']=time.monotonic()-1
        (folder/'test-request.json').write_text(json.dumps(pending))
        self.assertEqual(self.request({'action':'status'})[1]['test']['phase'],'error')

    def test_http_test_driver_ack_stop_and_report(self):
        folder=self.enable_displays();events=[]
        device=types.SimpleNamespace(spi=types.SimpleNamespace(max_speed_hz=4_000_000),
                                     reinitialize=lambda speed:events.append(('reset',speed)),
                                     show=lambda frame:events.append(('frame',frame.size)))
        display=driver.RoundDisplayTest([None,device],folder)
        self.request({'action':'test-start'})
        self.assertTrue(display.tick([None,driver.volume_frame(45)]))
        status=self.request({'action':'status'})[1]['test']
        self.assertEqual(status['phase'],'running');self.assertGreater(status['remaining'],25)
        self.assertEqual(events[0],('reset',500_000))
        self.assertEqual(self.request({'action':'test-stop'})[1]['phase'],'stopping')
        self.assertFalse(display.tick([None,driver.volume_frame(45)]))
        self.assertEqual(self.request({'action':'status'})[1]['test']['phase'],'finished')
        self.assertEqual(events[-2],('reset',4_000_000))
        self.assertTrue(all(args[:2]==['systemctl','is-active'] for args in self.calls))
        report=self.diagnose()['report']
        self.assertIn('Letzter Display-Test:',report)
        self.assertIn('finished',report)
        identifier=self.request({'action':'usb'})[1]['drives'][0]['id']
        result=self.request({'action':'export','id':identifier})[1]
        with zipfile.ZipFile(self.stick/result['name']) as archive:
            self.assertEqual(json.loads(archive.read('raspi-tv-display-test.json'))['phase'],'finished')

    def test_selects_each_display_without_resetting_the_other(self):
        folder=self.enable_displays();events=[]
        devices=[types.SimpleNamespace(spi=types.SimpleNamespace(max_speed_hz=4_000_000),
                   reinitialize=lambda speed,n=n:events.append((n,'reset',speed)),
                   show=lambda frame,n=n:events.append((n,'frame',frame.size))) for n in (1,2)]
        normal=[driver.album_frame({}),driver.volume_frame(45)]
        for number in (1,2):
            with self.subTest(display=number):
                code,result=self.request({'action':'test-start','display':number})
                self.assertEqual(code,200,result)
                self.assertEqual(result['display'],number)
                display=driver.RoundDisplayTest(devices,folder)
                events.clear()
                self.assertEqual(display.tick(normal),number)
                self.assertEqual(self.request({'action':'status'})[1]['test']['display'],number)
                # A second click on the other display must not replace the active test.
                self.assertEqual(self.request({'action':'test-start','display':3-number})[1]['display'],number)
                self.request({'action':'test-stop'});self.assertFalse(display.tick(normal))
                self.assertEqual({event[0] for event in events},{number})
                self.assertEqual(events[-2],(number,'reset',4_000_000))
                status=self.request({'action':'status'})[1]['test']
                self.assertEqual((status['phase'],status['display']),('finished',number))

    def test_rejects_invalid_display_selection_without_touching_hardware(self):
        for number in (0,3,-1,True,False,1.0,'1',None,{},[]):
            self.assertEqual(self.request({'action':'test-start','display':number})[0],400,repr(number))
        self.assertEqual(self.request({'action':'test-stop','display':1})[0],400)
        self.assertEqual(self.calls,[])

    def test_real_task_and_filtered_result_without_browser_admin_code(self):
        self.app.tasks['network'] = {'result':'UNRELATED_TASK'}
        self.assertIsNone(self.request({'action':'status'})[1]['report'])
        result = self.diagnose()
        self.assertIsNone(result['error'])
        self.assertIn('Raspberry Pi 5', result['report'])
        self.assertIn('SPI1.0 vorhanden: False', result['report'])
        for secret in ('0042','PRIVATE_SECRET','UNRELATED_TASK'):
            self.assertNotIn(secret, json.dumps(result))
        self.assertFalse(any('restart' in args or 'set' in args or 'stop' in args for args in self.calls))

    def test_fixed_actions_local_origin_and_no_generic_admin_tunnel(self):
        for data in ({'action':'restart-browser'}, {'action':[]}, {'action':'start','path':'/install'}, {'action':'status','url':'http://evil'}, {'action':'export','id':'../../outside'}):
            self.assertEqual(self.request(data)[0], 400, data)
        for headers in ({'Origin':'http://evil.example'}, {'Host':'evil.example'}, {'X-Raspi-TV':''}):
            self.assertEqual(self.request({'action':'start'}, headers)[0], 403)
        self.assertEqual(self.calls, [])
        with self.assertRaises(urllib.error.HTTPError) as caught:
            urllib.request.urlopen(self.url+'/api/round-displays')
        self.assertEqual(caught.exception.code, 404); caught.exception.close()

    def test_usb_export_requires_report_and_contains_collector_output(self):
        code, drives = self.request({'action':'usb'}); self.assertEqual(code, 200)
        identifier = drives['drives'][0]['id']
        self.assertEqual(self.request({'action':'export','id':identifier})[0], 400)
        report = self.diagnose()['report']
        code, result = self.request({'action':'export','id':identifier})
        self.assertEqual(code, 200, result)
        with zipfile.ZipFile(self.stick/result['name']) as archive:
            self.assertEqual(archive.read('raspi-tv-display-diagnose.txt').decode(), report)
        self.assertEqual(self.request({'action':'export','id':'a'*24})[0], 400)

    def test_service_errors_and_retry(self):
        (recovery.ROOT/'display-diagnostics.py').unlink()
        failed = self.diagnose()
        self.assertTrue(failed['error']); self.assertIsNone(failed['report'])
        shutil.copyfile(ROOT/'system/display-diagnostics.py', recovery.ROOT/'display-diagnostics.py')
        self.assertIsNone(self.diagnose()['error'])
        (recovery.STATE/'admin.key').unlink()
        code, result = self.request({'action':'status'})
        self.assertEqual(code, 503); self.assertNotIn('admin.key', result['error'])


if __name__ == '__main__': unittest.main()
