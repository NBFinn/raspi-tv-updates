"""Bounded display test using the real driver with in-memory SPI/GPIO outputs."""
import importlib.util
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('display_test_driver',ROOT/'system/round-displays.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)


class DisplayTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.folder=Path(self.tmp.name)
        self.clock=100.0;self.events=[];self.frames=[];self.fail=False
        events=self.events
        class Bus:
            def __init__(bus,number):bus.max_speed_hz=4_000_000;bus.number=number;bus.frames=[]
            def writebytes(bus,data):events.append(('spi'+str(bus.number-1),bus.max_speed_hz,bytes(data)))
            def writebytes2(bus,data):
                if self.fail:self.fail=False;raise OSError('transfer failed')
                bus.frames.append((bus.max_speed_hz,bytes(data)))
        def pin(number):
            return types.SimpleNamespace(on=lambda:events.append(('gpio',number,1)),off=lambda:events.append(('gpio',number,0)))
        self.device=r.GC9A01(Bus(2),pin(24),pin(23));self.frames=self.device.spi.frames
        self.devices=[r.GC9A01(Bus(1),pin(25),pin(27)),self.device]
        self.test=r.RoundDisplayTest(self.devices,self.folder,lambda:self.clock)
        self.normal=[r.album_frame({}),r.volume_frame(45)]
        self.sleep=patch.object(r.time,'sleep');self.sleep.start()
        self.addCleanup(self.sleep.stop);self.addCleanup(self.tmp.cleanup)

    def request(self,identifier='a'*24,cancel=False,expires=None,number=2):
        (self.folder/'test-request.json').write_text(json.dumps({'id':identifier,'expires':self.clock+10 if expires is None else expires,'cancel':cancel,'display':number}))

    def status(self):return json.loads((self.folder/'test-status.json').read_text())

    def test_slow_test_same_pins_then_automatic_restore_without_ui(self):
        self.request();self.assertTrue(self.test.tick(self.normal))
        self.assertEqual(self.frames,[(500_000,r.rgb565(r.test_frame(2)))])
        self.assertEqual(self.status()['phase'],'running')
        self.assertEqual(self.status()['until'],130)
        self.assertEqual({event[1] for event in self.events if event[0]=='gpio'},{23,24})
        sent=len(self.events);self.clock=129.9
        self.assertTrue(self.test.tick(self.normal));self.assertEqual(len(self.events),sent)
        self.clock=130
        self.assertFalse(self.test.tick(self.normal))
        self.assertEqual(self.frames[-1],(4_000_000,r.rgb565(self.normal[1])))
        self.assertEqual(self.device.spi.max_speed_hz,4_000_000)
        self.assertEqual(self.status()['phase'],'finished')
        sent=len(self.events);self.test.tick(self.normal);self.assertEqual(len(self.events),sent,'No replay')

    def test_stop_and_cancel_before_start(self):
        self.request(cancel=True);self.assertFalse(self.test.tick(self.normal))
        self.assertEqual(self.events,[]);self.assertEqual(self.status()['phase'],'finished')
        self.request('b'*24);self.assertTrue(self.test.tick(self.normal))
        self.request('b'*24,cancel=True);self.assertFalse(self.test.tick(self.normal))
        self.assertEqual(self.status()['phase'],'finished')
        self.assertEqual(self.frames[-1][0],4_000_000)

    def test_expired_request_failed_transfer_and_retry(self):
        self.request(expires=99);self.assertFalse(self.test.tick(self.normal));self.assertEqual(self.events,[])
        self.request();self.fail=True;self.assertFalse(self.test.tick(self.normal))
        self.assertEqual(self.status()['phase'],'error')
        self.assertIn('transfer failed',self.status()['error'])
        self.assertEqual(self.frames[-1],(4_000_000,r.rgb565(self.normal[1])))
        self.request('b'*24);self.assertTrue(self.test.tick(self.normal))
        self.test.close();self.assertEqual(self.device.spi.max_speed_hz,4_000_000)
        self.assertEqual(self.status()['phase'],'error')

    def test_service_restart_does_not_replay_test(self):
        self.request();self.test.tick(self.normal)
        replacement=r.RoundDisplayTest(self.devices,self.folder,lambda:self.clock)
        sent=len(self.events)
        self.assertFalse(replacement.tick(self.normal));self.assertEqual(len(self.events),sent)
        self.assertEqual(self.status()['phase'],'error')

    def test_display_one_uses_only_its_bus_and_pins_and_restores_clock(self):
        self.request(number=1)
        self.assertEqual(self.test.tick(self.normal),1)
        first=self.devices[0]
        self.assertEqual(first.spi.frames,[(500_000,r.rgb565(r.test_frame(1)))])
        self.assertEqual(self.status()['display'],1)
        self.clock=130;self.assertFalse(self.test.tick(self.normal))
        self.assertEqual(first.spi.frames[-1],(4_000_000,r.rgb565(self.normal[0])))
        self.assertEqual({e[1] for e in self.events if e[0]=='gpio'},{25,27})
        self.assertFalse(any(e[0]=='spi1' for e in self.events))
        self.assertEqual(self.frames,[])
        self.assertEqual(self.device.spi.max_speed_hz,4_000_000)

    def test_invalid_display_number_never_changes_outputs(self):
        for number in (0,3,True,False,'1',1.0,None):
            self.request(number=number)
            self.assertFalse(self.test.tick(self.normal))
        self.assertEqual(self.events,[])
        self.assertEqual(self.frames,[])


if __name__=='__main__':unittest.main()
