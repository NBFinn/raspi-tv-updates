import subprocess
import tempfile
import types
import unittest
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from unittest.mock import patch

SOURCE=Path(__file__).with_name('start.sh')
embedded=SOURCE.read_text(encoding='utf-8').split("<<'PY'\n",1)[1].rsplit('\nPY',1)[0]
helper=types.ModuleType('emergency_start')
exec(compile(embedded,str(SOURCE),'exec'),helper.__dict__)


class EmergencyStartTests(unittest.TestCase):
    def test_report_redacts_code_and_saved_password_without_modifying_them(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            key=root/'var/lib/raspi-tv-recovery/admin.key'
            key.parent.mkdir(parents=True);key.write_text('0042')
            config=root/'var/lib/raspi-tv/config.json'
            config.parent.mkdir(parents=True);config.write_text('{"wifi":{"password":"private-wifi"}}')
            (key.parent/'frontend.log').write_text('Startup error 0042 private-wifi\nReferenceError: missingFunction\n')
            calls=[]
            def run(command,**kwargs):
                calls.append(command)
                return types.SimpleNamespace(stdout='TypeError at startup\nsecret=hidden\nhttps://tv/?token=abc',stderr='')
            code,values=helper.secrets_on_pi(root)
            self.assertEqual(code,'0042')
            report=helper.collect(root,values,run)
            for secret in ('0042','private-wifi','hidden','token=abc'):self.assertNotIn(secret,report)
            self.assertIn('ReferenceError: missingFunction',report)
            self.assertEqual(key.read_text(),'0042')
            self.assertEqual([call[0] for call in calls],['systemctl','journalctl'])
            self.assertIn('status',calls[0])

    def test_code_display_and_report_when_service_commands_fail(self):
        with tempfile.TemporaryDirectory() as folder:
            screen=StringIO()
            with patch.object(helper,'secrets_on_pi',return_value=('0042',['0042'])),patch.object(helper.subprocess,'run',side_effect=FileNotFoundError('systemd unavailable')),redirect_stdout(screen):
                helper.main(folder)
            self.assertIn('DEIN ADMIN-CODE:  0042',screen.getvalue())
            files=list(Path(folder).glob('raspi-tv-startfehler-*.txt'))
            self.assertEqual(len(files),1)
            self.assertNotIn('0042',files[0].read_text())
            self.assertIn('systemd unavailable',files[0].read_text())

    def test_missing_code_is_not_created(self):
        with tempfile.TemporaryDirectory() as folder:
            self.assertEqual(helper.secrets_on_pi(Path(folder)),('',[]))
            self.assertEqual(list(Path(folder).iterdir()),[])


if __name__=='__main__':unittest.main()
