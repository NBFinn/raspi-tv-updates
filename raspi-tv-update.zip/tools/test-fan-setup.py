import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('fan_setup',ROOT/'system/fan-setup.py')
fan=importlib.util.module_from_spec(spec);spec.loader.exec_module(fan)


class FanSetupTests(unittest.TestCase):
    def test_dedicated_pin_kernel_thermal_settings_and_idempotence(self):
        original='dtparam=spi=on\ndtoverlay=spi1-1cs\n[pi4]\narm_boost=1\n'
        updated=fan.updated_config(original)
        self.assertTrue(updated.startswith(original))
        self.assertIn('[all]\ndtoverlay=gpio-fan,gpiopin=26,temp=60000,hyst=10000\n',updated)
        self.assertEqual(fan.updated_config(updated),updated)
        self.assertEqual(fan.updated_config(updated,False),original)
        warmer=fan.updated_config(updated,on=65)
        self.assertEqual(warmer.count('dtoverlay=gpio-fan'),1)
        self.assertIn('temp=65000',warmer)
        # BCM pins reserved by the documented independent display wiring and SPI1 MISO.
        self.assertNotIn(fan.GPIO,{8,10,11,18,19,20,21,23,24,25,27})

    def test_invalid_temperatures_and_foreign_configs_are_preserved(self):
        for on in (0,44,81,100,True,60.5,'60'):
            with self.subTest(on=on),self.assertRaises(ValueError):fan.updated_config('',on=on)
        for text in ('dtoverlay=gpio-fan,gpiopin=14\n',
                     '[pi5]\ndtoverlay=pwm-fan\n',
                     'dtoverlay=pwm-gpio-fan,gpio=26\n',
                     fan.BEGIN+'\n',
                     fan.updated_config('')+fan.updated_config(''),
                     fan.updated_config('').replace('[all]','[all]\ngpu_mem=64')):
            with self.subTest(text=text),self.assertRaises(ValueError):fan.updated_config(text)
        self.assertIn('gpiopin=26',fan.updated_config('# dtoverlay=gpio-fan\n'))
        self.assertEqual(fan.updated_config('unrelated=1',False),'unrelated=1')

    def test_backup_and_repeat_activation(self):
        with tempfile.TemporaryDirectory() as folder:
            config=Path(folder)/'config.txt';original='[all]\ndtparam=spi=on\n'
            config.write_text(original)
            backup=fan.configure(config)
            self.assertEqual(backup.read_text(),original)
            self.assertIn('temp=60000',config.read_text())
            self.assertIsNone(fan.configure(config))
            self.assertEqual(len(list(Path(folder).glob('*.bak'))),1)
            fan.configure(config,False)
            self.assertEqual(config.read_text(),original)

    def test_failed_write_keeps_original_and_backup(self):
        with tempfile.TemporaryDirectory() as folder:
            config=Path(folder)/'config.txt';config.write_text('dtparam=spi=on\n')
            with patch.object(fan.os,'replace',side_effect=OSError('read-only boot partition')):
                with self.assertRaises(OSError):fan.configure(config)
            self.assertEqual(config.read_text(),'dtparam=spi=on\n')
            self.assertEqual(len(list(Path(folder).glob('*.bak'))),1)
            self.assertEqual(list(Path(folder).glob('.raspi-tv-fan-*')),[])


if __name__=='__main__':unittest.main()
