"""Verify the actual emitted Home key without requiring evdev or a Raspberry Pi."""
import ast
import threading
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]


def load_class(file, name, scope):
    tree = ast.parse((ROOT / file).read_text(encoding='utf-8'))
    node = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == name)
    exec(compile(ast.Module(body=[node], type_ignores=[]), file, 'exec'), scope)
    return scope[name]


def main():
    events = []
    codes = SimpleNamespace(KEY_F8=66, KEY_HOMEPAGE=172, EV_KEY=1)
    device = SimpleNamespace(write=lambda *e: events.append(e), syn=lambda: None)
    cls = load_class('system/tvctl.py', 'VirtualInput', {'threading': threading, 'E': codes})
    remote = cls.__new__(cls)
    remote.lock = threading.Lock()
    remote._ui = lambda: device
    remote.key('home')
    assert events == [(1, 66, 1), (1, 66, 0)], f'Handy Home emits browser navigation instead of app command: {events}'
    cls = load_class('system/cec-remote.py', 'Translator', {'e': codes, 'stop_native_app': lambda: False})
    remote = cls.__new__(cls)
    sent = []
    remote.tap = sent.append
    remote.home()
    assert sent == [66], f'CEC Home must use the same app command: {sent}'
    print('Home input checks passed: phone and CEC emit F8, never native browser Home.')


if __name__ == '__main__':
    main()
