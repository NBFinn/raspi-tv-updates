// Full launcher smoke test, serving the real index and all its script dependencies.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require('playwright');
const root=path.resolve(__dirname,'..');
(async()=>{const browser=await chromium.launch({headless:true,executablePath:process.env.BROWSER_EXECUTABLE});try{
 const page=await browser.newPage({viewport:{width:1280,height:720}}),errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 let config={hidden:[],setup_done:true,startup:'home',intro:false,ui_scale:100,lang:'de',screensaver_min:0,saver_style:'classic',motion:'full'};
 await page.route('http://127.0.0.1:8765/**',route=>{
  const request=route.request(),url=new URL(request.url()),n=url.pathname;
  if(n.startsWith('/api/')){
   if(n==='/api/config'){if(request.method()==='POST')config={...config,...request.postDataJSON()};return route.fulfill({json:config});}
   const data={'/api/status':{network:{online:true,ethernet:true},tv:'on'},'/api/channels':[], '/api/epg/now':{},'/api/parental':{has_pin:false,kids_mode:false},'/api/store':{installed:[],hidden:[],custom:[],native:{}},'/api/native':{running:false},'/api/news':{items:[]},'/api/spotify/now':{}};
   if(n==='/api/weather')return route.fulfill({status:503,json:{error:'offline fixture'}});
   return route.fulfill({json:data[n]||{}});
  }
  const file=path.join(root,'launcher',n==='/'?'index.html':n.slice(1));
  if(!fs.existsSync(file))return route.fulfill({status:404,body:'not found'});
  const type=file.endsWith('.js')?'text/javascript; charset=utf-8':file.endsWith('.css')?'text/css':file.endsWith('.html')?'text/html; charset=utf-8':'application/octet-stream';
  return route.fulfill({contentType:type,body:fs.readFileSync(file)});
 });
 await page.goto('http://127.0.0.1:8765/');
 await page.locator('#home-ambient').waitFor();
 await page.locator('#home-ambient').click();
 // 6.0: Musikansicht mit Ambient-Video (Fallback: animierte Szene)
 await page.locator('.vsaver, .ambient-aurora').first().waitFor();
 await page.keyboard.press('Escape');
 await page.evaluate(()=>location.hash='#/settings/energy');
 await page.locator('#ss-style').waitFor();
 for(let i=0;i<4;i++)await page.locator('#ss-style').click();
 await page.waitForFunction(()=>state.config.saver_style==='aurora');
 await page.locator('#e-try').click();
 await page.locator('.ambient-aurora').waitFor();
 await page.waitForTimeout(1000);
 assert.deepEqual(errors,[]);
 console.log('Full launcher startup and settings passed: every real script loaded, Home music view, saver style selection and preview.');
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1});
