"""Authenticated HTTP boundaries and pre-install enforcement."""
import importlib.util
import json
import io
import os
import shutil
from pathlib import Path
import tempfile
import threading
import types
import time
import unittest
import zipfile
import urllib.request
import urllib.error
from http.server import ThreadingHTTPServer
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
r=load('recovery_http_suite',os.environ.get('RECOVERY_UNDER_TEST',ROOT/'system/recovery.py'))
m=load('maintenance_http_suite',ROOT/'system/maintenance.py')

class ApiTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();base=Path(self.tmp.name)
        r.ROOT=base/'program';r.ROOT.mkdir();(r.ROOT/'VERSION').write_text('5.6.0')
        r.STATE=base/'state';r.STATE.mkdir();r.KEY='0042';r.AUTH_FAILURES.clear()
        (r.STATE/'admin.key').write_text(r.KEY)
        r.JOB.update(running=False,error=None,step='Bereit')
        self.service=m.Maintenance(r.ROOT,r.STATE,lambda:{},lambda:([],[]),r.inspect_update,lambda:dict(r.JOB),base/'system')
        r.MAINTENANCE=self.service
        self.http=ThreadingHTTPServer(('127.0.0.1',0),r.Handler)
        self.thread=threading.Thread(target=self.http.serve_forever,daemon=True);self.thread.start()
        self.url='http://127.0.0.1:'+str(self.http.server_port)
    def tearDown(self):
        self.http.shutdown();self.http.server_close();self.thread.join(2);self.tmp.cleanup()
    def request(self,path,body=None,auth=True,origin=None):
        headers={'X-Admin-Key':r.KEY} if auth else {}
        if origin:headers['Origin']=origin
        request=urllib.request.Request(self.url+path,data=json.dumps(body).encode() if body is not None else None,headers=headers)
        try:
            with urllib.request.urlopen(request,timeout=5) as response:return response.status,response.read()
        except urllib.error.HTTPError as error:
            data=error.read();error.close();return error.code,data
    def test_new_tools_are_not_public(self):
        self.assertEqual(self.request('/maintenance/status',auth=False)[0],401)
        self.assertEqual(self.request('/maintenance/status')[0],200)
        self.assertEqual(self.request('/maintenance/safe',{'enabled':True},auth=False)[0],401)
        self.assertEqual(self.request('/maintenance/safe',{'enabled':True},origin='http://evil.example')[0],403)
        self.assertFalse((self.service.config/'safe-mode').exists())
    def test_anonymous_browser_requests_do_not_lock_out_valid_admin(self):
        self.assertEqual(self.request('/favicon.ico',auth=False)[0],204)
        for _ in range(12):
            self.assertEqual(self.request('/maintenance/status',auth=False)[0],401)
        self.assertEqual(self.request('/maintenance/status')[0],200)
    def test_private_report_and_export_cannot_be_read_without_pin(self):
        self.assertEqual(self.request('/maintenance/support.zip',auth=False)[0],401)
        self.assertEqual(self.request('/maintenance/status')[0],200)
        self.assertEqual(self.request('/maintenance/report?id='+'a'*24,auth=False)[0],401)
    def test_live_update_is_not_started_when_preflight_fails(self):
        import zipfile
        with zipfile.ZipFile(r.STATE/'update.zip','w') as archive:
            for name in r.REQUIRED:archive.writestr(name,'5.6.0' if name=='VERSION' else 'fixture')
        with patch.object(self.service,'preflight',side_effect=ValueError('Probelauf fehlgeschlagen')),patch.object(r.subprocess,'run') as process:
            r.install_worker()
        process.assert_not_called()
        self.assertIn('Probelauf fehlgeschlagen',r.JOB['error'])
        self.assertFalse(r.JOB['running'])
        self.assertFalse((r.STATE/'unpacked').exists())
    def test_configuration_is_blocked_while_installation_runs(self):
        r.JOB['running']=True
        self.assertEqual(self.request('/maintenance/safe',{'enabled':True})[0],400)
        self.assertFalse((self.service.config/'safe-mode').exists())

    def test_display_diagnosis_requires_auth_and_is_exported_in_support(self):
        shutil.copyfile(ROOT/'system/display-diagnostics.py',r.ROOT/'display-diagnostics.py')
        calls=[]
        def read_command(args,**kwargs):
            calls.append(args)
            return types.SimpleNamespace(returncode=0,stdout='GPIO state; credential 0042\n',stderr='')
        self.service.run=read_command
        self.assertEqual(self.request('/maintenance/round-displays',{},auth=False)[0],401)
        self.assertEqual(self.request('/maintenance/round-displays',{},origin='http://evil.example')[0],403)
        self.assertEqual(calls,[])
        self.assertEqual(self.request('/maintenance/round-displays',{})[0],200)
        deadline=time.monotonic()+5
        while time.monotonic()<deadline:
            code,body=self.request('/maintenance/status')
            task=json.loads(body)['tasks'].get('round-displays',{})
            if task and not task['running']:break
            time.sleep(.02)
        self.assertFalse(task['running']);self.assertIsNone(task['error'])
        report=task['result']['report']
        self.assertIn('SPI1.0 vorhanden: False',report)
        self.assertNotIn('0042',report)
        self.assertFalse(any('restart' in call or 'set' in call or 'stop' in call for call in calls))
        status,data=self.request('/maintenance/support.zip')
        self.assertEqual(status,200)
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            self.assertEqual(archive.read('raspi-tv-display-diagnose.txt').decode(),report)

    def test_display_diagnosis_reports_missing_collector_as_task_error(self):
        self.assertEqual(self.request('/maintenance/round-displays',{})[0],200)
        deadline=time.monotonic()+3
        while time.monotonic()<deadline:
            task=json.loads(self.request('/maintenance/status')[1])['tasks'].get('round-displays',{})
            if task and not task['running']:break
            time.sleep(.02)
        self.assertFalse(task['running']);self.assertTrue(task['error']);self.assertIsNone(task['result'])

if __name__=='__main__':unittest.main()
