"""Behavior and failure-boundary checks for all ten maintenance features."""
import ast
import base64
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
import types
import unittest
import zipfile
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
def module(name, path):
    spec=importlib.util.spec_from_file_location(name,path)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result
m=module('maintenance_test',ROOT/'system/maintenance.py')
r=module('recovery_maintenance_test',ROOT/'system/recovery.py')
guard=module('browser_guard_test',ROOT/'system/browser-guard.py')


class ToolsTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.base=Path(self.tmp.name)
        self.program=self.base/'program';self.program.mkdir()
        (self.program/'VERSION').write_text('5.6.0')
        self.state=self.base/'state';self.state.mkdir()
        (self.state/'admin.key').write_text('0042')
        self.usb=self.base/'usb';self.usb.mkdir()
        self.system=self.base/'system'
        self.svc=m.Maintenance(self.program,self.state,
            lambda:{'service':'password="demo secret"\nAuthorization: Bearer PRIVATE-TOKEN\nPIN: 0042\nordinary error',
                    'password':'demo secret','frontend':'https://user:pass@server/error?token=abc'},
            lambda:([(self.usb,'TEST-USB')],[]),r.inspect_update,lambda:{'running':False},self.system)
        self.svc.config.mkdir(parents=True)
        (self.svc.config/'config.json').write_text(json.dumps({'password':'demo secret','token':'PRIVATE-TOKEN'}))
        self.commands=[]
        self.svc.run=self.run_boundary
    def tearDown(self):
        self.tmp.cleanup()
    def run_boundary(self,args,**kwargs):
        self.commands.append(args)
        text=''
        if args[:2]==['hostname','-I']:text='127.0.0.1 192.168.1.20'
        elif args[:3]==['id','-u','tv']:text='1000'
        elif 'xrandr' in args and '--query' in args:
            text='HDMI-1 connected primary 1920x1080+0+0\n   1920x1080 60.00*+ 50.00\n   1280x720 60.00\n'
        elif 'pw-dump' in args:
            text=json.dumps([{'id':42,'type':'PipeWire:Interface:Node','info':{'props':{'media.class':'Audio/Sink','node.description':'HDMI'}}}])
        elif args[0]=='findmnt':text='ro,nosuid,nodev,noexec'
        elif args[:3]==['ip','-j','address']:
            text=json.dumps([{'addr_info':[{'family':'inet','scope':'global','local':'192.168.1.20'}]}])
        elif args[:2]==['iw','dev'] and len(args)==2:text='phy#0\n Interface wlan0\n'
        elif args[:2]==['iw','dev']:text='Connected to aa:bb:cc:dd:ee:ff\n SSID: test-net'
        return types.SimpleNamespace(returncode=0,stdout=text,stderr='')
    def archive(self, extra=None):
        files={'VERSION':'5.6.0','system/apply-update.sh':'#!/bin/bash\ntrue\n',
               'system/install-files.sh':'#!/bin/bash\ntrue\n','system/tvctl.py':'print("ok")\n',
               'launcher/index.html':'<!doctype html>','user/xinitrc':'true\n','user/bash_profile':'true\n'}
        files.update(extra or {})
        with zipfile.ZipFile(self.state/'update.zip','w') as package:
            for name,text in files.items():package.writestr(name,text)
    def fake_install(self,source,target,workspace):
        self.assertTrue(target.resolve().is_relative_to(workspace.resolve()))
        for name in ['opt/raspi-tv/launcher/index.html','opt/raspi-tv/VERSION',
                     'opt/raspi-tv/start-browser.sh','etc/systemd/system/raspi-tv-ctl.service']:
            path=target/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text('fixture')
        return 'isolated installation'
    def test_qr_report_requires_login_url_and_redacts_secrets(self):
        result=self.svc.report()
        self.assertTrue(result['url'].startswith('http://192.168.1.20:8767/#report='))
        self.assertNotIn('0042',result['url'])
        loaded=self.svc.get('/maintenance/report',{'id':[result['id']]})
        text=json.dumps(loaded)
        for secret in ['0042','demo secret','PRIVATE-TOKEN','user:pass']:
            self.assertNotIn(secret,text)
        with self.assertRaises(ValueError):self.svc.get('/maintenance/report',{'id':['../admin.key']})
    def test_three_frontend_failures_enable_safe_start(self):
        for index in range(3):self.svc.frontend_failure('failure '+str(index))
        self.assertTrue(self.svc.safe_status()['active'])
        self.svc.safe_set(False)
        self.assertFalse(self.svc.safe_status()['active'])
    def test_preflight_checks_syntax_and_installs_only_to_test_root(self):
        self.archive()
        with patch.object(self.svc,'_sandbox_install',side_effect=self.fake_install) as installer:
            result=self.svc.preflight()
            self.assertTrue(result['ok']);self.assertEqual(len(result['steps']),4)
            self.svc.preflight()
            self.assertEqual(installer.call_count,1)
        self.assertFalse((self.system/'opt/raspi-tv').exists())
        self.assertEqual(list(self.state.glob('dry-run-*')),[])
    def test_preflight_invalid_python_and_low_space_never_install(self):
        self.archive({'system/broken.py':'def broken(:\n'})
        with patch.object(self.svc,'_sandbox_install') as installer:
            with self.assertRaises(SyntaxError):self.svc.preflight()
            installer.assert_not_called()
        self.archive()
        with patch.object(m.shutil,'disk_usage',return_value=types.SimpleNamespace(free=1)):
            with self.assertRaisesRegex(ValueError,'Nicht genug Speicher'):self.svc.preflight()
    def test_preflight_invalid_shell_line_endings_rejected(self):
        self.archive({'system/apply-update.sh':'#!/bin/bash\r\ntrue\r\n'})
        with patch.object(self.svc,'_sandbox_install') as installer:
            with self.assertRaisesRegex(ValueError,'Linux-Zeilenenden'):self.svc.preflight()
            installer.assert_not_called()
    def test_preflight_cache_invalidated_by_changed_archive(self):
        self.archive()
        with patch.object(self.svc,'_sandbox_install',side_effect=self.fake_install) as installer:
            first=self.svc.preflight()['sha256']
            self.archive({'system/new.py':'print("changed")\n'})
            second=self.svc.preflight()['sha256']
            self.assertNotEqual(first,second);self.assertEqual(installer.call_count,2)
    def test_sandbox_disables_privileges_network_and_global_writes(self):
        workspace=self.state/'workspace';workspace.mkdir()
        self.svc._sandbox_install(workspace,workspace/'target',workspace)
        command=self.commands[-1]
        for option in ['--property=ProtectSystem=strict','--property=ProtectHome=yes',
                       '--property=CapabilityBoundingSet=','--property=NoNewPrivileges=yes',
                       '--property=SystemCallFilter=~@network-io',
                       '--property=SystemCallErrorNumber=EPERM','--property=PrivateNetwork=yes']:
            self.assertIn(option,command)
        self.assertNotIn('--property=RestrictAddressFamilies=none',command)
        self.assertIn('--property=ReadWritePaths='+str(workspace),command)
    def test_network_tests_are_separate_and_report_dns_failure(self):
        normal=self.svc.run
        def run(args,**kwargs):
            if args[0]=='getent':raise ValueError('DNS unavailable')
            return normal(args,**kwargs)
        self.svc.run=run
        with patch.object(self.svc,'connector') as connector:
            result=self.svc.network()
        outcomes={row['name']:row['ok'] for row in result['checks']}
        self.assertTrue(outcomes['WLAN']);self.assertTrue(outcomes['IP-Adresse'])
        self.assertFalse(outcomes['DNS']);self.assertTrue(outcomes['Internet'])
        connector.assert_called_once_with(('1.1.1.1',443),timeout=3)
    def test_cec_mapping_persisted_and_invalid_actions_rejected(self):
        result=self.svc.cec_save({'code':398,'action':'home'})
        self.assertEqual(result['mapping']['398'],'home')
        with self.assertRaises(ValueError):self.svc.cec_save({'code':398,'action':'run-shell'})
        self.svc.cec_save({'code':398,'action':'default'})
        self.assertEqual(self.svc.cec_state()['mapping'],{})
    def test_display_change_reverts_unless_confirmed(self):
        timers=[]
        class Timer:
            def __init__(self,seconds,fn):self.fn=fn;self.daemon=False;timers.append(self)
            def start(self):pass
        with patch.object(m.threading,'Timer',Timer):
            result=self.svc.display_test({'output':'HDMI-1','mode':'1280x720','rate':'60.00'})
            self.assertFalse((self.svc.config/'display-mode').exists())
            timers[-1].fn()
            self.assertIsNone(self.svc.display_pending)
            self.assertEqual(self.commands[-1][-4:],['--mode','1920x1080','--rate','60.00'])
            result=self.svc.display_test({'output':'HDMI-1','mode':'1280x720','rate':'60.00'})
            self.svc.display_confirm(result['id'])
            timers[-1].fn()
        self.assertIn('1280x720',(self.svc.config/'display-mode').read_text())
        with self.assertRaises(ValueError):
            self.svc.display_test({'output':'HDMI-1;bad','mode':'1280x720','rate':'60.00'})
    def test_audio_only_accepts_detected_pipewire_output(self):
        self.svc.audio_set(42)
        self.assertEqual(self.commands[-1][-3:],['wpctl','set-default','42'])
        with self.assertRaises(ValueError):self.svc.audio_set(9999)
    def test_audio_test_generates_finite_quiet_wave_without_external_assets(self):
        class Process:
            def poll(self):return 0
            def wait(self,timeout=None):return 0
        class Thread:
            def __init__(self,target,**kwargs):self.target=target
            def start(self):self.target()
        def popen(args,**kwargs):
            path=Path(args[-1]);self.assertTrue(path.exists())
            import wave
            with wave.open(str(path)) as sound:
                self.assertEqual(sound.getnframes(),96000)
                self.assertEqual(sound.getnchannels(),2)
            return Process()
        with patch.object(self.svc,'spawn',side_effect=popen),patch.object(m.threading,'Thread',Thread):
            self.assertEqual(self.svc.audio_test()['seconds'],2)
    def test_corrupt_history_does_not_hide_new_errors(self):
        (self.state/'events.jsonl').write_text('incomplete line\\n{"other":"record"}\\n')
        self.svc.event('error','new valid error')
        rows=self.svc.timeline()['events']
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]['message'],'new valid error')
    def test_timeline_correlates_config_changes_and_errors(self):
        self.svc.timeline()
        (self.svc.config/'config.json').write_text('{"changed":true}')
        changed_at=time.time()-120
        os.utime(self.svc.config/'config.json',(changed_at,changed_at))
        self.svc.event('error','ordinary problem')
        rows=self.svc.timeline()['events']
        self.assertEqual(rows[0]['kind'],'error')
        changed=next(row for row in rows if row['kind']=='configuration')
        self.assertAlmostEqual(changed['at'],changed_at,places=2)
        self.assertIn('configuration',[row['kind'] for row in rows])
        self.assertIn('error',[row['kind'] for row in rows])
        self.assertTrue(all(row['version']=='5.6.0' for row in rows))
    def test_storage_deletes_selected_cache_only_and_preserves_canary(self):
        cache=self.system/'var/cache/raspi-tv';cache.mkdir(parents=True)
        (cache/'large.tmp').write_bytes(b'x'*1000)
        canary=self.svc.home/'.config/private';canary.parent.mkdir(parents=True);canary.write_text('keep')
        result=self.svc.storage_scan();self.assertEqual(len(result['files']),1)
        with self.assertRaises(ValueError):self.svc.storage_delete(['../../private'])
        self.assertEqual(self.svc.storage_delete([result['files'][0]['id']])['deleted'],1000)
        self.assertEqual(canary.read_text(),'keep')
    def test_storage_rejects_files_changed_since_scan(self):
        downloads=self.svc.home/'Downloads';downloads.mkdir(parents=True)
        path=downloads/'file.zip';path.write_bytes(b'one')
        result=self.svc.storage_scan()
        path.write_bytes(b'changed')
        deleted=self.svc.storage_delete([result['files'][0]['id']])
        self.assertEqual(deleted['deleted'],0);self.assertTrue(path.exists());self.assertTrue(deleted['errors'])
    def test_offline_help_includes_diagrams_and_no_remote_dependency(self):
        script=(ROOT/'system/maintenance.js').read_text(encoding='utf-8')
        self.assertIn('<svg viewBox=',script)
        for title in ['Kein Bild','Kein Internet','Update schlägt fehl','Kein Ton','Speicher voll']:
            self.assertIn(title,script)
        self.assertNotIn('https://',script)
    def test_support_zip_and_usb_export_redact_credentials_and_restore_read_only(self):
        content=self.svc.support_zip()
        with zipfile.ZipFile(io.BytesIO(content)) as archive:
            text=archive.read('diagnose.json').decode()
            for secret in ['demo secret','PRIVATE-TOKEN','0042','user:pass']:
                self.assertNotIn(secret,text)
            self.assertNotIn('admin.key',archive.namelist())
        identifier=self.svc.usb_targets()['drives'][0]['id']
        result=self.svc.support_export(identifier)
        self.assertTrue((self.usb/result['name']).is_file())
        mounts=[args for args in self.commands if args[0]=='mount']
        self.assertEqual([args[2] for args in mounts],['remount,rw','remount,ro'])
    def test_support_export_failure_still_restores_read_only(self):
        identifier=self.svc.usb_targets()['drives'][0]['id']
        original=m.os.open
        def fail_target(path,*args,**kwargs):
            if Path(path).parent==self.usb:
                raise OSError('write failed')
            return original(path,*args,**kwargs)
        with patch.object(m.os,'open',side_effect=fail_target):
            with self.assertRaises(OSError):self.svc.support_export(identifier)
        self.assertEqual(self.commands[-1][2],'remount,ro')


class GuardTest(unittest.TestCase):
    def test_three_short_crashes_trigger_safe_mode_but_manual_restart_does_not(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'state.json';flag=Path(folder)/'safe'
            self.assertEqual(guard.mode(path,flag),'normal')
            for index in range(2):guard.record(path,5,1,now=100+index)
            guard.record(path,5,143,now=103)
            self.assertEqual(guard.mode(path,flag),'normal')
            guard.record(path,5,1,now=104)
            self.assertEqual(guard.mode(path,flag),'safe')
    @unittest.skipUnless(Path(r'C:\Program Files\Git\bin\bash.exe').exists() if os.name == 'nt' else Path('/bin/bash').exists(), 'Bash unavailable')
    def test_real_start_script_disables_extensions_in_safe_mode(self):
        script=(ROOT/'system/start-browser.sh').read_text(encoding='utf-8')
        fixture=r"""
command() { printf 'fixture_browser\n'; }
fixture_browser() {
 if [ "$1" = "--version" ]; then printf 'Chromium 130\n'; return 0; fi
 printf 'BROWSER_ARG:%s\n' "$@"
 exit 0
}
curl() { return 0; }
python3() { printf 'safe\n'; }
sleep() { :; }
# The browser now runs in the background; end the kiosk loop after its first run.
wait() { builtin wait "$@"; exit 0; }
"""
        bash=r'C:\Program Files\Git\bin\bash.exe' if os.name=='nt' else '/bin/bash'
        with tempfile.TemporaryDirectory() as folder:
            result=subprocess.run([bash,'--noprofile','--norc','-s'],input=(fixture+script).encode(),
                                  env=dict(os.environ,HOME=folder),capture_output=True,timeout=30)
            log=Path(folder)/'raspi-tv-browser.log'
            text=result.stdout.decode()+(log.read_text(encoding='utf-8') if log.exists() else '')
        self.assertEqual(result.returncode,0,result.stderr.decode('utf-8','replace'))
        self.assertIn('BROWSER_ARG:--disable-extensions',text)
        self.assertNotIn('BROWSER_ARG:--load-extension=',text)
        self.assertIn('BROWSER_ARG:http://127.0.0.1:8767/local',text)
        self.assertNotIn('BROWSER_ARG:http://127.0.0.1:8765/',text)

    def test_old_crashes_expire(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'state.json'
            guard.record(path,5,1,now=100)
            guard.record(path,5,1,now=500)
            self.assertEqual(len(guard.load(path)['failures']),1)


class CecIntegrationTest(unittest.TestCase):
    def test_live_mapping_is_used_by_actual_translator(self):
        class Codes:
            def __init__(self):self.values={};self.KEY={}
            def __getattr__(self,name):
                if name not in self.values:self.values[name]=len(self.values)+1
                return self.values[name]
        codes=Codes();events=[]
        device=types.SimpleNamespace(write=lambda *args:events.append(args),syn=lambda:None)
        evdev=types.ModuleType('evdev');evdev.UInput=lambda *args,**kwargs:device;evdev.ecodes=codes
        with patch.dict('sys.modules',{'evdev':evdev}):
            cec=module('cec_maintenance_test',ROOT/'system/cec-remote.py')
        with tempfile.TemporaryDirectory() as folder:
            cec.CEC_MAPPING_FILE=str(Path(folder)/'mapping.json')
            cec.CEC_LAST_KEY=str(Path(folder)/'last.json')
            cec.set_power=lambda *_:None;cec.mark_input=lambda:None
            Path(cec.CEC_MAPPING_FILE).write_text(json.dumps({str(codes.KEY_BLUE):'right'}))
            translator=cec.Translator();translator.handle(codes.KEY_BLUE,1)
            Path(cec.CEC_MAPPING_FILE).write_text(json.dumps({str(codes.KEY_BLUE):'left'}))
            translator.handle(codes.KEY_BLUE,0)
            self.assertEqual(events[-2:],[(codes.EV_KEY,codes.KEY_RIGHT,1),(codes.EV_KEY,codes.KEY_RIGHT,0)])
            self.assertIn(codes.KEY_VOLUMEUP,cec.OUT_KEYS)
            self.assertEqual(json.loads(Path(cec.CEC_LAST_KEY).read_text())['code'],codes.KEY_BLUE)


if __name__=='__main__':
    unittest.main()
