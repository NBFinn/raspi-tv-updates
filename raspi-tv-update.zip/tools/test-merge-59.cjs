const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
(async () => {
  const messages=[], updates=[], reloads=[], listeners=[];
  const tabs=[{id:1,url:'http://127.0.0.1:8765/',active:true},{id:2,url:'https://open.spotify.com/track/current',discarded:false},{id:42,url:'https://www.youtube.com/watch?v=test'}];
  const context={URL,console,Date,fetch:async()=>({json:async()=>({})}),chrome:{
    tabs:{query:async()=>tabs,update:async(id,data)=>updates.push({id,...data}),reload:async id=>reloads.push(id),
      onUpdated:{addListener(){}},sendMessage:async(id,data)=>messages.push({id,...data})},
    runtime:{onMessage:{addListener:f=>listeners.push(f)},onStartup:{addListener(){}},onInstalled:{addListener(){}}},
    alarms:{create(){},onAlarm:{addListener(){}}}}};
  vm.createContext(context);vm.runInContext(fs.readFileSync(path.join(root,'extension/background.js'),'utf8'),context);
  vm.runInContext('BG.playing=true; BG.at=Date.now()-50000',context);
  await context.watchSpotify();
  assert.deepEqual(reloads,[], 'Late reports must not interrupt live audio');
  assert.equal(messages.at(-1).type,'raspi-tv-spotify-refresh');
  await context.openBg('https://open.spotify.com/playlist/saved');
  assert.equal(updates.at(-1).url,undefined,'Reopening an app must retain current track');
  await context.openBg('https://open.spotify.com/track/shared',true);
  assert.equal(updates.at(-1).url,'https://open.spotify.com/track/shared');
  await context.mediaCommand({target:'web',cmd:'toggle',tab:42});
  assert.equal(messages.at(-1).id,42,'Remote command follows reporting tab, not focused Home');
  const count=messages.length;
  await context.mediaCommand({target:'web',cmd:'toggle',tab:999});
  assert.equal(messages.length,count,'A closed player must not control some other tab');

  let paused=false,played=0,now=10000;
  const reports=[];
  const radio={Date:{now:()=>now},API:{post:async(_,data)=>reports.push(data)},window:{addEventListener(){}},
    localStorage:{getItem:()=>null},fetch:async()=>({json:async()=>[]}),setInterval(){},state:{config:{}},
    $:()=>null,document:{querySelectorAll:()=>[]},toast(){}};
  vm.createContext(radio);
  const source=fs.readFileSync(path.join(root,'launcher/extras2.js'),'utf8');
  vm.runInContext(source.slice(0,source.indexOf('function renderRadio('))+'\nglobalThis.radio=Radio;',radio);
  const r=radio.radio;
  r.stations=[{name:'Station',url:'http://station.test/live'}];r.current=r.stations[0];r.state='playing';
  r.audio={pause(){paused=true;},play:async()=>{played++;}};
  r.update=function(){this.report();};
  r.report();now+=11000;r.report();assert.equal(reports.length,2,'Long streams keep reporting without state change');
  await r.control('toggle');assert(paused);assert.equal(r.current.name,'Station');assert.equal(r.state,'paused');
  await r.control('toggle');assert.equal(played,1);assert.equal(r.current.name,'Station');
  console.log('Merged extension/radio checks passed: uninterrupted Spotify, explicit sharing, exact video tab, radio heartbeat and pause/resume.');
})().catch(e=>{console.error(e);process.exitCode=1;});
