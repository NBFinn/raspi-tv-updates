"""Behavior checks for the 5.5 branch merged into 5.8.8."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('features_merge',ROOT/'system/features.py')
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
class ApiError(Exception):
    def __init__(self,message,code=400):super().__init__(message);self.code=code

class MergeTest(unittest.TestCase):
    def setUp(self):
        f.bind({'ApiError':ApiError,'load_config':lambda:{'volume_target':'pi'},'tv_power':lambda:'on'})
        f._webnow.update(now=None,at=0);f._radio_now.update(now=None,at=0);f._media_cmds.clear()
        f._web_media.clear()
        self.volume=patch.object(f,'_pi_volume',return_value={'level':45,'muted':False});self.volume.start()
    def tearDown(self):self.volume.stop()
    def test_radio_paused_metadata_and_spotify_priority(self):
        f.radio_now_report({'name':'Radio Test','state':'paused'})
        self.assertEqual(f.remote_media()['title'],'Radio Test')
        self.assertFalse(f.remote_media()['playing'])
        f._webnow.update(now={'title':'Track','artist':'Artist','playing':True},at=f.time.time())
        self.assertEqual(f.remote_media()['source'],'spotify')
        f._webnow['at']-=25
        self.assertEqual(f.remote_media()['source'],'radio')
    def test_controls_are_queued_without_faking_playback(self):
        f.radio_now_report({'name':'Radio Test','state':'playing'})
        with patch.object(f,'touch_activity'):
            result=f.remote_media_ctl({'cmd':'toggle','source':'radio'})
        self.assertTrue(result['playing'])
        self.assertEqual(f.QUERY_ROUTES['/api/nav/pending']({}, {'X-Raspi-TV':'1'})['media'],{'target':'radio','cmd':'toggle'})
        self.assertNotIn('media',f.nav_pending({}, {'X-Raspi-TV':'1'}))
        with self.assertRaises(ApiError):f.remote_media_ctl({'cmd':'shell'})
        with self.assertRaises(ApiError):f.nav_pending({}, {})
    def test_expired_controls_do_not_apply_later(self):
        f._media_cmds.append({'target':'spotify','cmd':'toggle','at':f.time.time()-20})
        self.assertNotIn('media',f.nav_pending({}, {'X-Raspi-TV':'1'}))
    def test_video_reports_and_commands_belong_to_exact_tab(self):
        def report(value):f.media_webnow({'d':[json.dumps(value)]},{'X-Raspi-TV':'1'})
        report({'tab':42,'title':'Video','playing':True,'site':'YouTube'})
        report({'tab':99})
        self.assertEqual(f.remote_media()['title'],'Video')
        report({'tab':99,'title':'Other paused video','playing':False})
        self.assertEqual(f.remote_media()['tab'],42)
        with patch.object(f,'touch_activity'):f.remote_media_ctl({'cmd':'toggle','source':'web'})
        self.assertEqual(f.nav_pending({}, {'X-Raspi-TV':'1'})['media'],{'target':'web','cmd':'toggle','tab':42})
        report({'tab':42});self.assertEqual(f.remote_media()['tab'],99)
        with self.assertRaises(ApiError):report({'title':'missing tab'})
    def test_shared_links_and_plain_text(self):
        self.assertEqual(f._open_target('Watch https://youtu.be/abcd?t=30')[0],'https://www.youtube.com/watch?v=abcd&t=30')
        self.assertEqual(f._open_target('https://www.youtube.com/shorts/abcd')[0],'https://www.youtube.com/watch?v=abcd')
        self.assertEqual(f._open_target('https://notyoutube.com/shorts/abcd')[1],'Webseite')
        self.assertIn('search_query=Hallo%20Welt',f._open_target('Hallo Welt')[0])
        with patch.object(f,'touch_activity'):
            result=f.REMOTE_ROUTES_EXTRA['/r/open']({'text':'https://open.spotify.com/track/abc'})
        self.assertEqual(f._nav['url'],result['url'])
    def test_new_and_recent_routes_survive_merge(self):
        for route in ('/r/media','/r/media/ctl','/r/open','/r/gamepad','/r/mirror'):self.assertIn(route,f.REMOTE_ROUTES_EXTRA)
        for route in ('/api/round-display','/api/profiles','/api/audio-meter'):self.assertIn(route,f.GET_ROUTES)
    def test_legacy_windows_package_list_and_binary(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'00-packages-nr';path.write_bytes(b'\xef\xbb\xbfpython3-spidev\r\npython3-lgpio\r\n')
            binary=Path(folder)/'asset.bin';binary.write_bytes(b'\x00\xff\r\n')
            f._unix_line_endings(folder)
            self.assertEqual(path.read_bytes(),b'python3-spidev\npython3-lgpio\n')
            self.assertEqual(binary.read_bytes(),b'\x00\xff\r\n')
if __name__=='__main__':unittest.main()
