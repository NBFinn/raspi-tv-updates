const {spawn}=require('node:child_process');
const path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require('playwright');
const root=path.resolve(__dirname,'..');
(async()=>{
 const python=spawn('python',['-u',path.join(root,'tools/multimedia-test-server.py')],{stdio:['ignore','pipe','pipe']});let browser;
 try{
 const info=await new Promise((resolve,reject)=>{let text='';const timer=setTimeout(()=>reject(Error('Fixture did not start')),20000);python.stdout.on('data',b=>{text+=b;if(text.includes('\n')){clearTimeout(timer);resolve(JSON.parse(text.split('\n')[0]));}});python.stderr.on('data',b=>process.stderr.write(b));python.on('exit',c=>reject(Error('Fixture exited '+c)));});
 browser=await chromium.launch({headless:true,executablePath:process.env.BROWSER_EXECUTABLE,args:['--autoplay-policy=no-user-gesture-required']});
 const pc=await browser.newPage(),tv=await browser.newPage();pc.setDefaultTimeout(20000);tv.setDefaultTimeout(20000);
 const errors=[];pc.on('pageerror',e=>errors.push(e.message));tv.on('pageerror',e=>errors.push(e.message));
 await pc.addInitScript(()=>{
  navigator.mediaDevices.getDisplayMedia=async()=>{
   const canvas=document.createElement('canvas');canvas.width=640;canvas.height=360;const ctx=canvas.getContext('2d');
   function frame(){ctx.fillStyle='#22cc66';ctx.fillRect(0,0,640,360);ctx.fillStyle='white';ctx.fillRect((Date.now()/10)%500,100,40,40);}
   frame();const timer=setInterval(frame,50);const stream=canvas.captureStream(15);window.testCapture=stream;stream.getVideoTracks()[0].addEventListener('ended',()=>clearInterval(timer));return stream;
  };
 });
 await pc.goto('http://127.0.0.1:'+info.helper+'/');
 await pc.locator('#ip').fill('127.0.0.1');await pc.locator('#pin').fill('123456');await pc.locator('#pair').click();
 await pc.waitForFunction(()=>!document.querySelector('#share').disabled);
 await pc.locator('#share').click();
 let navigation;const deadline=Date.now()+20000;
 while(Date.now()<deadline){navigation=await (await fetch('http://127.0.0.1:'+info.pi+'/nav')).json();if(navigation.url)break;await new Promise(r=>setTimeout(r,100));}
 assert(navigation.url,'Starting the PC helper must request the receiver page on the TV');
 const url=new URL(navigation.url);await tv.goto('http://127.0.0.1:'+info.pi+url.pathname+url.hash);
 await tv.waitForFunction(()=>document.querySelector('video').videoWidth>0&&document.querySelector('video').readyState>=2,null,{timeout:25000});
 const color=await tv.locator('video').evaluate(video=>{const c=document.createElement('canvas');c.width=640;c.height=360;const ctx=c.getContext('2d');ctx.drawImage(video,0,0,640,360);return [...ctx.getImageData(10,10,1,1).data];});
 assert(color[1]>120&&color[1]>color[0]*2,'The TV must receive actual green video frames through a native WebRTC connection');
 await pc.locator('#stop').click();await pc.waitForFunction(()=>window.testCapture.getVideoTracks()[0].readyState==='ended');
 await tv.waitForFunction(()=>document.querySelector('#status').textContent.includes('beendet'));
 assert.deepEqual(errors,[]);
 console.log('Native WebRTC integration passed: real localhost relay, pairing boundary, SDP exchange, received live video pixels, explicit stop and capture release.');
 }finally{if(browser)await browser.close();python.kill();}
})().catch(e=>{console.error(e);process.exitCode=1});
