import array
import importlib.util
import math
import threading
import time
import types
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('media',ROOT/'system/multimedia.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class MediaTests(unittest.TestCase):
 def test_spectrum_responds_to_real_pcm_frequency_and_silence(self):
  samples=array.array('h',[int(12000*math.sin(2*math.pi*1000*i/8000)) for i in range(512)])
  out=m.spectrum(samples.tobytes())
  self.assertGreater(out['level'],.5)
  self.assertEqual(out['bands'].index(max(out['bands'])),m.BANDS.index(1000))
  self.assertGreater(out['bands'][6],out['bands'][0]*10)
  self.assertEqual(m.spectrum(bytes(1024)),{'level':0,'bands':[0.0]*len(m.BANDS)})
 def test_mirror_roles_expiry_and_stop(self):
  clock=[0];nav=[];mrr=m.Mirror(nav.append,lambda:clock[0])
  identifier=mrr.request({'action':'create'})['id']
  self.assertIn(identifier,nav[-1])
  self.assertEqual(mrr.request({'id':'wrong'},True),{'ended':True})
  with self.assertRaises(ValueError):mrr.request({'action':'create'})
  with self.assertRaises(ValueError):mrr.request({'action':'offer','id':identifier,'sdp':'v=0\n'},True)
  mrr.request({'action':'offer','id':identifier,'sdp':'v=0\nfixture'})
  self.assertEqual(mrr.request({'id':identifier},True)['offer'],'v=0\nfixture')
  mrr.request({'action':'answer','id':identifier,'sdp':'v=0\nanswer'},True)
  self.assertEqual(mrr.request({'id':identifier})['answer'],'v=0\nanswer')
  self.assertEqual(mrr.request({'action':'stop','id':identifier},True),{'ended':True})
  identifier=mrr.request({'action':'create'})['id'];clock[0]=26
  self.assertEqual(mrr.request({'id':identifier},True),{'ended':True})
 def make_gamepad(self):
  names=['EV_KEY','EV_ABS','ABS_X','ABS_Y','ABS_HAT0X','ABS_HAT0Y']+list(m.BUTTON_NAMES.values())
  codes=types.SimpleNamespace(**{n:i for i,n in enumerate(names)})
  events=[];device=types.SimpleNamespace(write=lambda *args:events.append(args),syn=lambda:None)
  clock=[0];pad=m.Gamepad(lambda:(device,codes),lambda:clock[0]);pad.thread_started=True
  return pad,events,codes,clock
 def test_gamepad_release_watchdog_and_stale_packet(self):
  pad,events,e,clock=self.make_gamepad()
  pad.request({'client':'test-phone','seq':1,'buttons':['a','up'],'axes':[.5,0]})
  self.assertIn((e.EV_KEY,e.BTN_SOUTH,1),events)
  self.assertIn((e.EV_ABS,e.ABS_HAT0Y,-1),events)
  with self.assertRaises(ValueError):pad.request({'client':'other-phone','seq':2,'buttons':['b']})
  clock[0]=1.1;pad.release_expired()
  self.assertIn((e.EV_KEY,e.BTN_SOUTH,0),events)
  self.assertEqual(pad.pressed,set());self.assertEqual(pad.axes,[0,0])
  self.assertTrue(pad.request({'client':'test-phone','seq':1,'buttons':['a']})['ignored'])
  self.assertEqual(pad.pressed,set())
  pad.request({'client':'test-phone','seq':2,'buttons':['b']})
  pad.request({'client':'test-phone','seq':3,'buttons':[]})
  self.assertIn((e.EV_KEY,e.BTN_EAST,0),events)
  self.assertTrue(pad.request({'client':'test-phone','seq':2,'buttons':['b']})['ignored'])
 def test_watchdog_releases_without_another_request(self):
  pad,events,e,_=self.make_gamepad();pad.clock=time.monotonic;pad.thread_started=False
  pad.request({'client':'test-phone','seq':1,'buttons':['a']})
  deadline=time.monotonic()+3
  while pad.pressed and time.monotonic()<deadline:time.sleep(.05)
  self.assertEqual(pad.pressed,set())
  self.assertIn((e.EV_KEY,e.BTN_SOUTH,0),events)
 def test_gamepad_rejects_unknown_or_nonfinite_input(self):
  pad,*_=self.make_gamepad()
  for packet in ({'buttons':['delete']},{'axes':[float('nan'),0]},{'axes':[2,0]},{'axes':[True,0]},{'seq':True}):
   with self.assertRaises(ValueError):pad.request({'client':'test-phone','seq':1,**packet})

if __name__=='__main__':unittest.main()
