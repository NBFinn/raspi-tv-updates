const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');
const root = path.resolve(__dirname, '..');
const read = n => fs.readFileSync(path.join(root,n),'utf8');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.BROWSER_EXECUTABLE});
 try {
 const page=await browser.newPage({viewport:{width:1280,height:800}}),errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 let profiles=[{id:'default',name:'Standard'}];
 await page.route('http://personal.test/**',r=>{
  if(r.request().method()==='POST'){
   const d=r.request().postDataJSON();
   if(d.action==='create')profiles.push({id:'new',name:d.name});
   if(d.action==='rename')profiles.find(p=>p.id===d.id).name=d.name;
   if(d.action==='delete')profiles=profiles.filter(p=>p.id!==d.id);
   return r.fulfill({json:{active:'default',profiles}});
  }
  if(r.request().url().includes('/api/profiles'))return r.fulfill({json:{active:'default',profiles}});
  return r.fulfill({contentType:'text/html',body:`<meta charset="utf-8"><style>${read('launcher/style.css')}</style><main id="view"></main><div id="modals"></div><div id="toast"></div><script>${read('launcher/app.js')}</script><script>${read('launcher/store.js')}</script><script>${read('launcher/personal.js')}</script><script>let renderToken=1;function go(p){location.hash=p;}</script>`});
 });
 await page.goto('http://personal.test/');
 await page.evaluate(()=>renderProfiles(document.querySelector('#view'),1));
 await page.locator('#profile-new').click();
 await page.locator('#profile-name').fill('Finn');
 await page.getByRole('button',{name:'Speichern',exact:true}).click();
 await page.locator('[data-rename=new]').waitFor();
 await page.locator('[data-rename=new]').click();
 await page.locator('#profile-name').fill('Gast');
 await page.getByRole('button',{name:'Speichern',exact:true}).click();
 await page.getByRole('heading',{name:'Gast',exact:true}).waitFor();
 await page.waitForTimeout(600);
 await page.screenshot({path:path.join(root,'artifacts/profiles-5.4.png')});
 await page.locator('[data-delete=new]').click();
 await page.getByRole('button',{name:'Löschen',exact:true}).last().click();
 await page.waitForFunction(()=>document.querySelectorAll('.profile-card').length===1);
 // Personal TV favourites/recents remain separate and survive multiple switches.
 await page.evaluate(()=>{
  localStorage.setItem('tv.favs','["A"]');Personal.sync();
  state.config.active_profile='new';Personal.sync();
  if(localStorage.getItem('tv.favs')!==null)throw Error('Favourite leaked into new profile');
  localStorage.setItem('tv.favs','["B"]');state.config.active_profile='default';Personal.sync();
  if(localStorage.getItem('tv.favs')!=='["A"]')throw Error('Original favourites lost');
  state.config.active_profile='new';Personal.sync();
  if(localStorage.getItem('tv.favs')!=='["B"]')throw Error('Second profile favourites lost');
  renderAppSearch(document.querySelector('#view'));
 });
 await page.locator('#app-query').fill('spotify');
 assert(await page.locator('[data-launch=spotify]').isVisible());
 await page.locator('[data-details=spotify]').click();
 assert(await page.getByRole('button',{name:'Ausblenden',exact:true}).isVisible());
 await page.evaluate(()=>closeAllModals());
 await page.locator('[data-filter=available]').click();
 assert.equal(await page.locator('[data-launch=spotify]').count(),0);
 await page.locator('#app-query').fill('zzzzzznotfound');
 assert.equal(await page.locator('.catalog-card').count(),0);
 await page.locator('[data-filter=all]').click();
 await page.locator('#app-query').fill('');
 await page.screenshot({path:path.join(root,'artifacts/app-search-5.4.png')});
 const matches=await page.evaluate(()=>appSearchResults('spotify','installed').map(a=>a.id));
 assert(matches.includes('spotify'));
 assert.deepEqual(errors,[]);
 console.log('Browser checks passed: profile create/rename/delete, isolated favourites, app search/filter/details, empty results.');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
