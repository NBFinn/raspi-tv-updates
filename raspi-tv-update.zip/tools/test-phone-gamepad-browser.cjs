const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {chromium}=require('playwright');
const root=path.resolve(__dirname,'..');
(async()=>{const browser=await chromium.launch({headless:true,executablePath:process.env.BROWSER_EXECUTABLE});try{
 for(const native of [false,true]){
  const page=await browser.newPage({viewport:{width:390,height:844},hasTouch:true,isMobile:true});const calls=[],errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  const response=(url,data)=>{calls.push({url,data});if(url==='/r/ping')return {tv:'on',lang:'de'};if(url==='/r/state')return {tv:'on',time:Math.floor(Date.now()/1000)};return {ok:true};};
  await page.route('http://phone.test/**',route=>{const req=route.request();if(req.method()==='POST')return route.fulfill({json:response(new URL(req.url()).pathname,req.postDataJSON())});return route.fulfill({contentType:'text/html; charset=utf-8',body:fs.readFileSync(path.join(root,'launcher/remote.html'),'utf8')});});
  await page.addInitScript(()=>localStorage.setItem('raspi-tv.token','fixture-phone-12345678'));
  if(native){await page.exposeFunction('__nativeCall',m=>response(m.path,m.data));await page.addInitScript(()=>{window.RaspiApp={state:()=> 'connected',lang:()=> 'de',menu(){},chooseDevice(){},send(text){const m=JSON.parse(text);window.__nativeCall(m).then(data=>window.__raspiReply({id:m.id,data}));}};});}
  await page.goto('http://phone.test/remote.html');await page.locator('#tabbar').waitFor({state:'visible'});
  await page.locator('[data-tab=gamepad]').tap();await page.locator('#pad-enable').tap();
  const a=page.locator('[data-pad=a]'),up=page.locator('[data-pad=up]');
  await a.dispatchEvent('pointerdown',{pointerId:1,bubbles:true});await up.dispatchEvent('pointerdown',{pointerId:2,bubbles:true});
  await page.waitForTimeout(300);
  assert(calls.some(c=>c.url==='/r/gamepad'&&c.data.buttons.includes('a')&&c.data.buttons.includes('up')),'Simultaneous touches must preserve both buttons');
  await a.dispatchEvent('pointerup',{pointerId:1,bubbles:true});await up.dispatchEvent('pointercancel',{pointerId:2,bubbles:true});await page.waitForTimeout(250);
  assert(calls.filter(c=>c.url==='/r/gamepad').at(-1).data.buttons.length===0);
  await a.dispatchEvent('pointerdown',{pointerId:3,bubbles:true});await page.waitForTimeout(200);
  await page.locator('[data-tab=remote]').tap();await page.waitForTimeout(300);
  assert(calls.filter(c=>c.url==='/r/gamepad').at(-1).data.buttons.length===0,'Changing tabs must release all controls');
  await page.locator('[data-tab=gamepad]').tap();
  for(const [width,height] of [[320,568],[844,390]]){await page.setViewportSize({width,height});await page.waitForTimeout(100);assert((await page.evaluate(()=>document.documentElement.scrollWidth))<=width,'No horizontal clipping');if(width>height){const fit=await page.evaluate(()=>{const box=document.querySelector('#app').getBoundingClientRect();return [...document.querySelectorAll('[data-pad]')].every(b=>{const r=b.getBoundingClientRect();return r.top>=box.top&&r.bottom<=box.bottom;});});assert(fit,'All game buttons must fit on screen in landscape');}}
  if(!native){await page.setViewportSize({width:740,height:390});await page.screenshot({path:path.join(root,'artifacts/phone-gamepad.png')});}
  assert.deepEqual(errors,[]);await page.close();
 }
 console.log('Phone gamepad browser passed: WLAN + native Bluetooth bridge, multitouch, cancel/release, tab change, small and landscape layouts.');
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1});
