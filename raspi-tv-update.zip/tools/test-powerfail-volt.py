"""7.8.1: Stromausfall an der Eingangsspannung erkennen (ohne Kabel)."""
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('powerfail', ROOT / 'system/powerfail.py')
pf = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pf)


class Clock:
    def __init__(self):
        self.t = 0.0

    def monotonic(self):
        return self.t

    def sleep(self, s):
        self.t += s

    def time(self):
        return 1e9 + self.t


class VoltTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        pf.CONFIG = self.tmp.name + '/config.json'
        pf.STATUS = self.tmp.name + '/status.json'
        pf.PAUSE = self.tmp.name + '/pause'
        self.clock = Clock()
        pf.time = self.clock
        pf.V_ARMED = False
        pf.VS.update(hist=[], low_since=None, ok_since=None)
        self.shut = []
        pf.shutdown = lambda: self.shut.append(self.clock.t)
        self.volts = lambda t: 5.15

        pf.read_volt = lambda: self.volts(self.clock.t)

    def tearDown(self):
        self.tmp.cleanup()

    def conf(self, **kw):
        Path(pf.CONFIG).write_text(json.dumps({'powerfail': dict({'on': True, 'source': 'voltage'}, **kw)}))
        return pf.cfg()

    def run_secs(self, c, secs):
        end = self.clock.t + secs
        while self.clock.t < end and not self.shut:
            try:
                pf.watch_voltage(c)
            except SystemExit:
                break

    def test_threshold(self):
        self.assertEqual(self.conf(v_mains=5.15, v_batt=4.95)['threshold'], 5.05)
        self.assertIsNone(self.conf(v_mains=5.10, v_batt=5.05)['threshold'])       # zu dicht
        self.assertIsNone(self.conf()['threshold'])

    def test_triggers_after_drop(self):
        c = self.conf(v_mains=5.15, v_batt=4.95)
        self.volts = lambda t: 5.15 if t < 20 else 4.95
        self.run_secs(c, 30)
        self.assertTrue(self.shut)
        self.assertTrue(20.5 <= self.shut[0] <= 21.5, self.shut)

    def test_short_dips_ignored(self):
        c = self.conf(v_mains=5.15, v_batt=4.95)
        self.volts = lambda t: 4.90 if 15 <= t % 20 < 15.3 else 5.15            # 0,3 s Einbrüche bei Last
        self.run_secs(c, 60)
        self.assertFalse(self.shut)

    def test_not_armed_when_starting_on_battery(self):
        c = self.conf(v_mains=5.15, v_batt=4.95)
        self.volts = lambda t: 4.95
        self.run_secs(c, 30)
        self.assertFalse(self.shut)

    def test_pause_while_learning(self):
        c = self.conf(v_mains=5.15, v_batt=4.95)
        self.volts = lambda t: 5.15 if t < 20 else 4.95
        Path(pf.PAUSE).write_text('1')
        pf.paused = lambda: self.clock.t < 40
        self.run_secs(c, 34)
        self.assertFalse(self.shut)
        self.run_secs(c, 5)
        self.assertTrue(self.shut)

    def test_no_threshold_never_triggers(self):
        c = self.conf()
        self.volts = lambda t: 5.15 if t < 10 else 4.5
        self.run_secs(c, 30)
        self.assertFalse(self.shut)
        self.assertTrue(json.loads(Path(pf.STATUS).read_text())['need_learn'])


if __name__ == '__main__':
    unittest.main()
