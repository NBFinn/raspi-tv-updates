"""Real systemd integration; run as root on a disposable Linux test host, not required on Pi."""
import importlib.util
import os
from pathlib import Path
import shutil
import shlex
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result


@unittest.skipUnless(os.name=='posix' and Path('/run/systemd/system').exists() and os.geteuid()==0,'requires root and running systemd')
class LinuxPreflightTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='raspi-tv-preflight-test-',dir='/var/lib')
        self.base=Path(self.temp.name)
        self.addCleanup(self.temp.cleanup)
        self.program=self.base/'program';self.program.mkdir();(self.program/'VERSION').write_text('test')
        self.state=self.base/'state';self.state.mkdir()
        maintenance=module('real_linux_maintenance',ROOT/'system/maintenance.py')
        recovery=module('real_linux_recovery',ROOT/'system/recovery.py')
        self.service=maintenance.Maintenance(self.program,self.state,lambda:{},lambda:([],[]),recovery.inspect_update,lambda:{'running':False},self.base/'system')

    def test_complete_update_preflight_with_real_systemd(self):
        shutil.copyfile(ROOT/'fertig/raspi-tv-update.zip',self.state/'update.zip')
        result=self.service.preflight()
        self.assertTrue(result['ok'])
        self.assertEqual(result['version'],(ROOT/'VERSION').read_text().strip())
        self.assertEqual(len(result['steps']),4)
        self.assertFalse((self.base/'system/opt').exists())

    def test_network_and_external_writes_are_denied(self):
        workspace=self.state/'isolation';workspace.mkdir()
        source=workspace/'source';(source/'system').mkdir(parents=True)
        target=workspace/'target';target.mkdir()
        outside=self.base/'outside-test-root'
        script=source/'probe.py'
        script.write_text('''import errno, socket, sys
from pathlib import Path
for family in (socket.AF_INET,socket.AF_UNIX):
    try:
        connection=socket.socket(family,socket.SOCK_STREAM)
    except OSError as error:
        assert error.errno in (errno.EPERM,errno.EACCES), error
    else:
        connection.close()
        raise AssertionError('Socket access was allowed')
try:
    Path(sys.argv[2]).write_text('should be denied')
except OSError as error:
    assert error.errno in (errno.EROFS,errno.EPERM,errno.EACCES), error
else:
    raise AssertionError('Write outside test workspace was allowed')
Path(sys.argv[1],'allowed').write_text('ok')
print('Network blocked; external writes blocked; workspace writable.')
''')
        (source/'system/install-files.sh').write_text('#!/bin/bash\nexec '+shlex.quote(sys.executable)+' "$1/probe.py" "$2" "'+str(outside)+'"\n')
        output=self.service._sandbox_install(source,target,workspace)
        self.assertIn('Network blocked',output)
        self.assertEqual((target/'allowed').read_text(),'ok')
        self.assertFalse(outside.exists())


if __name__=='__main__':unittest.main()
