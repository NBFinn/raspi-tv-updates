import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('features', ROOT/'system/features.py')
f = importlib.util.module_from_spec(spec)
spec.loader.exec_module(f)

class ApiError(Exception):
    def __init__(self, message, code=400): super().__init__(message); self.code=code

class ProfilesTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name)/'config.json'
        self.path.write_text(json.dumps({'theme':'aurora','channel_hidden':['A'],'wifi':'shared','parental':{'enabled':True}}))
        f.bind({'load_config':self.load,'save_config':lambda c:self.path.write_text(json.dumps(c)), 'ApiError':ApiError})
    def tearDown(self): self.tmp.cleanup()
    def load(self): return json.loads(self.path.read_text())
    def test_switch_persistence_and_global_settings(self):
        self.assertEqual(f.profiles_status()['active'],'default')
        p=f.profiles_change({'action':'create','name':'Finn'})['profiles'][1]['id']
        f.profiles_change({'action':'switch','id':p})
        c=self.load();c['theme']='light';c['channel_hidden']=['B'];f._save(c)
        f.profiles_change({'action':'switch','id':'default'})
        self.assertEqual(self.load()['theme'],'aurora')
        self.assertEqual(self.load()['channel_hidden'],['A'])
        f.profiles_change({'action':'switch','id':p})
        self.assertEqual(self.load()['theme'],'light')
        self.assertEqual(self.load()['channel_hidden'],['B'])
        self.assertEqual(self.load()['wifi'],'shared')
        self.assertEqual(self.load()['parental'],{'enabled':True})
        self.assertEqual(f.profiles_status()['active'],p)
    def test_validation_and_deletion(self):
        for name in ('', 'a'*25, 'A\nB'):
            with self.assertRaises(ApiError): f.profiles_change({'action':'create','name':name})
        with self.assertRaises(ApiError): f.profiles_change({'action':'create','name':'standard'})
        with self.assertRaises(ApiError): f.profiles_change({'action':'create','name':'Standard','id':'default'})
        with self.assertRaises(ApiError): f.profiles_change({'action':'delete','id':'default'})
        with self.assertRaises(ApiError): f.profiles_change({'action':'switch','id':'missing'})
        p=f.profiles_change({'action':'create','name':'Test'})['profiles'][1]['id']
        f.profiles_change({'action':'rename','id':p,'name':'Gast'})
        self.assertEqual(f.profiles_status()['profiles'][1]['name'],'Gast')
        f.profiles_change({'action':'delete','id':p})
        self.assertEqual(len(f.profiles_status()['profiles']),1)
        for i in range(7): f.profiles_change({'action':'create','name':str(i)})
        with self.assertRaises(ApiError): f.profiles_change({'action':'create','name':'Overflow'})

if __name__=='__main__': unittest.main()
