const fs=require('node:fs/promises'),os=require('node:os'),path=require('node:path'),assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const root=process.argv[2]||path.resolve(__dirname,'..'),screenshot=process.argv[3]||path.join(root,'artifacts/emergency-admin-local.png');
const pythonExe=process.env.PYTHON||'python';
const browserExe=process.env.BROWSER_EXECUTABLE||['C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe','C:/Program Files/Google/Chrome/Application/chrome.exe','/usr/bin/chromium','/usr/bin/chromium-browser'].find(file=>require('node:fs').existsSync(file));
let python,browser,profile,connection;
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
class CDP{
 constructor(ws){this.ws=ws;this.id=0;this.pending=new Map();this.errors=[];ws.addEventListener('message',event=>{const message=JSON.parse(String(event.data));if(message.id){const item=this.pending.get(message.id);if(item){clearTimeout(item.timer);this.pending.delete(message.id);message.error?item.reject(Error(JSON.stringify(message.error))):item.resolve(message.result);}}else if(message.method==='Runtime.exceptionThrown')this.errors.push(JSON.stringify(message.params.exceptionDetails));});}
 send(method,params={}){return new Promise((resolve,reject)=>{const id=++this.id;const timer=setTimeout(()=>{this.pending.delete(id);reject(Error('CDP timeout: '+method));},15000);this.pending.set(id,{resolve,reject,timer});this.ws.send(JSON.stringify({id,method,params}));});}
 async evaluate(expression){const result=await this.send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(result.exceptionDetails)throw Error(JSON.stringify(result.exceptionDetails));return result.result.value;}
 async wait(expression,timeout=12000){const deadline=Date.now()+timeout;while(Date.now()<deadline){if(await this.evaluate(expression))return;await delay(100);}throw Error('UI timeout: '+expression);}
}
(async()=>{
 try{
  python=spawn(pythonExe,['-u',path.join(root,'tools/recovery-browser-server.py'),root],{windowsHide:true,stdio:['ignore','pipe','pipe']});
  const info=await new Promise((resolve,reject)=>{let text='';const timer=setTimeout(()=>reject(Error('Test server timeout')),12000);python.stdout.on('data',data=>{text+=data;if(text.includes('\n')){clearTimeout(timer);resolve(JSON.parse(text.split('\n')[0]));}});python.stderr.on('data',data=>process.stderr.write(data));python.once('exit',code=>reject(Error('Server exit '+code)));});
  profile=await fs.mkdtemp(path.join(os.tmpdir(),'raspitv-browser-'));
  browser=spawn(browserExe,['--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--remote-debugging-port=0','--remote-debugging-address=127.0.0.1','--user-data-dir='+profile,'about:blank'],{windowsHide:true,stdio:'ignore'});
  let port;
  const deadline=Date.now()+15000;
  while(Date.now()<deadline){try{port=(await fs.readFile(path.join(profile,'DevToolsActivePort'),'utf8')).split('\n')[0];break;}catch{await delay(100);}}
  assert(port,'Headless browser did not start');
  const target=await(await fetch('http://127.0.0.1:'+port+'/json/new?about:blank',{method:'PUT'})).json();
  const ws=new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
  const c=connection=new CDP(ws);await c.send('Page.enable');await c.send('Runtime.enable');
  ws.addEventListener('message',event=>{const message=JSON.parse(String(event.data));if(message.method==='Page.javascriptDialogOpening')c.send('Page.handleJavaScriptDialog',{accept:true}).catch(()=>{});});
  await c.send('Emulation.setDeviceMetricsOverride',{width:1280,height:900,deviceScaleFactor:1,mobile:false});
  const url='http://127.0.0.1:'+info.port;

  await c.send('Page.navigate',{url:url+'/local'});
  await c.wait("location.pathname==='/local'&&document.readyState==='complete'&&!!window.RaspiMaintenance");
  await c.evaluate("document.querySelector('#key').value='0042';document.querySelector('#connect').click()");
  await c.wait("!document.querySelector('#admin').hidden");
  await c.evaluate("document.querySelector('[data-tab=qr]').click()");
  await c.evaluate("[...document.querySelectorAll('#maintenanceView button')].find(button=>button.textContent==='QR-Code und Fehlerbericht erstellen').click()");
  await c.wait("!!document.querySelector('#qrResult a')");
  const id=await c.evaluate("document.querySelector('#qrResult a').href.split('#report=')[1]");
  assert.match(id,/^[0-9a-f]{24}$/);
  await c.send('Page.navigate',{url:url+'/#report='+id});
  await c.wait("location.hash==="+JSON.stringify('#report='+id)+"&&document.readyState==='complete'&&!!window.RaspiMaintenance");
  assert(await c.evaluate("document.querySelector('#admin').hidden"));
  await c.evaluate("document.querySelector('#key').value='0042';document.querySelector('#connect').click()");
  await c.wait("document.querySelector('#maintenanceView').textContent.includes('Fehlerbericht vom Pi')");
  console.log('Focused QR report authentication passed.');

 }catch(error){
  if(connection){try{console.error('UI state:',JSON.stringify(await connection.evaluate("({url:location.href,ready:document.readyState,connected:typeof connected==='undefined'?null:connected,notice:document.querySelector('#notice')?.textContent,view:document.querySelector('#maintenanceView')?.textContent.slice(0,1000)})")));}catch{}}
  throw error;
 }finally{
  if(connection){for(const item of connection.pending.values()){clearTimeout(item.timer);item.reject(Error('Browser test ended'));}connection.pending.clear();connection.ws.close();}
  if(browser)browser.kill();if(python)python.kill();
  if(profile){await delay(500);const resolved=path.resolve(profile);if(resolved.startsWith(path.resolve(os.tmpdir())+path.sep)&&path.basename(resolved).startsWith('raspitv-browser-'))await fs.rm(resolved,{recursive:true,force:true,maxRetries:3,retryDelay:300}).catch(()=>{});}
 }
})().catch(error=>{console.error(error);process.exitCode=1;});
