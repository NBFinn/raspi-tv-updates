// Integration test uses the real independent HTTP server, not the launcher.
const {spawn}=require('node:child_process');
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require('playwright');
const root=path.resolve(__dirname,'..');
const code=`import importlib.util,tempfile,json,zipfile
from pathlib import Path
from http.server import ThreadingHTTPServer
root=Path(${JSON.stringify(root).replaceAll('\\\\','/')})
spec=importlib.util.spec_from_file_location('r',root/'system/recovery.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
tmp=tempfile.TemporaryDirectory();r.STATE=Path(tmp.name);r.ROOT=root/'system';r.KEY='0042'
with zipfile.ZipFile(r.STATE/'fixture.zip','w') as z:
 for name in r.REQUIRED:z.writestr(name,'5.4.1' if name=='VERSION' else 'test')
server=ThreadingHTTPServer(('127.0.0.1',0),r.Handler)
print(json.dumps({'port':server.server_port,'zip':str(r.STATE/'fixture.zip')}),flush=True)
server.serve_forever()
`;
(async()=>{
 const child=spawn('python',['-u','-c',code],{stdio:['ignore','pipe','pipe']});
 let browser;
 try {
  const info=await new Promise((resolve,reject)=>{let output='';child.stdout.on('data',b=>{output+=b;if(output.includes('\n'))resolve(JSON.parse(output.split('\n')[0]));});child.stderr.on('data',b=>process.stderr.write(b));child.on('exit',c=>reject(Error('Test server exited: '+c)));});
  browser=await chromium.launch({headless:true,executablePath:process.env.BROWSER_EXECUTABLE});
  const page=await browser.newPage({viewport:{width:1280,height:900}}),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.addInitScript(()=>sessionStorage.setItem('raspi.recovery.key','old-long-admin-code'));
  await page.goto('http://127.0.0.1:'+info.port+'/');
  assert.equal(await page.locator('#key').getAttribute('inputmode'),'numeric');
  assert.equal(await page.locator('#key').getAttribute('maxlength'),'4');
  assert.equal(await page.locator('#key').inputValue(),'');
  await page.locator('#key').fill('42');await page.locator('#connect').click();
  await page.waitForFunction(()=>document.querySelector('#notice').textContent.includes('vier Ziffern'));
  await page.locator('#key').fill('9999');await page.locator('#connect').click();
  await page.waitForFunction(()=>document.querySelector('#notice').textContent.includes('falsch'));
  await page.locator('#key').fill('0042');await page.locator('#connect').click();
  await page.locator('#admin').waitFor({state:'visible'});
  assert(await page.locator('#service').textContent());
  await page.locator('#file').setInputFiles(info.zip);
  await page.locator('#upload').click();
  await page.waitForFunction(()=>document.querySelector('#uploaded').textContent.includes('5.4.1'));
  assert.equal(await page.locator('#install').isEnabled(),true);
  assert.equal(await page.locator('#job').textContent(),'Bereit');
  const download=page.waitForEvent('download');await page.locator('#download').click();assert.equal((await download).suggestedFilename(),'raspi-tv-diagnose.json');
  await page.screenshot({path:path.join(root,'artifacts/emergency-admin.png'),fullPage:true});
  // A completely broken launcher still produces a visible error and a diagnostic report.
  const broken=await browser.newPage();let reports=[];
  await broken.route('http://127.0.0.1:8767/report',route=>{
    reports.push(JSON.parse(route.request().postData()));
    return route.fulfill({json:{ok:true},headers:{'Access-Control-Allow-Origin':'http://127.0.0.1:8765'}});
  });
  await broken.route('http://127.0.0.1:8765/**',route=>route.fulfill({contentType:'text/html; charset=utf-8',body:'<meta charset="utf-8"><body><script>'+fs.readFileSync(path.join(root,'launcher/bootwatch.js'),'utf8')+'</script><script>throw new Error("Launcher start failed test")</script>'}));
  await broken.goto('http://127.0.0.1:8765/');
  await broken.getByRole('link',{name:'Notfall-Admin öffnen'}).waitFor();
  await broken.waitForTimeout(200);
  assert(reports.some(r=>r.message.includes('Launcher start failed test')));
  assert.deepEqual(errors,[]);
  console.log('Recovery browser integration passed: independent server, authentication, diagnostics, real ZIP upload/validation, explicit install step and diagnostic download.');
 }finally{if(browser)await browser.close();child.kill();}
})().catch(e=>{console.error(e);process.exitCode=1});
