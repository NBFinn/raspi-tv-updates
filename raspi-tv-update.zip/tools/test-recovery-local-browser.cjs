const fs=require('node:fs/promises'),os=require('node:os'),path=require('node:path'),assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const root=process.argv[2]||path.resolve(__dirname,'..'),screenshot=process.argv[3]||path.join(root,'artifacts/emergency-admin-local.png');
const pythonExe=process.env.PYTHON||'python';
const browserExe=process.env.BROWSER_EXECUTABLE||['C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe','C:/Program Files/Google/Chrome/Application/chrome.exe','/usr/bin/chromium','/usr/bin/chromium-browser'].find(file=>require('node:fs').existsSync(file));
let python,browser,profile,connection;
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
class CDP{
 constructor(ws){this.ws=ws;this.id=0;this.pending=new Map();this.errors=[];ws.addEventListener('message',event=>{const message=JSON.parse(String(event.data));if(message.id){const item=this.pending.get(message.id);if(item){clearTimeout(item.timer);this.pending.delete(message.id);message.error?item.reject(Error(JSON.stringify(message.error))):item.resolve(message.result);}}else if(message.method==='Runtime.exceptionThrown')this.errors.push(JSON.stringify(message.params.exceptionDetails));});}
 send(method,params={}){return new Promise((resolve,reject)=>{const id=++this.id;const timer=setTimeout(()=>{this.pending.delete(id);reject(Error('CDP timeout: '+method));},15000);this.pending.set(id,{resolve,reject,timer});this.ws.send(JSON.stringify({id,method,params}));});}
 async evaluate(expression){const result=await this.send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(result.exceptionDetails)throw Error(JSON.stringify(result.exceptionDetails));return result.result.value;}
 async wait(expression,timeout=12000){const deadline=Date.now()+timeout;while(Date.now()<deadline){if(await this.evaluate(expression))return;await delay(100);}throw Error('UI timeout: '+expression);}
}
(async()=>{
 try{
  python=spawn(pythonExe,['-u',path.join(root,'tools/recovery-browser-server.py'),root],{windowsHide:true,stdio:['ignore','pipe','pipe']});
  const info=await new Promise((resolve,reject)=>{let text='';const timer=setTimeout(()=>reject(Error('Test server timeout')),12000);python.stdout.on('data',data=>{text+=data;if(text.includes('\n')){clearTimeout(timer);resolve(JSON.parse(text.split('\n')[0]));}});python.stderr.on('data',data=>process.stderr.write(data));python.once('exit',code=>reject(Error('Server exit '+code)));});
  profile=await fs.mkdtemp(path.join(os.tmpdir(),'raspitv-browser-'));
  browser=spawn(browserExe,['--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--remote-debugging-port=0','--remote-debugging-address=127.0.0.1','--user-data-dir='+profile,'about:blank'],{windowsHide:true,stdio:'ignore'});
  let port;
  const deadline=Date.now()+15000;
  while(Date.now()<deadline){try{port=(await fs.readFile(path.join(profile,'DevToolsActivePort'),'utf8')).split('\n')[0];break;}catch{await delay(100);}}
  assert(port,'Headless browser did not start');
  const target=await(await fetch('http://127.0.0.1:'+port+'/json/new?about:blank',{method:'PUT'})).json();
  const ws=new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
  const c=connection=new CDP(ws);await c.send('Page.enable');await c.send('Runtime.enable');
  ws.addEventListener('message',event=>{const message=JSON.parse(String(event.data));if(message.method==='Page.javascriptDialogOpening')c.send('Page.handleJavaScriptDialog',{accept:true}).catch(()=>{});});
  await c.send('Emulation.setDeviceMetricsOverride',{width:1280,height:900,deviceScaleFactor:1,mobile:false});
  const url='http://127.0.0.1:'+info.port;
  await c.send('Page.navigate',{url:url+'/'});
  await c.wait("document.readyState==='complete'&&!!window.RaspiMaintenance&&!!document.querySelector('#connect')");
  assert.equal(await c.evaluate("document.querySelector('#key').getAttribute('inputmode')"),'numeric');
  await c.evaluate("document.querySelector('#key').value='42';document.querySelector('#connect').click()");
  await c.wait("document.querySelector('#notice').textContent.includes('vier Ziffern')");
  await c.evaluate("document.querySelector('#key').value='9999';document.querySelector('#connect').click()");
  await c.wait("document.querySelector('#notice').textContent.includes('falsch')");
  await c.evaluate("document.querySelector('#key').value='0042';document.querySelector('#connect').click()");
  await c.wait("!document.querySelector('#admin').hidden");
  assert((await c.evaluate("document.querySelector('#service').textContent")).includes('Steuerdienst ausgefallen'));
  // Even a cached PIN from the old release must not bypass the local admin login.
  await c.evaluate("sessionStorage.setItem('raspi.recovery.key','0042')");
  await c.send('Page.navigate',{url:url+'/local'});
  await c.wait("document.readyState==='complete'&&!!window.RaspiMaintenance&&!!document.querySelector('#connect')");
  assert(await c.evaluate("!document.querySelector('#login').hidden&&document.querySelector('#admin').hidden"));
  assert.equal(await c.evaluate("document.querySelector('#key').value"),'');
  assert.equal(await c.evaluate("sessionStorage.getItem('raspi.recovery.key')"),null);
  await c.evaluate("document.querySelector('#pinKeyboard').click()");
  await c.wait("!document.querySelector('#keyboard').hidden");
  await c.evaluate("for(const digit of ['0','0','4','2'])[...document.querySelectorAll('#keyboardKeys button')].find(button=>button.textContent===digit).click();[...document.querySelectorAll('#keyboardKeys button')].find(button=>button.textContent==='Senden').click()");
  await c.wait("!document.querySelector('#admin').hidden");
  await c.wait("document.querySelectorAll('#usbUpdates button').length===1");
  await c.evaluate("document.querySelector('#usbUpdates button').click()");
  await c.wait("document.querySelector('#uploaded').textContent.includes("+JSON.stringify((await fs.readFile(path.join(root,'VERSION'),'utf8')).trim())+")");
  assert(await c.evaluate("document.querySelector('#install').disabled"));
  await c.evaluate("document.querySelector('#preflight').click()");
  await c.wait("!document.querySelector('#install').disabled||document.querySelector('#notice').className==='error'",90000);
  assert.equal(await c.evaluate("document.querySelector('#install').disabled"),false,await c.evaluate("document.querySelector('#preflightResult').textContent"));
  await c.evaluate("document.querySelector('#terminalOpen').click()");
  await c.wait("document.querySelector('#terminalStatus').textContent==='Terminal verbunden.'");
  assert.equal(await c.evaluate("document.querySelectorAll('#terminalScreen .xterm').length"),1);
  await c.evaluate("document.querySelector('#commandKeyboard').click()");
  await c.wait("!document.querySelector('#keyboard').hidden");
  await c.evaluate("[...document.querySelectorAll('#keyboardKeys button')].find(button=>button.textContent==='a').click()");
  assert.equal(await c.evaluate("document.querySelector('#terminalCommand').value"),'a');
  await c.evaluate("document.querySelector('#keyboard').hidden=true;document.querySelector('#terminalCommand').value='echo browser-test';document.querySelector('#terminalSend').click()");
  await c.wait("!!term&&term.buffer.active.getLine(0).translateToString().includes('browser-test')");

  async function tab(name){await c.evaluate("document.querySelector('[data-tab="+JSON.stringify(name)+"]').click()");await delay(200);}
  async function clickLabel(text){await c.evaluate("[...document.querySelectorAll('#maintenanceView button')].find(button=>button.textContent==="+JSON.stringify(text)+").click()");}
  await tab('qr');
  await clickLabel('QR-Code und Fehlerbericht erstellen');
  await c.wait("document.querySelectorAll('#qrResult svg').length===1");
  assert(!(await c.evaluate("document.querySelector('#qrResult').textContent")).includes('DO_NOT_EXPORT'));
  const reportId=await c.evaluate("document.querySelector('#qrResult a').href.split('#report=')[1]");
  await tab('safe');await clickLabel('Abgesicherten Start aktivieren');
  await c.wait("document.querySelector('#maintenanceView').textContent.includes('Abgesicherter Start aktiv:')");
  await clickLabel('Zum normalen Start zurückkehren');
  await c.wait("document.querySelector('#maintenanceView').textContent.includes('Normaler Start.')");
  await tab('network');await clickLabel('Netzwerktest starten');
  await c.wait("document.querySelectorAll('#maintenanceView .maintenance-item strong').length===4");
  await tab('cec');await clickLabel('Taste lernen');
  await c.evaluate("post('/fixture/cec-key',{code:398})");
  await c.wait("document.querySelector('#maintenanceView').textContent.includes('Erkannt: KEY_RED')");
  await c.evaluate("document.querySelector('#cecAction').value='home'");
  await clickLabel('Belegung speichern');
  await c.wait("document.querySelector('#notice').textContent.includes('Tastenbelegung gespeichert')");
  assert.equal(await c.evaluate("api('/maintenance/cec').then(result=>result.mapping['398'])"),'home');
  await tab('av');await c.wait("!!document.querySelector('#audioOutput')");
  await clickLabel('Testbild bildschirmfüllend anzeigen');
  await c.wait("!document.querySelector('#calibration').hidden");
  const pattern=await c.send('Page.captureScreenshot',{format:'png'});
  await fs.writeFile(screenshot.replace('.png','-testbild.png'),Buffer.from(pattern.data,'base64'));
  await c.evaluate("document.querySelector('#calibrationClose').click()");
  await c.wait("document.querySelector('#calibration').hidden");
  await c.evaluate("document.querySelector('#displayMode').value=JSON.stringify({mode:'1280x720',rate:'60.00',output:'HDMI-1'})");
  await clickLabel('Auflösung für 20 Sekunden testen');
  await c.wait("[...document.querySelectorAll('#maintenanceView button')].some(button=>button.textContent==='Bild ist sichtbar – Auflösung behalten'&&!button.disabled)");
  await clickLabel('Bild ist sichtbar – Auflösung behalten');
  await c.wait("document.querySelector('#maintenanceView').textContent.includes('Auflösung dauerhaft gespeichert')");
  await clickLabel('Audioausgang übernehmen');await clickLabel('Leisen Testton abspielen');
  await c.wait("document.querySelector('#notice').textContent.includes('Testton läuft')");
  await tab('storage');await clickLabel('Speicher und große Dateien prüfen');
  await c.wait("document.querySelectorAll('#maintenanceView input[type=checkbox]').length===2");
  await clickLabel('Angezeigte Cache-Dateien auswählen');await clickLabel('Ausgewählte Dateien löschen');
  await c.wait("document.querySelector('#notice').textContent.includes('freigegeben')");
  await tab('timeline');await c.wait("document.querySelector('#maintenanceView').textContent.includes('cleanup')");
  await tab('help');
  assert.equal(await c.evaluate("document.querySelectorAll('#maintenanceView figure svg').length"),8);
  await tab('support');await c.wait("document.querySelector('#supportUsb').options.length===1");
  await clickLabel('Support-Paket auf USB speichern');
  await c.wait("document.querySelector('#notice').textContent.includes('raspi-tv-support-')");
  const zipInfo=await c.evaluate("fetch('/maintenance/support.zip',{headers:{'X-Admin-Key':key}}).then(async response=>({code:response.status,type:response.headers.get('Content-Type'),size:(await response.arrayBuffer()).byteLength}))");
  assert.equal(zipInfo.code,200);assert(zipInfo.type.includes('application/zip'));assert(zipInfo.size>100);

  // TV remote arrow keys must move focus even when no mouse is available.
  await c.evaluate("document.querySelector('#usbScan').focus()");
  await c.send('Input.dispatchKeyEvent',{type:'keyDown',key:'ArrowDown',code:'ArrowDown',windowsVirtualKeyCode:40});
  await c.send('Input.dispatchKeyEvent',{type:'keyUp',key:'ArrowDown',code:'ArrowDown',windowsVirtualKeyCode:40});
  assert.notEqual(await c.evaluate("document.activeElement.id"),'usbScan');
  await c.send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});
  await delay(150);
  assert(await c.evaluate("document.documentElement.scrollWidth<=innerWidth+1"),'Mobile layout overflows');
  await c.send('Emulation.setDeviceMetricsOverride',{width:1280,height:900,deviceScaleFactor:1,mobile:false});
  await delay(150);
  const metrics=await c.send('Page.getLayoutMetrics');
  const shot=await c.send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true,clip:{x:0,y:0,width:metrics.cssContentSize.width,height:metrics.cssContentSize.height,scale:1}});
  await fs.writeFile(screenshot,Buffer.from(shot.data,'base64'));
  await c.evaluate("document.querySelector('#install').click()");
  await c.wait("document.querySelector('#job').textContent.includes('Test: Installation')");
  assert.deepEqual(c.errors,[]);
  await c.send('Page.navigate',{url:url+'/broken-launcher'});
  await c.wait("!!document.querySelector('a')&&document.querySelector('a').textContent==='Notfall-Admin öffnen'");
  await c.wait("location.pathname==='/local'&&document.querySelector('#login')&&!document.querySelector('#login').hidden");
  assert(await c.evaluate("document.querySelector('#admin').hidden"));
  assert.equal(await c.evaluate("fetch('/terminal/start',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}).then(response=>response.status)"),401);
  assert.equal(await c.evaluate("fetch('/usb/scan',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}).then(response=>response.status)"),401);
  await c.send('Page.navigate',{url:url+'/#report='+reportId});
  await c.wait("location.hash==="+JSON.stringify('#report='+reportId)+"&&document.readyState==='complete'&&!!window.RaspiMaintenance&&!!document.querySelector('#connect')");
  assert(await c.evaluate("document.querySelector('#admin').hidden"));
  await c.evaluate("document.querySelector('#key').value='0042';document.querySelector('#connect').click()");
  await c.wait("document.querySelector('#maintenanceView').textContent.includes('Fehlerbericht vom Pi')");
  assert.equal(c.errors.length,1);
  assert(c.errors[0].includes('Launcher start failed test'),'Unexpected browser exception');
  console.log('Browser integration passed: normal authenticated access, mandatory local PIN entry after failures, independent USB staging, terminal protocol and rendering, on-screen keyboard, remote arrows, mobile layout, all ten maintenance tools, authenticated QR report and explicit update handoff.');
 }catch(error){
  if(connection){try{console.error('UI state:',JSON.stringify(await connection.evaluate("({url:location.href,ready:document.readyState,connected:typeof connected==='undefined'?null:connected,notice:document.querySelector('#notice')?.textContent,view:document.querySelector('#maintenanceView')?.textContent.slice(0,1000)})")));}catch{}}
  throw error;
 }finally{
  if(connection){for(const item of connection.pending.values()){clearTimeout(item.timer);item.reject(Error('Browser test ended'));}connection.pending.clear();connection.ws.close();}
  if(browser)browser.kill();if(python)python.kill();
  if(profile){await delay(500);const resolved=path.resolve(profile);if(resolved.startsWith(path.resolve(os.tmpdir())+path.sep)&&path.basename(resolved).startsWith('raspitv-browser-'))await fs.rm(resolved,{recursive:true,force:true,maxRetries:3,retryDelay:300}).catch(()=>{});}
 }
})().catch(error=>{console.error(error);process.exitCode=1;});
