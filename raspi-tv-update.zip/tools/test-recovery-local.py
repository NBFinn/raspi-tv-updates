import base64
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
import threading
import time
import types
import unittest
import urllib.error
import urllib.request
import zipfile
from http.server import ThreadingHTTPServer
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('recovery_local', os.environ.get('RECOVERY_UNDER_TEST', ROOT/'system/recovery.py'))
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)


def update_archive():
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w') as archive:
        for name in r.REQUIRED:
            archive.writestr(name, '5.5.0' if name == 'VERSION' else 'fixture')
    return buffer.getvalue()


class Session:
    def __init__(self):
        self.alive = True
        self.written = []
        self.size = None
    def info(self):
        return {'id': 'recovery-admin', 'alive': self.alive}
    def read(self, since, wait):
        return {'data': base64.b64encode(b'root@pi:# ').decode(), 'seq': 10, 'reset': False, 'alive': self.alive, 'code': None}
    def write(self, data):
        self.written.append(data)
    def resize(self, cols, rows):
        self.size = (cols, rows)


class LocalRecoveryTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.stick = self.base/'stick'
        self.stick.mkdir()
        r.STATE = self.base/'state'
        r.STATE.mkdir()
        r.MEDIA_ROOT = r.STATE/'usb-mounts'
        r.ROOT = ROOT/'system'
        r.KEY = '0042'
        r.JOB.update(running=False, step='Bereit', error=None)
        r.AUTH_FAILURES.clear()
        if hasattr(r, 'USB_CANDIDATES'):
            r.USB_CANDIDATES.clear()
        self.http = ThreadingHTTPServer(('127.0.0.1', 0), r.Handler)
        self.thread = threading.Thread(target=self.http.serve_forever, daemon=True)
        self.thread.start()
        self.url = 'http://127.0.0.1:' + str(self.http.server_port)
    def tearDown(self):
        self.http.shutdown()
        self.http.server_close()
        self.thread.join(2)
        self.tmp.cleanup()
    def request(self, path, body=None, auth=True, headers=None):
        extra = {'X-Admin-Key': r.KEY} if auth else {}
        extra.update(headers or {})
        if body is not None:
            body = json.dumps(body).encode()
            extra['Content-Type'] = 'application/json'
        request = urllib.request.Request(self.url+path, data=body, headers=extra)
        try:
            with urllib.request.urlopen(request, timeout=5) as response:
                return response.status, response.read()
        except urllib.error.HTTPError as error:
            data = error.read()
            error.close()
            return error.code, data
    def test_local_page_requires_admin_pin_without_exposing_it(self):
        status, page = self.request('/local', auth=False)
        self.assertEqual(status, 200)
        self.assertNotIn(b'0042', page)
        self.assertNotIn(b'sessionStorage.setItem("raspi.recovery.key"', page)
        self.assertEqual(self.request('/status', auth=False)[0], 401)
        self.assertEqual(self.request('/terminal/start', {}, auth=False)[0], 401)
        self.assertEqual(self.request('/usb/scan', {}, auth=False)[0], 401)
        self.assertEqual(self.request('/status')[0], 200)
        self.assertEqual(self.request('/local', auth=False, headers={'Host': 'evil.example'})[0], 403)
    def test_leaving_page_can_cancel_a_long_poll_without_server_error(self):
        for location in ('headers', 'body'):
            with self.subTest(location=location):
                def fail(*args):
                    raise ConnectionAbortedError('client navigated away')
                handler = types.SimpleNamespace(
                    send_response=lambda *args: None, send_header=lambda *args: None,
                    end_headers=fail if location == 'headers' else lambda: None,
                    wfile=types.SimpleNamespace(write=fail))
                r.Handler.reply(handler, 200, {'data': ''})
    def test_terminal_requires_pin_and_rejects_foreign_origin(self):
        self.assertEqual(self.request('/terminal/start', {}, auth=False)[0], 401)
        self.assertEqual(self.request('/terminal/start', {}, headers={'Origin': 'http://evil.example'})[0], 403)
        self.assertEqual(self.request('/terminal/read?since=0', auth=False)[0], 401)
    def test_terminal_start_input_output_resize_and_stop(self):
        session = Session()
        backend = types.SimpleNamespace(start=lambda *args, **kwargs: session, get=lambda _: session,
                                        stop=lambda _: setattr(session, 'alive', False))
        with patch.object(r, 'terminal_backend', return_value=backend):
            self.assertEqual(self.request('/terminal/start', {'cols': 80, 'rows': 24})[0], 200)
            self.assertEqual(self.request('/terminal/write', {'data': 'printf hello\n'})[0], 200)
            self.assertEqual(session.written, ['printf hello\n'])
            status, body = self.request('/terminal/read?since=0&wait=0')
            self.assertEqual(status, 200)
            self.assertEqual(base64.b64decode(json.loads(body)['data']), b'root@pi:# ')
            self.assertEqual(self.request('/terminal/resize', {'cols': 120, 'rows': 30})[0], 200)
            self.assertEqual(session.size, (120, 30))
            self.assertEqual(self.request('/terminal/stop', {})[0], 200)
            self.assertFalse(session.alive)
            self.assertEqual(self.request('/terminal/write', {'data': ['invalid']})[0], 400)
    def test_usb_scan_and_selection_copy_and_validate_without_installing(self):
        original = update_archive()
        (self.stick/'raspi-tv-update.zip').write_bytes(original)
        (self.stick/'broken.zip').write_bytes(b'not a zip')
        with patch.object(r, 'usb_roots', return_value=([(self.stick, 'TEST-USB')], [])):
            status, body = self.request('/usb/scan', {})
        self.assertEqual(status, 200)
        updates = json.loads(body)['updates']
        self.assertEqual(len(updates), 1)
        self.assertEqual(updates[0]['version'], '5.5.0')
        self.assertFalse((r.STATE/'update.zip').exists())
        status, body = self.request('/usb/select', {'id': updates[0]['id']})
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(body)['version'], '5.5.0')
        self.assertEqual((r.STATE/'update.zip').read_bytes(), original)
        self.assertFalse(r.JOB['running'])
        self.assertEqual(self.request('/usb/select', {'id': '/etc/passwd'})[0], 400)
    def test_usb_modified_file_and_install_in_progress_are_rejected(self):
        path = self.stick/'update.zip'
        path.write_bytes(update_archive())
        with patch.object(r, 'usb_roots', return_value=([(self.stick, 'USB')], [])):
            identifier = r.scan_usb_updates()['updates'][0]['id']
        r.JOB['running'] = True
        self.assertEqual(self.request('/usb/select', {'id': identifier})[0], 409)
        r.JOB['running'] = False
        path.write_bytes(b'changed')
        self.assertEqual(self.request('/usb/select', {'id': identifier})[0], 400)
        self.assertFalse((r.STATE/'update.zip').exists())
    def test_system_disk_excluded_and_usb_mounted_read_only(self):
        tree = {'blockdevices': [
            {'name': '/dev/sda', 'tran': 'usb', 'children': [{'name': '/dev/sda1', 'fstype': 'ext4', 'mountpoints': ['/']}]},
            {'name': '/dev/sdb', 'tran': 'usb', 'children': [{'name': '/dev/sdb1', 'fstype': 'vfat', 'mountpoints': [None]}]},
        ]}
        def run(args, **kwargs):
            if args[0] == 'lsblk':
                return types.SimpleNamespace(stdout=json.dumps(tree))
            self.assertEqual(args[:4], ['mount', '-o', 'ro,nosuid,nodev,noexec', '--'])
            self.assertEqual(args[4], '/dev/sdb1')
            return types.SimpleNamespace(returncode=0)
        with patch.object(r.subprocess, 'run', side_effect=run) as mocked:
            roots, errors = r.usb_roots()
        self.assertEqual(len(roots), 1)
        self.assertEqual(errors, [])
        self.assertEqual(mocked.call_count, 2)
    def test_terminal_backend_uses_its_independent_copy(self):
        old_root, old_backend = r.ROOT, r.TERMINAL_BACKEND
        r.ROOT = self.base/'isolated-program'
        (r.ROOT/'recovery-assets').mkdir(parents=True)
        (r.ROOT/'recovery-assets/terminal.py').write_text("def get(sid): return 'independent-backend'\n")
        r.TERMINAL_BACKEND = None
        try:
            self.assertEqual(r.terminal_backend().get('test'), 'independent-backend')
        finally:
            r.ROOT, r.TERMINAL_BACKEND = old_root, old_backend
    def test_assets_do_not_depend_on_main_server(self):
        old_root = r.ROOT
        r.ROOT = self.base/'program'
        (r.ROOT/'recovery-assets').mkdir(parents=True)
        (r.ROOT/'recovery-assets/xterm.js').write_text('/* offline terminal */')
        try:
            self.assertEqual(self.request('/assets/xterm.js', auth=False), (200, b'/* offline terminal */'))
            self.assertEqual(self.request('/assets/../admin.key', auth=False)[0], 401)
        finally:
            r.ROOT = old_root


@unittest.skipUnless(os.name == 'posix', 'Linux PTY integration requires a Linux runtime')
class PtyTest(unittest.TestCase):
    def test_real_shell_output_resize_and_termination(self):
        spec = importlib.util.spec_from_file_location('recovery_pty_test', ROOT/'system/terminal.py')
        backend = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(backend)
        session = backend.start('test', ['/bin/bash', '--noprofile', '--norc', '-i'], dict(os.environ, TERM='xterm-256color'), rows=24, cols=80)
        try:
            session.write("printf '%s' 'PTY_' 'WORKS'\n")
            collected = b''
            since = 0
            deadline = time.monotonic()+5
            while time.monotonic()<deadline and b'PTY_WORKS' not in collected:
                data = session.read(since, 0.2)
                collected += base64.b64decode(data['data'])
                since = data['seq']
            self.assertIn(b'PTY_WORKS', collected)
            session.resize(120, 30)
            session.write('stty size\n')
            collected = b''
            deadline = time.monotonic()+5
            while time.monotonic()<deadline and b'30 120' not in collected:
                data = session.read(since, 0.2)
                collected += base64.b64decode(data['data'])
                since = data['seq']
            self.assertIn(b'30 120', collected)
        finally:
            backend.stop('test')
        deadline = time.monotonic()+2
        while session.alive and time.monotonic()<deadline:
            time.sleep(0.02)
        self.assertFalse(session.alive)


class StartupTest(unittest.TestCase):
    @unittest.skipUnless(Path(r'C:\Program Files\Git\bin\bash.exe').exists() if os.name == 'nt' else Path('/bin/bash').exists(), 'Bash unavailable')
    def test_normal_start_and_unavailable_launcher_fallback(self):
        bash = r'C:\Program Files\Git\bin\bash.exe' if os.name == 'nt' else '/bin/bash'
        script = (ROOT/'system/start-browser.sh').read_text(encoding='utf-8-sig')
        fixture = r'''
command() { printf 'fixture_browser\n'; }
fixture_browser() {
 if [ "$1" = "--version" ]; then printf 'Chromium 130\n'; return 0; fi
 printf 'BROWSER_ARG:%s\n' "$@"
 exit 0
}
curl() { return FIXTURE_STATUS; }
python3() { printf 'normal\n'; }
sleep() { :; }
# Der Browser läuft seit 5.9 im Hintergrund; die Kiosk-Schleife nach dem ersten Lauf beenden.
wait() { builtin wait "$@"; exit 0; }
'''
        with tempfile.TemporaryDirectory() as folder:
            for ready, expected in [(True, 'http://127.0.0.1:8765/'), (False, 'http://127.0.0.1:8767/local')]:
                with self.subTest(ready=ready):
                    code = fixture.replace('FIXTURE_STATUS', '0' if ready else '1') + script
                    result = subprocess.run([bash, '--noprofile', '--norc', '-s'], input=code.encode('utf-8'),
                                            env=dict(os.environ, HOME=folder), capture_output=True, timeout=30)
                    self.assertEqual(result.returncode, 0, result.stderr.decode('utf-8', 'replace'))
                    log = Path(folder)/'raspi-tv-browser.log'
                    text = result.stdout.decode('utf-8') + (log.read_text(encoding='utf-8') if log.exists() else '')
                    if log.exists(): log.unlink()
                    args = [line for line in text.splitlines() if line.startswith('BROWSER_ARG:')]
                    self.assertEqual(args[-1], 'BROWSER_ARG:'+expected)


if __name__ == '__main__':
    unittest.main()
