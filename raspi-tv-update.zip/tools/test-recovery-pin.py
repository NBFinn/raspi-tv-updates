import importlib.util
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path
from http.server import ThreadingHTTPServer
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('recovery_pin', ROOT/'system/recovery.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)


class CodeTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        r.STATE = Path(self.tmp.name)
    def tearDown(self):
        self.tmp.cleanup()
    def test_generated_code_keeps_leading_zeroes_and_survives_restart(self):
        with patch.object(r.secrets, 'randbelow', return_value=42):
            self.assertEqual(r.load_admin_code(), '0042')
        self.assertEqual((r.STATE/'admin.key').read_text(), '0042')
        with patch.object(r.secrets, 'randbelow') as random:
            self.assertEqual(r.load_admin_code(), '0042')
            random.assert_not_called()
    def test_generation_covers_four_digit_boundaries(self):
        for value, expected in [(0, '0000'), (9999, '9999')]:
            with self.subTest(value=value):
                (r.STATE/'admin.key').unlink(missing_ok=True)
                with patch.object(r.secrets, 'randbelow', return_value=value) as random:
                    self.assertEqual(r.load_admin_code(), expected)
                    random.assert_called_once_with(10000)
    def test_old_or_invalid_codes_are_replaced_once(self):
        for old in ['long-legacy-admin-key', '', '123', '12345', 'a234', '１２３４']:
            with self.subTest(old=old):
                (r.STATE/'admin.key').write_text(old, encoding='utf-8')
                with patch.object(r.secrets, 'randbelow', return_value=731):
                    self.assertEqual(r.load_admin_code(), '0731')
                self.assertEqual(r.load_admin_code(), '0731')
    def test_validation_requires_exactly_four_ascii_digits(self):
        for value in ['0000', '0042', '9999']:
            self.assertTrue(r.valid_admin_code(value))
        for value in ['', '042', '00042', '１２３４', '12a4', ' 1234', '1234\n']:
            self.assertFalse(r.valid_admin_code(value))


class AuthTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        r.STATE = Path(self.tmp.name)
        r.ROOT = ROOT/'system'
        r.KEY = '0042'
        if hasattr(r, 'AUTH_FAILURES'):
            r.AUTH_FAILURES.clear()
        self.http = ThreadingHTTPServer(('127.0.0.1', 0), r.Handler)
        self.thread = threading.Thread(target=self.http.serve_forever, daemon=True)
        self.thread.start()
        self.url = 'http://127.0.0.1:' + str(self.http.server_port)
    def tearDown(self):
        self.http.shutdown()
        self.http.server_close()
        self.thread.join(timeout=2)
        self.tmp.cleanup()
    def request(self, code):
        request = urllib.request.Request(self.url+'/status', headers={'X-Admin-Key': code})
        try:
            with urllib.request.urlopen(request, timeout=3) as response:
                return response.status
        except urllib.error.HTTPError as error:
            error.close()
            return error.code
    def test_four_digits_authenticate_without_losing_zeroes(self):
        self.assertEqual(self.request('42'), 401)
        self.assertEqual(self.request('9999'), 401)
        self.assertEqual(self.request('0042'), 200)
    def test_failed_attempts_are_temporarily_limited(self):
        for _ in range(5):
            self.assertEqual(self.request('9999'), 401)
        self.assertEqual(self.request('9999'), 429)
        self.assertEqual(self.request('0042'), 429)
        with patch.object(r.time, 'monotonic', return_value=time.monotonic()+61):
            self.assertEqual(self.request('0042'), 200)
    def test_successful_login_clears_failed_attempts(self):
        for _ in range(4):
            self.assertEqual(self.request('9999'), 401)
        self.assertEqual(self.request('0042'), 200)
        for _ in range(4):
            self.assertEqual(self.request('9999'), 401)
        self.assertEqual(self.request('0042'), 200)


if __name__ == '__main__':
    unittest.main()
