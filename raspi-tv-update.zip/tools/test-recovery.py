import importlib.util
import io
import json
import tempfile
import threading
import unittest
import urllib.request
import urllib.error
import zipfile
from pathlib import Path
from unittest.mock import patch
from http.server import ThreadingHTTPServer

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('recovery',ROOT/'system/recovery.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)

def archive(extra=None):
 b=io.BytesIO()
 with zipfile.ZipFile(b,'w') as z:
  for name in r.REQUIRED:z.writestr(name,'5.4.1' if name=='VERSION' else 'test')
  for name,content in (extra or {}).items():z.writestr(name,content)
 return b.getvalue()

class RecoveryTest(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();r.STATE=Path(self.tmp.name);r.ROOT=ROOT/'system';r.KEY='0042';r.AUTH_FAILURES.clear();r.JOB.update(running=False,error=None,step='Bereit')
  self.http=ThreadingHTTPServer(('127.0.0.1',0),r.Handler)
  self.thread=threading.Thread(target=self.http.serve_forever,daemon=True);self.thread.start()
  self.url='http://127.0.0.1:'+str(self.http.server_port)
 def tearDown(self):self.http.shutdown();self.http.server_close();self.tmp.cleanup()
 def req(self,path,body=None,auth=True,origin=None):
  headers={}
  if auth:headers['X-Admin-Key']=r.KEY
  if origin:headers['Origin']=origin
  req=urllib.request.Request(self.url+path,data=body,headers=headers)
  try:
   with urllib.request.urlopen(req,timeout=5) as reply:return reply.status,reply.read()
  except urllib.error.HTTPError as e:return e.code,e.read()
 def test_independent_access_and_auth(self):
  self.assertEqual(self.req('/',auth=False)[0],200)
  self.assertEqual(self.req('/status',auth=False)[0],401)
  self.assertEqual(self.req('/upload',archive(),auth=False)[0],401)
  self.assertEqual(self.req('/upload',archive(),origin='http://evil.test')[0],403)
  with patch.object(r,'command',return_value='main service is down'):
   code,body=self.req('/diagnostics');self.assertEqual(code,200)
   self.assertEqual(json.loads(body)['service'],'main service is down')
 def test_upload_validation_and_install_handoff(self):
  self.assertEqual(self.req('/upload',b'bad zip')[0],400)
  self.assertEqual(self.req('/upload',archive({'../bad':'x'}))[0],400)
  self.assertEqual(self.req('/upload',archive({'/tmp/bad':'x'}))[0],400)
  self.assertFalse((r.STATE/'update.zip').exists())
  code,body=self.req('/upload',archive());self.assertEqual(code,200)
  self.assertEqual(json.loads(body)['version'],'5.4.1')
  self.assertFalse(r.JOB['running'],'Uploading must not install')
  installed=threading.Event()
  with patch.object(r,'install_worker',side_effect=installed.set):
   self.assertEqual(self.req('/install',b'')[0],202)
   self.assertTrue(installed.wait(2))
  self.assertEqual(self.req('/upload',archive())[0],409)
 def test_local_frontend_report(self):
  self.assertEqual(self.req('/report',b'{"message":"ReferenceError: Missing"}',auth=False,origin='http://127.0.0.1:8765')[0],200)
  self.assertIn('ReferenceError', (r.STATE/'frontend.log').read_text())
  self.assertEqual(self.req('/report',b'{}',auth=False,origin='http://evil.test')[0],403)

if __name__=='__main__':unittest.main()
