const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'launcher/remote.html'), 'utf8');
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.BROWSER_EXECUTABLE, headless: true });
  try {
    for (const android of [false, true]) {
      const calls = [], errors = [];
      const context = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true });
      const page = await context.newPage();
      page.on('pageerror', e => errors.push(e.message));
      const now = Math.floor(Date.now() / 1000);
      const state = { tv: 'on', time: now, channel: { name: 'Das Erste', num: 1, logo: '' }, now: { title: 'Tagesschau', start: now - 600, stop: now + 300 } };
      const media = { source: 'spotify', title: 'Testmusik', artist: 'Testkünstler', cover: '', playing: true, volume: { level: 45 }, ext_ok: true };
      const response = (url, body) => {
        calls.push({ path: url, data: body });
        if (url === '/r/ping') return { tv: 'on', lang: 'de' };
        if (url === '/r/state') return state;
        if (url === '/r/media') return media;
        if (url === '/r/media/ctl') { if (body.cmd === 'toggle') media.playing = !media.playing; return media; }
        if (url === '/r/channels') return { time: now, current: 'Das Erste', channels: [{ name: 'Das Erste', num: 1, now: state.now }] };
        return { ok: true };
      };
      await page.route('http://remote.test/**', r => {
        const req = r.request();
        if (req.method() === 'POST') return r.fulfill({ json: response(new URL(req.url()).pathname, req.postDataJSON()) });
        return r.fulfill({ contentType: 'text/html', body: html });
      });
      await page.addInitScript(() => localStorage.setItem('raspi-tv.token', 'test-token-123456789'));
      if (android) {
        await page.exposeFunction('__androidSend', msg => response(msg.path, msg.data));
        await page.addInitScript(() => {
          window.RaspiApp = { state: () => 'connected', lang: () => 'de', menu() {}, chooseDevice() {},
            send(text) { const msg = JSON.parse(text); window.__androidSend(msg).then(data => window.__raspiReply({ id: msg.id, data })); } };
        });
      }
      await page.goto('http://remote.test/remote.html');
      await page.waitForFunction(() => !document.getElementById('nowbar').hidden);
      for (const [width, height] of [[390,844],[360,640],[320,568],[844,390]]) {
        await page.setViewportSize({ width, height });
        await page.waitForTimeout(100);
        const layout = await page.evaluate(() => {
          const app = document.getElementById('app'), nav = document.getElementById('tabbar');
          const buttons = [...document.querySelectorAll('header button, #tabbar button')].filter(b => !b.hidden);
          return { docWidth: document.documentElement.scrollWidth, width: innerWidth, navBottom: nav.getBoundingClientRect().bottom,
            height: innerHeight, appRight: app.getBoundingClientRect().right,
            controls: buttons.map(b => ({ width: b.getBoundingClientRect().width, height: b.getBoundingClientRect().height })) };
        });
        assert(layout.docWidth <= width, `No horizontal clipping (${android ? 'Android' : 'WLAN'} ${width}x${height})`);
        assert(layout.navBottom <= height, 'Navigation stays on screen');
        assert(layout.controls.every(b => b.width >= 40 && b.height >= 40), 'Navigation and header targets remain touch friendly');
      }
      await page.setViewportSize({ width: 390, height: 844 });
      await page.locator('.dpad [data-key=up]').tap();
      await page.locator('.row3 [data-key=home]').first().tap();
      await page.waitForTimeout(100);
      assert(calls.some(c => c.path === '/r/key' && c.data.key === 'up'));
      assert(calls.some(c => c.path === '/r/key' && c.data.key === 'home'));
      await page.locator('[data-tab=channels]').tap();
      await page.locator('.chrow').waitFor();
      await page.locator('[data-tab=remote]').tap();
      await page.locator('#open-more').tap();
      await page.locator('#mode [data-mode=swipe]').tap();
      assert.equal(await page.locator('#swipe').isVisible(), true);
      await page.locator('#open-more').tap();
      await page.locator('#mode [data-mode=pad]').tap();
      state.channel = null;
      await page.waitForFunction(() => document.getElementById('nb-title').textContent === 'Testmusik');
      await page.locator('#nb-pp').tap();
      await page.waitForFunction(() => !!document.querySelector('#nb-pp path'));
      assert.equal(media.playing, false, 'Mini-player pauses through both transports');
      await page.locator('#nowbar').tap();
      await page.locator('#musicsheet.open .mp-main').tap();
      await page.waitForTimeout(100);
      assert.equal(media.playing, true);
      await page.locator('#musicsheet [data-mc=next]').tap();
      assert(calls.some(c => c.path === '/r/media/ctl' && c.data.cmd === 'next'));
      if (android) {
        await page.evaluate(() => window.__raspiShare('https://open.spotify.com/track/test'));
        await page.waitForTimeout(100);
        assert(calls.some(c => c.path === '/r/open' && c.data.text.includes('/track/test')));
      }
      media.source = 'web'; media.site = 'YouTube'; media.title = 'Testvideo';
      await page.waitForFunction(() => document.querySelector('.mp-title').textContent === 'Testvideo');
      assert.equal(await page.locator('.mp-src').textContent(), 'YouTube');
      if (!android) await page.screenshot({ path: path.join(root, 'artifacts/remote-390.png') });
      assert.deepEqual(errors, []);
      await context.close();
    }
    const preview = await browser.newPage({ viewport: { width: 360, height: 640 } });
    const errors = [];
    preview.on('pageerror', e => errors.push(e.message));
    await preview.route('http://preview.test/**', r => r.fulfill({ contentType: 'text/html', body: html }));
    await preview.goto('http://preview.test/?preview');
    for (const [theme, layout] of [['light','classic'],['aurora','big'],['midnight','top'],['forest','swipe']]) {
      await preview.evaluate(look => window.postMessage({ raspiLook: look }, '*'), { theme, layout });
      await preview.waitForFunction(name => document.body.classList.contains('L-' + name), layout);
      assert.equal(await preview.locator('#tabbar').isVisible(), true);
    }
    assert.deepEqual(errors, []);
    console.log('Remote browser checks passed: WLAN + Android bridge, music/video player, pause/resume/next, Android sharing, 4 viewport sizes, touch actions, channels, swipe, 4 themes/layouts.');
  } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exitCode = 1; });
