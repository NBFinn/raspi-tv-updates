import ast
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('repair_update',ROOT/'tools/repair-update.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)


class RepairTests(unittest.TestCase):
    def test_only_known_property_changes_and_repeat_run_is_safe(self):
        current=(ROOT/'system/maintenance.py').read_text(encoding='utf-8')
        # Recreate exactly the previous deployed command while retaining surrounding code.
        old=current.replace(repr(r.FILTER)+',\n                   '+repr(r.ERRNO),repr(r.OLD))
        self.assertNotEqual(old,current)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'maintenance.py';path.write_text(old,encoding='utf-8')
            backup=r.repair(path)
            self.assertEqual(backup.read_text(encoding='utf-8'),old)
            fixed=path.read_text(encoding='utf-8')
            self.assertEqual(ast.dump(ast.parse(fixed)),ast.dump(ast.parse(current)))
            self.assertIsNone(r.repair(path))
            self.assertEqual(len(list(Path(folder).iterdir())),2)

    def test_unknown_file_unchanged(self):
        for source in ('class SomethingElse: pass','class Maintenance:\n def _sandbox_install(self): return 0'):
            with tempfile.TemporaryDirectory() as folder:
                path=Path(folder)/'maintenance.py';path.write_text(source)
                with self.assertRaises(ValueError):r.repair(path)
                self.assertEqual(path.read_text(),source)
                self.assertEqual(len(list(Path(folder).iterdir())),1)

    def test_write_failure_preserves_installed_file(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'maintenance.py'
            source='class Maintenance:\n def _sandbox_install(self): return ['+repr(r.OLD)+']\n'
            path.write_text(source)
            with patch.object(r.os,'replace',side_effect=OSError('read-only')):
                with self.assertRaises(OSError):r.repair(path)
            self.assertEqual(path.read_text(),source)
            self.assertEqual(list(Path(folder).glob('.update-reparatur-*')),[])


if __name__=='__main__':unittest.main()
