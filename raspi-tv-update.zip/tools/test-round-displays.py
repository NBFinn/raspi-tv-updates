import importlib.util
import types
import io
from contextlib import redirect_stdout
import unittest
from unittest.mock import patch
from pathlib import Path
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('round_ui',ROOT/'system/round-displays.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
class RoundTests(unittest.TestCase):
 def test_independent_buses_and_control_pins(self):
  buses=[];pins=[];events=[]
  class Bus:
   def __init__(self):buses.append(self)
   def open(self,bus,cs):self.address=(bus,cs)
   def writebytes(self,data):events.append(('write',self.address,bytes(data)))
   def close(self):self.closed=True
  class Pin:
   def __init__(self,number,initial_value):self.number=number;pins.append(self)
   def on(self):events.append(('on',self.number))
   def off(self):events.append(('off',self.number))
   def close(self):self.closed=True
  with patch.object(r.time,'sleep'):
   displays,controls=r.open_displays(types.SimpleNamespace(SpiDev=Bus),Pin)
  self.assertEqual([b.address for b in buses],[(0,0),(1,0)])
  self.assertTrue(all(b.max_speed_hz==4_000_000 for b in buses))
  for address in ((0,0),(1,0)):
   writes=[event[2] for event in events if event[:2]==('write',address)]
   self.assertIn([b'\x36',b'\x48'],[writes[i:i+2] for i in range(len(writes)-1)])
  self.assertEqual([p.number for p in controls],[25,27,24,23])
  self.assertIs(displays[0].dc,pins[0]);self.assertIs(displays[1].dc,pins[2])
  self.assertIn(('off',27),events);self.assertIn(('off',23),events)
  events.clear();displays[1].command(0x29)
  self.assertEqual(events,[('off',24),('write',(1,0),b'\x29')])
 def test_inverted_cs_keeps_only_that_display_selected_and_reinitializes(self):
  buses=[];events=[];probed=[]
  class Bus:
   def __init__(self):self.no_cs=False;buses.append(self)
   def open(self,bus,cs):self.address=(bus,cs)
   def writebytes(self,data):events.append((self.address,self.no_cs,bytes(data)))
   def close(self):pass
  class Pin:
   def __init__(self,*args,**kwargs):pass
   def on(self):pass
   def off(self):pass
   def close(self):pass
  def probe(gpio):probed.append(gpio);return gpio==8
  with patch.object(r.time,'sleep'),redirect_stdout(io.StringIO()) as log:
   r.open_displays(types.SimpleNamespace(SpiDev=Bus),Pin,probe)
  self.assertEqual(probed,[8,18])
  self.assertEqual([b.no_cs for b in buses],[True,False])
  # Display 1 receives a complete init (incl. display-on) after CS handling was switched off.
  self.assertIn(((0,0),True,b'\x29'),events)
  self.assertNotIn(((1,0),True,b'\x29'),events)
  self.assertIn('GPIO8',log.getvalue())
 def test_pages_rotate_every_ten_seconds_and_volume_change_jumps_back(self):
  now=[0.0];clock=lambda:now[0]
  pages=r.Pages(clock)
  seen=[]
  def fake(name):return lambda *a,**k:seen.append(name) or name
  with patch.object(r,'album_frame',fake('clock')),patch.object(r,'wlan_frame',fake('wlan')),\
       patch.object(r,'system_frame',fake('system')),patch.object(r,'volume_frame',fake('volume')),\
       patch.object(r,'status_frame',fake('status')),patch.object(r,'update_frame',fake('update')):
   state={'volume':40,'muted':False,'target':'pi'}
   order=[]
   for t in (0,9.9,10,20,30):
    now[0]=t;order.append(pages.frames(state,True,None,{}))
   self.assertEqual(order,[['clock','volume'],['clock','volume'],['wlan','status'],['system','update'],['clock','volume']])
   now[0]=45;self.assertEqual(pages.frames(state,True,None,{})[1],'status')
   state=dict(state,volume=55);self.assertEqual(pages.frames(state,True,None,{})[1],'volume')
   now[0]=54.9;self.assertEqual(pages.frames(state,True,None,{})[1],'volume')
   now[0]=55;self.assertEqual(pages.frames(state,True,None,{})[1],'status')
   now[0]=56;self.assertEqual(pages.frames(dict(state,muted=True),True,None,{})[1],'volume')
   # Stale data never counts as a volume change.
   now[0]=66;self.assertEqual(pages.frames({},False,None,{})[1],'status')
   # A newly found update and a running installation show the update page.
   state=dict(state,muted=True,update={'newer':False})
   now[0]=67;pages.frames(state,True,None,{})
   self.assertEqual(pages.frames(dict(state,update={'newer':True,'latest':'9.0'}),True,None,{})[1],'update')
   now[0]=200;self.assertEqual(pages.frames(dict(state,update={'running':True}),True,None,{})[1],'update')
 def test_system_info_reads_proc_files_and_errors(self):
  import tempfile,json as js
  with tempfile.TemporaryDirectory() as folder:
   root=Path(folder)
   files={'proc/stat':'cpu  100 0 100 800 0 0 0 0 0 0\n','proc/meminfo':'MemTotal: 1000 kB\nMemAvailable: 250 kB\n',
          'sys/class/thermal/thermal_zone0/temp':'61234\n',
          'proc/net/wireless':'h1\nh2\n wlan0: 0000   56.  -54.  -256  0 0 0 0 0 0\n',
          'var/lib/raspi-tv-recovery/admin.key':'0815\n',
          'var/lib/raspi-tv-recovery/frontend.log':js.dumps({'at':'2026-11-11 21:00:00','message':'TypeError: x is undefined'})+'\n'}
   for name,text in files.items():
    p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
   def run(args,**k):
    out={'iwgetid':'Heimnetz\n','systemctl':'raspi-tv-ctl.service loaded failed failed X\n'}.get(args[0],'')
    return types.SimpleNamespace(stdout=out)
   wall=r.time.mktime(r.time.strptime('2026-11-11 22:00:00','%Y-%m-%d %H:%M:%S'))
   info=r.SystemInfo(root,run,wall=lambda:wall)
   first=info.snapshot()
   (root/'proc/stat').write_text('cpu  150 0 150 900 0 0 0 0 0 0\n')
   second=info.snapshot()
  self.assertIsNone(first['cpu']);self.assertEqual(second['cpu'],50)
  self.assertEqual((second['temp'],second['ram'],second['signal'],second['ssid']),(61,75,80,'Heimnetz'))
  # The admin code file exists in the fixture but must never be read or passed on.
  self.assertNotIn('0815',repr(second))
  self.assertEqual(second['errors'],['Dienst ausgefallen: raspi-tv-ctl','Oberflaeche: TypeError: x is undefined'])
 def test_brightness_dims_picture_and_keeps_full_by_default(self):
  image=Image.new('RGB',(240,240),(200,100,50))
  self.assertIs(r.dim(image,100),image);self.assertIs(r.dim(image,None),image);self.assertIs(r.dim(image,True),image)
  self.assertEqual(r.dim(image,50).getpixel((0,0)),(100,50,25))
  self.assertEqual(r.dim(image,1).getpixel((0,0)),(20,10,5))
 def test_admin_code_is_never_read_or_shown(self):
  source=(ROOT/'system/round-displays.py').read_text(encoding='utf-8')
  self.assertNotIn('admin.key',source);self.assertFalse(hasattr(r,'admin_frame'))
 def test_info_pages_render_and_handle_missing_values(self):
  for image in (r.wlan_frame({}),r.wlan_frame({'wlan':True,'signal':80,'ssid':'X'*40}),r.system_frame({}),
                r.system_frame({'cpu':95,'temp':75,'ram':40}),
                r.status_frame([]),r.status_frame(['Ein sehr langer Fehlertext '*10,'zweiter'])):
   self.assertEqual(image.size,(240,240))
  self.assertEqual(r.wrap('aaa bbb ccc',7,1),['aaa bb…'])
 def test_cs_probe_reads_idle_level(self):
  run=lambda text:(lambda *a,**k:types.SimpleNamespace(stdout=text))
  self.assertTrue(r.cs_idle_low(8,run(' 8: op dl pu | lo // GPIO8 = output\n')))
  self.assertFalse(r.cs_idle_low(18,run('18: op dh pd | hi // GPIO18 = output\n')))
  self.assertFalse(r.cs_idle_low(8,run(' 8: a0 pn | lo // GPIO8 = SPI0_CE0\n')))
  def missing(*a,**k):raise FileNotFoundError('pinctrl')
  self.assertFalse(r.cs_idle_low(8,missing))
 def test_failed_second_bus_releases_resources(self):
  buses=[];pins=[]
  class Bus:
   def __init__(self):self.closed=False;buses.append(self)
   def open(self,bus,cs):
    if bus==1:raise OSError('SPI1 unavailable')
   def writebytes(self,data):pass
   def close(self):self.closed=True
  class Pin:
   def __init__(self,*args,**kwargs):self.closed=False;pins.append(self)
   def on(self):pass
   def off(self):pass
   def close(self):self.closed=True
  with patch.object(r.time,'sleep'),self.assertRaisesRegex(OSError,'SPI1 unavailable'):
   r.open_displays(types.SimpleNamespace(SpiDev=Bus),Pin)
  self.assertTrue(all(b.closed for b in buses))
  self.assertTrue(all(p.closed for p in pins))
 def test_volume_ring_and_mute(self):
  zero=r.volume_frame(0);full=r.volume_frame(100);muted=r.volume_frame(100,True)
  self.assertEqual(full.size,(240,240))
  self.assertNotEqual(zero.getpixel((120,24)),full.getpixel((120,24)))
  self.assertEqual(zero.getpixel((120,24)),muted.getpixel((120,24)))
  self.assertEqual(r.volume_frame(None,'',target='tv').size,(240,240))
 def test_rgb565_wire_order_and_cached_frame(self):
  image=Image.new('RGB',(3,1));image.putdata([(255,0,0),(0,255,0),(0,0,255)])
  self.assertEqual(r.rgb565(image),b'\xf8\x00\x07\xe0\x00\x1f')
  writes=[];spi=types.SimpleNamespace(writebytes=lambda b:writes.append(b),writebytes2=lambda b:writes.append(b))
  dc=types.SimpleNamespace(on=lambda:None,off=lambda:None)
  driver=r.GC9A01(spi,dc);frame=r.volume_frame(42);driver.show(frame)
  self.assertEqual(len(writes[-1]),240*240*2)
  count=len(writes);driver.show(frame);self.assertEqual(len(writes),count)
 def test_failed_frame_is_retried(self):
  calls=[]
  def transmit(data):
   calls.append(data)
   if len(calls)==1:raise OSError('transfer failed')
  spi=types.SimpleNamespace(writebytes=lambda b:None,writebytes2=transmit)
  dc=types.SimpleNamespace(on=lambda:None,off=lambda:None)
  driver=r.GC9A01(spi,dc);frame=r.volume_frame(42)
  with self.assertRaises(OSError):driver.show(frame)
  driver.show(frame)
  self.assertEqual(len(calls),2)
 def test_numbered_hardware_probe_without_api(self):
  buses=[];pins=[]
  class Bus:
   def __init__(self):self.frames=[];self.closed=False;buses.append(self)
   def open(self,bus,cs):self.address=(bus,cs)
   def writebytes(self,data):pass
   def writebytes2(self,data):self.frames.append(data)
   def close(self):self.closed=True
  class Pin:
   def __init__(self,*args,**kwargs):self.closed=False;pins.append(self)
   def on(self):pass
   def off(self):pass
   def close(self):self.closed=True
  with patch.dict(r.sys.modules,{'spidev':types.SimpleNamespace(SpiDev=Bus),'gpiozero':types.SimpleNamespace(DigitalOutputDevice=Pin)}),patch.object(r.time,'sleep'),patch.object(r.signal,'signal'),patch('builtins.input',return_value=''),patch.object(r.urllib.request,'urlopen') as api,redirect_stdout(io.StringIO()):
   r.main(test=True)
  api.assert_not_called()
  self.assertEqual(len(buses),2)
  self.assertNotEqual(buses[0].frames[0],buses[1].frames[0])
  self.assertTrue(all(len(b.frames[0])==240*240*2 for b in buses))
  self.assertTrue(all(b.closed for b in buses))
  self.assertTrue(all(p.closed for p in pins))
 def test_album_and_clock(self):
  music={'title':'Nachts am Meer','artist':'Raspi-TV','playing':True}
  cover=Image.new('RGB',(240,240),'#164a70')
  self.assertEqual(r.album_frame(music,cover).size,(240,240))
  self.assertEqual(r.album_frame({}).size,(240,240))

if __name__=='__main__':
 result=unittest.main(exit=False).result
 if not result.wasSuccessful():raise SystemExit(1)
 cover=Image.new('RGB',(240,240),'#123857');d=ImageDraw.Draw(cover)
 for radius in range(100,0,-4):d.ellipse((120-radius,120-radius,120+radius,120+radius),outline=(30,100+radius,140+radius//2),width=2)
 left=r.album_frame({'title':'Nachts am Meer','artist':'Raspi-TV','playing':True},cover);right=r.volume_frame(42)
 preview=Image.new('RGB',(520,280),'#0b1020');mask=Image.new('L',(240,240));ImageDraw.Draw(mask).ellipse((0,0,239,239),fill=255)
 preview.paste(left,(10,15),mask);preview.paste(right,(270,15),mask)
 preview.save(ROOT/'artifacts/round-volume-ring.png')
