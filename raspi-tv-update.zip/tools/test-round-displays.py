import tempfile
import importlib.util
import types
import io
from contextlib import redirect_stdout
import unittest
from unittest.mock import patch
from pathlib import Path
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('round_ui',ROOT/'system/round-displays.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
class RoundTests(unittest.TestCase):
 def test_independent_buses_and_control_pins(self):
  buses=[];pins=[];events=[]
  class Bus:
   def __init__(self):buses.append(self)
   def open(self,bus,cs):self.address=(bus,cs)
   def writebytes(self,data):events.append(('write',self.address,bytes(data)))
   def close(self):self.closed=True
  class Pin:
   def __init__(self,number,initial_value):self.number=number;pins.append(self)
   def on(self):events.append(('on',self.number))
   def off(self):events.append(('off',self.number))
   def close(self):self.closed=True
  with patch.object(r.time,'sleep'):
   displays,controls=r.open_displays(types.SimpleNamespace(SpiDev=Bus),Pin)
  self.assertEqual([b.address for b in buses],[(0,0),(1,0)])
  self.assertTrue(all(b.max_speed_hz==4_000_000 for b in buses))
  for address in ((0,0),(1,0)):
   writes=[event[2] for event in events if event[:2]==('write',address)]
   self.assertIn([b'\x36',b'\x48'],[writes[i:i+2] for i in range(len(writes)-1)])
  self.assertEqual([p.number for p in controls],[25,27,24,23])
  self.assertIs(displays[0].dc,pins[0]);self.assertIs(displays[1].dc,pins[2])
  self.assertIn(('off',27),events);self.assertIn(('off',23),events)
  events.clear();displays[1].command(0x29)
  self.assertEqual(events,[('off',24),('write',(1,0),b'\x29')])
 def test_inverted_cs_keeps_only_that_display_selected_and_reinitializes(self):
  buses=[];events=[];probed=[]
  class Bus:
   def __init__(self):self.no_cs=False;buses.append(self)
   def open(self,bus,cs):self.address=(bus,cs)
   def writebytes(self,data):events.append((self.address,self.no_cs,bytes(data)))
   def close(self):pass
  class Pin:
   def __init__(self,*args,**kwargs):pass
   def on(self):pass
   def off(self):pass
   def close(self):pass
  def probe(gpio):probed.append(gpio);return gpio==8
  with patch.object(r.time,'sleep'),redirect_stdout(io.StringIO()) as log:
   r.open_displays(types.SimpleNamespace(SpiDev=Bus),Pin,probe)
  self.assertEqual(probed,[8,18])
  self.assertEqual([b.no_cs for b in buses],[True,False])
  # Display 1 receives a complete init (incl. display-on) after CS handling was switched off.
  self.assertIn(((0,0),True,b'\x29'),events)
  self.assertNotIn(((1,0),True,b'\x29'),events)
  self.assertIn('GPIO8',log.getvalue())
 def test_pages_rotate_every_ten_seconds_and_volume_change_jumps_back(self):
  now=[0.0];clock=lambda:now[0]
  pages=r.Pages(clock)
  seen=[]
  def fake(name):return lambda *a,**k:seen.append(name) or name
  with patch.object(r,'album_frame',fake('clock')),patch.object(r,'wlan_frame',fake('wlan')),\
       patch.object(r,'system_frame',fake('system')),patch.object(r,'volume_frame',fake('volume')),\
       patch.object(r,'status_frame',fake('status')),patch.object(r,'update_frame',fake('update')):
   state={'volume':40,'muted':False,'target':'pi'}
   order=[]
   for t in (0,9.9,10,20,30):
    now[0]=t;order.append(pages.frames(state,True,None,{}))
   self.assertEqual(order,[['clock','volume'],['clock','volume'],['wlan','status'],['system','update'],['clock','volume']])
   now[0]=45;self.assertEqual(pages.frames(state,True,None,{})[1],'status')
   state=dict(state,volume=55);self.assertEqual(pages.frames(state,True,None,{})[1],'volume')
   now[0]=54.9;self.assertEqual(pages.frames(state,True,None,{})[1],'volume')
   now[0]=55;self.assertEqual(pages.frames(state,True,None,{})[1],'status')
   now[0]=56;self.assertEqual(pages.frames(dict(state,muted=True),True,None,{})[1],'volume')
   # Stale data never counts as a volume change.
   now[0]=66;self.assertEqual(pages.frames({},False,None,{})[1],'status')
   # A newly found update and a running installation show the update page.
   state=dict(state,muted=True,update={'newer':False})
   now[0]=67;pages.frames(state,True,None,{})
   self.assertEqual(pages.frames(dict(state,update={'newer':True,'latest':'9.0'}),True,None,{})[1],'update')
   now[0]=200;self.assertEqual(pages.frames(dict(state,update={'running':True}),True,None,{})[1],'update')
 def test_teensy_state_line_and_port_detection(self):
  line=r.teensy_state_line({'music':{'title':'A\tB','artist':'C','playing':True},'volume':42,'muted':False,'target':'pi',
                            'palette':{'accent':'#123456','bg':'#000000'},'update':{'installed':'7.0.0','newer':True,'latest':'7.1.0'},
                            'version':'7.0.0','brightness':80},{'cpu':12,'errors':['Kaputt']},None,True,now=1000)
  self.assertTrue(line.startswith('S '))
  fields=dict(part.split('=',1) for part in line[2:].split('\t'))
  self.assertEqual((fields['v'],fields['ti'],fields['ac'],fields['un'],fields['ul'],fields['ne'],fields['e1']),('42','A B','#123456','1','7.1.0','1','Kaputt'))
  self.assertNotIn('\n',line)
  with tempfile.TemporaryDirectory() as folder:
   root=Path(folder);dev=root/'sys/devices/usb1/1-1/1-1:1.0/tty/ttyACM0';dev.mkdir(parents=True)
   (root/'sys/devices/usb1/1-1/idVendor').write_text('16c0\n');(root/'sys/devices/usb1/1-1/idProduct').write_text('0483\n')
   (root/'sys/class/tty').mkdir(parents=True);(root/'sys/class/tty/ttyACM0').symlink_to(dev)
   (dev/'device').symlink_to(root/'sys/devices/usb1/1-1/1-1:1.0')
   self.assertEqual(r.teensy_port(root),str(root/'dev/ttyACM0'))
   (root/'sys/devices/usb1/1-1/idVendor').write_text('1234\n')
   self.assertIsNone(r.teensy_port(root))

 def test_teensy_auto_detect_any_port_and_usb_type(self):
  with tempfile.TemporaryDirectory() as folder:
   root=Path(folder)
   usb=root/'sys/devices/usb1/1-3/1-3.2';(usb/'1-3.2:1.0/tty').mkdir(parents=True)
   (usb/'idVendor').write_text('16c0\n');(usb/'idProduct').write_text('0489\n')   # Serial+MIDI
   other=root/'sys/devices/usb1/1-4';(other/'1-4:1.0').mkdir(parents=True)
   (other/'idVendor').write_text('10c4\n');(other/'idProduct').write_text('ea60\n')
   (root/'sys/class/tty/ttyUSB0').mkdir(parents=True);(root/'sys/class/tty/ttyUSB0/device').symlink_to(other/'1-4:1.0')
   (root/'sys/class/tty/ttyACM3').mkdir(parents=True);(root/'sys/class/tty/ttyACM3/device').symlink_to(usb/'1-3.2:1.0')
   (root/'sys/class/tty/tty1').mkdir(parents=True)
   self.assertEqual(r.teensy_port(root),str(root/'dev/ttyACM3'))
   self.assertEqual(len(r.serial_ports(root)),2)
   calls=[]
   class Res:
    def __init__(self,c):self.returncode=c
   def run(cmd,timeout=0):calls.append(cmd);return Res(3)
   old=(r.TEENSY_SCAN,r.TEENSY_PRESENT);r.TEENSY_SCAN=root/'scan.json';r.TEENSY_PRESENT=root/'present'
   try:r.teensy_watch(run=run,root=root,sleep=lambda s:None,rounds=1)
   finally:r.TEENSY_SCAN,r.TEENSY_PRESENT=old
   self.assertIn(['systemctl','start','--no-block','raspi-tv-round.service'],calls)
   self.assertEqual((root/'present').read_text(),str(root/'dev/ttyACM3'))
   self.assertIn('ttyUSB0 (10c4:ea60)',(root/'scan.json').read_text())

 def test_vu_levels_and_new_state_keys(self):
  import array,math
  def tone(left,right):
   a=array.array('h')
   for i in range(400):a.append(int(left*math.sin(i*.5)));a.append(int(right*math.sin(i*.37)))
   return a.tobytes()
  (l,r_),ref=r.vu_levels(tone(8000,2000),0)
  self.assertGreater(l,80);self.assertTrue(30<r_<l)           # links laut, rechts leiser
  (l2,r2),ref=r.vu_levels(tone(10,10),ref);self.assertEqual((l2,r2),(0,0))   # Stille
  (l3,_),_=r.vu_levels(tone(800,800),0);self.assertGreater(l3,80)            # leise Wiedergabe schlägt genauso aus
  line=r.teensy_state_line({'clock':3,'vu':2,'time':0},{},None,False)
  self.assertIn('\tcs=3\tvu=2',line)
  self.assertIn('\tcs=0\tvu=0',r.teensy_state_line({'clock':9,'vu':'x'},{},None,False))

 def test_teensy_firmware_update_without_button(self):
  with tempfile.TemporaryDirectory() as folder:
   log=Path(folder)/'flash.json'
   self.assertTrue(r.teensy_flash_allowed('1.0.1',log,now=1000))
   self.assertFalse(r.teensy_flash_allowed('1.0.1',log,now=1100))      # nicht gleich wieder (5 min Abstand)
   self.assertTrue(r.teensy_flash_allowed('1.0.1',log,now=1500))       # 2. Versuch
   self.assertTrue(r.teensy_flash_allowed('1.0.1',log,now=2000))       # 3. Versuch
   self.assertFalse(r.teensy_flash_allowed('1.0.1',log,now=99999))     # höchstens 3 automatische Versuche
   self.assertTrue(r.teensy_flash_allowed('1.0.1',log,now=99999,force=True))   # Knopf in den Einstellungen
   self.assertTrue(r.teensy_flash_allowed('1.0.2',log,now=99999))      # neue Version
   self.assertEqual(r.reset_text('0x1'),'Strom eingeschaltet oder Spannung eingebrochen')
   self.assertEqual(r.reset_text('2'),'Neustart durch Software oder Absturz')
   sent=[];calls=[]
   class Link:
    port='/dev/x';version='1.0.0';fd=-1
    def line(self,t):sent.append(t)
    def close(self):sent.append('close')
   hexfile=Path(folder)/'fw.hex';hexfile.write_text(':00000001FF\n')
   def run(cmd,**k):calls.append(cmd);return types.SimpleNamespace(returncode=0,stdout='',stderr='')
   with patch.object(r,'TEENSY_FLASH_LOG',Path(folder)/'f2.json'),patch.object(r,'TEENSY_STATUS',Path(folder)/'st.json'),\
        patch.object(r.shutil,'which',lambda n:'/usr/bin/'+n):
    self.assertTrue(r.teensy_flash(Link(),hexfile,run,'1.0.1'))
   self.assertEqual(sent,['B','close'])
   self.assertEqual(calls,[['systemctl','start','raspi-tv-teensy-flash.service']])

 def test_halfkay_flasher_writes_blocks_without_extra_program(self):
  with tempfile.TemporaryDirectory() as folder:
   hexfile=Path(folder)/'fw.hex'
   def rec(addr,kind,data):
    raw=bytes([len(data),addr>>8&255,addr&255,kind])+data
    return ':'+(raw+bytes([(-sum(raw))&255])).hex().upper()
   hexfile.write_text('\n'.join([rec(0,4,b'\x60\x00'),rec(0,0,b'\x11\x22'),rec(0x0800,0,b'\x33'),rec(0,1,b'')])+'\n')
   image,mask=r.read_ihex(hexfile)
   self.assertEqual((image[0],image[1],image[0x800],mask[2]),(0x11,0x22,0x33,0))
   blocks=list(r.halfkay_blocks(image,mask))
   self.assertEqual([a for a,_ in blocks],[0,0x800])
   self.assertEqual(blocks[1][1][:3],bytes([0x00,0x08,0x00]));self.assertEqual(len(blocks[1][1]),1088)
   sent=[];fails=[2]
   def write(fd,data):
    if fails[0]:fails[0]-=1;raise OSError(32,'busy')
    sent.append(data)
   with patch.object(r.os,'close',lambda fd:None):
    self.assertTrue(r.halfkay_flash(hexfile,device='/dev/x',writer=write,opener=lambda p,f:7,log=lambda m:None))
   self.assertEqual(len(sent),3)                       # 2 Blöcke + Start-Befehl
   self.assertTrue(all(d[0]==0 and len(d)==1089 for d in sent))
   self.assertEqual(sent[-1][1:4],b'\xff\xff\xff')
   bad=Path(folder)/'bad.hex';bad.write_text(':0100000011EF\n')
   with self.assertRaises(ValueError):r.read_ihex(bad)
   sysroot=Path(folder)/'root';dev=sysroot/'sys/class/hidraw/hidraw3/device';dev.mkdir(parents=True)
   (dev/'uevent').write_text('DRIVER=hid-generic\nHID_ID=0003:000016C0:00000478\n')
   self.assertEqual(r.find_halfkay(sysroot),str(sysroot/'dev/hidraw3'))

 def test_system_info_reads_proc_files_and_errors(self):
  import tempfile,json as js
  with tempfile.TemporaryDirectory() as folder:
   root=Path(folder)
   files={'proc/stat':'cpu  100 0 100 800 0 0 0 0 0 0\n','proc/meminfo':'MemTotal: 1000 kB\nMemAvailable: 250 kB\n',
          'sys/class/thermal/thermal_zone0/temp':'61234\n',
          'proc/net/wireless':'h1\nh2\n wlan0: 0000   56.  -54.  -256  0 0 0 0 0 0\n',
          'var/lib/raspi-tv-recovery/admin.key':'0815\n',
          'var/lib/raspi-tv-recovery/frontend.log':js.dumps({'at':'2026-11-11 21:00:00','message':'TypeError: x is undefined'})+'\n'}
   for name,text in files.items():
    p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
   def run(args,**k):
    out={'iwgetid':'Heimnetz\n','systemctl':'raspi-tv-ctl.service loaded failed failed X\n'}.get(args[0],'')
    return types.SimpleNamespace(stdout=out)
   wall=r.time.mktime(r.time.strptime('2026-11-11 22:00:00','%Y-%m-%d %H:%M:%S'))
   info=r.SystemInfo(root,run,wall=lambda:wall)
   first=info.snapshot()
   (root/'proc/stat').write_text('cpu  150 0 150 900 0 0 0 0 0 0\n')
   second=info.snapshot()
  self.assertIsNone(first['cpu']);self.assertEqual(second['cpu'],50)
  self.assertEqual((second['temp'],second['ram'],second['signal'],second['ssid']),(61,75,80,'Heimnetz'))
  # The admin code file exists in the fixture but must never be read or passed on.
  self.assertNotIn('0815',repr(second))
  self.assertEqual(second['errors'],['Dienst ausgefallen: raspi-tv-ctl','Oberflaeche: TypeError: x is undefined'])
 def test_brightness_dims_picture_and_keeps_full_by_default(self):
  image=Image.new('RGB',(240,240),(200,100,50))
  self.assertIs(r.dim(image,100),image);self.assertIs(r.dim(image,None),image);self.assertIs(r.dim(image,True),image)
  self.assertEqual(r.dim(image,50).getpixel((0,0)),(100,50,25))
  self.assertEqual(r.dim(image,1).getpixel((0,0)),(20,10,5))
 def test_admin_code_is_never_read_or_shown(self):
  source=(ROOT/'system/round-displays.py').read_text(encoding='utf-8')
  self.assertNotIn('admin.key',source);self.assertFalse(hasattr(r,'admin_frame'))
 def test_info_pages_render_and_handle_missing_values(self):
  for image in (r.wlan_frame({}),r.wlan_frame({'wlan':True,'signal':80,'ssid':'X'*40}),r.system_frame({}),
                r.system_frame({'cpu':95,'temp':75,'ram':40}),
                r.status_frame([]),r.status_frame(['Ein sehr langer Fehlertext '*10,'zweiter'])):
   self.assertEqual(image.size,(240,240))
  self.assertEqual(r.wrap('aaa bbb ccc',7,1),['aaa bb…'])
 def test_cs_probe_reads_idle_level(self):
  run=lambda text:(lambda *a,**k:types.SimpleNamespace(stdout=text))
  self.assertTrue(r.cs_idle_low(8,run(' 8: op dl pu | lo // GPIO8 = output\n')))
  self.assertFalse(r.cs_idle_low(18,run('18: op dh pd | hi // GPIO18 = output\n')))
  self.assertFalse(r.cs_idle_low(8,run(' 8: a0 pn | lo // GPIO8 = SPI0_CE0\n')))
  def missing(*a,**k):raise FileNotFoundError('pinctrl')
  self.assertFalse(r.cs_idle_low(8,missing))
 def test_failed_second_bus_releases_resources(self):
  buses=[];pins=[]
  class Bus:
   def __init__(self):self.closed=False;buses.append(self)
   def open(self,bus,cs):
    if bus==1:raise OSError('SPI1 unavailable')
   def writebytes(self,data):pass
   def close(self):self.closed=True
  class Pin:
   def __init__(self,*args,**kwargs):self.closed=False;pins.append(self)
   def on(self):pass
   def off(self):pass
   def close(self):self.closed=True
  with patch.object(r.time,'sleep'),self.assertRaisesRegex(OSError,'SPI1 unavailable'):
   r.open_displays(types.SimpleNamespace(SpiDev=Bus),Pin)
  self.assertTrue(all(b.closed for b in buses))
  self.assertTrue(all(p.closed for p in pins))
 def test_volume_ring_and_mute(self):
  zero=r.volume_frame(0);full=r.volume_frame(100);muted=r.volume_frame(100,True)
  self.assertEqual(full.size,(240,240))
  self.assertNotEqual(zero.getpixel((120,24)),full.getpixel((120,24)))
  self.assertEqual(zero.getpixel((120,24)),muted.getpixel((120,24)))
  self.assertEqual(r.volume_frame(None,'',target='tv').size,(240,240))
 def test_rgb565_wire_order_and_cached_frame(self):
  image=Image.new('RGB',(3,1));image.putdata([(255,0,0),(0,255,0),(0,0,255)])
  self.assertEqual(r.rgb565(image),b'\xf8\x00\x07\xe0\x00\x1f')
  writes=[];spi=types.SimpleNamespace(writebytes=lambda b:writes.append(b),writebytes2=lambda b:writes.append(b))
  dc=types.SimpleNamespace(on=lambda:None,off=lambda:None)
  driver=r.GC9A01(spi,dc);frame=r.volume_frame(42);driver.show(frame)
  self.assertEqual(len(writes[-1]),240*240*2)
  count=len(writes);driver.show(frame);self.assertEqual(len(writes),count)
 def test_failed_frame_is_retried(self):
  calls=[]
  def transmit(data):
   calls.append(data)
   if len(calls)==1:raise OSError('transfer failed')
  spi=types.SimpleNamespace(writebytes=lambda b:None,writebytes2=transmit)
  dc=types.SimpleNamespace(on=lambda:None,off=lambda:None)
  driver=r.GC9A01(spi,dc);frame=r.volume_frame(42)
  with self.assertRaises(OSError):driver.show(frame)
  driver.show(frame)
  self.assertEqual(len(calls),2)
 def test_numbered_hardware_probe_without_api(self):
  buses=[];pins=[]
  class Bus:
   def __init__(self):self.frames=[];self.closed=False;buses.append(self)
   def open(self,bus,cs):self.address=(bus,cs)
   def writebytes(self,data):pass
   def writebytes2(self,data):self.frames.append(data)
   def close(self):self.closed=True
  class Pin:
   def __init__(self,*args,**kwargs):self.closed=False;pins.append(self)
   def on(self):pass
   def off(self):pass
   def close(self):self.closed=True
  with patch.dict(r.sys.modules,{'spidev':types.SimpleNamespace(SpiDev=Bus),'gpiozero':types.SimpleNamespace(DigitalOutputDevice=Pin)}),patch.object(r.time,'sleep'),patch.object(r.signal,'signal'),patch('builtins.input',return_value=''),patch.object(r.urllib.request,'urlopen') as api,redirect_stdout(io.StringIO()):
   r.main(test=True)
  api.assert_not_called()
  self.assertEqual(len(buses),2)
  self.assertNotEqual(buses[0].frames[0],buses[1].frames[0])
  self.assertTrue(all(len(b.frames[0])==240*240*2 for b in buses))
  self.assertTrue(all(b.closed for b in buses))
  self.assertTrue(all(p.closed for p in pins))
 def test_album_and_clock(self):
  music={'title':'Nachts am Meer','artist':'Raspi-TV','playing':True}
  cover=Image.new('RGB',(240,240),'#164a70')
  self.assertEqual(r.album_frame(music,cover).size,(240,240))
  self.assertEqual(r.album_frame({}).size,(240,240))

if __name__=='__main__':
 result=unittest.main(exit=False).result
 if not result.wasSuccessful():raise SystemExit(1)
 cover=Image.new('RGB',(240,240),'#123857');d=ImageDraw.Draw(cover)
 for radius in range(100,0,-4):d.ellipse((120-radius,120-radius,120+radius,120+radius),outline=(30,100+radius,140+radius//2),width=2)
 left=r.album_frame({'title':'Nachts am Meer','artist':'Raspi-TV','playing':True},cover);right=r.volume_frame(42)
 preview=Image.new('RGB',(520,280),'#0b1020');mask=Image.new('L',(240,240));ImageDraw.Draw(mask).ellipse((0,0,239,239),fill=255)
 preview.paste(left,(10,15),mask);preview.paste(right,(270,15),mask)
 preview.save(ROOT/'artifacts/round-volume-ring.png')
