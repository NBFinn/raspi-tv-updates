import importlib.util
import json
import threading
import unittest
import urllib.request
import urllib.error
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('helper',ROOT/'windows-screen/screen_helper.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
class HelperTests(unittest.TestCase):
 def test_pair_validation_and_token_not_returned(self):
  relay=h.Relay();calls=[]
  relay.call=lambda *args:(calls.append(args) or {'token':'private-paired-token'})
  for data in ({'ip':'8.8.8.8','pin':'123456'},{'ip':'192.168.1.5','pin':'１２３４５６'},{'ip':'192.168.1.5','pin':'123'}):
   with self.assertRaises(ValueError):relay.pair(data)
  self.assertEqual(calls,[])
  self.assertEqual(relay.pair({'ip':'192.168.1.5','pin':'123456'}),{'ok':True})
  self.assertEqual(relay.token,'private-paired-token')
  with self.assertRaises(ValueError):relay.signal({'action':'reboot'})
 def test_local_nonce_and_origin_required(self):
  relay=type('Relay',(),{'pair':lambda self,data:{'ok':True},'signal':lambda self,data:{'ended':True}})()
  server=h.Server(('127.0.0.1',0),relay);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  address='http://127.0.0.1:'+str(server.server_port)
  def req(key=None,origin=None):
   headers={'Content-Type':'application/json'}
   if key:headers['X-Local-Key']=key
   if origin:headers['Origin']=origin
   try:
    with urllib.request.urlopen(urllib.request.Request(address+'/pair',data=b'{}',headers=headers),timeout=3) as r:return r.status
   except urllib.error.HTTPError as e:return e.code
  try:
   self.assertEqual(req(),403)
   self.assertEqual(req(server.nonce,'http://evil.test'),403)
   self.assertEqual(req(server.nonce,address),200)
  finally:server.shutdown();server.server_close()
if __name__=='__main__':unittest.main()
