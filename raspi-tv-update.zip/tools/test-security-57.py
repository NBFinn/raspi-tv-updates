import ast
import concurrent.futures
import importlib.util
import io
import json
import re
import hmac
import tempfile
import threading
import types
import unittest
import zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('recovery_security',ROOT/'system/recovery.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)

class SecurityTests(unittest.TestCase):
 def zip(self,path,extra):
  with zipfile.ZipFile(path,'w') as z:
   for n in r.REQUIRED:z.writestr(n,'5.7.0' if n=='VERSION' else 'content')
   for n,c in extra.items():z.writestr(n,c)
 def test_aliases_and_file_directory_collisions(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'test.zip'
   self.zip(p,{})
   self.assertEqual(r.inspect_update(p),('', '5.7.0'))
   for extra in ({'./VERSION':'other'},{'system//extra.py':'x'},{'a':'file','a/b':'nested'}):
    self.zip(p,extra)
    with self.assertRaises(ValueError):r.inspect_update(p)
 def test_corrupt_file_rejected_before_extraction(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'test.zip';self.zip(p,{'payload':'unique-original-bytes'})
   p.write_bytes(p.read_bytes().replace(b'unique-original-bytes',b'unique-modified-bytes'))
   with self.assertRaises((ValueError,zipfile.BadZipFile)):r.inspect_update(p)
 def test_pairing_pin_consumed_atomically(self):
  tree=ast.parse((ROOT/'system/tvctl.py').read_text(encoding='utf-8'))
  fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='remote_pair')
  barrier=threading.Barrier(2)
  class Gate:
   lock=threading.Lock()
   def __enter__(self):self.lock.acquire()
   def __exit__(self,*args):self.lock.release();barrier.wait(timeout=5)
  class ApiError(Exception):pass
  env={'re':re,'hmac':hmac,'time':types.SimpleNamespace(time=lambda:100,sleep=lambda _:None),
       '_PIN':{'pin':'123456','until':1000,'locked_until':0,'fails':0},'_PIN_LOCK':Gate(),
       'ApiError':ApiError,'remote_token':lambda:'token'}
  exec(compile(ast.Module(body=[fn],type_ignores=[]),'remote_pair','exec'),env)
  def attempt(_):
   try:return env['remote_pair']({'pin':'123456'})
   except ApiError:return None
  with concurrent.futures.ThreadPoolExecutor(2) as pool:results=list(pool.map(attempt,range(2)))
  self.assertEqual(sum(x is not None for x in results),1)
 def test_remote_body_limit_before_read(self):
  tree=ast.parse((ROOT/'system/tvctl.py').read_text(encoding='utf-8'))
  cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='RemoteHandler')
  fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_body')
  class ApiError(Exception):
   def __init__(self,text,code=400):self.code=code
  env={'json':json,'ApiError':ApiError}
  exec(compile(ast.Module(body=[fn],type_ignores=[]),'_body','exec'),env)
  for size in [-1,8193,1000000000]:
   stream=io.BytesIO(b'{}');h=types.SimpleNamespace(headers={'Content-Type':'application/json','Content-Length':str(size)},rfile=stream)
   with self.assertRaises(ApiError):env['_body'](h)
   self.assertEqual(stream.tell(),0,'Invalid lengths must not trigger a read')
  h=types.SimpleNamespace(headers={'Content-Type':'application/json','Content-Length':'2'},rfile=io.BytesIO(b'{}'))
  self.assertEqual(env['_body'](h),{})
 def test_remote_response_prevents_foreign_framing(self):
  tree=ast.parse((ROOT/'system/tvctl.py').read_text(encoding='utf-8'))
  cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='RemoteHandler')
  fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_send')
  env={};exec(compile(ast.Module(body=[fn],type_ignores=[]),'_send','exec'),env)
  headers={}
  handler=types.SimpleNamespace(send_response=lambda _:None,send_header=lambda k,v:headers.update({k:v}),end_headers=lambda:None,wfile=io.BytesIO(),command='GET')
  env['_send'](handler,200,b'hello','text/html')
  self.assertEqual(headers['X-Frame-Options'],'SAMEORIGIN')
  self.assertEqual(headers['Content-Security-Policy'],"frame-ancestors 'self'")

if __name__=='__main__':unittest.main()
