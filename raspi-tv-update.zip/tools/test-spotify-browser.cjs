// Real browser/DOM/audio; Chrome's extension API is adapted to Playwright tabs.
// Requires playwright. BROWSER_EXECUTABLE optionally selects an installed browser.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { chromium } = require('playwright');
const root = path.resolve(__dirname, '..');
const read = name => fs.readFileSync(path.join(root, name), 'utf8');
const HOME = 'http://127.0.0.1:8765/';

(async () => {
  const browser = await chromium.launch({ headless: true, executablePath: process.env.BROWSER_EXECUTABLE,
    args: ['--autoplay-policy=no-user-gesture-required'] });
  try {
    const context = await browser.newContext({ viewport: { width: 1280, height: 720 } });
    const pages = new Map(), listeners = [], pageErrors = [], updates = [];
    let nextId = 1, activeId, now = {};
    const sendToWorker = (id, msg) => new Promise(resolve => {
      let async = false;
      for (const listener of listeners) {
        if (listener(msg, { tab: { id, url: pages.get(id).url() } }, resolve) === true) async = true;
      }
      if (!async) resolve({});
    });
    const create = async ({ url }) => {
      const id = nextId++, page = await context.newPage();
      pages.set(id, page);
      page.on('pageerror', e => pageErrors.push(e.message));
      await page.exposeBinding('__extensionSend', (_, message) => sendToWorker(id, message));
      await page.addInitScript(() => {
        window.__extensionListeners = [];
        window.chrome = { runtime: { id: "browser-fixture", lastError: null,
          sendMessage(message, callback) {
            window.__extensionSend(message).then(reply => { if (callback) callback(reply); });
          }, onMessage: { addListener(f) { window.__extensionListeners.push(f); } } } };
      });
      await page.addInitScript({ path: path.join(root, 'extension/keys.js') });
      await page.addInitScript({ path: path.join(root, 'extension/bridge.js') });
      await page.goto(url);
      activeId = id;
      return { id };
    };
    const events = { addListener() {} };
    vm.runInNewContext(read('extension/background.js'), {
      URL, console,
      fetch: async url => {
        if (url.includes('api/spotify/webnow?')) {
          const report = JSON.parse(new URL(url).searchParams.get('d'));
          now = report && report.title ? { ...report, web: true, paused: !report.playing } : {};
        }
        return { json: async () => ({}) };
      },
      chrome: {
        runtime: { onMessage: { addListener: f => listeners.push(f) }, onStartup: events, onInstalled: events },
        alarms: { create() {}, onAlarm: events },
        tabs: {
          onUpdated: { addListener() {} },
          query: async () => [...pages].map(([id, p]) => ({ id, url: p.url(), active: id === activeId })),
          create,
          update: async (id, changes) => {
            updates.push({ id, ...changes });
            if (changes.url) await pages.get(id).goto(changes.url);
            if (changes.active) { activeId = id; await pages.get(id).bringToFront(); }
          },
          sendMessage: async (id, msg) => pages.get(id).evaluate(message => {
            for (const f of window.__extensionListeners) f(message);
          }, msg),
        },
      },
    });
    // Silent WAV gives the browser a real looping media element, without Spotify/network credentials.
    const wav = Buffer.alloc(44 + 8000 * 2 * 30);
    wav.write('RIFF'); wav.writeUInt32LE(wav.length - 8, 4); wav.write('WAVEfmt ', 8);
    wav.writeUInt32LE(16, 16); wav.writeUInt16LE(1, 20); wav.writeUInt16LE(1, 22);
    wav.writeUInt32LE(8000, 24); wav.writeUInt32LE(16000, 28); wav.writeUInt16LE(2, 32);
    wav.writeUInt16LE(16, 34); wav.write('data', 36); wav.writeUInt32LE(wav.length - 44, 40);
    const art = 'https://image.test/cover.svg';
    await context.route('**/*', async route => {
      const url = route.request().url();
      if (url.startsWith(HOME + 'api/spotify/now')) return route.fulfill({ json: now });
      if (url.startsWith('https://image.test/')) return route.fulfill({ contentType: 'image/svg+xml', body: '<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80"><rect width="80" height="80" fill="green"/></svg>' });
      if (url.startsWith('https://open.spotify.com/')) return route.fulfill({ contentType: 'text/html', body: `
        <div data-testid="now-playing-widget"><a data-testid="context-item-link" href="/track/test">Fixture track</a>
        <a href="/artist/test">Fixture artist</a><img src="${art}"></div>
        <button data-testid="control-button-playpause" aria-label="Play">Play/Pause</button>
        <audio loop src="data:audio/wav;base64,${wav.toString('base64')}"></audio>
        <script>const audio = document.querySelector('audio'), button = document.querySelector('button');
        button.onclick = () => { if(audio.paused) audio.play(); else audio.pause(); };
        audio.onplay = () => button.setAttribute('aria-label','Pause');
        audio.onpause = () => button.setAttribute('aria-label','Play');</script>` });
      if (url.startsWith(HOME)) return route.fulfill({ contentType: 'text/html', body: `
        <style>${read('launcher/style.css')}</style><div id="modals"></div>
        <button id="launch" onclick="openApp('spotify')">Spotify</button>
        <script>${read('launcher/app.js')}</script>
        <script>function findApp(id) { return APPS.find(a => a.id === id); }
        function toast(message) { document.body.dataset.error = message; }</script>
        <script>${read('launcher/extras3.js')}</script><script>SpotifyNow.start();</script>` });
      return route.abort();
    });
    const { id: homeId } = await create({ url: HOME });
    const home = pages.get(homeId);
    await home.locator('#launch').click();
    const deadline = Date.now() + 8000;
    while (pages.size < 2 && Date.now() < deadline) await new Promise(r => setTimeout(r, 50));
    assert.equal(pages.size, 2, 'Opening Spotify creates its own persistent tab');
    const [spotifyId, spotify] = [...pages].find(([id]) => id !== homeId);
    await spotify.waitForLoadState();
    await spotify.locator('button').click();
    await spotify.waitForFunction(() => !document.querySelector('audio').paused);
    await spotify.waitForTimeout(350);
    const position = await spotify.locator('audio').evaluate(a => a.currentTime);
    await spotify.keyboard.press('Escape');
    await home.waitForFunction(() => document.querySelector('#spotify-bar.show .rb-text b')?.textContent === 'Fixture track');
    assert.equal(await home.locator('.rb-text small').textContent(), 'Fixture artist');
    assert.equal(await home.locator('.sb-cover').getAttribute('src'), art);
    assert.equal(await spotify.locator('audio').evaluate(a => a.paused), false);
    await spotify.waitForFunction(at => document.querySelector('audio').currentTime > at, position, { timeout: 5000 });
    await home.locator('.sb-toggle').click();
    await spotify.waitForFunction(() => document.querySelector('audio').paused);
    await home.waitForFunction(() => document.querySelector('.sb-toggle')?.getAttribute('aria-label') === 'Musik fortsetzen');
    await home.locator('.sb-toggle').click();
    await spotify.waitForFunction(() => !document.querySelector('audio').paused);
    for (let i = 0; i < 3; i++) {
      await home.locator('.sb-open').click();
      await spotify.waitForTimeout(150);
      await spotify.keyboard.press('F8');
      await home.waitForFunction(() => !document.hidden);
      assert.equal(activeId, homeId, 'A real Home key must activate Home, not navigate Spotify');
      await home.waitForTimeout(1600); // same debounce as a physical Home key
    }
    assert.equal(pages.size, 2);
    assert.equal(updates.filter(u => u.id === spotifyId && u.url).length, 0, 'Spotify never reloads');
    assert.equal(await spotify.locator('audio').evaluate(a => a.paused), false);
    assert.deepEqual(pageErrors, []);
    fs.mkdirSync(path.join(root, 'artifacts'), { recursive: true });
    await home.screenshot({ path: path.join(root, 'artifacts/spotify-mini-player.png') });
    console.log('Browser integration passed: metadata, cover, pause/resume, real audio position, repeated Home/reopen without reload.');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
