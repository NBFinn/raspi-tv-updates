// Native extension test: no emulated chrome API. Uses an isolated browser profile.
const assert=require('node:assert/strict'),fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os'),http=require('node:http');
const {spawn}=require('node:child_process');
const root=process.argv[2]||path.resolve(__dirname,'..');
const browserExe=process.env.BROWSER_EXECUTABLE||['C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe','/usr/bin/chromium','/usr/bin/chromium-browser'].find(p=>require('node:fs').existsSync(p));
const delay=ms=>new Promise(r=>setTimeout(r,ms));
class CDP{
 constructor(ws){this.ws=ws;this.id=0;this.pending=new Map();ws.addEventListener('message',e=>{const m=JSON.parse(String(e.data));const p=this.pending.get(m.id);if(p){clearTimeout(p.timer);this.pending.delete(m.id);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result)}})}
 send(method,params={}){return new Promise((resolve,reject)=>{const id=++this.id;const timer=setTimeout(()=>{this.pending.delete(id);reject(Error('CDP timeout: '+method))},10000);this.pending.set(id,{resolve,reject,timer});this.ws.send(JSON.stringify({id,method,params}))})}
 async evaluate(expression){const r=await this.send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value}
 async wait(expr,timeout=20000){const until=Date.now()+timeout;while(Date.now()<until){if(await this.evaluate(expr))return;await delay(100)}throw Error('UI timeout: '+expr)}
}
async function connect(url){const ws=new WebSocket(url);await new Promise((r,j)=>{ws.addEventListener('open',r,{once:true});ws.addEventListener('error',j,{once:true})});return new CDP(ws)}
let browser,profile,server,port;const connections=[];
const targets=async()=>await(await fetch('http://127.0.0.1:'+port+'/json')).json();
(async()=>{try{
 assert(browserExe,'Set BROWSER_EXECUTABLE to a Chromium browser supporting --load-extension');
 const source=await fs.readFile(path.join(root,'launcher/app.js'),'utf8');
 const opener=source.slice(source.indexOf('function openBgApp('),source.indexOf('window.addEventListener("pageshow"'));
 const html='<!doctype html><title>Raspi-TV extension test</title><button id="launch">Spotify</button><script>let opening=false;window.errors=[];function toast(s){errors.push(s)};'+opener+';launch.onclick=()=>{opening=true;const splash=document.createElement("div");document.body.appendChild(splash);openBgApp({url:"https://open.spotify.com/"},splash)};window.pageMarker=Math.random();</script>';
 server=http.createServer((req,res)=>{if(req.url.startsWith('/api/')){res.setHeader('Content-Type','application/json');res.end(JSON.stringify({sources:[],lang:'de'}))}else{res.setHeader('Content-Type','text/html; charset=utf-8');res.end(html)}});
 await new Promise((r,j)=>{server.once('error',j);server.listen(8765,'127.0.0.1',r)});
 profile=await fs.mkdtemp(path.join(os.tmpdir(),'raspitv-native-extension-'));
 browser=spawn(browserExe,['--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-renderer-backgrounding','--disable-background-timer-throttling','--remote-debugging-port=0','--remote-debugging-address=127.0.0.1','--user-data-dir='+profile,'--load-extension='+path.join(root,'extension'),'http://127.0.0.1:8765/'],{windowsHide:true,stdio:'ignore'});
 for(let i=0;i<200;i++){try{port=(await fs.readFile(path.join(profile,'DevToolsActivePort'),'utf8')).split('\n')[0];break}catch{await delay(100)}}assert(port,'Browser failed to start');
 const tab=(await targets()).find(t=>t.type==='page'&&t.url.startsWith('http://127.0.0.1:8765/'));assert(tab,'Home tab missing');
 const page=await connect(tab.webSocketDebuggerUrl);connections.push(page);await page.wait("location.origin==='http://127.0.0.1:8765'&&document.readyState==='complete'&&!!document.querySelector('#launch')");
 // Discover only our extension, without attaching to browser-supplied workers.
 const internal=browserExe.toLowerCase().includes('msedge')?'edge://extensions/':'chrome://extensions/';
 const infoTab=await(await fetch('http://127.0.0.1:'+port+'/json/new?'+internal,{method:'PUT'})).json();
 const info=await connect(infoTab.webSocketDebuggerUrl);connections.push(info);
 await info.wait("!!(globalThis.chrome&&chrome.developerPrivate&&chrome.developerPrivate.getExtensionsInfo)");
 let extensionId;
 for(let attempt=0;attempt<100&&!extensionId;attempt++){
  const list=await info.evaluate("new Promise(resolve=>chrome.developerPrivate.getExtensionsInfo({includeDisabled:true,includeTerminated:true},items=>resolve(items.filter(x=>x.name==='Raspi-TV System').map(x=>({id:x.id,state:x.state,errors:x.manifestErrors})))))");
  if(list.length){assert.equal(list[0].state,'ENABLED',JSON.stringify(list));extensionId=list[0].id;break}
  await delay(200);
 }
 assert(extensionId,'Native browser did not register the system extension');
 await info.send('Page.close');info.ws.close();
 const marker=await page.evaluate('pageMarker');
 await page.send('Page.bringToFront');await page.evaluate('launch.click()');await page.wait('!opening',15000);assert.deepEqual(await page.evaluate('errors'),[],'Initial Spotify opening failed');
 const spotify=(await targets()).find(t=>t.type==='page'&&t.url.startsWith('https://open.spotify.com/'));assert(spotify,'Spotify tab missing');
 let worker;
 for(const target of (await targets()).filter(t=>t.type==='service_worker'&&t.url==='chrome-extension://'+extensionId+'/background.js')){const c=await connect(target.webSocketDebuggerUrl);connections.push(c);if(await c.evaluate("chrome.runtime.getManifest().name==='Raspi-TV System'")){worker=c;break}}
 assert(worker,'System extension worker missing');
 // Reload while Home stays open: registered content scripts do not reinject themselves.
 await worker.evaluate('setTimeout(()=>chrome.runtime.reload(),100);true');
 await delay(1200);
 await page.send('Page.bringToFront');await page.evaluate('launch.click()');await page.wait('!opening',15000);
 assert.deepEqual(await page.evaluate('errors'),[],'An already-open Home tab must reconnect after extension reload');
 assert.equal(await page.evaluate('pageMarker'),marker,'Repair must preserve the existing Home document');
 const after=await targets(),spotifyTabs=after.filter(t=>t.type==='page'&&t.url.startsWith('https://open.spotify.com/'));
 assert.equal(spotifyTabs.length,1,'Reopening must reuse one Spotify tab');assert.equal(spotifyTabs[0].id,spotify.id,'The playback tab must survive extension reload');
 await page.send('Browser.close').catch(()=>{});
 console.log('Native browser passed: initial launch, extension reload on existing Home, one persistent Spotify tab.');
 }finally{
 if(connections[0]&&connections[0].ws.readyState===1)await connections[0].send('Browser.close').catch(()=>{});for(const c of connections)c.ws.close();if(browser){browser.kill();await Promise.race([new Promise(r=>browser.once('exit',r)),delay(2000)])}if(server){server.closeAllConnections();await new Promise(r=>server.close(r))}if(profile&&path.dirname(path.resolve(profile))===path.resolve(os.tmpdir())&&path.basename(profile).startsWith("raspitv-native-extension-"))await fs.rm(profile,{recursive:true,force:true,maxRetries:3,retryDelay:200}).catch(()=>{});
 }})().catch(e=>{console.error(e);process.exitCode=1});