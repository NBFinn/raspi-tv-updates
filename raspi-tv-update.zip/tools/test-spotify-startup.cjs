const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const root=process.argv[2]||path.resolve(__dirname,'..');
const read=name=>fs.readFileSync(path.join(root,name),'utf8');
async function workerRepair(){
 const events={},injections=[];
 const event=name=>({addListener:f=>(events[name]??=[]).push(f)});
 const chrome={tabs:{query:async()=>[{id:1,url:'http://127.0.0.1:8765/'},{id:2,url:'https://example.com/'}],onUpdated:event('updated')},
 scripting:{executeScript:async args=>injections.push(args)},runtime:{onMessage:event('message'),onStartup:event('startup'),onInstalled:event('installed')},alarms:{create(){},onAlarm:event('alarm')}};
 vm.runInNewContext(read('extension/background.js'),{chrome,URL,console,fetch:async()=>({json:async()=>({sources:[]})})});
 await new Promise(setImmediate);
 assert(injections.some(i=>i.target.tabId===1&&i.files.includes('bridge.js')),'Worker startup must restore the bridge in an already-open Home tab');
 assert(injections.every(i=>i.target.tabId===1),'Never inject the privileged Home bridge on external sites');
 injections.length=0;
 for(const f of events.updated||[])f(1,{status:'complete'},{id:1,url:'http://127.0.0.1:8765/'});
 await new Promise(setImmediate);
 assert.equal(injections.length,1,'A reloaded Home tab must recover the bridge');
}
async function bridge(){
 const listeners=new Set(),posts=[],sent=[],timers=[];let complete;
 const window={addEventListener:(type,f)=>{if(type==='message')listeners.add(f)},removeEventListener:(type,f)=>listeners.delete(f),postMessage:data=>posts.push(data)};window.top=window;
 const context={window,location:{origin:'http://127.0.0.1:8765'},chrome:{runtime:{id:"test-extension",lastError:null,sendMessage:(data,cb)=>{sent.push(data);complete=cb}}},setTimeout:f=>timers.push(f),Map,String};
 const run=()=>vm.runInNewContext(read('extension/bridge.js'),context);
 run();run();assert.equal(listeners.size,1,'Bridge reinjection replaces its old listener');
 const request={source:window,origin:context.location.origin,data:{type:'raspi-tv-open-bg',requestId:'once',url:'https://open.spotify.com/'}};
 for(const f of listeners){f({...request,origin:'https://evil.test'});f({...request,source:{}})}
 assert.equal(sent.length,0);
 for(const f of listeners){f(request);f(request)}
 assert.equal(sent.length,1,'A retried launch must not create duplicate Spotify tabs');
 complete({ok:true});await new Promise(setImmediate);
 assert(posts.some(p=>p.type==='raspi-tv-open-bg-ok'&&p.requestId==='once'&&p.ok));
 for(const f of listeners)f(request);
 assert.equal(sent.length,1,'A completed request is idempotent during retries');
}
(async()=>{await workerRepair();await bridge();console.log('Startup and bridge recovery passed.');})().catch(e=>{console.error(e);process.exitCode=1});