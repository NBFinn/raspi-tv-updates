const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');

async function testNavigation() {
  const listeners = [], updates = [], creates = [], messages = [];
  const tabs = [{ id: 1, url: 'http://127.0.0.1:8765/' },
    { id: 2, url: 'https://open.spotify.com/playlist/playing' }];
  const context = {
    URL, console, fetch: async () => ({ json: async () => ({}) }),
    chrome: {
      tabs: {
        onUpdated: { addListener() {} },
        query: async () => tabs,
        update: async (id, data) => updates.push({ id, ...data }),
        create: async data => { creates.push(data); return { id: 3 }; },
        sendMessage: async (id, data) => messages.push({ id, ...data }),
      },
      runtime: { onMessage: { addListener: f => listeners.push(f) },
        onStartup: { addListener() {} }, onInstalled: { addListener() {} } },
      alarms: { create() {}, onAlarm: { addListener() {} } },
    },
  };
  vm.runInNewContext(fs.readFileSync(path.join(root, 'extension/background.js'), 'utf8'), context);
  const send = async (message, tab) => {
    listeners.forEach(f => f(message, { tab }, () => {}));
    await new Promise(resolve => setImmediate(resolve));
  };
  tabs[1].pendingUrl = tabs[1].url;
  tabs[1].url = "";
  await send({ type: "raspi-tv-open-bg", url: "https://open.spotify.com/" }, tabs[0]);
  assert.equal(creates.length, 0, "A still-loading Spotify tab must be reused");
  tabs[1].url = tabs[1].pendingUrl; delete tabs[1].pendingUrl;
  for (let i = 0; i < 3; i++) {
    await send({ type: 'raspi-tv-home' }, tabs[1]);
    await send({ type: 'raspi-tv-open-bg', url: 'https://open.spotify.com/' }, tabs[0]);
  }
  assert.equal(creates.length, 0, 'Reopening must reuse the playback tab');
  assert.equal(messages.length, 0, 'Navigation must never pause or restart playback');
  assert(updates.filter(u => u.id === 2).every(u => !('url' in u)), 'Spotify must never reload');
  assert(updates.some(u => u.id === 2 && u.autoDiscardable === false));
  await send({ type: 'raspi-tv-spotify-control', action: 'toggle' }, tabs[0]);
  assert.equal(messages.at(-1).type, 'raspi-tv-spotify-toggle');
  assert.equal(messages.at(-1).id, 2);
  const before = messages.length;
  await send({ type: 'raspi-tv-spotify-control', action: 'toggle' }, { id: 8, url: 'https://example.com/' });
  assert.equal(messages.length, before, 'Only the local launcher may control Spotify');
  await send({ type: 'raspi-tv-spotify-control', action: 'refresh' }, tabs[0]);
  assert.equal(messages.at(-1).type, 'raspi-tv-spotify-refresh');
  await send({ type: 'raspi-tv-media-start' }, tabs[0]);
  assert.equal(messages.at(-1).type, 'raspi-tv-pause', 'Other audible media still pauses Spotify');
}

function testSpotifyControls() {
  const listeners = [], keys = [], reports = [];
  let clicks = 0, playing = true;
  const button = { disabled: false, click() { clicks++; playing = !playing; },
    getAttribute: () => playing ? 'Pause' : 'Play' };
  const window = { addEventListener: (name, f) => { if (name === 'keydown') keys.push(f); } };
  window.top = window;
  const context = {
    window, location: { hostname: 'open.spotify.com', origin: 'https://open.spotify.com' },
    navigator: { mediaSession: { metadata: { title: 'Track', artist: 'Artist', artwork: [{ src: 'https://cover.test/art.jpg' }] }, get playbackState() { return playing ? 'playing' : 'paused'; } } },
    document: { addEventListener() {}, querySelector: () => button },
    chrome: { runtime: { sendMessage: message => reports.push(message),
      onMessage: { addListener: f => listeners.push(f) } } },
    setInterval() {}, setTimeout: f => f(), Date, console,
  };
  vm.runInNewContext(fs.readFileSync(path.join(root, 'extension/keys.js'), 'utf8'), context);
  const send = type => listeners.forEach(f => f({ type }));
  send('raspi-tv-spotify-toggle');
  assert.equal(clicks, 1);
  assert.equal(reports.at(-1).now.playing, false);
  assert.equal(reports.at(-1).now.title, 'Track');
  assert.equal(reports.at(-1).now.cover, 'https://cover.test/art.jpg');
  send('raspi-tv-spotify-toggle');
  assert.equal(clicks, 2);
  assert.equal(reports.at(-1).now.playing, true);
  send('raspi-tv-spotify-refresh');
  assert.equal(clicks, 2, 'Refreshing metadata must not change playback');
  const event = { key: 'Escape', target: { matches: () => false }, preventDefault() {}, stopImmediatePropagation() {} };
  keys.at(-1)(event);
  assert.equal(reports.at(-1).type, 'raspi-tv-home');
  assert.equal(clicks, 2, 'Closing the view must not pause');
}

function testMissingExtension() {
  const source = fs.readFileSync(path.join(root, 'launcher/app.js'), 'utf8');
  const code = source.slice(source.indexOf('function openBgApp('), source.indexOf('window.addEventListener("pageshow"'));
  const timers = [], notices = [];
  const location = { origin: 'http://127.0.0.1:8765', href: 'http://127.0.0.1:8765/' };
  let removed = false;
  const context = { location, opening: true, Math, Date,
    toast: message => notices.push(message),
    window: { addEventListener() {}, removeEventListener() {}, postMessage() {} },
    setTimeout: f => timers.push(f), clearTimeout() {}, setInterval() {}, clearInterval() {},
  };
  vm.runInNewContext(code, context);
  context.openBgApp({ url: 'https://open.spotify.com/' }, { remove() { removed = true; } });
  timers.forEach(f => f());
  assert.equal(location.href, 'http://127.0.0.1:8765/', 'No destructive same-tab fallback when extension is missing');
  assert.equal(context.opening, false);
  assert(removed && notices.length === 1, 'Missing extension must leave Home usable with a visible error');
  const bindings = fs.readFileSync(path.join(root, 'user/xbindkeysrc'), 'utf8');
  const home = bindings.match(/"([^"\n]+)"\s+F12/)[1];
  assert(home.includes('F8') && !home.includes('raspi-tv-browser'), 'F12 must navigate Home without terminating the browser');
}

(async () => {
  await testNavigation();
  testSpotifyControls();
  testMissingExtension();
  console.log('Spotify regression checks passed: persistent tab, navigation, pause/resume, metadata, trusted controls.');
})().catch(error => { console.error(error); process.exitCode = 1; });
