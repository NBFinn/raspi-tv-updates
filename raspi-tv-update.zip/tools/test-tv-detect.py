"""7.7: Fernseher-Erkennung – entprellt, nur echte Wechsel, Standby/Aufwachen, Prüfung der Einstellungen."""
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('features', ROOT / 'system/features.py')
f = importlib.util.module_from_spec(spec)
spec.loader.exec_module(f)


class TvDetectTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.cfgp = Path(self.tmp.name) / 'config.json'
        self.cfgp.write_text(json.dumps({'tv_detect': {'delay': 10}}))
        self.power = 'on'
        self.calls = []
        f.bind({'load_config': lambda: json.loads(self.cfgp.read_text()), 'save_config': lambda c: None,
                'tv_power': lambda: self.power, 'tv_standby': lambda: self.calls.append('standby'),
                'TV_POWER_FILE': str(Path(self.tmp.name) / 'tv-power')})
        self.hpd = True
        f._hdmi_state = lambda: self.hpd
        f._cec_state = lambda: None
        f._set_tv_power = self.set_power
        f.touch_activity = lambda *_: None
        f._tvd_follow_power = lambda: None
        f._tvd['src'] = {n: f._TvSource(n) for n in ('hdmi', 'cec', 'gpio', 'shelly')}
        f._tvd['events'] = []

    def set_power(self, st):
        self.power = st
        self.calls.append('power-' + st)

    def tearDown(self):
        self.tmp.cleanup()

    def run_for(self, t0, secs):
        for t in range(t0, t0 + secs, 2):
            f._tvd_tick(float(t))
        return t0 + secs

    def test_off_then_on(self):
        t = self.run_for(0, 10)                    # Grundzustand an – nichts auslösen
        self.assertEqual(self.calls, [])
        self.hpd = False
        t = self.run_for(t, 6)                     # noch nicht lange genug aus
        self.assertEqual(self.calls, [])
        t = self.run_for(t, 8)
        self.assertEqual(self.calls, ['standby', 'power-standby'])
        self.hpd = True
        t = self.run_for(t, 6)
        self.assertEqual(self.calls[-1], 'power-on')
        self.assertTrue(f.tv_detect_status()['sources']['hdmi']['seen_change'])

    def test_short_blip_ignored_and_start_off(self):
        self.hpd = False
        t = self.run_for(0, 30)                    # schon beim Start aus: kein Standby
        self.assertEqual(self.calls, [])
        self.hpd = True
        t = self.run_for(t, 6)                     # an, aber Raspi-TV war nicht im Standby
        self.assertEqual(self.calls, [])
        self.hpd = False
        t = self.run_for(t, 4)
        self.hpd = True
        t = self.run_for(t, 20)                    # kurzer Aussetzer
        self.assertEqual(self.calls, [])

    def test_disabled(self):
        self.cfgp.write_text(json.dumps({'tv_detect': {'delay': 10, 'auto_standby': False, 'wake': False}}))
        t = self.run_for(0, 10)
        self.hpd = False
        t = self.run_for(t, 20)
        self.power = 'standby'
        self.hpd = True
        self.run_for(t, 10)
        self.assertEqual(self.calls, [])

    def test_valid(self):
        ok = f.tv_detect_valid
        self.assertTrue(ok({}))
        self.assertTrue(ok({'auto_standby': True, 'delay': 30, 'gpio': {'on': True, 'pin': 17, 'on_level': 'low', 'pull': 'up'},
                            'shelly': {'host': '192.168.1.50', 'watts': 15}}))
        for bad in ({'delay': 2}, {'delay': '20'}, {'gpio': {'pin': 26}}, {'gpio': {'pin': 40}},
                    {'shelly': {'host': 'a/b'}}, {'shelly': {'host': 'x;rm'}}, {'shelly': {'watts': 0}}, {'x': 1}):
            self.assertFalse(ok(bad), bad)

    def test_shelly(self):
        import io
        class R(io.BytesIO):
            def __enter__(s): return s
            def __exit__(s, *a): pass
        seen = []
        def fake(url, timeout):
            seen.append(url)
            if 'rpc' in url:
                raise OSError('gen1')
            return R(json.dumps({'meters': [{'power': 42.5}]}).encode())
        old = f.urllib.request.urlopen
        f.urllib.request.urlopen = fake
        try:
            self.assertEqual(f._shelly_watts('10.0.0.5'), 42.5)
            self.assertTrue(f._shelly_state({'host': '10.0.0.5', 'watts': 15}, 100.0))
        finally:
            f.urllib.request.urlopen = old


if __name__ == '__main__':
    unittest.main()
