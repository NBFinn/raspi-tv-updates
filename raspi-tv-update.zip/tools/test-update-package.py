import importlib.util
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
PACKAGER = Path(os.environ.get('RASPI_TV_PACKAGER_UNDER_TEST', ROOT/'tools/update-paket.ps1'))
ARCHIVE = ROOT/'fertig/raspi-tv-update.zip'
BASH = r'C:\Program Files\Git\bin\bash.exe' if os.name == 'nt' else shutil.which('bash')


class UpdatePackageTest(unittest.TestCase):
    @unittest.skipUnless(os.name == 'nt', 'Windows packager integration')
    def test_converts_linux_text_and_preserves_binary(self):
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder)
            fixture = {
                'VERSION': b'5.4.2\n',
                'system/apply-update.sh': b'\xef\xbb\xbf#!/bin/bash\r\nset -e\r\necho ready\r\n',
                'system/test.service': b'[Service]\r\nExecStart=/bin/true\r\n',
                'user/bash_profile': b'echo hello\r\n',
                'hook': b'#!/bin/sh\r\nexit 0\r\n',
                'image/stage-raspitv/00-test/00-packages-nr': b'python3-spidev\r\npython3-lgpio\r\n\r\n',
                'binary.bin': b'\x00\xff\r\n\x80',
            }
            for name, data in fixture.items():
                path = source/name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
            result = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(PACKAGER), '-Src', str(source)], capture_output=True, timeout=30)
            self.assertEqual(result.returncode, 0, result.stderr.decode('utf-8', 'replace'))
            with zipfile.ZipFile(source/'fertig/raspi-tv-update.zip') as archive:
                self.assertEqual(set(archive.namelist()), set(fixture))
                for name, data in fixture.items():
                    if name == 'binary.bin' or name == 'VERSION':
                        self.assertEqual(archive.read(name), data)
                    else:
                        self.assertEqual(archive.read(name), data.removeprefix(b'\xef\xbb\xbf').replace(b'\r\n', b'\n'))
    def test_complete_archive_has_linux_ready_scripts(self):
        spec = importlib.util.spec_from_file_location('recovery_package', ROOT/'system/recovery.py')
        recovery = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(recovery)
        self.assertEqual(recovery.inspect_update(ARCHIVE), ('', (ROOT/'VERSION').read_text().strip()))
        with zipfile.ZipFile(ARCHIVE) as archive:
            names = archive.namelist()
            self.assertTrue(all('\\' not in name and not name.endswith('/') for name in names))
            self.assertFalse(any(name.startswith(('fertig/', 'artifacts/', '.git/')) for name in names))
            for name in names:
                if name.endswith(('.sh', '.service', '/00-packages-nr')) or name in ('user/xinitrc', 'user/bash_profile', 'user/xbindkeysrc'):
                    data = archive.read(name)
                    self.assertNotIn(b'\r', data, name)
                    self.assertFalse(data.startswith(b'\xef\xbb\xbf'), name)
            module = {}
            exec(compile(archive.read('system/dlna.py'), 'dlna.py', 'exec'), module)
            self.assertEqual(module['PORT'], 8768)
            pin_module = {}
            exec(compile(archive.read('system/recovery.py'), 'recovery.py', 'exec'), pin_module)
            self.assertTrue(pin_module['valid_admin_code']('0042'))
            self.assertFalse(pin_module['valid_admin_code']('legacy-long-code'))
    @unittest.skipUnless(BASH and Path(BASH).exists(), 'Bash unavailable')
    def test_all_packaged_shell_scripts_have_valid_syntax(self):
        with zipfile.ZipFile(ARCHIVE) as archive:
            for name in archive.namelist():
                if name.endswith('.sh'):
                    with self.subTest(name=name):
                        result = subprocess.run([BASH, '--noprofile', '--norc', '-n'], input=archive.read(name), capture_output=True, timeout=10)
                        self.assertEqual(result.returncode, 0, result.stderr.decode('utf-8', 'replace'))
    @unittest.skipUnless(BASH and Path(BASH).exists(), 'Bash unavailable')
    def test_real_file_installation_into_isolated_root(self):
        with tempfile.TemporaryDirectory() as folder:
            sandbox = Path(folder).resolve()
            source = sandbox/'source'
            target = sandbox/'rootfs'
            source.mkdir()
            (target/'etc/systemd/system').mkdir(parents=True)
            self.assertTrue(target.resolve().is_relative_to(sandbox))
            with zipfile.ZipFile(ARCHIVE) as archive:
                archive.extractall(source)
            result = subprocess.run([BASH, str(source/'system/install-files.sh').replace('\\', '/'), str(source).replace('\\', '/'), str(target).replace('\\', '/')], capture_output=True, timeout=30)
            self.assertEqual(result.returncode, 0, result.stderr.decode('utf-8', 'replace'))
            self.assertEqual((target/'opt/raspi-tv/VERSION').read_text().strip(), (ROOT/'VERSION').read_text().strip())
            self.assertEqual((target/'opt/raspi-tv/dlna.py').read_bytes(), (source/'system/dlna.py').read_bytes())
            self.assertTrue((target/'etc/systemd/system/raspi-tv-recovery.service').is_file())
            self.assertTrue((target/'opt/raspi-tv/launcher/index.html').is_file())
            self.assertTrue((target/'opt/raspi-tv/recovery.html').is_file())
            for asset in ('xterm.js', 'xterm.css', 'xterm-addon-fit.js'):
                self.assertEqual((target/'opt/raspi-tv/recovery-assets'/asset).read_bytes(),
                                 (source/'launcher'/asset).read_bytes())
            self.assertEqual((target/'opt/raspi-tv/recovery-assets/terminal.py').read_bytes(),
                             (source/'system/terminal.py').read_bytes())
            self.assertIn('http://127.0.0.1:8767/local',
                          (target/'opt/raspi-tv/start-browser.sh').read_text())
            self.assertIn('F10', (target/'opt/raspi-tv/user/xbindkeysrc').read_text())
            self.assertTrue((target/'opt/raspi-tv/open-recovery.sh').is_file())
            self.assertEqual((target/'opt/raspi-tv/maintenance.py').read_bytes(),
                             (source/'system/maintenance.py').read_bytes())
            self.assertEqual((target/'opt/raspi-tv/recovery-assets/maintenance.js').read_bytes(),
                             (source/'system/maintenance.js').read_bytes())
            self.assertEqual((target/'opt/raspi-tv/recovery-assets/qrcode.js').read_bytes(),
                             (source/'launcher/qrcode.js').read_bytes())
            self.assertTrue((target/'opt/raspi-tv/browser-guard.py').is_file())
            for name in ('display-watch.sh','display_settings.py','launcher/round-displays.js','display-diagnostics.py','fan-setup.py','enable-fan.sh','multimedia.py','round-displays.py','enable-round-displays.sh','launcher/multimedia.js','launcher/mirror.html'):
                self.assertTrue((target/'opt/raspi-tv'/name).is_file(), name)
            self.assertTrue((target/'etc/systemd/system/raspi-tv-round.service').is_file())
            self.assertTrue((target/'opt/raspi-tv/extension/_metadata').is_dir())
            self.assertEqual((target/'opt/raspi-tv/extension/bridge.js').read_bytes(), (source/'extension/bridge.js').read_bytes())



if __name__ == '__main__':
    unittest.main()
